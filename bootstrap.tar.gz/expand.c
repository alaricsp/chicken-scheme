/* Generated from expand.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-10-29 11:59
   Version 4.0.0x - linux-unix-gnu-x86	[ ptables applyhook ]
   SVN rev. 12299	compiled 2008-10-29 on dill (Linux)
   command line: expand.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -output-file expand.c
   unit: expand
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[391];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,17),40,100,32,97,114,103,49,55,32,46,32,109,111,114,101,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,18),40,108,111,111,107,117,112,32,105,100,50,52,32,115,101,50,53,41,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,24),40,109,97,99,114,111,45,97,108,105,97,115,32,118,97,114,52,53,32,115,101,52,54,41};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,11),40,97,51,53,56,57,32,97,56,48,41,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,13),40,109,97,112,45,115,101,32,115,101,55,56,41,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,11),40,119,97,108,107,32,120,49,49,53,41,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,24),40,98,111,100,121,49,48,48,32,115,101,49,49,48,32,97,108,105,97,115,49,49,49,41};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,23),40,100,101,102,45,97,108,105,97,115,49,48,51,32,37,115,101,57,56,49,51,57,41,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,11),40,100,101,102,45,115,101,49,48,50,41,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,36),40,35,35,115,121,115,35,115,116,114,105,112,45,115,121,110,116,97,120,32,101,120,112,57,48,32,46,32,116,109,112,56,57,57,49,41,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,57),40,35,35,115,121,115,35,101,120,116,101,110,100,45,109,97,99,114,111,45,101,110,118,105,114,111,110,109,101,110,116,32,110,97,109,101,49,53,57,32,115,101,49,54,48,32,104,97,110,100,108,101,114,49,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,32),40,35,35,115,121,115,35,99,111,112,121,45,109,97,99,114,111,32,111,108,100,49,56,49,32,110,101,119,49,56,50,41};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,27),40,109,97,99,114,111,63,32,115,121,109,49,57,52,32,46,32,116,109,112,49,57,51,49,57,53,41,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,109,101,50,50,56,41,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,32),40,35,35,115,121,115,35,117,110,114,101,103,105,115,116,101,114,45,109,97,99,114,111,32,110,97,109,101,50,50,52,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,25),40,117,110,100,101,102,105,110,101,45,109,97,99,114,111,33,32,110,97,109,101,50,52,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,12),40,99,111,112,121,32,112,115,50,55,53,41,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,7),40,97,51,57,54,48,41,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,13),40,97,51,57,53,52,32,101,120,50,54,56,41,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,7),40,97,52,48,54,55,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,7),40,97,52,48,57,52,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,20),40,97,52,48,56,56,32,46,32,97,114,103,115,50,54,50,50,57,53,41,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,7),40,97,52,48,54,49,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,15),40,97,51,57,52,56,32,107,50,54,49,50,54,54,41,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,46),40,99,97,108,108,45,104,97,110,100,108,101,114,32,110,97,109,101,50,53,50,32,104,97,110,100,108,101,114,50,53,51,32,101,120,112,50,53,52,32,115,101,50,53,53,41,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,31),40,101,120,112,97,110,100,32,104,101,97,100,51,48,48,32,101,120,112,51,48,49,32,109,100,101,102,51,48,50,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,12),40,97,52,51,50,52,32,98,51,55,52,41,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,30),40,35,35,115,121,115,35,101,120,112,97,110,100,45,48,32,101,120,112,50,52,55,32,100,115,101,50,52,56,41,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,109,111,100,117,108,101,45,114,101,110,97,109,101,32,115,121,109,51,57,49,32,112,114,101,102,105,120,51,57,50,41,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,16),40,109,114,101,110,97,109,101,32,115,121,109,52,48,56,41};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,97,108,105,97,115,45,103,108,111,98,97,108,45,104,111,111,107,32,115,121,109,51,57,54,32,97,115,115,105,103,110,51,57,55,41,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,7),40,97,52,53,51,53,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,32),40,97,52,53,52,49,32,101,120,112,50,52,55,53,52,55,54,52,56,49,32,109,52,55,55,52,55,56,52,56,50,41};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,101,120,112,52,55,50,41,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,101,120,112,97,110,100,32,101,120,112,52,53,55,32,46,32,116,109,112,52,53,54,52,53,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,108,108,105,115,116,52,57,54,41,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,101,120,116,101,110,100,101,100,45,108,97,109,98,100,97,45,108,105,115,116,63,32,108,108,105,115,116,52,57,50,41,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,12),40,101,114,114,32,109,115,103,53,51,50,41,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,12),40,97,52,56,52,48,32,107,53,54,53,41,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,44),40,108,111,111,112,32,109,111,100,101,53,52,55,32,114,101,113,53,52,56,32,111,112,116,53,52,57,32,107,101,121,53,53,48,32,108,108,105,115,116,53,53,49,41,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,67),40,35,35,115,121,115,35,101,120,112,97,110,100,45,101,120,116,101,110,100,101,100,45,108,97,109,98,100,97,45,108,105,115,116,32,108,108,105,115,116,48,53,50,53,32,98,111,100,121,53,50,54,32,101,114,114,104,53,50,55,32,115,101,53,50,56,41,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,98,111,100,121,50,55,48,51,32,101,120,112,115,55,48,52,41,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,17),40,97,53,52,48,52,32,118,55,54,48,32,116,55,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,18),40,97,53,51,54,55,32,118,115,55,53,49,32,120,55,53,50,41,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,17),40,97,53,52,51,52,32,118,55,52,52,32,120,55,52,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,12),40,97,53,52,53,50,32,118,55,52,50,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,48),40,102,105,110,105,32,118,97,114,115,54,57,51,32,118,97,108,115,54,57,52,32,109,118,97,114,115,54,57,53,32,109,118,97,108,115,54,57,54,32,98,111,100,121,54,57,55,41};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,30),40,108,111,111,112,32,98,111,100,121,55,56,50,32,100,101,102,115,55,56,51,32,100,111,110,101,55,56,52,41,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,55),40,102,105,110,105,47,115,121,110,116,97,120,32,118,97,114,115,55,55,52,32,118,97,108,115,55,55,53,32,109,118,97,114,115,55,55,54,32,109,118,97,108,115,55,55,55,32,98,111,100,121,55,55,56,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,50,32,120,56,53,56,41,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,48),40,108,111,111,112,32,98,111,100,121,56,50,49,32,118,97,114,115,56,50,50,32,118,97,108,115,56,50,51,32,109,118,97,114,115,56,50,52,32,109,118,97,108,115,56,50,53,41};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,16),40,101,120,112,97,110,100,32,98,111,100,121,56,49,55,41};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,45),40,35,35,115,121,115,35,99,97,110,111,110,105,99,97,108,105,122,101,45,98,111,100,121,32,98,111,100,121,54,55,55,32,46,32,116,109,112,54,55,54,54,55,56,41,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,17),40,109,119,97,108,107,32,120,57,48,53,32,112,57,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,40),40,109,97,116,99,104,45,101,120,112,114,101,115,115,105,111,110,32,101,120,112,56,57,54,32,112,97,116,56,57,55,32,118,97,114,115,56,57,56,41};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,104,101,97,100,57,52,49,32,98,111,100,121,57,52,50,41,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,51),40,35,35,115,121,115,35,101,120,112,97,110,100,45,99,117,114,114,105,101,100,45,100,101,102,105,110,101,32,104,101,97,100,57,51,52,32,98,111,100,121,57,51,53,32,115,101,57,51,54,41,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,115,121,110,116,97,120,45,101,114,114,111,114,45,104,111,111,107,32,46,32,97,114,103,115,57,54,48,41,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,25),40,103,101,116,45,108,105,110,101,45,110,117,109,98,101,114,32,115,101,120,112,57,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,13),40,101,114,114,32,109,115,103,49,48,52,49,41,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,29),40,116,101,115,116,32,120,49,48,51,53,32,112,114,101,100,49,48,51,54,32,109,115,103,49,48,51,55,41,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,120,49,48,53,57,41,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,20),40,108,97,109,98,100,97,45,108,105,115,116,63,32,120,49,48,52,57,41,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,20),40,112,114,111,112,101,114,45,108,105,115,116,63,32,120,49,48,56,48,41,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,24),40,100,111,108,111,111,112,49,49,50,57,32,120,49,49,51,54,32,110,49,49,51,55,41};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,13),40,97,54,52,57,52,32,121,49,49,53,55,41,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,18),40,119,97,108,107,32,120,49,49,48,51,32,112,49,49,48,52,41,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,29),40,98,111,100,121,49,48,49,54,32,99,117,108,112,114,105,116,49,48,50,54,32,115,101,49,48,50,55,41,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,29),40,100,101,102,45,115,101,49,48,49,57,32,37,99,117,108,112,114,105,116,49,48,49,52,49,49,55,51,41,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,17),40,100,101,102,45,99,117,108,112,114,105,116,49,48,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,57),40,35,35,115,121,115,35,99,104,101,99,107,45,115,121,110,116,97,120,32,105,100,49,48,48,52,32,101,120,112,49,48,48,53,32,112,97,116,49,48,48,54,32,46,32,116,109,112,49,48,48,51,49,48,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,16),40,114,101,110,97,109,101,32,115,121,109,49,49,57,56,41};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,31),40,108,111,111,107,117,112,50,32,110,49,51,51,53,32,115,121,109,49,51,51,54,32,100,115,101,49,51,51,55,41,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,23),40,99,111,109,112,97,114,101,32,115,49,49,50,53,49,32,115,50,49,50,53,50,41,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,32),40,102,95,54,54,50,52,32,102,111,114,109,49,49,56,57,32,115,101,49,49,57,48,32,100,115,101,49,49,57,49,41};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,101,114,45,116,114,97,110,115,102,111,114,109,101,114,32,104,97,110,100,108,101,114,49,49,56,55,41,0,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,17),40,114,101,115,111,108,118,101,32,115,121,109,49,51,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,13),40,116,111,115,116,114,32,120,49,51,55,52,41,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,10),40,115,119,97,112,49,52,48,50,41,0,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,7),40,97,55,48,53,50,41,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,22),40,105,109,112,111,114,116,45,110,97,109,101,32,115,112,101,99,49,51,56,51,41,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,32,105,100,115,49,52,57,48,32,118,49,52,57,49,32,115,49,52,57,50,41,0,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,105,109,112,115,49,53,51,49,32,115,49,53,51,50,41,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,105,109,112,118,49,53,49,57,32,118,49,53,50,48,41,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,14),40,97,55,51,50,57,32,105,100,49,53,55,48,41,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,44),40,108,111,111,112,32,105,109,112,118,49,53,52,56,32,105,109,112,115,49,53,52,57,32,118,49,53,53,48,32,115,49,53,53,49,32,105,100,115,49,53,53,50,41,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,13),40,114,101,110,32,105,109,112,49,53,56,57,41,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,22),40,105,109,112,111,114,116,45,115,112,101,99,32,115,112,101,99,49,52,53,52,41,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,15),40,97,55,53,57,48,32,105,109,112,49,54,50,57,41,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,15),40,97,55,54,51,50,32,105,109,112,49,54,49,57,41,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,16),40,97,55,53,51,56,32,115,112,101,99,49,53,57,55,41};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,86),40,35,35,115,121,115,35,101,120,112,97,110,100,45,105,109,112,111,114,116,32,120,49,51,52,57,32,114,49,51,53,48,32,99,49,51,53,49,32,105,109,112,111,114,116,45,101,110,118,49,51,53,50,32,109,97,99,114,111,45,101,110,118,49,51,53,51,32,109,101,116,97,63,49,51,53,52,32,108,111,99,49,51,53,53,41,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,18),40,102,95,55,57,49,48,32,114,117,108,101,115,50,50,57,54,41,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,13),40,97,56,48,53,51,32,120,50,51,49,53,41,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,17),40,102,95,56,48,48,52,32,114,117,108,101,50,51,48,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,30),40,102,95,56,48,56,56,32,105,110,112,117,116,50,51,49,55,32,112,97,116,116,101,114,110,50,51,49,56,41,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,30),40,102,95,56,51,48,57,32,105,110,112,117,116,50,51,54,55,32,112,97,116,116,101,114,110,50,51,54,56,41,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,10),40,108,112,32,105,50,52,48,57,41,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,30),40,102,95,56,52,50,55,32,105,110,112,117,116,50,51,56,52,32,112,97,116,116,101,114,110,50,51,56,53,41,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,13),40,97,56,55,53,51,32,120,50,52,52,53,41,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,10),40,108,112,32,105,50,52,55,51,41,0,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,39),40,102,95,56,55,49,53,32,112,97,116,116,101,114,110,50,52,51,52,32,112,97,116,104,50,52,51,53,32,109,97,112,105,116,50,52,51,54,41,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,26),40,100,111,108,111,111,112,50,53,50,57,32,100,50,53,51,53,32,103,101,110,50,53,51,54,41,0,0,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,37),40,102,95,56,57,50,50,32,116,101,109,112,108,97,116,101,50,52,56,56,32,100,105,109,50,52,56,57,32,101,110,118,50,52,57,48,41,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,37),40,102,95,57,49,55,54,32,112,97,116,116,101,114,110,50,53,54,50,32,100,105,109,50,53,54,51,32,118,97,114,115,50,53,54,52,41,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,46),40,102,95,57,50,52,57,32,116,101,109,112,108,97,116,101,50,53,55,51,32,100,105,109,50,53,55,52,32,101,110,118,50,53,55,53,32,102,114,101,101,50,53,55,54,41,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,20),40,102,95,57,51,52,50,32,112,97,116,116,101,114,110,50,53,57,49,41,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,20),40,102,95,57,51,54,52,32,112,97,116,116,101,114,110,50,54,48,49,41,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,20),40,102,95,57,51,57,48,32,112,97,116,116,101,114,110,50,54,48,55,41,0,0,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,112,97,116,116,101,114,110,50,54,49,51,41,0,0,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,20),40,102,95,57,52,49,48,32,112,97,116,116,101,114,110,50,54,48,57,41,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,79),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,115,121,110,116,97,120,45,114,117,108,101,115,32,101,108,108,105,112,115,105,115,50,50,51,57,32,114,117,108,101,115,50,50,52,48,32,115,117,98,107,101,121,119,111,114,100,115,50,50,52,49,32,114,50,50,52,50,32,99,50,50,52,51,41,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,13),40,109,111,100,117,108,101,45,110,97,109,101,41,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,20),40,109,111,100,117,108,101,45,101,120,112,111,114,116,45,108,105,115,116,41,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,46),40,115,101,116,45,109,111,100,117,108,101,45,100,101,102,105,110,101,100,45,108,105,115,116,33,32,120,50,54,56,48,50,55,49,49,32,121,50,54,56,49,50,55,49,50,41,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,21),40,109,111,100,117,108,101,45,100,101,102,105,110,101,100,45,108,105,115,116,41,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,19),40,109,111,100,117,108,101,45,101,120,105,115,116,45,108,105,115,116,41,0,0,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,28),40,109,111,100,117,108,101,45,100,101,102,105,110,101,100,45,115,121,110,116,97,120,45,108,105,115,116,41,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,48),40,115,101,116,45,109,111,100,117,108,101,45,117,110,100,101,102,105,110,101,100,45,108,105,115,116,33,32,120,50,54,56,48,50,55,51,53,32,121,50,54,56,49,50,55,51,54,41};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,33),40,109,111,100,117,108,101,45,117,110,100,101,102,105,110,101,100,45,108,105,115,116,32,120,50,54,56,48,50,55,51,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,21),40,109,111,100,117,108,101,45,105,109,112,111,114,116,45,102,111,114,109,115,41,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,26),40,109,111,100,117,108,101,45,109,101,116,97,45,105,109,112,111,114,116,45,102,111,114,109,115,41,0,0,0,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,25),40,109,111,100,117,108,101,45,109,101,116,97,45,101,120,112,114,101,115,115,105,111,110,115,41,0,0,0,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,17),40,109,111,100,117,108,101,45,118,101,120,112,111,114,116,115,41,0,0,0,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,17),40,109,111,100,117,108,101,45,115,101,120,112,111,114,116,115,41,0,0,0,0,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,51),40,109,97,107,101,45,109,111,100,117,108,101,32,101,120,112,108,105,115,116,50,56,48,55,32,118,101,120,112,111,114,116,115,50,56,48,56,32,115,101,120,112,111,114,116,115,50,56,48,57,41,0,0,0,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,102,105,110,100,45,109,111,100,117,108,101,32,110,97,109,101,50,56,49,57,32,46,32,116,109,112,50,56,49,56,50,56,50,48,41,0,0,0,0,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,64),40,35,35,115,121,115,35,116,111,112,108,101,118,101,108,45,100,101,102,105,110,105,116,105,111,110,45,104,111,111,107,32,115,121,109,50,56,52,52,32,109,111,100,50,56,52,53,32,101,120,112,50,56,52,54,32,118,97,108,50,56,52,55,41};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,40),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,109,101,116,97,45,101,120,112,114,101,115,115,105,111,110,32,101,120,112,50,56,53,49,41};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,42),40,99,104,101,99,107,45,102,111,114,45,114,101,100,101,102,32,115,121,109,50,56,54,48,32,101,110,118,50,56,54,49,32,115,101,110,118,50,56,54,50,41,0,0,0,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,101,120,112,111,114,116,32,115,121,109,50,56,55,55,32,109,111,100,50,56,55,56,41,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,54),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,115,121,110,116,97,120,45,101,120,112,111,114,116,32,115,121,109,50,57,48,50,32,109,111,100,50,57,48,51,32,118,97,108,50,57,48,52,41,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,117,110,100,101,102,105,110,101,100,32,115,121,109,50,57,50,56,32,109,111,100,50,57,50,57,41,0,0,0,0,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,23),40,98,111,100,121,50,57,53,54,32,115,101,120,112,111,114,116,115,50,57,54,55,41,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,18),40,100,101,102,45,115,101,120,112,111,114,116,115,50,57,53,57,41,0,0,0,0,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,58),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,109,111,100,117,108,101,32,110,97,109,101,50,57,52,53,32,101,120,112,108,105,115,116,50,57,52,54,32,46,32,116,109,112,50,57,52,52,50,57,52,55,41,0,0,0,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,16),40,97,49,48,48,49,51,32,105,109,112,50,57,57,49,41};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,36),40,35,35,115,121,115,35,109,97,114,107,45,105,109,112,111,114,116,101,100,45,115,121,109,98,111,108,115,32,115,101,50,57,56,57,41,0,0,0,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,21),40,119,97,114,110,32,109,115,103,51,48,51,48,32,105,100,51,48,51,49,41,0,0,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,50,32,105,101,120,112,111,114,116,115,51,48,52,54,41,0,0,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,101,120,112,111,114,116,115,51,48,51,53,41,0,0,0,0,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,33),40,109,111,100,117,108,101,45,105,110,100,105,114,101,99,116,45,101,120,112,111,114,116,115,32,109,111,100,51,48,48,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,115,101,51,48,57,55,41,0,0,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,18),40,109,101,114,103,101,45,115,101,32,115,101,115,51,48,57,48,41,0,0,0,0,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,20),40,97,49,48,53,48,48,32,115,101,120,112,111,114,116,51,49,52,50,41,0,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,15),40,97,49,48,53,54,53,32,105,101,51,49,51,50,41,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,44),40,35,35,115,121,115,35,99,111,109,112,105,108,101,100,45,109,111,100,117,108,101,45,114,101,103,105,115,116,114,97,116,105,111,110,32,109,111,100,51,49,49,51,41,0,0,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,17),40,97,49,48,55,51,50,32,105,101,120,112,51,49,56,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,17),40,97,49,48,55,53,50,32,115,101,120,112,51,49,55,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,15),40,97,49,48,55,55,48,32,105,101,51,49,55,48,41,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,15),40,97,49,48,56,48,50,32,115,101,51,49,54,54,41,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,80),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,99,111,109,112,105,108,101,100,45,109,111,100,117,108,101,32,110,97,109,101,51,49,53,57,32,105,101,120,112,111,114,116,115,51,49,54,48,32,118,101,120,112,111,114,116,115,51,49,54,49,32,115,101,120,112,111,114,116,115,51,49,54,50,41};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,15),40,97,49,48,56,52,56,32,115,101,51,50,49,57,41,0};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,15),40,97,49,48,56,54,54,32,118,101,51,50,49,52,41,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,69),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,112,114,105,109,105,116,105,118,101,45,109,111,100,117,108,101,32,110,97,109,101,51,49,57,54,32,118,101,120,112,111,114,116,115,51,49,57,55,32,46,32,116,109,112,51,49,57,53,51,49,57,56,41,0,0,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,120,108,51,50,52,48,41,0,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,48),40,35,35,115,121,115,35,102,105,110,100,45,101,120,112,111,114,116,32,115,121,109,51,50,51,50,32,109,111,100,51,50,51,51,32,105,110,100,105,114,101,99,116,51,50,51,52,41};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,14),40,97,49,49,49,51,50,32,109,51,51,54,49,41,0,0};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,16),40,97,49,49,49,56,48,32,101,120,112,51,51,52,50,41};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,14),40,97,49,49,50,49,56,32,117,51,51,51,54,41,0,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,120,108,51,51,48,56,41,0,0,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,15),40,97,49,49,51,54,54,32,115,100,51,50,56,57,41,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,109,101,51,50,57,51,41,0,0,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,16),40,97,49,49,52,50,56,32,115,121,109,51,50,56,53,41};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,102,105,110,97,108,105,122,101,45,109,111,100,117,108,101,32,109,111,100,51,50,55,51,41,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,109,101,51,51,56,54,41,0,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,28),40,35,35,115,121,115,35,109,97,99,114,111,45,115,117,98,115,101,116,32,109,101,48,51,51,56,50,41,0,0,0,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,28),40,97,49,49,52,57,49,32,101,120,112,50,50,50,51,32,114,50,50,50,52,32,99,50,50,50,53,41,0,0,0,0};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,16),40,97,49,49,53,53,56,32,101,120,112,50,49,57,57,41};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,26),40,97,49,49,53,50,56,32,120,50,49,57,48,32,114,50,49,57,49,32,99,50,49,57,50,41,0,0,0,0,0,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,26),40,97,49,49,54,51,49,32,120,50,49,55,48,32,114,50,49,55,49,32,99,50,49,55,50,41,0,0,0,0,0,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,26),40,97,49,49,54,56,53,32,120,50,49,54,48,32,114,50,49,54,49,32,99,50,49,54,50,41,0,0,0,0,0,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,26),40,97,49,49,55,51,54,32,120,50,49,52,57,32,114,50,49,53,48,32,99,50,49,53,49,41,0,0,0,0,0,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,26),40,97,49,49,55,53,55,32,120,50,49,51,56,32,114,50,49,51,57,32,99,50,49,52,48,41,0,0,0,0,0,0};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,11),40,101,114,114,32,120,50,48,53,51,41,0,0,0,0,0};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,13),40,116,101,115,116,32,102,120,50,48,53,53,41,0,0,0};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,14),40,97,49,49,57,55,53,32,120,50,49,48,57,41,0,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,16),40,101,120,112,97,110,100,32,99,108,115,50,49,48,48,41};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,29),40,97,49,49,55,55,56,32,102,111,114,109,50,48,52,48,32,114,50,48,52,49,32,99,50,48,52,50,41,0,0,0};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,29),40,97,49,50,48,54,50,32,102,111,114,109,50,48,51,48,32,114,50,48,51,49,32,99,50,48,51,50,41,0,0,0};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,18),40,119,97,108,107,32,120,49,57,50,50,32,110,49,57,50,51,41,0,0,0,0,0,0};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,19),40,119,97,108,107,49,32,120,49,57,50,53,32,110,49,57,50,54,41,0,0,0,0,0};
static C_char C_TLS li184[] C_aligned={C_lihdr(0,0,16),40,115,105,109,112,108,105,102,121,32,120,49,57,57,48,41};
static C_char C_TLS li185[] C_aligned={C_lihdr(0,0,29),40,97,49,50,48,57,53,32,102,111,114,109,49,57,49,48,32,114,49,57,49,49,32,99,49,57,49,50,41,0,0,0};
static C_char C_TLS li186[] C_aligned={C_lihdr(0,0,14),40,97,49,50,53,57,53,32,98,49,57,48,54,41,0,0};
static C_char C_TLS li187[] C_aligned={C_lihdr(0,0,14),40,97,49,50,54,53,48,32,98,49,56,57,52,41,0,0};
static C_char C_TLS li188[] C_aligned={C_lihdr(0,0,29),40,97,49,50,52,57,48,32,102,111,114,109,49,56,55,56,32,114,49,56,55,57,32,99,49,56,56,48,41,0,0,0};
static C_char C_TLS li189[] C_aligned={C_lihdr(0,0,15),40,101,120,112,97,110,100,32,98,115,49,56,54,52,41,0};
static C_char C_TLS li190[] C_aligned={C_lihdr(0,0,29),40,97,49,50,54,55,50,32,102,111,114,109,49,56,53,52,32,114,49,56,53,53,32,99,49,56,53,54,41,0,0,0};
static C_char C_TLS li191[] C_aligned={C_lihdr(0,0,14),40,97,49,50,56,54,53,32,120,49,56,52,51,41,0,0};
static C_char C_TLS li192[] C_aligned={C_lihdr(0,0,20),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,49,56,51,48,41,0,0,0,0};
static C_char C_TLS li193[] C_aligned={C_lihdr(0,0,29),40,97,49,50,55,52,49,32,102,111,114,109,49,56,49,48,32,114,49,56,49,49,32,99,49,56,49,50,41,0,0,0};
static C_char C_TLS li194[] C_aligned={C_lihdr(0,0,20),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,49,55,54,54,41,0,0,0,0};
static C_char C_TLS li195[] C_aligned={C_lihdr(0,0,29),40,97,49,50,57,49,49,32,102,111,114,109,49,55,53,49,32,114,49,55,53,50,32,99,49,55,53,51,41,0,0,0};
static C_char C_TLS li196[] C_aligned={C_lihdr(0,0,29),40,97,49,51,50,52,52,32,102,111,114,109,49,55,51,53,32,114,49,55,51,54,32,99,49,55,51,55,41,0,0,0};
static C_char C_TLS li197[] C_aligned={C_lihdr(0,0,29),40,97,49,51,51,51,52,32,102,111,114,109,49,55,50,49,32,114,49,55,50,50,32,99,49,55,50,51,41,0,0,0};
static C_char C_TLS li198[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,102,111,114,109,49,54,57,48,41,0};
static C_char C_TLS li199[] C_aligned={C_lihdr(0,0,29),40,97,49,51,51,57,51,32,102,111,114,109,49,54,56,52,32,114,49,54,56,53,32,99,49,54,56,54,41,0,0,0};
static C_char C_TLS li200[] C_aligned={C_lihdr(0,0,50),40,97,49,51,53,51,53,32,103,49,54,55,50,49,54,55,51,49,54,55,56,32,103,49,54,55,52,49,54,55,53,49,54,55,57,32,103,49,54,55,54,49,54,55,55,49,54,56,48,41,0,0,0,0,0,0};
static C_char C_TLS li201[] C_aligned={C_lihdr(0,0,50),40,97,49,51,53,52,53,32,103,49,54,53,54,49,54,53,55,49,54,54,50,32,103,49,54,53,56,49,54,53,57,49,54,54,51,32,103,49,54,54,48,49,54,54,49,49,54,54,52,41,0,0,0,0,0,0};
static C_char C_TLS li202[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_expand_toplevel)
C_externexport void C_ccall C_expand_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3484)
static void C_ccall f_3484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3511)
static void C_ccall f_3511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3515)
static void C_ccall f_3515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3765)
static void C_ccall f_3765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13546)
static void C_ccall f_13546(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13544)
static void C_ccall f_13544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7761)
static void C_ccall f_7761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13536)
static void C_ccall f_13536(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13534)
static void C_ccall f_13534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7764)
static void C_ccall f_7764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7768)
static void C_ccall f_7768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13394)
static void C_ccall f_13394(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13404)
static void C_fcall f_13404(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13420)
static void C_ccall f_13420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13423)
static void C_ccall f_13423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13451)
static void C_ccall f_13451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13426)
static void C_ccall f_13426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13473)
static void C_ccall f_13473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13476)
static void C_ccall f_13476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13522)
static void C_ccall f_13522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13479)
static void C_ccall f_13479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13502)
static void C_ccall f_13502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13514)
static void C_ccall f_13514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13460)
static void C_ccall f_13460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13463)
static void C_ccall f_13463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13470)
static void C_ccall f_13470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13392)
static void C_ccall f_13392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7771)
static void C_ccall f_7771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13335)
static void C_ccall f_13335(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13364)
static void C_ccall f_13364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13384)
static void C_ccall f_13384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13388)
static void C_ccall f_13388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13333)
static void C_ccall f_13333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7774)
static void C_ccall f_7774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13245)
static void C_ccall f_13245(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13270)
static void C_ccall f_13270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13277)
static void C_ccall f_13277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13297)
static void C_ccall f_13297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13317)
static void C_ccall f_13317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13321)
static void C_ccall f_13321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13243)
static void C_ccall f_13243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7777)
static void C_ccall f_7777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12912)
static void C_ccall f_12912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12919)
static void C_ccall f_12919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12922)
static void C_ccall f_12922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12925)
static void C_ccall f_12925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12928)
static void C_ccall f_12928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12931)
static void C_ccall f_12931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12934)
static void C_ccall f_12934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12937)
static void C_ccall f_12937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12942)
static void C_fcall f_12942(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12958)
static void C_ccall f_12958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12964)
static void C_ccall f_12964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13006)
static void C_ccall f_13006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13074)
static void C_ccall f_13074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13199)
static void C_ccall f_13199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13195)
static void C_ccall f_13195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13077)
static void C_ccall f_13077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13132)
static void C_ccall f_13132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13009)
static void C_ccall f_13009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13048)
static void C_ccall f_13048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13000)
static void C_ccall f_13000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12971)
static void C_ccall f_12971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12910)
static void C_ccall f_12910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7780)
static void C_ccall f_7780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12742)
static void C_ccall f_12742(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12746)
static void C_ccall f_12746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12755)
static void C_ccall f_12755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12758)
static void C_ccall f_12758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12761)
static void C_ccall f_12761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12764)
static void C_ccall f_12764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12767)
static void C_ccall f_12767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12788)
static void C_fcall f_12788(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12804)
static void C_ccall f_12804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12810)
static void C_ccall f_12810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12866)
static void C_ccall f_12866(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12864)
static void C_ccall f_12864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12860)
static void C_ccall f_12860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12852)
static void C_ccall f_12852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12848)
static void C_ccall f_12848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12817)
static void C_ccall f_12817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12786)
static void C_ccall f_12786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12740)
static void C_ccall f_12740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7783)
static void C_ccall f_7783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12673)
static void C_ccall f_12673(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12677)
static void C_ccall f_12677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12686)
static void C_ccall f_12686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12691)
static void C_fcall f_12691(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12728)
static void C_ccall f_12728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12709)
static void C_ccall f_12709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12671)
static void C_ccall f_12671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7786)
static void C_ccall f_7786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12491)
static void C_ccall f_12491(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12495)
static void C_ccall f_12495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12507)
static void C_ccall f_12507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12510)
static void C_ccall f_12510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12513)
static void C_ccall f_12513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12516)
static void C_ccall f_12516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12651)
static void C_ccall f_12651(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12531)
static void C_ccall f_12531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12649)
static void C_ccall f_12649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12558)
static void C_fcall f_12558(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12639)
static void C_ccall f_12639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12574)
static void C_fcall f_12574(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12596)
static void C_ccall f_12596(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12594)
static void C_ccall f_12594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12590)
static void C_ccall f_12590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12489)
static void C_ccall f_12489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7789)
static void C_ccall f_7789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12096)
static void C_ccall f_12096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12100)
static void C_ccall f_12100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12103)
static void C_ccall f_12103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12106)
static void C_ccall f_12106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12109)
static void C_ccall f_12109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12478)
static void C_ccall f_12478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12390)
static void C_fcall f_12390(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12394)
static void C_ccall f_12394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12419)
static void C_ccall f_12419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12465)
static void C_ccall f_12465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12450)
static void C_ccall f_12450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12121)
static void C_fcall f_12121(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12168)
static void C_ccall f_12168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12215)
static void C_ccall f_12215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12376)
static void C_ccall f_12376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12384)
static void C_ccall f_12384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12362)
static void C_ccall f_12362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12351)
static void C_ccall f_12351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12359)
static void C_ccall f_12359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12336)
static void C_ccall f_12336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12324)
static void C_ccall f_12324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12305)
static void C_ccall f_12305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12263)
static void C_ccall f_12263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12240)
static void C_ccall f_12240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12194)
static void C_ccall f_12194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12143)
static void C_ccall f_12143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12139)
static void C_ccall f_12139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12111)
static void C_fcall f_12111(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12119)
static void C_ccall f_12119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12094)
static void C_ccall f_12094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7792)
static void C_ccall f_7792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12063)
static void C_ccall f_12063(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12067)
static void C_ccall f_12067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12061)
static void C_ccall f_12061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7795)
static void C_ccall f_7795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11779)
static void C_ccall f_11779(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11786)
static void C_ccall f_11786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11789)
static void C_ccall f_11789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11792)
static void C_ccall f_11792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11795)
static void C_ccall f_11795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11798)
static void C_ccall f_11798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11960)
static void C_fcall f_11960(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12013)
static void C_ccall f_12013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12035)
static void C_ccall f_12035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12042)
static void C_ccall f_12042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12029)
static void C_ccall f_12029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11976)
static void C_ccall f_11976(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11974)
static void C_ccall f_11974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11810)
static void C_fcall f_11810(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11841)
static void C_ccall f_11841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11887)
static void C_ccall f_11887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11937)
static void C_ccall f_11937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11944)
static void C_ccall f_11944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11902)
static void C_ccall f_11902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11916)
static void C_ccall f_11916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11859)
static void C_ccall f_11859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11870)
static void C_ccall f_11870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11800)
static void C_fcall f_11800(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11777)
static void C_ccall f_11777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7798)
static void C_ccall f_7798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11758)
static void C_ccall f_11758(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11756)
static void C_ccall f_11756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7801)
static void C_ccall f_7801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11737)
static void C_ccall f_11737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11735)
static void C_ccall f_11735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7804)
static void C_ccall f_7804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11686)
static void C_ccall f_11686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11690)
static void C_ccall f_11690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11727)
static void C_ccall f_11727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11720)
static void C_ccall f_11720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11713)
static void C_ccall f_11713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11684)
static void C_ccall f_11684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7807)
static void C_ccall f_7807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11632)
static void C_ccall f_11632(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11636)
static void C_ccall f_11636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11639)
static void C_ccall f_11639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11676)
static void C_ccall f_11676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11642)
static void C_ccall f_11642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11657)
static void C_ccall f_11657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11661)
static void C_ccall f_11661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11630)
static void C_ccall f_11630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7810)
static void C_ccall f_7810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11529)
static void C_ccall f_11529(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11536)
static void C_ccall f_11536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11539)
static void C_ccall f_11539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11559)
static void C_ccall f_11559(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11581)
static C_word C_fcall f_11581(C_word t0);
C_noret_decl(f_11566)
static void C_fcall f_11566(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11542)
static void C_ccall f_11542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11557)
static void C_ccall f_11557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11549)
static void C_ccall f_11549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11545)
static void C_ccall f_11545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11527)
static void C_ccall f_11527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7813)
static void C_ccall f_7813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11492)
static void C_ccall f_11492(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11496)
static void C_ccall f_11496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11514)
static void C_ccall f_11514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11505)
static void C_fcall f_11505(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11490)
static void C_ccall f_11490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7816)
static void C_ccall f_7816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9451)
static void C_ccall f_9451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11486)
static void C_ccall f_11486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9455)
static void C_ccall f_9455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9459)
static void C_ccall f_9459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11444)
static void C_ccall f_11444(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11452)
static void C_ccall f_11452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11454)
static void C_fcall f_11454(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11475)
static void C_ccall f_11475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10997)
static void C_ccall f_10997(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11429)
static void C_ccall f_11429(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11437)
static void C_ccall f_11437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11013)
static void C_ccall f_11013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11386)
static void C_ccall f_11386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11388)
static void C_fcall f_11388(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11427)
static void C_ccall f_11427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11401)
static void C_ccall f_11401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11412)
static void C_ccall f_11412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11367)
static void C_ccall f_11367(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11379)
static void C_ccall f_11379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11016)
static void C_ccall f_11016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11239)
static void C_fcall f_11239(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11290)
static void C_fcall f_11290(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11343)
static void C_ccall f_11343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11302)
static void C_fcall f_11302(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11329)
static void C_ccall f_11329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11325)
static void C_ccall f_11325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11305)
static void C_ccall f_11305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11287)
static void C_ccall f_11287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11276)
static void C_ccall f_11276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11019)
static void C_ccall f_11019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11233)
static void C_ccall f_11233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11219)
static void C_ccall f_11219(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11022)
static void C_ccall f_11022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11217)
static void C_ccall f_11217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11181)
static void C_ccall f_11181(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11209)
static void C_ccall f_11209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11025)
static void C_ccall f_11025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11175)
static void C_ccall f_11175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11179)
static void C_ccall f_11179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11028)
static void C_ccall f_11028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11031)
static void C_ccall f_11031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11133)
static void C_ccall f_11133(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11137)
static void C_ccall f_11137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11167)
static void C_ccall f_11167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11163)
static void C_ccall f_11163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11140)
static void C_ccall f_11140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11034)
static void C_ccall f_11034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11131)
static void C_ccall f_11131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11127)
static void C_ccall f_11127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11123)
static void C_ccall f_11123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11119)
static void C_ccall f_11119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11115)
static void C_ccall f_11115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11111)
static void C_ccall f_11111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11107)
static void C_ccall f_11107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11103)
static void C_ccall f_11103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11099)
static void C_ccall f_11099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11037)
static void C_ccall f_11037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11040)
static void C_ccall f_11040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10912)
static void C_ccall f_10912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10923)
static void C_ccall f_10923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10925)
static void C_fcall f_10925(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10974)
static void C_ccall f_10974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10970)
static void C_ccall f_10970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10953)
static void C_fcall f_10953(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10821)
static void C_ccall f_10821(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_10821)
static void C_ccall f_10821r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_10825)
static void C_ccall f_10825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10828)
static void C_ccall f_10828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10867)
static void C_ccall f_10867(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10887)
static void C_ccall f_10887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10877)
static void C_ccall f_10877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10880)
static void C_ccall f_10880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10843)
static void C_ccall f_10843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10849)
static void C_ccall f_10849(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10847)
static void C_ccall f_10847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10701)
static void C_ccall f_10701(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_10803)
static void C_ccall f_10803(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10815)
static void C_ccall f_10815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10705)
static void C_ccall f_10705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10771)
static void C_ccall f_10771(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10793)
static void C_ccall f_10793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10708)
static void C_ccall f_10708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10765)
static void C_ccall f_10765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10769)
static void C_ccall f_10769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10714)
static void C_ccall f_10714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10717)
static void C_ccall f_10717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10753)
static void C_ccall f_10753(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10720)
static void C_ccall f_10720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10733)
static void C_ccall f_10733(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10723)
static void C_ccall f_10723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10415)
static void C_ccall f_10415(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10699)
static void C_ccall f_10699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10435)
static void C_fcall f_10435(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10669)
static void C_ccall f_10669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10443)
static void C_fcall f_10443(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10651)
static void C_ccall f_10651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10451)
static void C_ccall f_10451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10639)
static void C_ccall f_10639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10566)
static void C_ccall f_10566(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10564)
static void C_ccall f_10564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10560)
static void C_ccall f_10560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10501)
static void C_ccall f_10501(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10511)
static void C_ccall f_10511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10499)
static void C_ccall f_10499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10495)
static void C_ccall f_10495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10447)
static void C_ccall f_10447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10439)
static void C_ccall f_10439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10343)
static void C_fcall f_10343(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10347)
static void C_ccall f_10347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10350)
static void C_ccall f_10350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10362)
static void C_fcall f_10362(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10401)
static void C_ccall f_10401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10393)
static void C_ccall f_10393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10353)
static void C_ccall f_10353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10356)
static void C_ccall f_10356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10067)
static void C_fcall f_10067(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10148)
static void C_fcall f_10148(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10175)
static void C_ccall f_10175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10177)
static void C_fcall f_10177(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10337)
static void C_ccall f_10337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10325)
static void C_ccall f_10325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10306)
static void C_ccall f_10306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10288)
static void C_ccall f_10288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10273)
static void C_ccall f_10273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10243)
static void C_ccall f_10243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10228)
static void C_ccall f_10228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10200)
static void C_ccall f_10200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10125)
static void C_fcall f_10125(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10137)
static void C_ccall f_10137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10133)
static void C_ccall f_10133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10008)
static void C_ccall f_10008(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10014)
static void C_ccall f_10014(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10021)
static void C_fcall f_10021(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10024)
static void C_ccall f_10024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9940)
static void C_ccall f_9940(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_9940)
static void C_ccall f_9940r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_9960)
static C_word C_fcall f_9960(C_word *a,C_word t0);
C_noret_decl(f_9955)
static C_word C_fcall f_9955(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_9942)
static C_word C_fcall f_9942(C_word *a,C_word t0,C_word t1,C_word t2);
C_noret_decl(f_9918)
static void C_ccall f_9918(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9925)
static void C_ccall f_9925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9841)
static void C_ccall f_9841(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9851)
static void C_ccall f_9851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9854)
static void C_ccall f_9854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9860)
static void C_ccall f_9860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9899)
static void C_ccall f_9899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9903)
static void C_ccall f_9903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9863)
static void C_ccall f_9863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9866)
static void C_ccall f_9866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9869)
static void C_ccall f_9869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9752)
static void C_ccall f_9752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9762)
static void C_ccall f_9762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9765)
static void C_ccall f_9765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9828)
static void C_ccall f_9828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9768)
static void C_ccall f_9768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9824)
static void C_ccall f_9824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9771)
static void C_ccall f_9771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9810)
static void C_ccall f_9810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9814)
static void C_ccall f_9814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9774)
static void C_ccall f_9774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9777)
static void C_ccall f_9777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9783)
static void C_ccall f_9783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9731)
static void C_fcall f_9731(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9738)
static void C_ccall f_9738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9711)
static void C_ccall f_9711(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9715)
static void C_ccall f_9715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9708)
static void C_ccall f_9708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9668)
static void C_ccall f_9668(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9668)
static void C_ccall f_9668r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9672)
static void C_ccall f_9672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9662)
static C_word C_fcall f_9662(C_word *a,C_word t0,C_word t1,C_word t2,C_word t3);
C_noret_decl(f_9653)
static C_word C_fcall f_9653(C_word t0);
C_noret_decl(f_9635)
static C_word C_fcall f_9635(C_word t0);
C_noret_decl(f_9617)
static C_word C_fcall f_9617(C_word t0);
C_noret_decl(f_9599)
static C_word C_fcall f_9599(C_word t0);
C_noret_decl(f_9581)
static C_word C_fcall f_9581(C_word t0);
C_noret_decl(f_9563)
static void C_ccall f_9563(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9554)
static void C_ccall f_9554(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9545)
static C_word C_fcall f_9545(C_word t0);
C_noret_decl(f_9527)
static C_word C_fcall f_9527(C_word t0);
C_noret_decl(f_9509)
static C_word C_fcall f_9509(C_word t0);
C_noret_decl(f_9500)
static void C_fcall f_9500(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9491)
static C_word C_fcall f_9491(C_word t0);
C_noret_decl(f_9473)
static C_word C_fcall f_9473(C_word t0);
C_noret_decl(f_7818)
static void C_ccall f_7818(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_7825)
static void C_ccall f_7825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7839)
static void C_ccall f_7839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7843)
static void C_ccall f_7843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7847)
static void C_ccall f_7847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7852)
static void C_ccall f_7852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7858)
static void C_ccall f_7858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7862)
static void C_ccall f_7862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7866)
static void C_ccall f_7866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7870)
static void C_ccall f_7870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7874)
static void C_ccall f_7874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7879)
static void C_ccall f_7879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7883)
static void C_ccall f_7883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7890)
static void C_ccall f_7890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7895)
static void C_ccall f_7895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7899)
static void C_ccall f_7899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7903)
static void C_ccall f_7903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7907)
static void C_ccall f_7907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9410)
static void C_ccall f_9410(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9420)
static void C_fcall f_9420(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9427)
static void C_fcall f_9427(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9390)
static void C_ccall f_9390(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9397)
static void C_ccall f_9397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9404)
static void C_ccall f_9404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9364)
static void C_ccall f_9364(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9342)
static void C_ccall f_9342(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9349)
static void C_ccall f_9349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9249)
static void C_ccall f_9249(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9291)
static void C_ccall f_9291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9340)
static void C_ccall f_9340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9323)
static void C_ccall f_9323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9302)
static void C_ccall f_9302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9262)
static void C_fcall f_9262(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9176)
static void C_ccall f_9176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9202)
static void C_ccall f_9202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9247)
static void C_ccall f_9247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9230)
static void C_ccall f_9230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8922)
static void C_ccall f_8922(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8969)
static void C_ccall f_8969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9167)
static void C_ccall f_9167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9163)
static void C_ccall f_9163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9130)
static void C_ccall f_9130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9138)
static void C_ccall f_9138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8972)
static void C_ccall f_8972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8978)
static void C_ccall f_8978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8990)
static void C_ccall f_8990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9056)
static void C_fcall f_9056(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9071)
static void C_ccall f_9071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8993)
static void C_fcall f_8993(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9027)
static void C_fcall f_9027(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8996)
static void C_ccall f_8996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9025)
static void C_ccall f_9025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9021)
static void C_ccall f_9021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9017)
static void C_ccall f_9017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8715)
static void C_ccall f_8715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8745)
static void C_ccall f_8745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8845)
static void C_fcall f_8845(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8868)
static void C_fcall f_8868(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8882)
static void C_ccall f_8882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8886)
static void C_ccall f_8886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8855)
static void C_ccall f_8855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8805)
static void C_ccall f_8805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8809)
static void C_ccall f_8809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8754)
static void C_ccall f_8754(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8762)
static void C_fcall f_8762(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8739)
static void C_ccall f_8739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8427)
static void C_ccall f_8427(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8434)
static void C_fcall f_8434(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8473)
static void C_fcall f_8473(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8483)
static void C_fcall f_8483(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8614)
static void C_ccall f_8614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8618)
static void C_ccall f_8618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8547)
static void C_ccall f_8547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8543)
static void C_ccall f_8543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8481)
static void C_ccall f_8481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8477)
static void C_ccall f_8477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8309)
static void C_ccall f_8309(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8313)
static void C_ccall f_8313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8088)
static void C_ccall f_8088(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8138)
static void C_ccall f_8138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8252)
static void C_fcall f_8252(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8190)
static void C_ccall f_8190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8198)
static void C_ccall f_8198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8194)
static void C_ccall f_8194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8186)
static void C_ccall f_8186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8004)
static void C_ccall f_8004(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8011)
static void C_fcall f_8011(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8014)
static void C_ccall f_8014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8063)
static void C_ccall f_8063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8059)
static void C_ccall f_8059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8054)
static void C_ccall f_8054(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8040)
static void C_ccall f_8040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8052)
static void C_ccall f_8052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8048)
static void C_ccall f_8048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7910)
static void C_ccall f_7910(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7954)
static void C_ccall f_7954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7950)
static void C_ccall f_7950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6916)
static void C_ccall f_6916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_6920)
static void C_ccall f_6920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6923)
static void C_ccall f_6923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6926)
static void C_ccall f_6926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6929)
static void C_ccall f_6929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7528)
static void C_ccall f_7528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7531)
static void C_ccall f_7531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7750)
static void C_ccall f_7750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7735)
static void C_ccall f_7735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7534)
static void C_ccall f_7534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7539)
static void C_ccall f_7539(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7543)
static void C_ccall f_7543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7552)
static void C_ccall f_7552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7710)
static void C_ccall f_7710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7555)
static void C_ccall f_7555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7687)
static void C_ccall f_7687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7558)
static void C_ccall f_7558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7561)
static void C_ccall f_7561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7633)
static void C_ccall f_7633(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7667)
static void C_ccall f_7667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7564)
static void C_ccall f_7564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7591)
static void C_ccall f_7591(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7631)
static void C_ccall f_7631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7567)
static void C_ccall f_7567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7589)
static void C_ccall f_7589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7585)
static void C_ccall f_7585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7570)
static void C_ccall f_7570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7581)
static void C_ccall f_7581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7577)
static void C_ccall f_7577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7537)
static void C_ccall f_7537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7070)
static void C_fcall f_7070(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7089)
static void C_fcall f_7089(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7098)
static void C_ccall f_7098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7110)
static void C_ccall f_7110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7190)
static void C_ccall f_7190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7297)
static void C_ccall f_7297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7444)
static void C_ccall f_7444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7447)
static void C_ccall f_7447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7450)
static void C_ccall f_7450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7483)
static void C_ccall f_7483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7487)
static void C_ccall f_7487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7452)
static void C_ccall f_7452(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7472)
static void C_ccall f_7472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7468)
static void C_ccall f_7468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7460)
static void C_ccall f_7460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7300)
static void C_ccall f_7300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7309)
static void C_fcall f_7309(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_7438)
static void C_ccall f_7438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7419)
static void C_ccall f_7419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7407)
static void C_ccall f_7407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7386)
static void C_ccall f_7386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7367)
static void C_ccall f_7367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7355)
static void C_ccall f_7355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7330)
static void C_ccall f_7330(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7325)
static void C_ccall f_7325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7193)
static void C_ccall f_7193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7196)
static void C_ccall f_7196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7201)
static void C_fcall f_7201(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7287)
static void C_ccall f_7287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7213)
static void C_fcall f_7213(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7255)
static void C_ccall f_7255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7113)
static void C_ccall f_7113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7116)
static void C_ccall f_7116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7121)
static void C_fcall f_7121(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6983)
static void C_fcall f_6983(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6987)
static void C_ccall f_6987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6990)
static void C_ccall f_6990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7068)
static void C_ccall f_7068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7064)
static void C_ccall f_7064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7005)
static void C_ccall f_7005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7011)
static void C_ccall f_7011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7014)
static void C_ccall f_7014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7053)
static void C_ccall f_7053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7047)
static void C_ccall f_7047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7051)
static void C_ccall f_7051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7015)
static void C_ccall f_7015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7019)
static void C_ccall f_7019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7022)
static void C_ccall f_7022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7026)
static void C_ccall f_7026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7029)
static void C_ccall f_7029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7033)
static void C_ccall f_7033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7036)
static void C_ccall f_7036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7040)
static void C_ccall f_7040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7043)
static void C_ccall f_7043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6993)
static void C_ccall f_6993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6940)
static void C_fcall f_6940(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6953)
static void C_ccall f_6953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6960)
static void C_ccall f_6960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6931)
static void C_ccall f_6931(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6935)
static void C_ccall f_6935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6622)
static void C_ccall f_6622(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6624)
static void C_ccall f_6624(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6753)
static void C_ccall f_6753(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6786)
static void C_ccall f_6786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6876)
static void C_ccall f_6876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6789)
static void C_fcall f_6789(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6792)
static void C_ccall f_6792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6870)
static void C_ccall f_6870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6795)
static void C_fcall f_6795(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6864)
static void C_ccall f_6864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6841)
static void C_ccall f_6841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6814)
static void C_ccall f_6814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6821)
static void C_ccall f_6821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6757)
static void C_fcall f_6757(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6760)
static void C_ccall f_6760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6890)
static void C_fcall f_6890(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6894)
static void C_ccall f_6894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6897)
static void C_ccall f_6897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6627)
static void C_ccall f_6627(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6663)
static void C_ccall f_6663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6724)
static void C_ccall f_6724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6727)
static void C_ccall f_6727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6694)
static void C_ccall f_6694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6697)
static void C_ccall f_6697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6675)
static void C_ccall f_6675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6637)
static void C_ccall f_6637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6160)
static void C_ccall f_6160(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6160)
static void C_ccall f_6160r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6574)
static void C_fcall f_6574(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6565)
static void C_fcall f_6565(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6573)
static void C_ccall f_6573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6162)
static void C_fcall f_6162(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6293)
static void C_fcall f_6293(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6298)
static void C_fcall f_6298(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6536)
static void C_ccall f_6536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6495)
static void C_ccall f_6495(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6499)
static void C_ccall f_6499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6317)
static void C_fcall f_6317(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6322)
static void C_fcall f_6322(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6341)
static void C_ccall f_6341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6264)
static void C_ccall f_6264(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6270)
static C_word C_fcall f_6270(C_word t0);
C_noret_decl(f_6208)
static void C_ccall f_6208(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6212)
static void C_ccall f_6212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6220)
static void C_fcall f_6220(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6240)
static void C_ccall f_6240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6165)
static void C_fcall f_6165(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6172)
static void C_ccall f_6172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6177)
static void C_fcall f_6177(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6181)
static void C_ccall f_6181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6206)
static void C_ccall f_6206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6195)
static void C_ccall f_6195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6199)
static void C_ccall f_6199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6188)
static void C_ccall f_6188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6124)
static void C_ccall f_6124(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6146)
static void C_ccall f_6146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6113)
static void C_ccall f_6113(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6113)
static void C_ccall f_6113r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6121)
static void C_ccall f_6121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6043)
static void C_ccall f_6043(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6106)
static void C_ccall f_6106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6046)
static void C_fcall f_6046(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6099)
static void C_ccall f_6099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6072)
static void C_ccall f_6072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5960)
static void C_fcall f_5960(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6041)
static void C_ccall f_6041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5963)
static void C_fcall f_5963(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6012)
static void C_ccall f_6012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5207)
static void C_ccall f_5207(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5207)
static void C_ccall f_5207r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5211)
static void C_ccall f_5211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5650)
static void C_fcall f_5650(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5656)
static void C_fcall f_5656(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5920)
static void C_ccall f_5920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5678)
static void C_fcall f_5678(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5888)
static void C_ccall f_5888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5862)
static void C_ccall f_5862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5869)
static void C_ccall f_5869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5834)
static void C_ccall f_5834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5822)
static void C_ccall f_5822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5696)
static void C_ccall f_5696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5701)
static void C_fcall f_5701(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5714)
static void C_ccall f_5714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5770)
static void C_ccall f_5770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5797)
static void C_ccall f_5797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5748)
static void C_ccall f_5748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5759)
static void C_ccall f_5759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5763)
static void C_ccall f_5763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5473)
static void C_fcall f_5473(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5483)
static void C_fcall f_5483(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5632)
static void C_ccall f_5632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5628)
static void C_ccall f_5628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5618)
static void C_ccall f_5618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5621)
static void C_ccall f_5621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5529)
static void C_fcall f_5529(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5561)
static void C_ccall f_5561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5573)
static void C_ccall f_5573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5581)
static void C_ccall f_5581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5585)
static void C_ccall f_5585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5547)
static void C_fcall f_5547(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5498)
static void C_ccall f_5498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5514)
static void C_ccall f_5514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5506)
static void C_ccall f_5506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5510)
static void C_ccall f_5510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5481)
static void C_ccall f_5481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5213)
static void C_fcall f_5213(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5324)
static void C_ccall f_5324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5465)
static void C_ccall f_5465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5453)
static void C_ccall f_5453(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5346)
static void C_ccall f_5346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5451)
static void C_ccall f_5451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5435)
static void C_ccall f_5435(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5354)
static void C_ccall f_5354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5429)
static void C_ccall f_5429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5433)
static void C_ccall f_5433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5368)
static void C_ccall f_5368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5372)
static void C_ccall f_5372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5405)
static void C_ccall f_5405(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5403)
static void C_ccall f_5403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5399)
static void C_ccall f_5399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5362)
static void C_ccall f_5362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5366)
static void C_ccall f_5366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5358)
static void C_ccall f_5358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5350)
static void C_ccall f_5350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5330)
static void C_ccall f_5330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5225)
static void C_fcall f_5225(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5239)
static void C_ccall f_5239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5314)
static void C_ccall f_5314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5307)
static void C_ccall f_5307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5248)
static void C_fcall f_5248(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5255)
static void C_ccall f_5255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5263)
static void C_ccall f_5263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5271)
static void C_ccall f_5271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5259)
static void C_ccall f_5259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4617)
static void C_ccall f_4617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4637)
static void C_ccall f_4637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4640)
static void C_ccall f_4640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4643)
static void C_ccall f_4643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4646)
static void C_ccall f_4646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4649)
static void C_ccall f_4649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4654)
static void C_fcall f_4654(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4965)
static void C_ccall f_4965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5144)
static void C_fcall f_5144(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5082)
static void C_ccall f_5082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5063)
static void C_fcall f_5063(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5017)
static void C_fcall f_5017(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5020)
static void C_fcall f_5020(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4999)
static void C_ccall f_4999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4980)
static void C_fcall f_4980(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4942)
static void C_fcall f_4942(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4921)
static void C_ccall f_4921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4668)
static void C_ccall f_4668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4914)
static void C_ccall f_4914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4841)
static void C_ccall f_4841(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4910)
static void C_ccall f_4910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4894)
static void C_ccall f_4894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4876)
static void C_fcall f_4876(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4872)
static void C_ccall f_4872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4835)
static void C_ccall f_4835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4839)
static void C_ccall f_4839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4672)
static void C_fcall f_4672(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4684)
static void C_fcall f_4684(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4787)
static void C_ccall f_4787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4779)
static void C_ccall f_4779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4783)
static void C_ccall f_4783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4756)
static void C_ccall f_4756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4760)
static void C_ccall f_4760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4711)
static void C_ccall f_4711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4731)
static void C_ccall f_4731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4703)
static void C_ccall f_4703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4675)
static void C_fcall f_4675(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4620)
static void C_fcall f_4620(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4574)
static void C_ccall f_4574(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4580)
static void C_fcall f_4580(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4599)
static void C_fcall f_4599(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4521)
static void C_ccall f_4521(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4521)
static void C_ccall f_4521r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4525)
static void C_ccall f_4525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4530)
static void C_fcall f_4530(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4542)
static void C_ccall f_4542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4536)
static void C_ccall f_4536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4431)
static void C_ccall f_4431(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4467)
static void C_ccall f_4467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4470)
static void C_ccall f_4470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4482)
static void C_ccall f_4482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4519)
static void C_ccall f_4519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4494)
static void C_ccall f_4494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4509)
static void C_ccall f_4509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4485)
static void C_ccall f_4485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4476)
static void C_ccall f_4476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4434)
static void C_fcall f_4434(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4438)
static void C_ccall f_4438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4444)
static void C_ccall f_4444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4447)
static void C_ccall f_4447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4413)
static void C_ccall f_4413(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4421)
static void C_ccall f_4421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3931)
static void C_ccall f_3931(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4230)
static void C_ccall f_4230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4404)
static void C_ccall f_4404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4397)
static void C_ccall f_4397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4236)
static void C_fcall f_4236(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4338)
static void C_fcall f_4338(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4344)
static void C_ccall f_4344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4351)
static void C_ccall f_4351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4245)
static void C_ccall f_4245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4257)
static void C_ccall f_4257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4325)
static void C_ccall f_4325(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4315)
static void C_ccall f_4315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4319)
static void C_ccall f_4319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4283)
static void C_ccall f_4283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4279)
static void C_ccall f_4279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4113)
static void C_fcall f_4113(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4170)
static void C_ccall f_4170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4173)
static void C_fcall f_4173(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4199)
static void C_ccall f_4199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4195)
static void C_ccall f_4195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4185)
static void C_fcall f_4185(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4117)
static void C_ccall f_4117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4139)
static void C_ccall f_4139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3934)
static void C_fcall f_3934(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3938)
static void C_ccall f_3938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4111)
static void C_ccall f_4111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4107)
static void C_ccall f_4107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3941)
static void C_ccall f_3941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3949)
static void C_ccall f_3949(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4062)
static void C_ccall f_4062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4089)
static void C_ccall f_4089(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4089)
static void C_ccall f_4089r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4095)
static void C_ccall f_4095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4068)
static void C_ccall f_4068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4072)
static void C_ccall f_4072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4075)
static void C_ccall f_4075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3955)
static void C_ccall f_3955(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3961)
static void C_ccall f_3961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3972)
static void C_fcall f_3972(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3989)
static void C_fcall f_3989(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4008)
static void C_fcall f_4008(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4019)
static void C_ccall f_4019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3983)
static void C_ccall f_3983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3969)
static void C_fcall f_3969(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3947)
static void C_ccall f_3947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3922)
static void C_ccall f_3922(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3871)
static void C_ccall f_3871(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3883)
static void C_ccall f_3883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3885)
static void C_fcall f_3885(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3920)
static void C_ccall f_3920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3912)
static void C_ccall f_3912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3879)
static void C_ccall f_3879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3815)
static void C_ccall f_3815(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3815)
static void C_ccall f_3815r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3819)
static void C_ccall f_3819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3828)
static void C_ccall f_3828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3847)
static void C_ccall f_3847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3837)
static void C_ccall f_3837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3802)
static void C_ccall f_3802(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3813)
static void C_ccall f_3813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3806)
static void C_ccall f_3806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3769)
static void C_ccall f_3769(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3773)
static void C_ccall f_3773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3776)
static void C_ccall f_3776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3614)
static void C_ccall f_3614(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3614)
static void C_ccall f_3614r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3714)
static void C_fcall f_3714(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3709)
static void C_fcall f_3709(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3616)
static void C_fcall f_3616(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3622)
static void C_ccall f_3622(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3708)
static void C_ccall f_3708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3704)
static void C_ccall f_3704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3679)
static void C_ccall f_3679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3683)
static void C_ccall f_3683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3632)
static void C_ccall f_3632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3638)
static void C_fcall f_3638(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3584)
static void C_fcall f_3584(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3590)
static void C_ccall f_3590(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3535)
static void C_fcall f_3535(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3542)
static void C_ccall f_3542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3545)
static void C_fcall f_3545(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3548)
static void C_ccall f_3548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3551)
static void C_ccall f_3551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3557)
static void C_ccall f_3557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3560)
static void C_ccall f_3560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3517)
static void C_fcall f_3517(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3530)
static void C_ccall f_3530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3486)
static void C_ccall f_3486(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3486)
static void C_ccall f_3486r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;

C_noret_decl(trf_13404)
static void C_fcall trf_13404(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13404(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13404(t0,t1,t2);}

C_noret_decl(trf_12942)
static void C_fcall trf_12942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12942(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12942(t0,t1,t2);}

C_noret_decl(trf_12788)
static void C_fcall trf_12788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12788(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12788(t0,t1,t2);}

C_noret_decl(trf_12691)
static void C_fcall trf_12691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12691(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12691(t0,t1,t2);}

C_noret_decl(trf_12558)
static void C_fcall trf_12558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12558(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12558(t0,t1);}

C_noret_decl(trf_12574)
static void C_fcall trf_12574(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12574(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12574(t0,t1);}

C_noret_decl(trf_12390)
static void C_fcall trf_12390(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12390(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12390(t0,t1,t2);}

C_noret_decl(trf_12121)
static void C_fcall trf_12121(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12121(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12121(t0,t1,t2,t3);}

C_noret_decl(trf_12111)
static void C_fcall trf_12111(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12111(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12111(t0,t1,t2,t3);}

C_noret_decl(trf_11960)
static void C_fcall trf_11960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11960(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11960(t0,t1,t2);}

C_noret_decl(trf_11810)
static void C_fcall trf_11810(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11810(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11810(t0,t1,t2);}

C_noret_decl(trf_11800)
static void C_fcall trf_11800(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11800(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11800(t0,t1,t2);}

C_noret_decl(trf_11566)
static void C_fcall trf_11566(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11566(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11566(t0,t1);}

C_noret_decl(trf_11505)
static void C_fcall trf_11505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11505(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11505(t0,t1);}

C_noret_decl(trf_11454)
static void C_fcall trf_11454(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11454(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11454(t0,t1,t2);}

C_noret_decl(trf_11388)
static void C_fcall trf_11388(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11388(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11388(t0,t1,t2);}

C_noret_decl(trf_11239)
static void C_fcall trf_11239(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11239(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11239(t0,t1,t2);}

C_noret_decl(trf_11290)
static void C_fcall trf_11290(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11290(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11290(t0,t1);}

C_noret_decl(trf_11302)
static void C_fcall trf_11302(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11302(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11302(t0,t1);}

C_noret_decl(trf_10925)
static void C_fcall trf_10925(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10925(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10925(t0,t1,t2);}

C_noret_decl(trf_10953)
static void C_fcall trf_10953(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10953(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10953(t0,t1);}

C_noret_decl(trf_10435)
static void C_fcall trf_10435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10435(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10435(t0,t1);}

C_noret_decl(trf_10443)
static void C_fcall trf_10443(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10443(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10443(t0,t1);}

C_noret_decl(trf_10343)
static void C_fcall trf_10343(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10343(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10343(t0,t1);}

C_noret_decl(trf_10362)
static void C_fcall trf_10362(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10362(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10362(t0,t1,t2);}

C_noret_decl(trf_10067)
static void C_fcall trf_10067(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10067(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10067(t0,t1);}

C_noret_decl(trf_10148)
static void C_fcall trf_10148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10148(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10148(t0,t1,t2);}

C_noret_decl(trf_10177)
static void C_fcall trf_10177(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10177(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10177(t0,t1,t2);}

C_noret_decl(trf_10125)
static void C_fcall trf_10125(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10125(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10125(t0,t1,t2,t3);}

C_noret_decl(trf_10021)
static void C_fcall trf_10021(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10021(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10021(t0,t1);}

C_noret_decl(trf_9731)
static void C_fcall trf_9731(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9731(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9731(t0,t1,t2,t3);}

C_noret_decl(trf_9500)
static void C_fcall trf_9500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9500(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9500(t0,t1,t2);}

C_noret_decl(trf_9420)
static void C_fcall trf_9420(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9420(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9420(t0,t1,t2);}

C_noret_decl(trf_9427)
static void C_fcall trf_9427(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9427(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9427(t0,t1);}

C_noret_decl(trf_9262)
static void C_fcall trf_9262(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9262(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9262(t0,t1);}

C_noret_decl(trf_9056)
static void C_fcall trf_9056(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9056(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9056(t0,t1);}

C_noret_decl(trf_8993)
static void C_fcall trf_8993(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8993(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8993(t0,t1);}

C_noret_decl(trf_9027)
static void C_fcall trf_9027(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9027(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9027(t0,t1,t2,t3);}

C_noret_decl(trf_8845)
static void C_fcall trf_8845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8845(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8845(t0,t1);}

C_noret_decl(trf_8868)
static void C_fcall trf_8868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8868(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8868(t0,t1,t2);}

C_noret_decl(trf_8762)
static void C_fcall trf_8762(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8762(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8762(t0,t1);}

C_noret_decl(trf_8434)
static void C_fcall trf_8434(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8434(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8434(t0,t1);}

C_noret_decl(trf_8473)
static void C_fcall trf_8473(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8473(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8473(t0,t1);}

C_noret_decl(trf_8483)
static void C_fcall trf_8483(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8483(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8483(t0,t1,t2);}

C_noret_decl(trf_8252)
static void C_fcall trf_8252(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8252(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8252(t0,t1);}

C_noret_decl(trf_8011)
static void C_fcall trf_8011(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8011(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8011(t0,t1);}

C_noret_decl(trf_7070)
static void C_fcall trf_7070(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7070(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7070(t0,t1,t2);}

C_noret_decl(trf_7089)
static void C_fcall trf_7089(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7089(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7089(t0,t1);}

C_noret_decl(trf_7309)
static void C_fcall trf_7309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7309(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_7309(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_7201)
static void C_fcall trf_7201(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7201(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7201(t0,t1,t2,t3);}

C_noret_decl(trf_7213)
static void C_fcall trf_7213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7213(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7213(t0,t1,t2,t3);}

C_noret_decl(trf_7121)
static void C_fcall trf_7121(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7121(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7121(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6983)
static void C_fcall trf_6983(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6983(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6983(t0,t1,t2);}

C_noret_decl(trf_6940)
static void C_fcall trf_6940(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6940(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6940(t0,t1,t2);}

C_noret_decl(trf_6789)
static void C_fcall trf_6789(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6789(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6789(t0,t1);}

C_noret_decl(trf_6795)
static void C_fcall trf_6795(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6795(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6795(t0,t1);}

C_noret_decl(trf_6757)
static void C_fcall trf_6757(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6757(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6757(t0,t1);}

C_noret_decl(trf_6890)
static void C_fcall trf_6890(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6890(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6890(t0,t1,t2,t3);}

C_noret_decl(trf_6574)
static void C_fcall trf_6574(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6574(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6574(t0,t1);}

C_noret_decl(trf_6565)
static void C_fcall trf_6565(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6565(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6565(t0,t1,t2);}

C_noret_decl(trf_6162)
static void C_fcall trf_6162(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6162(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6162(t0,t1,t2,t3);}

C_noret_decl(trf_6293)
static void C_fcall trf_6293(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6293(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6293(t0,t1);}

C_noret_decl(trf_6298)
static void C_fcall trf_6298(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6298(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6298(t0,t1,t2,t3);}

C_noret_decl(trf_6317)
static void C_fcall trf_6317(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6317(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6317(t0,t1);}

C_noret_decl(trf_6322)
static void C_fcall trf_6322(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6322(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6322(t0,t1,t2,t3);}

C_noret_decl(trf_6220)
static void C_fcall trf_6220(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6220(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6220(t0,t1,t2);}

C_noret_decl(trf_6165)
static void C_fcall trf_6165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6165(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6165(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6177)
static void C_fcall trf_6177(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6177(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6177(t0,t1,t2);}

C_noret_decl(trf_6046)
static void C_fcall trf_6046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6046(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6046(t0,t1,t2,t3);}

C_noret_decl(trf_5960)
static void C_fcall trf_5960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5960(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5960(t0,t1,t2,t3);}

C_noret_decl(trf_5963)
static void C_fcall trf_5963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5963(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5963(t0,t1,t2,t3);}

C_noret_decl(trf_5650)
static void C_fcall trf_5650(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5650(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5650(t0,t1,t2);}

C_noret_decl(trf_5656)
static void C_fcall trf_5656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5656(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5656(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5678)
static void C_fcall trf_5678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5678(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5678(t0,t1);}

C_noret_decl(trf_5701)
static void C_fcall trf_5701(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5701(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5701(t0,t1,t2);}

C_noret_decl(trf_5473)
static void C_fcall trf_5473(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5473(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5473(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5483)
static void C_fcall trf_5483(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5483(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5483(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5529)
static void C_fcall trf_5529(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5529(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5529(t0,t1);}

C_noret_decl(trf_5547)
static void C_fcall trf_5547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5547(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5547(t0,t1);}

C_noret_decl(trf_5213)
static void C_fcall trf_5213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5213(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5213(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5225)
static void C_fcall trf_5225(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5225(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5225(t0,t1,t2,t3);}

C_noret_decl(trf_5248)
static void C_fcall trf_5248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5248(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5248(t0,t1);}

C_noret_decl(trf_4654)
static void C_fcall trf_4654(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4654(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_4654(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5144)
static void C_fcall trf_5144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5144(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5144(t0,t1);}

C_noret_decl(trf_5063)
static void C_fcall trf_5063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5063(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5063(t0,t1);}

C_noret_decl(trf_5017)
static void C_fcall trf_5017(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5017(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5017(t0,t1);}

C_noret_decl(trf_5020)
static void C_fcall trf_5020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5020(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5020(t0,t1);}

C_noret_decl(trf_4980)
static void C_fcall trf_4980(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4980(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4980(t0,t1);}

C_noret_decl(trf_4942)
static void C_fcall trf_4942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4942(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4942(t0,t1);}

C_noret_decl(trf_4876)
static void C_fcall trf_4876(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4876(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4876(t0,t1);}

C_noret_decl(trf_4672)
static void C_fcall trf_4672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4672(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4672(t0,t1);}

C_noret_decl(trf_4684)
static void C_fcall trf_4684(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4684(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4684(t0,t1);}

C_noret_decl(trf_4675)
static void C_fcall trf_4675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4675(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4675(t0,t1);}

C_noret_decl(trf_4620)
static void C_fcall trf_4620(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4620(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4620(t0,t1,t2);}

C_noret_decl(trf_4580)
static void C_fcall trf_4580(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4580(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4580(t0,t1,t2);}

C_noret_decl(trf_4599)
static void C_fcall trf_4599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4599(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4599(t0,t1);}

C_noret_decl(trf_4530)
static void C_fcall trf_4530(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4530(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4530(t0,t1,t2);}

C_noret_decl(trf_4434)
static void C_fcall trf_4434(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4434(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4434(t0,t1,t2);}

C_noret_decl(trf_4236)
static void C_fcall trf_4236(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4236(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4236(t0,t1);}

C_noret_decl(trf_4338)
static void C_fcall trf_4338(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4338(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4338(t0,t1);}

C_noret_decl(trf_4113)
static void C_fcall trf_4113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4113(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4113(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4173)
static void C_fcall trf_4173(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4173(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4173(t0,t1);}

C_noret_decl(trf_4185)
static void C_fcall trf_4185(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4185(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4185(t0,t1);}

C_noret_decl(trf_3934)
static void C_fcall trf_3934(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3934(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3934(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3972)
static void C_fcall trf_3972(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3972(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3972(t0,t1);}

C_noret_decl(trf_3989)
static void C_fcall trf_3989(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3989(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3989(t0,t1,t2);}

C_noret_decl(trf_4008)
static void C_fcall trf_4008(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4008(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4008(t0,t1);}

C_noret_decl(trf_3969)
static void C_fcall trf_3969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3969(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3969(t0,t1);}

C_noret_decl(trf_3885)
static void C_fcall trf_3885(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3885(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3885(t0,t1,t2);}

C_noret_decl(trf_3714)
static void C_fcall trf_3714(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3714(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3714(t0,t1);}

C_noret_decl(trf_3709)
static void C_fcall trf_3709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3709(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3709(t0,t1,t2);}

C_noret_decl(trf_3616)
static void C_fcall trf_3616(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3616(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3616(t0,t1,t2,t3);}

C_noret_decl(trf_3638)
static void C_fcall trf_3638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3638(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3638(t0,t1);}

C_noret_decl(trf_3584)
static void C_fcall trf_3584(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3584(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3584(t0,t1);}

C_noret_decl(trf_3535)
static void C_fcall trf_3535(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3535(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3535(t0,t1,t2);}

C_noret_decl(trf_3545)
static void C_fcall trf_3545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3545(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3545(t0,t1);}

C_noret_decl(trf_3517)
static void C_fcall trf_3517(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3517(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3517(t0,t1,t2);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_expand_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_expand_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("expand_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3764)){
C_save(t1);
C_rereclaim2(3764*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,391);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],12,"\003sysfeatures");
lf[4]=C_h_intern(&lf[4],2,"pp");
lf[5]=C_h_intern(&lf[5],5,"print");
lf[8]=C_h_intern(&lf[8],23,"\003syscurrent-environment");
lf[9]=C_h_intern(&lf[9],28,"\003syscurrent-meta-environment");
lf[11]=C_h_intern(&lf[11],7,"\003sysget");
lf[12]=C_h_intern(&lf[12],16,"\004coremacro-alias");
lf[14]=C_h_intern(&lf[14],7,"<macro>");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000\011aliasing ");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\004 to ");
lf[17]=C_h_intern(&lf[17],8,"\003sysput!");
lf[18]=C_h_intern(&lf[18],6,"gensym");
lf[19]=C_h_intern(&lf[19],21,"\003sysqualified-symbol\077");
lf[21]=C_h_intern(&lf[21],7,"\003sysmap");
lf[22]=C_h_intern(&lf[22],16,"\003sysstrip-syntax");
lf[23]=C_h_intern(&lf[23],21,"\003sysalias-global-hook");
lf[24]=C_h_intern(&lf[24],3,"get");
lf[25]=C_h_intern(&lf[25],12,"list->vector");
lf[26]=C_h_intern(&lf[26],12,"vector->list");
lf[27]=C_h_intern(&lf[27],9,"\003syserror");
lf[28]=C_h_intern(&lf[28],12,"strip-syntax");
lf[29]=C_h_intern(&lf[29],21,"\003sysmacro-environment");
lf[30]=C_h_intern(&lf[30],29,"\003syschicken-macro-environment");
lf[31]=C_h_intern(&lf[31],33,"\003syschicken-ffi-macro-environment");
lf[32]=C_h_intern(&lf[32],28,"\003sysextend-macro-environment");
lf[33]=C_h_intern(&lf[33],14,"\003syscopy-macro");
lf[34]=C_h_intern(&lf[34],6,"macro\077");
lf[35]=C_h_intern(&lf[35],20,"\003sysunregister-macro");
lf[36]=C_h_intern(&lf[36],4,"caar");
lf[37]=C_h_intern(&lf[37],15,"undefine-macro!");
lf[38]=C_h_intern(&lf[38],12,"\003sysexpand-0");
lf[39]=C_h_intern(&lf[39],9,"\003sysabort");
lf[40]=C_h_intern(&lf[40],9,"condition");
lf[41]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[42]=C_h_intern(&lf[42],13,"string-append");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\025during expansion of (");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\010 ...) - ");
lf[45]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[46]=C_h_intern(&lf[46],3,"exn");
lf[47]=C_h_intern(&lf[47],3,"-->");
lf[48]=C_h_intern(&lf[48],22,"with-exception-handler");
lf[49]=C_h_intern(&lf[49],30,"call-with-current-continuation");
lf[50]=C_h_intern(&lf[50],10,"\000STATIC-SE");
lf[51]=C_h_intern(&lf[51],10,"\003sysappend");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\020invoking macro: ");
lf[53]=C_h_intern(&lf[53],21,"\003syssyntax-error-hook");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid syntax in macro form");
lf[55]=C_h_intern(&lf[55],7,"\000EXPAND");
lf[56]=C_h_intern(&lf[56],3,"\000SE");
lf[57]=C_h_intern(&lf[57],1,"_");
lf[58]=C_h_intern(&lf[58],3,"let");
lf[59]=C_h_intern(&lf[59],8,"\004corelet");
lf[60]=C_h_intern(&lf[60],16,"\004coreloop-lambda");
lf[61]=C_h_intern(&lf[61],11,"\004coreletrec");
lf[62]=C_h_intern(&lf[62],8,"\004coreapp");
lf[63]=C_h_intern(&lf[63],4,"cadr");
lf[64]=C_h_intern(&lf[64],16,"\003syscheck-syntax");
lf[65]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[66]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[67]=C_h_intern(&lf[67],10,"\003syssetter");
lf[68]=C_h_intern(&lf[68],6,"append");
lf[69]=C_h_intern(&lf[69],4,"set!");
lf[70]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[71]=C_h_intern(&lf[71],9,"\004coreset!");
lf[72]=C_h_intern(&lf[72],25,"\003sysenable-runtime-macros");
lf[73]=C_h_intern(&lf[73],17,"\003sysmodule-rename");
lf[74]=C_h_intern(&lf[74],18,"\003sysstring->symbol");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\001#");
lf[77]=C_h_intern(&lf[77],22,"\003sysregister-undefined");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\025(ALIAS) global alias ");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[80]=C_h_intern(&lf[80],18,"\003syscurrent-module");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\023(ALIAS) primitive: ");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\020(ALIAS) marked: ");
lf[83]=C_h_intern(&lf[83],14,"\004coreprimitive");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000 (ALIAS) in current environment: ");
lf[85]=C_h_intern(&lf[85],12,"\004corealiased");
lf[86]=C_h_intern(&lf[86],10,"\003sysexpand");
lf[87]=C_h_intern(&lf[87],6,"expand");
lf[88]=C_h_intern(&lf[88],25,"\003sysextended-lambda-list\077");
lf[89]=C_h_intern(&lf[89],6,"#!rest");
lf[90]=C_h_intern(&lf[90],10,"#!optional");
lf[91]=C_h_intern(&lf[91],5,"#!key");
lf[92]=C_h_intern(&lf[92],7,"reverse");
lf[93]=C_h_intern(&lf[93],31,"\003sysexpand-extended-lambda-list");
lf[94]=C_h_intern(&lf[94],5,"cadar");
lf[95]=C_h_intern(&lf[95],5,"quote");
lf[96]=C_h_intern(&lf[96],15,"\003sysget-keyword");
lf[97]=C_h_intern(&lf[97],11,"\004corelambda");
lf[98]=C_h_intern(&lf[98],15,"string->keyword");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000+rest argument list specified more than once");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000-`#!optional\047 argument marker in wrong context");
lf[101]=C_h_intern(&lf[101],3,"tmp");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000#invalid syntax of `#!rest\047 argument");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000)`#!rest\047 argument marker in wrong context");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000(`#!key\047 argument marker in wrong context");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000 invalid required argument syntax");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[110]=C_h_intern(&lf[110],14,"let-optionals*");
lf[111]=C_h_intern(&lf[111],13,"let-optionals");
lf[112]=C_h_intern(&lf[112],8,"optional");
lf[113]=C_h_intern(&lf[113],4,"let*");
lf[114]=C_h_intern(&lf[114],3,"map");
lf[115]=C_h_intern(&lf[115],21,"\003syscanonicalize-body");
lf[116]=C_h_intern(&lf[116],5,"begin");
lf[117]=C_h_intern(&lf[117],6,"define");
lf[118]=C_h_intern(&lf[118],13,"define-values");
lf[119]=C_h_intern(&lf[119],5,"\000BODY");
lf[120]=C_h_intern(&lf[120],20,"\003syscall-with-values");
lf[121]=C_h_intern(&lf[121],14,"\004coreundefined");
lf[122]=C_h_intern(&lf[122],3,"cdr");
lf[123]=C_h_intern(&lf[123],13,"letrec-syntax");
lf[124]=C_h_intern(&lf[124],13,"define-syntax");
lf[125]=C_h_intern(&lf[125],5,"cdadr");
lf[126]=C_h_intern(&lf[126],6,"lambda");
lf[127]=C_h_intern(&lf[127],5,"caadr");
lf[128]=C_h_intern(&lf[128],25,"\003sysexpand-curried-define");
lf[129]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[130]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[131]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[132]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\001\000\000\010variable\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[133]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[134]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015define-syntax\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[135]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015define-values\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[136]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[138]=C_h_intern(&lf[138],24,"\003sysline-number-database");
lf[139]=C_h_intern(&lf[139],24,"\003syssyntax-error-culprit");
lf[140]=C_h_intern(&lf[140],15,"\003syssignal-hook");
lf[141]=C_h_intern(&lf[141],13,"\000syntax-error");
lf[142]=C_h_intern(&lf[142],12,"syntax-error");
lf[143]=C_h_intern(&lf[143],15,"get-line-number");
lf[144]=C_h_intern(&lf[144],18,"\003syshash-table-ref");
lf[145]=C_h_intern(&lf[145],8,"keyword\077");
lf[146]=C_h_intern(&lf[146],14,"symbol->string");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\012) in line ");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\024not enough arguments");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\022too many arguments");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\021not a proper list");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\021unexpected object");
lf[156]=C_h_intern(&lf[156],4,"pair");
lf[157]=C_h_intern(&lf[157],5,"pair\077");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\015pair expected");
lf[159]=C_h_intern(&lf[159],8,"variable");
lf[160]=C_h_intern(&lf[160],7,"symbol\077");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\023identifier expected");
lf[162]=C_h_intern(&lf[162],6,"symbol");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\017symbol expected");
lf[164]=C_h_intern(&lf[164],4,"list");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\024proper list expected");
lf[166]=C_h_intern(&lf[166],6,"number");
lf[167]=C_h_intern(&lf[167],7,"number\077");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\017number expected");
lf[169]=C_h_intern(&lf[169],6,"string");
lf[170]=C_h_intern(&lf[170],7,"string\077");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\017string expected");
lf[172]=C_h_intern(&lf[172],11,"lambda-list");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\024lambda-list expected");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\015pair expected");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\017incomplete form");
lf[177]=C_h_intern(&lf[177],18,"\003syser-transformer");
lf[178]=C_h_intern(&lf[178],12,"\000RENAME/RENV");
lf[179]=C_h_intern(&lf[179],14,"\000RENAME/LOOKUP");
lf[180]=C_h_intern(&lf[180],20,"\000RENAME/LOOKUP/MACRO");
lf[181]=C_h_intern(&lf[181],7,"\000RENAME");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\016  (lookup/DSE ");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\005 --> ");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[186]=C_h_intern(&lf[186],8,"\000COMPARE");
lf[187]=C_h_intern(&lf[187],17,"\003sysexpand-import");
lf[188]=C_h_intern(&lf[188],17,"\003sysstring-append");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[190]=C_h_intern(&lf[190],18,"\003syssymbol->string");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid prefix");
lf[194]=C_h_intern(&lf[194],15,"\003sysfind-module");
lf[195]=C_h_intern(&lf[195],8,"\003sysload");
lf[196]=C_h_intern(&lf[196],16,"\003sysdynamic-wind");
lf[197]=C_h_intern(&lf[197],26,"\003sysmeta-macro-environment");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000$can not import from undefined module");
lf[199]=C_h_intern(&lf[199],18,"\003sysfind-extension");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\007.import");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid import specification");
lf[202]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[203]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[204]=C_h_intern(&lf[204],8,"\003syswarn");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\037renamed identifier not imported");
lf[206]=C_h_intern(&lf[206],12,"\003sysfor-each");
lf[207]=C_h_intern(&lf[207],8,"\003sysdelq");
lf[208]=C_h_intern(&lf[208],4,"cdar");
lf[209]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000");
lf[210]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid import specification");
lf[212]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000$re-importing already imported syntax");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\047re-importing already imported identfier");
lf[215]=C_h_intern(&lf[215],25,"\003sysmark-imported-symbols");
lf[216]=C_h_intern(&lf[216],10,"<toplevel>");
lf[217]=C_h_intern(&lf[217],2,"\000S");
lf[218]=C_h_intern(&lf[218],2,"\000V");
lf[219]=C_h_intern(&lf[219],7,"\000IMPORT");
lf[220]=C_h_intern(&lf[220],6,"module");
lf[221]=C_h_intern(&lf[221],14,"\003sysblock-set!");
lf[224]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[225]=C_h_intern(&lf[225],6,"prefix");
lf[226]=C_h_intern(&lf[226],6,"except");
lf[227]=C_h_intern(&lf[227],6,"rename");
lf[228]=C_h_intern(&lf[228],4,"only");
lf[229]=C_h_intern(&lf[229],29,"\003sysinitial-macro-environment");
lf[230]=C_h_intern(&lf[230],24,"\003sysprocess-syntax-rules");
lf[231]=C_h_intern(&lf[231],7,"\003syscar");
lf[232]=C_h_intern(&lf[232],7,"\003syscdr");
lf[233]=C_h_intern(&lf[233],11,"\003sysvector\077");
lf[234]=C_h_intern(&lf[234],17,"\003sysvector-length");
lf[235]=C_h_intern(&lf[235],14,"\003sysvector-ref");
lf[236]=C_h_intern(&lf[236],16,"\003sysvector->list");
lf[237]=C_h_intern(&lf[237],16,"\003syslist->vector");
lf[238]=C_h_intern(&lf[238],6,"\003sys>=");
lf[239]=C_h_intern(&lf[239],5,"\003sys=");
lf[240]=C_h_intern(&lf[240],5,"\003sys+");
lf[241]=C_h_intern(&lf[241],8,"\003syscons");
lf[242]=C_h_intern(&lf[242],7,"\003syseq\077");
lf[243]=C_h_intern(&lf[243],10,"\003sysequal\077");
lf[244]=C_h_intern(&lf[244],9,"\003syslist\077");
lf[245]=C_h_intern(&lf[245],9,"\003sysmap-n");
lf[246]=C_h_intern(&lf[246],9,"\003sysnull\077");
lf[247]=C_h_intern(&lf[247],9,"\003syspair\077");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\024no rule matches form");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\026ill-formed syntax rule");
lf[250]=C_h_intern(&lf[250],6,"syntax");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000,template dimension error (too few ellipses\077)");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\021too many ellipses");
lf[253]=C_h_intern(&lf[253],9,"\003sysapply");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000 segment matching not implemented");
lf[255]=C_h_intern(&lf[255],4,"temp");
lf[256]=C_h_intern(&lf[256],4,"tail");
lf[257]=C_h_intern(&lf[257],2,"or");
lf[258]=C_h_intern(&lf[258],4,"loop");
lf[259]=C_h_intern(&lf[259],1,"l");
lf[260]=C_h_intern(&lf[260],5,"input");
lf[261]=C_h_intern(&lf[261],4,"else");
lf[262]=C_h_intern(&lf[262],4,"cond");
lf[263]=C_h_intern(&lf[263],7,"compare");
lf[264]=C_h_intern(&lf[264],1,"i");
lf[265]=C_h_intern(&lf[265],3,"and");
lf[266]=C_h_intern(&lf[266],29,"\003sysdefault-macro-environment");
lf[272]=C_h_intern(&lf[272],26,"set-module-undefined-list!");
lf[273]=C_h_intern(&lf[273],21,"module-undefined-list");
lf[276]=C_h_intern(&lf[276],16,"\003sysmodule-table");
lf[277]=C_h_intern(&lf[277],5,"error");
lf[278]=C_h_intern(&lf[278],6,"import");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\020module not found");
lf[280]=C_h_intern(&lf[280],28,"\003systoplevel-definition-hook");
lf[281]=C_h_intern(&lf[281],28,"\003sysregister-meta-expression");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\047redefinition of imported syntax binding");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000&redefinition of imported value binding");
lf[285]=C_h_intern(&lf[285],19,"\003sysregister-export");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\011defined: ");
lf[287]=C_h_intern(&lf[287],15,"\003sysfind-export");
lf[288]=C_h_intern(&lf[288],26,"\003sysregister-syntax-export");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\020defined syntax: ");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000!use of syntax precedes definition");
lf[291]=C_h_intern(&lf[291],19,"\003sysregister-module");
lf[292]=C_h_intern(&lf[292],8,"\000MARKING");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\014 in module `");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000!indirect export of syntax binding");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\033indirect reexport of syntax");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\042indirect export of unknown binding");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\024  merged has length ");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\010merging ");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\033 se\047s with total length of ");
lf[303]=C_h_intern(&lf[303],32,"\003syscompiled-module-registration");
lf[304]=C_h_intern(&lf[304],28,"\003sysregister-compiled-module");
lf[305]=C_h_intern(&lf[305],4,"cons");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000((internal) exported syntax has no source");
lf[307]=C_h_intern(&lf[307],4,"eval");
lf[308]=C_h_intern(&lf[308],29,"\003sysregister-primitive-module");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\0001unknown macro referenced while registering module");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\002#%");
lf[311]=C_h_intern(&lf[311],18,"module-exists-list");
lf[312]=C_h_intern(&lf[312],19,"\003sysfinalize-module");
lf[313]=C_h_intern(&lf[313],6,"\000DLIST");
lf[314]=C_h_intern(&lf[314],7,"\000SDLIST");
lf[315]=C_h_intern(&lf[315],9,"\000IEXPORTS");
lf[316]=C_h_intern(&lf[316],9,"\000VEXPORTS");
lf[317]=C_h_intern(&lf[317],9,"\000SEXPORTS");
lf[318]=C_h_intern(&lf[318],8,"\000EXPORTS");
lf[319]=C_h_intern(&lf[319],6,"\000FIXUP");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000$(internal) indirect export not found");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000(reference to possibly unbound identifier");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\015reexporting: ");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000 exported identifier for module `");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\026\047 has not been defined");
lf[326]=C_h_intern(&lf[326],16,"\003sysmacro-subset");
lf[327]=C_h_intern(&lf[327],14,"make-parameter");
lf[328]=C_h_intern(&lf[328],12,"syntax-rules");
lf[329]=C_h_intern(&lf[329],3,"...");
lf[330]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[331]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[332]=C_h_intern(&lf[332],6,"export");
lf[333]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid export syntax");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000!`export\047 used outside module body");
lf[336]=C_h_intern(&lf[336],16,"begin-for-syntax");
lf[337]=C_h_intern(&lf[337],24,"\004coreelaborationtimeonly");
lf[338]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[339]=C_h_intern(&lf[339],11,"\004coremodule");
lf[340]=C_h_intern(&lf[340],1,"*");
lf[341]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[342]=C_h_intern(&lf[342],17,"require-extension");
lf[343]=C_h_intern(&lf[343],22,"\004corerequire-extension");
lf[344]=C_h_intern(&lf[344],15,"require-library");
lf[345]=C_h_intern(&lf[345],11,"cond-expand");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\042syntax error in `cond-expand\047 form");
lf[347]=C_h_intern(&lf[347],12,"\003sysfeature\077");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000(no matching clause in `cond-expand\047 form");
lf[349]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[350]=C_h_intern(&lf[350],3,"not");
lf[351]=C_h_intern(&lf[351],5,"delay");
lf[352]=C_h_intern(&lf[352],16,"\003sysmake-promise");
lf[353]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[354]=C_h_intern(&lf[354],10,"quasiquote");
lf[355]=C_h_intern(&lf[355],8,"\003syslist");
lf[356]=C_h_intern(&lf[356],17,"%unquote-splicing");
lf[357]=C_h_intern(&lf[357],1,"a");
lf[358]=C_h_intern(&lf[358],1,"b");
lf[359]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\003sysappend\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[360]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[361]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\003syslist\376\001\000\000\001b\376\377\016");
lf[362]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\001\000\000\001b\376\377\016");
lf[363]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[364]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[365]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[366]=C_h_intern(&lf[366],16,"unquote-splicing");
lf[367]=C_h_intern(&lf[367],7,"unquote");
lf[368]=C_h_intern(&lf[368],2,"do");
lf[369]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[370]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[371]=C_h_intern(&lf[371],2,"if");
lf[372]=C_h_intern(&lf[372],6,"doloop");
lf[373]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001"
"\000\000\000\001");
lf[374]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[375]=C_h_intern(&lf[375],4,"case");
lf[376]=C_h_intern(&lf[376],8,"\003syseqv\077");
lf[377]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[378]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[379]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[380]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[381]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[382]=C_h_intern(&lf[382],2,"=>");
lf[383]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[384]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list");
lf[385]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[386]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\013lambda-list");
lf[387]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[388]=C_decode_literal(C_heaptop,"\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[389]=C_h_intern(&lf[389],17,"import-for-syntax");
lf[390]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\020\000hygienic-macros\376\003\000\000\002\376\001\000\000\015\000syntax-rules\376\377\016");
C_register_lf2(lf,391,create_ptable());
t2=C_mutate(&lf[0] /* (set! c152 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3484,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 38   append */
t4=*((C_word*)lf[68]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[390],C_retrieve(lf[2]));}

/* k3482 */
static void C_ccall f_3484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3484,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! features ...) */,t1);
t3=C_mutate(&lf[3] /* (set! d ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3486,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[6] /* (set! dd ...) */,C_retrieve2(lf[3],"d"));
t5=C_mutate(&lf[7] /* (set! dm ...) */,C_retrieve2(lf[3],"d"));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3511,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 66   make-parameter */
t7=C_retrieve(lf[327]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,C_SCHEME_END_OF_LIST);}

/* k3509 in k3482 */
static void C_ccall f_3511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3511,2,t0,t1);}
t2=C_mutate((C_word*)lf[8]+1 /* (set! current-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3515,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 67   make-parameter */
t4=C_retrieve(lf[327]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_END_OF_LIST);}

/* k3513 in k3509 in k3482 */
static void C_ccall f_3515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3515,2,t0,t1);}
t2=C_mutate((C_word*)lf[9]+1 /* (set! current-meta-environment ...) */,t1);
t3=C_mutate(&lf[10] /* (set! lookup ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3517,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[13] /* (set! macro-alias ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3535,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[20] /* (set! map-se ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3584,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[22]+1 /* (set! strip-syntax ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3614,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[28]+1 /* (set! strip-syntax ...) */,C_retrieve(lf[22]));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3765,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 119  make-parameter */
t9=C_retrieve(lf[327]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,C_SCHEME_END_OF_LIST);}

/* k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_3765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3765,2,t0,t1);}
t2=C_mutate((C_word*)lf[29]+1 /* (set! macro-environment ...) */,t1);
t3=C_set_block_item(lf[30] /* chicken-macro-environment */,0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(lf[31] /* chicken-ffi-macro-environment */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate((C_word*)lf[32]+1 /* (set! extend-macro-environment ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3769,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[33]+1 /* (set! copy-macro ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3802,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[34]+1 /* (set! macro? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3815,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[35]+1 /* (set! unregister-macro ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3871,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[37]+1 /* (set! undefine-macro! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3922,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[38]+1 /* (set! expand-0 ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3931,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t11=C_set_block_item(lf[72] /* enable-runtime-macros */,0,C_SCHEME_FALSE);
t12=C_mutate((C_word*)lf[73]+1 /* (set! module-rename ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4413,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[23]+1 /* (set! alias-global-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4431,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[86]+1 /* (set! expand ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4521,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[87]+1 /* (set! expand ...) */,C_retrieve(lf[86]));
t16=C_mutate((C_word*)lf[88]+1 /* (set! extended-lambda-list? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4574,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t17=*((C_word*)lf[92]+1);
t18=C_retrieve(lf[18]);
t19=C_mutate((C_word*)lf[93]+1 /* (set! expand-extended-lambda-list ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4617,a[2]=t17,a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp));
t20=*((C_word*)lf[92]+1);
t21=*((C_word*)lf[114]+1);
t22=C_mutate((C_word*)lf[115]+1 /* (set! canonicalize-body ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5207,a[2]=t21,a[3]=t20,a[4]=((C_word)li52),tmp=(C_word)a,a+=5,tmp));
t23=C_mutate(&lf[137] /* (set! match-expression ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5960,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[128]+1 /* (set! expand-curried-define ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6043,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp));
t25=C_set_block_item(lf[138] /* line-number-database */,0,C_SCHEME_FALSE);
t26=C_set_block_item(lf[139] /* syntax-error-culprit */,0,C_SCHEME_FALSE);
t27=C_mutate((C_word*)lf[53]+1 /* (set! syntax-error-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6113,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[142]+1 /* (set! syntax-error ...) */,C_retrieve(lf[53]));
t29=C_mutate((C_word*)lf[143]+1 /* (set! get-line-number ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6124,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t30=*((C_word*)lf[42]+1);
t31=C_retrieve(lf[145]);
t32=C_retrieve(lf[143]);
t33=*((C_word*)lf[146]+1);
t34=C_mutate((C_word*)lf[64]+1 /* (set! check-syntax ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6160,a[2]=t31,a[3]=t32,a[4]=t33,a[5]=t30,a[6]=((C_word)li71),tmp=(C_word)a,a+=7,tmp));
t35=C_mutate((C_word*)lf[177]+1 /* (set! er-transformer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6622,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[187]+1 /* (set! expand-import ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6916,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp));
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7761,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13544,a[2]=t37,tmp=(C_word)a,a+=3,tmp);
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13546,a[2]=((C_word)li201),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 867  ##sys#er-transformer */
t40=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t40))(3,t40,t38,t39);}

/* a13545 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13546(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13546,5,t0,t1,t2,t3,t4);}
/* ##sys#expand-import */
t5=C_retrieve(lf[187]);
((C_proc9)C_retrieve_proc(t5))(9,t5,t1,t2,t3,t4,C_retrieve(lf[8]),C_retrieve(lf[29]),C_SCHEME_FALSE,lf[278]);}

/* k13542 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 865  ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[278],C_SCHEME_END_OF_LIST,t1);}

/* k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7764,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13534,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13536,a[2]=((C_word)li200),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 873  ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a13535 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13536(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13536,5,t0,t1,t2,t3,t4);}
/* ##sys#expand-import */
t5=C_retrieve(lf[187]);
((C_proc9)C_retrieve_proc(t5))(9,t5,t1,t2,t3,t4,C_retrieve(lf[9]),C_retrieve(lf[197]),C_SCHEME_TRUE,lf[389]);}

/* k13532 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 871  ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[389],C_SCHEME_END_OF_LIST,t1);}

/* k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7764,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7768,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 877  ##sys#macro-environment */
t3=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7768,2,t0,t1);}
t2=C_mutate((C_word*)lf[229]+1 /* (set! initial-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7771,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13392,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13394,a[2]=((C_word)li199),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 882  ##sys#er-transformer */
t6=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* a13393 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13394(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13394,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13404,a[2]=t3,a[3]=t7,a[4]=((C_word)li198),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_13404(t9,t1,t5);}

/* loop in a13393 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_13404(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13404,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13460,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 893  ##sys#check-syntax */
t7=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,lf[117],t3,lf[384]);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13473,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 897  ##sys#check-syntax */
t7=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,lf[117],t3,lf[386]);}}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13420,a[2]=t1,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 888  ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[117],t3,lf[162]);}}

/* k13418 in loop in a13393 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13423,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 889  ##sys#check-syntax */
t3=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[117],((C_word*)t0)[4],lf[388]);}

/* k13421 in k13418 in loop in a13393 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13426,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13451,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 890  ##sys#current-module */
t4=C_retrieve(lf[80]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k13449 in k13421 in k13418 in loop in a13393 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 890  ##sys#register-export */
t2=C_retrieve(lf[285]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k13424 in k13421 in k13418 in loop in a13393 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13426,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[4]):lf[387]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[71],t5));}

/* k13471 in loop in a13393 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13476,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 898  ##sys#check-syntax */
t3=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[117],((C_word*)t0)[3],lf[385]);}

/* k13474 in k13471 in loop in a13393 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13476,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13479,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13522,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 899  ##sys#current-module */
t5=C_retrieve(lf[80]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k13520 in k13474 in k13471 in loop in a13393 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 899  ##sys#register-export */
t2=C_retrieve(lf[285]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k13477 in k13474 in k13471 in loop in a13393 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13479,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13502,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 902  r */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[126]);}

/* k13500 in k13477 in k13474 in k13471 in loop in a13393 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13502,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13514,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13512 in k13500 in k13477 in k13474 in k13471 in loop in a13393 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13514,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[71],t5));}

/* k13458 in loop in a13393 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 894  ##sys#check-syntax */
t3=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[117],((C_word*)t0)[2],lf[383]);}

/* k13461 in k13458 in loop in a13393 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13470,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 895  ##sys#expand-curried-define */
t3=C_retrieve(lf[128]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13468 in k13461 in k13458 in loop in a13393 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 895  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_13404(t2,((C_word*)t0)[2],t1);}

/* k13390 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 879  ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[117],C_SCHEME_END_OF_LIST,t1);}

/* k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7774,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13333,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13335,a[2]=((C_word)li197),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 907  ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a13334 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13335(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13335,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t5);
t7=(C_word)C_i_car(t5);
if(C_truep((C_word)C_i_nullp(t6))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13364,a[2]=t3,a[3]=t6,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 916  r */
t9=t3;
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,lf[371]);}}}

/* k13362 in a13334 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13384,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 916  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[265]);}

/* k13382 in k13362 in a13334 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13388,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13386 in k13382 in k13362 in a13334 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13388,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k13331 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 904  ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[265],C_SCHEME_END_OF_LIST,t1);}

/* k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7777,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13243,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13245,a[2]=((C_word)li196),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 921  ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a13244 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13245(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13245,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t5);
t7=(C_word)C_i_car(t5);
if(C_truep((C_word)C_i_nullp(t6))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13270,a[2]=t3,a[3]=t6,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 930  r */
t9=t3;
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,lf[101]);}}}

/* k13268 in a13244 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13277,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 931  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[58]);}

/* k13275 in k13268 in a13244 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13277,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13297,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 932  r */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[371]);}

/* k13295 in k13275 in k13268 in a13244 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13317,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 932  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[257]);}

/* k13315 in k13295 in k13275 in k13268 in a13244 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13321,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13319 in k13315 in k13295 in k13275 in k13268 in a13244 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13321,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t8));}

/* k13241 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 918  ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[257],C_SCHEME_END_OF_LIST,t1);}

/* k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7780,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12910,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12912,a[2]=((C_word)li195),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 937  ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12911 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12912,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12919,a[2]=t5,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 940  r */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[116]);}

/* k12917 in a12911 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12922,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 941  r */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[58]);}

/* k12920 in k12917 in a12911 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 942  r */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[371]);}

/* k12923 in k12920 in k12917 in a12911 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12928,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 943  r */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[382]);}

/* k12926 in k12923 in k12920 in k12917 in a12911 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 944  r */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[257]);}

/* k12929 in k12926 in k12923 in k12920 in k12917 in a12911 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12934,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 945  r */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[261]);}

/* k12932 in k12929 in k12926 in k12923 in k12920 in k12917 in a12911 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12937,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 946  r */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[126]);}

/* k12935 in k12932 in k12929 in k12926 in k12923 in k12920 in k12917 in a12911 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12937,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_12942,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t3,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word)li194),tmp=(C_word)a,a+=13,tmp));
t5=((C_word*)t3)[1];
f_12942(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k12935 in k12932 in k12929 in k12926 in k12923 in k12920 in k12917 in a12911 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_12942(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12942,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_12958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t4,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t3,a[13]=((C_word*)t0)[11],a[14]=t1,tmp=(C_word)a,a+=15,tmp);
/* expand.scm: 952  ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[262],t3,lf[380]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[381]);}}

/* k12956 in expand in k12935 in k12932 in k12929 in k12926 in k12923 in k12920 in k12917 in a12911 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_12964,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[12]);
/* expand.scm: 953  c */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k12962 in k12956 in expand in k12935 in k12932 in k12929 in k12926 in k12923 in k12920 in k12917 in a12911 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12964,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12971,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[11]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13000,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[13],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 954  expand */
t5=((C_word*)((C_word*)t0)[9])[1];
f_12942(t5,t4,((C_word*)t0)[8]);}
else{
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_13006,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[11]);
/* expand.scm: 955  c */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}}

/* k13004 in k12962 in k12956 in expand in k12935 in k12932 in k12929 in k12926 in k12923 in k12920 in k12917 in a12911 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13006,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13009,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 956  r */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[101]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13074,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[12]))){
t3=(C_word)C_i_length(((C_word*)t0)[12]);
t4=(C_word)C_eqp(t3,C_fix(4));
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[12]);
/* expand.scm: 962  c */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t2,((C_word*)t0)[2],t5);}
else{
t5=t2;
f_13074(2,t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_13074(2,t3,C_SCHEME_FALSE);}}}

/* k13072 in k13004 in k12962 in k12956 in expand in k12935 in k12932 in k12929 in k12926 in k12923 in k12920 in k12917 in a12911 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13074,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13077,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 963  r */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[101]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13199,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[9]);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}}

/* k13197 in k13072 in k13004 in k12962 in k12956 in expand in k12935 in k12932 in k12929 in k12926 in k12923 in k12920 in k12917 in a12911 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13199,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13195,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 972  expand */
t4=((C_word*)((C_word*)t0)[3])[1];
f_12942(t4,t3,((C_word*)t0)[2]);}

/* k13193 in k13197 in k13072 in k13004 in k12962 in k12956 in expand in k12935 in k12932 in k12929 in k12926 in k12923 in k12920 in k12917 in a12911 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13195,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k13075 in k13072 in k13004 in k12962 in k12956 in expand in k12935 in k12932 in k12929 in k12926 in k12923 in k12920 in k12917 in a12911 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13077,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_i_cadr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[253],t8);
t10=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t11=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t10,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[253],t12);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13132,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t9,a[7]=t13,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 969  expand */
t15=((C_word*)((C_word*)t0)[3])[1];
f_12942(t15,t14,((C_word*)t0)[2]);}

/* k13130 in k13075 in k13072 in k13004 in k12962 in k12956 in expand in k12935 in k12932 in k12929 in k12926 in k12923 in k12920 in k12917 in a12911 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13132,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,lf[371],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[120],t10));}

/* k13007 in k13004 in k12962 in k12956 in expand in k12935 in k12932 in k12929 in k12926 in k12923 in k12920 in k12917 in a12911 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13009,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_i_caddr(((C_word*)t0)[7]);
t7=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13048,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 960  expand */
t10=((C_word*)((C_word*)t0)[3])[1];
f_12942(t10,t9,((C_word*)t0)[2]);}

/* k13046 in k13007 in k13004 in k12962 in k12956 in expand in k12935 in k12932 in k12929 in k12926 in k12923 in k12920 in k12917 in a12911 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13048,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k12998 in k12962 in k12956 in expand in k12935 in k12932 in k12929 in k12926 in k12923 in k12920 in k12917 in a12911 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_13000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13000,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k12969 in k12962 in k12956 in expand in k12935 in k12932 in k12929 in k12926 in k12923 in k12920 in k12917 in a12911 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12971,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k12908 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 934  ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[262],C_SCHEME_END_OF_LIST,t1);}

/* k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7780,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7783,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12740,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12742,a[2]=((C_word)li193),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 977  ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12741 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12742(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12742,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12746,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 979  ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[375],t2,lf[379]);}

/* k12744 in a12741 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12746,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12755,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 982  r */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[101]);}

/* k12753 in k12744 in a12741 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12755,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12758,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 983  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[116]);}

/* k12756 in k12753 in k12744 in a12741 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12758,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12761,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 984  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[371]);}

/* k12759 in k12756 in k12753 in k12744 in a12741 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 985  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[257]);}

/* k12762 in k12759 in k12756 in k12753 in k12744 in a12741 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12764,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12767,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 987  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[261]);}

/* k12765 in k12762 in k12759 in k12756 in k12753 in k12744 in a12741 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12767,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12786,a[2]=((C_word*)t0)[7],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12788,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word)li192),tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_12788(t9,t5,((C_word*)t0)[2]);}

/* expand in k12765 in k12762 in k12759 in k12756 in k12753 in k12744 in a12741 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_12788(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12788,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t3,a[10]=((C_word*)t0)[8],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 994  ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[375],t3,lf[377]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[378]);}}

/* k12802 in expand in k12765 in k12762 in k12759 in k12756 in k12753 in k12744 in a12741 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12810,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* expand.scm: 995  c */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k12808 in k12802 in expand in k12765 in k12762 in k12759 in k12756 in k12753 in k12744 in a12741 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12810,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12817,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12860,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12864,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12866,a[2]=((C_word*)t0)[2],a[3]=((C_word)li191),tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[7]);
/* expand.scm: 997  ##sys#map */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a12865 in k12808 in k12802 in expand in k12765 in k12762 in k12759 in k12756 in k12753 in k12744 in a12741 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12866(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12866,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[95],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[376],t6));}

/* k12862 in k12808 in k12802 in expand in k12765 in k12762 in k12759 in k12756 in k12753 in k12744 in a12741 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k12858 in k12808 in k12802 in expand in k12765 in k12762 in k12759 in k12756 in k12753 in k12744 in a12741 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12860,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12852,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k12850 in k12858 in k12808 in k12802 in expand in k12765 in k12762 in k12759 in k12756 in k12753 in k12744 in a12741 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12852,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12848,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1000 expand */
t4=((C_word*)((C_word*)t0)[3])[1];
f_12788(t4,t3,((C_word*)t0)[2]);}

/* k12846 in k12850 in k12858 in k12808 in k12802 in expand in k12765 in k12762 in k12759 in k12756 in k12753 in k12744 in a12741 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12848,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k12815 in k12808 in k12802 in expand in k12765 in k12762 in k12759 in k12756 in k12753 in k12744 in a12741 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12817,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k12784 in k12765 in k12762 in k12759 in k12756 in k12753 in k12744 in a12741 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12786,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[58],t3));}

/* k12738 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 974  ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[375],C_SCHEME_END_OF_LIST,t1);}

/* k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7786,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12671,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12673,a[2]=((C_word)li190),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1005 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12672 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12673(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12673,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12677,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1007 ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[113],t2,lf[374]);}

/* k12675 in a12672 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12677,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12686,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1010 r */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[58]);}

/* k12684 in k12675 in a12672 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12686,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12691,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word)li189),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_12691(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k12684 in k12675 in a12672 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_12691(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_12691,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12709,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12728,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(t2);
/* expand.scm: 1014 expand */
t10=t6;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}

/* k12726 in expand in k12684 in k12675 in a12672 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12728,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k12707 in expand in k12684 in k12675 in a12672 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12709,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k12669 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1002 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[113],C_SCHEME_END_OF_LIST,t1);}

/* k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7789,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12489,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12491,a[2]=((C_word)li188),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1019 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12490 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12491(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12491,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12495,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1021 ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[368],t2,lf[373]);}

/* k12493 in a12490 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12495,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12507,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1025 r */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[372]);}

/* k12505 in k12493 in a12490 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12510,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1026 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[58]);}

/* k12508 in k12505 in k12493 in a12490 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12513,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1027 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[371]);}

/* k12511 in k12508 in k12505 in k12493 in a12490 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12516,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1028 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[116]);}

/* k12514 in k12511 in k12508 in k12505 in k12493 in a12490 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12651,a[2]=((C_word)li187),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1029 ##sys#map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a12650 in k12514 in k12511 in k12508 in k12505 in k12493 in a12490 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12651(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12651,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_car(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,2,t3,t5));}

/* k12529 in k12514 in k12511 in k12508 in k12505 in k12493 in a12490 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12531,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cdr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t5=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t4;
f_12558(t6,lf[370]);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12649,a[2]=((C_word*)t0)[7],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t7=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,C_SCHEME_END_OF_LIST);}}

/* k12647 in k12529 in k12514 in k12511 in k12508 in k12505 in k12493 in a12490 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12649,2,t0,t1);}
t2=((C_word*)t0)[3];
f_12558(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k12556 in k12529 in k12514 in k12511 in k12508 in k12505 in k12493 in a12490 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_12558(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12558,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12574,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t2;
f_12574(t4,lf[369]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12639,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}

/* k12637 in k12556 in k12529 in k12514 in k12511 in k12508 in k12505 in k12493 in a12490 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12639,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
f_12574(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k12572 in k12556 in k12529 in k12514 in k12511 in k12508 in k12505 in k12493 in a12490 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_12574(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12574,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12590,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12594,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12596,a[2]=((C_word)li186),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1040 ##sys#map */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a12595 in k12572 in k12556 in k12529 in k12514 in k12511 in k12508 in k12505 in k12493 in a12490 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12596(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12596,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_cdr(t3);
t5=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_car(t2));}
else{
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_car(t7));}}

/* k12592 in k12572 in k12556 in k12529 in k12514 in k12511 in k12508 in k12505 in k12493 in a12490 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k12588 in k12572 in k12556 in k12529 in k12514 in k12511 in k12508 in k12505 in k12493 in a12490 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12590,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[62],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t12);
t14=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t13));}

/* k12487 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1016 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[368],C_SCHEME_END_OF_LIST,t1);}

/* k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7792,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12094,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12096,a[2]=((C_word)li185),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1049 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12096,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12100,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1051 r */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[95]);}

/* k12098 in a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12103,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1052 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[354]);}

/* k12101 in k12098 in a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12103,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12106,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1053 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[367]);}

/* k12104 in k12101 in k12098 in a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12106,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12109,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1054 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[366]);}

/* k12107 in k12104 in k12101 in k12098 in a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12109,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12111,a[2]=t5,a[3]=t7,a[4]=((C_word)li182),tmp=(C_word)a,a+=5,tmp));
t9=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12121,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,a[8]=((C_word)li183),tmp=(C_word)a,a+=9,tmp));
t10=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12390,a[2]=t7,a[3]=((C_word)li184),tmp=(C_word)a,a+=4,tmp));
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12478,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1104 ##sys#check-syntax */
t12=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,lf[354],((C_word*)t0)[3],lf[365]);}

/* k12476 in k12107 in k12104 in k12101 in k12098 in a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* expand.scm: 1105 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_12111(t3,((C_word*)t0)[2],t2,C_fix(0));}

/* simplify in k12107 in k12104 in k12101 in k12098 in a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_12390(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12390,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12394,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1092 match-expression */
f_5960(t3,t2,lf[363],lf[364]);}

/* k12392 in simplify in k12107 in k12104 in k12101 in k12098 in a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12394,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[357],t1);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[355],t4);
/* expand.scm: 1093 simplify */
t6=((C_word*)((C_word*)t0)[4])[1];
f_12390(t6,((C_word*)t0)[3],t5);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12419,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1094 match-expression */
f_5960(t2,((C_word*)t0)[2],lf[361],lf[362]);}}

/* k12417 in k12392 in simplify in k12107 in k12104 in k12101 in k12098 in a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12419,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[358],t1);
t3=(C_word)C_i_length(t2);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(32)))){
t4=(C_word)C_i_assq(lf[357],t1);
t5=(C_word)C_slot(t4,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12450,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(t2);
/* ##sys#append */
t8=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,C_SCHEME_END_OF_LIST);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1101 match-expression */
f_5960(t2,((C_word*)t0)[2],lf[359],lf[360]);}}

/* k12463 in k12417 in k12392 in simplify in k12107 in k12104 in k12101 in k12098 in a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[357],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k12448 in k12417 in k12392 in simplify in k12107 in k12104 in k12101 in k12098 in a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12450,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[355],t2);
/* expand.scm: 1098 simplify */
t4=((C_word*)((C_word*)t0)[3])[1];
f_12390(t4,((C_word*)t0)[2],t3);}

/* walk1 in k12107 in k12104 in k12101 in k12098 in a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_12121(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12121,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12139,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12143,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1058 vector->list */
t6=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12168,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=t3,a[11]=t5,tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 1063 c */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[6],t4);}
else{
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4));}}}

/* k12166 in walk1 in k12107 in k12104 in k12101 in k12098 in a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12168,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[11]))){
t2=(C_word)C_i_car(((C_word*)t0)[11]);
t3=(C_word)C_eqp(((C_word*)t0)[10],C_fix(0));
if(C_truep(t3)){
t4=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12194,a[2]=t5,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_fixnum_difference(((C_word*)t0)[10],C_fix(1));
/* expand.scm: 1069 walk */
t8=((C_word*)((C_word*)t0)[6])[1];
f_12111(t8,t6,t2,t7);}}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2));}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12215,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 1071 c */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k12213 in k12166 in walk1 in k12107 in k12104 in k12101 in k12098 in a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12215,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[10]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12240,a[2]=((C_word*)t0)[7],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[10]);
t6=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
/* expand.scm: 1074 walk */
t7=((C_word*)((C_word*)t0)[5])[1];
f_12111(t7,t4,t5,t6);}
else{
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12263,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1076 walk */
t4=((C_word*)((C_word*)t0)[5])[1];
f_12111(t4,t3,((C_word*)t0)[10],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12362,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1080 c */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12376,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1090 walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_12111(t3,t2,((C_word*)t0)[4],((C_word*)t0)[6]);}}}

/* k12374 in k12213 in k12166 in walk1 in k12107 in k12104 in k12101 in k12098 in a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12384,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1090 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_12111(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12382 in k12374 in k12213 in k12166 in walk1 in k12107 in k12104 in k12101 in k12098 in a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12384,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[241],t3));}

/* k12360 in k12213 in k12166 in walk1 in k12107 in k12104 in k12101 in k12098 in a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12362,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_pairp(((C_word*)t0)[7]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(0));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12305,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1084 walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_12111(t6,t5,((C_word*)t0)[3],((C_word*)t0)[6]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12336,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_fixnum_difference(((C_word*)t0)[6],C_fix(1));
/* expand.scm: 1086 walk */
t7=((C_word*)((C_word*)t0)[4])[1];
f_12111(t7,t5,t3,t6);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12351,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1088 walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_12111(t4,t3,((C_word*)t0)[2],((C_word*)t0)[6]);}}

/* k12349 in k12360 in k12213 in k12166 in walk1 in k12107 in k12104 in k12101 in k12098 in a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12359,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1088 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_12111(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12357 in k12349 in k12360 in k12213 in k12166 in walk1 in k12107 in k12104 in k12101 in k12098 in a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12359,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[241],t3));}

/* k12334 in k12360 in k12213 in k12166 in walk1 in k12107 in k12104 in k12101 in k12098 in a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12336,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[356],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[355],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12324,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1087 walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_12111(t6,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12322 in k12334 in k12360 in k12213 in k12166 in walk1 in k12107 in k12104 in k12101 in k12098 in a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12324,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[241],t3));}

/* k12303 in k12360 in k12213 in k12166 in walk1 in k12107 in k12104 in k12101 in k12098 in a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12305,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[51],t3));}

/* k12261 in k12213 in k12166 in walk1 in k12107 in k12104 in k12101 in k12098 in a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12263,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[241],((C_word*)t0)[2],t1));}

/* k12238 in k12213 in k12166 in walk1 in k12107 in k12104 in k12101 in k12098 in a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12240,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[355],t3));}

/* k12192 in k12166 in walk1 in k12107 in k12104 in k12101 in k12098 in a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12194,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[355],((C_word*)t0)[2],t1));}

/* k12141 in walk1 in k12107 in k12104 in k12101 in k12098 in a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1058 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_12111(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k12137 in walk1 in k12107 in k12104 in k12101 in k12098 in a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12139,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[237],t2));}

/* walk in k12107 in k12104 in k12101 in k12098 in a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_12111(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12111,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12119,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1055 walk1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_12121(t5,t4,t2,t3);}

/* k12117 in walk in k12107 in k12104 in k12101 in k12098 in a12095 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1055 simplify */
t2=((C_word*)((C_word*)t0)[3])[1];
f_12390(t2,((C_word*)t0)[2],t1);}

/* k12092 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1046 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[354],C_SCHEME_END_OF_LIST,t1);}

/* k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7795,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12061,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12063,a[2]=((C_word)li181),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1110 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12062 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12063(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12063,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12067,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1112 ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[351],t2,lf[353]);}

/* k12065 in a12062 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12067,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[126],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[352],t6));}

/* k12059 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1107 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[351],C_SCHEME_END_OF_LIST,t1);}

/* k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7798,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11777,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11779,a[2]=((C_word)li180),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1118 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11778 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11779(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11779,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11786,a[2]=t3,a[3]=t1,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1121 r */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[257]);}

/* k11784 in a11778 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11789,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1122 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[350]);}

/* k11787 in k11784 in a11778 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11792,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1123 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[261]);}

/* k11790 in k11787 in k11784 in a11778 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11795,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1124 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[116]);}

/* k11793 in k11790 in k11787 in k11784 in a11778 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11798,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1125 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[265]);}

/* k11796 in k11793 in k11790 in k11787 in k11784 in a11778 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11800,a[2]=((C_word*)t0)[8],a[3]=((C_word)li176),tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11810,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=t4,a[7]=t1,a[8]=((C_word)li177),tmp=(C_word)a,a+=9,tmp));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11960,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[8],a[9]=((C_word)li179),tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_11960(t9,((C_word*)t0)[2],((C_word*)t0)[8]);}

/* expand in k11796 in k11793 in k11790 in k11787 in k11784 in a11778 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_11960(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11960,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11974,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11976,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[8]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_i_car(t4);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12013,a[2]=t6,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=t4,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1162 c */
t8=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,t6,((C_word*)t0)[3]);}
else{
/* expand.scm: 1160 err */
t6=((C_word*)t0)[2];
f_11800(t6,t1,t4);}}
else{
/* expand.scm: 1155 err */
t4=((C_word*)t0)[2];
f_11800(t4,t1,t2);}}}

/* k12011 in expand in k11796 in k11793 in k11790 in k11787 in k11784 in a11778 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12013,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[349]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12029,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_SCHEME_END_OF_LIST);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12035,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1167 test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11810(t3,t2,((C_word*)t0)[2]);}}

/* k12033 in k12011 in expand in k11796 in k11793 in k11790 in k11787 in k11784 in a11778 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12035,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12042,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
/* expand.scm: 1168 expand */
t2=((C_word*)((C_word*)t0)[3])[1];
f_11960(t2,((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k12040 in k12033 in k12011 in expand in k11796 in k11793 in k11790 in k11787 in k11784 in a11778 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12042,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k12027 in k12011 in expand in k11796 in k11793 in k11790 in k11787 in k11784 in a11778 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_12029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12029,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a11975 in expand in k11796 in k11793 in k11790 in k11787 in k11784 in a11778 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11976(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11976,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k11972 in expand in k11796 in k11793 in k11790 in k11787 in k11784 in a11778 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[27]+1),lf[348],t1);}

/* test in k11796 in k11793 in k11790 in k11787 in k11784 in a11778 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_11810(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11810,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* expand.scm: 1131 ##sys#feature? */
t3=C_retrieve(lf[347]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_11841,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t1,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 1136 c */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[7],t3);}
else{
/* expand.scm: 1132 err */
t3=((C_word*)t0)[5];
f_11800(t3,t1,t2);}}}

/* k11839 in test in k11796 in k11793 in k11790 in k11787 in k11784 in a11778 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11841,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
t3=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[11]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11859,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[11]);
/* expand.scm: 1139 test */
t5=((C_word*)((C_word*)t0)[8])[1];
f_11810(t5,t3,t4);}
else{
/* expand.scm: 1141 err */
t3=((C_word*)t0)[7];
f_11800(t3,((C_word*)t0)[10],((C_word*)t0)[6]);}}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11887,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 1142 c */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k11885 in k11839 in test in k11796 in k11793 in k11790 in k11787 in k11784 in a11778 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11887,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
t3=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[10]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11902,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[10]);
/* expand.scm: 1145 test */
t5=((C_word*)((C_word*)t0)[7])[1];
f_11810(t5,t3,t4);}
else{
/* expand.scm: 1147 err */
t3=((C_word*)t0)[6];
f_11800(t3,((C_word*)t0)[9],((C_word*)t0)[5]);}}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11937,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1148 c */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k11935 in k11885 in k11839 in test in k11796 in k11793 in k11790 in k11787 in k11784 in a11778 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11937,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11944,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* expand.scm: 1148 test */
t4=((C_word*)((C_word*)t0)[3])[1];
f_11810(t4,t2,t3);}
else{
/* expand.scm: 1149 err */
t2=((C_word*)t0)[2];
f_11800(t2,((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k11942 in k11935 in k11885 in k11839 in test in k11796 in k11793 in k11790 in k11787 in k11784 in a11778 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k11900 in k11885 in k11839 in test in k11796 in k11793 in k11790 in k11787 in k11784 in a11778 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11902,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11916,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}}

/* k11914 in k11900 in k11885 in k11839 in test in k11796 in k11793 in k11790 in k11787 in k11784 in a11778 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11916,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* expand.scm: 1146 test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11810(t3,((C_word*)t0)[2],t2);}

/* k11857 in k11839 in test in k11796 in k11793 in k11790 in k11787 in k11784 in a11778 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11859,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11870,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11868 in k11857 in k11839 in test in k11796 in k11793 in k11790 in k11787 in k11784 in a11778 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11870,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* expand.scm: 1140 test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11810(t3,((C_word*)t0)[2],t2);}

/* err in k11796 in k11793 in k11790 in k11787 in k11784 in a11778 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_11800(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11800,NULL,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,lf[345],((C_word*)t0)[2]);
/* expand.scm: 1127 ##sys#error */
t4=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[346],t2,t3);}

/* k11775 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1115 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[345],C_SCHEME_END_OF_LIST,t1);}

/* k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7801,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11756,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11758,a[2]=((C_word)li175),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1173 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11757 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11758(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11758,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[343],t7));}

/* k11754 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1170 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[344],C_SCHEME_END_OF_LIST,t1);}

/* k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7804,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11735,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11737,a[2]=((C_word)li174),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1181 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11736 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11737,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[343],t7));}

/* k11733 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1178 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[342],C_SCHEME_END_OF_LIST,t1);}

/* k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7807,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11684,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11686,a[2]=((C_word)li173),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1189 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11685 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11686,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11690,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1191 ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[220],t2,lf[341]);}

/* k11688 in a11685 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11690,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11720,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11727,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1194 r */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[340]);}

/* k11725 in k11688 in a11685 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* expand.scm: 1194 c */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k11718 in k11688 in a11685 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11720,2,t0,t1);}
t2=(C_truep(t1)?C_SCHEME_TRUE:(C_word)C_i_caddr(((C_word*)t0)[4]));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11713,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k11711 in k11718 in k11688 in a11685 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11713,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[339],t3));}

/* k11682 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1186 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[220],C_SCHEME_END_OF_LIST,t1);}

/* k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7810,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11630,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11632,a[2]=((C_word)li172),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1202 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11631 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11632(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11632,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11636,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1204 ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[336],t2,lf[338]);}

/* k11634 in a11631 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11636,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11639,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1205 ##sys#current-module */
t3=C_retrieve(lf[80]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k11637 in k11634 in a11631 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11639,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11642,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11676,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_11642(2,t3,C_SCHEME_FALSE);}}

/* k11674 in k11637 in k11634 in a11631 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11676,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[116],t1);
/* expand.scm: 1206 ##sys#register-meta-expression */
t3=C_retrieve(lf[281]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k11640 in k11637 in k11634 in a11631 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11657,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1207 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[116]);}

/* k11655 in k11640 in k11637 in k11634 in a11631 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11661,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k11659 in k11655 in k11640 in k11637 in k11634 in a11631 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11661,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[337],t3));}

/* k11628 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1199 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[336],C_SCHEME_END_OF_LIST,t1);}

/* k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7813,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11527,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11529,a[2]=((C_word)li171),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1212 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11528 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11529(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11529,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11536,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1215 ##sys#current-module */
t7=C_retrieve(lf[80]);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k11534 in a11528 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11539,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_11539(2,t3,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 1217 syntax-error */
t3=C_retrieve(lf[142]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[332],lf[335]);}}

/* k11537 in k11534 in a11528 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11539,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11542,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11559,a[2]=((C_word*)t0)[3],a[3]=((C_word)li170),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11558 in k11537 in k11534 in a11528 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11559(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11559,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11566,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
t4=t3;
f_11566(t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11581,a[2]=((C_word)li169),tmp=(C_word)a,a+=3,tmp);
t5=t3;
f_11566(t5,f_11581(t2));}}

/* loop in a11558 in k11537 in k11534 in a11528 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static C_word C_fcall f_11581(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_i_cdr(t1);
t5=t3;
t1=t5;
goto loop;}
else{
return(C_SCHEME_TRUE);}}
else{
return(C_SCHEME_TRUE);}}}

/* k11564 in a11558 in k11537 in k11534 in a11528 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_11566(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=f_9473(((C_word*)t0)[4]);
/* expand.scm: 1226 syntax-error */
t3=C_retrieve(lf[142]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[3],lf[332],lf[334],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k11540 in k11537 in k11534 in a11528 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11542,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11545,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11549,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=f_9491(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11557,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* map */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[22]),((C_word*)t0)[2]);}

/* k11555 in k11540 in k11537 in k11534 in a11528 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1230 append */
t2=*((C_word*)lf[68]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11547 in k11540 in k11537 in k11534 in a11528 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t4=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],t2,C_fix(2),t1);}

/* k11543 in k11540 in k11537 in k11534 in a11528 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[333]);}

/* k11525 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1209 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[332],C_SCHEME_END_OF_LIST,t1);}

/* k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7816,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11490,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11492,a[2]=((C_word)li168),tmp=(C_word)a,a+=3,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11491 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11492(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11492,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11496,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[328],t2,lf[331]);}

/* k11494 in a11491 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11496,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[5]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=lf[329];
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11505,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t7,a[6]=t9,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t4)[1]))){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11514,a[2]=t10,a[3]=t7,a[4]=t4,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
/* ##sys#check-syntax */
t12=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,lf[328],((C_word*)t0)[5],lf[330]);}
else{
t11=t10;
f_11505(t11,C_SCHEME_UNDEFINED);}}

/* k11512 in k11494 in a11491 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)((C_word*)t0)[4])[1]);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[2];
f_11505(t7,t6);}

/* k11503 in k11494 in a11491 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_11505(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#process-syntax-rules */
t2=C_retrieve(lf[230]);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11488 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[328],C_SCHEME_END_OF_LIST,t1);}

/* k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7816,2,t0,t1);}
t2=C_mutate((C_word*)lf[230]+1 /* (set! process-syntax-rules ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7818,a[2]=((C_word)li112),tmp=(C_word)a,a+=3,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9451,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1242 ##sys#macro-environment */
t4=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9451,2,t0,t1);}
t2=C_mutate((C_word*)lf[266]+1 /* (set! default-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9455,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11486,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1247 ##sys#macro-environment */
t5=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k11484 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1247 make-parameter */
t2=C_retrieve(lf[327]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9455,2,t0,t1);}
t2=C_mutate((C_word*)lf[197]+1 /* (set! meta-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9459,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1248 make-parameter */
t4=C_retrieve(lf[327]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[93],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9459,2,t0,t1);}
t2=C_mutate((C_word*)lf[80]+1 /* (set! current-module ...) */,t1);
t3=C_mutate(&lf[76] /* (set! module-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9473,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[267] /* (set! module-export-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9491,a[2]=((C_word)li114),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[268] /* (set! set-module-defined-list! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9500,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[269] /* (set! module-defined-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9509,a[2]=((C_word)li116),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[270] /* (set! module-exist-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9527,a[2]=((C_word)li117),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate(&lf[271] /* (set! module-defined-syntax-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9545,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[272]+1 /* (set! set-module-undefined-list! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9554,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[273]+1 /* (set! module-undefined-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9563,a[2]=((C_word)li120),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[223] /* (set! module-import-forms ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9581,a[2]=((C_word)li121),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate(&lf[222] /* (set! module-meta-import-forms ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9599,a[2]=((C_word)li122),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate(&lf[274] /* (set! module-meta-expressions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9617,a[2]=((C_word)li123),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate(&lf[192] /* (set! module-vexports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9635,a[2]=((C_word)li124),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate(&lf[193] /* (set! module-sexports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9653,a[2]=((C_word)li125),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate(&lf[275] /* (set! make-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9662,a[2]=((C_word)li126),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[194]+1 /* (set! find-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9668,a[2]=((C_word)li127),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[280]+1 /* (set! toplevel-definition-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9708,a[2]=((C_word)li128),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[281]+1 /* (set! register-meta-expression ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9711,a[2]=((C_word)li129),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate(&lf[282] /* (set! check-for-redef ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9731,a[2]=((C_word)li130),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[285]+1 /* (set! register-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9752,a[2]=((C_word)li131),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[288]+1 /* (set! register-syntax-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9841,a[2]=((C_word)li132),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[77]+1 /* (set! register-undefined ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9918,a[2]=((C_word)li133),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[291]+1 /* (set! register-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9940,a[2]=((C_word)li136),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[215]+1 /* (set! mark-imported-symbols ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10008,a[2]=((C_word)li138),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate(&lf[293] /* (set! module-indirect-exports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10067,a[2]=((C_word)li142),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate(&lf[299] /* (set! merge-se ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10343,a[2]=((C_word)li144),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[303]+1 /* (set! compiled-module-registration ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10415,a[2]=((C_word)li147),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[304]+1 /* (set! register-compiled-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10701,a[2]=((C_word)li152),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[308]+1 /* (set! register-primitive-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10821,a[2]=((C_word)li155),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[287]+1 /* (set! find-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10912,a[2]=((C_word)li157),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[312]+1 /* (set! finalize-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10997,a[2]=((C_word)li165),tmp=(C_word)a,a+=3,tmp));
t33=C_set_block_item(lf[276] /* module-table */,0,C_SCHEME_END_OF_LIST);
t34=C_mutate((C_word*)lf[326]+1 /* (set! macro-subset ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11444,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp));
t35=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t35+1)))(2,t35,C_SCHEME_UNDEFINED);}

/* ##sys#macro-subset in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11444(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11444,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11452,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1576 ##sys#macro-environment */
t4=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k11450 in ##sys#macro-subset in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11452,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11454,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li166),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11454(t5,((C_word*)t0)[2],t1);}

/* loop in k11450 in ##sys#macro-subset in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_11454(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11454,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,((C_word*)t0)[3]));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11475,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(t2);
/* expand.scm: 1579 loop */
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}

/* k11473 in loop in k11450 in ##sys#macro-subset in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11475,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10997(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10997,3,t0,t1,t2);}
t3=f_9491(t2);
t4=f_9473(t2);
t5=f_9509(t2);
t6=f_9527(t2);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11013,a[2]=t4,a[3]=t3,a[4]=t6,a[5]=t5,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11429,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp);
t9=f_9545(t2);
/* map */
t10=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}

/* a11428 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11429(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11429,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11437,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1503 ##sys#macro-environment */
t4=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k11435 in a11428 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_assq(((C_word*)t0)[2],t1));}

/* k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11016,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11367,a[2]=((C_word)li162),tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11386,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1509 ##sys#macro-environment */
t5=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k11384 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11386,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11388,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li163),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11388(t5,((C_word*)t0)[2],t1);}

/* loop in k11384 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_11388(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11388,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11401,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11427,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1511 caar */
t5=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k11425 in loop in k11384 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1511 ##sys#find-export */
t2=C_retrieve(lf[287]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k11399 in loop in k11384 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11401,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11412,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1512 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11388(t5,t3,t4);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1513 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_11388(t3,((C_word*)t0)[3],t2);}}

/* k11410 in k11399 in loop in k11384 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11412,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a11366 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11367(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11367,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11379,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1507 ##sys#macro-environment */
t5=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k11377 in a11366 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_assq(((C_word*)t0)[2],t1));}

/* k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11019,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
t4=(C_truep(t3)?((C_word*)t0)[4]:((C_word*)t0)[3]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11239,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t6,a[5]=t1,a[6]=((C_word)li161),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_11239(t8,t2,t4);}

/* loop in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_11239(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11239,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_symbolp(t3);
t5=(C_truep(t4)?t3:(C_word)C_i_car(t3));
if(C_truep((C_word)C_i_assq(t5,((C_word*)t0)[5]))){
t6=(C_word)C_i_cdr(t2);
/* expand.scm: 1521 loop */
t12=t1;
t13=t6;
t1=t12;
t2=t13;
goto loop;}
else{
t6=(C_word)C_i_assq(t5,((C_word*)t0)[3]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11287,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11290,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t6,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t9=(C_word)C_i_cdr(t6);
t10=t8;
f_11290(t10,(C_word)C_i_symbolp(t9));}
else{
t9=t8;
f_11290(t9,C_SCHEME_FALSE);}}}}

/* k11288 in loop in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_11290(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11290,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_11287(2,t2,(C_word)C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11343,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1528 ##sys#current-environment */
t3=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}

/* k11341 in k11288 in loop in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11343,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11302,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=t3;
f_11302(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t3;
f_11302(t4,C_SCHEME_FALSE);}}

/* k11300 in k11341 in k11288 in loop in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_11302(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11302,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11305,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* expand.scm: 1530 dm */
t4=C_retrieve2(lf[7],"dm");
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[322],((C_word*)t0)[4],lf[323],t3);}
else{
if(C_truep(((C_word*)t0)[3])){
/* expand.scm: 1539 ##sys#module-rename */
t2=C_retrieve(lf[73]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11325,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11329,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1536 symbol->string */
t4=*((C_word*)lf[146]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}}

/* k11327 in k11300 in k11341 in k11288 in loop in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1534 string-append */
t2=*((C_word*)lf[42]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[324],t1,lf[325]);}

/* k11323 in k11300 in k11341 in k11288 in loop in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1533 ##sys#warn */
t2=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k11303 in k11300 in k11341 in k11288 in loop in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_11287(2,t2,(C_word)C_i_cdr(((C_word*)t0)[2]));}

/* k11285 in loop in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11287,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11276,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1540 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11239(t5,t3,t4);}

/* k11274 in k11285 in loop in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11276,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11022,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11219,a[2]=((C_word*)t0)[2],a[3]=((C_word)li160),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11233,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1545 module-undefined-list */
t5=C_retrieve(lf[273]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[6]);}

/* k11231 in k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a11218 in k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11219(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11219,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[2]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 1544 ##sys#warn */
t3=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[321],t2);}}

/* k11020 in k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11181,a[2]=((C_word)li159),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11217,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1551 module-indirect-exports */
f_10067(t4,((C_word*)t0)[6]);}

/* k11215 in k11020 in k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a11180 in k11020 in k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11181(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11181,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11209,a[2]=t2,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1549 ##sys#macro-environment */
t6=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}}

/* k11207 in a11180 in k11020 in k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* expand.scm: 1550 ##sys#error */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],lf[320],t3);}}

/* k11023 in k11020 in k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11028,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11175,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1553 ##sys#macro-environment */
t4=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k11173 in k11023 in k11020 in k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11179,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1554 ##sys#current-environment */
t3=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k11177 in k11173 in k11023 in k11020 in k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11179,2,t0,t1);}
/* expand.scm: 1552 merge-se */
f_10343(((C_word*)t0)[4],(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],t1,((C_word*)t0)[2]));}

/* k11026 in k11023 in k11020 in k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11031,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 1556 ##sys#mark-imported-symbols */
t3=C_retrieve(lf[215]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}

/* k11029 in k11026 in k11023 in k11020 in k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11034,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11133,a[2]=((C_word*)t0)[2],a[3]=((C_word)li158),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a11132 in k11029 in k11026 in k11023 in k11020 in k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11133(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11133,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11137,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cadr(t2);
/* expand.scm: 1559 merge-se */
f_10343(t3,(C_word)C_a_i_list(&a,2,t4,((C_word*)t0)[2]));}

/* k11135 in a11132 in k11029 in k11026 in k11023 in k11020 in k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11137,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11140,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11163,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11167,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1560 map-se */
f_3584(t5,t1);}

/* k11165 in k11135 in a11132 in k11029 in k11026 in k11023 in k11020 in k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11161 in k11135 in a11132 in k11029 in k11026 in k11023 in k11020 in k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11163,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[319],t2);
/* expand.scm: 1560 dm */
t4=C_retrieve2(lf[7],"dm");
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],t3);}

/* k11138 in k11135 in a11132 in k11029 in k11026 in k11023 in k11020 in k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_car(t2,((C_word*)t0)[2]));}

/* k11032 in k11029 in k11026 in k11023 in k11020 in k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11037,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=f_9473(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11131,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k11129 in k11032 in k11029 in k11026 in k11023 in k11020 in k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11131,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[313],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11123,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11127,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1566 map-se */
f_3584(t4,((C_word*)t0)[2]);}

/* k11125 in k11129 in k11032 in k11029 in k11026 in k11023 in k11020 in k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11121 in k11129 in k11032 in k11029 in k11026 in k11023 in k11020 in k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11123,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[314],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11115,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11119,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1567 map-se */
f_3584(t4,((C_word*)t0)[2]);}

/* k11117 in k11121 in k11129 in k11032 in k11029 in k11026 in k11023 in k11020 in k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11113 in k11121 in k11129 in k11032 in k11029 in k11026 in k11023 in k11020 in k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11115,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[315],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11107,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11111,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1568 map-se */
f_3584(t4,((C_word*)t0)[2]);}

/* k11109 in k11113 in k11121 in k11129 in k11032 in k11029 in k11026 in k11023 in k11020 in k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11105 in k11113 in k11121 in k11129 in k11032 in k11029 in k11026 in k11023 in k11020 in k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11107,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[316],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11099,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11103,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1569 map-se */
f_3584(t4,((C_word*)t0)[2]);}

/* k11101 in k11105 in k11113 in k11121 in k11129 in k11032 in k11029 in k11026 in k11023 in k11020 in k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11097 in k11105 in k11113 in k11121 in k11129 in k11032 in k11029 in k11026 in k11023 in k11020 in k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11099,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[317],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[318],t8);
/* expand.scm: 1563 dm */
t10=C_retrieve2(lf[7],"dm");
((C_proc3)C_retrieve_proc(t10))(3,t10,((C_word*)t0)[2],t9);}

/* k11035 in k11032 in k11029 in k11026 in k11023 in k11020 in k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11040,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[2];
t5=(C_word)C_i_check_structure(t3,lf[220]);
/* ##sys#block-set! */
t6=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t2,t3,C_fix(10),t4);}

/* k11038 in k11035 in k11032 in k11029 in k11026 in k11023 in k11020 in k11017 in k11014 in k11011 in ##sys#finalize-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_11040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=(C_word)C_i_check_structure(t3,lf[220]);
/* ##sys#block-set! */
t6=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t2,t3,C_fix(11),t4);}

/* ##sys#find-export in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10912,5,t0,t1,t2,t3,t4);}
t5=f_9491(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10923,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(C_SCHEME_TRUE,t5);
if(C_truep(t7)){
/* expand.scm: 1489 module-exists-list */
t8=C_retrieve(lf[311]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t3);}
else{
t8=t6;
f_10923(2,t8,t5);}}

/* k10921 in ##sys#find-export in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10923,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10925,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li156),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_10925(t5,((C_word*)t0)[2],t1);}

/* loop in k10921 in ##sys#find-export in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_10925(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10925,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(((C_word*)t0)[4],t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1493 caar */
t7=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t6=(C_word)C_i_cdr(t2);
/* expand.scm: 1496 loop */
t9=t1;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}}}

/* k10972 in loop in k10921 in ##sys#find-export in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10974,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10953,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10970,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1494 cdar */
t5=*((C_word*)lf[208]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}
else{
t4=t3;
f_10953(t4,C_SCHEME_FALSE);}}}

/* k10968 in k10972 in loop in k10921 in ##sys#find-export in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_10953(t2,(C_word)C_i_memq(((C_word*)t0)[2],t1));}

/* k10951 in k10972 in loop in k10921 in ##sys#find-export in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_10953(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1495 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10925(t3,((C_word*)t0)[4],t2);}}

/* ##sys#register-primitive-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10821(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_10821r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_10821r(t0,t1,t2,t3,t4);}}

static void C_ccall f_10821r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10825,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_10825(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_10825(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k10823 in ##sys#register-primitive-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10828,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1466 ##sys#macro-environment */
t3=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k10826 in k10823 in ##sys#register-primitive-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10843,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10867,a[2]=((C_word)li154),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10866 in k10826 in k10823 in ##sys#register-primitive-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10867(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10867,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10877,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10887,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* expand.scm: 1473 ##sys#string-append */
t6=C_retrieve(lf[188]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[310],t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k10885 in a10866 in k10826 in k10823 in ##sys#register-primitive-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1472 ##sys#string->symbol */
t2=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10875 in a10866 in k10826 in k10823 in ##sys#register-primitive-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10880,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1474 ##sys#put! */
t3=C_retrieve(lf[17]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,t1,lf[83],((C_word*)t0)[2]);}

/* k10878 in k10875 in a10866 in k10826 in k10823 in ##sys#register-primitive-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10880,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k10841 in k10826 in k10823 in ##sys#register-primitive-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10847,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10849,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word)li153),tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10848 in k10841 in k10826 in k10823 in ##sys#register-primitive-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10849(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10849,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* expand.scm: 1481 ##sys#error */
t4=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[309],t2,((C_word*)t0)[2]);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k10845 in k10841 in k10826 in k10823 in ##sys#register-primitive-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10847,2,t0,t1);}
t2=f_9662(C_a_i(&a,13),((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve(lf[276]));
t5=C_mutate((C_word*)lf[276]+1 /* (set! module-table ...) */,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* ##sys#register-compiled-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10701(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_10701,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10705,a[2]=t3,a[3]=t1,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10803,a[2]=((C_word)li151),tmp=(C_word)a,a+=3,tmp);
/* map */
t8=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,t5);}

/* a10802 in ##sys#register-compiled-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10803(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10803,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10815,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
/* expand.scm: 1439 ##sys#er-transformer */
t6=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k10813 in a10802 in ##sys#register-compiled-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10815,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[2],C_SCHEME_FALSE,t1));}

/* k10703 in ##sys#register-compiled-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10705,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10708,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10771,a[2]=((C_word)li150),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10770 in k10703 in ##sys#register-compiled-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10771(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10771,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cadr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10793,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_caddr(t2);
/* expand.scm: 1444 ##sys#er-transformer */
t8=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k10791 in a10770 in k10703 in ##sys#register-compiled-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10793,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10706 in k10703 in ##sys#register-compiled-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10708,2,t0,t1);}
t2=f_9662(C_a_i(&a,13),((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10714,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10765,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1449 ##sys#macro-environment */
t5=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k10763 in k10706 in k10703 in ##sys#register-compiled-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10769,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1450 ##sys#current-environment */
t3=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k10767 in k10763 in k10706 in k10703 in ##sys#register-compiled-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10769,2,t0,t1);}
/* expand.scm: 1448 merge-se */
f_10343(((C_word*)t0)[6],(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k10712 in k10706 in k10703 in ##sys#register-compiled-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10717,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1452 ##sys#mark-imported-symbols */
t3=C_retrieve(lf[215]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k10715 in k10712 in k10706 in k10703 in ##sys#register-compiled-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10720,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10753,a[2]=((C_word*)t0)[4],a[3]=((C_word)li149),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10752 in k10715 in k10712 in k10706 in k10703 in ##sys#register-compiled-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10753(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10753,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_car(t3,((C_word*)t0)[2]));}

/* k10718 in k10715 in k10712 in k10706 in k10703 in ##sys#register-compiled-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10723,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10733,a[2]=((C_word*)t0)[3],a[3]=((C_word)li148),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10732 in k10718 in k10715 in k10712 in k10706 in k10703 in ##sys#register-compiled-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10733(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10733,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cdr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_set_car(t4,((C_word*)t0)[2]));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k10721 in k10718 in k10715 in k10712 in k10706 in k10703 in ##sys#register-compiled-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10723,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[276]));
t4=C_mutate((C_word*)lf[276]+1 /* (set! module-table ...) */,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[3]);}

/* ##sys#compiled-module-registration in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10415(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10415,3,t0,t1,t2);}
t3=f_9509(t2);
t4=f_9473(t2);
t5=f_9581(t2);
t6=f_9599(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10435,a[2]=t6,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10699,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t9=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t5,C_SCHEME_END_OF_LIST);}
else{
t8=t7;
f_10435(t8,C_SCHEME_END_OF_LIST);}}

/* k10697 in ##sys#compiled-module-registration in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10699,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[278],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[95],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[307],t5);
t7=((C_word*)t0)[2];
f_10435(t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}

/* k10433 in ##sys#compiled-module-registration in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_10435(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10435,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10439,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10443,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10669,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t4=t3;
f_10443(t4,C_SCHEME_END_OF_LIST);}}

/* k10667 in k10433 in ##sys#compiled-module-registration in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10669,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[278],t1);
t3=((C_word*)t0)[2];
f_10443(t3,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}

/* k10441 in k10433 in ##sys#compiled-module-registration in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_10443(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10443,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10447,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10451,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10651,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=f_9617(((C_word*)t0)[4]);
/* map */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,C_retrieve(lf[22]),t5);}

/* k10649 in k10441 in k10433 in ##sys#compiled-module-registration in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1417 reverse */
t2=*((C_word*)lf[92]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10449 in k10441 in k10433 in ##sys#compiled-module-registration in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10451,2,t0,t1);}
t2=f_9473(((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[95],t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10560,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10564,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10566,a[2]=((C_word)li146),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10639,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1425 module-indirect-exports */
f_10067(t8,((C_word*)t0)[5]);}

/* k10637 in k10449 in k10441 in k10433 in ##sys#compiled-module-registration in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a10565 in k10449 in k10441 in k10433 in ##sys#compiled-module-registration in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10566(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[33],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10566,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[95],t7));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[95],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[95],t7);
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t8,t10);
t12=(C_word)C_a_i_cons(&a,2,t6,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,lf[164],t12));}}

/* k10562 in k10449 in k10441 in k10433 in ##sys#compiled-module-registration in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k10558 in k10449 in k10441 in k10433 in ##sys#compiled-module-registration in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10560,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[164],t1);
t3=f_9635(((C_word*)t0)[7]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[95],t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10495,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10499,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li145),tmp=(C_word)a,a+=5,tmp);
t9=f_9653(((C_word*)t0)[7]);
/* map */
t10=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}

/* a10500 in k10558 in k10449 in k10441 in k10433 in ##sys#compiled-module-registration in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10501(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10501,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_assq(t3,((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10511,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=t5;
f_10511(2,t6,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 1432 error */
t6=*((C_word*)lf[277]+1);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,lf[220],lf[306],t3,((C_word*)t0)[2]);}}

/* k10509 in a10500 in k10558 in k10449 in k10441 in k10433 in ##sys#compiled-module-registration in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10511,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[95],t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t4,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[305],t7));}

/* k10497 in k10558 in k10449 in k10441 in k10433 in ##sys#compiled-module-registration in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k10493 in k10558 in k10449 in k10441 in k10433 in ##sys#compiled-module-registration in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10495,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[164],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[304],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t9=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,((C_word*)t0)[3],((C_word*)t0)[2],t8);}

/* k10445 in k10441 in k10433 in ##sys#compiled-module-registration in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10437 in k10433 in ##sys#compiled-module-registration in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* merge-se in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_10343(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10343,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10347,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t3,*((C_word*)lf[68]+1),t2);}

/* k10345 in merge-se in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10350,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_length(((C_word*)t0)[2]);
t4=(C_word)C_i_length(t1);
/* expand.scm: 1401 dm */
t5=C_retrieve2(lf[7],"dm");
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,lf[301],t3,lf[302],t4);}

/* k10348 in k10345 in merge-se in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10353,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10362,a[2]=t4,a[3]=((C_word)li143),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_10362(t6,t2,((C_word*)t0)[2]);}

/* loop in k10348 in k10345 in merge-se in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_10362(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10362,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10401,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1405 caar */
t4=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k10399 in loop in k10348 in k10345 in merge-se in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10401,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_assq(t1,t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1405 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_10362(t4,((C_word*)t0)[2],t3);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10393,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1406 loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_10362(t6,t4,t5);}}

/* k10391 in k10399 in loop in k10348 in k10345 in merge-se in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10393,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10351 in k10348 in k10345 in merge-se in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10356,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_length(t1);
/* expand.scm: 1407 dm */
t4=C_retrieve2(lf[7],"dm");
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[300],t3);}

/* k10354 in k10351 in k10348 in k10345 in merge-se in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* module-indirect-exports in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_10067(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10067,NULL,2,t1,t2);}
t3=f_9491(t2);
t4=f_9473(t2);
t5=f_9509(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10125,a[2]=t4,a[3]=((C_word)li139),tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_SCHEME_TRUE,t3);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_END_OF_LIST);}
else{
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10148,a[2]=t4,a[3]=t5,a[4]=t6,a[5]=t9,a[6]=((C_word)li141),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_10148(t11,t1,t3);}}

/* loop in module-indirect-exports in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_10148(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10148,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_cdr(t2);
/* expand.scm: 1374 loop */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10175,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1376 cdar */
t5=*((C_word*)lf[208]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}}

/* k10173 in loop in module-indirect-exports in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10175,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10177,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li140),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_10177(t5,((C_word*)t0)[2],t1);}

/* loop2 in k10173 in loop in module-indirect-exports in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_10177(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10177,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* expand.scm: 1377 loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_10148(t4,t1,t3);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10337,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1378 ##sys#macro-environment */
t5=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k10335 in loop2 in k10173 in loop in module-indirect-exports in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10337,2,t0,t1);}
if(C_truep((C_word)C_i_assq(((C_word*)t0)[8],t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10200,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
/* expand.scm: 1379 warn */
t4=((C_word*)t0)[4];
f_10125(t4,t2,lf[296],t3);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_i_cdr(t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10243,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_10243(2,t7,t5);}
else{
t7=(C_word)C_i_car(((C_word*)t0)[7]);
/* expand.scm: 1386 ##sys#module-rename */
t8=C_retrieve(lf[73]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,t7,((C_word*)t0)[2]);}}
else{
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10325,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1388 ##sys#current-environment */
t6=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}}}

/* k10323 in k10335 in loop2 in k10173 in loop in module-indirect-exports in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10325,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10273,a[2]=t6,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* expand.scm: 1391 loop2 */
t9=((C_word*)((C_word*)t0)[3])[1];
f_10177(t9,t7,t8);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10288,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
/* expand.scm: 1393 warn */
t6=((C_word*)t0)[2];
f_10125(t6,t4,lf[297],t5);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10306,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* expand.scm: 1396 warn */
t5=((C_word*)t0)[2];
f_10125(t5,t3,lf[298],t4);}}

/* k10304 in k10323 in k10335 in loop2 in k10173 in loop in module-indirect-exports in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1397 loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10177(t3,((C_word*)t0)[2],t2);}

/* k10286 in k10323 in k10335 in loop2 in k10173 in loop in module-indirect-exports in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1394 loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10177(t3,((C_word*)t0)[2],t2);}

/* k10271 in k10323 in k10335 in loop2 in k10173 in loop in module-indirect-exports in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10273,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10241 in k10335 in loop2 in k10173 in loop in module-indirect-exports in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10243,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10228,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1387 loop2 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_10177(t5,t3,t4);}

/* k10226 in k10241 in k10335 in loop2 in k10173 in loop in module-indirect-exports in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10228,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10198 in k10335 in loop2 in k10173 in loop in module-indirect-exports in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1380 loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10177(t3,((C_word*)t0)[2],t2);}

/* warn in module-indirect-exports in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_10125(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10125,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10133,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10137,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1368 symbol->string */
t6=*((C_word*)lf[146]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k10135 in warn in module-indirect-exports in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1368 string-append */
t2=*((C_word*)lf[42]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[294],t1,lf[295]);}

/* k10131 in warn in module-indirect-exports in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1367 ##sys#warn */
t2=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##sys#mark-imported-symbols in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10008(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10008,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10014,a[2]=((C_word)li137),tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a10013 in ##sys#mark-imported-symbols in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10014(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10014,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10021,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_eqp(t5,t6);
t8=t3;
f_10021(t8,(C_word)C_i_not(t7));}
else{
t5=t3;
f_10021(t5,C_SCHEME_FALSE);}}

/* k10019 in a10013 in ##sys#mark-imported-symbols in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_10021(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10021,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10024,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[292],t4);
/* expand.scm: 1352 dm */
t6=C_retrieve2(lf[7],"dm");
((C_proc3)C_retrieve_proc(t6))(3,t6,t2,t5);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k10022 in k10019 in a10013 in ##sys#mark-imported-symbols in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_10024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1353 ##sys#put! */
t3=C_retrieve(lf[17]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],t2,lf[85],C_SCHEME_TRUE);}

/* ##sys#register-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9940(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+69)){
C_save_and_reclaim((void*)tr4r,(void*)f_9940r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_9940r(t0,t1,t2,t3,t4);}}

static void C_ccall f_9940r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(69);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9942,a[2]=t3,a[3]=t2,a[4]=((C_word)li134),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9955,a[2]=t5,a[3]=((C_word)li135),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9960,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-vexports29582977 */
t8=t1;
((C_proc2)C_retrieve_proc(t8))(2,t8,f_9960(C_a_i(&a,19),t7));}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-sexports29592973 */
t10=t1;
((C_proc2)C_retrieve_proc(t10))(2,t10,f_9955(C_a_i(&a,19),t6,t8));}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body29562965 */
t12=t1;
((C_proc2)C_retrieve_proc(t12))(2,t12,f_9942(C_a_i(&a,19),t5,t8,t10));}
else{
/* ##sys#error */
t12=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-vexports2958 in ##sys#register-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static C_word C_fcall f_9960(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_stack_check;
return(f_9955(C_a_i(&a,19),((C_word*)t0)[2],C_SCHEME_END_OF_LIST));}

/* def-sexports2959 in ##sys#register-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static C_word C_fcall f_9955(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return(f_9942(C_a_i(&a,19),((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST));}

/* body2956 in ##sys#register-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static C_word C_fcall f_9942(C_word *a,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t3=f_9662(C_a_i(&a,13),((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_retrieve(lf[276]));
t6=C_mutate((C_word*)lf[276]+1 /* (set! module-table ...) */,t5);
return(t3);}

/* ##sys#register-undefined in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9918(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9918,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9925,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1339 module-undefined-list */
t5=C_retrieve(lf[273]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k9923 in ##sys#register-undefined in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9925,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* expand.scm: 1341 set-module-undefined-list! */
t3=C_retrieve(lf[272]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* ##sys#register-syntax-export in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9841(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9841,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=f_9491(t3);
t6=(C_word)C_eqp(C_SCHEME_TRUE,t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9851,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t8=t7;
f_9851(2,t8,t6);}
else{
/* expand.scm: 1321 ##sys#find-export */
t8=C_retrieve(lf[287]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,t2,t3,C_SCHEME_TRUE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k9849 in ##sys#register-syntax-export in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9854,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1322 module-undefined-list */
t3=C_retrieve(lf[273]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}

/* k9852 in k9849 in ##sys#register-syntax-export in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9854,2,t0,t1);}
t2=f_9473(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9860,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[5],t1))){
/* expand.scm: 1325 ##sys#warn */
t4=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[290],((C_word*)t0)[5]);}
else{
t4=t3;
f_9860(2,t4,C_SCHEME_UNDEFINED);}}

/* k9858 in k9852 in k9849 in ##sys#register-syntax-export in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9863,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9899,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1326 ##sys#current-environment */
t4=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k9897 in k9858 in k9852 in k9849 in ##sys#register-syntax-export in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9903,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1326 ##sys#macro-environment */
t3=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k9901 in k9897 in k9858 in k9852 in k9849 in ##sys#register-syntax-export in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1326 check-for-redef */
f_9731(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9861 in k9858 in k9852 in k9849 in ##sys#register-syntax-export in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1327 dm */
t3=C_retrieve2(lf[7],"dm");
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[289],((C_word*)t0)[5]);}

/* k9864 in k9861 in k9858 in k9852 in k9849 in ##sys#register-syntax-export in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9869,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[2]);
t4=f_9509(((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
/* expand.scm: 1329 set-module-defined-list! */
f_9500(t2,((C_word*)t0)[6],t5);}
else{
t3=t2;
f_9869(2,t3,C_SCHEME_UNDEFINED);}}

/* k9867 in k9864 in k9861 in k9858 in k9852 in k9849 in ##sys#register-syntax-export in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9869,2,t0,t1);}
t2=f_9545(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[4];
t6=(C_word)C_i_check_structure(t5,lf[220]);
/* ##sys#block-set! */
t7=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t4,t5,C_fix(5),t3);}

/* ##sys#register-export in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9752,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=f_9491(t3);
t5=(C_word)C_eqp(C_SCHEME_TRUE,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9762,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_9762(2,t7,t5);}
else{
/* expand.scm: 1302 ##sys#find-export */
t7=C_retrieve(lf[287]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,t2,t3,C_SCHEME_TRUE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k9760 in ##sys#register-export in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9765,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1303 module-undefined-list */
t3=C_retrieve(lf[273]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k9763 in k9760 in ##sys#register-export in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9768,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9828,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=f_9473(((C_word*)t0)[3]);
/* expand.scm: 1305 ##sys#module-rename */
t5=C_retrieve(lf[73]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[4],t4);}

/* k9826 in k9763 in k9760 in ##sys#register-export in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1304 ##sys#toplevel-definition-hook */
t2=C_retrieve(lf[280]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k9766 in k9763 in k9760 in ##sys#register-export in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9768,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9771,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9824,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1308 ##sys#delq */
t4=C_retrieve(lf[207]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
t3=t2;
f_9771(2,t3,C_SCHEME_UNDEFINED);}}

/* k9822 in k9766 in k9763 in k9760 in ##sys#register-export in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1308 set-module-undefined-list! */
t2=C_retrieve(lf[272]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9769 in k9766 in k9763 in k9760 in ##sys#register-export in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9774,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9810,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1309 ##sys#current-environment */
t4=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k9808 in k9769 in k9766 in k9763 in k9760 in ##sys#register-export in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9814,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1309 ##sys#macro-environment */
t3=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k9812 in k9808 in k9769 in k9766 in k9763 in k9760 in ##sys#register-export in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1309 check-for-redef */
f_9731(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9772 in k9769 in k9766 in k9763 in k9760 in ##sys#register-export in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9777,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=f_9527(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
t6=(C_word)C_i_check_structure(t5,lf[220]);
/* ##sys#block-set! */
t7=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t2,t5,C_fix(4),t4);}

/* k9775 in k9772 in k9769 in k9766 in k9763 in k9760 in ##sys#register-export in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9777,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9783,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1312 dm */
t3=C_retrieve2(lf[7],"dm");
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[286],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k9781 in k9775 in k9772 in k9769 in k9766 in k9763 in k9760 in ##sys#register-export in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9783,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_FALSE);
t3=f_9509(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
/* expand.scm: 1313 set-module-defined-list! */
f_9500(((C_word*)t0)[2],((C_word*)t0)[3],t4);}

/* check-for-redef in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_9731(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9731,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_assq(t2,t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9738,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
/* expand.scm: 1295 ##sys#warn */
t7=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,lf[284],t2);}
else{
t7=t6;
f_9738(2,t7,C_SCHEME_FALSE);}}

/* k9736 in check-for-redef in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]))){
/* expand.scm: 1297 ##sys#warn */
t2=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[283],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#register-meta-expression in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9711(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9711,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9715,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1290 ##sys#current-module */
t4=C_retrieve(lf[80]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k9713 in ##sys#register-meta-expression in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9715,2,t0,t1);}
if(C_truep(t1)){
t2=f_9617(t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
t5=t1;
t6=(C_word)C_i_check_structure(t5,lf[220]);
/* ##sys#block-set! */
t7=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t4,t5,C_fix(9),t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#toplevel-definition-hook in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9708,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}

/* ##sys#find-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9668(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_9668r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_9668r(t0,t1,t2,t3);}}

static void C_ccall f_9668r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9672,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_9672(2,t5,C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_9672(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k9670 in ##sys#find-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[3],C_retrieve(lf[276]));
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cdr(t2));}
else{
if(C_truep(t1)){
/* expand.scm: 1284 error */
t3=*((C_word*)lf[277]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[278],lf[279],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* make-module in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static C_word C_fcall f_9662(C_word *a,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_stack_check;
return((C_word)C_a_i_record(&a,12,lf[220],t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t3,t4));}

/* module-sexports in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static C_word C_fcall f_9653(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(11)));}

/* module-vexports in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static C_word C_fcall f_9635(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(10)));}

/* module-meta-expressions in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static C_word C_fcall f_9617(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(9)));}

/* module-meta-import-forms in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static C_word C_fcall f_9599(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(8)));}

/* module-import-forms in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static C_word C_fcall f_9581(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(7)));}

/* module-undefined-list in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9563(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9563,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[220]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(6)));}

/* set-module-undefined-list! in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9554(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9554,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t5=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* module-defined-syntax-list in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static C_word C_fcall f_9545(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(5)));}

/* module-exist-list in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static C_word C_fcall f_9527(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(4)));}

/* module-defined-list in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static C_word C_fcall f_9509(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(3)));}

/* set-module-defined-list! in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_9500(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9500,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t5=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* module-export-list in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static C_word C_fcall f_9491(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(2)));}

/* module-name in k9457 in k9453 in k9449 in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static C_word C_fcall f_9473(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(1)));}

/* ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7818(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word ab[151],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_7818,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_SCHEME_UNDEFINED;
t24=(*a=C_VECTOR_TYPE|1,a[1]=t23,tmp=(C_word)a,a+=2,tmp);
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_UNDEFINED;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_SCHEME_UNDEFINED;
t30=(*a=C_VECTOR_TYPE|1,a[1]=t29,tmp=(C_word)a,a+=2,tmp);
t31=C_SCHEME_UNDEFINED;
t32=(*a=C_VECTOR_TYPE|1,a[1]=t31,tmp=(C_word)a,a+=2,tmp);
t33=C_SCHEME_UNDEFINED;
t34=(*a=C_VECTOR_TYPE|1,a[1]=t33,tmp=(C_word)a,a+=2,tmp);
t35=C_SCHEME_UNDEFINED;
t36=(*a=C_VECTOR_TYPE|1,a[1]=t35,tmp=(C_word)a,a+=2,tmp);
t37=C_SCHEME_UNDEFINED;
t38=(*a=C_VECTOR_TYPE|1,a[1]=t37,tmp=(C_word)a,a+=2,tmp);
t39=C_SCHEME_UNDEFINED;
t40=(*a=C_VECTOR_TYPE|1,a[1]=t39,tmp=(C_word)a,a+=2,tmp);
t41=C_SCHEME_UNDEFINED;
t42=(*a=C_VECTOR_TYPE|1,a[1]=t41,tmp=(C_word)a,a+=2,tmp);
t43=C_SCHEME_UNDEFINED;
t44=(*a=C_VECTOR_TYPE|1,a[1]=t43,tmp=(C_word)a,a+=2,tmp);
t45=C_SCHEME_UNDEFINED;
t46=(*a=C_VECTOR_TYPE|1,a[1]=t45,tmp=(C_word)a,a+=2,tmp);
t47=C_SCHEME_UNDEFINED;
t48=(*a=C_VECTOR_TYPE|1,a[1]=t47,tmp=(C_word)a,a+=2,tmp);
t49=C_SCHEME_UNDEFINED;
t50=(*a=C_VECTOR_TYPE|1,a[1]=t49,tmp=(C_word)a,a+=2,tmp);
t51=C_SCHEME_UNDEFINED;
t52=(*a=C_VECTOR_TYPE|1,a[1]=t51,tmp=(C_word)a,a+=2,tmp);
t53=C_SCHEME_UNDEFINED;
t54=(*a=C_VECTOR_TYPE|1,a[1]=t53,tmp=(C_word)a,a+=2,tmp);
t55=C_SCHEME_UNDEFINED;
t56=(*a=C_VECTOR_TYPE|1,a[1]=t55,tmp=(C_word)a,a+=2,tmp);
t57=C_SCHEME_UNDEFINED;
t58=(*a=C_VECTOR_TYPE|1,a[1]=t57,tmp=(C_word)a,a+=2,tmp);
t59=C_SCHEME_UNDEFINED;
t60=(*a=C_VECTOR_TYPE|1,a[1]=t59,tmp=(C_word)a,a+=2,tmp);
t61=C_SCHEME_UNDEFINED;
t62=(*a=C_VECTOR_TYPE|1,a[1]=t61,tmp=(C_word)a,a+=2,tmp);
t63=C_SCHEME_UNDEFINED;
t64=(*a=C_VECTOR_TYPE|1,a[1]=t63,tmp=(C_word)a,a+=2,tmp);
t65=C_SCHEME_UNDEFINED;
t66=(*a=C_VECTOR_TYPE|1,a[1]=t65,tmp=(C_word)a,a+=2,tmp);
t67=C_SCHEME_UNDEFINED;
t68=(*a=C_VECTOR_TYPE|1,a[1]=t67,tmp=(C_word)a,a+=2,tmp);
t69=C_SCHEME_UNDEFINED;
t70=(*a=C_VECTOR_TYPE|1,a[1]=t69,tmp=(C_word)a,a+=2,tmp);
t71=C_SCHEME_UNDEFINED;
t72=(*a=C_VECTOR_TYPE|1,a[1]=t71,tmp=(C_word)a,a+=2,tmp);
t73=C_SCHEME_UNDEFINED;
t74=(*a=C_VECTOR_TYPE|1,a[1]=t73,tmp=(C_word)a,a+=2,tmp);
t75=C_SCHEME_UNDEFINED;
t76=(*a=C_VECTOR_TYPE|1,a[1]=t75,tmp=(C_word)a,a+=2,tmp);
t77=C_SCHEME_UNDEFINED;
t78=(*a=C_VECTOR_TYPE|1,a[1]=t77,tmp=(C_word)a,a+=2,tmp);
t79=C_SCHEME_UNDEFINED;
t80=(*a=C_VECTOR_TYPE|1,a[1]=t79,tmp=(C_word)a,a+=2,tmp);
t81=C_SCHEME_UNDEFINED;
t82=(*a=C_VECTOR_TYPE|1,a[1]=t81,tmp=(C_word)a,a+=2,tmp);
t83=C_SCHEME_UNDEFINED;
t84=(*a=C_VECTOR_TYPE|1,a[1]=t83,tmp=(C_word)a,a+=2,tmp);
t85=C_SCHEME_UNDEFINED;
t86=(*a=C_VECTOR_TYPE|1,a[1]=t85,tmp=(C_word)a,a+=2,tmp);
t87=C_SCHEME_UNDEFINED;
t88=(*a=C_VECTOR_TYPE|1,a[1]=t87,tmp=(C_word)a,a+=2,tmp);
t89=C_SCHEME_UNDEFINED;
t90=(*a=C_VECTOR_TYPE|1,a[1]=t89,tmp=(C_word)a,a+=2,tmp);
t91=C_SCHEME_UNDEFINED;
t92=(*a=C_VECTOR_TYPE|1,a[1]=t91,tmp=(C_word)a,a+=2,tmp);
t93=C_SCHEME_UNDEFINED;
t94=(*a=C_VECTOR_TYPE|1,a[1]=t93,tmp=(C_word)a,a+=2,tmp);
t95=C_SCHEME_UNDEFINED;
t96=(*a=C_VECTOR_TYPE|1,a[1]=t95,tmp=(C_word)a,a+=2,tmp);
t97=C_SCHEME_UNDEFINED;
t98=(*a=C_VECTOR_TYPE|1,a[1]=t97,tmp=(C_word)a,a+=2,tmp);
t99=C_SCHEME_UNDEFINED;
t100=(*a=C_VECTOR_TYPE|1,a[1]=t99,tmp=(C_word)a,a+=2,tmp);
t101=C_SCHEME_UNDEFINED;
t102=(*a=C_VECTOR_TYPE|1,a[1]=t101,tmp=(C_word)a,a+=2,tmp);
t103=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7825,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=t98,a[6]=t100,a[7]=t94,a[8]=t102,a[9]=t2,a[10]=t96,a[11]=t86,a[12]=t84,a[13]=t4,a[14]=t82,a[15]=t88,a[16]=t92,a[17]=t90,a[18]=t80,a[19]=t78,a[20]=t76,a[21]=t74,a[22]=t72,a[23]=t70,a[24]=t68,a[25]=t66,a[26]=t64,a[27]=t62,a[28]=t60,a[29]=t58,a[30]=t56,a[31]=t54,a[32]=t52,a[33]=t50,a[34]=t48,a[35]=t46,a[36]=t44,a[37]=t42,a[38]=t40,a[39]=t38,a[40]=t36,a[41]=t34,a[42]=t32,a[43]=t30,a[44]=t28,a[45]=t26,a[46]=t24,a[47]=t22,a[48]=t20,a[49]=t18,a[50]=t16,a[51]=t14,a[52]=t12,a[53]=t10,a[54]=t8,tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t104=t5;
((C_proc3)C_retrieve_proc(t104))(3,t104,t103,lf[265]);}

/* k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7825,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[53])+1,lf[231]);
t4=C_mutate(((C_word *)((C_word*)t0)[52])+1,lf[232]);
t5=C_mutate(((C_word *)((C_word*)t0)[51])+1,lf[233]);
t6=C_mutate(((C_word *)((C_word*)t0)[50])+1,lf[234]);
t7=C_mutate(((C_word *)((C_word*)t0)[49])+1,lf[235]);
t8=C_mutate(((C_word *)((C_word*)t0)[48])+1,lf[236]);
t9=C_mutate(((C_word *)((C_word*)t0)[47])+1,lf[237]);
t10=C_mutate(((C_word *)((C_word*)t0)[46])+1,lf[238]);
t11=C_mutate(((C_word *)((C_word*)t0)[45])+1,lf[239]);
t12=C_mutate(((C_word *)((C_word*)t0)[44])+1,lf[240]);
t13=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[47],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[48],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[45],a[13]=((C_word*)t0)[50],a[14]=((C_word*)t0)[49],a[15]=((C_word*)t0)[44],a[16]=((C_word*)t0)[46],a[17]=((C_word*)t0)[51],a[18]=((C_word*)t0)[10],a[19]=((C_word*)t0)[11],a[20]=((C_word*)t0)[53],a[21]=((C_word*)t0)[12],a[22]=((C_word*)t0)[13],a[23]=((C_word*)t0)[14],a[24]=((C_word*)t0)[15],a[25]=((C_word*)t0)[16],a[26]=((C_word*)t0)[17],a[27]=((C_word*)t0)[54],a[28]=((C_word*)t0)[18],a[29]=((C_word*)t0)[52],a[30]=((C_word*)t0)[19],a[31]=((C_word*)t0)[20],a[32]=((C_word*)t0)[21],a[33]=((C_word*)t0)[22],a[34]=((C_word*)t0)[23],a[35]=((C_word*)t0)[24],a[36]=((C_word*)t0)[25],a[37]=((C_word*)t0)[26],a[38]=((C_word*)t0)[27],a[39]=((C_word*)t0)[28],a[40]=((C_word*)t0)[29],a[41]=((C_word*)t0)[30],a[42]=((C_word*)t0)[31],a[43]=((C_word*)t0)[32],a[44]=((C_word*)t0)[33],a[45]=((C_word*)t0)[34],a[46]=((C_word*)t0)[35],a[47]=((C_word*)t0)[36],a[48]=((C_word*)t0)[37],a[49]=((C_word*)t0)[38],a[50]=((C_word*)t0)[39],a[51]=((C_word*)t0)[40],a[52]=((C_word*)t0)[41],a[53]=((C_word*)t0)[42],a[54]=((C_word*)t0)[43],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t14=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,lf[264]);}

/* k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7839,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7843,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[54],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[263]);}

/* k7841 in k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7843,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7847,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[54],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[262]);}

/* k7845 in k7841 in k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7847,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[53])+1,lf[241]);
t4=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[53],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[54],a[32]=((C_word*)t0)[30],a[33]=((C_word*)t0)[31],a[34]=((C_word*)t0)[32],a[35]=((C_word*)t0)[33],a[36]=((C_word*)t0)[34],a[37]=((C_word*)t0)[35],a[38]=((C_word*)t0)[36],a[39]=((C_word*)t0)[37],a[40]=((C_word*)t0)[38],a[41]=((C_word*)t0)[39],a[42]=((C_word*)t0)[40],a[43]=((C_word*)t0)[41],a[44]=((C_word*)t0)[42],a[45]=((C_word*)t0)[43],a[46]=((C_word*)t0)[44],a[47]=((C_word*)t0)[45],a[48]=((C_word*)t0)[46],a[49]=((C_word*)t0)[47],a[50]=((C_word*)t0)[48],a[51]=((C_word*)t0)[49],a[52]=((C_word*)t0)[50],a[53]=((C_word*)t0)[51],a[54]=((C_word*)t0)[52],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[261]);}

/* k7850 in k7845 in k7841 in k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7852,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[53])+1,lf[242]);
t4=C_mutate(((C_word *)((C_word*)t0)[52])+1,lf[243]);
t5=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[52],a[22]=((C_word*)t0)[53],a[23]=((C_word*)t0)[21],a[24]=((C_word*)t0)[22],a[25]=((C_word*)t0)[23],a[26]=((C_word*)t0)[24],a[27]=((C_word*)t0)[25],a[28]=((C_word*)t0)[26],a[29]=((C_word*)t0)[27],a[30]=((C_word*)t0)[28],a[31]=((C_word*)t0)[29],a[32]=((C_word*)t0)[30],a[33]=((C_word*)t0)[54],a[34]=((C_word*)t0)[31],a[35]=((C_word*)t0)[32],a[36]=((C_word*)t0)[33],a[37]=((C_word*)t0)[34],a[38]=((C_word*)t0)[35],a[39]=((C_word*)t0)[36],a[40]=((C_word*)t0)[37],a[41]=((C_word*)t0)[38],a[42]=((C_word*)t0)[39],a[43]=((C_word*)t0)[40],a[44]=((C_word*)t0)[41],a[45]=((C_word*)t0)[42],a[46]=((C_word*)t0)[43],a[47]=((C_word*)t0)[44],a[48]=((C_word*)t0)[45],a[49]=((C_word*)t0)[46],a[50]=((C_word*)t0)[47],a[51]=((C_word*)t0)[48],a[52]=((C_word*)t0)[49],a[53]=((C_word*)t0)[50],a[54]=((C_word*)t0)[51],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[260]);}

/* k7856 in k7850 in k7845 in k7841 in k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7858,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[54],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[259]);}

/* k7860 in k7856 in k7850 in k7845 in k7841 in k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7862,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[54],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[126]);}

/* k7864 in k7860 in k7856 in k7850 in k7845 in k7841 in k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7866,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7870,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[54],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[58]);}

/* k7868 in k7864 in k7860 in k7856 in k7850 in k7845 in k7841 in k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7870,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[54],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[113]);}

/* k7872 in k7868 in k7864 in k7860 in k7856 in k7850 in k7845 in k7841 in k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7874,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[53])+1,lf[244]);
t4=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[53],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[54],a[34]=((C_word*)t0)[32],a[35]=((C_word*)t0)[33],a[36]=((C_word*)t0)[34],a[37]=((C_word*)t0)[35],a[38]=((C_word*)t0)[36],a[39]=((C_word*)t0)[37],a[40]=((C_word*)t0)[38],a[41]=((C_word*)t0)[39],a[42]=((C_word*)t0)[40],a[43]=((C_word*)t0)[41],a[44]=((C_word*)t0)[42],a[45]=((C_word*)t0)[43],a[46]=((C_word*)t0)[44],a[47]=((C_word*)t0)[45],a[48]=((C_word*)t0)[46],a[49]=((C_word*)t0)[47],a[50]=((C_word*)t0)[48],a[51]=((C_word*)t0)[49],a[52]=((C_word*)t0)[50],a[53]=((C_word*)t0)[51],a[54]=((C_word*)t0)[52],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[164]);}

/* k7877 in k7872 in k7868 in k7864 in k7860 in k7856 in k7850 in k7845 in k7841 in k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],a[53]=((C_word*)t0)[53],a[54]=((C_word*)t0)[54],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[258]);}

/* k7881 in k7877 in k7872 in k7868 in k7864 in k7860 in k7856 in k7850 in k7845 in k7841 in k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7883,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[53])+1,lf[21]);
t4=C_mutate(((C_word *)((C_word*)t0)[52])+1,lf[245]);
t5=C_mutate(((C_word *)((C_word*)t0)[51])+1,lf[246]);
t6=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7890,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[52],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[53],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[54],a[23]=((C_word*)t0)[51],a[24]=((C_word*)t0)[20],a[25]=((C_word*)t0)[21],a[26]=((C_word*)t0)[22],a[27]=((C_word*)t0)[23],a[28]=((C_word*)t0)[24],a[29]=((C_word*)t0)[25],a[30]=((C_word*)t0)[26],a[31]=((C_word*)t0)[27],a[32]=((C_word*)t0)[28],a[33]=((C_word*)t0)[29],a[34]=((C_word*)t0)[30],a[35]=((C_word*)t0)[31],a[36]=((C_word*)t0)[32],a[37]=((C_word*)t0)[33],a[38]=((C_word*)t0)[34],a[39]=((C_word*)t0)[35],a[40]=((C_word*)t0)[36],a[41]=((C_word*)t0)[37],a[42]=((C_word*)t0)[38],a[43]=((C_word*)t0)[39],a[44]=((C_word*)t0)[40],a[45]=((C_word*)t0)[41],a[46]=((C_word*)t0)[42],a[47]=((C_word*)t0)[43],a[48]=((C_word*)t0)[44],a[49]=((C_word*)t0)[45],a[50]=((C_word*)t0)[46],a[51]=((C_word*)t0)[47],a[52]=((C_word*)t0)[48],a[53]=((C_word*)t0)[49],a[54]=((C_word*)t0)[50],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[257]);}

/* k7888 in k7881 in k7877 in k7872 in k7868 in k7864 in k7860 in k7856 in k7850 in k7845 in k7841 in k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7890,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[53])+1,lf[247]);
t4=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[54],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[53],a[33]=((C_word*)t0)[31],a[34]=((C_word*)t0)[32],a[35]=((C_word*)t0)[33],a[36]=((C_word*)t0)[34],a[37]=((C_word*)t0)[35],a[38]=((C_word*)t0)[36],a[39]=((C_word*)t0)[37],a[40]=((C_word*)t0)[38],a[41]=((C_word*)t0)[39],a[42]=((C_word*)t0)[40],a[43]=((C_word*)t0)[41],a[44]=((C_word*)t0)[42],a[45]=((C_word*)t0)[43],a[46]=((C_word*)t0)[44],a[47]=((C_word*)t0)[45],a[48]=((C_word*)t0)[46],a[49]=((C_word*)t0)[47],a[50]=((C_word*)t0)[48],a[51]=((C_word*)t0)[49],a[52]=((C_word*)t0)[50],a[53]=((C_word*)t0)[51],a[54]=((C_word*)t0)[52],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[95]);}

/* k7893 in k7888 in k7881 in k7877 in k7872 in k7868 in k7864 in k7860 in k7856 in k7850 in k7845 in k7841 in k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7895,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[54],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[227]);}

/* k7897 in k7893 in k7888 in k7881 in k7877 in k7872 in k7868 in k7864 in k7860 in k7856 in k7850 in k7845 in k7841 in k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7899,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7903,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[54],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[256]);}

/* k7901 in k7897 in k7893 in k7888 in k7881 in k7877 in k7872 in k7868 in k7864 in k7860 in k7856 in k7850 in k7845 in k7841 in k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[54],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7903,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=(*a=C_CLOSURE_TYPE|53,a[1]=(C_word)f_7907,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],a[36]=((C_word*)t0)[37],a[37]=((C_word*)t0)[38],a[38]=((C_word*)t0)[39],a[39]=((C_word*)t0)[40],a[40]=((C_word*)t0)[41],a[41]=((C_word*)t0)[42],a[42]=((C_word*)t0)[43],a[43]=((C_word*)t0)[44],a[44]=((C_word*)t0)[45],a[45]=((C_word*)t0)[46],a[46]=((C_word*)t0)[54],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],a[53]=((C_word*)t0)[53],tmp=(C_word)a,a+=54,tmp);
/* r2242 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[255]);}

/* k7905 in k7901 in k7897 in k7893 in k7888 in k7881 in k7877 in k7872 in k7868 in k7864 in k7860 in k7856 in k7850 in k7845 in k7841 in k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[129],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7907,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[53])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[52])+1,lf[53]);
t4=C_mutate(((C_word *)((C_word*)t0)[51])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7910,a[2]=((C_word*)t0)[41],a[3]=((C_word*)t0)[42],a[4]=((C_word*)t0)[52],a[5]=((C_word*)t0)[43],a[6]=((C_word*)t0)[44],a[7]=((C_word*)t0)[45],a[8]=((C_word*)t0)[46],a[9]=((C_word*)t0)[47],a[10]=((C_word*)t0)[48],a[11]=((C_word*)t0)[49],a[12]=((C_word*)t0)[50],a[13]=((C_word)li93),tmp=(C_word)a,a+=14,tmp));
t5=C_mutate(((C_word *)((C_word*)t0)[41])+1,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8004,a[2]=((C_word*)t0)[35],a[3]=((C_word*)t0)[46],a[4]=((C_word*)t0)[36],a[5]=((C_word*)t0)[37],a[6]=((C_word*)t0)[38],a[7]=((C_word*)t0)[39],a[8]=((C_word*)t0)[40],a[9]=((C_word)li95),tmp=(C_word)a,a+=10,tmp));
t6=C_mutate(((C_word *)((C_word*)t0)[35])+1,(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_8088,a[2]=((C_word*)t0)[27],a[3]=((C_word*)t0)[28],a[4]=((C_word*)t0)[29],a[5]=((C_word*)t0)[30],a[6]=((C_word*)t0)[31],a[7]=((C_word*)t0)[35],a[8]=((C_word*)t0)[47],a[9]=((C_word*)t0)[44],a[10]=((C_word*)t0)[40],a[11]=((C_word*)t0)[32],a[12]=((C_word*)t0)[53],a[13]=((C_word*)t0)[33],a[14]=((C_word*)t0)[50],a[15]=((C_word*)t0)[49],a[16]=((C_word*)t0)[34],a[17]=((C_word)li96),tmp=(C_word)a,a+=18,tmp));
t7=C_mutate(((C_word *)((C_word*)t0)[33])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8309,a[2]=((C_word*)t0)[35],a[3]=((C_word*)t0)[31],a[4]=((C_word*)t0)[44],a[5]=((C_word*)t0)[22],a[6]=((C_word*)t0)[40],a[7]=((C_word*)t0)[23],a[8]=((C_word*)t0)[47],a[9]=((C_word*)t0)[32],a[10]=((C_word*)t0)[24],a[11]=((C_word*)t0)[25],a[12]=((C_word*)t0)[26],a[13]=((C_word)li97),tmp=(C_word)a,a+=14,tmp));
t8=C_mutate(((C_word *)((C_word*)t0)[30])+1,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_8427,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[35],a[6]=((C_word*)t0)[17],a[7]=((C_word*)t0)[18],a[8]=((C_word*)t0)[23],a[9]=((C_word*)t0)[22],a[10]=((C_word*)t0)[19],a[11]=((C_word*)t0)[20],a[12]=((C_word*)t0)[44],a[13]=((C_word*)t0)[40],a[14]=((C_word*)t0)[21],a[15]=((C_word*)t0)[53],a[16]=((C_word)li99),tmp=(C_word)a,a+=17,tmp));
t9=C_mutate(((C_word *)((C_word*)t0)[36])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8715,a[2]=((C_word*)t0)[27],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[17],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[31],a[7]=((C_word*)t0)[47],a[8]=((C_word*)t0)[36],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[43],a[11]=((C_word*)t0)[53],a[12]=((C_word*)t0)[34],a[13]=((C_word)li102),tmp=(C_word)a,a+=14,tmp));
t10=C_mutate(((C_word *)((C_word*)t0)[38])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8922,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[43],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[38],a[12]=((C_word*)t0)[49],a[13]=((C_word)li104),tmp=(C_word)a,a+=14,tmp));
t11=C_mutate(((C_word *)((C_word*)t0)[37])+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9176,a[2]=((C_word*)t0)[27],a[3]=((C_word*)t0)[37],a[4]=((C_word*)t0)[34],a[5]=((C_word)li105),tmp=(C_word)a,a+=6,tmp));
t12=C_mutate(((C_word *)((C_word*)t0)[9])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9249,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],a[4]=((C_word)li106),tmp=(C_word)a,a+=5,tmp));
t13=C_mutate(((C_word *)((C_word*)t0)[27])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9342,a[2]=((C_word*)t0)[4],a[3]=((C_word)li107),tmp=(C_word)a,a+=4,tmp));
t14=C_mutate(((C_word *)((C_word*)t0)[4])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9364,a[2]=((C_word*)t0)[14],a[3]=((C_word)li108),tmp=(C_word)a,a+=4,tmp));
t15=C_mutate(((C_word *)((C_word*)t0)[8])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9390,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word)li109),tmp=(C_word)a,a+=5,tmp));
t16=C_mutate(((C_word *)((C_word*)t0)[11])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9410,a[2]=((C_word*)t0)[14],a[3]=((C_word)li111),tmp=(C_word)a,a+=4,tmp));
/* make-transformer2282 */
t17=((C_word*)((C_word*)t0)[51])[1];
((C_proc3)C_retrieve_proc(t17))(3,t17,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_9410 in k7905 in k7901 in k7897 in k7893 in k7888 in k7881 in k7877 in k7872 in k7868 in k7864 in k7860 in k7856 in k7850 in k7845 in k7841 in k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9410(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9410,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9420,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word)li110),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_9420(t7,t1,t3);}

/* loop */
static void C_fcall f_9420(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9420,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9427,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=t3;
f_9427(t5,(C_word)C_eqp(t4,((C_word*)t0)[2]));}
else{
t4=t3;
f_9427(t4,C_SCHEME_FALSE);}}

/* k9425 in loop */
static void C_fcall f_9427(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* loop2611 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9420(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* f_9390 in k7905 in k7901 in k7897 in k7893 in k7888 in k7881 in k7877 in k7872 in k7868 in k7864 in k7860 in k7856 in k7850 in k7845 in k7841 in k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9390(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9390,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9397,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* segment-template?2292 */
t4=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k9395 */
static void C_ccall f_9397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9397,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9404,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* segment-depth2293 */
t4=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}

/* k9402 in k9395 */
static void C_ccall f_9404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(C_fix(1),t1));}

/* f_9364 in k7905 in k7901 in k7897 in k7893 in k7888 in k7881 in k7877 in k7872 in k7868 in k7864 in k7860 in k7856 in k7850 in k7845 in k7841 in k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9364(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9364,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t4,((C_word*)t0)[2]));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_9342 in k7905 in k7901 in k7897 in k7893 in k7888 in k7881 in k7877 in k7872 in k7868 in k7864 in k7860 in k7856 in k7850 in k7845 in k7841 in k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9342(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9342,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9349,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* segment-template?2292 */
t4=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k9347 */
static void C_ccall f_9349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* ##sys#syntax-error-hook */
t4=C_retrieve(lf[53]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],lf[254],((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_9249 in k7905 in k7901 in k7897 in k7893 in k7888 in k7881 in k7877 in k7872 in k7868 in k7864 in k7860 in k7856 in k7850 in k7845 in k7841 in k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9249(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9249,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_symbolp(t2))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9262,a[2]=t5,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t2,t5))){
t7=t6;
f_9262(t7,C_SCHEME_FALSE);}
else{
t7=(C_word)C_i_assq(t2,t4);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t7);
t9=t3;
t10=t6;
f_9262(t10,(C_word)C_fixnum_greater_or_equal_p(t8,t9));}
else{
t8=t6;
f_9262(t8,C_SCHEME_FALSE);}}}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9291,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* segment-template?2292 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}}

/* k9289 */
static void C_ccall f_9291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9291,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9302,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[7]);
/* free-meta-variables2290 */
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9323,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* free-meta-variables2290 */
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[7]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9340,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* vector->list */
t3=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}}}

/* k9338 in k9289 */
static void C_ccall f_9340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* free-meta-variables2290 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9321 in k9289 */
static void C_ccall f_9323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* free-meta-variables2290 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9300 in k9289 */
static void C_ccall f_9302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* free-meta-variables2290 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9260 */
static void C_fcall f_9262(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9262,NULL,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]):((C_word*)t0)[2]));}

/* f_9176 in k7905 in k7901 in k7897 in k7893 in k7888 in k7881 in k7877 in k7872 in k7868 in k7864 in k7860 in k7856 in k7850 in k7845 in k7841 in k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_9176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9176,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_symbolp(t2))){
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[4]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,t5,t4));}}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9202,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* segment-pattern?2291 */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}

/* k9200 */
static void C_ccall f_9202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9202,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* meta-variables2289 */
t4=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9230,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* meta-variables2289 */
t5=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9247,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* vector->list */
t3=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}}}

/* k9245 in k9200 */
static void C_ccall f_9247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* meta-variables2289 */
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9228 in k9200 */
static void C_ccall f_9230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* meta-variables2289 */
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_8922 in k7905 in k7901 in k7897 in k7893 in k7888 in k7881 in k7877 in k7872 in k7868 in k7864 in k7860 in k7856 in k7850 in k7845 in k7841 in k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_8922(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[27],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8922,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_symbolp(t2))){
t5=(C_word)C_i_assq(t2,t4);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t5);
t7=t3;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t6,t7))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t2);}
else{
/* ##sys#syntax-error-hook */
t8=C_retrieve(lf[53]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,lf[251],t2);}}
else{
t6=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[250],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[12])[1],t8));}}
else{
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8969,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t4,a[11]=((C_word*)t0)[11],a[12]=t2,a[13]=t1,a[14]=t3,tmp=(C_word)a,a+=15,tmp);
/* segment-template?2292 */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}

/* k8967 */
static void C_ccall f_8969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8969,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8972,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
/* segment-depth2293 */
t3=((C_word*)((C_word*)t0)[5])[1];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[12]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[12]))){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9130,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[12]);
/* process-template2288 */
t4=((C_word*)((C_word*)t0)[11])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[14],((C_word*)t0)[10]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[12]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9163,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9167,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[14],a[4]=t2,a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* vector->list */
t4=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[12]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t2));}}}}

/* k9165 in k8967 */
static void C_ccall f_9167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* process-template2288 */
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9161 in k8967 */
static void C_ccall f_9163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9163,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t2));}

/* k9128 in k8967 */
static void C_ccall f_9130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9130,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9138,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* process-template2288 */
t4=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9136 in k9128 in k8967 */
static void C_ccall f_9138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9138,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t3));}

/* k8970 in k8967 */
static void C_ccall f_8972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8972,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[10],t1);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8978,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[8]);
/* free-meta-variables2290 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,t4,t2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}

/* k8976 in k8970 in k8967 */
static void C_ccall f_8978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8978,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
/* ##sys#syntax-error-hook */
t2=C_retrieve(lf[53]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[11],lf[252],((C_word*)t0)[10]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8990,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[10]);
/* process-template2288 */
t4=((C_word*)((C_word*)t0)[9])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],((C_word*)t0)[7]);}}

/* k8988 in k8976 in k8970 in k8967 */
static void C_ccall f_8990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8993,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9056,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t4))){
if(C_truep((C_word)C_i_symbolp(t1))){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=t3;
f_9056(t6,(C_word)C_eqp(t1,t5));}
else{
t5=t3;
f_9056(t5,C_SCHEME_FALSE);}}
else{
t5=t3;
f_9056(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_9056(t4,C_SCHEME_FALSE);}}

/* k9054 in k8988 in k8976 in k8970 in k8967 */
static void C_fcall f_9056(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9056,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_8993(t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t6=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}}

/* k9069 in k9054 in k8988 in k8976 in k8970 in k8967 */
static void C_ccall f_9071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9071,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_8993(t3,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t2));}

/* k8991 in k8988 in k8976 in k8970 in k8967 */
static void C_fcall f_8993(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8993,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8996,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9027,a[2]=t4,a[3]=((C_word)li103),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_9027(t6,t2,((C_word*)t0)[2],t1);}

/* doloop2529 in k8991 in k8988 in k8976 in k8970 in k8967 */
static void C_fcall f_9027(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9027,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,C_fix(1));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[51],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[253],t8);
t11=t1;
t12=t6;
t13=t9;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}

/* k8994 in k8991 in k8988 in k8976 in k8970 in k8967 */
static void C_ccall f_8996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* segment-tail2294 */
t3=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k9023 in k8994 in k8991 in k8988 in k8976 in k8970 in k8967 */
static void C_ccall f_9025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9025,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9017,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9021,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* segment-tail2294 */
t4=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}

/* k9019 in k9023 in k8994 in k8991 in k8988 in k8976 in k8970 in k8967 */
static void C_ccall f_9021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* process-template2288 */
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9015 in k9023 in k8994 in k8991 in k8988 in k8976 in k8970 in k8967 */
static void C_ccall f_9017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9017,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[51],t3));}

/* f_8715 in k7905 in k7901 in k7897 in k7893 in k7888 in k7881 in k7877 in k7872 in k7868 in k7864 in k7860 in k7856 in k7850 in k7845 in k7841 in k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_8715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8715,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_symbolp(t2))){
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[12]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8739,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* mapit2436 */
t6=t4;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}}
else{
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8745,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t3,a[12]=((C_word*)t0)[11],a[13]=t4,a[14]=t2,tmp=(C_word)a,a+=15,tmp);
/* segment-pattern?2291 */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}

/* k8743 */
static void C_ccall f_8745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8745,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8754,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word)li100),tmp=(C_word)a,a+=8,tmp);
/* process-pattern2287 */
t4=((C_word*)((C_word*)t0)[8])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[7],t2,((C_word*)((C_word*)t0)[12])[1],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[14]))){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8805,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[14]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t4);
/* process-pattern2287 */
t6=((C_word*)((C_word*)t0)[8])[1];
((C_proc5)C_retrieve_proc(t6))(5,t6,t2,t3,t5,((C_word*)t0)[13]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[14]))){
t2=(C_word)C_i_vector_length(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8845,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(2)))){
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=(C_word)C_i_vector_ref(((C_word*)t0)[14],t4);
t6=t3;
f_8845(t6,(C_word)C_eqp(t5,((C_word*)t0)[2]));}
else{
t4=t3;
f_8845(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}}}

/* k8843 in k8743 */
static void C_fcall f_8845(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8845,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8855,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* vector->list */
t3=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8868,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word*)t0)[3],a[9]=((C_word)li101),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_8868(t5,((C_word*)t0)[6],C_fix(0));}}

/* lp in k8843 in k8743 */
static void C_fcall f_8868(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8868,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[8]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8882,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_vector_ref(((C_word*)t0)[6],t2);
t6=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t7);
/* process-pattern2287 */
t9=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t9))(5,t9,t4,t5,t8,((C_word*)t0)[2]);}}

/* k8880 in lp in k8843 in k8743 */
static void C_ccall f_8882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8886,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* lp2471 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8868(t4,t2,t3);}

/* k8884 in k8880 in lp in k8843 in k8743 */
static void C_ccall f_8886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[68]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8853 in k8843 in k8743 */
static void C_ccall f_8855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8855,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t2);
/* process-pattern2287 */
t4=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,t3,((C_word*)t0)[2]);}

/* k8803 in k8743 */
static void C_ccall f_8805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8805,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8809,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t4);
/* process-pattern2287 */
t6=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t6))(5,t6,t2,t3,t5,((C_word*)t0)[2]);}

/* k8807 in k8803 in k8743 */
static void C_ccall f_8809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[68]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8753 in k8743 */
static void C_ccall f_8754(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8754,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8762,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],t2);
if(C_truep(t4)){
t5=t3;
f_8762(t5,((C_word*)t0)[4]);}
else{
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t8,t9);
t11=t3;
f_8762(t11,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t10));}}

/* k8760 in a8753 in k8743 */
static void C_fcall f_8762(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* mapit2436 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8737 */
static void C_ccall f_8739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8739,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,1,t2));}

/* f_8427 in k7905 in k7901 in k7897 in k7893 in k7888 in k7881 in k7877 in k7872 in k7868 in k7864 in k7860 in k7856 in k7850 in k7845 in k7841 in k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_8427(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8427,4,t0,t1,t2,t3);}
t4=(C_word)C_i_vector_length(t3);
t5=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_8434,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t4,a[13]=t1,a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=t2,tmp=(C_word)a,a+=19,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,C_fix(2)))){
t6=(C_word)C_fixnum_difference(t4,C_fix(1));
t7=(C_word)C_i_vector_ref(t3,t6);
t8=t5;
f_8434(t8,(C_word)C_eqp(t7,((C_word*)t0)[2]));}
else{
t6=t5;
f_8434(t6,C_SCHEME_FALSE);}}

/* k8432 */
static void C_fcall f_8434(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[63],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8434,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[18],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[16])[1],t5);
t7=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_8473,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[17],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=t4,a[16]=((C_word*)t0)[15],a[17]=t6,tmp=(C_word)a,a+=18,tmp);
if(C_truep(t1)){
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t8);
t10=(C_word)C_fixnum_difference(((C_word*)t0)[12],C_fix(2));
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t9,t11);
t13=t7;
f_8473(t13,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t12));}
else{
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t9,t10);
t12=t7;
f_8473(t12,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t11));}}

/* k8471 in k8432 */
static void C_fcall f_8473(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8473,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8477,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[17],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8481,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_8483,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[16],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],a[16]=((C_word)li98),tmp=(C_word)a,a+=17,tmp));
t7=((C_word*)t5)[1];
f_8483(t7,t3,C_fix(0));}

/* lp in k8471 in k8432 */
static void C_fcall f_8483(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8483,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[15]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_fixnum_difference(((C_word*)t0)[15],C_fix(2));
t5=t2;
t6=(C_word)C_eqp(t5,t4);
t7=(C_truep(t6)?((C_word*)t0)[14]:C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[13])[1],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[15],C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[13])[1],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[12])[1],t12);
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8543,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t10,a[6]=((C_word*)t0)[10],a[7]=t13,a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8547,a[2]=t14,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[13],tmp=(C_word)a,a+=6,tmp);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[13])[1],C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t17);
t19=(C_word)C_fixnum_difference(((C_word*)t0)[15],C_fix(2));
t20=(C_word)C_i_vector_ref(((C_word*)t0)[4],t19);
/* process-match2284 */
t21=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t21))(4,t21,t15,t18,t20);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8614,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t9);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t10);
t12=(C_word)C_i_vector_ref(((C_word*)t0)[4],t2);
/* process-match2284 */
t13=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t13))(4,t13,t8,t11,t12);}}}

/* k8612 in lp in k8471 in k8432 */
static void C_ccall f_8614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8614,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8618,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* lp2407 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8483(t4,t2,t3);}

/* k8616 in k8612 in lp in k8471 in k8432 */
static void C_ccall f_8618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[68]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8545 in lp in k8471 in k8432 */
static void C_ccall f_8547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8547,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_fix(1),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t8=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[2],t1,t7);}

/* k8541 in lp in k8471 in k8432 */
static void C_ccall f_8543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8543,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[8])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST));}

/* k8479 in k8471 in k8432 */
static void C_ccall f_8481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8475 in k8471 in k8432 */
static void C_ccall f_8477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8477,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST));}

/* f_8309 in k7905 in k7901 in k7897 in k7893 in k7888 in k7881 in k7877 in k7872 in k7868 in k7864 in k7860 in k7856 in k7850 in k7845 in k7841 in k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_8309(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8309,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8313,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t1,a[11]=((C_word*)t0)[12],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
/* process-match2284 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t6,t3);}

/* k8311 */
static void C_ccall f_8313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[75],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8313,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],t2);
t4=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[8])[1],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t8,t13);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t6,t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,t4,t19);
t21=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t21);
t23=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,(C_word)C_a_i_cons(&a,2,t22,C_SCHEME_END_OF_LIST));}}

/* f_8088 in k7905 in k7901 in k7897 in k7893 in k7888 in k7881 in k7877 in k7872 in k7868 in k7864 in k7860 in k7856 in k7850 in k7845 in k7841 in k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_8088(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[40],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8088,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_symbolp(t3))){
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[16]))){
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[250],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[15])[1],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t2,t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[14])[1],t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}
else{
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_8138,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t2,a[13]=t1,a[14]=((C_word*)t0)[13],a[15]=t3,tmp=(C_word)a,a+=16,tmp);
/* segment-pattern?2291 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}}

/* k8136 */
static void C_ccall f_8138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8138,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[15]);
/* process-segment-match2285 */
t3=((C_word*)((C_word*)t0)[14])[1];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[13],((C_word*)t0)[12],t2);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[15]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8186,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=t4,a[5]=((C_word*)t0)[9],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8190,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[11],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t9);
t11=(C_word)C_i_car(((C_word*)t0)[15]);
/* process-match2284 */
t12=((C_word*)((C_word*)t0)[6])[1];
((C_proc4)C_retrieve_proc(t12))(4,t12,t8,t10,t11);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[15]))){
/* process-vector-match2286 */
t2=((C_word*)((C_word*)t0)[4])[1];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[15]);}
else{
t2=(C_word)C_i_nullp(((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8252,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[15],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_8252(t4,t2);}
else{
t4=(C_word)C_booleanp(((C_word*)t0)[15]);
t5=t3;
f_8252(t5,(C_truep(t4)?t4:(C_word)C_charp(((C_word*)t0)[15])));}}}}}

/* k8250 in k8136 */
static void C_fcall f_8252(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8252,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[95],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[95],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}}

/* k8188 in k8136 */
static void C_ccall f_8190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8194,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8198,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* process-match2284 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t7))(4,t7,t3,t5,t6);}

/* k8196 in k8188 in k8136 */
static void C_ccall f_8198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8192 in k8188 in k8136 */
static void C_ccall f_8194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8184 in k8136 */
static void C_ccall f_8186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8186,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}

/* f_8004 in k7905 in k7901 in k7897 in k7893 in k7888 in k7881 in k7877 in k7872 in k7868 in k7864 in k7860 in k7856 in k7850 in k7845 in k7841 in k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_8004(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8004,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8011,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cddr(t2);
t6=t3;
f_8011(t6,(C_word)C_i_nullp(t5));}
else{
t5=t3;
f_8011(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8011(t4,C_SCHEME_FALSE);}}

/* k8009 */
static void C_fcall f_8011(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8011,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* cdar */
t3=*((C_word*)lf[208]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[10]);}
else{
/* ##sys#syntax-error-hook */
t2=C_retrieve(lf[53]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],lf[249],((C_word*)t0)[10]);}}

/* k8012 in k8009 */
static void C_ccall f_8014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8014,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8059,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8063,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* process-match2284 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],t1);}

/* k8061 in k8012 in k8009 */
static void C_ccall f_8063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8057 in k8012 in k8009 */
static void C_ccall f_8059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8059,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8040,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8054,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp);
/* process-pattern2287 */
t5=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1],t4);}

/* a8053 in k8057 in k8012 in k8009 */
static void C_ccall f_8054(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8054,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8038 in k8057 in k8012 in k8009 */
static void C_ccall f_8040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8048,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8052,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* meta-variables2289 */
t4=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],C_fix(0),C_SCHEME_END_OF_LIST);}

/* k8050 in k8038 in k8057 in k8012 in k8009 */
static void C_ccall f_8052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* process-template2288 */
t2=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}

/* k8046 in k8038 in k8057 in k8012 in k8009 */
static void C_ccall f_8048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8048,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* f_7910 in k7905 in k7901 in k7897 in k7893 in k7888 in k7881 in k7877 in k7872 in k7868 in k7864 in k7860 in k7856 in k7850 in k7845 in k7841 in k7837 in k7823 in ##sys#process-syntax-rules in k7814 in k7811 in k7808 in k7805 in k7802 in k7799 in k7796 in k7793 in k7790 in k7787 in k7784 in k7781 in k7778 in k7775 in k7772 in k7769 in k7766 in k7762 in k7759 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7910(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[38],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7910,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[12])[1],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[8])[1],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7950,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t10,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7954,a[2]=t11,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* map */
t13=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t12,((C_word*)((C_word*)t0)[2])[1],t2);}

/* k7952 */
static void C_ccall f_7954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7954,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[248],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t8=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[2],t1,t7);}

/* k7948 */
static void C_ccall f_7950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7950,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t7));}

/* ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_6916,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6920,a[2]=t3,a[3]=t7,a[4]=t2,a[5]=t5,a[6]=t6,a[7]=t1,a[8]=t4,a[9]=t8,tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 726  r */
t10=t3;
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,lf[228]);}

/* k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 727  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[227]);}

/* k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6926,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 728  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[226]);}

/* k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6929,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 729  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[225]);}

/* k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6929,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6931,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6940,a[2]=((C_word*)t0)[11],a[3]=((C_word)li78),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6983,a[2]=t2,a[3]=((C_word*)t0)[11],a[4]=((C_word)li81),tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7070,a[2]=t6,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t1,a[7]=((C_word*)t0)[10],a[8]=t3,a[9]=t2,a[10]=((C_word*)t0)[11],a[11]=t4,a[12]=((C_word)li88),tmp=(C_word)a,a+=13,tmp));
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7528,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 826  ##sys#check-syntax */
t9=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t8,((C_word*)t0)[11],((C_word*)t0)[3],lf[224]);}

/* k7526 in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 827  ##sys#current-module */
t3=C_retrieve(lf[80]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k7529 in k7526 in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7534,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7735,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=f_9599(t1);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 833  append */
t6=*((C_word*)lf[68]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7750,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=f_9581(t1);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 836  append */
t6=*((C_word*)lf[68]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}}
else{
t3=t2;
f_7534(2,t3,C_SCHEME_UNDEFINED);}}

/* k7748 in k7529 in k7526 in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t4=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],t2,C_fix(7),t1);}

/* k7733 in k7529 in k7526 in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t4=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],t2,C_fix(8),t1);}

/* k7532 in k7529 in k7526 in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7534,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7537,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7539,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li91),tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* for-each */
t5=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a7538 in k7532 in k7529 in k7526 in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7539(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7539,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7543,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 839  import-spec */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7070(t4,t3,t2);}

/* k7541 in a7538 in k7532 in k7529 in k7526 in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7543,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7552,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[219],t5);
/* expand.scm: 842  dd */
t7=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t7))(3,t7,t4,t6);}

/* k7550 in k7541 in a7538 in k7532 in k7529 in k7526 in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_truep(((C_word*)t0)[2])?f_9473(((C_word*)t0)[2]):lf[216]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7710,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 843  map-se */
f_3584(t4,((C_word*)t0)[3]);}

/* k7708 in k7550 in k7541 in a7538 in k7532 in k7529 in k7526 in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7710,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[218],t3);
/* expand.scm: 843  dd */
t5=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t5))(3,t5,((C_word*)t0)[2],t4);}

/* k7553 in k7550 in k7541 in a7538 in k7532 in k7529 in k7526 in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7558,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_truep(((C_word*)t0)[2])?f_9473(((C_word*)t0)[2]):lf[216]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7687,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 844  map-se */
f_3584(t4,((C_word*)t0)[5]);}

/* k7685 in k7553 in k7550 in k7541 in a7538 in k7532 in k7529 in k7526 in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7687,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[217],t3);
/* expand.scm: 844  dd */
t5=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t5))(3,t5,((C_word*)t0)[2],t4);}

/* k7556 in k7553 in k7550 in k7541 in a7538 in k7532 in k7529 in k7526 in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7561,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 845  ##sys#mark-imported-symbols */
t3=C_retrieve(lf[215]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k7559 in k7556 in k7553 in k7550 in k7541 in a7538 in k7532 in k7529 in k7526 in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7564,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7633,a[2]=((C_word*)t0)[3],a[3]=((C_word)li90),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7632 in k7559 in k7556 in k7553 in k7550 in k7541 in a7538 in k7532 in k7529 in k7526 in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7633(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7633,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7667,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 850  import-env */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k7665 in a7632 in k7559 in k7556 in k7553 in k7550 in k7541 in a7538 in k7532 in k7529 in k7526 in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_eqp(((C_word*)t0)[3],t3);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}
else{
/* expand.scm: 852  ##sys#warn */
t5=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[2],lf[214],((C_word*)t0)[4]);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7562 in k7559 in k7556 in k7553 in k7550 in k7541 in a7538 in k7532 in k7529 in k7526 in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7591,a[2]=((C_word*)t0)[6],a[3]=((C_word)li89),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a7590 in k7562 in k7559 in k7556 in k7553 in k7550 in k7541 in a7538 in k7532 in k7529 in k7526 in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7591(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7591,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7631,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 856  macro-env */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k7629 in a7590 in k7562 in k7559 in k7556 in k7553 in k7550 in k7541 in a7538 in k7532 in k7529 in k7526 in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_car(((C_word*)t0)[3]);
/* expand.scm: 858  ##sys#warn */
t7=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[2],lf[213],t6);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7565 in k7562 in k7559 in k7556 in k7553 in k7550 in k7541 in a7538 in k7532 in k7529 in k7526 in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7567,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7570,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7585,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7589,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 860  import-env */
t5=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k7587 in k7565 in k7562 in k7559 in k7556 in k7553 in k7550 in k7541 in a7538 in k7532 in k7529 in k7526 in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 860  append */
t2=*((C_word*)lf[68]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7583 in k7565 in k7562 in k7559 in k7556 in k7553 in k7550 in k7541 in a7538 in k7532 in k7529 in k7526 in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 860  import-env */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7568 in k7565 in k7562 in k7559 in k7556 in k7553 in k7550 in k7541 in a7538 in k7532 in k7529 in k7526 in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7570,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7577,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7581,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 861  macro-env */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7579 in k7568 in k7565 in k7562 in k7559 in k7556 in k7553 in k7550 in k7541 in a7538 in k7532 in k7529 in k7526 in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 861  append */
t2=*((C_word*)lf[68]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7575 in k7568 in k7565 in k7562 in k7559 in k7556 in k7553 in k7550 in k7541 in a7538 in k7532 in k7529 in k7526 in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 861  macro-env */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7535 in k7532 in k7529 in k7526 in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[212]);}

/* import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_7070(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7070,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* expand.scm: 759  import-name */
t3=((C_word*)t0)[11];
f_6983(t3,t1,t2);}
else{
t3=(C_word)C_i_listp(t2);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7089,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
if(C_truep(t4)){
t6=t5;
f_7089(t6,t4);}
else{
t6=(C_word)C_i_length(t2);
t7=t5;
f_7089(t7,(C_word)C_fixnum_lessp(t6,C_fix(2)));}}}

/* k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_7089(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7089,NULL,2,t0,t1);}
if(C_truep(t1)){
/* expand.scm: 761  syntax-error */
t2=C_retrieve(lf[142]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[12],((C_word*)t0)[11],lf[201],((C_word*)t0)[10]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7098,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[10]);
/* expand.scm: 764  import-spec */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7070(t5,t3,t4);}}

/* k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7098,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7110,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[10]);
/* expand.scm: 767  c */
t6=((C_word*)t0)[6];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}

/* k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7110,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7113,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 768  ##sys#check-syntax */
t3=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[7],((C_word*)t0)[9],lf[202]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7190,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* expand.scm: 779  c */
t4=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k7188 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7190,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7193,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 780  ##sys#check-syntax */
t3=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[6],((C_word*)t0)[8],lf[203]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7297,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
/* expand.scm: 790  c */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k7295 in k7188 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7297,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7300,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 791  ##sys#check-syntax */
t3=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[9],lf[209]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7444,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* expand.scm: 816  c */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k7442 in k7295 in k7188 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7444,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7447,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 817  ##sys#check-syntax */
t3=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4],lf[210]);}
else{
/* expand.scm: 825  syntax-error */
t2=C_retrieve(lf[142]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[7],((C_word*)t0)[2],lf[211],((C_word*)t0)[4]);}}

/* k7445 in k7442 in k7295 in k7188 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7450,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[3]);
/* expand.scm: 818  tostr */
t4=((C_word*)t0)[2];
f_6940(t4,t2,t3);}

/* k7448 in k7445 in k7442 in k7295 in k7188 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7452,a[2]=t1,a[3]=((C_word)li87),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7483,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,((C_word*)t0)[2]);}

/* k7481 in k7448 in k7445 in k7442 in k7295 in k7188 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7487,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7485 in k7481 in k7448 in k7445 in k7442 in k7295 in k7188 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7487,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ren in k7448 in k7445 in k7442 in k7295 in k7188 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7452(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7452,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7460,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7468,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7472,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_car(t2);
/* expand.scm: 822  ##sys#symbol->string */
t7=C_retrieve(lf[190]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}

/* k7470 in ren in k7448 in k7445 in k7442 in k7295 in k7188 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 822  ##sys#string-append */
t2=C_retrieve(lf[188]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7466 in ren in k7448 in k7445 in k7442 in k7295 in k7188 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 821  ##sys#string->symbol */
t2=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7458 in ren in k7448 in k7445 in k7442 in k7295 in k7188 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7460,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t1,t2));}

/* k7298 in k7295 in k7188 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7300,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7309,a[2]=t4,a[3]=((C_word)li86),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_7309(t6,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t2);}

/* loop in k7298 in k7295 in k7188 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_7309(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7309,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7325,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7330,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp);
/* for-each */
t9=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,t6);}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7386,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t5,a[7]=t3,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 800  caar */
t8=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7438,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t4,a[7]=t2,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 807  caar */
t8=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}}

/* k7436 in loop in k7298 in k7295 in k7188 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7438,2,t0,t1);}
t2=(C_word)C_i_assq(t1,((C_word*)t0)[8]);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7419,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 810  cdar */
t6=*((C_word*)lf[208]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
/* expand.scm: 813  loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_7309(t6,((C_word*)t0)[4],t3,((C_word*)t0)[3],t5,((C_word*)t0)[2],((C_word*)t0)[8]);}}

/* k7417 in k7436 in loop in k7298 in k7295 in k7188 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7419,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7407,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 812  ##sys#delq */
t5=C_retrieve(lf[207]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7405 in k7417 in k7436 in loop in k7298 in k7295 in k7188 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 809  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_7309(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7384 in loop in k7298 in k7295 in k7188 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7386,2,t0,t1);}
t2=(C_word)C_i_assq(t1,((C_word*)t0)[8]);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7367,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 804  cdar */
t6=*((C_word*)lf[208]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
/* expand.scm: 806  loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_7309(t6,((C_word*)t0)[4],((C_word*)t0)[3],t3,((C_word*)t0)[2],t5,((C_word*)t0)[8]);}}

/* k7365 in k7384 in loop in k7298 in k7295 in k7188 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7367,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7355,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 805  ##sys#delq */
t5=C_retrieve(lf[207]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7353 in k7365 in k7384 in loop in k7298 in k7295 in k7188 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 802  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_7309(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7329 in loop in k7298 in k7295 in k7188 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7330(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7330,3,t0,t1,t2);}
/* expand.scm: 797  ##sys#warn */
t3=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[205],t2);}

/* k7323 in loop in k7298 in k7295 in k7188 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7325,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k7191 in k7188 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7196,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k7194 in k7191 in k7188 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7196,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7201,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word)li84),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7201(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop in k7194 in k7191 in k7188 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_7201(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7201,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7213,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word)li83),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_7213(t7,t1,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7287,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 788  caar */
t5=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k7285 in loop in k7194 in k7191 in k7188 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7287,2,t0,t1);}
if(C_truep((C_word)C_i_memq(t1,((C_word*)t0)[6]))){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* expand.scm: 788  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7201(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* expand.scm: 789  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_7201(t5,((C_word*)t0)[3],t2,t4);}}

/* loop in loop in k7194 in k7191 in k7188 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_7213(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7213,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7255,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 786  caar */
t5=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k7253 in loop in loop in k7194 in k7191 in k7188 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7255,2,t0,t1);}
if(C_truep((C_word)C_i_memq(t1,((C_word*)t0)[6]))){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* expand.scm: 786  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7213(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* expand.scm: 787  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_7213(t5,((C_word*)t0)[3],t2,t4);}}

/* k7111 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7116,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k7114 in k7111 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7116,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7121,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li82),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7121(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in k7114 in k7111 in k7108 in k7096 in k7087 in import-spec in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_7121(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7121,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,t3,t4));}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_assq(t5,((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t2);
t8=(C_word)C_a_i_cons(&a,2,t6,t3);
/* expand.scm: 774  loop */
t15=t1;
t16=t7;
t17=t8;
t18=t4;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_assq(t7,((C_word*)t0)[2]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_a_i_cons(&a,2,t8,t4);
/* expand.scm: 777  loop */
t15=t1;
t16=t9;
t17=t3;
t18=t10;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}
else{
t9=(C_word)C_i_cdr(t2);
/* expand.scm: 778  loop */
t15=t1;
t16=t9;
t17=t3;
t18=t4;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}}}}

/* import-name in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_6983(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6983,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6987,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 739  resolve */
t4=((C_word*)t0)[2];
f_6931(3,t4,t3,t2);}

/* k6985 in import-name in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6990,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 740  ##sys#find-module */
t3=C_retrieve(lf[194]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,C_SCHEME_FALSE);}

/* k6988 in k6985 in import-name in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6990,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6993,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t3)[1])){
t5=t4;
f_6993(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7005,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7064,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7068,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 743  symbol->string */
t8=*((C_word*)lf[146]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[3]);}}

/* k7066 in k6988 in k6985 in import-name in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 743  string-append */
t2=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[200]);}

/* k7062 in k6988 in k6985 in import-name in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 742  ##sys#find-extension */
t2=C_retrieve(lf[199]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k7003 in k6988 in k6985 in import-name in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7005,2,t0,t1);}
if(C_truep(t1)){
t2=C_retrieve(lf[80]);
t3=C_retrieve(lf[8]);
t4=C_retrieve(lf[9]);
t5=C_retrieve(lf[29]);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7011,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t3,a[8]=t4,a[9]=t5,a[10]=t9,a[11]=t7,tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 747  ##sys#current-meta-environment */
t11=C_retrieve(lf[9]);
((C_proc2)C_retrieve_proc(t11))(2,t11,t10);}
else{
/* expand.scm: 752  syntax-error */
t2=C_retrieve(lf[142]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[198],((C_word*)t0)[3]);}}

/* k7009 in k7003 in k6988 in k6985 in import-name in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7011,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* expand.scm: 748  ##sys#meta-macro-environment */
t5=C_retrieve(lf[197]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k7012 in k7009 in k7003 in k6988 in k6985 in import-name in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7014,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7015,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t3,a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word)li79),tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7047,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7053,a[2]=((C_word*)t0)[2],a[3]=((C_word)li80),tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t7=*((C_word*)lf[196]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,t4,t6,t4);}

/* a7052 in k7012 in k7009 in k7003 in k6988 in k6985 in import-name in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7053,2,t0,t1);}
/* expand.scm: 749  ##sys#load */
t2=C_retrieve(lf[195]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k7045 in k7012 in k7009 in k7003 in k6988 in k6985 in import-name in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7051,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 750  ##sys#find-module */
t3=C_retrieve(lf[194]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k7049 in k7045 in k7012 in k7009 in k7003 in k6988 in k6985 in import-name in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6993(2,t3,t2);}

/* swap1402 in k7012 in k7009 in k7003 in k6988 in k6985 in import-name in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* g140514061421 */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k7017 in swap1402 in k7012 in k7009 in k7003 in k6988 in k6985 in import-name in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7022,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* g140514061421 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[10])[1]);}

/* k7020 in k7017 in swap1402 in k7012 in k7009 in k7003 in k6988 in k6985 in import-name in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7022,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[10])+1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7026,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* g140714081422 */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7024 in k7020 in k7017 in swap1402 in k7012 in k7009 in k7003 in k6988 in k6985 in import-name in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7026,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7029,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* g140714081422 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[8])[1]);}

/* k7027 in k7024 in k7020 in k7017 in swap1402 in k7012 in k7009 in k7003 in k6988 in k6985 in import-name in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7029,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g140914101423 */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7031 in k7027 in k7024 in k7020 in k7017 in swap1402 in k7012 in k7009 in k7003 in k6988 in k6985 in import-name in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7036,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g140914101423 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[6])[1]);}

/* k7034 in k7031 in k7027 in k7024 in k7020 in k7017 in swap1402 in k7012 in k7009 in k7003 in k6988 in k6985 in import-name in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7036,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7040,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g141114121424 */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7038 in k7034 in k7031 in k7027 in k7024 in k7020 in k7017 in swap1402 in k7012 in k7009 in k7003 in k6988 in k6985 in import-name in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7043,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g141114121424 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k7041 in k7038 in k7034 in k7031 in k7027 in k7024 in k7020 in k7017 in swap1402 in k7012 in k7009 in k7003 in k6988 in k6985 in import-name in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_7043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6991 in k6988 in k6985 in import-name in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6993,2,t0,t1);}
t2=f_9635(((C_word*)((C_word*)t0)[3])[1]);
t3=f_9653(((C_word*)((C_word*)t0)[3])[1]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* tostr in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_6940(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6940,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6953,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 734  keyword? */
t4=C_retrieve(lf[145]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k6951 in tostr in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6953,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6960,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 734  ##sys#symbol->string */
t3=C_retrieve(lf[190]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* expand.scm: 735  ##sys#symbol->string */
t2=C_retrieve(lf[190]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[3]))){
/* expand.scm: 736  number->string */
C_number_to_string(3,0,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* expand.scm: 737  syntax-error */
t2=C_retrieve(lf[142]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[191]);}}}}

/* k6958 in k6951 in tostr in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 734  ##sys#string-append */
t2=C_retrieve(lf[188]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[189]);}

/* resolve in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6931(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6931,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6935,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 731  lookup */
f_3517(t3,t2,C_SCHEME_END_OF_LIST);}

/* k6933 in resolve in k6927 in k6924 in k6921 in k6918 in ##sys#expand-import in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##sys#er-transformer in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6622(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6622,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6624,a[2]=t2,a[3]=((C_word)li75),tmp=(C_word)a,a+=4,tmp));}

/* f_6624 in ##sys#er-transformer in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6624(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6624,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6627,a[2]=t3,a[3]=t6,a[4]=((C_word)li72),tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6890,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6753,a[2]=t4,a[3]=t8,a[4]=((C_word)li74),tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 720  handler */
t10=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t10))(5,t10,t1,t2,t7,t9);}

/* compare */
static void C_ccall f_6753(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6753,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6757,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_symbolp(t2);
t6=(C_truep(t5)?(C_word)C_i_symbolp(t3):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6786,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 691  ##sys#get */
t8=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,t2,lf[12]);}
else{
t7=t4;
f_6757(t7,(C_word)C_eqp(t2,t3));}}

/* k6784 in compare */
static void C_ccall f_6786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6789,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_6789(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6876,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 692  lookup2 */
f_6890(t3,C_fix(1),((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k6874 in k6784 in compare */
static void C_ccall f_6876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_6789(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k6787 in k6784 in compare */
static void C_fcall f_6789(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6789,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6792,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 694  ##sys#get */
t3=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[4],lf[12]);}

/* k6790 in k6787 in k6784 in compare */
static void C_ccall f_6792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6795,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_6795(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6870,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 695  lookup2 */
f_6890(t3,C_fix(2),((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k6868 in k6790 in k6787 in k6784 in compare */
static void C_ccall f_6870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_6795(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k6793 in k6790 in k6787 in k6784 in compare */
static void C_fcall f_6795(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6795,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6814,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 699  ##sys#get */
t3=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[83]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6841,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 701  ##sys#macro-environment */
t3=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}
else{
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6864,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 705  ##sys#macro-environment */
t3=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
f_6757(t2,(C_word)C_eqp(((C_word*)t0)[3],t1));}}}

/* k6862 in k6793 in k6790 in k6787 in k6784 in compare */
static void C_ccall f_6864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=((C_word*)t0)[3];
f_6757(t4,(C_word)C_eqp(((C_word*)t0)[2],t3));}
else{
t3=((C_word*)t0)[3];
f_6757(t3,C_SCHEME_FALSE);}}

/* k6839 in k6793 in k6790 in k6787 in k6784 in compare */
static void C_ccall f_6841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=((C_word*)t0)[3];
f_6757(t4,(C_word)C_eqp(t3,((C_word*)t0)[2]));}
else{
t3=((C_word*)t0)[3];
f_6757(t3,C_SCHEME_FALSE);}}

/* k6812 in k6793 in k6790 in k6787 in k6784 in compare */
static void C_ccall f_6814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6814,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6821,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 700  ##sys#get */
t4=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],lf[83]);}

/* k6819 in k6812 in k6793 in k6790 in k6787 in k6784 in compare */
static void C_ccall f_6821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
f_6757(t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k6755 in compare */
static void C_fcall f_6757(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6757,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6760,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[47],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[186],t6);
/* expand.scm: 710  dd */
t8=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t8))(3,t8,t2,t7);}

/* k6758 in k6755 in compare */
static void C_ccall f_6760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* lookup2 */
static void C_fcall f_6890(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6890,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6894,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 713  lookup */
f_3517(t5,t3,t4);}

/* k6892 in lookup2 */
static void C_ccall f_6894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6897,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
t4=(C_truep(t1)?(C_word)C_i_pairp(t1):C_SCHEME_FALSE);
t5=(C_truep(t4)?lf[14]:t1);
/* expand.scm: 714  dd */
t6=C_retrieve2(lf[6],"dd");
((C_proc9)C_retrieve_proc(t6))(9,t6,t2,lf[182],t3,lf[183],((C_word*)t0)[2],lf[184],t5,lf[185]);}

/* k6895 in k6892 in lookup2 */
static void C_ccall f_6897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* rename */
static void C_ccall f_6627(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6627,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6637,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t3);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[47],t6);
t8=(C_word)C_a_i_cons(&a,2,t2,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[178],t8);
/* expand.scm: 671  dd */
t10=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t10))(3,t10,t4,t9);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6663,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 673  lookup */
f_3517(t4,t2,((C_word*)t0)[2]);}}

/* k6661 in rename */
static void C_ccall f_6663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6663,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6675,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[47],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[179],t5);
/* expand.scm: 676  dd */
t7=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t7))(3,t7,t2,t6);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6694,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 679  macro-alias */
f_3535(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6724,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 684  macro-alias */
f_3535(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k6722 in k6661 in rename */
static void C_ccall f_6724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[47],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[181],t5);
/* expand.scm: 685  dd */
t7=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t7))(3,t7,t2,t6);}

/* k6725 in k6722 in k6661 in rename */
static void C_ccall f_6727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6727,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}

/* k6692 in k6661 in rename */
static void C_ccall f_6694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6694,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6697,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[47],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[180],t5);
/* expand.scm: 680  dd */
t7=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t7))(3,t7,t2,t6);}

/* k6695 in k6692 in k6661 in rename */
static void C_ccall f_6697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6697,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}

/* k6673 in k6661 in rename */
static void C_ccall f_6675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k6635 in rename */
static void C_ccall f_6637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cdr(((C_word*)t0)[2]));}

/* ##sys#check-syntax in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6160(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr5r,(void*)f_6160r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6160r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6160r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(18);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6162,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t3,a[9]=((C_word)li68),tmp=(C_word)a,a+=10,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6565,a[2]=t6,a[3]=((C_word)li69),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6574,a[2]=t7,a[3]=((C_word)li70),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-culprit10181176 */
t9=t8;
f_6574(t9,t1);}
else{
t9=(C_word)C_i_car(t5);
t10=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-se10191172 */
t11=t7;
f_6565(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* body10161025 */
t13=t6;
f_6162(t13,t1,t9,t11);}
else{
/* ##sys#error */
t13=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[0],t12);}}}}

/* def-culprit1018 in ##sys#check-syntax in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_6574(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6574,NULL,2,t0,t1);}
/* def-se10191172 */
t2=((C_word*)t0)[2];
f_6565(t2,t1,C_SCHEME_FALSE);}

/* def-se1019 in ##sys#check-syntax in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_6565(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6565,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6573,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 585  ##sys#current-environment */
t4=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k6571 in def-se1019 in ##sys#check-syntax in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* body10161025 */
t2=((C_word*)t0)[4];
f_6162(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* body1016 in ##sys#check-syntax in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_6162(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6162,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6177,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word)li59),tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6165,a[2]=t4,a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6208,a[2]=((C_word*)t0)[3],a[3]=((C_word)li62),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6264,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6293,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=t1,a[5]=t3,a[6]=t6,a[7]=t7,a[8]=t5,a[9]=t4,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
t9=C_mutate((C_word*)lf[139]+1 /* (set! syntax-error-culprit ...) */,t2);
t10=t8;
f_6293(t10,t9);}
else{
t9=t8;
f_6293(t9,C_SCHEME_UNDEFINED);}}

/* k6291 in body1016 in ##sys#check-syntax in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_6293(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6293,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6298,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t3,a[7]=((C_word*)t0)[9],a[8]=((C_word)li67),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_6298(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in k6291 in body1016 in ##sys#check-syntax in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_6298(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word *a;
loop:
a=C_alloc(19);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6298,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_vectorp(t3))){
t4=(C_word)C_i_vector_ref(t3,C_fix(0));
t5=(C_word)C_block_size(t3);
t6=(C_word)C_fixnum_greaterp(t5,C_fix(1));
t7=(C_truep(t6)?(C_word)C_i_vector_ref(t3,C_fix(1)):C_fix(0));
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6317,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=(C_word)C_eqp(t5,C_fix(1));
if(C_truep(t9)){
t10=t8;
f_6317(t10,C_fix(1));}
else{
t10=(C_word)C_fixnum_greaterp(t5,C_fix(2));
t11=t8;
f_6317(t11,(C_truep(t10)?(C_word)C_i_vector_ref(t3,C_fix(2)):C_fix(99999)));}}
else{
if(C_truep((C_word)C_immp(t3))){
t4=(C_word)C_eqp(t3,t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 638  err */
t5=((C_word*)t0)[7];
f_6177(t5,t1,lf[155]);}}
else{
if(C_truep((C_word)C_i_symbolp(t3))){
t4=t3;
t5=(C_word)C_eqp(t4,lf[57]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_eqp(t4,lf[156]);
if(C_truep(t6)){
/* expand.scm: 642  test */
t7=((C_word*)t0)[5];
f_6165(t7,t1,t2,*((C_word*)lf[157]+1),lf[158]);}
else{
t7=(C_word)C_eqp(t4,lf[159]);
if(C_truep(t7)){
/* expand.scm: 643  test */
t8=((C_word*)t0)[5];
f_6165(t8,t1,t2,*((C_word*)lf[160]+1),lf[161]);}
else{
t8=(C_word)C_eqp(t4,lf[162]);
if(C_truep(t8)){
/* expand.scm: 644  test */
t9=((C_word*)t0)[5];
f_6165(t9,t1,t2,*((C_word*)lf[160]+1),lf[163]);}
else{
t9=(C_word)C_eqp(t4,lf[164]);
if(C_truep(t9)){
/* expand.scm: 645  test */
t10=((C_word*)t0)[5];
f_6165(t10,t1,t2,((C_word*)t0)[4],lf[165]);}
else{
t10=(C_word)C_eqp(t4,lf[166]);
if(C_truep(t10)){
/* expand.scm: 646  test */
t11=((C_word*)t0)[5];
f_6165(t11,t1,t2,*((C_word*)lf[167]+1),lf[168]);}
else{
t11=(C_word)C_eqp(t4,lf[169]);
if(C_truep(t11)){
/* expand.scm: 647  test */
t12=((C_word*)t0)[5];
f_6165(t12,t1,t2,*((C_word*)lf[170]+1),lf[171]);}
else{
t12=(C_word)C_eqp(t4,lf[172]);
if(C_truep(t12)){
/* expand.scm: 648  test */
t13=((C_word*)t0)[5];
f_6165(t13,t1,t2,((C_word*)t0)[3],lf[173]);}
else{
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6495,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li66),tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 650  test */
t14=((C_word*)t0)[5];
f_6165(t14,t1,t2,t13,lf[174]);}}}}}}}}}
else{
if(C_truep((C_word)C_i_pairp(t3))){
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6536,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* expand.scm: 660  walk */
t26=t4;
t27=t5;
t28=t6;
t1=t26;
t2=t27;
t3=t28;
goto loop;}
else{
/* expand.scm: 658  err */
t4=((C_word*)t0)[7];
f_6177(t4,t1,lf[175]);}}
else{
/* expand.scm: 657  err */
t4=((C_word*)t0)[7];
f_6177(t4,t1,lf[176]);}}}}}

/* k6534 in walk in k6291 in body1016 in ##sys#check-syntax in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 661  walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6298(t4,((C_word*)t0)[2],t2,t3);}

/* a6494 in walk in k6291 in body1016 in ##sys#check-syntax in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6495(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6495,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6499,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* expand.scm: 653  lookup */
f_3517(t3,t2,((C_word*)t0)[2]);}
else{
t4=t3;
f_6499(2,t4,C_SCHEME_FALSE);}}

/* k6497 in a6494 in walk in k6291 in body1016 in ##sys#check-syntax in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_symbolp(t1);
t3=(C_truep(t2)?t1:((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(t3,((C_word*)t0)[2]));}

/* k6315 in walk in k6291 in body1016 in ##sys#check-syntax in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_6317(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6317,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6322,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li65),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_6322(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* doloop1129 in k6315 in walk in k6291 in body1016 in ##sys#check-syntax in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_6322(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6322,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[7]))){
/* expand.scm: 631  err */
t5=((C_word*)t0)[6];
f_6177(t5,t1,lf[152]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6341,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
/* expand.scm: 633  err */
t6=((C_word*)t0)[6];
f_6177(t6,t5,lf[153]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_car(t2);
/* expand.scm: 636  walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6298(t7,t5,t6,((C_word*)t0)[2]);}
else{
/* expand.scm: 635  err */
t6=((C_word*)t0)[6];
f_6177(t6,t5,lf[154]);}}}}

/* k6339 in doloop1129 in k6315 in walk in k6291 in body1016 in ##sys#check-syntax in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_6322(t4,((C_word*)t0)[2],t2,t3);}

/* proper-list? in body1016 in ##sys#check-syntax in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6264(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6264,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6270,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_6270(t2));}

/* loop in proper-list? in body1016 in ##sys#check-syntax in k3763 in k3513 in k3509 in k3482 */
static C_word C_fcall f_6270(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
return(t2);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_i_cdr(t1);
t5=t3;
t1=t5;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* lambda-list? in body1016 in ##sys#check-syntax in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6208(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6208,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6212,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 600  ##sys#extended-lambda-list? */
t4=C_retrieve(lf[88]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6210 in lambda-list? in body1016 in ##sys#check-syntax in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6212,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6220,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li61),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6220(t5,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* loop in k6210 in lambda-list? in body1016 in ##sys#check-syntax in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_6220(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6220,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6240,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 603  keyword? */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_cdr(t2);
/* expand.scm: 607  loop */
t8=t1;
t9=t5;
t1=t8;
t2=t9;
goto loop;}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}}

/* k6238 in loop in k6210 in lambda-list? in body1016 in ##sys#check-syntax in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* test in body1016 in ##sys#check-syntax in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_6165(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6165,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6172,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 588  pred */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k6170 in test in body1016 in ##sys#check-syntax in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 588  err */
t2=((C_word*)t0)[3];
f_6177(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in body1016 in ##sys#check-syntax in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_6177(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6177,NULL,3,t0,t1,t2);}
t3=C_retrieve(lf[139]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6181,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 592  get-line-number */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k6179 in err in body1016 in ##sys#check-syntax in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6181,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6188,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6195,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 595  symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6206,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 596  symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}

/* k6204 in k6179 in err in body1016 in ##sys#check-syntax in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 596  string-append */
t2=((C_word*)t0)[4];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[150],t1,lf[151],((C_word*)t0)[2]);}

/* k6193 in k6179 in err in body1016 in ##sys#check-syntax in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6199,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 595  number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}

/* k6197 in k6193 in k6179 in err in body1016 in ##sys#check-syntax in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 595  string-append */
t2=((C_word*)t0)[5];
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[4],lf[147],((C_word*)t0)[3],lf[148],t1,lf[149],((C_word*)t0)[2]);}

/* k6186 in k6179 in err in body1016 in ##sys#check-syntax in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 593  ##sys#syntax-error-hook */
t2=C_retrieve(lf[53]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* get-line-number in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6124(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6124,3,t0,t1,t2);}
if(C_truep(C_retrieve(lf[138]))){
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6146,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 574  ##sys#hash-table-ref */
t5=C_retrieve(lf[144]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[138]),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k6144 in get-line-number in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_i_cdr(t2):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#syntax-error-hook in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6113(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_6113r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6113r(t0,t1,t2);}}

static void C_ccall f_6113r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6121,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 565  ##sys#strip-syntax */
t4=C_retrieve(lf[22]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6119 in ##sys#syntax-error-hook in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[2],C_retrieve(lf[140]),lf[141],t1);}

/* ##sys#expand-curried-define in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6043(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6043,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6046,a[2]=t8,a[3]=t6,a[4]=((C_word)li55),tmp=(C_word)a,a+=5,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6106,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 554  loop */
t11=((C_word*)t8)[1];
f_6046(t11,t10,t2,t3);}

/* k6104 in ##sys#expand-curried-define in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6106,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],t1));}

/* loop in ##sys#expand-curried-define in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_6046(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6046,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_car(t2);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=(C_word)C_i_cdr(t2);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6072,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t9=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t3,C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6099,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t8=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t3,C_SCHEME_END_OF_LIST);}}

/* k6097 in loop in ##sys#expand-curried-define in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6099,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[97],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
/* expand.scm: 553  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6046(t5,((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k6070 in loop in ##sys#expand-curried-define in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6072,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[97],t2));}

/* match-expression in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_5960(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5960,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5963,a[2]=t4,a[3]=t6,a[4]=t8,a[5]=((C_word)li53),tmp=(C_word)a,a+=6,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6041,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 541  mwalk */
t11=((C_word*)t8)[1];
f_5963(t11,t10,t2,t3);}

/* k6039 in match-expression in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));}

/* mwalk in match-expression in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_5963(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5963,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6012,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* expand.scm: 538  mwalk */
t13=t4;
t14=t5;
t15=t6;
t1=t13;
t2=t14;
t3=t15;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t4=(C_word)C_i_assq(t3,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_equalp(t2,t5));}
else{
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[2]))){
t5=(C_word)C_a_i_cons(&a,2,t3,t2);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)((C_word*)t0)[3])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t2,t3));}}}}

/* k6010 in mwalk in match-expression in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_6012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 539  mwalk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5963(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5207(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_5207r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5207r(t0,t1,t2,t3);}}

static void C_ccall f_5207r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5211,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* expand.scm: 415  ##sys#current-environment */
t5=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5211(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5211,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5213,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t7,a[6]=((C_word)li46),tmp=(C_word)a,a+=7,tmp));
t9=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5473,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word)li48),tmp=(C_word)a,a+=7,tmp));
t10=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5650,a[2]=t3,a[3]=t5,a[4]=t1,a[5]=((C_word)li51),tmp=(C_word)a,a+=6,tmp));
/* expand.scm: 522  expand */
t11=((C_word*)t7)[1];
f_5650(t11,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_5650(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5650,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word)li50),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_5656(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in expand in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_5656(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5656,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_i_pairp(t7);
t10=(C_truep(t9)?(C_word)C_i_car(t7):C_SCHEME_FALSE);
t11=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5678,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=t1,a[7]=t6,a[8]=t5,a[9]=t8,a[10]=((C_word*)t0)[4],a[11]=t4,a[12]=t3,a[13]=((C_word*)t0)[5],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t10)){
if(C_truep((C_word)C_i_symbolp(t10))){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5920,a[2]=t10,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 482  lookup */
f_3517(t12,t10,((C_word*)t0)[5]);}
else{
t12=t11;
f_5678(t12,C_SCHEME_FALSE);}}
else{
t12=t11;
f_5678(t12,C_SCHEME_FALSE);}}
else{
/* expand.scm: 476  fini */
t7=((C_word*)((C_word*)t0)[2])[1];
f_5213(t7,t1,t3,t4,t5,t6,t2);}}

/* k5918 in loop in expand in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_5678(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k5676 in loop in expand in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_5678(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5678,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(C_word)C_eqp(lf[117],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5696,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 485  ##sys#check-syntax */
t4=C_retrieve(lf[64]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t3,lf[117],((C_word*)t0)[5],lf[133],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t3=(C_word)C_eqp(lf[124],t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5822,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 507  ##sys#check-syntax */
t5=C_retrieve(lf[64]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,lf[124],((C_word*)t0)[5],lf[134],((C_word*)t0)[13]);}
else{
t4=(C_word)C_eqp(lf[118],t1);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5834,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 510  ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc7)C_retrieve_proc(t6))(7,t6,t5,lf[118],((C_word*)t0)[5],lf[135],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t5=(C_word)C_eqp(lf[116],t1);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5862,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 513  ##sys#check-syntax */
t7=C_retrieve(lf[64]);
((C_proc7)C_retrieve_proc(t7))(7,t7,t6,lf[116],((C_word*)t0)[5],lf[136],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t6=(C_word)C_i_memq(t1,((C_word*)t0)[12]);
t7=(C_truep(t6)?t6:(C_word)C_i_memq(t1,((C_word*)t0)[8]));
if(C_truep(t7)){
/* expand.scm: 516  fini */
t8=((C_word*)((C_word*)t0)[2])[1];
f_5213(t8,((C_word*)t0)[6],((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[3]);}
else{
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5888,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[2],a[11]=((C_word*)t0)[5],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 518  ##sys#expand-0 */
t9=C_retrieve(lf[38]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,((C_word*)t0)[5],((C_word*)t0)[13]);}}}}}}
else{
/* expand.scm: 483  fini */
t2=((C_word*)((C_word*)t0)[2])[1];
f_5213(t2,((C_word*)t0)[6],((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[3]);}}

/* k5886 in k5676 in loop in expand in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5888,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[11],t1);
if(C_truep(t2)){
/* expand.scm: 520  fini */
t3=((C_word*)((C_word*)t0)[10])[1];
f_5213(t3,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
/* expand.scm: 521  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5656(t4,((C_word*)t0)[9],t3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* k5860 in k5676 in loop in expand in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5869,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 514  ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* k5867 in k5860 in k5676 in loop in expand in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 514  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5656(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5832 in k5676 in loop in expand in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5834,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
t4=(C_word)C_i_caddr(((C_word*)t0)[9]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[7]);
/* expand.scm: 511  loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_5656(t6,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3,t5);}

/* k5820 in k5676 in loop in expand in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 508  fini/syntax */
t2=((C_word*)((C_word*)t0)[8])[1];
f_5473(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5694 in k5676 in loop in expand in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5696,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5701,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,a[10]=((C_word)li49),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_5701(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2 in k5694 in k5676 in loop in expand in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_5701(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5701,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5748,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 497  ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc7)C_retrieve_proc(t6))(7,t6,t5,lf[117],t2,lf[129],C_SCHEME_FALSE,((C_word*)t0)[8]);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5770,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 501  ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc7)C_retrieve_proc(t6))(7,t6,t5,lf[117],t2,lf[130],C_SCHEME_FALSE,((C_word*)t0)[8]);}}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5714,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 489  ##sys#check-syntax */
t5=C_retrieve(lf[64]);
((C_proc7)C_retrieve_proc(t5))(7,t5,t4,lf[117],t2,lf[132],C_SCHEME_FALSE,((C_word*)t0)[8]);}}

/* k5712 in loop2 in k5694 in k5676 in loop in expand in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5714,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(C_word)C_i_cddr(((C_word*)t0)[8]);
t4=(C_word)C_i_pairp(t3);
t5=(C_truep(t4)?(C_word)C_i_caddr(((C_word*)t0)[8]):lf[131]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[7]);
/* expand.scm: 490  loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_5656(t7,((C_word*)t0)[5],((C_word*)t0)[4],t2,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5768 in loop2 in k5694 in k5676 in loop in expand in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5770,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[10]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(C_word)C_i_cdr(((C_word*)t0)[10]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5797,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t4,tmp=(C_word)a,a+=10,tmp);
t6=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t7=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}

/* k5795 in k5768 in loop2 in k5694 in k5676 in loop in expand in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5797,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[97],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[8]);
/* expand.scm: 502  loop */
t5=((C_word*)((C_word*)t0)[7])[1];
f_5656(t5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5746 in loop2 in k5694 in k5676 in loop in expand in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5748,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5759,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 498  macro-alias */
f_3535(t2,lf[117],((C_word*)t0)[2]);}

/* k5757 in k5746 in loop2 in k5694 in k5676 in loop in expand in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5759,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5763,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* expand.scm: 499  ##sys#expand-curried-define */
t4=C_retrieve(lf[128]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k5761 in k5757 in k5746 in loop2 in k5694 in k5676 in loop in expand in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5763,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* expand.scm: 498  loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5701(t3,((C_word*)t0)[2],t2);}

/* fini/syntax in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_5473(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5473,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5481,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5483,a[2]=t9,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li47),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_5483(t11,t7,t6,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in fini/syntax in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_5483(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(19);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5483,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5498,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 457  macro-alias */
f_3535(t5,lf[123],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5529,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_length(t7);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(C_fix(3),t8))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5632,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 462  caar */
t10=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t2);}
else{
t9=t5;
f_5529(t9,C_SCHEME_FALSE);}}
else{
t7=t5;
f_5529(t7,C_SCHEME_FALSE);}}
else{
/* expand.scm: 459  loop */
t12=t1;
t13=t2;
t14=t3;
t15=C_SCHEME_TRUE;
t1=t12;
t2=t13;
t3=t14;
t4=t15;
goto loop;}}}

/* k5630 in loop in fini/syntax in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5632,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5618,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5628,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 463  caar */
t4=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
f_5529(t2,C_SCHEME_FALSE);}}

/* k5626 in k5630 in loop in fini/syntax in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 463  lookup */
f_3517(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5616 in k5630 in loop in fini/syntax in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5621,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_5621(2,t3,t1);}
else{
/* expand.scm: 463  caar */
t3=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k5619 in k5616 in k5630 in loop in fini/syntax in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5529(t2,(C_word)C_eqp(lf[124],t1));}

/* k5527 in loop in fini/syntax in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_5529(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5529,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5547,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5561,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 468  caadr */
t7=*((C_word*)lf[127]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t6=t4;
f_5547(t6,t2);}}
else{
/* expand.scm: 472  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5483(t2,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[5],C_SCHEME_TRUE);}}

/* k5559 in k5527 in loop in fini/syntax in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5573,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 468  macro-alias */
f_3535(t2,lf[126],((C_word*)t0)[2]);}

/* k5571 in k5559 in k5527 in loop in fini/syntax in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5573,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5581,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 468  cdadr */
t3=*((C_word*)lf[125]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5579 in k5571 in k5559 in k5527 in loop in fini/syntax in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5581,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5585,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k5583 in k5579 in k5571 in k5559 in k5527 in loop in fini/syntax in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5585,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
f_5547(t6,(C_word)C_a_i_cons(&a,2,lf[124],t5));}

/* k5545 in k5527 in loop in fini/syntax in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_5547(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5547,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* expand.scm: 465  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5483(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k5496 in loop in fini/syntax in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5498,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5506,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5514,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 458  reverse */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5512 in k5496 in loop in fini/syntax in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 458  map */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[122]+1),t1);}

/* k5504 in k5496 in loop in fini/syntax in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5510,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5508 in k5504 in k5496 in loop in fini/syntax in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5510,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k5479 in fini/syntax in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 454  fini */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5213(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_5213(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5213,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_nullp(t2);
t8=(C_truep(t7)?(C_word)C_i_nullp(t4):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5225,a[2]=t6,a[3]=t10,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li41),tmp=(C_word)a,a+=8,tmp));
t12=((C_word*)t10)[1];
f_5225(t12,t1,t6,C_SCHEME_END_OF_LIST);}
else{
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5324,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],a[7]=t6,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 433  reverse */
t10=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t2);}}

/* k5322 in fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5346,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5453,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5465,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,*((C_word*)lf[51]+1),t1,((C_word*)t0)[3]);}

/* k5463 in k5322 in fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 436  ##sys#map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5452 in k5322 in fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5453(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5453,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,lf[121]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}

/* k5344 in k5322 in fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5350,a[2]=((C_word*)t0)[9],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5354,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5435,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5451,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 438  reverse */
t6=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k5449 in k5344 in k5322 in fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 438  map */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5434 in k5344 in k5322 in fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5435(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5435,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[71],t5));}

/* k5352 in k5344 in k5322 in fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5358,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5362,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5368,a[2]=((C_word*)t0)[5],a[3]=((C_word)li43),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5429,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 448  reverse */
t6=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k5427 in k5352 in k5344 in k5322 in fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5433,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 449  reverse */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5431 in k5427 in k5352 in k5344 in k5322 in fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 439  map */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5367 in k5352 in k5344 in k5322 in fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5368,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5372,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 440  ##sys#map */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[18]),t2);}

/* k5370 in a5367 in k5352 in k5344 in k5322 in fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5372,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[97],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5399,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5403,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5405,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 445  map */
t8=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,t7,((C_word*)t0)[2],t1);}

/* a5404 in k5370 in a5367 in k5352 in k5344 in k5322 in fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5405(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5405,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[71],t5));}

/* k5401 in k5370 in a5367 in k5352 in k5344 in k5322 in fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k5397 in k5370 in a5367 in k5352 in k5344 in k5322 in fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5399,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[97],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[120],t5));}

/* k5360 in k5352 in k5344 in k5322 in fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5366,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5364 in k5360 in k5352 in k5344 in k5322 in fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5356 in k5352 in k5344 in k5322 in fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5348 in k5344 in k5322 in fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5350,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[59],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5330,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[119],t5);
/* expand.scm: 451  dd */
t7=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t7))(3,t7,t4,t6);}

/* k5328 in k5348 in k5344 in k5322 in fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* loop in fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_5225(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5225,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5248,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_i_car(t4);
if(C_truep((C_word)C_i_symbolp(t6))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5314,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 427  lookup */
f_3517(t7,t6,((C_word*)t0)[4]);}
else{
t7=t5;
f_5248(t7,C_SCHEME_FALSE);}}
else{
t6=t5;
f_5248(t6,C_SCHEME_FALSE);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5239,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 421  macro-alias */
f_3535(t4,lf[116],((C_word*)t0)[4]);}}

/* k5237 in loop in fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5239,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k5312 in loop in fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5314,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[117]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
f_5248(t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5307,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 428  lookup */
f_3517(t4,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k5305 in k5312 in loop in fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_5248(t3,(C_word)C_eqp(t2,lf[118]));}

/* k5246 in loop in fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_5248(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5248,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5255,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 430  macro-alias */
f_3535(t2,lf[116],((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[5]);
/* expand.scm: 432  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5225(t4,((C_word*)t0)[9],t2,t3);}}

/* k5253 in k5246 in loop in fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5259,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5263,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 431  reverse */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5261 in k5253 in k5246 in loop in fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5263,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5271,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 431  expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5650(t3,t2,((C_word*)t0)[2]);}

/* k5269 in k5261 in k5253 in k5246 in loop in fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5271,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* expand.scm: 431  ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5257 in k5253 in k5246 in loop in fini in k5209 in ##sys#canonicalize-body in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5259,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4617,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4620,a[2]=t2,a[3]=t4,a[4]=((C_word)li37),tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4637,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=t6,a[6]=t3,a[7]=((C_word*)t0)[2],a[8]=t10,a[9]=t8,tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 322  macro-alias */
f_3535(t11,lf[113],t5);}

/* k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4640,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 324  macro-alias */
f_3535(t2,lf[112],((C_word*)t0)[4]);}

/* k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4643,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 325  macro-alias */
f_3535(t2,lf[111],((C_word*)t0)[4]);}

/* k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* expand.scm: 326  macro-alias */
f_3535(t2,lf[110],((C_word*)t0)[4]);}

/* k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4649,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* expand.scm: 327  macro-alias */
f_3535(t2,lf[58],((C_word*)t0)[4]);}

/* k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4649,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4654,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word)li39),tmp=(C_word)a,a+=15,tmp));
t5=((C_word*)t3)[1];
f_4654(t5,((C_word*)t0)[3],C_fix(0),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);}

/* loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_4654(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4654,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t6))){
t7=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4668,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t5,a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=t4,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)((C_word*)t0)[13])[1])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4921,a[2]=((C_word*)t0)[13],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 335  reverse */
t9=((C_word*)t0)[8];
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t3);}
else{
/* expand.scm: 335  reverse */
t8=((C_word*)t0)[8];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}
else{
if(C_truep((C_word)C_i_symbolp(t6))){
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(2)))){
/* expand.scm: 363  err */
t7=((C_word*)t0)[4];
f_4620(t7,t1,lf[99]);}
else{
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4942,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t8=((C_word*)((C_word*)t0)[13])[1];
if(C_truep(t8)){
t9=t7;
f_4942(t9,C_SCHEME_UNDEFINED);}
else{
t9=C_mutate(((C_word *)((C_word*)t0)[13])+1,t6);
t10=t7;
f_4942(t10,t9);}}}
else{
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4965,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[4],a[8]=t3,a[9]=t1,a[10]=((C_word*)t0)[3],a[11]=t2,a[12]=t6,a[13]=t7,tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_symbolp(t7))){
/* expand.scm: 372  lookup */
f_3517(t8,t7,((C_word*)t0)[2]);}
else{
t9=t8;
f_4965(2,t9,C_SCHEME_FALSE);}}
else{
/* expand.scm: 369  err */
t7=((C_word*)t0)[4];
f_4620(t7,t1,lf[109]);}}}}

/* k4963 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[64],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4965,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[13]);
t3=(C_word)C_i_cdr(((C_word*)t0)[12]);
t4=(C_word)C_eqp(t2,lf[90]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4980,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
t6=((C_word*)((C_word*)t0)[6])[1];
if(C_truep(t6)){
t7=t5;
f_4980(t7,C_SCHEME_UNDEFINED);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4999,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 376  macro-alias */
f_3535(t7,lf[101],((C_word*)t0)[5]);}}
else{
t5=(C_word)C_eqp(t2,lf[89]);
if(C_truep(t5)){
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[11],C_fix(1)))){
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5017,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[4],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t7=(C_word)C_i_car(t3);
t8=t6;
f_5017(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_5017(t7,C_SCHEME_FALSE);}}
else{
/* expand.scm: 388  err */
t6=((C_word*)t0)[7];
f_4620(t6,((C_word*)t0)[9],lf[103]);}}
else{
t6=(C_word)C_eqp(t2,lf[91]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5063,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t8=((C_word*)((C_word*)t0)[6])[1];
if(C_truep(t8)){
t9=t7;
f_5063(t9,C_SCHEME_UNDEFINED);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5082,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 390  macro-alias */
f_3535(t9,lf[101],((C_word*)t0)[5]);}}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t7=((C_word*)t0)[11];
switch(t7){
case C_fix(0):
t8=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
/* expand.scm: 397  loop */
t9=((C_word*)((C_word*)t0)[10])[1];
f_4654(t9,((C_word*)t0)[9],C_fix(0),t8,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t3);
case C_fix(1):
t8=(C_word)C_a_i_list(&a,2,t2,C_SCHEME_FALSE);
t9=(C_word)C_a_i_cons(&a,2,t8,((C_word*)t0)[3]);
/* expand.scm: 398  loop */
t10=((C_word*)((C_word*)t0)[10])[1];
f_4654(t10,((C_word*)t0)[9],C_fix(1),((C_word*)t0)[8],t9,C_SCHEME_END_OF_LIST,t3);
case C_fix(2):
/* expand.scm: 399  err */
t8=((C_word*)t0)[7];
f_4620(t8,((C_word*)t0)[9],lf[105]);
default:
t8=(C_word)C_a_i_list(&a,1,t2);
t9=(C_word)C_a_i_cons(&a,2,t8,((C_word*)t0)[2]);
/* expand.scm: 400  loop */
t10=((C_word*)((C_word*)t0)[10])[1];
f_4654(t10,((C_word*)t0)[9],C_fix(3),((C_word*)t0)[8],((C_word*)t0)[3],t9,t3);}}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5144,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],a[7]=t2,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t8=(C_word)C_i_length(t2);
t9=t7;
f_5144(t9,(C_word)C_eqp(C_fix(2),t8));}
else{
t8=t7;
f_5144(t8,C_SCHEME_FALSE);}}}}}}

/* k5142 in k4963 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_5144(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5144,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
switch(t2){
case C_fix(0):
/* expand.scm: 403  err */
t3=((C_word*)t0)[9];
f_4620(t3,((C_word*)t0)[8],lf[106]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
/* expand.scm: 404  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4654(t4,((C_word*)t0)[8],C_fix(1),((C_word*)t0)[4],t3,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
case C_fix(2):
/* expand.scm: 405  err */
t3=((C_word*)t0)[9];
f_4620(t3,((C_word*)t0)[8],lf[107]);
default:
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[2]);
/* expand.scm: 406  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4654(t4,((C_word*)t0)[8],C_fix(3),((C_word*)t0)[4],((C_word*)t0)[6],t3,((C_word*)t0)[3]);}}
else{
/* expand.scm: 407  err */
t2=((C_word*)t0)[9];
f_4620(t2,((C_word*)t0)[8],lf[108]);}}

/* k5080 in k4963 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_5082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5063(t3,t2);}

/* k5061 in k4963 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_5063(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[8],C_fix(3)))){
/* expand.scm: 392  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_4654(t2,((C_word*)t0)[6],C_fix(3),((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* expand.scm: 393  err */
t2=((C_word*)t0)[2];
f_4620(t2,((C_word*)t0)[6],lf[104]);}}

/* k5015 in k4963 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_5017(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5017,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5020,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t3)){
t4=t2;
f_5020(t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[9]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=t2;
f_5020(t6,t5);}}
else{
/* expand.scm: 387  err */
t2=((C_word*)t0)[2];
f_4620(t2,((C_word*)t0)[6],lf[102]);}}

/* k5018 in k5015 in k4963 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_5020(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* expand.scm: 386  loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_4654(t5,((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t4);}

/* k4997 in k4963 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4980(t3,t2);}

/* k4978 in k4963 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_4980(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[7],C_fix(0));
if(C_truep(t2)){
/* expand.scm: 378  loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4654(t3,((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* expand.scm: 379  err */
t3=((C_word*)t0)[2];
f_4620(t3,((C_word*)t0)[5],lf[100]);}}

/* k4940 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_4942(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
/* expand.scm: 367  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4654(t3,((C_word*)t0)[4],C_fix(4),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k4919 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 335  ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k4666 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4672,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[7]))){
t3=t2;
f_4672(t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4835,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4841,a[2]=((C_word*)t0)[11],a[3]=((C_word)li38),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4914,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 347  reverse */
t6=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}}

/* k4912 in k4666 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4840 in k4666 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4841(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4841,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4910,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
/* expand.scm: 319  string->keyword */
t6=C_retrieve(lf[98]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k4908 in a4840 in k4666 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4910,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[95],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4872,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4876,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4894,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t9=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,C_SCHEME_END_OF_LIST);}
else{
t7=t5;
f_4876(t7,C_SCHEME_END_OF_LIST);}}

/* k4892 in k4908 in a4840 in k4666 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4894,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[97],t2);
t4=((C_word*)t0)[2];
f_4876(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k4874 in k4908 in a4840 in k4666 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_4876(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4870 in k4908 in a4840 in k4666 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4872,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[96],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k4833 in k4666 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4835,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4839,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4837 in k4833 in k4666 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4839,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_4672(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k4670 in k4666 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_4672(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4672,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4675,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[10]))){
t3=t2;
f_4675(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[10],a[8]=t1,a[9]=t2,a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
t4=((C_word*)((C_word*)t0)[6])[1];
if(C_truep(t4)){
t5=t3;
f_4684(t5,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t5=(C_word)C_i_cdr(((C_word*)t0)[10]);
t6=t3;
f_4684(t6,(C_word)C_i_nullp(t5));}
else{
t5=t3;
f_4684(t5,C_SCHEME_FALSE);}}}}

/* k4682 in k4670 in k4666 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_4684(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4684,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4711,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 352  caar */
t3=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_nullp(((C_word*)t0)[5]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4756,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 356  reverse */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[7]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4779,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4787,a[2]=t4,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 359  reverse */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}}}

/* k4785 in k4682 in k4670 in k4666 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4787,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_truep(t2)?t2:((C_word*)((C_word*)t0)[3])[1]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* expand.scm: 359  ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k4777 in k4682 in k4670 in k4666 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4783,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4781 in k4777 in k4682 in k4670 in k4666 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4783,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
f_4675(t5,(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST));}

/* k4754 in k4682 in k4670 in k4666 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4760,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4758 in k4754 in k4682 in k4670 in k4666 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4760,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
f_4675(t5,(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST));}

/* k4709 in k4682 in k4670 in k4666 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4731,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 352  cadar */
t3=*((C_word*)lf[94]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4729 in k4709 in k4682 in k4670 in k4666 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4731,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4703,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t9=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4701 in k4729 in k4709 in k4682 in k4670 in k4666 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4703,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_4675(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k4673 in k4670 in k4666 in loop in k4647 in k4644 in k4641 in k4638 in k4635 in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_4675(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 334  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* err in ##sys#expand-extended-lambda-list in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_4620(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4620,NULL,3,t0,t1,t2);}
/* expand.scm: 318  errh */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#extended-lambda-list? in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4574(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4574,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4580,a[2]=t4,a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4580(t6,t1,t2);}

/* loop in ##sys#extended-lambda-list? in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_4580(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4580,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(t3,lf[89]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4599,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_4599(t6,t4);}
else{
t6=(C_word)C_eqp(t3,lf[90]);
t7=t5;
f_4599(t7,(C_truep(t6)?t6:(C_word)C_eqp(t3,lf[91])));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k4597 in loop in ##sys#extended-lambda-list? in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_4599(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 312  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4580(t3,((C_word*)t0)[4],t2);}}

/* ##sys#expand in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4521(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4521r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4521r(t0,t1,t2,t3);}}

static void C_ccall f_4521r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4525,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* expand.scm: 285  ##sys#current-environment */
t5=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4525(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4523 in ##sys#expand in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4525,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4530,a[2]=t3,a[3]=t1,a[4]=((C_word)li33),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4530(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k4523 in ##sys#expand in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_4530(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4530,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4536,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li31),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4542,a[2]=((C_word*)t0)[2],a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a4541 in loop in k4523 in ##sys#expand in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4542,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* expand.scm: 289  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4530(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* a4535 in loop in k4523 in ##sys#expand in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4536,2,t0,t1);}
/* expand.scm: 287  ##sys#expand-0 */
t2=C_retrieve(lf[38]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#alias-global-hook in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4431(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4431,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4434,a[2]=t3,a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4467,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 265  ##sys#qualified-symbol? */
t6=C_retrieve(lf[19]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k4465 in ##sys#alias-global-hook in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4467,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 266  ##sys#get */
t3=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[83]);}}

/* k4468 in k4465 in ##sys#alias-global-hook in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4470,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4476,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 268  dm */
t3=C_retrieve2(lf[7],"dm");
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[81],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4482,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 270  ##sys#get */
t3=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[85]);}}

/* k4480 in k4468 in k4465 in ##sys#alias-global-hook in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4482,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4485,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 271  dm */
t3=C_retrieve2(lf[7],"dm");
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[82],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4519,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 273  ##sys#current-environment */
t3=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}

/* k4517 in k4480 in k4468 in k4465 in ##sys#alias-global-hook in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4519,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4494,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 275  dm */
t4=C_retrieve2(lf[7],"dm");
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[84],((C_word*)t0)[4]);}
else{
/* expand.scm: 280  mrename */
t3=((C_word*)t0)[3];
f_4434(t3,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* k4492 in k4517 in k4480 in k4468 in k4465 in ##sys#alias-global-hook in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4494,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t2))){
/* expand.scm: 278  mrename */
t3=((C_word*)t0)[4];
f_4434(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4509,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 279  ##sys#get */
t4=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[83]);}}

/* k4507 in k4492 in k4517 in k4480 in k4468 in k4465 in ##sys#alias-global-hook in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k4483 in k4480 in k4468 in k4465 in ##sys#alias-global-hook in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4474 in k4468 in k4465 in ##sys#alias-global-hook in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* mrename in ##sys#alias-global-hook in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_4434(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4434,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4438,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 259  ##sys#current-module */
t4=C_retrieve(lf[80]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k4436 in mrename in ##sys#alias-global-hook in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4438,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4444,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=f_9473(t1);
/* expand.scm: 261  dm */
t4=C_retrieve2(lf[7],"dm");
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[78],((C_word*)t0)[3],lf[79],t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* k4442 in k4436 in mrename in ##sys#alias-global-hook in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4447,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4447(2,t3,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 262  ##sys#register-undefined */
t3=C_retrieve(lf[77]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[5]);}}

/* k4445 in k4442 in k4436 in mrename in ##sys#alias-global-hook in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_9473(((C_word*)t0)[4]);
/* expand.scm: 263  ##sys#module-rename */
t3=C_retrieve(lf[73]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* ##sys#module-rename in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4413(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4413,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4421,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(1));
/* expand.scm: 252  string-append */
t7=*((C_word*)lf[42]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,t4,t5,lf[75],t6);}

/* k4419 in ##sys#module-rename in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 251  ##sys#string->symbol */
t2=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_3931(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3931,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3934,a[2]=t3,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4113,a[2]=t4,a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t6))){
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4230,a[2]=t5,a[3]=t2,a[4]=t3,a[5]=t1,a[6]=t7,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 217  lookup */
f_3517(t8,t6,t3);}
else{
/* expand.scm: 245  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}
else{
/* expand.scm: 246  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}

/* k4228 in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4230,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[7]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4236,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t4)[1]))){
t6=t5;
f_4236(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4397,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4404,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 219  ##sys#macro-environment */
t8=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}}

/* k4402 in k4228 in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 219  lookup */
f_3517(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k4395 in k4228 in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(t1)?t1:((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4236(t4,t3);}

/* k4234 in k4228 in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_4236(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4236,NULL,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[8])[1];
if(C_truep((C_truep((C_word)C_eqp(t2,lf[58]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,lf[59]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4245,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 221  ##sys#check-syntax */
t4=C_retrieve(lf[64]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t3,lf[58],((C_word*)t0)[7],lf[66],C_SCHEME_FALSE,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4338,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=((C_word*)((C_word*)t0)[8])[1];
if(C_truep((C_truep((C_word)C_eqp(t4,lf[69]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[71]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t5=(C_word)C_i_car(((C_word*)t0)[7]);
t6=t3;
f_4338(t6,(C_word)C_i_pairp(t5));}
else{
t5=t3;
f_4338(t5,C_SCHEME_FALSE);}}
else{
t5=t3;
f_4338(t5,C_SCHEME_FALSE);}}}

/* k4336 in k4234 in k4228 in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_4338(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4338,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4344,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 238  ##sys#check-syntax */
t4=C_retrieve(lf[64]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t3,lf[69],((C_word*)t0)[8],lf[70],C_SCHEME_FALSE,((C_word*)t0)[6]);}
else{
/* expand.scm: 244  expand */
t2=((C_word*)t0)[5];
f_4113(t2,((C_word*)t0)[7],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}}

/* k4342 in k4336 in k4234 in k4228 in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4351,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,2,lf[67],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
t7=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* expand.scm: 240  append */
t8=*((C_word*)lf[68]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,t2,t5,t6,t7);}

/* k4349 in k4342 in k4336 in k4234 in k4228 in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 239  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k4243 in k4234 in k4228 in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4245,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4257,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 224  ##sys#check-syntax */
t4=C_retrieve(lf[64]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t3,lf[58],((C_word*)t0)[5],lf[65],C_SCHEME_FALSE,((C_word*)t0)[3]);}
else{
/* expand.scm: 233  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k4255 in k4243 in k4234 in k4228 in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4257,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4315,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4325,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a4324 in k4255 in k4243 in k4234 in k4228 in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4325(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4325,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k4313 in k4255 in k4243 in k4234 in k4228 in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4319,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k4317 in k4313 in k4255 in k4243 in k4234 in k4228 in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4319,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[60],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[61],t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4279,a[2]=((C_word*)t0)[3],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4283,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 231  ##sys#map */
t12=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,*((C_word*)lf[63]+1),((C_word*)t0)[2]);}

/* k4281 in k4317 in k4313 in k4255 in k4243 in k4234 in k4228 in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4277 in k4317 in k4313 in k4255 in k4243 in k4234 in k4228 in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4279,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[62],t2);
/* expand.scm: 226  values */
C_values(4,0,((C_word*)t0)[2],t3,C_SCHEME_TRUE);}

/* expand in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_4113(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4113,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4117,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4170,a[2]=t4,a[3]=t5,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 198  get */
t7=C_retrieve(lf[24]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,lf[12]);}

/* k4168 in expand in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4173,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_symbolp(t1);
t4=t2;
f_4173(t4,(C_truep(t3)?t1:lf[14]));}
else{
t3=t2;
f_4173(t3,lf[57]);}}

/* k4171 in k4168 in expand in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_4173(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4173,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4185,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4195,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4199,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[2]);
/* expand.scm: 203  map-se */
f_3584(t4,t5);}
else{
t3=t2;
f_4185(t3,((C_word*)t0)[2]);}}

/* k4197 in k4171 in k4168 in expand in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4193 in k4171 in k4168 in expand in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4195,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4185(t2,(C_word)C_a_i_cons(&a,2,lf[56],t1));}

/* k4183 in k4171 in k4168 in expand in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_4185(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4185,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[55],t5);
/* expand.scm: 196  dd */
t7=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t7))(3,t7,((C_word*)t0)[2],t6);}

/* k4115 in expand in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4117,2,t0,t1);}
if(C_truep((C_word)C_i_listp(((C_word*)t0)[6]))){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4139,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* expand.scm: 210  call-handler */
t5=((C_word*)t0)[3];
f_3934(t5,t2,((C_word*)t0)[2],t3,((C_word*)t0)[6],t4);}
else{
/* expand.scm: 212  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[6],C_SCHEME_FALSE);}}
else{
/* expand.scm: 206  ##sys#syntax-error-hook */
t2=C_retrieve(lf[53]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[54],((C_word*)t0)[6]);}}

/* k4137 in k4115 in expand in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 208  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* call-handler in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_3934(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3934,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3938,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 163  dd */
t7=C_retrieve2(lf[6],"dd");
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,lf[52],t2);}

/* k3936 in call-handler in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_3938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3941,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4107,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4111,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 164  map-se */
f_3584(t4,((C_word*)t0)[3]);}

/* k4109 in k3936 in call-handler in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4105 in k3936 in call-handler in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4107,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[50],t1);
/* expand.scm: 164  dd */
t3=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k3939 in k3936 in call-handler in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_3941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3947,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li23),tmp=(C_word)a,a+=8,tmp);
/* call-with-current-continuation */
t4=*((C_word*)lf[49]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* a3948 in k3939 in k3936 in call-handler in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_3949(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3949,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3955,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word)li18),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4062,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word)li22),tmp=(C_word)a,a+=9,tmp);
/* with-exception-handler */
t5=C_retrieve(lf[48]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a4061 in a3948 in k3939 in k3936 in call-handler in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4068,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li19),tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4089,a[2]=((C_word*)t0)[2],a[3]=((C_word)li21),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a4088 in a4061 in a3948 in k3939 in k3936 in call-handler in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4089(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4089r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4089r(t0,t1,t2);}}

static void C_ccall f_4089r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4095,a[2]=t2,a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp);
/* k261266 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4094 in a4088 in a4061 in a3948 in k3939 in k3936 in call-handler in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4095,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4067 in a4061 in a3948 in k3939 in k3936 in call-handler in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4072,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 192  handler */
t3=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4070 in a4067 in a4061 in a3948 in k3939 in k3936 in call-handler in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4072,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4075,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[47],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4);
/* expand.scm: 193  dd */
t6=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t6))(3,t6,t2,t5);}

/* k4073 in k4070 in a4067 in a4061 in a3948 in k3939 in k3936 in call-handler in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a3954 in a3948 in k3939 in k3936 in call-handler in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_3955(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3955,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3961,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li17),tmp=(C_word)a,a+=5,tmp);
/* k261266 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3960 in a3954 in a3948 in k3939 in k3936 in call-handler in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_3961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3969,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3972,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[3],lf[40]))){
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t5=t3;
f_3972(t5,(C_word)C_i_memq(lf[46],t4));}
else{
t4=t3;
f_3972(t4,C_SCHEME_FALSE);}}

/* k3970 in a3960 in a3954 in a3948 in k3939 in k3936 in call-handler in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_3972(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3972,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3983,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3989,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word)li16),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3989(t8,t3,t4);}
else{
t2=((C_word*)t0)[3];
f_3969(t2,((C_word*)t0)[4]);}}

/* copy in k3970 in a3960 in a3954 in a3948 in k3939 in k3936 in call-handler in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_3989(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3989,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4008,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_equalp(lf[45],t3))){
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_i_car(t4);
t7=t5;
f_4008(t7,(C_word)C_i_stringp(t6));}
else{
t6=t5;
f_4008(t6,C_SCHEME_FALSE);}}
else{
t6=t5;
f_4008(t6,C_SCHEME_FALSE);}}}

/* k4006 in copy in k3970 in a3960 in a3954 in a3948 in k3939 in k3936 in call-handler in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_4008(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4008,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4019,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* expand.scm: 184  string-append */
t5=*((C_word*)lf[42]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,lf[43],t3,lf[44],t4);}
else{
/* expand.scm: 190  copy */
t2=((C_word*)((C_word*)t0)[2])[1];
f_3989(t2,((C_word*)t0)[4],((C_word*)t0)[5]);}}

/* k4017 in k4006 in copy in k3970 in a3960 in a3954 in a3948 in k3939 in k3936 in call-handler in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_4019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4019,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[41],t3));}

/* k3981 in k3970 in a3960 in a3954 in a3948 in k3939 in k3936 in call-handler in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_3983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3983,2,t0,t1);}
t2=((C_word*)t0)[3];
f_3969(t2,(C_word)C_a_i_record(&a,3,lf[40],((C_word*)t0)[2],t1));}

/* k3967 in a3960 in a3954 in a3948 in k3939 in k3936 in call-handler in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_3969(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 168  ##sys#abort */
t2=C_retrieve(lf[39]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3945 in k3939 in k3936 in call-handler in ##sys#expand-0 in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_3947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* undefine-macro! in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_3922(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3922,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[37]);
/* expand.scm: 156  ##sys#unregister-macro */
t4=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}

/* ##sys#unregister-macro in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_3871(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3871,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3879,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3883,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 149  ##sys#macro-environment */
t5=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k3881 in ##sys#unregister-macro in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_3883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3883,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3885,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3885(t5,((C_word*)t0)[2],t1);}

/* loop in k3881 in ##sys#unregister-macro in k3763 in k3513 in k3509 in k3482 */
static void C_fcall f_3885(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3885,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3920,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 151  caar */
t4=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k3918 in loop in k3881 in ##sys#unregister-macro in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_3920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3920,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[5],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cdr(((C_word*)t0)[3]));}
else{
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3912,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 152  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_3885(t6,t4,t5);}}

/* k3910 in k3918 in loop in k3881 in ##sys#unregister-macro in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_3912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3912,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3877 in ##sys#unregister-macro in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_3879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 147  ##sys#macro-environment */
t2=C_retrieve(lf[29]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* macro? in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_3815(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3815r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3815r(t0,t1,t2,t3);}}

static void C_ccall f_3815r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3819,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* expand.scm: 138  ##sys#current-environment */
t5=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3819(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3817 in macro? in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_3819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3819,2,t0,t1);}
t2=(C_word)C_i_check_symbol_2(((C_word*)t0)[3],lf[34]);
t3=(C_word)C_i_check_list_2(t1,lf[34]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3828,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 141  lookup */
f_3517(t4,((C_word*)t0)[3],t1);}

/* k3826 in k3817 in macro? in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_3828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3828,2,t0,t1);}
t2=(C_word)C_i_pairp(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3837,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3847,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 143  ##sys#macro-environment */
t5=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k3845 in k3826 in k3817 in macro? in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_3847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 143  lookup */
f_3517(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3835 in k3826 in k3817 in macro? in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_3837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_i_pairp(t1):C_SCHEME_FALSE));}

/* ##sys#copy-macro in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_3802(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3802,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3806,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3813,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 135  ##sys#macro-environment */
t6=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k3811 in ##sys#copy-macro in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_3813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 135  lookup */
f_3517(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3804 in ##sys#copy-macro in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_3806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[3],C_retrieve(lf[32]),((C_word*)t0)[2],t1);}

/* ##sys#extend-macro-environment in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_3769(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3769,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3773,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 124  ##sys#macro-environment */
t6=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k3771 in ##sys#extend-macro-environment in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_3773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3776,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 125  lookup */
f_3517(t2,((C_word*)t0)[2],t1);}

/* k3774 in k3771 in ##sys#extend-macro-environment in k3763 in k3513 in k3509 in k3482 */
static void C_ccall f_3776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3776,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_set_car(t1,((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(t1);
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_car(t3,((C_word*)t0)[4]));}
else{
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[2]);
/* expand.scm: 130  ##sys#macro-environment */
t4=C_retrieve(lf[29]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[5],t3);}}

/* ##sys#strip-syntax in k3513 in k3509 in k3482 */
static void C_ccall f_3614(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_3614r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3614r(t0,t1,t2,t3);}}

static void C_ccall f_3614r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3616,a[2]=t2,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3709,a[2]=t4,a[3]=((C_word)li7),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3714,a[2]=t5,a[3]=((C_word)li8),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-se102142 */
t7=t6;
f_3714(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-alias103138 */
t9=t5;
f_3709(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body100109 */
t11=t4;
f_3616(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-se102 in ##sys#strip-syntax in k3513 in k3509 in k3482 */
static void C_fcall f_3714(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3714,NULL,2,t0,t1);}
/* def-alias103138 */
t2=((C_word*)t0)[2];
f_3709(t2,t1,C_SCHEME_FALSE);}

/* def-alias103 in ##sys#strip-syntax in k3513 in k3509 in k3482 */
static void C_fcall f_3709(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3709,NULL,3,t0,t1,t2);}
/* body100109 */
t3=((C_word*)t0)[2];
f_3616(t3,t1,t2,C_SCHEME_FALSE);}

/* body100 in ##sys#strip-syntax in k3513 in k3509 in k3482 */
static void C_fcall f_3616(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3616,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3622,a[2]=t5,a[3]=t2,a[4]=t3,a[5]=((C_word)li5),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_3622(3,t7,t1,((C_word*)t0)[2]);}

/* walk in body100 in ##sys#strip-syntax in k3513 in k3509 in k3482 */
static void C_ccall f_3622(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(18);
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_3622,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3632,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* expand.scm: 100  lookup */
f_3517(t3,t2,((C_word*)t0)[3]);}
else{
/* expand.scm: 101  get */
t4=C_retrieve(lf[24]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[12]);}}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3679,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* expand.scm: 108  walk */
t9=t3;
t10=t4;
t1=t9;
t2=t10;
c=3;
goto loop;}
else{
if(C_truep((C_word)C_i_vectorp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3704,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3708,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 111  vector->list */
t5=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}}

/* k3706 in walk in body100 in ##sys#strip-syntax in k3513 in k3509 in k3482 */
static void C_ccall f_3708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k3702 in walk in body100 in ##sys#strip-syntax in k3513 in k3509 in k3482 */
static void C_ccall f_3704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 111  list->vector */
t2=*((C_word*)lf[25]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3677 in walk in body100 in ##sys#strip-syntax in k3513 in k3509 in k3482 */
static void C_ccall f_3679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3683,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 109  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3622(3,t4,t2,t3);}

/* k3681 in k3677 in walk in body100 in ##sys#strip-syntax in k3513 in k3509 in k3482 */
static void C_ccall f_3683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3683,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3630 in walk in body100 in ##sys#strip-syntax in k3513 in k3509 in k3482 */
static void C_ccall f_3632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3638,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[2]);
t4=t2;
f_3638(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_3638(t3,C_SCHEME_FALSE);}}

/* k3636 in k3630 in walk in body100 in ##sys#strip-syntax in k3513 in k3509 in k3482 */
static void C_fcall f_3638(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* expand.scm: 103  ##sys#alias-global-hook */
t2=C_retrieve(lf[23]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[2];
if(C_truep(t2)){
t3=(C_word)C_i_pairp(((C_word*)t0)[2]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?((C_word*)t0)[3]:((C_word*)t0)[2]));}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}}

/* map-se in k3513 in k3509 in k3482 */
static void C_fcall f_3584(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3584,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3590,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a3589 in map-se in k3513 in k3509 in k3482 */
static void C_ccall f_3590(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3590,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_symbolp(t4);
t6=(C_truep(t5)?(C_word)C_i_cdr(t2):lf[14]);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t3,t6));}

/* macro-alias in k3513 in k3509 in k3482 */
static void C_fcall f_3535(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3535,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3542,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 75   ##sys#qualified-symbol? */
t5=C_retrieve(lf[19]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k3540 in macro-alias in k3513 in k3509 in k3482 */
static void C_ccall f_3542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3542,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3545,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_3545(t3,t1);}
else{
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_block_size(t3);
t5=(C_word)C_fixnum_greaterp(t4,C_fix(0));
t6=t2;
f_3545(t6,(C_truep(t5)?(C_word)C_eqp(C_make_character(35),(C_word)C_subchar(t3,C_fix(0))):C_SCHEME_FALSE));}}

/* k3543 in k3540 in macro-alias in k3513 in k3509 in k3482 */
static void C_fcall f_3545(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3545,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 81   gensym */
t3=C_retrieve(lf[18]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}

/* k3546 in k3543 in k3540 in macro-alias in k3513 in k3509 in k3482 */
static void C_ccall f_3548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3551,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 82   lookup */
f_3517(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k3549 in k3546 in k3543 in k3540 in macro-alias in k3513 in k3509 in k3482 */
static void C_ccall f_3551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3551,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3557,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 83   ##sys#put! */
t4=C_retrieve(lf[17]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],lf[12],t2);}

/* k3555 in k3549 in k3546 in k3543 in k3540 in macro-alias in k3513 in k3509 in k3482 */
static void C_ccall f_3557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3560,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_pairp(((C_word*)t0)[2]);
t4=(C_truep(t3)?lf[14]:((C_word*)t0)[2]);
/* expand.scm: 84   dd */
t5=C_retrieve2(lf[6],"dd");
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,lf[15],((C_word*)t0)[3],lf[16],t4);}

/* k3558 in k3555 in k3549 in k3546 in k3543 in k3540 in macro-alias in k3513 in k3509 in k3482 */
static void C_ccall f_3560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* lookup in k3513 in k3509 in k3482 */
static void C_fcall f_3517(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3517,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cdr(t4));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3530,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 71   ##sys#get */
t6=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,lf[12]);}}

/* k3528 in lookup in k3513 in k3509 in k3482 */
static void C_ccall f_3530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:C_SCHEME_FALSE));}

/* d in k3482 */
static void C_ccall f_3486(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_3486r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3486r(t0,t1,t2,t3);}}

static void C_ccall f_3486r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
if(C_truep((C_word)C_fudge(C_fix(13)))){
if(C_truep((C_word)C_i_nullp(t3))){
/* expand.scm: 43   pp */
t4=C_retrieve(lf[4]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}
else{
C_apply(5,0,t1,*((C_word*)lf[5]+1),t2,t3);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[856] = {
{"toplevelexpand.scm",(void*)C_expand_toplevel},
{"f_3484expand.scm",(void*)f_3484},
{"f_3511expand.scm",(void*)f_3511},
{"f_3515expand.scm",(void*)f_3515},
{"f_3765expand.scm",(void*)f_3765},
{"f_13546expand.scm",(void*)f_13546},
{"f_13544expand.scm",(void*)f_13544},
{"f_7761expand.scm",(void*)f_7761},
{"f_13536expand.scm",(void*)f_13536},
{"f_13534expand.scm",(void*)f_13534},
{"f_7764expand.scm",(void*)f_7764},
{"f_7768expand.scm",(void*)f_7768},
{"f_13394expand.scm",(void*)f_13394},
{"f_13404expand.scm",(void*)f_13404},
{"f_13420expand.scm",(void*)f_13420},
{"f_13423expand.scm",(void*)f_13423},
{"f_13451expand.scm",(void*)f_13451},
{"f_13426expand.scm",(void*)f_13426},
{"f_13473expand.scm",(void*)f_13473},
{"f_13476expand.scm",(void*)f_13476},
{"f_13522expand.scm",(void*)f_13522},
{"f_13479expand.scm",(void*)f_13479},
{"f_13502expand.scm",(void*)f_13502},
{"f_13514expand.scm",(void*)f_13514},
{"f_13460expand.scm",(void*)f_13460},
{"f_13463expand.scm",(void*)f_13463},
{"f_13470expand.scm",(void*)f_13470},
{"f_13392expand.scm",(void*)f_13392},
{"f_7771expand.scm",(void*)f_7771},
{"f_13335expand.scm",(void*)f_13335},
{"f_13364expand.scm",(void*)f_13364},
{"f_13384expand.scm",(void*)f_13384},
{"f_13388expand.scm",(void*)f_13388},
{"f_13333expand.scm",(void*)f_13333},
{"f_7774expand.scm",(void*)f_7774},
{"f_13245expand.scm",(void*)f_13245},
{"f_13270expand.scm",(void*)f_13270},
{"f_13277expand.scm",(void*)f_13277},
{"f_13297expand.scm",(void*)f_13297},
{"f_13317expand.scm",(void*)f_13317},
{"f_13321expand.scm",(void*)f_13321},
{"f_13243expand.scm",(void*)f_13243},
{"f_7777expand.scm",(void*)f_7777},
{"f_12912expand.scm",(void*)f_12912},
{"f_12919expand.scm",(void*)f_12919},
{"f_12922expand.scm",(void*)f_12922},
{"f_12925expand.scm",(void*)f_12925},
{"f_12928expand.scm",(void*)f_12928},
{"f_12931expand.scm",(void*)f_12931},
{"f_12934expand.scm",(void*)f_12934},
{"f_12937expand.scm",(void*)f_12937},
{"f_12942expand.scm",(void*)f_12942},
{"f_12958expand.scm",(void*)f_12958},
{"f_12964expand.scm",(void*)f_12964},
{"f_13006expand.scm",(void*)f_13006},
{"f_13074expand.scm",(void*)f_13074},
{"f_13199expand.scm",(void*)f_13199},
{"f_13195expand.scm",(void*)f_13195},
{"f_13077expand.scm",(void*)f_13077},
{"f_13132expand.scm",(void*)f_13132},
{"f_13009expand.scm",(void*)f_13009},
{"f_13048expand.scm",(void*)f_13048},
{"f_13000expand.scm",(void*)f_13000},
{"f_12971expand.scm",(void*)f_12971},
{"f_12910expand.scm",(void*)f_12910},
{"f_7780expand.scm",(void*)f_7780},
{"f_12742expand.scm",(void*)f_12742},
{"f_12746expand.scm",(void*)f_12746},
{"f_12755expand.scm",(void*)f_12755},
{"f_12758expand.scm",(void*)f_12758},
{"f_12761expand.scm",(void*)f_12761},
{"f_12764expand.scm",(void*)f_12764},
{"f_12767expand.scm",(void*)f_12767},
{"f_12788expand.scm",(void*)f_12788},
{"f_12804expand.scm",(void*)f_12804},
{"f_12810expand.scm",(void*)f_12810},
{"f_12866expand.scm",(void*)f_12866},
{"f_12864expand.scm",(void*)f_12864},
{"f_12860expand.scm",(void*)f_12860},
{"f_12852expand.scm",(void*)f_12852},
{"f_12848expand.scm",(void*)f_12848},
{"f_12817expand.scm",(void*)f_12817},
{"f_12786expand.scm",(void*)f_12786},
{"f_12740expand.scm",(void*)f_12740},
{"f_7783expand.scm",(void*)f_7783},
{"f_12673expand.scm",(void*)f_12673},
{"f_12677expand.scm",(void*)f_12677},
{"f_12686expand.scm",(void*)f_12686},
{"f_12691expand.scm",(void*)f_12691},
{"f_12728expand.scm",(void*)f_12728},
{"f_12709expand.scm",(void*)f_12709},
{"f_12671expand.scm",(void*)f_12671},
{"f_7786expand.scm",(void*)f_7786},
{"f_12491expand.scm",(void*)f_12491},
{"f_12495expand.scm",(void*)f_12495},
{"f_12507expand.scm",(void*)f_12507},
{"f_12510expand.scm",(void*)f_12510},
{"f_12513expand.scm",(void*)f_12513},
{"f_12516expand.scm",(void*)f_12516},
{"f_12651expand.scm",(void*)f_12651},
{"f_12531expand.scm",(void*)f_12531},
{"f_12649expand.scm",(void*)f_12649},
{"f_12558expand.scm",(void*)f_12558},
{"f_12639expand.scm",(void*)f_12639},
{"f_12574expand.scm",(void*)f_12574},
{"f_12596expand.scm",(void*)f_12596},
{"f_12594expand.scm",(void*)f_12594},
{"f_12590expand.scm",(void*)f_12590},
{"f_12489expand.scm",(void*)f_12489},
{"f_7789expand.scm",(void*)f_7789},
{"f_12096expand.scm",(void*)f_12096},
{"f_12100expand.scm",(void*)f_12100},
{"f_12103expand.scm",(void*)f_12103},
{"f_12106expand.scm",(void*)f_12106},
{"f_12109expand.scm",(void*)f_12109},
{"f_12478expand.scm",(void*)f_12478},
{"f_12390expand.scm",(void*)f_12390},
{"f_12394expand.scm",(void*)f_12394},
{"f_12419expand.scm",(void*)f_12419},
{"f_12465expand.scm",(void*)f_12465},
{"f_12450expand.scm",(void*)f_12450},
{"f_12121expand.scm",(void*)f_12121},
{"f_12168expand.scm",(void*)f_12168},
{"f_12215expand.scm",(void*)f_12215},
{"f_12376expand.scm",(void*)f_12376},
{"f_12384expand.scm",(void*)f_12384},
{"f_12362expand.scm",(void*)f_12362},
{"f_12351expand.scm",(void*)f_12351},
{"f_12359expand.scm",(void*)f_12359},
{"f_12336expand.scm",(void*)f_12336},
{"f_12324expand.scm",(void*)f_12324},
{"f_12305expand.scm",(void*)f_12305},
{"f_12263expand.scm",(void*)f_12263},
{"f_12240expand.scm",(void*)f_12240},
{"f_12194expand.scm",(void*)f_12194},
{"f_12143expand.scm",(void*)f_12143},
{"f_12139expand.scm",(void*)f_12139},
{"f_12111expand.scm",(void*)f_12111},
{"f_12119expand.scm",(void*)f_12119},
{"f_12094expand.scm",(void*)f_12094},
{"f_7792expand.scm",(void*)f_7792},
{"f_12063expand.scm",(void*)f_12063},
{"f_12067expand.scm",(void*)f_12067},
{"f_12061expand.scm",(void*)f_12061},
{"f_7795expand.scm",(void*)f_7795},
{"f_11779expand.scm",(void*)f_11779},
{"f_11786expand.scm",(void*)f_11786},
{"f_11789expand.scm",(void*)f_11789},
{"f_11792expand.scm",(void*)f_11792},
{"f_11795expand.scm",(void*)f_11795},
{"f_11798expand.scm",(void*)f_11798},
{"f_11960expand.scm",(void*)f_11960},
{"f_12013expand.scm",(void*)f_12013},
{"f_12035expand.scm",(void*)f_12035},
{"f_12042expand.scm",(void*)f_12042},
{"f_12029expand.scm",(void*)f_12029},
{"f_11976expand.scm",(void*)f_11976},
{"f_11974expand.scm",(void*)f_11974},
{"f_11810expand.scm",(void*)f_11810},
{"f_11841expand.scm",(void*)f_11841},
{"f_11887expand.scm",(void*)f_11887},
{"f_11937expand.scm",(void*)f_11937},
{"f_11944expand.scm",(void*)f_11944},
{"f_11902expand.scm",(void*)f_11902},
{"f_11916expand.scm",(void*)f_11916},
{"f_11859expand.scm",(void*)f_11859},
{"f_11870expand.scm",(void*)f_11870},
{"f_11800expand.scm",(void*)f_11800},
{"f_11777expand.scm",(void*)f_11777},
{"f_7798expand.scm",(void*)f_7798},
{"f_11758expand.scm",(void*)f_11758},
{"f_11756expand.scm",(void*)f_11756},
{"f_7801expand.scm",(void*)f_7801},
{"f_11737expand.scm",(void*)f_11737},
{"f_11735expand.scm",(void*)f_11735},
{"f_7804expand.scm",(void*)f_7804},
{"f_11686expand.scm",(void*)f_11686},
{"f_11690expand.scm",(void*)f_11690},
{"f_11727expand.scm",(void*)f_11727},
{"f_11720expand.scm",(void*)f_11720},
{"f_11713expand.scm",(void*)f_11713},
{"f_11684expand.scm",(void*)f_11684},
{"f_7807expand.scm",(void*)f_7807},
{"f_11632expand.scm",(void*)f_11632},
{"f_11636expand.scm",(void*)f_11636},
{"f_11639expand.scm",(void*)f_11639},
{"f_11676expand.scm",(void*)f_11676},
{"f_11642expand.scm",(void*)f_11642},
{"f_11657expand.scm",(void*)f_11657},
{"f_11661expand.scm",(void*)f_11661},
{"f_11630expand.scm",(void*)f_11630},
{"f_7810expand.scm",(void*)f_7810},
{"f_11529expand.scm",(void*)f_11529},
{"f_11536expand.scm",(void*)f_11536},
{"f_11539expand.scm",(void*)f_11539},
{"f_11559expand.scm",(void*)f_11559},
{"f_11581expand.scm",(void*)f_11581},
{"f_11566expand.scm",(void*)f_11566},
{"f_11542expand.scm",(void*)f_11542},
{"f_11557expand.scm",(void*)f_11557},
{"f_11549expand.scm",(void*)f_11549},
{"f_11545expand.scm",(void*)f_11545},
{"f_11527expand.scm",(void*)f_11527},
{"f_7813expand.scm",(void*)f_7813},
{"f_11492expand.scm",(void*)f_11492},
{"f_11496expand.scm",(void*)f_11496},
{"f_11514expand.scm",(void*)f_11514},
{"f_11505expand.scm",(void*)f_11505},
{"f_11490expand.scm",(void*)f_11490},
{"f_7816expand.scm",(void*)f_7816},
{"f_9451expand.scm",(void*)f_9451},
{"f_11486expand.scm",(void*)f_11486},
{"f_9455expand.scm",(void*)f_9455},
{"f_9459expand.scm",(void*)f_9459},
{"f_11444expand.scm",(void*)f_11444},
{"f_11452expand.scm",(void*)f_11452},
{"f_11454expand.scm",(void*)f_11454},
{"f_11475expand.scm",(void*)f_11475},
{"f_10997expand.scm",(void*)f_10997},
{"f_11429expand.scm",(void*)f_11429},
{"f_11437expand.scm",(void*)f_11437},
{"f_11013expand.scm",(void*)f_11013},
{"f_11386expand.scm",(void*)f_11386},
{"f_11388expand.scm",(void*)f_11388},
{"f_11427expand.scm",(void*)f_11427},
{"f_11401expand.scm",(void*)f_11401},
{"f_11412expand.scm",(void*)f_11412},
{"f_11367expand.scm",(void*)f_11367},
{"f_11379expand.scm",(void*)f_11379},
{"f_11016expand.scm",(void*)f_11016},
{"f_11239expand.scm",(void*)f_11239},
{"f_11290expand.scm",(void*)f_11290},
{"f_11343expand.scm",(void*)f_11343},
{"f_11302expand.scm",(void*)f_11302},
{"f_11329expand.scm",(void*)f_11329},
{"f_11325expand.scm",(void*)f_11325},
{"f_11305expand.scm",(void*)f_11305},
{"f_11287expand.scm",(void*)f_11287},
{"f_11276expand.scm",(void*)f_11276},
{"f_11019expand.scm",(void*)f_11019},
{"f_11233expand.scm",(void*)f_11233},
{"f_11219expand.scm",(void*)f_11219},
{"f_11022expand.scm",(void*)f_11022},
{"f_11217expand.scm",(void*)f_11217},
{"f_11181expand.scm",(void*)f_11181},
{"f_11209expand.scm",(void*)f_11209},
{"f_11025expand.scm",(void*)f_11025},
{"f_11175expand.scm",(void*)f_11175},
{"f_11179expand.scm",(void*)f_11179},
{"f_11028expand.scm",(void*)f_11028},
{"f_11031expand.scm",(void*)f_11031},
{"f_11133expand.scm",(void*)f_11133},
{"f_11137expand.scm",(void*)f_11137},
{"f_11167expand.scm",(void*)f_11167},
{"f_11163expand.scm",(void*)f_11163},
{"f_11140expand.scm",(void*)f_11140},
{"f_11034expand.scm",(void*)f_11034},
{"f_11131expand.scm",(void*)f_11131},
{"f_11127expand.scm",(void*)f_11127},
{"f_11123expand.scm",(void*)f_11123},
{"f_11119expand.scm",(void*)f_11119},
{"f_11115expand.scm",(void*)f_11115},
{"f_11111expand.scm",(void*)f_11111},
{"f_11107expand.scm",(void*)f_11107},
{"f_11103expand.scm",(void*)f_11103},
{"f_11099expand.scm",(void*)f_11099},
{"f_11037expand.scm",(void*)f_11037},
{"f_11040expand.scm",(void*)f_11040},
{"f_10912expand.scm",(void*)f_10912},
{"f_10923expand.scm",(void*)f_10923},
{"f_10925expand.scm",(void*)f_10925},
{"f_10974expand.scm",(void*)f_10974},
{"f_10970expand.scm",(void*)f_10970},
{"f_10953expand.scm",(void*)f_10953},
{"f_10821expand.scm",(void*)f_10821},
{"f_10825expand.scm",(void*)f_10825},
{"f_10828expand.scm",(void*)f_10828},
{"f_10867expand.scm",(void*)f_10867},
{"f_10887expand.scm",(void*)f_10887},
{"f_10877expand.scm",(void*)f_10877},
{"f_10880expand.scm",(void*)f_10880},
{"f_10843expand.scm",(void*)f_10843},
{"f_10849expand.scm",(void*)f_10849},
{"f_10847expand.scm",(void*)f_10847},
{"f_10701expand.scm",(void*)f_10701},
{"f_10803expand.scm",(void*)f_10803},
{"f_10815expand.scm",(void*)f_10815},
{"f_10705expand.scm",(void*)f_10705},
{"f_10771expand.scm",(void*)f_10771},
{"f_10793expand.scm",(void*)f_10793},
{"f_10708expand.scm",(void*)f_10708},
{"f_10765expand.scm",(void*)f_10765},
{"f_10769expand.scm",(void*)f_10769},
{"f_10714expand.scm",(void*)f_10714},
{"f_10717expand.scm",(void*)f_10717},
{"f_10753expand.scm",(void*)f_10753},
{"f_10720expand.scm",(void*)f_10720},
{"f_10733expand.scm",(void*)f_10733},
{"f_10723expand.scm",(void*)f_10723},
{"f_10415expand.scm",(void*)f_10415},
{"f_10699expand.scm",(void*)f_10699},
{"f_10435expand.scm",(void*)f_10435},
{"f_10669expand.scm",(void*)f_10669},
{"f_10443expand.scm",(void*)f_10443},
{"f_10651expand.scm",(void*)f_10651},
{"f_10451expand.scm",(void*)f_10451},
{"f_10639expand.scm",(void*)f_10639},
{"f_10566expand.scm",(void*)f_10566},
{"f_10564expand.scm",(void*)f_10564},
{"f_10560expand.scm",(void*)f_10560},
{"f_10501expand.scm",(void*)f_10501},
{"f_10511expand.scm",(void*)f_10511},
{"f_10499expand.scm",(void*)f_10499},
{"f_10495expand.scm",(void*)f_10495},
{"f_10447expand.scm",(void*)f_10447},
{"f_10439expand.scm",(void*)f_10439},
{"f_10343expand.scm",(void*)f_10343},
{"f_10347expand.scm",(void*)f_10347},
{"f_10350expand.scm",(void*)f_10350},
{"f_10362expand.scm",(void*)f_10362},
{"f_10401expand.scm",(void*)f_10401},
{"f_10393expand.scm",(void*)f_10393},
{"f_10353expand.scm",(void*)f_10353},
{"f_10356expand.scm",(void*)f_10356},
{"f_10067expand.scm",(void*)f_10067},
{"f_10148expand.scm",(void*)f_10148},
{"f_10175expand.scm",(void*)f_10175},
{"f_10177expand.scm",(void*)f_10177},
{"f_10337expand.scm",(void*)f_10337},
{"f_10325expand.scm",(void*)f_10325},
{"f_10306expand.scm",(void*)f_10306},
{"f_10288expand.scm",(void*)f_10288},
{"f_10273expand.scm",(void*)f_10273},
{"f_10243expand.scm",(void*)f_10243},
{"f_10228expand.scm",(void*)f_10228},
{"f_10200expand.scm",(void*)f_10200},
{"f_10125expand.scm",(void*)f_10125},
{"f_10137expand.scm",(void*)f_10137},
{"f_10133expand.scm",(void*)f_10133},
{"f_10008expand.scm",(void*)f_10008},
{"f_10014expand.scm",(void*)f_10014},
{"f_10021expand.scm",(void*)f_10021},
{"f_10024expand.scm",(void*)f_10024},
{"f_9940expand.scm",(void*)f_9940},
{"f_9960expand.scm",(void*)f_9960},
{"f_9955expand.scm",(void*)f_9955},
{"f_9942expand.scm",(void*)f_9942},
{"f_9918expand.scm",(void*)f_9918},
{"f_9925expand.scm",(void*)f_9925},
{"f_9841expand.scm",(void*)f_9841},
{"f_9851expand.scm",(void*)f_9851},
{"f_9854expand.scm",(void*)f_9854},
{"f_9860expand.scm",(void*)f_9860},
{"f_9899expand.scm",(void*)f_9899},
{"f_9903expand.scm",(void*)f_9903},
{"f_9863expand.scm",(void*)f_9863},
{"f_9866expand.scm",(void*)f_9866},
{"f_9869expand.scm",(void*)f_9869},
{"f_9752expand.scm",(void*)f_9752},
{"f_9762expand.scm",(void*)f_9762},
{"f_9765expand.scm",(void*)f_9765},
{"f_9828expand.scm",(void*)f_9828},
{"f_9768expand.scm",(void*)f_9768},
{"f_9824expand.scm",(void*)f_9824},
{"f_9771expand.scm",(void*)f_9771},
{"f_9810expand.scm",(void*)f_9810},
{"f_9814expand.scm",(void*)f_9814},
{"f_9774expand.scm",(void*)f_9774},
{"f_9777expand.scm",(void*)f_9777},
{"f_9783expand.scm",(void*)f_9783},
{"f_9731expand.scm",(void*)f_9731},
{"f_9738expand.scm",(void*)f_9738},
{"f_9711expand.scm",(void*)f_9711},
{"f_9715expand.scm",(void*)f_9715},
{"f_9708expand.scm",(void*)f_9708},
{"f_9668expand.scm",(void*)f_9668},
{"f_9672expand.scm",(void*)f_9672},
{"f_9662expand.scm",(void*)f_9662},
{"f_9653expand.scm",(void*)f_9653},
{"f_9635expand.scm",(void*)f_9635},
{"f_9617expand.scm",(void*)f_9617},
{"f_9599expand.scm",(void*)f_9599},
{"f_9581expand.scm",(void*)f_9581},
{"f_9563expand.scm",(void*)f_9563},
{"f_9554expand.scm",(void*)f_9554},
{"f_9545expand.scm",(void*)f_9545},
{"f_9527expand.scm",(void*)f_9527},
{"f_9509expand.scm",(void*)f_9509},
{"f_9500expand.scm",(void*)f_9500},
{"f_9491expand.scm",(void*)f_9491},
{"f_9473expand.scm",(void*)f_9473},
{"f_7818expand.scm",(void*)f_7818},
{"f_7825expand.scm",(void*)f_7825},
{"f_7839expand.scm",(void*)f_7839},
{"f_7843expand.scm",(void*)f_7843},
{"f_7847expand.scm",(void*)f_7847},
{"f_7852expand.scm",(void*)f_7852},
{"f_7858expand.scm",(void*)f_7858},
{"f_7862expand.scm",(void*)f_7862},
{"f_7866expand.scm",(void*)f_7866},
{"f_7870expand.scm",(void*)f_7870},
{"f_7874expand.scm",(void*)f_7874},
{"f_7879expand.scm",(void*)f_7879},
{"f_7883expand.scm",(void*)f_7883},
{"f_7890expand.scm",(void*)f_7890},
{"f_7895expand.scm",(void*)f_7895},
{"f_7899expand.scm",(void*)f_7899},
{"f_7903expand.scm",(void*)f_7903},
{"f_7907expand.scm",(void*)f_7907},
{"f_9410expand.scm",(void*)f_9410},
{"f_9420expand.scm",(void*)f_9420},
{"f_9427expand.scm",(void*)f_9427},
{"f_9390expand.scm",(void*)f_9390},
{"f_9397expand.scm",(void*)f_9397},
{"f_9404expand.scm",(void*)f_9404},
{"f_9364expand.scm",(void*)f_9364},
{"f_9342expand.scm",(void*)f_9342},
{"f_9349expand.scm",(void*)f_9349},
{"f_9249expand.scm",(void*)f_9249},
{"f_9291expand.scm",(void*)f_9291},
{"f_9340expand.scm",(void*)f_9340},
{"f_9323expand.scm",(void*)f_9323},
{"f_9302expand.scm",(void*)f_9302},
{"f_9262expand.scm",(void*)f_9262},
{"f_9176expand.scm",(void*)f_9176},
{"f_9202expand.scm",(void*)f_9202},
{"f_9247expand.scm",(void*)f_9247},
{"f_9230expand.scm",(void*)f_9230},
{"f_8922expand.scm",(void*)f_8922},
{"f_8969expand.scm",(void*)f_8969},
{"f_9167expand.scm",(void*)f_9167},
{"f_9163expand.scm",(void*)f_9163},
{"f_9130expand.scm",(void*)f_9130},
{"f_9138expand.scm",(void*)f_9138},
{"f_8972expand.scm",(void*)f_8972},
{"f_8978expand.scm",(void*)f_8978},
{"f_8990expand.scm",(void*)f_8990},
{"f_9056expand.scm",(void*)f_9056},
{"f_9071expand.scm",(void*)f_9071},
{"f_8993expand.scm",(void*)f_8993},
{"f_9027expand.scm",(void*)f_9027},
{"f_8996expand.scm",(void*)f_8996},
{"f_9025expand.scm",(void*)f_9025},
{"f_9021expand.scm",(void*)f_9021},
{"f_9017expand.scm",(void*)f_9017},
{"f_8715expand.scm",(void*)f_8715},
{"f_8745expand.scm",(void*)f_8745},
{"f_8845expand.scm",(void*)f_8845},
{"f_8868expand.scm",(void*)f_8868},
{"f_8882expand.scm",(void*)f_8882},
{"f_8886expand.scm",(void*)f_8886},
{"f_8855expand.scm",(void*)f_8855},
{"f_8805expand.scm",(void*)f_8805},
{"f_8809expand.scm",(void*)f_8809},
{"f_8754expand.scm",(void*)f_8754},
{"f_8762expand.scm",(void*)f_8762},
{"f_8739expand.scm",(void*)f_8739},
{"f_8427expand.scm",(void*)f_8427},
{"f_8434expand.scm",(void*)f_8434},
{"f_8473expand.scm",(void*)f_8473},
{"f_8483expand.scm",(void*)f_8483},
{"f_8614expand.scm",(void*)f_8614},
{"f_8618expand.scm",(void*)f_8618},
{"f_8547expand.scm",(void*)f_8547},
{"f_8543expand.scm",(void*)f_8543},
{"f_8481expand.scm",(void*)f_8481},
{"f_8477expand.scm",(void*)f_8477},
{"f_8309expand.scm",(void*)f_8309},
{"f_8313expand.scm",(void*)f_8313},
{"f_8088expand.scm",(void*)f_8088},
{"f_8138expand.scm",(void*)f_8138},
{"f_8252expand.scm",(void*)f_8252},
{"f_8190expand.scm",(void*)f_8190},
{"f_8198expand.scm",(void*)f_8198},
{"f_8194expand.scm",(void*)f_8194},
{"f_8186expand.scm",(void*)f_8186},
{"f_8004expand.scm",(void*)f_8004},
{"f_8011expand.scm",(void*)f_8011},
{"f_8014expand.scm",(void*)f_8014},
{"f_8063expand.scm",(void*)f_8063},
{"f_8059expand.scm",(void*)f_8059},
{"f_8054expand.scm",(void*)f_8054},
{"f_8040expand.scm",(void*)f_8040},
{"f_8052expand.scm",(void*)f_8052},
{"f_8048expand.scm",(void*)f_8048},
{"f_7910expand.scm",(void*)f_7910},
{"f_7954expand.scm",(void*)f_7954},
{"f_7950expand.scm",(void*)f_7950},
{"f_6916expand.scm",(void*)f_6916},
{"f_6920expand.scm",(void*)f_6920},
{"f_6923expand.scm",(void*)f_6923},
{"f_6926expand.scm",(void*)f_6926},
{"f_6929expand.scm",(void*)f_6929},
{"f_7528expand.scm",(void*)f_7528},
{"f_7531expand.scm",(void*)f_7531},
{"f_7750expand.scm",(void*)f_7750},
{"f_7735expand.scm",(void*)f_7735},
{"f_7534expand.scm",(void*)f_7534},
{"f_7539expand.scm",(void*)f_7539},
{"f_7543expand.scm",(void*)f_7543},
{"f_7552expand.scm",(void*)f_7552},
{"f_7710expand.scm",(void*)f_7710},
{"f_7555expand.scm",(void*)f_7555},
{"f_7687expand.scm",(void*)f_7687},
{"f_7558expand.scm",(void*)f_7558},
{"f_7561expand.scm",(void*)f_7561},
{"f_7633expand.scm",(void*)f_7633},
{"f_7667expand.scm",(void*)f_7667},
{"f_7564expand.scm",(void*)f_7564},
{"f_7591expand.scm",(void*)f_7591},
{"f_7631expand.scm",(void*)f_7631},
{"f_7567expand.scm",(void*)f_7567},
{"f_7589expand.scm",(void*)f_7589},
{"f_7585expand.scm",(void*)f_7585},
{"f_7570expand.scm",(void*)f_7570},
{"f_7581expand.scm",(void*)f_7581},
{"f_7577expand.scm",(void*)f_7577},
{"f_7537expand.scm",(void*)f_7537},
{"f_7070expand.scm",(void*)f_7070},
{"f_7089expand.scm",(void*)f_7089},
{"f_7098expand.scm",(void*)f_7098},
{"f_7110expand.scm",(void*)f_7110},
{"f_7190expand.scm",(void*)f_7190},
{"f_7297expand.scm",(void*)f_7297},
{"f_7444expand.scm",(void*)f_7444},
{"f_7447expand.scm",(void*)f_7447},
{"f_7450expand.scm",(void*)f_7450},
{"f_7483expand.scm",(void*)f_7483},
{"f_7487expand.scm",(void*)f_7487},
{"f_7452expand.scm",(void*)f_7452},
{"f_7472expand.scm",(void*)f_7472},
{"f_7468expand.scm",(void*)f_7468},
{"f_7460expand.scm",(void*)f_7460},
{"f_7300expand.scm",(void*)f_7300},
{"f_7309expand.scm",(void*)f_7309},
{"f_7438expand.scm",(void*)f_7438},
{"f_7419expand.scm",(void*)f_7419},
{"f_7407expand.scm",(void*)f_7407},
{"f_7386expand.scm",(void*)f_7386},
{"f_7367expand.scm",(void*)f_7367},
{"f_7355expand.scm",(void*)f_7355},
{"f_7330expand.scm",(void*)f_7330},
{"f_7325expand.scm",(void*)f_7325},
{"f_7193expand.scm",(void*)f_7193},
{"f_7196expand.scm",(void*)f_7196},
{"f_7201expand.scm",(void*)f_7201},
{"f_7287expand.scm",(void*)f_7287},
{"f_7213expand.scm",(void*)f_7213},
{"f_7255expand.scm",(void*)f_7255},
{"f_7113expand.scm",(void*)f_7113},
{"f_7116expand.scm",(void*)f_7116},
{"f_7121expand.scm",(void*)f_7121},
{"f_6983expand.scm",(void*)f_6983},
{"f_6987expand.scm",(void*)f_6987},
{"f_6990expand.scm",(void*)f_6990},
{"f_7068expand.scm",(void*)f_7068},
{"f_7064expand.scm",(void*)f_7064},
{"f_7005expand.scm",(void*)f_7005},
{"f_7011expand.scm",(void*)f_7011},
{"f_7014expand.scm",(void*)f_7014},
{"f_7053expand.scm",(void*)f_7053},
{"f_7047expand.scm",(void*)f_7047},
{"f_7051expand.scm",(void*)f_7051},
{"f_7015expand.scm",(void*)f_7015},
{"f_7019expand.scm",(void*)f_7019},
{"f_7022expand.scm",(void*)f_7022},
{"f_7026expand.scm",(void*)f_7026},
{"f_7029expand.scm",(void*)f_7029},
{"f_7033expand.scm",(void*)f_7033},
{"f_7036expand.scm",(void*)f_7036},
{"f_7040expand.scm",(void*)f_7040},
{"f_7043expand.scm",(void*)f_7043},
{"f_6993expand.scm",(void*)f_6993},
{"f_6940expand.scm",(void*)f_6940},
{"f_6953expand.scm",(void*)f_6953},
{"f_6960expand.scm",(void*)f_6960},
{"f_6931expand.scm",(void*)f_6931},
{"f_6935expand.scm",(void*)f_6935},
{"f_6622expand.scm",(void*)f_6622},
{"f_6624expand.scm",(void*)f_6624},
{"f_6753expand.scm",(void*)f_6753},
{"f_6786expand.scm",(void*)f_6786},
{"f_6876expand.scm",(void*)f_6876},
{"f_6789expand.scm",(void*)f_6789},
{"f_6792expand.scm",(void*)f_6792},
{"f_6870expand.scm",(void*)f_6870},
{"f_6795expand.scm",(void*)f_6795},
{"f_6864expand.scm",(void*)f_6864},
{"f_6841expand.scm",(void*)f_6841},
{"f_6814expand.scm",(void*)f_6814},
{"f_6821expand.scm",(void*)f_6821},
{"f_6757expand.scm",(void*)f_6757},
{"f_6760expand.scm",(void*)f_6760},
{"f_6890expand.scm",(void*)f_6890},
{"f_6894expand.scm",(void*)f_6894},
{"f_6897expand.scm",(void*)f_6897},
{"f_6627expand.scm",(void*)f_6627},
{"f_6663expand.scm",(void*)f_6663},
{"f_6724expand.scm",(void*)f_6724},
{"f_6727expand.scm",(void*)f_6727},
{"f_6694expand.scm",(void*)f_6694},
{"f_6697expand.scm",(void*)f_6697},
{"f_6675expand.scm",(void*)f_6675},
{"f_6637expand.scm",(void*)f_6637},
{"f_6160expand.scm",(void*)f_6160},
{"f_6574expand.scm",(void*)f_6574},
{"f_6565expand.scm",(void*)f_6565},
{"f_6573expand.scm",(void*)f_6573},
{"f_6162expand.scm",(void*)f_6162},
{"f_6293expand.scm",(void*)f_6293},
{"f_6298expand.scm",(void*)f_6298},
{"f_6536expand.scm",(void*)f_6536},
{"f_6495expand.scm",(void*)f_6495},
{"f_6499expand.scm",(void*)f_6499},
{"f_6317expand.scm",(void*)f_6317},
{"f_6322expand.scm",(void*)f_6322},
{"f_6341expand.scm",(void*)f_6341},
{"f_6264expand.scm",(void*)f_6264},
{"f_6270expand.scm",(void*)f_6270},
{"f_6208expand.scm",(void*)f_6208},
{"f_6212expand.scm",(void*)f_6212},
{"f_6220expand.scm",(void*)f_6220},
{"f_6240expand.scm",(void*)f_6240},
{"f_6165expand.scm",(void*)f_6165},
{"f_6172expand.scm",(void*)f_6172},
{"f_6177expand.scm",(void*)f_6177},
{"f_6181expand.scm",(void*)f_6181},
{"f_6206expand.scm",(void*)f_6206},
{"f_6195expand.scm",(void*)f_6195},
{"f_6199expand.scm",(void*)f_6199},
{"f_6188expand.scm",(void*)f_6188},
{"f_6124expand.scm",(void*)f_6124},
{"f_6146expand.scm",(void*)f_6146},
{"f_6113expand.scm",(void*)f_6113},
{"f_6121expand.scm",(void*)f_6121},
{"f_6043expand.scm",(void*)f_6043},
{"f_6106expand.scm",(void*)f_6106},
{"f_6046expand.scm",(void*)f_6046},
{"f_6099expand.scm",(void*)f_6099},
{"f_6072expand.scm",(void*)f_6072},
{"f_5960expand.scm",(void*)f_5960},
{"f_6041expand.scm",(void*)f_6041},
{"f_5963expand.scm",(void*)f_5963},
{"f_6012expand.scm",(void*)f_6012},
{"f_5207expand.scm",(void*)f_5207},
{"f_5211expand.scm",(void*)f_5211},
{"f_5650expand.scm",(void*)f_5650},
{"f_5656expand.scm",(void*)f_5656},
{"f_5920expand.scm",(void*)f_5920},
{"f_5678expand.scm",(void*)f_5678},
{"f_5888expand.scm",(void*)f_5888},
{"f_5862expand.scm",(void*)f_5862},
{"f_5869expand.scm",(void*)f_5869},
{"f_5834expand.scm",(void*)f_5834},
{"f_5822expand.scm",(void*)f_5822},
{"f_5696expand.scm",(void*)f_5696},
{"f_5701expand.scm",(void*)f_5701},
{"f_5714expand.scm",(void*)f_5714},
{"f_5770expand.scm",(void*)f_5770},
{"f_5797expand.scm",(void*)f_5797},
{"f_5748expand.scm",(void*)f_5748},
{"f_5759expand.scm",(void*)f_5759},
{"f_5763expand.scm",(void*)f_5763},
{"f_5473expand.scm",(void*)f_5473},
{"f_5483expand.scm",(void*)f_5483},
{"f_5632expand.scm",(void*)f_5632},
{"f_5628expand.scm",(void*)f_5628},
{"f_5618expand.scm",(void*)f_5618},
{"f_5621expand.scm",(void*)f_5621},
{"f_5529expand.scm",(void*)f_5529},
{"f_5561expand.scm",(void*)f_5561},
{"f_5573expand.scm",(void*)f_5573},
{"f_5581expand.scm",(void*)f_5581},
{"f_5585expand.scm",(void*)f_5585},
{"f_5547expand.scm",(void*)f_5547},
{"f_5498expand.scm",(void*)f_5498},
{"f_5514expand.scm",(void*)f_5514},
{"f_5506expand.scm",(void*)f_5506},
{"f_5510expand.scm",(void*)f_5510},
{"f_5481expand.scm",(void*)f_5481},
{"f_5213expand.scm",(void*)f_5213},
{"f_5324expand.scm",(void*)f_5324},
{"f_5465expand.scm",(void*)f_5465},
{"f_5453expand.scm",(void*)f_5453},
{"f_5346expand.scm",(void*)f_5346},
{"f_5451expand.scm",(void*)f_5451},
{"f_5435expand.scm",(void*)f_5435},
{"f_5354expand.scm",(void*)f_5354},
{"f_5429expand.scm",(void*)f_5429},
{"f_5433expand.scm",(void*)f_5433},
{"f_5368expand.scm",(void*)f_5368},
{"f_5372expand.scm",(void*)f_5372},
{"f_5405expand.scm",(void*)f_5405},
{"f_5403expand.scm",(void*)f_5403},
{"f_5399expand.scm",(void*)f_5399},
{"f_5362expand.scm",(void*)f_5362},
{"f_5366expand.scm",(void*)f_5366},
{"f_5358expand.scm",(void*)f_5358},
{"f_5350expand.scm",(void*)f_5350},
{"f_5330expand.scm",(void*)f_5330},
{"f_5225expand.scm",(void*)f_5225},
{"f_5239expand.scm",(void*)f_5239},
{"f_5314expand.scm",(void*)f_5314},
{"f_5307expand.scm",(void*)f_5307},
{"f_5248expand.scm",(void*)f_5248},
{"f_5255expand.scm",(void*)f_5255},
{"f_5263expand.scm",(void*)f_5263},
{"f_5271expand.scm",(void*)f_5271},
{"f_5259expand.scm",(void*)f_5259},
{"f_4617expand.scm",(void*)f_4617},
{"f_4637expand.scm",(void*)f_4637},
{"f_4640expand.scm",(void*)f_4640},
{"f_4643expand.scm",(void*)f_4643},
{"f_4646expand.scm",(void*)f_4646},
{"f_4649expand.scm",(void*)f_4649},
{"f_4654expand.scm",(void*)f_4654},
{"f_4965expand.scm",(void*)f_4965},
{"f_5144expand.scm",(void*)f_5144},
{"f_5082expand.scm",(void*)f_5082},
{"f_5063expand.scm",(void*)f_5063},
{"f_5017expand.scm",(void*)f_5017},
{"f_5020expand.scm",(void*)f_5020},
{"f_4999expand.scm",(void*)f_4999},
{"f_4980expand.scm",(void*)f_4980},
{"f_4942expand.scm",(void*)f_4942},
{"f_4921expand.scm",(void*)f_4921},
{"f_4668expand.scm",(void*)f_4668},
{"f_4914expand.scm",(void*)f_4914},
{"f_4841expand.scm",(void*)f_4841},
{"f_4910expand.scm",(void*)f_4910},
{"f_4894expand.scm",(void*)f_4894},
{"f_4876expand.scm",(void*)f_4876},
{"f_4872expand.scm",(void*)f_4872},
{"f_4835expand.scm",(void*)f_4835},
{"f_4839expand.scm",(void*)f_4839},
{"f_4672expand.scm",(void*)f_4672},
{"f_4684expand.scm",(void*)f_4684},
{"f_4787expand.scm",(void*)f_4787},
{"f_4779expand.scm",(void*)f_4779},
{"f_4783expand.scm",(void*)f_4783},
{"f_4756expand.scm",(void*)f_4756},
{"f_4760expand.scm",(void*)f_4760},
{"f_4711expand.scm",(void*)f_4711},
{"f_4731expand.scm",(void*)f_4731},
{"f_4703expand.scm",(void*)f_4703},
{"f_4675expand.scm",(void*)f_4675},
{"f_4620expand.scm",(void*)f_4620},
{"f_4574expand.scm",(void*)f_4574},
{"f_4580expand.scm",(void*)f_4580},
{"f_4599expand.scm",(void*)f_4599},
{"f_4521expand.scm",(void*)f_4521},
{"f_4525expand.scm",(void*)f_4525},
{"f_4530expand.scm",(void*)f_4530},
{"f_4542expand.scm",(void*)f_4542},
{"f_4536expand.scm",(void*)f_4536},
{"f_4431expand.scm",(void*)f_4431},
{"f_4467expand.scm",(void*)f_4467},
{"f_4470expand.scm",(void*)f_4470},
{"f_4482expand.scm",(void*)f_4482},
{"f_4519expand.scm",(void*)f_4519},
{"f_4494expand.scm",(void*)f_4494},
{"f_4509expand.scm",(void*)f_4509},
{"f_4485expand.scm",(void*)f_4485},
{"f_4476expand.scm",(void*)f_4476},
{"f_4434expand.scm",(void*)f_4434},
{"f_4438expand.scm",(void*)f_4438},
{"f_4444expand.scm",(void*)f_4444},
{"f_4447expand.scm",(void*)f_4447},
{"f_4413expand.scm",(void*)f_4413},
{"f_4421expand.scm",(void*)f_4421},
{"f_3931expand.scm",(void*)f_3931},
{"f_4230expand.scm",(void*)f_4230},
{"f_4404expand.scm",(void*)f_4404},
{"f_4397expand.scm",(void*)f_4397},
{"f_4236expand.scm",(void*)f_4236},
{"f_4338expand.scm",(void*)f_4338},
{"f_4344expand.scm",(void*)f_4344},
{"f_4351expand.scm",(void*)f_4351},
{"f_4245expand.scm",(void*)f_4245},
{"f_4257expand.scm",(void*)f_4257},
{"f_4325expand.scm",(void*)f_4325},
{"f_4315expand.scm",(void*)f_4315},
{"f_4319expand.scm",(void*)f_4319},
{"f_4283expand.scm",(void*)f_4283},
{"f_4279expand.scm",(void*)f_4279},
{"f_4113expand.scm",(void*)f_4113},
{"f_4170expand.scm",(void*)f_4170},
{"f_4173expand.scm",(void*)f_4173},
{"f_4199expand.scm",(void*)f_4199},
{"f_4195expand.scm",(void*)f_4195},
{"f_4185expand.scm",(void*)f_4185},
{"f_4117expand.scm",(void*)f_4117},
{"f_4139expand.scm",(void*)f_4139},
{"f_3934expand.scm",(void*)f_3934},
{"f_3938expand.scm",(void*)f_3938},
{"f_4111expand.scm",(void*)f_4111},
{"f_4107expand.scm",(void*)f_4107},
{"f_3941expand.scm",(void*)f_3941},
{"f_3949expand.scm",(void*)f_3949},
{"f_4062expand.scm",(void*)f_4062},
{"f_4089expand.scm",(void*)f_4089},
{"f_4095expand.scm",(void*)f_4095},
{"f_4068expand.scm",(void*)f_4068},
{"f_4072expand.scm",(void*)f_4072},
{"f_4075expand.scm",(void*)f_4075},
{"f_3955expand.scm",(void*)f_3955},
{"f_3961expand.scm",(void*)f_3961},
{"f_3972expand.scm",(void*)f_3972},
{"f_3989expand.scm",(void*)f_3989},
{"f_4008expand.scm",(void*)f_4008},
{"f_4019expand.scm",(void*)f_4019},
{"f_3983expand.scm",(void*)f_3983},
{"f_3969expand.scm",(void*)f_3969},
{"f_3947expand.scm",(void*)f_3947},
{"f_3922expand.scm",(void*)f_3922},
{"f_3871expand.scm",(void*)f_3871},
{"f_3883expand.scm",(void*)f_3883},
{"f_3885expand.scm",(void*)f_3885},
{"f_3920expand.scm",(void*)f_3920},
{"f_3912expand.scm",(void*)f_3912},
{"f_3879expand.scm",(void*)f_3879},
{"f_3815expand.scm",(void*)f_3815},
{"f_3819expand.scm",(void*)f_3819},
{"f_3828expand.scm",(void*)f_3828},
{"f_3847expand.scm",(void*)f_3847},
{"f_3837expand.scm",(void*)f_3837},
{"f_3802expand.scm",(void*)f_3802},
{"f_3813expand.scm",(void*)f_3813},
{"f_3806expand.scm",(void*)f_3806},
{"f_3769expand.scm",(void*)f_3769},
{"f_3773expand.scm",(void*)f_3773},
{"f_3776expand.scm",(void*)f_3776},
{"f_3614expand.scm",(void*)f_3614},
{"f_3714expand.scm",(void*)f_3714},
{"f_3709expand.scm",(void*)f_3709},
{"f_3616expand.scm",(void*)f_3616},
{"f_3622expand.scm",(void*)f_3622},
{"f_3708expand.scm",(void*)f_3708},
{"f_3704expand.scm",(void*)f_3704},
{"f_3679expand.scm",(void*)f_3679},
{"f_3683expand.scm",(void*)f_3683},
{"f_3632expand.scm",(void*)f_3632},
{"f_3638expand.scm",(void*)f_3638},
{"f_3584expand.scm",(void*)f_3584},
{"f_3590expand.scm",(void*)f_3590},
{"f_3535expand.scm",(void*)f_3535},
{"f_3542expand.scm",(void*)f_3542},
{"f_3545expand.scm",(void*)f_3545},
{"f_3548expand.scm",(void*)f_3548},
{"f_3551expand.scm",(void*)f_3551},
{"f_3557expand.scm",(void*)f_3557},
{"f_3560expand.scm",(void*)f_3560},
{"f_3517expand.scm",(void*)f_3517},
{"f_3530expand.scm",(void*)f_3530},
{"f_3486expand.scm",(void*)f_3486},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
