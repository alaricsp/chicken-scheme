/* Generated from chicken.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-10-01 13:56
   Version 4.0.0x - linux-unix-gnu-x86	[ dload ptables applyhook lockts ]
   SVN rev. 11775	compiled 2008-08-28 on dill (Linux)
   command line: chicken.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -no-lambda-info -extend private-namespace.scm -output-file chicken.c
   used units: library eval data_structures ports extras srfi_69 srfi_1 srfi_4 utils files support compiler optimizer driver platform backend srfi_69
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_4_toplevel)
C_externimport void C_ccall C_srfi_4_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_support_toplevel)
C_externimport void C_ccall C_support_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_compiler_toplevel)
C_externimport void C_ccall C_compiler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_optimizer_toplevel)
C_externimport void C_ccall C_optimizer_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_driver_toplevel)
C_externimport void C_ccall C_driver_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_platform_toplevel)
C_externimport void C_ccall C_platform_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_backend_toplevel)
C_externimport void C_ccall C_backend_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[303];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1775)
static void C_ccall f_1775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1778)
static void C_ccall f_1778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1781)
static void C_ccall f_1781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1784)
static void C_ccall f_1784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1787)
static void C_ccall f_1787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1790)
static void C_ccall f_1790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1793)
static void C_ccall f_1793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1796)
static void C_ccall f_1796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1799)
static void C_ccall f_1799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1802)
static void C_ccall f_1802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1805)
static void C_ccall f_1805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1808)
static void C_ccall f_1808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1811)
static void C_ccall f_1811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1814)
static void C_ccall f_1814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1817)
static void C_ccall f_1817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1823)
static void C_ccall f_1823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1826)
static void C_ccall f_1826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1830)
static void C_ccall f_1830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8944)
static void C_ccall f_8944(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8948)
static void C_ccall f_8948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8957)
static void C_ccall f_8957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8963)
static void C_ccall f_8963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8966)
static void C_ccall f_8966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8969)
static void C_ccall f_8969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8972)
static void C_ccall f_8972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9382)
static void C_ccall f_9382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9342)
static void C_ccall f_9342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9374)
static void C_ccall f_9374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9334)
static void C_ccall f_9334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9290)
static void C_ccall f_9290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9001)
static void C_fcall f_9001(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9011)
static void C_ccall f_9011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9278)
static void C_ccall f_9278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9014)
static void C_ccall f_9014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9274)
static void C_ccall f_9274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9017)
static void C_ccall f_9017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9064)
static void C_fcall f_9064(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9028)
static void C_ccall f_9028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8999)
static void C_ccall f_8999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8995)
static void C_ccall f_8995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8942)
static void C_ccall f_8942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1833)
static void C_ccall f_1833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8801)
static void C_ccall f_8801(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8805)
static void C_ccall f_8805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8808)
static void C_ccall f_8808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8811)
static void C_ccall f_8811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8847)
static void C_ccall f_8847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8862)
static void C_fcall f_8862(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8916)
static void C_ccall f_8916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8877)
static void C_ccall f_8877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8840)
static void C_ccall f_8840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8799)
static void C_ccall f_8799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1836)
static void C_ccall f_1836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8702)
static void C_ccall f_8702(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8706)
static void C_ccall f_8706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8709)
static void C_ccall f_8709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8712)
static void C_ccall f_8712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8791)
static void C_ccall f_8791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8700)
static void C_ccall f_8700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8684)
static void C_ccall f_8684(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8692)
static void C_ccall f_8692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8682)
static void C_ccall f_8682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1842)
static void C_ccall f_1842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8595)
static void C_ccall f_8595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8599)
static void C_ccall f_8599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8602)
static void C_ccall f_8602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8605)
static void C_ccall f_8605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8671)
static void C_ccall f_8671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8608)
static void C_ccall f_8608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8621)
static void C_ccall f_8621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8665)
static void C_ccall f_8665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8632)
static void C_ccall f_8632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8640)
static void C_ccall f_8640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8642)
static void C_fcall f_8642(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8659)
static void C_ccall f_8659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8627)
static void C_ccall f_8627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8619)
static void C_ccall f_8619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8615)
static void C_ccall f_8615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8593)
static void C_ccall f_8593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1845)
static void C_ccall f_1845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8484)
static void C_ccall f_8484(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8488)
static void C_ccall f_8488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8497)
static void C_ccall f_8497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8500)
static void C_ccall f_8500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8503)
static void C_fcall f_8503(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8546)
static void C_ccall f_8546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8482)
static void C_ccall f_8482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1848)
static void C_ccall f_1848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8347)
static void C_ccall f_8347(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8351)
static void C_ccall f_8351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8363)
static void C_ccall f_8363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8366)
static void C_ccall f_8366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8369)
static void C_ccall f_8369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8420)
static void C_fcall f_8420(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8416)
static void C_ccall f_8416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8345)
static void C_ccall f_8345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1851)
static void C_ccall f_1851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8089)
static void C_ccall f_8089(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8093)
static void C_ccall f_8093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8102)
static void C_ccall f_8102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8333)
static void C_ccall f_8333(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8341)
static void C_ccall f_8341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8105)
static void C_ccall f_8105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8323)
static void C_ccall f_8323(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8331)
static void C_ccall f_8331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8108)
static void C_ccall f_8108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8111)
static void C_ccall f_8111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8114)
static void C_ccall f_8114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8321)
static void C_ccall f_8321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8281)
static void C_ccall f_8281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8299)
static void C_fcall f_8299(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8313)
static void C_ccall f_8313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8293)
static void C_ccall f_8293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8289)
static void C_ccall f_8289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8285)
static void C_ccall f_8285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8125)
static void C_ccall f_8125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8265)
static void C_ccall f_8265(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8233)
static void C_ccall f_8233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8251)
static void C_ccall f_8251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8241)
static void C_ccall f_8241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8237)
static void C_ccall f_8237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8229)
static void C_ccall f_8229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8221)
static void C_ccall f_8221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8201)
static void C_ccall f_8201(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8169)
static void C_ccall f_8169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8187)
static void C_ccall f_8187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8177)
static void C_ccall f_8177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8173)
static void C_ccall f_8173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8165)
static void C_ccall f_8165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8087)
static void C_ccall f_8087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1854)
static void C_ccall f_1854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7968)
static void C_ccall f_7968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7972)
static void C_ccall f_7972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7978)
static void C_ccall f_7978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8079)
static void C_ccall f_8079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7984)
static void C_ccall f_7984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7987)
static void C_ccall f_7987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7990)
static void C_ccall f_7990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8030)
static void C_fcall f_8030(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8053)
static void C_ccall f_8053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8060)
static void C_ccall f_8060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8067)
static void C_ccall f_8067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8043)
static void C_ccall f_8043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7993)
static void C_ccall f_7993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7966)
static void C_ccall f_7966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1857)
static void C_ccall f_1857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7766)
static void C_ccall f_7766(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7770)
static void C_ccall f_7770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7779)
static void C_ccall f_7779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7782)
static void C_ccall f_7782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7785)
static void C_ccall f_7785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7788)
static void C_ccall f_7788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7791)
static void C_ccall f_7791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7954)
static void C_ccall f_7954(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7962)
static void C_ccall f_7962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7794)
static void C_ccall f_7794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7944)
static void C_ccall f_7944(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7952)
static void C_ccall f_7952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7797)
static void C_ccall f_7797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7938)
static void C_ccall f_7938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7942)
static void C_ccall f_7942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7808)
static void C_ccall f_7808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7882)
static void C_ccall f_7882(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7880)
static void C_ccall f_7880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7876)
static void C_ccall f_7876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7856)
static void C_ccall f_7856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7764)
static void C_ccall f_7764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1860)
static void C_ccall f_1860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7721)
static void C_ccall f_7721(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7725)
static void C_ccall f_7725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7732)
static void C_ccall f_7732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7752)
static void C_ccall f_7752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7756)
static void C_ccall f_7756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7719)
static void C_ccall f_7719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1863)
static void C_ccall f_1863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7668)
static void C_ccall f_7668(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7672)
static void C_ccall f_7672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7679)
static void C_ccall f_7679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7707)
static void C_ccall f_7707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7711)
static void C_ccall f_7711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7666)
static void C_ccall f_7666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1866)
static void C_ccall f_1866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7523)
static void C_ccall f_7523(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7527)
static void C_ccall f_7527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7536)
static void C_ccall f_7536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7605)
static void C_ccall f_7605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7638)
static void C_ccall f_7638(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7636)
static void C_ccall f_7636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7632)
static void C_ccall f_7632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7521)
static void C_ccall f_7521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1869)
static void C_ccall f_1869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7481)
static void C_ccall f_7481(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7485)
static void C_ccall f_7485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7505)
static void C_ccall f_7505(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7513)
static void C_ccall f_7513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7488)
static void C_ccall f_7488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7495)
static void C_ccall f_7495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7499)
static void C_ccall f_7499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7479)
static void C_ccall f_7479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1872)
static void C_ccall f_1872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7093)
static void C_ccall f_7093(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7097)
static void C_ccall f_7097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7106)
static void C_ccall f_7106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7109)
static void C_ccall f_7109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7184)
static void C_ccall f_7184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7437)
static void C_fcall f_7437(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7450)
static void C_ccall f_7450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7187)
static void C_ccall f_7187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7423)
static void C_ccall f_7423(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7435)
static void C_ccall f_7435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7431)
static void C_ccall f_7431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7190)
static void C_ccall f_7190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7377)
static void C_fcall f_7377(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7410)
static void C_ccall f_7410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7417)
static void C_ccall f_7417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7393)
static void C_fcall f_7393(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7202)
static void C_ccall f_7202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7371)
static void C_ccall f_7371(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7209)
static void C_ccall f_7209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7211)
static void C_fcall f_7211(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7365)
static void C_ccall f_7365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7249)
static void C_fcall f_7249(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7331)
static void C_ccall f_7331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7288)
static void C_ccall f_7288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7268)
static void C_ccall f_7268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7235)
static void C_ccall f_7235(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7243)
static void C_ccall f_7243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7229)
static void C_ccall f_7229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7233)
static void C_ccall f_7233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7191)
static void C_ccall f_7191(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7142)
static void C_fcall f_7142(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7165)
static void C_ccall f_7165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7169)
static void C_ccall f_7169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7111)
static void C_fcall f_7111(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7132)
static void C_ccall f_7132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7091)
static void C_ccall f_7091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1875)
static void C_ccall f_1875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7021)
static void C_ccall f_7021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7025)
static void C_ccall f_7025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7034)
static void C_ccall f_7034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7037)
static void C_ccall f_7037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7042)
static void C_fcall f_7042(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7079)
static void C_ccall f_7079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7060)
static void C_ccall f_7060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7019)
static void C_ccall f_7019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1878)
static void C_ccall f_1878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6855)
static void C_ccall f_6855(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6859)
static void C_ccall f_6859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6868)
static void C_ccall f_6868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6871)
static void C_ccall f_6871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7011)
static void C_ccall f_7011(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7009)
static void C_ccall f_7009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6874)
static void C_ccall f_6874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6993)
static void C_ccall f_6993(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7005)
static void C_ccall f_7005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7001)
static void C_ccall f_7001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6877)
static void C_ccall f_6877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6987)
static void C_ccall f_6987(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6897)
static void C_ccall f_6897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6911)
static void C_ccall f_6911(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6939)
static void C_ccall f_6939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6949)
static void C_ccall f_6949(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6965)
static void C_ccall f_6965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6947)
static void C_ccall f_6947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6943)
static void C_ccall f_6943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6905)
static void C_ccall f_6905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6909)
static void C_ccall f_6909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6901)
static void C_ccall f_6901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6878)
static void C_ccall f_6878(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6853)
static void C_ccall f_6853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6781)
static void C_ccall f_6781(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6785)
static void C_ccall f_6785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6788)
static void C_ccall f_6788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6791)
static void C_ccall f_6791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6794)
static void C_ccall f_6794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6779)
static void C_ccall f_6779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1884)
static void C_ccall f_1884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6680)
static void C_ccall f_6680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6684)
static void C_ccall f_6684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6771)
static void C_ccall f_6771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6767)
static void C_ccall f_6767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6686)
static void C_fcall f_6686(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6690)
static void C_ccall f_6690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6747)
static void C_ccall f_6747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6699)
static void C_fcall f_6699(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6721)
static void C_ccall f_6721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6711)
static void C_fcall f_6711(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6702)
static void C_ccall f_6702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6678)
static void C_ccall f_6678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1887)
static void C_ccall f_1887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6517)
static void C_ccall f_6517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6521)
static void C_ccall f_6521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6530)
static void C_ccall f_6530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6533)
static void C_ccall f_6533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6538)
static void C_fcall f_6538(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6583)
static void C_ccall f_6583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6650)
static void C_ccall f_6650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6612)
static void C_ccall f_6612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6552)
static void C_ccall f_6552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6556)
static void C_ccall f_6556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6515)
static void C_ccall f_6515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1890)
static void C_ccall f_1890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6348)
static void C_ccall f_6348(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6352)
static void C_ccall f_6352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6361)
static void C_ccall f_6361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6364)
static void C_ccall f_6364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6367)
static void C_ccall f_6367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6370)
static void C_ccall f_6370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6373)
static void C_ccall f_6373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6376)
static void C_ccall f_6376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6383)
static void C_ccall f_6383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6401)
static void C_fcall f_6401(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6417)
static void C_ccall f_6417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6423)
static void C_ccall f_6423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6479)
static void C_ccall f_6479(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6477)
static void C_ccall f_6477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6473)
static void C_ccall f_6473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6465)
static void C_ccall f_6465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6461)
static void C_ccall f_6461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6430)
static void C_ccall f_6430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6399)
static void C_ccall f_6399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6346)
static void C_ccall f_6346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1893)
static void C_ccall f_1893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5916)
static void C_ccall f_5916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5920)
static void C_ccall f_5920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5932)
static void C_ccall f_5932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5935)
static void C_ccall f_5935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5938)
static void C_ccall f_5938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5941)
static void C_ccall f_5941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5944)
static void C_ccall f_5944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5947)
static void C_ccall f_5947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6235)
static void C_ccall f_6235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6238)
static void C_ccall f_6238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6241)
static void C_ccall f_6241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6334)
static void C_ccall f_6334(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6342)
static void C_ccall f_6342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6257)
static void C_ccall f_6257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6260)
static void C_ccall f_6260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6263)
static void C_ccall f_6263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6266)
static void C_ccall f_6266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6324)
static void C_ccall f_6324(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6332)
static void C_ccall f_6332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6269)
static void C_ccall f_6269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6272)
static void C_ccall f_6272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6275)
static void C_ccall f_6275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6282)
static void C_ccall f_6282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6242)
static void C_fcall f_6242(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6254)
static void C_ccall f_6254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6250)
static void C_ccall f_6250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6046)
static void C_fcall f_6046(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6052)
static void C_fcall f_6052(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6228)
static void C_ccall f_6228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6172)
static void C_ccall f_6172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6114)
static void C_ccall f_6114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5949)
static void C_fcall f_5949(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5957)
static void C_ccall f_5957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5961)
static void C_ccall f_5961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5965)
static void C_ccall f_5965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5967)
static void C_fcall f_5967(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6020)
static void C_ccall f_6020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6036)
static void C_ccall f_6036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6032)
static void C_ccall f_6032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5988)
static void C_ccall f_5988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5914)
static void C_ccall f_5914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1896)
static void C_ccall f_1896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5732)
static void C_ccall f_5732(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5736)
static void C_ccall f_5736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5739)
static void C_ccall f_5739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5742)
static void C_ccall f_5742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5745)
static void C_ccall f_5745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5752)
static void C_ccall f_5752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5787)
static void C_ccall f_5787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5871)
static void C_ccall f_5871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5847)
static void C_ccall f_5847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5730)
static void C_ccall f_5730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1899)
static void C_ccall f_1899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5430)
static void C_ccall f_5430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5434)
static void C_ccall f_5434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5446)
static void C_ccall f_5446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5449)
static void C_ccall f_5449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5452)
static void C_ccall f_5452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5455)
static void C_ccall f_5455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5458)
static void C_ccall f_5458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5461)
static void C_ccall f_5461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5482)
static void C_fcall f_5482(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5710)
static void C_ccall f_5710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5572)
static void C_ccall f_5572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5591)
static void C_ccall f_5591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5548)
static void C_ccall f_5548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5480)
static void C_ccall f_5480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5428)
static void C_ccall f_5428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1902)
static void C_ccall f_1902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5009)
static void C_ccall f_5009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5013)
static void C_ccall f_5013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5050)
static void C_ccall f_5050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5409)
static void C_ccall f_5409(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5419)
static void C_ccall f_5419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5407)
static void C_ccall f_5407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5053)
static void C_ccall f_5053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5056)
static void C_ccall f_5056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5059)
static void C_ccall f_5059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5062)
static void C_ccall f_5062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5065)
static void C_ccall f_5065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5068)
static void C_ccall f_5068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5071)
static void C_ccall f_5071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5082)
static void C_ccall f_5082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5108)
static void C_ccall f_5108(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5118)
static void C_ccall f_5118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5122)
static void C_ccall f_5122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5371)
static void C_ccall f_5371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5356)
static void C_ccall f_5356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5136)
static void C_fcall f_5136(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5160)
static void C_ccall f_5160(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5187)
static void C_fcall f_5187(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5343)
static void C_ccall f_5343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5255)
static void C_ccall f_5255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5335)
static void C_ccall f_5335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5315)
static void C_ccall f_5315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5274)
static void C_ccall f_5274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5244)
static void C_ccall f_5244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5212)
static void C_ccall f_5212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5164)
static void C_ccall f_5164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5181)
static void C_ccall f_5181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5150)
static void C_ccall f_5150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5158)
static void C_ccall f_5158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5144)
static void C_ccall f_5144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5106)
static void C_ccall f_5106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5015)
static void C_fcall f_5015(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5021)
static void C_fcall f_5021(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5047)
static void C_ccall f_5047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5035)
static void C_ccall f_5035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5039)
static void C_ccall f_5039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5007)
static void C_ccall f_5007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1905)
static void C_ccall f_1905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4911)
static void C_ccall f_4911(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4915)
static void C_ccall f_4915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4980)
static void C_ccall f_4980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4995)
static void C_ccall f_4995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4930)
static void C_ccall f_4930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4953)
static void C_ccall f_4953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4965)
static void C_ccall f_4965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4909)
static void C_ccall f_4909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4717)
static void C_ccall f_4717(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4721)
static void C_ccall f_4721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4724)
static void C_ccall f_4724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4727)
static void C_ccall f_4727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4730)
static void C_ccall f_4730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4741)
static void C_ccall f_4741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4769)
static void C_ccall f_4769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4861)
static void C_ccall f_4861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4715)
static void C_ccall f_4715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4390)
static void C_ccall f_4390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4394)
static void C_ccall f_4394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4397)
static void C_ccall f_4397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4400)
static void C_ccall f_4400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4403)
static void C_ccall f_4403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4406)
static void C_ccall f_4406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4409)
static void C_ccall f_4409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4412)
static void C_ccall f_4412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4587)
static void C_ccall f_4587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4627)
static void C_ccall f_4627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4635)
static void C_ccall f_4635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4631)
static void C_ccall f_4631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4414)
static void C_ccall f_4414(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4538)
static void C_ccall f_4538(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4536)
static void C_ccall f_4536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4532)
static void C_ccall f_4532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4524)
static void C_ccall f_4524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4505)
static void C_ccall f_4505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4490)
static void C_fcall f_4490(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4475)
static void C_ccall f_4475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4456)
static void C_ccall f_4456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4441)
static void C_fcall f_4441(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4388)
static void C_ccall f_4388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4015)
static void C_ccall f_4015(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4019)
static void C_ccall f_4019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4034)
static void C_ccall f_4034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4037)
static void C_ccall f_4037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4040)
static void C_ccall f_4040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4046)
static void C_ccall f_4046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4049)
static void C_ccall f_4049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4052)
static void C_ccall f_4052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4055)
static void C_ccall f_4055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4373)
static void C_ccall f_4373(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4371)
static void C_ccall f_4371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4367)
static void C_ccall f_4367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4084)
static void C_fcall f_4084(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4110)
static void C_fcall f_4110(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4150)
static void C_fcall f_4150(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4126)
static void C_ccall f_4126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4122)
static void C_ccall f_4122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4082)
static void C_ccall f_4082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4078)
static void C_ccall f_4078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4013)
static void C_ccall f_4013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1917)
static void C_ccall f_1917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3827)
static void C_ccall f_3827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3831)
static void C_ccall f_3831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3834)
static void C_ccall f_3834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3837)
static void C_ccall f_3837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3840)
static void C_ccall f_3840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3843)
static void C_ccall f_3843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3852)
static void C_fcall f_3852(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3955)
static void C_ccall f_3955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3983)
static void C_ccall f_3983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3977)
static void C_ccall f_3977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3958)
static void C_ccall f_3958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3862)
static void C_ccall f_3862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3865)
static void C_ccall f_3865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3937)
static void C_ccall f_3937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3914)
static void C_ccall f_3914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3871)
static void C_ccall f_3871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3902)
static void C_ccall f_3902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3825)
static void C_ccall f_3825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1920)
static void C_ccall f_1920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3608)
static void C_ccall f_3608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3612)
static void C_ccall f_3612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3615)
static void C_ccall f_3615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3618)
static void C_ccall f_3618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3621)
static void C_ccall f_3621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3624)
static void C_ccall f_3624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3633)
static void C_fcall f_3633(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3752)
static void C_ccall f_3752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3780)
static void C_ccall f_3780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3813)
static void C_ccall f_3813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3786)
static void C_ccall f_3786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3774)
static void C_ccall f_3774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3755)
static void C_ccall f_3755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3643)
static void C_ccall f_3643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3646)
static void C_ccall f_3646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3742)
static void C_ccall f_3742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3707)
static void C_ccall f_3707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3652)
static void C_ccall f_3652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3675)
static void C_ccall f_3675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3695)
static void C_ccall f_3695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1923)
static void C_ccall f_1923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3335)
static void C_ccall f_3335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3338)
static void C_ccall f_3338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3341)
static void C_ccall f_3341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3344)
static void C_ccall f_3344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3347)
static void C_ccall f_3347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3350)
static void C_ccall f_3350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3359)
static void C_fcall f_3359(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3505)
static void C_fcall f_3505(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3508)
static void C_ccall f_3508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3517)
static void C_ccall f_3517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3542)
static void C_ccall f_3542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3567)
static void C_ccall f_3567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3589)
static void C_ccall f_3589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3582)
static void C_ccall f_3582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3574)
static void C_ccall f_3574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3561)
static void C_ccall f_3561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3557)
static void C_ccall f_3557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3536)
static void C_ccall f_3536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3532)
static void C_ccall f_3532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3499)
static void C_ccall f_3499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3369)
static void C_fcall f_3369(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3376)
static void C_ccall f_3376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3484)
static void C_ccall f_3484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3472)
static void C_ccall f_3472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3468)
static void C_ccall f_3468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3404)
static void C_ccall f_3404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3432)
static void C_ccall f_3432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3444)
static void C_ccall f_3444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3428)
static void C_ccall f_3428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1926)
static void C_ccall f_1926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3227)
static void C_ccall f_3227(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3231)
static void C_ccall f_3231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3237)
static void C_ccall f_3237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3321)
static void C_ccall f_3321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3282)
static void C_ccall f_3282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3294)
static void C_ccall f_3294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3225)
static void C_ccall f_3225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1929)
static void C_ccall f_1929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3123)
static void C_ccall f_3123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3197)
static void C_ccall f_3197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3209)
static void C_ccall f_3209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3138)
static void C_fcall f_3138(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3184)
static void C_ccall f_3184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3141)
static void C_ccall f_3141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3144)
static void C_ccall f_3144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3154)
static void C_ccall f_3154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3117)
static void C_ccall f_3117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1932)
static void C_ccall f_1932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3094)
static void C_ccall f_3094(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3098)
static void C_ccall f_3098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3092)
static void C_ccall f_3092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1935)
static void C_ccall f_1935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3084)
static void C_ccall f_3084(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3082)
static void C_ccall f_3082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1938)
static void C_ccall f_1938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1941)
static void C_ccall f_1941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1944)
static void C_ccall f_1944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1948)
static void C_ccall f_1948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2782)
static void C_ccall f_2782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2789)
static void C_ccall f_2789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2792)
static void C_fcall f_2792(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2795)
static void C_fcall f_2795(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2900)
static void C_ccall f_2900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2913)
static void C_ccall f_2913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3011)
static void C_ccall f_3011(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3009)
static void C_ccall f_3009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2973)
static void C_ccall f_2973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2997)
static void C_ccall f_2997(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2981)
static void C_ccall f_2981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2985)
static void C_ccall f_2985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2801)
static void C_ccall f_2801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2811)
static void C_ccall f_2811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2885)
static void C_ccall f_2885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2865)
static void C_ccall f_2865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2835)
static void C_fcall f_2835(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2831)
static void C_ccall f_2831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2780)
static void C_ccall f_2780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1951)
static void C_ccall f_1951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2641)
static void C_ccall f_2641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2645)
static void C_ccall f_2645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2657)
static void C_ccall f_2657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2757)
static void C_ccall f_2757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2660)
static void C_ccall f_2660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2667)
static void C_ccall f_2667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2737)
static void C_ccall f_2737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2753)
static void C_ccall f_2753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2717)
static void C_ccall f_2717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2691)
static void C_fcall f_2691(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2687)
static void C_ccall f_2687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2639)
static void C_ccall f_2639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1954)
static void C_ccall f_1954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2491)
static void C_ccall f_2491(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2495)
static void C_ccall f_2495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2504)
static void C_ccall f_2504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2627)
static void C_ccall f_2627(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2635)
static void C_ccall f_2635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2507)
static void C_ccall f_2507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2603)
static void C_ccall f_2603(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2518)
static void C_ccall f_2518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2601)
static void C_ccall f_2601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2528)
static void C_ccall f_2528(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2526)
static void C_ccall f_2526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2489)
static void C_ccall f_2489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1957)
static void C_ccall f_1957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2423)
static void C_ccall f_2423(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2427)
static void C_ccall f_2427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_ccall f_2430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2437)
static void C_ccall f_2437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2461)
static void C_ccall f_2461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2481)
static void C_ccall f_2481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2477)
static void C_ccall f_2477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2421)
static void C_ccall f_2421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1960)
static void C_ccall f_1960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2367)
static void C_ccall f_2367(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2371)
static void C_ccall f_2371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2374)
static void C_ccall f_2374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2381)
static void C_ccall f_2381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2397)
static void C_ccall f_2397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2365)
static void C_ccall f_2365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1963)
static void C_ccall f_1963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2338)
static void C_ccall f_2338(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2342)
static void C_ccall f_2342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2357)
static void C_ccall f_2357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2336)
static void C_ccall f_2336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1966)
static void C_ccall f_1966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1969)
static void C_ccall f_1969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2329)
static void C_ccall f_2329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2325)
static void C_ccall f_2325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2317)
static void C_ccall f_2317(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2315)
static void C_ccall f_2315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2102)
static void C_ccall f_2102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2114)
static void C_fcall f_2114(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2290)
static void C_ccall f_2290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2253)
static void C_ccall f_2253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2199)
static void C_ccall f_2199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2216)
static void C_ccall f_2216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2202)
static void C_ccall f_2202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2136)
static void C_ccall f_2136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2179)
static void C_ccall f_2179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2159)
static void C_ccall f_2159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2139)
static void C_ccall f_2139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2106)
static void C_ccall f_2106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2109)
static void C_ccall f_2109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2090)
static void C_ccall f_2090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2097)
static void C_ccall f_2097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2082)
static void C_ccall f_2082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2088)
static void C_ccall f_2088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2085)
static void C_ccall f_2085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1975)
static void C_ccall f_1975(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1981)
static void C_fcall f_1981(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2016)
static void C_fcall f_2016(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2042)
static void C_ccall f_2042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2038)
static void C_ccall f_2038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1995)
static void C_ccall f_1995(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_9001)
static void C_fcall trf_9001(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9001(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9001(t0,t1,t2,t3);}

C_noret_decl(trf_9064)
static void C_fcall trf_9064(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9064(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9064(t0,t1);}

C_noret_decl(trf_8862)
static void C_fcall trf_8862(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8862(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8862(t0,t1);}

C_noret_decl(trf_8642)
static void C_fcall trf_8642(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8642(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8642(t0,t1,t2,t3);}

C_noret_decl(trf_8503)
static void C_fcall trf_8503(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8503(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8503(t0,t1);}

C_noret_decl(trf_8420)
static void C_fcall trf_8420(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8420(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8420(t0,t1);}

C_noret_decl(trf_8299)
static void C_fcall trf_8299(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8299(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8299(t0,t1,t2);}

C_noret_decl(trf_8030)
static void C_fcall trf_8030(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8030(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8030(t0,t1,t2);}

C_noret_decl(trf_7437)
static void C_fcall trf_7437(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7437(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7437(t0,t1,t2,t3);}

C_noret_decl(trf_7377)
static void C_fcall trf_7377(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7377(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7377(t0,t1,t2,t3);}

C_noret_decl(trf_7393)
static void C_fcall trf_7393(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7393(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7393(t0,t1);}

C_noret_decl(trf_7211)
static void C_fcall trf_7211(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7211(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7211(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7249)
static void C_fcall trf_7249(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7249(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7249(t0,t1);}

C_noret_decl(trf_7142)
static void C_fcall trf_7142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7142(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7142(t0,t1,t2,t3);}

C_noret_decl(trf_7111)
static void C_fcall trf_7111(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7111(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7111(t0,t1,t2,t3);}

C_noret_decl(trf_7042)
static void C_fcall trf_7042(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7042(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7042(t0,t1,t2);}

C_noret_decl(trf_6686)
static void C_fcall trf_6686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6686(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6686(t0,t1,t2,t3);}

C_noret_decl(trf_6699)
static void C_fcall trf_6699(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6699(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6699(t0,t1);}

C_noret_decl(trf_6711)
static void C_fcall trf_6711(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6711(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6711(t0,t1);}

C_noret_decl(trf_6538)
static void C_fcall trf_6538(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6538(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6538(t0,t1,t2);}

C_noret_decl(trf_6401)
static void C_fcall trf_6401(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6401(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6401(t0,t1,t2);}

C_noret_decl(trf_6242)
static void C_fcall trf_6242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6242(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6242(t0,t1,t2);}

C_noret_decl(trf_6046)
static void C_fcall trf_6046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6046(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6046(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6052)
static void C_fcall trf_6052(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6052(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6052(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5949)
static void C_fcall trf_5949(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5949(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5949(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5967)
static void C_fcall trf_5967(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5967(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5967(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5482)
static void C_fcall trf_5482(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5482(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5482(t0,t1,t2,t3);}

C_noret_decl(trf_5136)
static void C_fcall trf_5136(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5136(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5136(t0,t1);}

C_noret_decl(trf_5187)
static void C_fcall trf_5187(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5187(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5187(t0,t1,t2,t3);}

C_noret_decl(trf_5015)
static void C_fcall trf_5015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5015(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5015(t0,t1,t2);}

C_noret_decl(trf_5021)
static void C_fcall trf_5021(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5021(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5021(t0,t1,t2);}

C_noret_decl(trf_4490)
static void C_fcall trf_4490(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4490(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4490(t0,t1);}

C_noret_decl(trf_4441)
static void C_fcall trf_4441(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4441(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4441(t0,t1);}

C_noret_decl(trf_4084)
static void C_fcall trf_4084(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4084(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4084(t0,t1,t2,t3);}

C_noret_decl(trf_4110)
static void C_fcall trf_4110(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4110(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4110(t0,t1);}

C_noret_decl(trf_4150)
static void C_fcall trf_4150(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4150(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4150(t0,t1);}

C_noret_decl(trf_3852)
static void C_fcall trf_3852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3852(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3852(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3633)
static void C_fcall trf_3633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3633(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3633(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3359)
static void C_fcall trf_3359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3359(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3359(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3505)
static void C_fcall trf_3505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3505(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3505(t0,t1);}

C_noret_decl(trf_3369)
static void C_fcall trf_3369(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3369(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3369(t0,t1);}

C_noret_decl(trf_3138)
static void C_fcall trf_3138(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3138(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3138(t0,t1);}

C_noret_decl(trf_2792)
static void C_fcall trf_2792(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2792(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2792(t0,t1);}

C_noret_decl(trf_2795)
static void C_fcall trf_2795(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2795(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2795(t0,t1);}

C_noret_decl(trf_2835)
static void C_fcall trf_2835(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2835(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2835(t0,t1);}

C_noret_decl(trf_2691)
static void C_fcall trf_2691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2691(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2691(t0,t1);}

C_noret_decl(trf_2114)
static void C_fcall trf_2114(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2114(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2114(t0,t1,t2);}

C_noret_decl(trf_1981)
static void C_fcall trf_1981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1981(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1981(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2016)
static void C_fcall trf_2016(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2016(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2016(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3967)){
C_save(t1);
C_rereclaim2(3967*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,303);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],29,"\003syschicken-macro-environment");
lf[3]=C_h_intern(&lf[3],33,"\003syschicken-ffi-macro-environment");
lf[4]=C_h_intern(&lf[4],27,"\010compilercompiler-arguments");
lf[5]=C_h_intern(&lf[5],29,"\010compilerprocess-command-line");
lf[6]=C_h_intern(&lf[6],7,"reverse");
lf[7]=C_h_intern(&lf[7],14,"string->symbol");
lf[8]=C_h_intern(&lf[8],9,"substring");
lf[9]=C_h_intern(&lf[9],25,"\003sysimplicit-exit-handler");
lf[10]=C_h_intern(&lf[10],17,"user-options-pass");
lf[11]=C_h_intern(&lf[11],4,"exit");
lf[12]=C_h_intern(&lf[12],19,"compile-source-file");
lf[13]=C_h_intern(&lf[13],14,"optimize-level");
lf[14]=C_h_intern(&lf[14],5,"cons*");
lf[15]=C_h_intern(&lf[15],22,"optimize-leaf-routines");
lf[16]=C_h_intern(&lf[16],6,"unsafe");
lf[17]=C_h_intern(&lf[17],25,"\010compilercompiler-warning");
lf[18]=C_h_intern(&lf[18],5,"usage");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\047invalid optimization level ~S - ignored");
lf[20]=C_h_intern(&lf[20],11,"debug-level");
lf[21]=C_h_intern(&lf[21],14,"no-lambda-info");
lf[22]=C_h_intern(&lf[22],8,"no-trace");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000 invalid debug level ~S - ignored");
lf[24]=C_h_intern(&lf[24],14,"benchmark-mode");
lf[25]=C_h_intern(&lf[25],17,"fixnum-arithmetic");
lf[26]=C_h_intern(&lf[26],18,"disable-interrupts");
lf[27]=C_h_intern(&lf[27],5,"block");
lf[28]=C_h_intern(&lf[28],11,"lambda-lift");
lf[29]=C_h_intern(&lf[29],31,"\010compilervalid-compiler-options");
lf[30]=C_h_intern(&lf[30],45,"\010compilervalid-compiler-options-with-argument");
lf[31]=C_h_intern(&lf[31],4,"quit");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~s\047 option");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000&invalid compiler option `~a\047 - ignored");
lf[34]=C_h_intern(&lf[34],4,"conc");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[36]=C_h_intern(&lf[36],6,"append");
lf[37]=C_h_intern(&lf[37],4,"argv");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[39]=C_h_intern(&lf[39],6,"remove");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[41]=C_h_intern(&lf[41],12,"string-split");
lf[42]=C_h_intern(&lf[42],6,"getenv");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\017CHICKEN_OPTIONS");
lf[44]=C_h_intern(&lf[44],16,"\003sysmacro-subset");
lf[45]=C_h_intern(&lf[45],28,"\003sysextend-macro-environment");
lf[46]=C_h_intern(&lf[46],15,"foreign-declare");
lf[47]=C_h_intern(&lf[47],12,"\004coredeclare");
lf[48]=C_h_intern(&lf[48],10,"\003sysappend");
lf[49]=C_h_intern(&lf[49],16,"\003syscheck-syntax");
lf[50]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\000");
lf[51]=C_h_intern(&lf[51],18,"\003syser-transformer");
lf[52]=C_h_intern(&lf[52],13,"foreign-value");
lf[53]=C_h_intern(&lf[53],23,"define-foreign-variable");
lf[54]=C_h_intern(&lf[54],5,"begin");
lf[55]=C_h_intern(&lf[55],6,"gensym");
lf[56]=C_h_intern(&lf[56],5,"code_");
lf[57]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[58]=C_h_intern(&lf[58],12,"foreign-code");
lf[59]=C_h_intern(&lf[59],11,"\004coreinline");
lf[60]=C_h_intern(&lf[60],7,"sprintf");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\0007static C_word ~A() { ~A\012; return C_SCHEME_UNDEFINED; }\012");
lf[62]=C_h_intern(&lf[62],18,"string-intersperse");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[64]=C_h_intern(&lf[64],7,"declare");
lf[65]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\000");
lf[66]=C_h_intern(&lf[66],12,"let-location");
lf[67]=C_h_intern(&lf[67],17,"\004corelet-location");
lf[68]=C_h_intern(&lf[68],10,"fold-right");
lf[69]=C_h_intern(&lf[69],10,"append-map");
lf[70]=C_h_intern(&lf[70],7,"\003sysmap");
lf[71]=C_h_intern(&lf[71],3,"let");
lf[72]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001\376\377\001\000\000"
"\000\000\376\001\000\000\001_");
lf[73]=C_h_intern(&lf[73],15,"define-location");
lf[74]=C_h_intern(&lf[74],9,"\004coreset!");
lf[75]=C_h_intern(&lf[75],24,"define-external-variable");
lf[76]=C_h_intern(&lf[76],14,"symbol->string");
lf[77]=C_h_intern(&lf[77],9,"\003syserror");
lf[78]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[79]=C_h_intern(&lf[79],15,"define-external");
lf[80]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[81]=C_h_intern(&lf[81],5,"quote");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[83]=C_h_intern(&lf[83],29,"\004coreforeign-callback-wrapper");
lf[84]=C_h_intern(&lf[84],6,"lambda");
lf[85]=C_h_intern(&lf[85],6,"define");
lf[86]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376"
"\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[87]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376"
"\001\000\000\001_\376\377\001\000\000\000\001");
lf[88]=C_h_intern(&lf[88],21,"\003sysmacro-environment");
lf[89]=C_h_intern(&lf[89],17,"register-feature!");
lf[90]=C_h_intern(&lf[90],6,"srfi-8");
lf[91]=C_h_intern(&lf[91],7,"srfi-16");
lf[92]=C_h_intern(&lf[92],7,"srfi-26");
lf[93]=C_h_intern(&lf[93],7,"srfi-31");
lf[94]=C_h_intern(&lf[94],7,"srfi-15");
lf[95]=C_h_intern(&lf[95],7,"srfi-11");
lf[96]=C_h_intern(&lf[96],12,"define-macro");
lf[97]=C_h_intern(&lf[97],12,"syntax-error");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000<`define-macro\047 is not supported - please use `define-syntax\047");
lf[99]=C_h_intern(&lf[99],3,"use");
lf[100]=C_h_intern(&lf[100],22,"\004corerequire-extension");
lf[101]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[102]=C_h_intern(&lf[102],17,"define-for-syntax");
lf[103]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016\376\377\016");
lf[104]=C_h_intern(&lf[104],25,"\003sysenable-runtime-macros");
lf[105]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[106]=C_h_intern(&lf[106],28,"\003sysregister-meta-expression");
lf[107]=C_h_intern(&lf[107],4,"eval");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\022invalid identifier");
lf[109]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[110]=C_h_intern(&lf[110],3,"rec");
lf[111]=C_h_intern(&lf[111],6,"letrec");
lf[112]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[113]=C_h_intern(&lf[113],16,"define-extension");
lf[114]=C_h_intern(&lf[114],22,"chicken-compile-shared");
lf[115]=C_h_intern(&lf[115],9,"compiling");
lf[116]=C_h_intern(&lf[116],4,"name");
lf[117]=C_h_intern(&lf[117],4,"unit");
lf[118]=C_h_intern(&lf[118],7,"provide");
lf[119]=C_h_intern(&lf[119],4,"else");
lf[120]=C_h_intern(&lf[120],3,"not");
lf[121]=C_h_intern(&lf[121],11,"cond-expand");
lf[122]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\007unquote\376\003\000\000\002\376\001\000\000\006%begin\376\377\016\376\377\016");
lf[123]=C_h_intern(&lf[123],4,"cdar");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid clause specifier");
lf[125]=C_h_intern(&lf[125],4,"caar");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid clause syntax");
lf[127]=C_h_intern(&lf[127],6,"export");
lf[128]=C_h_intern(&lf[128],7,"dynamic");
lf[129]=C_h_intern(&lf[129],6,"static");
lf[130]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\001_");
lf[131]=C_h_intern(&lf[131],4,"cute");
lf[132]=C_h_intern(&lf[132],5,"apply");
lf[133]=C_h_intern(&lf[133],5,"<...>");
lf[134]=C_h_intern(&lf[134],2,"<>");
lf[135]=C_h_intern(&lf[135],3,"cut");
lf[136]=C_h_intern(&lf[136],18,"define-record-type");
lf[137]=C_h_intern(&lf[137],18,"\003sysmake-structure");
lf[138]=C_h_intern(&lf[138],14,"\003sysstructure\077");
lf[139]=C_h_intern(&lf[139],15,"\000record-setters");
lf[140]=C_h_intern(&lf[140],12,"\003sysfeatures");
lf[141]=C_h_intern(&lf[141],19,"\003syscheck-structure");
lf[142]=C_h_intern(&lf[142],10,"\004corecheck");
lf[143]=C_h_intern(&lf[143],13,"\003sysblock-ref");
lf[144]=C_h_intern(&lf[144],14,"\003sysblock-set!");
lf[145]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[146]=C_h_intern(&lf[146],3,"car");
lf[147]=C_h_intern(&lf[147],18,"getter-with-setter");
lf[148]=C_h_intern(&lf[148],1,"y");
lf[149]=C_h_intern(&lf[149],1,"x");
lf[150]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\001\376\003\000\000\002\376\001\000\000\010variable\376\001\000"
"\000\001_");
lf[151]=C_h_intern(&lf[151],14,"condition-case");
lf[152]=C_h_intern(&lf[152],9,"condition");
lf[153]=C_h_intern(&lf[153],8,"\003sysslot");
lf[154]=C_h_intern(&lf[154],10,"\003syssignal");
lf[155]=C_h_intern(&lf[155],4,"cond");
lf[156]=C_h_intern(&lf[156],17,"handle-exceptions");
lf[157]=C_h_intern(&lf[157],4,"memv");
lf[158]=C_h_intern(&lf[158],3,"and");
lf[159]=C_h_intern(&lf[159],4,"kvar");
lf[160]=C_h_intern(&lf[160],5,"exvar");
lf[161]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[162]=C_h_intern(&lf[162],10,"\003sysvalues");
lf[163]=C_h_intern(&lf[163],9,"\003sysapply");
lf[164]=C_h_intern(&lf[164],20,"\003syscall-with-values");
lf[165]=C_h_intern(&lf[165],22,"with-exception-handler");
lf[166]=C_h_intern(&lf[166],30,"call-with-current-continuation");
lf[167]=C_h_intern(&lf[167],4,"args");
lf[168]=C_h_intern(&lf[168],1,"k");
lf[169]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[170]=C_h_intern(&lf[170],21,"define-record-printer");
lf[171]=C_h_intern(&lf[171],27,"\003sysregister-record-printer");
lf[172]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[173]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[174]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[175]=C_h_intern(&lf[175],11,"case-lambda");
lf[176]=C_h_intern(&lf[176],6,"length");
lf[177]=C_h_intern(&lf[177],9,"split-at!");
lf[178]=C_h_intern(&lf[178],4,"take");
lf[179]=C_h_intern(&lf[179],3,"map");
lf[180]=C_h_intern(&lf[180],4,"list");
lf[181]=C_h_intern(&lf[181],3,"cdr");
lf[182]=C_h_intern(&lf[182],4,"fx>=");
lf[183]=C_h_intern(&lf[183],3,"fx=");
lf[184]=C_h_intern(&lf[184],11,"lambda-list");
lf[185]=C_h_intern(&lf[185],25,"\003sysdecompose-lambda-list");
lf[186]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corecheck\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\003syserror\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreimmutable\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376B\000\0000no matching clause in call to \047case-lambda\047 form\376\377\016\376\377\016\376\377\016"
"\376\377\016");
lf[187]=C_h_intern(&lf[187],2,"if");
lf[188]=C_h_intern(&lf[188],4,"lvar");
lf[189]=C_h_intern(&lf[189],4,"rvar");
lf[190]=C_h_intern(&lf[190],3,"min");
lf[191]=C_h_intern(&lf[191],7,"require");
lf[192]=C_h_intern(&lf[192],6,"srfi-1");
lf[193]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[194]=C_h_intern(&lf[194],14,"let-optionals*");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[196]=C_h_intern(&lf[196],14,"\004coreimmutable");
lf[197]=C_h_intern(&lf[197],4,"tmp2");
lf[198]=C_h_intern(&lf[198],3,"tmp");
lf[199]=C_h_intern(&lf[199],5,"null\077");
lf[200]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[201]=C_h_intern(&lf[201],8,"optional");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[203]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[204]=C_h_intern(&lf[204],13,"let-optionals");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[206]=C_h_intern(&lf[206],13,"string-append");
lf[207]=C_h_intern(&lf[207],4,"let*");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\004def-");
lf[209]=C_h_intern(&lf[209],5,"%rest");
lf[210]=C_h_intern(&lf[210],4,"body");
lf[211]=C_h_intern(&lf[211],4,"cadr");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\001%");
lf[213]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[214]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[215]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[216]=C_h_intern(&lf[216],6,"select");
lf[217]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[218]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[219]=C_h_intern(&lf[219],4,"eqv\077");
lf[220]=C_h_intern(&lf[220],2,"or");
lf[221]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[222]=C_h_intern(&lf[222],8,"and-let*");
lf[223]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\001\000\000\001_");
lf[224]=C_h_intern(&lf[224],13,"define-inline");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000*invalid substitution form - must be lambda");
lf[226]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[227]=C_h_intern(&lf[227],18,"\004coredefine-inline");
lf[228]=C_h_intern(&lf[228],9,"nth-value");
lf[229]=C_h_intern(&lf[229],8,"list-ref");
lf[230]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[231]=C_h_intern(&lf[231],13,"letrec-values");
lf[232]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[233]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[234]=C_h_intern(&lf[234],11,"let*-values");
lf[235]=C_h_intern(&lf[235],10,"let-values");
lf[236]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[237]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[238]=C_h_intern(&lf[238],13,"define-values");
lf[239]=C_h_intern(&lf[239],11,"set!-values");
lf[240]=C_h_intern(&lf[240],19,"\003sysregister-export");
lf[241]=C_h_intern(&lf[241],18,"\003syscurrent-module");
lf[242]=C_h_intern(&lf[242],12,"\003sysfor-each");
lf[243]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[244]=C_h_intern(&lf[244],14,"\004coreundefined");
lf[245]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[246]=C_h_intern(&lf[246],6,"unless");
lf[247]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[248]=C_h_intern(&lf[248],4,"when");
lf[249]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[250]=C_h_intern(&lf[250],12,"parameterize");
lf[251]=C_h_intern(&lf[251],16,"\003sysdynamic-wind");
lf[252]=C_h_intern(&lf[252],1,"t");
lf[253]=C_h_intern(&lf[253],8,"\003syslist");
lf[254]=C_h_intern(&lf[254],4,"swap");
lf[255]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[256]=C_h_intern(&lf[256],9,"eval-when");
lf[257]=C_h_intern(&lf[257],10,"\000compiling");
lf[258]=C_h_intern(&lf[258],19,"\004corecompiletimetoo");
lf[259]=C_h_intern(&lf[259],20,"\004corecompiletimeonly");
lf[260]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[261]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid situation specifier");
lf[263]=C_h_intern(&lf[263],4,"load");
lf[264]=C_h_intern(&lf[264],7,"compile");
lf[265]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[266]=C_h_intern(&lf[266],9,"fluid-let");
lf[267]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\001\000\000\001_");
lf[268]=C_h_intern(&lf[268],6,"ensure");
lf[269]=C_h_intern(&lf[269],11,"\000type-error");
lf[270]=C_h_intern(&lf[270],15,"\003syssignal-hook");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\033argument has incorrect type");
lf[272]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\003");
lf[273]=C_h_intern(&lf[273],6,"assert");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\020assertion failed");
lf[275]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[276]=C_h_intern(&lf[276],7,"include");
lf[277]=C_h_intern(&lf[277],27,"\003syscurrent-source-filename");
lf[278]=C_h_intern(&lf[278],4,"read");
lf[279]=C_h_intern(&lf[279],20,"with-input-from-file");
lf[280]=C_h_intern(&lf[280],5,"print");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\014; including ");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[283]=C_h_intern(&lf[283],12,"load-verbose");
lf[284]=C_h_intern(&lf[284],28,"\003sysresolve-include-filename");
lf[285]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\377\016");
lf[286]=C_h_intern(&lf[286],4,"time");
lf[287]=C_h_intern(&lf[287],15,"\003sysstart-timer");
lf[288]=C_h_intern(&lf[288],14,"\003sysstop-timer");
lf[289]=C_h_intern(&lf[289],17,"\003sysdisplay-times");
lf[290]=C_h_intern(&lf[290],7,"receive");
lf[291]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[292]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[293]=C_h_intern(&lf[293],13,"define-record");
lf[294]=C_h_intern(&lf[294],3,"val");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\005-set!");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\001\077");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\005make-");
lf[300]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[301]=C_h_intern(&lf[301],11,"\003sysprovide");
lf[302]=C_h_intern(&lf[302],19,"chicken-more-macros");
C_register_lf2(lf,303,create_ptable());
t2=C_mutate(&lf[0] /* (set! c929 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1775,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1773 */
static void C_ccall f_1775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1778,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1776 in k1773 */
static void C_ccall f_1778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1781,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1779 in k1776 in k1773 */
static void C_ccall f_1781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1781,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1784,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1787,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1790,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1793,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1796,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_4_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1799,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1799,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1802,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1805,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_support_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1805,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1808,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_compiler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1808,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1811,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1811,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1814,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_driver_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1817,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_platform_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1820,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_backend_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1823,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1823,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1826,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#provide */
t3=C_retrieve(lf[301]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[302]);}

/* k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1830,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#macro-environment */
t3=C_retrieve(lf[88]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1830,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1833,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8942,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8944,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8943 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8944(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8944,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8948,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[293],t2,lf[300]);}

/* k8946 in a8943 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8948,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8957,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* symbol->string */
t5=*((C_word*)lf[76]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k8955 in k8946 in a8943 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8957,2,t0,t1);}
t2=(C_word)C_i_memq(lf[139],C_retrieve(lf[140]));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8963,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* r55 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[54]);}

/* k8961 in k8955 in k8946 in a8943 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* r55 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[85]);}

/* k8964 in k8961 in k8955 in k8946 in a8943 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8969,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* r55 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[147]);}

/* k8967 in k8964 in k8961 in k8955 in k8946 in a8943 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8972,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* r55 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[84]);}

/* k8970 in k8967 in k8964 in k8961 in k8955 in k8946 in a8943 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9342,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9382,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* string-append */
t4=*((C_word*)lf[206]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[299],((C_word*)t0)[2]);}

/* k9380 in k8970 in k8967 in k8964 in k8961 in k8955 in k8946 in a8943 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_9382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->symbol */
t2=*((C_word*)lf[7]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9340 in k8970 in k8967 in k8964 in k8961 in k8955 in k8946 in a8943 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_9342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9342,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[81],t2);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9374,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t3,tmp=(C_word)a,a+=13,tmp);
/* ##sys#append */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);}

/* k9372 in k9340 in k8970 in k8967 in k8964 in k8961 in k8955 in k8946 in a8943 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_9374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9374,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[137],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t8);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9290,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t9,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9334,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* string-append */
t12=*((C_word*)lf[206]+1);
((C_proc4)C_retrieve_proc(t12))(4,t12,t11,((C_word*)t0)[2],lf[298]);}

/* k9332 in k9372 in k9340 in k8970 in k8967 in k8964 in k8961 in k8955 in k8946 in a8943 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_9334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->symbol */
t2=*((C_word*)lf[7]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9288 in k9372 in k9340 in k8970 in k8967 in k8964 in k8961 in k8955 in k8946 in a8943 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_9290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9290,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[149],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[81],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[149],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[138],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t2,t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t1,t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t12);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8995,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t13,tmp=(C_word)a,a+=6,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8999,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9001,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t17,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp));
t19=((C_word*)t17)[1];
f_9001(t19,t15,((C_word*)t0)[2],C_fix(1));}

/* mapslots in k9288 in k9372 in k9340 in k8970 in k8967 in k8964 in k8961 in k8955 in k8946 in a8943 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_9001(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9001,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9011,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t3,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* symbol->string */
t7=*((C_word*)lf[76]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}}

/* k9009 in mapslots in k9288 in k9372 in k9340 in k8970 in k8967 in k8964 in k8961 in k8955 in k8946 in a8943 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_9011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9014,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9278,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* string-append */
t4=*((C_word*)lf[206]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[2],lf[296],t1,lf[297]);}

/* k9276 in k9009 in mapslots in k9288 in k9372 in k9340 in k8970 in k8967 in k8964 in k8961 in k8955 in k8946 in a8943 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_9278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->symbol */
t2=*((C_word*)lf[7]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9012 in k9009 in mapslots in k9288 in k9372 in k9340 in k8970 in k8967 in k8964 in k8961 in k8955 in k8946 in a8943 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_9014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9017,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9274,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* string-append */
t4=*((C_word*)lf[206]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[3],lf[295],((C_word*)t0)[2]);}

/* k9272 in k9012 in k9009 in mapslots in k9288 in k9372 in k9340 in k8970 in k8967 in k8964 in k8961 in k8955 in k8946 in a8943 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_9274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->symbol */
t2=*((C_word*)lf[7]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9015 in k9012 in k9009 in mapslots in k9288 in k9372 in k9340 in k8970 in k8967 in k8964 in k8961 in k8955 in k8946 in a8943 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_9017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word ab[169],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9017,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[294],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[149],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[81],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[149],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[141],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[142],t9);
t11=(C_word)C_a_i_cons(&a,2,lf[294],C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[149],t12);
t14=(C_word)C_a_i_cons(&a,2,lf[144],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t10,t15);
t17=(C_word)C_a_i_cons(&a,2,t3,t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t19);
t21=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t20);
t22=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9064,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t21,a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[3])){
t23=(C_word)C_a_i_cons(&a,2,lf[149],C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,lf[81],t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,lf[149],t26);
t28=(C_word)C_a_i_cons(&a,2,lf[141],t27);
t29=(C_word)C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST);
t30=(C_word)C_a_i_cons(&a,2,lf[142],t29);
t31=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t32=(C_word)C_a_i_cons(&a,2,lf[149],t31);
t33=(C_word)C_a_i_cons(&a,2,lf[143],t32);
t34=(C_word)C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,t30,t34);
t36=(C_word)C_a_i_cons(&a,2,t23,t35);
t37=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t36);
t38=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t39=(C_word)C_a_i_cons(&a,2,t37,t38);
t40=t22;
f_9064(t40,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t39));}
else{
t23=(C_word)C_a_i_cons(&a,2,lf[149],C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,lf[81],t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,lf[149],t26);
t28=(C_word)C_a_i_cons(&a,2,lf[141],t27);
t29=(C_word)C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST);
t30=(C_word)C_a_i_cons(&a,2,lf[142],t29);
t31=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t32=(C_word)C_a_i_cons(&a,2,lf[149],t31);
t33=(C_word)C_a_i_cons(&a,2,lf[143],t32);
t34=(C_word)C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,t30,t34);
t36=(C_word)C_a_i_cons(&a,2,t23,t35);
t37=t22;
f_9064(t37,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t36));}}

/* k9062 in k9015 in k9012 in k9009 in mapslots in k9288 in k9372 in k9340 in k8970 in k8967 in k8964 in k8961 in k8955 in k8946 in a8943 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_9064(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9064,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9028,a[2]=t7,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t10=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* mapslots80 */
t11=((C_word*)((C_word*)t0)[2])[1];
f_9001(t11,t8,t9,t10);}

/* k9026 in k9062 in k9015 in k9012 in k9009 in mapslots in k9288 in k9372 in k9340 in k8970 in k8967 in k8964 in k8961 in k8955 in k8946 in a8943 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_9028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9028,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8997 in k9288 in k9372 in k9340 in k8970 in k8967 in k8964 in k8961 in k8955 in k8946 in a8943 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8993 in k9288 in k9372 in k9340 in k8970 in k8967 in k8964 in k8961 in k8955 in k8946 in a8943 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8995,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k8940 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[293],C_SCHEME_END_OF_LIST,t1);}

/* k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1833,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8799,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8801,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8800 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8801(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8801,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8805,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* r109 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[84]);}

/* k8803 in a8800 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8805,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8808,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* r109 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[71]);}

/* k8806 in k8803 in a8800 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8808,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8811,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#check-syntax */
t3=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[290],((C_word*)t0)[4],lf[292]);}

/* k8809 in k8806 in k8803 in a8800 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8811,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8840,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* ##sys#append */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8847,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* ##sys#check-syntax */
t4=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[290],((C_word*)t0)[5],lf[291]);}}

/* k8845 in k8809 in k8806 in k8803 in a8800 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8847,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8862,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cdr(t2);
t7=t5;
f_8862(t7,(C_word)C_i_nullp(t6));}
else{
t6=t5;
f_8862(t6,C_SCHEME_FALSE);}}

/* k8860 in k8845 in k8809 in k8806 in k8803 in a8800 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_8862(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8862,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8877,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t7=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8916,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}}

/* k8914 in k8860 in k8845 in k8809 in k8806 in k8803 in a8800 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8916,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[164],t5));}

/* k8875 in k8860 in k8845 in k8809 in k8806 in k8803 in a8800 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8877,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k8838 in k8809 in k8806 in k8803 in a8800 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8840,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[253],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[164],t5));}

/* k8797 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[290],C_SCHEME_END_OF_LIST,t1);}

/* k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8700,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8702,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8701 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8702(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8702,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8706,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* r143 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[252]);}

/* k8704 in a8701 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8709,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* r143 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[54]);}

/* k8707 in k8704 in a8701 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8712,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* r143 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[84]);}

/* k8710 in k8707 in k8704 in a8701 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8712,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[287],C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8791,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k8789 in k8710 in k8707 in k8704 in a8701 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[54],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8791,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[288],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[289],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[162],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[163],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t6,t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,t3,t14);
t16=(C_word)C_a_i_cons(&a,2,lf[164],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t17);
t19=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t18));}

/* k8698 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[286],C_SCHEME_END_OF_LIST,t1);}

/* k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1842,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8682,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8684,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8683 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8684(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8684,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8692,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cdr(t2);
/* ##sys#append */
t7=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}

/* k8690 in a8683 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8692,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[47],t1));}

/* k8680 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[64],C_SCHEME_END_OF_LIST,t1);}

/* k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8593,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8595,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8594 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8595,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8599,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[276],t2,lf[285]);}

/* k8597 in a8594 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8599,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8602,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* ##sys#resolve-include-filename */
t4=C_retrieve(lf[284]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k8600 in k8597 in a8594 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8602,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8605,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* r163 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[54]);}

/* k8603 in k8600 in k8597 in a8594 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8605,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8608,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8671,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* load-verbose */
t4=C_retrieve(lf[283]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k8669 in k8603 in k8600 in k8597 in a8594 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* print */
t2=*((C_word*)lf[280]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[281],((C_word*)t0)[2],lf[282]);}
else{
t2=((C_word*)t0)[3];
f_8608(2,t2,C_SCHEME_UNDEFINED);}}

/* k8606 in k8603 in k8600 in k8597 in a8594 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8608,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8615,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8619,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8621,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* with-input-from-file */
t5=C_retrieve(lf[279]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}

/* a8620 in k8606 in k8603 in k8600 in k8597 in a8594 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8621,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8627,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8632,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8665,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[251]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t1,t6,t7,t8);}

/* a8664 in a8620 in k8606 in k8603 in k8600 in k8597 in a8594 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8665,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[277]));
t3=C_mutate((C_word*)lf[277]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a8631 in a8620 in k8606 in k8603 in k8600 in k8597 in a8594 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8640,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* read */
t3=*((C_word*)lf[278]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8638 in a8631 in a8620 in k8606 in k8603 in k8600 in k8597 in a8594 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8640,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8642,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_8642(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* doloop188 in k8638 in a8631 in a8620 in k8606 in k8603 in k8600 in k8597 in a8594 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_8642(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8642,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eofp(t2))){
/* reverse */
t4=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8659,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* read */
t5=*((C_word*)lf[278]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k8657 in doloop188 in k8638 in a8631 in a8620 in k8606 in k8603 in k8600 in k8597 in a8594 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8659,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_8642(t3,((C_word*)t0)[2],t1,t2);}

/* a8626 in a8620 in k8606 in k8603 in k8600 in k8597 in a8594 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8627,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[277]));
t3=C_mutate((C_word*)lf[277]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k8617 in k8606 in k8603 in k8600 in k8597 in a8594 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8613 in k8606 in k8603 in k8600 in k8597 in a8594 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8615,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8591 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[276],C_SCHEME_END_OF_LIST,t1);}

/* k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8482,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8484,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8483 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8484(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8484,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8488,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[273],t2,lf[275]);}

/* k8486 in a8483 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8488,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8497,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* r206 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[187]);}

/* k8495 in k8486 in a8483 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8500,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* r206 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[81]);}

/* k8498 in k8495 in k8486 in a8483 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8503,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,lf[274],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[81],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=t2;
f_8503(t7,(C_word)C_a_i_cons(&a,2,lf[196],t6));}
else{
t4=t2;
f_8503(t4,(C_word)C_i_car(((C_word*)t0)[2]));}}

/* k8501 in k8498 in k8495 in k8486 in a8483 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_8503(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8503,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[142],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[244],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8546,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t4,a[6]=t1,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_i_length(((C_word*)t0)[2]);
t9=(C_word)C_fixnum_greaterp(t8,C_fix(1));
t10=(C_truep(t9)?(C_word)C_i_cdr(((C_word*)t0)[2]):C_SCHEME_END_OF_LIST);
/* ##sys#append */
t11=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t7,t10,C_SCHEME_END_OF_LIST);}

/* k8544 in k8501 in k8498 in k8495 in k8486 in a8483 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8546,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[77],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k8480 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[273],C_SCHEME_END_OF_LIST,t1);}

/* k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8345,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8347,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8346 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8347(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8347,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8351,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[268],t2,lf[272]);}

/* k8349 in a8346 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8351,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8363,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* r231 */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[198]);}

/* k8361 in k8349 in a8346 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* r231 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[71]);}

/* k8364 in k8361 in k8349 in a8346 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8369,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* r231 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[187]);}

/* k8367 in k8364 in k8361 in k8349 in a8346 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[59],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8369,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[142],t7);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8416,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t1,a[6]=t8,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8420,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t11=t10;
f_8420(t11,((C_word*)t0)[2]);}
else{
t11=(C_word)C_a_i_cons(&a,2,lf[271],C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,lf[81],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,lf[196],t13);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,lf[81],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t17);
t19=t10;
f_8420(t19,(C_word)C_a_i_cons(&a,2,t14,t18));}}

/* k8418 in k8367 in k8364 in k8361 in k8349 in a8346 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_8420(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8414 in k8367 in k8364 in k8361 in k8349 in a8346 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8416,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[269],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[270],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k8343 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[268],C_SCHEME_END_OF_LIST,t1);}

/* k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8087,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8089,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8089(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8089,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8093,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[266],t2,lf[267]);}

/* k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8093,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8102,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* ##sys#map */
t5=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[146]+1),t2);}

/* k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8105,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8333,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#map */
t4=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a8332 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8333(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8333,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8341,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t4=C_retrieve(lf[55]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k8339 in a8332 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r251 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8103 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8105,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8108,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8323,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#map */
t4=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a8322 in k8103 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8323(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8323,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8331,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t4=C_retrieve(lf[55]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k8329 in a8322 in k8103 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r251 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8106 in k8103 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8108,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8111,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* r251 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[71]);}

/* k8109 in k8106 in k8103 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8114,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* r251 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[84]);}

/* k8112 in k8109 in k8106 in k8103 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8125,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8281,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8321,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#map */
t5=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[211]+1),((C_word*)t0)[2]);}

/* k8319 in k8112 in k8109 in k8106 in k8103 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[179]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[253]+1),((C_word*)t0)[2],t1);}

/* k8279 in k8112 in k8109 in k8106 in k8103 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8281,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8285,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8289,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8293,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_length(((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8299,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_8299(t9,t4,t5);}

/* loop in k8279 in k8112 in k8109 in k8106 in k8103 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_8299(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8299,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8313,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
/* loop278 */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k8311 in loop in k8279 in k8112 in k8109 in k8106 in k8103 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8313,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1));}

/* k8291 in k8279 in k8112 in k8109 in k8106 in k8103 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[179]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[253]+1),((C_word*)t0)[2],t1);}

/* k8287 in k8279 in k8112 in k8109 in k8106 in k8103 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8283 in k8279 in k8112 in k8109 in k8106 in k8103 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8123 in k8112 in k8109 in k8106 in k8103 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8229,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8233,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8265,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[179]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* a8264 in k8123 in k8112 in k8109 in k8106 in k8103 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8265(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8265,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[74],t5));}

/* k8231 in k8123 in k8112 in k8109 in k8106 in k8103 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8237,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8241,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8251,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[179]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8250 in k8231 in k8123 in k8112 in k8109 in k8106 in k8103 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8251,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[74],t5));}

/* k8239 in k8231 in k8123 in k8112 in k8109 in k8106 in k8103 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8241,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[244],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k8235 in k8231 in k8123 in k8112 in k8109 in k8106 in k8103 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8227 in k8123 in k8112 in k8109 in k8106 in k8103 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8229,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8221,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t3,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* ##sys#append */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k8219 in k8227 in k8123 in k8112 in k8109 in k8106 in k8103 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8221,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8165,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t3,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8169,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8201,tmp=(C_word)a,a+=2,tmp);
/* map */
t7=*((C_word*)lf[179]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,t6,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a8200 in k8219 in k8227 in k8123 in k8112 in k8109 in k8106 in k8103 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8201(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8201,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[74],t5));}

/* k8167 in k8219 in k8227 in k8123 in k8112 in k8109 in k8106 in k8103 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8173,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8177,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8187,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[179]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8186 in k8167 in k8219 in k8227 in k8123 in k8112 in k8109 in k8106 in k8103 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8187,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[74],t5));}

/* k8175 in k8167 in k8219 in k8227 in k8123 in k8112 in k8109 in k8106 in k8103 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8177,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[244],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k8171 in k8167 in k8219 in k8227 in k8123 in k8112 in k8109 in k8106 in k8103 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8163 in k8219 in k8227 in k8123 in k8112 in k8109 in k8106 in k8103 in k8100 in k8091 in a8088 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8165,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[251],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k8085 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[266],C_SCHEME_END_OF_LIST,t1);}

/* k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1857,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7966,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7968,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a7967 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7968,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7972,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[256],t2,lf[265]);}

/* k7970 in a7967 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7972,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7978,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* r314 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[54]);}

/* k7976 in k7970 in a7967 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8079,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k8077 in k7976 in k7970 in a7967 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8079,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7984,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* r314 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[107]);}

/* k7982 in k8077 in k7976 in k7970 in a7967 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* r314 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[264]);}

/* k7985 in k7982 in k8077 in k7976 in k7970 in a7967 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7990,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* r314 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[263]);}

/* k7988 in k7985 in k7982 in k8077 in k7976 in k7970 in a7967 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7990,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7993,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t7,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8030,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=t7,a[8]=t3,a[9]=t10,tmp=(C_word)a,a+=10,tmp));
t12=((C_word*)t10)[1];
f_8030(t12,t8,((C_word*)t0)[2]);}

/* loop in k7988 in k7985 in k7982 in k8077 in k7976 in k7970 in a7967 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_8030(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8030,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8043,a[2]=t1,a[3]=((C_word*)t0)[9],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8053,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* c315 */
t6=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t3,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8051 in loop in k7988 in k7985 in k7982 in k8077 in k7976 in k7970 in a7967 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8053,2,t0,t1);}
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[10],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[9];
f_8043(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8060,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c315 */
t3=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k8058 in k8051 in loop in k7988 in k7985 in k7982 in k8077 in k7976 in k7970 in a7967 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8060,2,t0,t1);}
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[8],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[7];
f_8043(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8067,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c315 */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k8065 in k8058 in k8051 in loop in k7988 in k7985 in k7982 in k8077 in k7976 in k7970 in a7967 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[3];
f_8043(2,t3,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
/* ##sys#error */
t3=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],lf[262],t2);}}

/* k8041 in loop in k7988 in k7985 in k7982 in k8077 in k7976 in k7970 in a7967 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_8043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* loop341 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8030(t3,((C_word*)t0)[2],t2);}

/* k7991 in k7988 in k7985 in k7982 in k8077 in k7976 in k7970 in a7967 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7993,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[257],C_retrieve(lf[140])))){
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?((C_word*)((C_word*)t0)[5])[1]:C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[258],t3));}
else{
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[259],t3));}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)((C_word*)t0)[5])[1])?((C_word*)t0)[4]:lf[260]));}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)((C_word*)t0)[2])[1])?((C_word*)t0)[4]:lf[261]));}}

/* k7964 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[256],C_SCHEME_END_OF_LIST,t1);}

/* k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1860,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7764,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7766,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a7765 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7766(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7766,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7770,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[250],t2,lf[255]);}

/* k7768 in a7765 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7770,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7779,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* r377 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[254]);}

/* k7777 in k7768 in a7765 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7782,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* r377 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[71]);}

/* k7780 in k7777 in k7768 in a7765 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7785,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* r377 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[84]);}

/* k7783 in k7780 in k7777 in k7768 in a7765 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7788,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* ##sys#map */
t3=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[146]+1),((C_word*)t0)[2]);}

/* k7786 in k7783 in k7780 in k7777 in k7768 in a7765 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7791,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* ##sys#map */
t3=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[211]+1),((C_word*)t0)[2]);}

/* k7789 in k7786 in k7783 in k7780 in k7777 in k7768 in a7765 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7794,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7954,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#map */
t4=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a7953 in k7789 in k7786 in k7783 in k7780 in k7777 in k7768 in a7765 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7954(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7954,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7962,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t4=C_retrieve(lf[55]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7960 in a7953 in k7789 in k7786 in k7783 in k7780 in k7777 in k7768 in a7765 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r377 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7768 in a7765 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7797,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7944,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#map */
t4=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a7943 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7768 in a7765 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7944(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7944,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7952,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t4=C_retrieve(lf[55]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7950 in a7943 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7768 in a7765 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r377 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7768 in a7765 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7808,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7938,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[179]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[253]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k7936 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7768 in a7765 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7942,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[179]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[253]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7940 in k7936 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7768 in a7765 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7806 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7768 in a7765 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7808,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7876,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7880,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7882,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[179]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7881 in k7806 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7768 in a7765 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7882(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[39],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7882,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[252],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t2,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[252],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t3,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[74],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t9,t13);
t15=(C_word)C_a_i_cons(&a,2,t7,t14);
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t15));}

/* k7878 in k7806 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7768 in a7765 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7874 in k7806 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7768 in a7765 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7876,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7856,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* ##sys#append */
t8=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k7854 in k7874 in k7806 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7768 in a7765 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7856,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[251],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t11);
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t12));}

/* k7762 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[250],C_SCHEME_END_OF_LIST,t1);}

/* k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1863,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7719,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7721,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a7720 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7721(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7721,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7725,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[248],t2,lf[249]);}

/* k7723 in a7720 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7732,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* r417 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[187]);}

/* k7730 in k7723 in a7720 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7732,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7752,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* r417 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[54]);}

/* k7750 in k7730 in k7723 in a7720 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7752,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7756,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k7754 in k7750 in k7730 in k7723 in a7720 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7756,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k7717 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[248],C_SCHEME_END_OF_LIST,t1);}

/* k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7666,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7668,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a7667 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7668(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7668,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7672,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[246],t2,lf[247]);}

/* k7670 in a7667 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* r426 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[187]);}

/* k7677 in k7670 in a7667 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7679,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,lf[244],C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7707,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* r426 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[54]);}

/* k7705 in k7677 in k7670 in a7667 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7711,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k7709 in k7705 in k7677 in k7670 in a7667 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7711,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k7664 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[246],C_SCHEME_END_OF_LIST,t1);}

/* k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1869,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7521,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7523,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a7522 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7523(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7523,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7527,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[239],t2,lf[245]);}

/* k7525 in a7522 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7527,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7536,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* r435 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[84]);}

/* k7534 in k7525 in a7522 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7536,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[244],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t6);
t8=(C_word)C_a_i_cons(&a,2,t1,t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t4,t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[164],t10));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[74],t5));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7605,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* map */
t4=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_retrieve(lf[55]),((C_word*)t0)[4]);}}}

/* k7603 in k7534 in k7525 in a7522 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7605,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7632,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7636,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7638,tmp=(C_word)a,a+=2,tmp);
/* map */
t8=*((C_word*)lf[179]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,t7,((C_word*)t0)[2],t1);}

/* a7637 in k7603 in k7534 in k7525 in a7522 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7638(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7638,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[74],t5));}

/* k7634 in k7603 in k7534 in k7525 in a7522 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7630 in k7603 in k7534 in k7525 in a7522 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7632,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[164],t5));}

/* k7519 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[239],C_SCHEME_END_OF_LIST,t1);}

/* k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1872,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7479,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7481,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a7480 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7481(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7481,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7485,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[238],t2,lf[243]);}

/* k7483 in a7480 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7488,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7505,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* for-each */
t5=*((C_word*)lf[242]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a7504 in k7483 in a7480 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7505(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7505,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7513,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#current-module */
t4=C_retrieve(lf[241]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7511 in a7504 in k7483 in a7480 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#register-export */
t2=C_retrieve(lf[240]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7486 in k7483 in a7480 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7495,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* r472 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[239]);}

/* k7493 in k7486 in k7483 in a7480 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7495,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7499,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k7497 in k7493 in k7486 in k7483 in a7480 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7499,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7477 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[238],C_SCHEME_END_OF_LIST,t1);}

/* k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1875,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7091,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7093,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7093(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7093,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7097,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[235],t2,lf[237]);}

/* k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7097,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7106,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* r491 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[71]);}

/* k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7106,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7109,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* r491 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[84]);}

/* k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7109,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7111,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t7=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7142,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7184,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* map */
t9=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,*((C_word*)lf[146]+1),((C_word*)t0)[3]);}

/* k7182 in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7187,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7437,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_7437(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* loop in k7182 in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_7437(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7437,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7450,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t4))){
/* append */
t6=*((C_word*)lf[36]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t4))){
/* append*499 */
t6=((C_word*)((C_word*)t0)[2])[1];
f_7111(t6,t5,t4,t3);}
else{
t6=t5;
f_7450(2,t6,(C_word)C_a_i_cons(&a,2,t4,t3));}}}}

/* k7448 in loop in k7182 in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* loop520 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7437(t3,((C_word*)t0)[2],t2,t1);}

/* k7185 in k7182 in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7190,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7423,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a7422 in k7185 in k7182 in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7423(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7423,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7431,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7435,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t5=C_retrieve(lf[55]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k7433 in a7422 in k7185 in k7182 in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r491 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7429 in a7422 in k7185 in k7182 in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7431,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7188 in k7185 in k7182 in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7191,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7202,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7377,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_7377(t7,t3,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}

/* loop in k7188 in k7185 in k7182 in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_7377(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7377,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* reverse */
t4=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7393,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7417,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* map*500 */
t7=((C_word*)((C_word*)t0)[3])[1];
f_7142(t7,t6,((C_word*)t0)[2],t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7410,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* lookup545 */
t7=((C_word*)t0)[2];
f_7191(3,t7,t6,t4);}}}

/* k7408 in loop in k7188 in k7185 in k7182 in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7410,2,t0,t1);}
t2=((C_word*)t0)[3];
f_7393(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k7415 in loop in k7188 in k7185 in k7182 in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7417,2,t0,t1);}
t2=((C_word*)t0)[3];
f_7393(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k7391 in loop in k7188 in k7185 in k7182 in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_7393(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* loop550 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7377(t3,((C_word*)t0)[2],t2,t1);}

/* k7200 in k7188 in k7185 in k7182 in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7209,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7371,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7370 in k7200 in k7188 in k7185 in k7182 in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7371(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7371,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k7207 in k7200 in k7188 in k7185 in k7182 in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7209,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7211,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_7211(t5,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* fold in k7207 in k7200 in k7188 in k7185 in k7182 in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_7211(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7211,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7229,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7235,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* map */
t7=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_i_car(t4);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7365,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* cdar */
t8=*((C_word*)lf[123]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}
else{
t7=t5;
f_7249(t7,C_SCHEME_FALSE);}}}

/* k7363 in fold in k7207 in k7200 in k7188 in k7185 in k7182 in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7249(t2,(C_word)C_i_nullp(t1));}

/* k7247 in fold in k7207 in k7200 in k7188 in k7185 in k7182 in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_7249(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7249,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7288,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* caar */
t3=*((C_word*)lf[125]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7331,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[5]);
t9=(C_word)C_i_cdr(((C_word*)t0)[8]);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* fold572 */
t11=((C_word*)((C_word*)t0)[3])[1];
f_7211(t11,t7,t8,t9,t10);}}

/* k7329 in k7247 in fold in k7207 in k7200 in k7188 in k7185 in k7182 in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7331,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[164],t6));}

/* k7286 in k7247 in fold in k7207 in k7200 in k7188 in k7185 in k7182 in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7288,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7268,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
t8=(C_word)C_i_cdr(((C_word*)t0)[7]);
t9=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* fold572 */
t10=((C_word*)((C_word*)t0)[2])[1];
f_7211(t10,t6,t7,t8,t9);}

/* k7266 in k7286 in k7247 in fold in k7207 in k7200 in k7188 in k7185 in k7182 in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7268,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* a7234 in fold in k7207 in k7200 in k7188 in k7185 in k7182 in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7235(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7235,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7243,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lookup545 */
t4=((C_word*)t0)[2];
f_7191(3,t4,t3,t2);}

/* k7241 in a7234 in fold in k7207 in k7200 in k7188 in k7185 in k7182 in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7243,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k7227 in fold in k7207 in k7200 in k7188 in k7185 in k7182 in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7233,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k7231 in k7227 in fold in k7207 in k7200 in k7188 in k7185 in k7182 in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7233,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* lookup in k7188 in k7185 in k7182 in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7191(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7191,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* map* in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_7142(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7142,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7165,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* proc505 */
t6=t2;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
/* proc505 */
t4=t2;
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}}}

/* k7163 in map* in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7169,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* map*500 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7142(t4,t2,((C_word*)t0)[2],t3);}

/* k7167 in k7163 in map* in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7169,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* append* in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_7111(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7111,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7132,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* append*499 */
t8=t5;
t9=t6;
t10=t3;
t1=t8;
t2=t9;
t3=t10;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}}

/* k7130 in append* in k7107 in k7104 in k7095 in a7092 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7132,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7089 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[235],C_SCHEME_END_OF_LIST,t1);}

/* k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1878,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7019,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7021,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a7020 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7021,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7025,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[234],t2,lf[236]);}

/* k7023 in a7020 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7025,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7034,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* r609 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[71]);}

/* k7032 in k7023 in a7020 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7037,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* r609 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[235]);}

/* k7035 in k7032 in k7023 in a7020 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7037,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7042,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7042(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fold in k7035 in k7032 in k7023 in a7020 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_7042(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7042,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7060,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7079,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(t2);
/* fold617 */
t9=t5;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}

/* k7077 in fold in k7035 in k7032 in k7023 in a7020 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7079,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k7058 in fold in k7035 in k7032 in k7023 in a7020 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7060,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k7017 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[234],C_SCHEME_END_OF_LIST,t1);}

/* k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6853,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6855,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a6854 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6855(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6855,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6859,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[231],t2,lf[233]);}

/* k6857 in a6854 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6859,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6868,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* r633 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[71]);}

/* k6866 in k6857 in a6854 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* r633 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[84]);}

/* k6869 in k6866 in k6857 in a6854 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7009,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7011,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[3]);}

/* a7010 in k6869 in k6866 in k6857 in a6854 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7011(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7011,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k7007 in k6869 in k6866 in k6857 in a6854 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[48]+1),t1);}

/* k6872 in k6869 in k6866 in k6857 in a6854 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6877,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6993,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a6992 in k6872 in k6869 in k6866 in k6857 in a6854 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6993(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6993,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7001,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7005,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t5=C_retrieve(lf[55]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k7003 in a6992 in k6872 in k6869 in k6866 in k6857 in a6854 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r633 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6999 in a6992 in k6872 in k6869 in k6866 in k6857 in a6854 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_7001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7001,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6875 in k6872 in k6869 in k6866 in k6857 in a6854 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6878,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6897,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6987,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a6986 in k6875 in k6872 in k6869 in k6866 in k6857 in a6854 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6987(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6987,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,lf[232]));}

/* k6895 in k6875 in k6872 in k6869 in k6866 in k6857 in a6854 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6901,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6905,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6911,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a6910 in k6895 in k6875 in k6872 in k6869 in k6866 in k6857 in a6854 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6911(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6911,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6939,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t6,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_i_car(t2);
/* map */
t9=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,((C_word*)t0)[2],t8);}

/* k6937 in a6910 in k6895 in k6875 in k6872 in k6869 in k6866 in k6857 in a6854 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6943,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6947,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6949,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a6948 in k6937 in a6910 in k6895 in k6875 in k6872 in k6869 in k6866 in k6857 in a6854 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6949(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6949,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6965,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lookup650 */
t4=((C_word*)t0)[2];
f_6878(3,t4,t3,t2);}

/* k6963 in a6948 in k6937 in a6910 in k6895 in k6875 in k6872 in k6869 in k6866 in k6857 in a6854 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6965,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[74],t3));}

/* k6945 in k6937 in a6910 in k6895 in k6875 in k6872 in k6869 in k6866 in k6857 in a6854 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6941 in k6937 in a6910 in k6895 in k6875 in k6872 in k6869 in k6866 in k6857 in a6854 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6943,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[164],t5));}

/* k6903 in k6895 in k6875 in k6872 in k6869 in k6866 in k6857 in a6854 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6909,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k6907 in k6903 in k6895 in k6875 in k6872 in k6869 in k6866 in k6857 in a6854 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6899 in k6895 in k6875 in k6872 in k6869 in k6866 in k6857 in a6854 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6901,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* lookup in k6875 in k6872 in k6869 in k6866 in k6857 in a6854 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6878(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6878,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k6851 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[231],C_SCHEME_END_OF_LIST,t1);}

/* k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1884,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6779,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6781,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a6780 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6781(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6781,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6785,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[228],t2,lf[230]);}

/* k6783 in a6780 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6788,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* r675 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[198]);}

/* k6786 in k6783 in a6780 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6791,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* r675 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[229]);}

/* k6789 in k6786 in k6783 in a6780 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6794,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* r675 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[84]);}

/* k6792 in k6789 in k6786 in k6783 in a6780 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6794,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_i_cadr(((C_word*)t0)[5]);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t10);
t12=(C_word)C_a_i_cons(&a,2,t1,t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t5,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[164],t14));}

/* k6777 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[228],C_SCHEME_END_OF_LIST,t1);}

/* k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1887,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6678,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6680,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a6679 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6680,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6684,a[2]=t2,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* r688 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[84]);}

/* k6682 in a6679 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6686,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6767,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6771,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* quotify-proc693 */
t6=t2;
f_6686(t6,t4,t5,lf[224]);}

/* k6769 in k6682 in a6679 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6765 in k6682 in a6679 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6767,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[227],t1));}

/* quotify-proc in k6682 in a6679 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_6686(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6686,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#check-syntax */
t5=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,t3,t2,lf[226]);}

/* k6688 in quotify-proc in k6682 in a6679 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6690,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6699,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6747,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* ##sys#append */
t9=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,C_SCHEME_END_OF_LIST);}
else{
t6=t5;
f_6699(t6,(C_word)C_i_cadr(((C_word*)t0)[5]));}}

/* k6745 in k6688 in quotify-proc in k6682 in a6679 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6747,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_6699(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k6697 in k6688 in quotify-proc in k6682 in a6679 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_6699(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6699,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6702,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_pairp(t1);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6711,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_6711(t6,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6721,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_car(t1);
/* c689 */
t8=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k6719 in k6697 in k6688 in quotify-proc in k6682 in a6679 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6711(t2,(C_word)C_i_not(t1));}

/* k6709 in k6697 in k6688 in quotify-proc in k6682 in a6679 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_6711(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* syntax-error */
t2=C_retrieve(lf[97]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[224],lf[225],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_6702(2,t2,C_SCHEME_UNDEFINED);}}

/* k6700 in k6697 in k6688 in quotify-proc in k6682 in a6679 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6702,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k6676 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[224],C_SCHEME_END_OF_LIST,t1);}

/* k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1890,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6515,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6517,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a6516 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6517,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6521,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[222],t2,lf[223]);}

/* k6519 in a6516 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6521,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6530,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* r727 */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[187]);}

/* k6528 in k6519 in a6516 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* r727 */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[71]);}

/* k6531 in k6528 in k6519 in a6516 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6533,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6538,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_6538(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fold in k6531 in k6528 in k6519 in a6516 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_6538(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(30);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6538,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6552,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* r727 */
t4=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[54]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=(C_word)C_i_car(t3);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6612,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* fold735 */
t17=t7;
t18=t4;
t1=t17;
t2=t18;
goto loop;}
else{
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_cadr(t3);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t6,t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6650,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t10,a[5]=((C_word*)t0)[4],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* fold735 */
t17=t11;
t18=t4;
t1=t17;
t2=t18;
goto loop;}}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6583,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* fold735 */
t17=t5;
t18=t4;
t1=t17;
t2=t18;
goto loop;}}}

/* k6581 in fold in k6531 in k6528 in k6519 in a6516 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6583,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k6648 in fold in k6531 in k6528 in k6519 in a6516 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6650,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k6610 in fold in k6531 in k6528 in k6519 in a6516 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6612,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k6550 in fold in k6531 in k6528 in k6519 in a6516 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6556,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k6554 in k6550 in fold in k6531 in k6528 in k6519 in a6516 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6556,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6513 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[222],C_SCHEME_END_OF_LIST,t1);}

/* k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6346,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6348,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a6347 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6348(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6348,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6352,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[216],t2,lf[221]);}

/* k6350 in a6347 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6352,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6361,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* r771 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[198]);}

/* k6359 in k6350 in a6347 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6364,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* r771 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[187]);}

/* k6362 in k6359 in k6350 in a6347 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6367,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* r771 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[119]);}

/* k6365 in k6362 in k6359 in k6350 in a6347 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6370,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* r771 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[220]);}

/* k6368 in k6365 in k6362 in k6359 in k6350 in a6347 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6373,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* r771 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[219]);}

/* k6371 in k6368 in k6365 in k6362 in k6359 in k6350 in a6347 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6376,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* r771 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[54]);}

/* k6374 in k6371 in k6368 in k6365 in k6362 in k6359 in k6350 in a6347 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6383,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* r771 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[71]);}

/* k6381 in k6374 in k6371 in k6368 in k6365 in k6362 in k6359 in k6350 in a6347 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6383,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6399,a[2]=t1,a[3]=((C_word*)t0)[9],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6401,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=t7,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_6401(t9,t5,((C_word*)t0)[2]);}

/* expand in k6381 in k6374 in k6371 in k6368 in k6365 in k6362 in k6359 in k6350 in a6347 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_6401(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6401,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6417,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t3,a[11]=((C_word*)t0)[9],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[216],t3,lf[217]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[218]);}}

/* k6415 in expand in k6381 in k6374 in k6371 in k6368 in k6365 in k6362 in k6359 in k6350 in a6347 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6417,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6423,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[10]);
/* c772 */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k6421 in k6415 in expand in k6381 in k6374 in k6371 in k6368 in k6365 in k6362 in k6359 in k6350 in a6347 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6423,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6430,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* ##sys#append */
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6473,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6477,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6479,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[8]);
/* map */
t6=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a6478 in k6421 in k6415 in expand in k6381 in k6374 in k6371 in k6368 in k6365 in k6362 in k6359 in k6350 in a6347 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6479(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6479,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k6475 in k6421 in k6415 in expand in k6381 in k6374 in k6371 in k6368 in k6365 in k6362 in k6359 in k6350 in a6347 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6471 in k6421 in k6415 in expand in k6381 in k6374 in k6371 in k6368 in k6365 in k6362 in k6359 in k6350 in a6347 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6473,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6465,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k6463 in k6471 in k6421 in k6415 in expand in k6381 in k6374 in k6371 in k6368 in k6365 in k6362 in k6359 in k6350 in a6347 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6465,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6461,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand787 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6401(t4,t3,((C_word*)t0)[2]);}

/* k6459 in k6463 in k6471 in k6421 in k6415 in expand in k6381 in k6374 in k6371 in k6368 in k6365 in k6362 in k6359 in k6350 in a6347 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6461,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k6428 in k6421 in k6415 in expand in k6381 in k6374 in k6371 in k6368 in k6365 in k6362 in k6359 in k6350 in a6347 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6430,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6397 in k6381 in k6374 in k6371 in k6368 in k6365 in k6362 in k6359 in k6350 in a6347 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6399,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k6344 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[216],C_SCHEME_END_OF_LIST,t1);}

/* k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5914,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5916,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5916,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5920,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[204],t2,lf[215]);}

/* k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5920,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5932,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* r813 */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[199]);}

/* k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5932,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* r813 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[187]);}

/* k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5938,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* r813 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[71]);}

/* k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5941,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* r813 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[146]);}

/* k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5944,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* r813 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[181]);}

/* k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5947,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* r813 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[84]);}

/* k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5949,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6046,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6235,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* ##sys#check-syntax */
t5=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[204],((C_word*)t0)[2],lf[214]);}

/* k6233 in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6238,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* ##sys#check-syntax */
t3=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[204],((C_word*)t0)[8],lf[213]);}

/* k6236 in k6233 in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* map */
t3=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[146]+1),((C_word*)t0)[2]);}

/* k6239 in k6236 in k6233 in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6242,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6257,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6334,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a6333 in k6239 in k6236 in k6233 in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6334(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6334,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6342,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* prefix-sym876 */
f_6242(t3,lf[212],t2);}

/* k6340 in a6333 in k6239 in k6236 in k6233 in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r813 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6255 in k6239 in k6236 in k6233 in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6260,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* map */
t3=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[211]+1),((C_word*)t0)[2]);}

/* k6258 in k6255 in k6239 in k6236 in k6233 in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6260,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6263,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* r813 */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[210]);}

/* k6261 in k6258 in k6255 in k6239 in k6236 in k6233 in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6263,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6266,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* r813 */
t3=((C_word*)t0)[7];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[209]);}

/* k6264 in k6261 in k6258 in k6255 in k6239 in k6236 in k6233 in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6266,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6269,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t1,a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6324,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[12]);}

/* a6323 in k6264 in k6261 in k6258 in k6255 in k6239 in k6236 in k6233 in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6324(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6324,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6332,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* prefix-sym876 */
f_6242(t3,lf[208],t2);}

/* k6330 in a6323 in k6264 in k6261 in k6258 in k6255 in k6239 in k6236 in k6233 in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r813 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6267 in k6264 in k6261 in k6258 in k6255 in k6239 in k6236 in k6233 in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6269,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6272,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* make-default-procs825 */
t3=((C_word*)t0)[3];
f_5949(t3,t2,((C_word*)t0)[4],((C_word*)t0)[8],t1,((C_word*)t0)[2]);}

/* k6270 in k6267 in k6264 in k6261 in k6258 in k6255 in k6239 in k6236 in k6233 in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6272,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6275,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* make-if-tree826 */
t3=((C_word*)t0)[4];
f_6046(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],((C_word*)t0)[11]);}

/* k6273 in k6270 in k6267 in k6264 in k6261 in k6258 in k6255 in k6239 in k6236 in k6233 in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6282,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* r813 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[207]);}

/* k6280 in k6273 in k6270 in k6267 in k6264 in k6261 in k6258 in k6255 in k6239 in k6236 in k6233 in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6282,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)t0)[4]);
t9=(C_word)C_a_i_cons(&a,2,t3,t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t9,t10);
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,t1,t11));}

/* prefix-sym in k6239 in k6236 in k6233 in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_6242(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6242,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6250,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6254,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* symbol->string */
t6=*((C_word*)lf[76]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}

/* k6252 in prefix-sym in k6239 in k6236 in k6233 in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-append */
t2=*((C_word*)lf[206]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6248 in prefix-sym in k6239 in k6236 in k6233 in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->symbol */
t2=*((C_word*)lf[7]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* make-if-tree in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_6046(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6046,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6052,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=((C_word*)t0)[6],a[9]=t5,tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_6052(t9,t1,t2,t3,C_SCHEME_END_OF_LIST);}

/* recur in make-if-tree in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_6052(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6052,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[142],t7);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6114,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=t8,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* reverse */
t10=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t4);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[199],t6);
t8=(C_word)C_i_car(t3);
t9=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6228,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=t7,a[9]=((C_word*)t0)[3],a[10]=((C_word*)t0)[4],a[11]=t5,a[12]=((C_word*)t0)[5],a[13]=((C_word*)t0)[9],a[14]=t8,tmp=(C_word)a,a+=15,tmp);
/* reverse */
t10=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t4);}}

/* k6226 in recur in make-if-tree in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6228,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[14],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t6,t11);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6172,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t2,a[6]=((C_word*)t0)[9],a[7]=t12,tmp=(C_word)a,a+=8,tmp);
t14=(C_word)C_i_cdr(((C_word*)t0)[5]);
t15=(C_word)C_i_cdr(((C_word*)t0)[4]);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],((C_word*)t0)[3]);
/* recur855 */
t17=((C_word*)((C_word*)t0)[2])[1];
f_6052(t17,t13,t14,t15,t16);}

/* k6170 in k6226 in recur in make-if-tree in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6172,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k6112 in recur in make-if-tree in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6114,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[205],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[81],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[196],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[77],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t2,t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t11);
t13=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t12));}

/* make-default-procs in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_5949(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5949,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5957,a[2]=t4,a[3]=t5,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* reverse */
t7=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}

/* k5955 in make-default-procs in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5961,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* reverse */
t3=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5959 in k5955 in make-default-procs in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5965,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* reverse */
t3=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5963 in k5959 in k5955 in make-default-procs in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5965,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5967,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5967(t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* recur in k5963 in k5959 in k5955 in make-default-procs in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_5967(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5967,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6020,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=t7,a[8]=((C_word*)t0)[3],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
/* reverse */
t9=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t6);}}

/* k6018 in recur in k5963 in k5959 in k5955 in make-default-procs in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6032,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6036,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* reverse */
t4=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6034 in k6018 in recur in k5963 in k5959 in k5955 in make-default-procs in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6036,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k6030 in k6018 in recur in k5963 in k5959 in k5955 in make-default-procs in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_6032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6032,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5988,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
t11=(C_word)C_i_car(((C_word*)t0)[5]);
/* recur834 */
t12=((C_word*)((C_word*)t0)[3])[1];
f_5967(t12,t8,((C_word*)t0)[2],t9,t10,t11);}

/* k5986 in k6030 in k6018 in recur in k5963 in k5959 in k5955 in make-default-procs in k5945 in k5942 in k5939 in k5936 in k5933 in k5930 in k5918 in a5915 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5988,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5912 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[204],C_SCHEME_END_OF_LIST,t1);}

/* k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5730,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5732,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a5731 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5732(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5732,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5736,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[201],t2,lf[203]);}

/* k5734 in a5731 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5739,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* r910 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[198]);}

/* k5737 in k5734 in a5731 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5742,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* r910 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[199]);}

/* k5740 in k5737 in k5734 in a5731 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5745,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* r910 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[187]);}

/* k5743 in k5740 in k5737 in k5734 in a5731 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5752,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* r910 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[71]);}

/* k5750 in k5743 in k5740 in k5737 in k5734 in a5731 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5752,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_i_cddr(((C_word*)t0)[7]);
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5787,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_nullp(t8))){
t10=t9;
f_5787(2,t10,C_SCHEME_FALSE);}
else{
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
t11=t9;
f_5787(2,t11,(C_word)C_i_car(t8));}
else{
/* ##sys#error */
t11=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,lf[0],t8);}}}

/* k5785 in k5750 in k5743 in k5740 in k5737 in k5734 in a5731 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* r910 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[181]);}

/* k5869 in k5785 in k5750 in k5743 in k5740 in k5737 in k5734 in a5731 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5871,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[142],t6);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5847,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t7,a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* r910 */
t9=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,lf[146]);}

/* k5845 in k5869 in k5785 in k5750 in k5743 in k5740 in k5737 in k5734 in a5731 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[60],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5847,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[202],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[81],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[196],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[77],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t3,t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t12);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t15);
t17=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t19);
t21=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t20));}

/* k5728 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[201],C_SCHEME_END_OF_LIST,t1);}

/* k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1902,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5428,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5430,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a5429 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5430,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5434,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[194],t2,lf[200]);}

/* k5432 in a5429 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5434,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5446,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* r932 */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[71]);}

/* k5444 in k5432 in a5429 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5449,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* r932 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[187]);}

/* k5447 in k5444 in k5432 in a5429 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* r932 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[199]);}

/* k5450 in k5447 in k5444 in k5432 in a5429 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* r932 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[146]);}

/* k5453 in k5450 in k5447 in k5444 in k5432 in a5429 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5458,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* r932 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[181]);}

/* k5456 in k5453 in k5450 in k5447 in k5444 in k5432 in a5429 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5461,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* r932 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[198]);}

/* k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5432 in a5429 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5461,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5480,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5482,a[2]=((C_word*)t0)[3],a[3]=t7,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_5482(t9,t5,t1,((C_word*)t0)[2]);}

/* loop in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5432 in a5429 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_5482(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5482,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[142],t6);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5548,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=t7,a[5]=t2,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* ##sys#append */
t9=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5572,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
/* r932 */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[197]);}
else{
t5=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5710,a[2]=((C_word*)t0)[8],a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t9=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}}}

/* k5708 in loop in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5432 in a5429 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5710,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k5570 in loop in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5432 in a5429 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[77],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5572,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[11]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[11]);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t5,t8);
t10=(C_word)C_a_i_cons(&a,2,t4,t9);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t2,t12);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t14);
t16=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,lf[81],t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t19=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t18);
t20=(C_word)C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,t17,t20);
t22=(C_word)C_a_i_cons(&a,2,t15,t21);
t23=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t22);
t24=(C_word)C_a_i_cons(&a,2,t23,C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,t1,t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,t13,t26);
t28=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5591,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t27,tmp=(C_word)a,a+=5,tmp);
t29=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* loop950 */
t30=((C_word*)((C_word*)t0)[2])[1];
f_5482(t30,t28,t1,t29);}

/* k5589 in k5570 in loop in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5432 in a5429 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5591,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k5546 in loop in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5432 in a5429 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5548,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[195],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[81],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[196],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[77],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t3,t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t12);
t14=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t13));}

/* k5478 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5432 in a5429 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5480,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k5426 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[194],C_SCHEME_END_OF_LIST,t1);}

/* k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1905,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5007,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5009,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5009,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5013,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[175],t2,lf[193]);}

/* k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5015,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5050,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* require */
t4=C_retrieve(lf[191]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[192]);}

/* k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5050,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5053,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5407,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5409,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a5408 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5409(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5409,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5419,tmp=(C_word)a,a+=2,tmp);
/* ##sys#decompose-lambda-list */
t5=C_retrieve(lf[185]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a5418 in a5408 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5419,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k5405 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[190]+1),t1);}

/* k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5053,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5056,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* genvars978 */
t3=((C_word*)t0)[2];
f_5015(t3,t2,t1);}

/* k5054 in k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5059,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* r975 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[189]);}

/* k5057 in k5054 in k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5062,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* r975 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[188]);}

/* k5060 in k5057 in k5054 in k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5065,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* r975 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[84]);}

/* k5063 in k5060 in k5057 in k5054 in k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5068,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* r975 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[71]);}

/* k5066 in k5063 in k5060 in k5057 in k5054 in k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* r975 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[187]);}

/* k5069 in k5066 in k5063 in k5060 in k5057 in k5054 in k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5082,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* append */
t3=*((C_word*)lf[36]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[4],((C_word*)t0)[10]);}

/* k5080 in k5069 in k5066 in k5063 in k5060 in k5057 in k5054 in k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5082,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[176],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5106,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,a[5]=((C_word*)t0)[9],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5108,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* fold-right */
t10=C_retrieve(lf[68]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t7,t8,lf[186],t9);}

/* a5107 in k5080 in k5069 in k5066 in k5063 in k5060 in k5057 in k5054 in k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5108(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5108,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5118,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t3,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* ##sys#decompose-lambda-list */
t6=C_retrieve(lf[185]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t4,t5);}

/* a5117 in a5107 in k5080 in k5069 in k5066 in k5063 in k5060 in k5057 in k5054 in k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5118,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_5122,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=((C_word*)t0)[8],a[11]=t1,a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=t3,tmp=(C_word)a,a+=15,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[5]);
/* ##sys#check-syntax */
t7=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,lf[175],t6,lf[184]);}

/* k5120 in a5117 in a5107 in k5080 in k5069 in k5066 in k5063 in k5060 in k5057 in k5054 in k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5122,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[14],((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5136,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[6])){
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=t3;
f_5136(t5,C_SCHEME_TRUE);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5356,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* r975 */
t6=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[182]);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5371,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* r975 */
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[183]);}}

/* k5369 in k5120 in a5117 in a5107 in k5080 in k5069 in k5066 in k5063 in k5060 in k5057 in k5054 in k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5371,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_5136(t4,(C_word)C_a_i_cons(&a,2,t1,t3));}

/* k5354 in k5120 in a5117 in a5107 in k5080 in k5069 in k5066 in k5063 in k5060 in k5057 in k5054 in k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5356,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_5136(t4,(C_word)C_a_i_cons(&a,2,t1,t3));}

/* k5134 in k5120 in a5117 in a5107 in k5080 in k5069 in k5066 in k5063 in k5060 in k5057 in k5054 in k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_5136(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5136,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5144,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=t1,a[5]=((C_word*)t0)[13],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5150,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5160,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a5159 in k5134 in k5120 in a5117 in a5107 in k5080 in k5069 in k5066 in k5063 in k5060 in k5057 in k5054 in k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5160(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5160,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5164,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5187,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_5187(t8,t4,t3,((C_word*)t0)[2]);}

/* build in a5159 in k5134 in k5120 in a5117 in a5107 in k5080 in k5069 in k5066 in k5063 in k5060 in k5057 in k5054 in k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_5187(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5187,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[6])){
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5212,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* ##sys#append */
t9=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cadr(((C_word*)t0)[4]));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5244,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* ##sys#append */
t7=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}}}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5255,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5343,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t6=C_retrieve(lf[55]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}}

/* k5341 in build in a5159 in k5134 in k5120 in a5117 in a5107 in k5080 in k5069 in k5066 in k5063 in k5060 in k5057 in k5054 in k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r975 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5253 in build in a5159 in k5134 in k5120 in a5117 in a5107 in k5080 in k5069 in k5066 in k5063 in k5060 in k5057 in k5054 in k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5255,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5335,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=t2,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* r975 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[146]);}

/* k5333 in k5253 in build in a5159 in k5134 in k5120 in a5117 in a5107 in k5080 in k5069 in k5066 in k5063 in k5060 in k5057 in k5054 in k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5335,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5315,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* r975 */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[181]);}

/* k5313 in k5333 in k5253 in build in a5159 in k5134 in k5120 in a5117 in a5107 in k5080 in k5069 in k5066 in k5063 in k5060 in k5057 in k5054 in k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5315,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5274,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* build1042 */
t11=((C_word*)((C_word*)t0)[2])[1];
f_5187(t11,t8,t10,((C_word*)t0)[7]);}
else{
/* build1042 */
t10=((C_word*)((C_word*)t0)[2])[1];
f_5187(t10,t8,C_SCHEME_END_OF_LIST,((C_word*)t0)[7]);}}

/* k5272 in k5313 in k5333 in k5253 in build in a5159 in k5134 in k5120 in a5117 in a5107 in k5080 in k5069 in k5066 in k5063 in k5060 in k5057 in k5054 in k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5274,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k5242 in build in a5159 in k5134 in k5120 in a5117 in a5107 in k5080 in k5069 in k5066 in k5063 in k5060 in k5057 in k5054 in k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5244,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k5210 in build in a5159 in k5134 in k5120 in a5117 in a5107 in k5080 in k5069 in k5066 in k5063 in k5060 in k5057 in k5054 in k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5212,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k5162 in a5159 in k5134 in k5120 in a5117 in a5107 in k5080 in k5069 in k5066 in k5063 in k5060 in k5057 in k5054 in k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5164,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5181,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* map */
t3=*((C_word*)lf[179]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[180]+1),((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k5179 in k5162 in a5159 in k5134 in k5120 in a5117 in a5107 in k5080 in k5069 in k5066 in k5063 in k5060 in k5057 in k5054 in k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5181,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* a5149 in k5134 in k5120 in a5117 in a5107 in k5080 in k5069 in k5066 in k5063 in k5060 in k5057 in k5054 in k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5150,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5158,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* take */
t3=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5156 in a5149 in k5134 in k5120 in a5117 in a5107 in k5080 in k5069 in k5066 in k5063 in k5060 in k5057 in k5054 in k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* split-at! */
t2=C_retrieve(lf[177]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5142 in k5134 in k5120 in a5117 in a5107 in k5080 in k5069 in k5066 in k5063 in k5060 in k5057 in k5054 in k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5144,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k5104 in k5080 in k5069 in k5066 in k5063 in k5060 in k5057 in k5054 in k5051 in k5048 in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5106,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t6));}

/* genvars in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_5015(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5015,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5021,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_5021(t6,t1,C_fix(0));}

/* loop in genvars in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_5021(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5021,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5035,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5047,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t5=C_retrieve(lf[55]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k5045 in loop in genvars in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r975 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5033 in loop in genvars in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5039,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* loop982 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5021(t4,t2,t3);}

/* k5037 in k5033 in loop in genvars in k5011 in a5008 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5039,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5005 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_5007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[175],C_SCHEME_END_OF_LIST,t1);}

/* k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1908,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4909,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4911,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a4910 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4911(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4911,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4915,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[170],t2,lf[174]);}

/* k4913 in a4910 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4915,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4930,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,lf[170],t5,lf[172]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4980,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,lf[170],t5,lf[173]);}}

/* k4978 in k4913 in a4910 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4980,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[81],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4995,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4993 in k4978 in k4913 in a4910 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4995,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[171],t2));}

/* k4928 in k4913 in a4910 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4930,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(0));
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[81],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4953,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* r1080 */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[84]);}

/* k4951 in k4928 in k4913 in a4910 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4953,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4965,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4963 in k4951 in k4928 in k4913 in a4910 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4965,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[171],t5));}

/* k4907 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[170],C_SCHEME_END_OF_LIST,t1);}

/* k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1911,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4715,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4717,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a4716 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4717(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4717,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4721,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[156],t2,lf[169]);}

/* k4719 in a4716 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4724,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* r1105 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[168]);}

/* k4722 in k4719 in a4716 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* r1105 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[167]);}

/* k4725 in k4722 in k4719 in a4716 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4730,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* r1105 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[84]);}

/* k4728 in k4725 in k4722 in k4719 in a4716 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4741,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* r1105 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[166]);}

/* k4739 in k4728 in k4725 in k4722 in k4719 in a4716 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4741,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4769,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* r1105 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[165]);}

/* k4767 in k4739 in k4728 in k4725 in k4722 in k4719 in a4716 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4769,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_i_caddr(((C_word*)t0)[8]);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t3,t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t11);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4861,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t12,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t14=(C_word)C_i_cdddr(((C_word*)t0)[8]);
/* ##sys#append */
t15=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,t14,C_SCHEME_END_OF_LIST);}

/* k4859 in k4767 in k4739 in k4728 in k4725 in k4722 in k4719 in a4716 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word ab[84],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4861,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[162],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[163],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[84],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t12);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t3,t15);
t17=(C_word)C_a_i_cons(&a,2,lf[164],t16);
t18=(C_word)C_a_i_cons(&a,2,t17,C_SCHEME_END_OF_LIST);
t19=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t18);
t20=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t19);
t21=(C_word)C_a_i_cons(&a,2,t20,C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t21);
t23=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t22);
t24=(C_word)C_a_i_cons(&a,2,t23,C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t24);
t26=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t25);
t27=(C_word)C_a_i_cons(&a,2,t26,C_SCHEME_END_OF_LIST);
t28=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t27);
t29=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,(C_word)C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST));}

/* k4713 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[156],C_SCHEME_END_OF_LIST,t1);}

/* k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1914,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4388,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4390,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a4389 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4390,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4394,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[151],t2,lf[161]);}

/* k4392 in a4389 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4397,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* r1118 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[160]);}

/* k4395 in k4392 in a4389 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4400,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* r1118 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[159]);}

/* k4398 in k4395 in k4392 in a4389 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4403,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* r1118 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[158]);}

/* k4401 in k4398 in k4395 in k4392 in a4389 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4406,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* r1118 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[71]);}

/* k4404 in k4401 in k4398 in k4395 in k4392 in a4389 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4409,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* r1118 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[157]);}

/* k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in a4389 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4412,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* r1118 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[119]);}

/* k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in a4389 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4414,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4587,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* r1118 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[156]);}

/* k4585 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in a4389 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4587,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[152],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[81],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[138],t5);
t7=(C_word)C_a_i_cons(&a,2,C_fix(1),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[153],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t6,t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4627,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t15,tmp=(C_word)a,a+=10,tmp);
/* r1118 */
t17=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t17))(3,t17,t16,lf[155]);}

/* k4625 in k4585 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in a4389 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4627,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4631,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4635,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[7]);
/* map */
t5=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}

/* k4633 in k4625 in k4585 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in a4389 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4635,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[154],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t7=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[2],t1,t6);}

/* k4629 in k4625 in k4585 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in a4389 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4631,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_i_cadr(((C_word*)t0)[5]);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t5,t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* parse-clause in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in a4389 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4414(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[38],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4414,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_symbolp(t3);
t5=(C_truep(t4)?(C_word)C_i_car(t2):C_SCHEME_FALSE);
t6=(C_truep(t5)?(C_word)C_i_cadr(t2):(C_word)C_i_car(t2));
t7=(C_truep(t5)?(C_word)C_i_cddr(t2):(C_word)C_i_cdr(t2));
if(C_truep((C_word)C_i_nullp(t6))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4441,a[2]=((C_word*)t0)[7],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t5,t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4456,a[2]=((C_word*)t0)[5],a[3]=t8,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t13=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t12,t7,C_SCHEME_END_OF_LIST);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4475,a[2]=((C_word*)t0)[5],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t10=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t7,C_SCHEME_END_OF_LIST);}}
else{
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4532,a[2]=t7,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4536,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t11=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,t6);}}

/* a4537 in parse-clause in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in a4389 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4538(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4538,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[81],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t6));}

/* k4534 in parse-clause in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in a4389 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4530 in parse-clause in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in a4389 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4532,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4490,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[5])){
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4505,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t9=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4524,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}

/* k4522 in k4530 in parse-clause in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in a4389 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4524,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
f_4490(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k4503 in k4530 in parse-clause in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in a4389 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4505,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_4490(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k4488 in k4530 in parse-clause in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in a4389 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_4490(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4490,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k4473 in parse-clause in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in a4389 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4475,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
f_4441(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k4454 in parse-clause in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in a4389 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4456,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_4441(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k4439 in parse-clause in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in a4389 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_4441(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4441,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k4386 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[151],C_SCHEME_END_OF_LIST,t1);}

/* k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1914,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1917,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4013,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4015,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a4014 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4015(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4015,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4019,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[136],t2,lf[150]);}

/* k4017 in a4014 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4019,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cadddr(((C_word*)t0)[4]);
t5=(C_word)C_i_cddddr(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4034,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* r1178 */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[54]);}

/* k4032 in k4017 in a4014 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* r1178 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[84]);}

/* k4035 in k4032 in k4017 in a4014 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4040,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* r1178 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[85]);}

/* k4038 in k4035 in k4032 in k4017 in a4014 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4040,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4046,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* r1178 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[149]);}

/* k4044 in k4038 in k4035 in k4032 in k4017 in a4014 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* r1178 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[148]);}

/* k4047 in k4044 in k4038 in k4035 in k4032 in k4017 in a4014 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4052,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* r1178 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[147]);}

/* k4050 in k4047 in k4044 in k4038 in k4035 in k4032 in k4017 in a4014 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4055,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* map */
t3=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[146]+1),((C_word*)t0)[3]);}

/* k4053 in k4050 in k4047 in k4044 in k4038 in k4035 in k4032 in k4017 in a4014 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4055,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[81],t2);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4367,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t3,tmp=(C_word)a,a+=14,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4371,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4373,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t7=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t1);}

/* a4372 in k4053 in k4050 in k4047 in k4044 in k4038 in k4035 in k4032 in k4017 in a4014 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4373(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4373,3,t0,t1,t2);}
t3=(C_word)C_i_memq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:lf[145]));}

/* k4369 in k4053 in k4050 in k4047 in k4044 in k4038 in k4035 in k4032 in k4017 in a4014 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4365 in k4053 in k4050 in k4047 in k4044 in k4038 in k4035 in k4032 in k4017 in a4014 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[65],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4367,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[137],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[81],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[138],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,t8,t14);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t15);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4078,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t6,a[5]=t16,tmp=(C_word)a,a+=6,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4082,a[2]=t17,tmp=(C_word)a,a+=3,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4084,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t20,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp));
t22=((C_word*)t20)[1];
f_4084(t22,t18,((C_word*)t0)[2],C_fix(1));}

/* loop in k4365 in k4053 in k4050 in k4047 in k4044 in k4038 in k4035 in k4032 in k4017 in a4014 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_4084(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word ab[114],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4084,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_memq(lf[139],C_retrieve(lf[140]));
t6=(C_word)C_i_cddr(t4);
t7=(C_word)C_i_pairp(t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[81],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[141],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,lf[142],t14);
t16=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t16);
t18=(C_word)C_a_i_cons(&a,2,lf[143],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,t15,t19);
t21=(C_word)C_a_i_cons(&a,2,t8,t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t21);
t23=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4110,a[2]=((C_word*)t0)[3],a[3]=t22,a[4]=t5,a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=t2,a[9]=t1,a[10]=((C_word*)t0)[5],a[11]=t4,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t7)){
t24=(C_word)C_i_caddr(t4);
t25=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t26=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t25);
t27=(C_word)C_a_i_cons(&a,2,t24,t26);
t28=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t29=(C_word)C_a_i_cons(&a,2,lf[81],t28);
t30=(C_word)C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t30);
t32=(C_word)C_a_i_cons(&a,2,lf[141],t31);
t33=(C_word)C_a_i_cons(&a,2,t32,C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,lf[142],t33);
t35=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t36=(C_word)C_a_i_cons(&a,2,t3,t35);
t37=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t36);
t38=(C_word)C_a_i_cons(&a,2,lf[144],t37);
t39=(C_word)C_a_i_cons(&a,2,t38,C_SCHEME_END_OF_LIST);
t40=(C_word)C_a_i_cons(&a,2,t34,t39);
t41=(C_word)C_a_i_cons(&a,2,t27,t40);
t42=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t41);
t43=t23;
f_4110(t43,(C_word)C_a_i_cons(&a,2,t42,C_SCHEME_END_OF_LIST));}
else{
t24=t23;
f_4110(t24,C_SCHEME_END_OF_LIST);}}}

/* k4108 in loop in k4365 in k4053 in k4050 in k4047 in k4044 in k4038 in k4035 in k4032 in k4017 in a4014 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_4110(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4110,NULL,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4150,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[4]:C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[11]);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t6);
t8=t3;
f_4150(t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}
else{
t5=t3;
f_4150(t5,((C_word*)t0)[3]);}}

/* k4148 in k4108 in loop in k4365 in k4053 in k4050 in k4047 in k4044 in k4038 in k4035 in k4032 in k4017 in a4014 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_4150(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4150,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4122,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4126,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
t8=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* loop1213 */
t9=((C_word*)((C_word*)t0)[2])[1];
f_4084(t9,t6,t7,t8);}

/* k4124 in k4148 in k4108 in loop in k4365 in k4053 in k4050 in k4047 in k4044 in k4038 in k4035 in k4032 in k4017 in a4014 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4120 in k4148 in k4108 in loop in k4365 in k4053 in k4050 in k4047 in k4044 in k4038 in k4035 in k4032 in k4017 in a4014 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4122,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* ##sys#append */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4080 in k4365 in k4053 in k4050 in k4047 in k4044 in k4038 in k4035 in k4032 in k4017 in a4014 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4076 in k4365 in k4053 in k4050 in k4047 in k4044 in k4038 in k4035 in k4032 in k4017 in a4014 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4078,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k4011 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_4013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[136],C_SCHEME_END_OF_LIST,t1);}

/* k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1917,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1920,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3825,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3827,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a3826 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3827,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3831,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* r1250 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[134]);}

/* k3829 in a3826 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3834,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* r1250 */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[133]);}

/* k3832 in k3829 in a3826 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* r1250 */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[132]);}

/* k3835 in k3832 in k3829 in a3826 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3840,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* r1250 */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[54]);}

/* k3838 in k3835 in k3832 in k3829 in a3826 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3843,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* r1250 */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[84]);}

/* k3841 in k3838 in k3835 in k3832 in k3829 in a3826 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3843,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3852,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_3852(t6,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k3841 in k3838 in k3835 in k3832 in k3829 in a3826 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_3852(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3852,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3862,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* reverse */
t7=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3955,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=t3,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t7=(C_word)C_i_car(t2);
/* c1251 */
t8=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k3953 in loop in k3841 in k3838 in k3835 in k3832 in k3829 in a3826 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3955,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3958,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3977,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t4=C_retrieve(lf[55]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3983,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* c1251 */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k3981 in k3953 in loop in k3841 in k3838 in k3835 in k3832 in k3829 in a3826 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3983,2,t0,t1);}
if(C_truep(t1)){
/* loop1259 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3852(t2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[2]);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
/* loop1259 */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3852(t5,((C_word*)t0)[5],t2,((C_word*)t0)[4],t4,C_SCHEME_FALSE);}}

/* k3975 in k3953 in loop in k3841 in k3838 in k3835 in k3832 in k3829 in a3826 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r1250 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3956 in k3953 in loop in k3841 in k3838 in k3835 in k3832 in k3829 in a3826 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3958,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* loop1259 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3852(t5,((C_word*)t0)[2],t2,t3,t4,C_SCHEME_FALSE);}

/* k3860 in loop in k3841 in k3838 in k3835 in k3832 in k3829 in a3826 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3865,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* reverse */
t3=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3863 in k3860 in loop in k3841 in k3838 in k3835 in k3832 in k3829 in a3826 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3865,2,t0,t1);}
if(C_truep(((C_word*)t0)[8])){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3871,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3914,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t4=C_retrieve(lf[55]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3937,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_cdr(t1);
/* ##sys#append */
t7=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}}

/* k3935 in k3863 in k3860 in loop in k3841 in k3838 in k3835 in k3832 in k3829 in a3826 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3937,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k3912 in k3863 in k3860 in loop in k3841 in k3838 in k3835 in k3832 in k3829 in a3826 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r1250 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3869 in k3863 in k3860 in loop in k3841 in k3838 in k3835 in k3832 in k3829 in a3826 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3882,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* ##sys#append */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k3880 in k3869 in k3863 in k3860 in loop in k3841 in k3838 in k3835 in k3832 in k3829 in a3826 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3882,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3902,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
/* ##sys#append */
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k3900 in k3880 in k3869 in k3863 in k3860 in loop in k3841 in k3838 in k3835 in k3832 in k3829 in a3826 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3902,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k3823 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[135],C_SCHEME_END_OF_LIST,t1);}

/* k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3606,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3608,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a3607 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3608,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3612,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* r1291 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[71]);}

/* k3610 in a3607 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3615,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* r1291 */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[84]);}

/* k3613 in k3610 in a3607 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3615,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* r1291 */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[134]);}

/* k3616 in k3613 in k3610 in a3607 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3621,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* r1291 */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[133]);}

/* k3619 in k3616 in k3613 in k3610 in a3607 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* r1291 */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[132]);}

/* k3622 in k3619 in k3616 in k3613 in k3610 in a3607 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3624,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3633,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_3633(t6,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k3622 in k3619 in k3616 in k3613 in k3610 in a3607 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_3633(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3633,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t2))){
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3643,a[2]=t5,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=t4,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t6,tmp=(C_word)a,a+=10,tmp);
/* reverse */
t8=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3752,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t8=(C_word)C_i_car(t2);
/* c1292 */
t9=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t9))(4,t9,t7,((C_word*)t0)[2],t8);}}

/* k3750 in loop in k3622 in k3619 in k3616 in k3613 in k3610 in a3607 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3752,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3755,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3774,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t4=C_retrieve(lf[55]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3780,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[10]);
/* c1292 */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k3778 in k3750 in loop in k3622 in k3619 in k3616 in k3613 in k3610 in a3607 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3780,2,t0,t1);}
if(C_truep(t1)){
/* loop1300 */
t2=((C_word*)((C_word*)t0)[8])[1];
f_3633(t2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3786,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3813,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t4=C_retrieve(lf[55]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k3811 in k3778 in k3750 in loop in k3622 in k3619 in k3616 in k3613 in k3610 in a3607 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r1291 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3784 in k3778 in k3750 in loop in k3622 in k3619 in k3616 in k3613 in k3610 in a3607 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3786,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
t6=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* loop1300 */
t7=((C_word*)((C_word*)t0)[4])[1];
f_3633(t7,((C_word*)t0)[3],t2,((C_word*)t0)[2],t5,t6,C_SCHEME_FALSE);}

/* k3772 in k3750 in loop in k3622 in k3619 in k3616 in k3613 in k3610 in a3607 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r1291 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3753 in k3750 in loop in k3622 in k3619 in k3616 in k3613 in k3610 in a3607 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3755,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* loop1300 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3633(t5,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2],t4,C_SCHEME_FALSE);}

/* k3641 in loop in k3622 in k3619 in k3616 in k3613 in k3610 in a3607 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3646,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* reverse */
t3=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3644 in k3641 in loop in k3622 in k3619 in k3616 in k3613 in k3610 in a3607 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3646,2,t0,t1);}
if(C_truep(((C_word*)t0)[9])){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3652,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3707,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t4=C_retrieve(lf[55]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3742,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(t1);
/* ##sys#append */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}}

/* k3740 in k3644 in k3641 in loop in k3622 in k3619 in k3616 in k3613 in k3610 in a3607 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3742,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k3705 in k3644 in k3641 in loop in k3622 in k3619 in k3616 in k3613 in k3610 in a3607 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r1291 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3650 in k3644 in k3641 in loop in k3622 in k3619 in k3616 in k3613 in k3610 in a3607 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3675,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* ##sys#append */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k3673 in k3650 in k3644 in k3641 in loop in k3622 in k3619 in k3616 in k3613 in k3610 in a3607 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3675,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3695,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[8]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
/* ##sys#append */
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k3693 in k3673 in k3650 in k3644 in k3641 in loop in k3622 in k3619 in k3616 in k3613 in k3610 in a3607 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3695,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t8));}

/* k3604 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[131],C_SCHEME_END_OF_LIST,t1);}

/* k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1926,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3329,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3331,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3331,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3335,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[113],t2,lf[130]);}

/* k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3338,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* r1335 */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[64]);}

/* k3336 in k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3341,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* r1335 */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[54]);}

/* k3339 in k3336 in k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* r1335 */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[129]);}

/* k3342 in k3339 in k3336 in k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3347,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* r1335 */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[128]);}

/* k3345 in k3342 in k3339 in k3336 in k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3350,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* r1335 */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[127]);}

/* k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3350,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[9]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3359,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_3359(t6,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t2,C_SCHEME_FALSE);}

/* loop in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_3359(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3359,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t4))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3369,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3499,a[2]=((C_word*)t0)[9],a[3]=t6,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t8=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t5,C_SCHEME_END_OF_LIST);}
else{
t7=t6;
f_3369(t7,lf[122]);}}
else{
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3505,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=t5,a[7]=t3,a[8]=t1,a[9]=((C_word*)t0)[5],a[10]=t2,a[11]=((C_word*)t0)[6],a[12]=t4,tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_i_car(t4);
t8=t6;
f_3505(t8,(C_word)C_i_pairp(t7));}
else{
t7=t6;
f_3505(t7,C_SCHEME_FALSE);}}}

/* k3503 in loop in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_3505(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3505,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3508,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* caar */
t3=*((C_word*)lf[125]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[12]);}
else{
/* syntax-error */
t2=C_retrieve(lf[97]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[8],lf[113],lf[126],((C_word*)t0)[12]);}}

/* k3506 in k3503 in loop in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3508,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3517,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
/* c1336 */
t4=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],t1);}

/* k3515 in k3506 in k3503 in loop in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3517,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3532,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3536,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* cdar */
t4=*((C_word*)lf[123]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3542,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* c1336 */
t3=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k3540 in k3515 in k3506 in k3503 in loop in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3542,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3557,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3561,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* cdar */
t4=*((C_word*)lf[123]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3567,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* c1336 */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k3565 in k3540 in k3515 in k3506 in k3503 in loop in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3567,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3574,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
t4=(C_truep(t3)?t3:C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3582,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* cdar */
t6=*((C_word*)lf[123]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3589,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* caar */
t3=*((C_word*)lf[125]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k3587 in k3565 in k3540 in k3515 in k3506 in k3503 in loop in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* syntax-error */
t2=C_retrieve(lf[97]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[113],lf[124],t1);}

/* k3580 in k3565 in k3540 in k3515 in k3506 in k3503 in loop in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[36]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3572 in k3565 in k3540 in k3515 in k3506 in k3503 in loop in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* loop1344 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3359(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3559 in k3540 in k3515 in k3506 in k3503 in loop in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3555 in k3540 in k3515 in k3506 in k3503 in loop in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3557,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* loop1344 */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3359(t4,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3534 in k3515 in k3506 in k3503 in loop in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3530 in k3515 in k3506 in k3503 in loop in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3532,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* loop1344 */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3359(t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3497 in loop in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3499,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
f_3369(t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k3367 in loop in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_3369(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3369,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3376,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* r1335 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[121]);}

/* k3374 in k3367 in loop in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3484,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* ##sys#append */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k3482 in k3374 in k3367 in loop in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3484,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[114],t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* r1335 */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[120]);}

/* k3470 in k3482 in k3374 in k3367 in loop in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3472,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[115],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3468,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
/* ##sys#append */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k3466 in k3470 in k3482 in k3374 in k3367 in loop in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3468,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3404,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* r1335 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[119]);}

/* k3402 in k3466 in k3470 in k3482 in k3374 in k3367 in loop in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3404,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[116]),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[117],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3432,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=t5,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* r1335 */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[118]);}

/* k3430 in k3402 in k3466 in k3470 in k3482 in k3374 in k3367 in loop in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3432,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3444,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* r1335 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[81]);}

/* k3442 in k3430 in k3402 in k3466 in k3470 in k3482 in k3374 in k3367 in loop in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3444,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[116]),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t4);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3428,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
/* ##sys#append */
t7=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k3426 in k3442 in k3430 in k3402 in k3466 in k3470 in k3482 in k3374 in k3367 in loop in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in a3330 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3428,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t8));}

/* k3327 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[113],C_SCHEME_END_OF_LIST,t1);}

/* k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1929,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3225,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3227,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a3226 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3227(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3227,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3231,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[110],t2,lf[112]);}

/* k3229 in a3226 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3231,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3237,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* r1398 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[111]);}

/* k3235 in k3229 in a3226 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3237,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3282,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* r1398 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[84]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3321,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* ##sys#append */
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}}

/* k3319 in k3235 in k3229 in a3226 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3321,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k3280 in k3235 in k3229 in a3226 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3282,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3294,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k3292 in k3280 in k3235 in k3229 in a3226 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3294,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t6,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k3223 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[110],C_SCHEME_END_OF_LIST,t1);}

/* k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1929,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1932,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3117,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3119,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a3118 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3119(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3119,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3123,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[102],t2,lf[109]);}

/* k3121 in a3118 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3123,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[103]:t3);
t6=(C_word)C_i_pairp(t2);
t7=(C_truep(t6)?(C_word)C_i_car(t2):t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3138,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t7,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3197,a[2]=t5,a[3]=t8,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* r1414 */
t10=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,lf[84]);}
else{
t9=t8;
f_3138(t9,(C_word)C_i_car(t5));}}

/* k3195 in k3121 in a3118 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3197,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3209,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k3207 in k3195 in k3121 in a3118 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3209,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_3138(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k3136 in k3121 in a3118 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_3138(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3138,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3141,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3184,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval */
t4=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}
else{
/* syntax-error */
t3=C_retrieve(lf[97]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[102],lf[108],((C_word*)t0)[4]);}}

/* k3182 in k3136 in k3121 in a3118 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3141(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* k3139 in k3136 in k3121 in a3118 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3144,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_cons(&a,2,lf[85],t4);
/* ##sys#register-meta-expression */
t6=C_retrieve(lf[106]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t2,t5);}

/* k3142 in k3139 in k3136 in k3121 in a3118 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3144,2,t0,t1);}
if(C_truep(C_retrieve(lf[104]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3154,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* r1414 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[85]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[105]);}}

/* k3152 in k3142 in k3139 in k3136 in k3121 in a3118 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3154,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t1,t3));}

/* k3115 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[102],C_SCHEME_END_OF_LIST,t1);}

/* k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1932,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3092,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3094,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a3093 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3094(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3094,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3098,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[99],t2,lf[101]);}

/* k3096 in a3093 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3098,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[100],t4));}

/* k3090 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[99],C_SCHEME_END_OF_LIST,t1);}

/* k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1938,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3082,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3084,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a3083 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3084(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3084,5,t0,t1,t2,t3,t4);}
/* syntax-error */
t5=C_retrieve(lf[97]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,lf[96],lf[98]);}

/* k3080 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[96],C_SCHEME_END_OF_LIST,t1);}

/* k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1941,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#macro-subset */
t3=C_retrieve(lf[44]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1941,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! chicken-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1944,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* register-feature! */
t4=C_retrieve(lf[89]);
((C_proc8)C_retrieve_proc(t4))(8,t4,t3,lf[90],lf[91],lf[92],lf[93],lf[94],lf[95]);}

/* k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1948,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#macro-environment */
t3=C_retrieve(lf[88]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1951,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2780,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2782,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a2781 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2782,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2789,a[2]=t3,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* r1502 */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[81]);}

/* k2787 in a2781 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2792,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=t2;
f_2792(t4,(C_word)C_i_stringp(t3));}
else{
t3=t2;
f_2792(t3,C_SCHEME_FALSE);}}

/* k2790 in k2787 in a2781 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_2792(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2792,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2795,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=t1;
if(C_truep(t3)){
t4=t2;
f_2795(t4,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_2795(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t2;
f_2795(t4,C_SCHEME_FALSE);}}}

/* k2793 in k2790 in k2787 in a2781 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_2795(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2795,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2801,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t3=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[79],((C_word*)t0)[5],lf[80]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2900,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
/* ##sys#check-syntax */
t3=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[79],((C_word*)t0)[5],lf[86]);}
else{
/* ##sys#check-syntax */
t3=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[79],((C_word*)t0)[5],lf[87]);}}}

/* k2898 in k2793 in k2790 in k2787 in a2781 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2900,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_i_cadr(((C_word*)t0)[4]):(C_word)C_i_car(((C_word*)t0)[4]));
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2913,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* r1502 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[85]);}

/* k2911 in k2898 in k2793 in k2790 in k2787 in a2781 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2913,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[81],t4);
t6=(C_truep(((C_word*)t0)[6])?(C_word)C_i_car(((C_word*)t0)[5]):lf[82]);
t7=(C_truep(((C_word*)t0)[6])?(C_word)C_i_caddr(((C_word*)t0)[5]):(C_word)C_i_cadr(((C_word*)t0)[5]));
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,lf[81],t8);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3009,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=t2,a[9]=t5,a[10]=t6,a[11]=t9,tmp=(C_word)a,a+=12,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3011,tmp=(C_word)a,a+=2,tmp);
/* map */
t12=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,((C_word*)t0)[3]);}

/* a3010 in k2911 in k2898 in k2793 in k2790 in k2787 in a2781 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3011(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3011,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k3007 in k2911 in k2898 in k2793 in k2790 in k2787 in a2781 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_3009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3009,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[81],t2);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2973,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
/* r1502 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[84]);}

/* k2971 in k3007 in k2911 in k2898 in k2793 in k2790 in k2787 in a2781 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2981,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2997,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2996 in k2971 in k3007 in k2911 in k2898 in k2793 in k2790 in k2787 in a2781 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2997(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2997,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k2979 in k2971 in k3007 in k2911 in k2898 in k2793 in k2790 in k2787 in a2781 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2985,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t3=(C_truep(((C_word*)t0)[3])?(C_word)C_i_cdddr(((C_word*)t0)[2]):(C_word)C_i_cddr(((C_word*)t0)[2]));
/* ##sys#append */
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k2983 in k2979 in k2971 in k3007 in k2911 in k2898 in k2793 in k2790 in k2787 in a2781 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2985,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[83],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t10);
t12=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t11));}

/* k2799 in k2793 in k2790 in k2787 in a2781 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2801,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2811,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* r1502 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[54]);}

/* k2809 in k2799 in k2793 in k2790 in k2787 in a2781 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2811,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2885,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* r1502 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[53]);}

/* k2883 in k2809 in k2799 in k2793 in k2790 in k2787 in a2781 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2885,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2865,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* r1502 */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[75]);}

/* k2863 in k2883 in k2809 in k2799 in k2793 in k2790 in k2787 in a2781 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2865,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2835,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cddr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_caddr(((C_word*)t0)[6]);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[74],t12);
t14=t8;
f_2835(t14,(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST));}
else{
t10=t8;
f_2835(t10,C_SCHEME_END_OF_LIST);}}

/* k2833 in k2863 in k2883 in k2809 in k2799 in k2793 in k2790 in k2787 in a2781 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_2835(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2829 in k2863 in k2883 in k2809 in k2799 in k2793 in k2790 in k2787 in a2781 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2831,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k2778 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[79],C_SCHEME_END_OF_LIST,t1);}

/* k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1954,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2639,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2641,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a2640 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2641,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2645,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[73],t2,lf[78]);}

/* k2643 in a2640 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2645,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2657,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_2657(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_2657(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k2655 in k2643 in a2640 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2660,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2757,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t4=C_retrieve(lf[55]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2755 in k2655 in k2643 in a2640 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r1555 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2658 in k2655 in k2643 in a2640 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2660,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2667,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* r1555 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[54]);}

/* k2665 in k2658 in k2655 in k2643 in a2640 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2737,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* r1555 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[53]);}

/* k2735 in k2665 in k2658 in k2655 in k2643 in a2640 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2737,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2753,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* symbol->string */
t3=*((C_word*)lf[76]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k2751 in k2735 in k2665 in k2658 in k2655 in k2643 in a2640 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2753,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2717,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* r1555 */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[75]);}

/* k2715 in k2751 in k2735 in k2665 in k2658 in k2655 in k2643 in a2640 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2717,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2687,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2691,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t9=(C_word)C_i_car(((C_word*)t0)[2]);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t10);
t12=(C_word)C_a_i_cons(&a,2,lf[74],t11);
t13=t8;
f_2691(t13,(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST));}
else{
t9=t8;
f_2691(t9,C_SCHEME_END_OF_LIST);}}

/* k2689 in k2715 in k2751 in k2735 in k2665 in k2658 in k2655 in k2643 in a2640 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_2691(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2685 in k2715 in k2751 in k2735 in k2665 in k2658 in k2655 in k2643 in a2640 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2687,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k2637 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[73],C_SCHEME_END_OF_LIST,t1);}

/* k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1957,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2489,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2491,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a2490 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2491(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2491,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2495,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[66],t2,lf[72]);}

/* k2493 in a2490 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2495,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2504,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* r1581 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[71]);}

/* k2502 in k2493 in a2490 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2507,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2627,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a2626 in k2502 in k2493 in a2490 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2627(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2627,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2635,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t4=C_retrieve(lf[55]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2633 in a2626 in k2502 in k2493 in a2490 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r1581 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2505 in k2502 in k2493 in a2490 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2518,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2603,tmp=(C_word)a,a+=2,tmp);
/* append-map */
t4=C_retrieve(lf[69]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],t1);}

/* a2602 in k2505 in k2502 in k2493 in a2490 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2603(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2603,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cddr(t2);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}}

/* k2516 in k2505 in k2502 in k2493 in a2490 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2526,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2528,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2601,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#append */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k2599 in k2516 in k2505 in k2502 in k2493 in a2490 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2601,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
/* fold-right */
t4=C_retrieve(lf[68]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2527 in k2516 in k2505 in k2502 in k2493 in a2490 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2528(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[27],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2528,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t2);
t6=(C_word)C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t3,t9);
t11=(C_word)C_a_i_cons(&a,2,t8,t10);
t12=(C_word)C_a_i_cons(&a,2,t7,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,lf[67],t12));}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t8,t9);
t11=(C_word)C_a_i_cons(&a,2,t7,t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,lf[67],t11));}}

/* k2524 in k2516 in k2505 in k2502 in k2493 in a2490 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2526,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k2487 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[66],C_SCHEME_END_OF_LIST,t1);}

/* k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1960,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2421,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2423,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a2422 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2423(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2423,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2427,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[58],t2,lf[65]);}

/* k2425 in a2422 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2430,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* gensym */
t3=C_retrieve(lf[55]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[56]);}

/* k2428 in k2425 in a2422 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2437,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* r1621 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[54]);}

/* k2435 in k2428 in k2425 in a2422 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2461,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* r1621 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[64]);}

/* k2459 in k2435 in k2428 in k2425 in a2422 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2477,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2481,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* string-intersperse */
t5=C_retrieve(lf[62]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,lf[63]);}

/* k2479 in k2459 in k2435 in k2428 in k2425 in a2422 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sprintf */
t2=C_retrieve(lf[60]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[61],((C_word*)t0)[2],t1);}

/* k2475 in k2459 in k2435 in k2428 in k2425 in a2422 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2477,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[46],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[59],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t5,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k2419 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[58],C_SCHEME_END_OF_LIST,t1);}

/* k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1963,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2365,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2367,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a2366 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2367(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2367,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2371,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[52],t2,lf[57]);}

/* k2369 in a2366 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2374,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* gensym */
t3=C_retrieve(lf[55]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[56]);}

/* k2372 in k2369 in a2366 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2381,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* r1632 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[54]);}

/* k2379 in k2372 in k2369 in a2366 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2397,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* r1632 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[53]);}

/* k2395 in k2379 in k2372 in k2369 in a2366 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2397,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[5]);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,t1,t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k2363 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[52],C_SCHEME_END_OF_LIST,t1);}

/* k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2336,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2338,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a2337 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2338(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2338,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2342,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[46],t2,lf[50]);}

/* k2340 in a2337 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2357,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k2355 in k2340 in a2337 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2357,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[46],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[47],t3));}

/* k2334 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[46],C_SCHEME_END_OF_LIST,t1);}

/* k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1969,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#macro-subset */
t3=C_retrieve(lf[44]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1969,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1 /* (set! chicken-ffi-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1973,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2307,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2317,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2325,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2329,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 82   getenv */
t8=C_retrieve(lf[42]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,lf[43]);}

/* k2327 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[40]);
/* chicken.scm: 82   string-split */
t3=C_retrieve(lf[41]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k2323 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 80   remove */
t2=C_retrieve(lf[39]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2316 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2317(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2317,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_string_equal_p(t2,lf[38]));}

/* k2305 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2315,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 83   argv */
t3=C_retrieve(lf[37]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2313 in k2305 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(t1);
/* chicken.scm: 79   append */
t3=*((C_word*)lf[36]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k1971 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1973,2,t0,t1);}
t2=C_mutate((C_word*)lf[4]+1 /* (set! compiler-arguments ...) */,t1);
t3=C_mutate((C_word*)lf[5]+1 /* (set! process-command-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1975,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2082,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2090,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2102,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}

/* a2101 in k1971 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2102,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2106,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2114,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_2114(t9,t5,((C_word*)t4)[1]);}

/* loop in a2101 in k1971 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_2114(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(26);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2114,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_eqp(lf[13],t3);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2136,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t4);
/* chicken.scm: 116  string->number */
C_string_to_number(3,0,t6,t7);}
else{
t6=(C_word)C_eqp(lf[20],t3);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2199,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_car(t4);
/* chicken.scm: 130  string->number */
C_string_to_number(3,0,t7,t8);}
else{
t7=(C_word)C_eqp(lf[24],t3);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2253,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 139  cons* */
t9=C_retrieve(lf[14]);
((C_proc11)C_retrieve_proc(t9))(11,t9,t8,lf[25],lf[26],lf[22],lf[16],lf[15],lf[27],lf[28],lf[21],((C_word*)((C_word*)t0)[2])[1]);}
else{
if(C_truep((C_word)C_i_memq(t3,C_retrieve(lf[29])))){
/* chicken.scm: 143  loop */
t17=t1;
t18=t4;
t1=t17;
t2=t18;
goto loop;}
else{
if(C_truep((C_word)C_i_memq(t3,C_retrieve(lf[30])))){
if(C_truep((C_word)C_i_pairp(t4))){
t8=(C_word)C_i_cdr(t4);
/* chicken.scm: 146  loop */
t17=t1;
t18=t8;
t1=t17;
t2=t18;
goto loop;}
else{
/* chicken.scm: 147  quit */
t8=C_retrieve(lf[31]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,lf[32],t3);}}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2290,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2297,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_stringp(t3))){
t10=t9;
f_2297(2,t10,t3);}
else{
/* chicken.scm: 151  conc */
t10=C_retrieve(lf[34]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,lf[35],t3);}}}}}}}}

/* k2295 in loop in a2101 in k1971 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 149  compiler-warning */
t2=C_retrieve(lf[17]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[18],lf[33],t1);}

/* k2288 in loop in a2101 in k1971 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 152  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2114(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2251 in loop in a2101 in k1971 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* chicken.scm: 142  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2114(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2197 in loop in a2101 in k1971 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2199,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2202,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
switch(t1){
case C_fix(0):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2216,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 132  cons* */
t4=C_retrieve(lf[14]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[21],lf[22],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,lf[22],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_2202(2,t5,t4);
case C_fix(2):
t3=t2;
f_2202(2,t3,C_SCHEME_FALSE);
default:
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 135  compiler-warning */
t4=C_retrieve(lf[17]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[18],lf[23],t3);}}

/* k2214 in k2197 in loop in a2101 in k1971 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2202(2,t3,t2);}

/* k2200 in k2197 in loop in a2101 in k1971 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 136  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2114(t3,((C_word*)t0)[2],t2);}

/* k2134 in loop in a2101 in k1971 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2136,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2139,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
switch(t1){
case C_fix(0):
t3=t2;
f_2139(2,t3,C_SCHEME_FALSE);
case C_fix(1):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2159,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 120  cons* */
t4=C_retrieve(lf[14]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[15],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(2):
t3=(C_word)C_a_i_cons(&a,2,lf[15],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_2139(2,t5,t4);
case C_fix(3):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2179,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 126  cons* */
t4=C_retrieve(lf[14]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[15],lf[16],((C_word*)((C_word*)t0)[2])[1]);
default:
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 127  compiler-warning */
t4=C_retrieve(lf[17]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[18],lf[19],t3);}}

/* k2177 in k2134 in loop in a2101 in k1971 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2139(2,t3,t2);}

/* k2157 in k2134 in loop in a2101 in k1971 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2139(2,t3,t2);}

/* k2137 in k2134 in loop in a2101 in k1971 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 128  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2114(t3,((C_word*)t0)[2],t2);}

/* k2104 in a2101 in k1971 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2106,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2109,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t2,C_retrieve(lf[12]),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2107 in k2104 in a2101 in k1971 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 154  exit */
t2=C_retrieve(lf[11]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a2089 in k1971 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2090,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2097,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 110  user-options-pass */
t3=C_retrieve(lf[10]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2095 in a2089 in k1971 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_retrieve(lf[5]));
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_retrieve(lf[4]));}

/* k2080 in k1971 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2085,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2088,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
t4=C_retrieve(lf[9]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2086 in k2080 in k1971 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k2083 in k2080 in k1971 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##compiler#process-command-line in k1971 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1975(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1975,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1981,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_1981(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in ##compiler#process-command-line in k1971 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_1981(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1981,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1995,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 95   reverse */
t6=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_string_length(t5);
t7=(C_word)C_i_string_ref(t5,C_fix(0));
t8=(C_word)C_eqp(C_make_character(45),t7);
t9=(C_truep(t8)?(C_word)C_fixnum_greaterp(t6,C_fix(1)):C_SCHEME_FALSE);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2016,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t6,C_fix(1)))){
t11=(C_word)C_i_string_ref(t5,C_fix(1));
t12=t10;
f_2016(t12,(C_word)C_eqp(C_make_character(58),t11));}
else{
t11=t10;
f_2016(t11,C_SCHEME_FALSE);}}
else{
if(C_truep(t4)){
t10=(C_word)C_i_cdr(t2);
t11=(C_word)C_a_i_cons(&a,2,t5,t3);
/* chicken.scm: 104  loop */
t17=t1;
t18=t10;
t19=t11;
t20=t4;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}
else{
t10=(C_word)C_i_cdr(t2);
/* chicken.scm: 105  loop */
t17=t1;
t18=t10;
t19=t3;
t20=t5;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}}}}

/* k2014 in loop in ##compiler#process-command-line in k1971 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_fcall f_2016(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2016,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* chicken.scm: 101  loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_1981(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2038,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2042,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 102  substring */
t5=*((C_word*)lf[8]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]);}}

/* k2040 in k2014 in loop in ##compiler#process-command-line in k1971 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 102  string->symbol */
t2=*((C_word*)lf[7]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2036 in k2014 in loop in ##compiler#process-command-line in k1971 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_2038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2038,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* chicken.scm: 102  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1981(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1993 in loop in ##compiler#process-command-line in k1971 in k1967 in k1964 in k1961 in k1958 in k1955 in k1952 in k1949 in k1946 in k1942 in k1939 in k1936 in k1933 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1773 */
static void C_ccall f_1995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 95   values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[705] = {
{"toplevelchicken.scm",(void*)C_toplevel},
{"f_1775chicken.scm",(void*)f_1775},
{"f_1778chicken.scm",(void*)f_1778},
{"f_1781chicken.scm",(void*)f_1781},
{"f_1784chicken.scm",(void*)f_1784},
{"f_1787chicken.scm",(void*)f_1787},
{"f_1790chicken.scm",(void*)f_1790},
{"f_1793chicken.scm",(void*)f_1793},
{"f_1796chicken.scm",(void*)f_1796},
{"f_1799chicken.scm",(void*)f_1799},
{"f_1802chicken.scm",(void*)f_1802},
{"f_1805chicken.scm",(void*)f_1805},
{"f_1808chicken.scm",(void*)f_1808},
{"f_1811chicken.scm",(void*)f_1811},
{"f_1814chicken.scm",(void*)f_1814},
{"f_1817chicken.scm",(void*)f_1817},
{"f_1820chicken.scm",(void*)f_1820},
{"f_1823chicken.scm",(void*)f_1823},
{"f_1826chicken.scm",(void*)f_1826},
{"f_1830chicken.scm",(void*)f_1830},
{"f_8944chicken.scm",(void*)f_8944},
{"f_8948chicken.scm",(void*)f_8948},
{"f_8957chicken.scm",(void*)f_8957},
{"f_8963chicken.scm",(void*)f_8963},
{"f_8966chicken.scm",(void*)f_8966},
{"f_8969chicken.scm",(void*)f_8969},
{"f_8972chicken.scm",(void*)f_8972},
{"f_9382chicken.scm",(void*)f_9382},
{"f_9342chicken.scm",(void*)f_9342},
{"f_9374chicken.scm",(void*)f_9374},
{"f_9334chicken.scm",(void*)f_9334},
{"f_9290chicken.scm",(void*)f_9290},
{"f_9001chicken.scm",(void*)f_9001},
{"f_9011chicken.scm",(void*)f_9011},
{"f_9278chicken.scm",(void*)f_9278},
{"f_9014chicken.scm",(void*)f_9014},
{"f_9274chicken.scm",(void*)f_9274},
{"f_9017chicken.scm",(void*)f_9017},
{"f_9064chicken.scm",(void*)f_9064},
{"f_9028chicken.scm",(void*)f_9028},
{"f_8999chicken.scm",(void*)f_8999},
{"f_8995chicken.scm",(void*)f_8995},
{"f_8942chicken.scm",(void*)f_8942},
{"f_1833chicken.scm",(void*)f_1833},
{"f_8801chicken.scm",(void*)f_8801},
{"f_8805chicken.scm",(void*)f_8805},
{"f_8808chicken.scm",(void*)f_8808},
{"f_8811chicken.scm",(void*)f_8811},
{"f_8847chicken.scm",(void*)f_8847},
{"f_8862chicken.scm",(void*)f_8862},
{"f_8916chicken.scm",(void*)f_8916},
{"f_8877chicken.scm",(void*)f_8877},
{"f_8840chicken.scm",(void*)f_8840},
{"f_8799chicken.scm",(void*)f_8799},
{"f_1836chicken.scm",(void*)f_1836},
{"f_8702chicken.scm",(void*)f_8702},
{"f_8706chicken.scm",(void*)f_8706},
{"f_8709chicken.scm",(void*)f_8709},
{"f_8712chicken.scm",(void*)f_8712},
{"f_8791chicken.scm",(void*)f_8791},
{"f_8700chicken.scm",(void*)f_8700},
{"f_1839chicken.scm",(void*)f_1839},
{"f_8684chicken.scm",(void*)f_8684},
{"f_8692chicken.scm",(void*)f_8692},
{"f_8682chicken.scm",(void*)f_8682},
{"f_1842chicken.scm",(void*)f_1842},
{"f_8595chicken.scm",(void*)f_8595},
{"f_8599chicken.scm",(void*)f_8599},
{"f_8602chicken.scm",(void*)f_8602},
{"f_8605chicken.scm",(void*)f_8605},
{"f_8671chicken.scm",(void*)f_8671},
{"f_8608chicken.scm",(void*)f_8608},
{"f_8621chicken.scm",(void*)f_8621},
{"f_8665chicken.scm",(void*)f_8665},
{"f_8632chicken.scm",(void*)f_8632},
{"f_8640chicken.scm",(void*)f_8640},
{"f_8642chicken.scm",(void*)f_8642},
{"f_8659chicken.scm",(void*)f_8659},
{"f_8627chicken.scm",(void*)f_8627},
{"f_8619chicken.scm",(void*)f_8619},
{"f_8615chicken.scm",(void*)f_8615},
{"f_8593chicken.scm",(void*)f_8593},
{"f_1845chicken.scm",(void*)f_1845},
{"f_8484chicken.scm",(void*)f_8484},
{"f_8488chicken.scm",(void*)f_8488},
{"f_8497chicken.scm",(void*)f_8497},
{"f_8500chicken.scm",(void*)f_8500},
{"f_8503chicken.scm",(void*)f_8503},
{"f_8546chicken.scm",(void*)f_8546},
{"f_8482chicken.scm",(void*)f_8482},
{"f_1848chicken.scm",(void*)f_1848},
{"f_8347chicken.scm",(void*)f_8347},
{"f_8351chicken.scm",(void*)f_8351},
{"f_8363chicken.scm",(void*)f_8363},
{"f_8366chicken.scm",(void*)f_8366},
{"f_8369chicken.scm",(void*)f_8369},
{"f_8420chicken.scm",(void*)f_8420},
{"f_8416chicken.scm",(void*)f_8416},
{"f_8345chicken.scm",(void*)f_8345},
{"f_1851chicken.scm",(void*)f_1851},
{"f_8089chicken.scm",(void*)f_8089},
{"f_8093chicken.scm",(void*)f_8093},
{"f_8102chicken.scm",(void*)f_8102},
{"f_8333chicken.scm",(void*)f_8333},
{"f_8341chicken.scm",(void*)f_8341},
{"f_8105chicken.scm",(void*)f_8105},
{"f_8323chicken.scm",(void*)f_8323},
{"f_8331chicken.scm",(void*)f_8331},
{"f_8108chicken.scm",(void*)f_8108},
{"f_8111chicken.scm",(void*)f_8111},
{"f_8114chicken.scm",(void*)f_8114},
{"f_8321chicken.scm",(void*)f_8321},
{"f_8281chicken.scm",(void*)f_8281},
{"f_8299chicken.scm",(void*)f_8299},
{"f_8313chicken.scm",(void*)f_8313},
{"f_8293chicken.scm",(void*)f_8293},
{"f_8289chicken.scm",(void*)f_8289},
{"f_8285chicken.scm",(void*)f_8285},
{"f_8125chicken.scm",(void*)f_8125},
{"f_8265chicken.scm",(void*)f_8265},
{"f_8233chicken.scm",(void*)f_8233},
{"f_8251chicken.scm",(void*)f_8251},
{"f_8241chicken.scm",(void*)f_8241},
{"f_8237chicken.scm",(void*)f_8237},
{"f_8229chicken.scm",(void*)f_8229},
{"f_8221chicken.scm",(void*)f_8221},
{"f_8201chicken.scm",(void*)f_8201},
{"f_8169chicken.scm",(void*)f_8169},
{"f_8187chicken.scm",(void*)f_8187},
{"f_8177chicken.scm",(void*)f_8177},
{"f_8173chicken.scm",(void*)f_8173},
{"f_8165chicken.scm",(void*)f_8165},
{"f_8087chicken.scm",(void*)f_8087},
{"f_1854chicken.scm",(void*)f_1854},
{"f_7968chicken.scm",(void*)f_7968},
{"f_7972chicken.scm",(void*)f_7972},
{"f_7978chicken.scm",(void*)f_7978},
{"f_8079chicken.scm",(void*)f_8079},
{"f_7984chicken.scm",(void*)f_7984},
{"f_7987chicken.scm",(void*)f_7987},
{"f_7990chicken.scm",(void*)f_7990},
{"f_8030chicken.scm",(void*)f_8030},
{"f_8053chicken.scm",(void*)f_8053},
{"f_8060chicken.scm",(void*)f_8060},
{"f_8067chicken.scm",(void*)f_8067},
{"f_8043chicken.scm",(void*)f_8043},
{"f_7993chicken.scm",(void*)f_7993},
{"f_7966chicken.scm",(void*)f_7966},
{"f_1857chicken.scm",(void*)f_1857},
{"f_7766chicken.scm",(void*)f_7766},
{"f_7770chicken.scm",(void*)f_7770},
{"f_7779chicken.scm",(void*)f_7779},
{"f_7782chicken.scm",(void*)f_7782},
{"f_7785chicken.scm",(void*)f_7785},
{"f_7788chicken.scm",(void*)f_7788},
{"f_7791chicken.scm",(void*)f_7791},
{"f_7954chicken.scm",(void*)f_7954},
{"f_7962chicken.scm",(void*)f_7962},
{"f_7794chicken.scm",(void*)f_7794},
{"f_7944chicken.scm",(void*)f_7944},
{"f_7952chicken.scm",(void*)f_7952},
{"f_7797chicken.scm",(void*)f_7797},
{"f_7938chicken.scm",(void*)f_7938},
{"f_7942chicken.scm",(void*)f_7942},
{"f_7808chicken.scm",(void*)f_7808},
{"f_7882chicken.scm",(void*)f_7882},
{"f_7880chicken.scm",(void*)f_7880},
{"f_7876chicken.scm",(void*)f_7876},
{"f_7856chicken.scm",(void*)f_7856},
{"f_7764chicken.scm",(void*)f_7764},
{"f_1860chicken.scm",(void*)f_1860},
{"f_7721chicken.scm",(void*)f_7721},
{"f_7725chicken.scm",(void*)f_7725},
{"f_7732chicken.scm",(void*)f_7732},
{"f_7752chicken.scm",(void*)f_7752},
{"f_7756chicken.scm",(void*)f_7756},
{"f_7719chicken.scm",(void*)f_7719},
{"f_1863chicken.scm",(void*)f_1863},
{"f_7668chicken.scm",(void*)f_7668},
{"f_7672chicken.scm",(void*)f_7672},
{"f_7679chicken.scm",(void*)f_7679},
{"f_7707chicken.scm",(void*)f_7707},
{"f_7711chicken.scm",(void*)f_7711},
{"f_7666chicken.scm",(void*)f_7666},
{"f_1866chicken.scm",(void*)f_1866},
{"f_7523chicken.scm",(void*)f_7523},
{"f_7527chicken.scm",(void*)f_7527},
{"f_7536chicken.scm",(void*)f_7536},
{"f_7605chicken.scm",(void*)f_7605},
{"f_7638chicken.scm",(void*)f_7638},
{"f_7636chicken.scm",(void*)f_7636},
{"f_7632chicken.scm",(void*)f_7632},
{"f_7521chicken.scm",(void*)f_7521},
{"f_1869chicken.scm",(void*)f_1869},
{"f_7481chicken.scm",(void*)f_7481},
{"f_7485chicken.scm",(void*)f_7485},
{"f_7505chicken.scm",(void*)f_7505},
{"f_7513chicken.scm",(void*)f_7513},
{"f_7488chicken.scm",(void*)f_7488},
{"f_7495chicken.scm",(void*)f_7495},
{"f_7499chicken.scm",(void*)f_7499},
{"f_7479chicken.scm",(void*)f_7479},
{"f_1872chicken.scm",(void*)f_1872},
{"f_7093chicken.scm",(void*)f_7093},
{"f_7097chicken.scm",(void*)f_7097},
{"f_7106chicken.scm",(void*)f_7106},
{"f_7109chicken.scm",(void*)f_7109},
{"f_7184chicken.scm",(void*)f_7184},
{"f_7437chicken.scm",(void*)f_7437},
{"f_7450chicken.scm",(void*)f_7450},
{"f_7187chicken.scm",(void*)f_7187},
{"f_7423chicken.scm",(void*)f_7423},
{"f_7435chicken.scm",(void*)f_7435},
{"f_7431chicken.scm",(void*)f_7431},
{"f_7190chicken.scm",(void*)f_7190},
{"f_7377chicken.scm",(void*)f_7377},
{"f_7410chicken.scm",(void*)f_7410},
{"f_7417chicken.scm",(void*)f_7417},
{"f_7393chicken.scm",(void*)f_7393},
{"f_7202chicken.scm",(void*)f_7202},
{"f_7371chicken.scm",(void*)f_7371},
{"f_7209chicken.scm",(void*)f_7209},
{"f_7211chicken.scm",(void*)f_7211},
{"f_7365chicken.scm",(void*)f_7365},
{"f_7249chicken.scm",(void*)f_7249},
{"f_7331chicken.scm",(void*)f_7331},
{"f_7288chicken.scm",(void*)f_7288},
{"f_7268chicken.scm",(void*)f_7268},
{"f_7235chicken.scm",(void*)f_7235},
{"f_7243chicken.scm",(void*)f_7243},
{"f_7229chicken.scm",(void*)f_7229},
{"f_7233chicken.scm",(void*)f_7233},
{"f_7191chicken.scm",(void*)f_7191},
{"f_7142chicken.scm",(void*)f_7142},
{"f_7165chicken.scm",(void*)f_7165},
{"f_7169chicken.scm",(void*)f_7169},
{"f_7111chicken.scm",(void*)f_7111},
{"f_7132chicken.scm",(void*)f_7132},
{"f_7091chicken.scm",(void*)f_7091},
{"f_1875chicken.scm",(void*)f_1875},
{"f_7021chicken.scm",(void*)f_7021},
{"f_7025chicken.scm",(void*)f_7025},
{"f_7034chicken.scm",(void*)f_7034},
{"f_7037chicken.scm",(void*)f_7037},
{"f_7042chicken.scm",(void*)f_7042},
{"f_7079chicken.scm",(void*)f_7079},
{"f_7060chicken.scm",(void*)f_7060},
{"f_7019chicken.scm",(void*)f_7019},
{"f_1878chicken.scm",(void*)f_1878},
{"f_6855chicken.scm",(void*)f_6855},
{"f_6859chicken.scm",(void*)f_6859},
{"f_6868chicken.scm",(void*)f_6868},
{"f_6871chicken.scm",(void*)f_6871},
{"f_7011chicken.scm",(void*)f_7011},
{"f_7009chicken.scm",(void*)f_7009},
{"f_6874chicken.scm",(void*)f_6874},
{"f_6993chicken.scm",(void*)f_6993},
{"f_7005chicken.scm",(void*)f_7005},
{"f_7001chicken.scm",(void*)f_7001},
{"f_6877chicken.scm",(void*)f_6877},
{"f_6987chicken.scm",(void*)f_6987},
{"f_6897chicken.scm",(void*)f_6897},
{"f_6911chicken.scm",(void*)f_6911},
{"f_6939chicken.scm",(void*)f_6939},
{"f_6949chicken.scm",(void*)f_6949},
{"f_6965chicken.scm",(void*)f_6965},
{"f_6947chicken.scm",(void*)f_6947},
{"f_6943chicken.scm",(void*)f_6943},
{"f_6905chicken.scm",(void*)f_6905},
{"f_6909chicken.scm",(void*)f_6909},
{"f_6901chicken.scm",(void*)f_6901},
{"f_6878chicken.scm",(void*)f_6878},
{"f_6853chicken.scm",(void*)f_6853},
{"f_1881chicken.scm",(void*)f_1881},
{"f_6781chicken.scm",(void*)f_6781},
{"f_6785chicken.scm",(void*)f_6785},
{"f_6788chicken.scm",(void*)f_6788},
{"f_6791chicken.scm",(void*)f_6791},
{"f_6794chicken.scm",(void*)f_6794},
{"f_6779chicken.scm",(void*)f_6779},
{"f_1884chicken.scm",(void*)f_1884},
{"f_6680chicken.scm",(void*)f_6680},
{"f_6684chicken.scm",(void*)f_6684},
{"f_6771chicken.scm",(void*)f_6771},
{"f_6767chicken.scm",(void*)f_6767},
{"f_6686chicken.scm",(void*)f_6686},
{"f_6690chicken.scm",(void*)f_6690},
{"f_6747chicken.scm",(void*)f_6747},
{"f_6699chicken.scm",(void*)f_6699},
{"f_6721chicken.scm",(void*)f_6721},
{"f_6711chicken.scm",(void*)f_6711},
{"f_6702chicken.scm",(void*)f_6702},
{"f_6678chicken.scm",(void*)f_6678},
{"f_1887chicken.scm",(void*)f_1887},
{"f_6517chicken.scm",(void*)f_6517},
{"f_6521chicken.scm",(void*)f_6521},
{"f_6530chicken.scm",(void*)f_6530},
{"f_6533chicken.scm",(void*)f_6533},
{"f_6538chicken.scm",(void*)f_6538},
{"f_6583chicken.scm",(void*)f_6583},
{"f_6650chicken.scm",(void*)f_6650},
{"f_6612chicken.scm",(void*)f_6612},
{"f_6552chicken.scm",(void*)f_6552},
{"f_6556chicken.scm",(void*)f_6556},
{"f_6515chicken.scm",(void*)f_6515},
{"f_1890chicken.scm",(void*)f_1890},
{"f_6348chicken.scm",(void*)f_6348},
{"f_6352chicken.scm",(void*)f_6352},
{"f_6361chicken.scm",(void*)f_6361},
{"f_6364chicken.scm",(void*)f_6364},
{"f_6367chicken.scm",(void*)f_6367},
{"f_6370chicken.scm",(void*)f_6370},
{"f_6373chicken.scm",(void*)f_6373},
{"f_6376chicken.scm",(void*)f_6376},
{"f_6383chicken.scm",(void*)f_6383},
{"f_6401chicken.scm",(void*)f_6401},
{"f_6417chicken.scm",(void*)f_6417},
{"f_6423chicken.scm",(void*)f_6423},
{"f_6479chicken.scm",(void*)f_6479},
{"f_6477chicken.scm",(void*)f_6477},
{"f_6473chicken.scm",(void*)f_6473},
{"f_6465chicken.scm",(void*)f_6465},
{"f_6461chicken.scm",(void*)f_6461},
{"f_6430chicken.scm",(void*)f_6430},
{"f_6399chicken.scm",(void*)f_6399},
{"f_6346chicken.scm",(void*)f_6346},
{"f_1893chicken.scm",(void*)f_1893},
{"f_5916chicken.scm",(void*)f_5916},
{"f_5920chicken.scm",(void*)f_5920},
{"f_5932chicken.scm",(void*)f_5932},
{"f_5935chicken.scm",(void*)f_5935},
{"f_5938chicken.scm",(void*)f_5938},
{"f_5941chicken.scm",(void*)f_5941},
{"f_5944chicken.scm",(void*)f_5944},
{"f_5947chicken.scm",(void*)f_5947},
{"f_6235chicken.scm",(void*)f_6235},
{"f_6238chicken.scm",(void*)f_6238},
{"f_6241chicken.scm",(void*)f_6241},
{"f_6334chicken.scm",(void*)f_6334},
{"f_6342chicken.scm",(void*)f_6342},
{"f_6257chicken.scm",(void*)f_6257},
{"f_6260chicken.scm",(void*)f_6260},
{"f_6263chicken.scm",(void*)f_6263},
{"f_6266chicken.scm",(void*)f_6266},
{"f_6324chicken.scm",(void*)f_6324},
{"f_6332chicken.scm",(void*)f_6332},
{"f_6269chicken.scm",(void*)f_6269},
{"f_6272chicken.scm",(void*)f_6272},
{"f_6275chicken.scm",(void*)f_6275},
{"f_6282chicken.scm",(void*)f_6282},
{"f_6242chicken.scm",(void*)f_6242},
{"f_6254chicken.scm",(void*)f_6254},
{"f_6250chicken.scm",(void*)f_6250},
{"f_6046chicken.scm",(void*)f_6046},
{"f_6052chicken.scm",(void*)f_6052},
{"f_6228chicken.scm",(void*)f_6228},
{"f_6172chicken.scm",(void*)f_6172},
{"f_6114chicken.scm",(void*)f_6114},
{"f_5949chicken.scm",(void*)f_5949},
{"f_5957chicken.scm",(void*)f_5957},
{"f_5961chicken.scm",(void*)f_5961},
{"f_5965chicken.scm",(void*)f_5965},
{"f_5967chicken.scm",(void*)f_5967},
{"f_6020chicken.scm",(void*)f_6020},
{"f_6036chicken.scm",(void*)f_6036},
{"f_6032chicken.scm",(void*)f_6032},
{"f_5988chicken.scm",(void*)f_5988},
{"f_5914chicken.scm",(void*)f_5914},
{"f_1896chicken.scm",(void*)f_1896},
{"f_5732chicken.scm",(void*)f_5732},
{"f_5736chicken.scm",(void*)f_5736},
{"f_5739chicken.scm",(void*)f_5739},
{"f_5742chicken.scm",(void*)f_5742},
{"f_5745chicken.scm",(void*)f_5745},
{"f_5752chicken.scm",(void*)f_5752},
{"f_5787chicken.scm",(void*)f_5787},
{"f_5871chicken.scm",(void*)f_5871},
{"f_5847chicken.scm",(void*)f_5847},
{"f_5730chicken.scm",(void*)f_5730},
{"f_1899chicken.scm",(void*)f_1899},
{"f_5430chicken.scm",(void*)f_5430},
{"f_5434chicken.scm",(void*)f_5434},
{"f_5446chicken.scm",(void*)f_5446},
{"f_5449chicken.scm",(void*)f_5449},
{"f_5452chicken.scm",(void*)f_5452},
{"f_5455chicken.scm",(void*)f_5455},
{"f_5458chicken.scm",(void*)f_5458},
{"f_5461chicken.scm",(void*)f_5461},
{"f_5482chicken.scm",(void*)f_5482},
{"f_5710chicken.scm",(void*)f_5710},
{"f_5572chicken.scm",(void*)f_5572},
{"f_5591chicken.scm",(void*)f_5591},
{"f_5548chicken.scm",(void*)f_5548},
{"f_5480chicken.scm",(void*)f_5480},
{"f_5428chicken.scm",(void*)f_5428},
{"f_1902chicken.scm",(void*)f_1902},
{"f_5009chicken.scm",(void*)f_5009},
{"f_5013chicken.scm",(void*)f_5013},
{"f_5050chicken.scm",(void*)f_5050},
{"f_5409chicken.scm",(void*)f_5409},
{"f_5419chicken.scm",(void*)f_5419},
{"f_5407chicken.scm",(void*)f_5407},
{"f_5053chicken.scm",(void*)f_5053},
{"f_5056chicken.scm",(void*)f_5056},
{"f_5059chicken.scm",(void*)f_5059},
{"f_5062chicken.scm",(void*)f_5062},
{"f_5065chicken.scm",(void*)f_5065},
{"f_5068chicken.scm",(void*)f_5068},
{"f_5071chicken.scm",(void*)f_5071},
{"f_5082chicken.scm",(void*)f_5082},
{"f_5108chicken.scm",(void*)f_5108},
{"f_5118chicken.scm",(void*)f_5118},
{"f_5122chicken.scm",(void*)f_5122},
{"f_5371chicken.scm",(void*)f_5371},
{"f_5356chicken.scm",(void*)f_5356},
{"f_5136chicken.scm",(void*)f_5136},
{"f_5160chicken.scm",(void*)f_5160},
{"f_5187chicken.scm",(void*)f_5187},
{"f_5343chicken.scm",(void*)f_5343},
{"f_5255chicken.scm",(void*)f_5255},
{"f_5335chicken.scm",(void*)f_5335},
{"f_5315chicken.scm",(void*)f_5315},
{"f_5274chicken.scm",(void*)f_5274},
{"f_5244chicken.scm",(void*)f_5244},
{"f_5212chicken.scm",(void*)f_5212},
{"f_5164chicken.scm",(void*)f_5164},
{"f_5181chicken.scm",(void*)f_5181},
{"f_5150chicken.scm",(void*)f_5150},
{"f_5158chicken.scm",(void*)f_5158},
{"f_5144chicken.scm",(void*)f_5144},
{"f_5106chicken.scm",(void*)f_5106},
{"f_5015chicken.scm",(void*)f_5015},
{"f_5021chicken.scm",(void*)f_5021},
{"f_5047chicken.scm",(void*)f_5047},
{"f_5035chicken.scm",(void*)f_5035},
{"f_5039chicken.scm",(void*)f_5039},
{"f_5007chicken.scm",(void*)f_5007},
{"f_1905chicken.scm",(void*)f_1905},
{"f_4911chicken.scm",(void*)f_4911},
{"f_4915chicken.scm",(void*)f_4915},
{"f_4980chicken.scm",(void*)f_4980},
{"f_4995chicken.scm",(void*)f_4995},
{"f_4930chicken.scm",(void*)f_4930},
{"f_4953chicken.scm",(void*)f_4953},
{"f_4965chicken.scm",(void*)f_4965},
{"f_4909chicken.scm",(void*)f_4909},
{"f_1908chicken.scm",(void*)f_1908},
{"f_4717chicken.scm",(void*)f_4717},
{"f_4721chicken.scm",(void*)f_4721},
{"f_4724chicken.scm",(void*)f_4724},
{"f_4727chicken.scm",(void*)f_4727},
{"f_4730chicken.scm",(void*)f_4730},
{"f_4741chicken.scm",(void*)f_4741},
{"f_4769chicken.scm",(void*)f_4769},
{"f_4861chicken.scm",(void*)f_4861},
{"f_4715chicken.scm",(void*)f_4715},
{"f_1911chicken.scm",(void*)f_1911},
{"f_4390chicken.scm",(void*)f_4390},
{"f_4394chicken.scm",(void*)f_4394},
{"f_4397chicken.scm",(void*)f_4397},
{"f_4400chicken.scm",(void*)f_4400},
{"f_4403chicken.scm",(void*)f_4403},
{"f_4406chicken.scm",(void*)f_4406},
{"f_4409chicken.scm",(void*)f_4409},
{"f_4412chicken.scm",(void*)f_4412},
{"f_4587chicken.scm",(void*)f_4587},
{"f_4627chicken.scm",(void*)f_4627},
{"f_4635chicken.scm",(void*)f_4635},
{"f_4631chicken.scm",(void*)f_4631},
{"f_4414chicken.scm",(void*)f_4414},
{"f_4538chicken.scm",(void*)f_4538},
{"f_4536chicken.scm",(void*)f_4536},
{"f_4532chicken.scm",(void*)f_4532},
{"f_4524chicken.scm",(void*)f_4524},
{"f_4505chicken.scm",(void*)f_4505},
{"f_4490chicken.scm",(void*)f_4490},
{"f_4475chicken.scm",(void*)f_4475},
{"f_4456chicken.scm",(void*)f_4456},
{"f_4441chicken.scm",(void*)f_4441},
{"f_4388chicken.scm",(void*)f_4388},
{"f_1914chicken.scm",(void*)f_1914},
{"f_4015chicken.scm",(void*)f_4015},
{"f_4019chicken.scm",(void*)f_4019},
{"f_4034chicken.scm",(void*)f_4034},
{"f_4037chicken.scm",(void*)f_4037},
{"f_4040chicken.scm",(void*)f_4040},
{"f_4046chicken.scm",(void*)f_4046},
{"f_4049chicken.scm",(void*)f_4049},
{"f_4052chicken.scm",(void*)f_4052},
{"f_4055chicken.scm",(void*)f_4055},
{"f_4373chicken.scm",(void*)f_4373},
{"f_4371chicken.scm",(void*)f_4371},
{"f_4367chicken.scm",(void*)f_4367},
{"f_4084chicken.scm",(void*)f_4084},
{"f_4110chicken.scm",(void*)f_4110},
{"f_4150chicken.scm",(void*)f_4150},
{"f_4126chicken.scm",(void*)f_4126},
{"f_4122chicken.scm",(void*)f_4122},
{"f_4082chicken.scm",(void*)f_4082},
{"f_4078chicken.scm",(void*)f_4078},
{"f_4013chicken.scm",(void*)f_4013},
{"f_1917chicken.scm",(void*)f_1917},
{"f_3827chicken.scm",(void*)f_3827},
{"f_3831chicken.scm",(void*)f_3831},
{"f_3834chicken.scm",(void*)f_3834},
{"f_3837chicken.scm",(void*)f_3837},
{"f_3840chicken.scm",(void*)f_3840},
{"f_3843chicken.scm",(void*)f_3843},
{"f_3852chicken.scm",(void*)f_3852},
{"f_3955chicken.scm",(void*)f_3955},
{"f_3983chicken.scm",(void*)f_3983},
{"f_3977chicken.scm",(void*)f_3977},
{"f_3958chicken.scm",(void*)f_3958},
{"f_3862chicken.scm",(void*)f_3862},
{"f_3865chicken.scm",(void*)f_3865},
{"f_3937chicken.scm",(void*)f_3937},
{"f_3914chicken.scm",(void*)f_3914},
{"f_3871chicken.scm",(void*)f_3871},
{"f_3882chicken.scm",(void*)f_3882},
{"f_3902chicken.scm",(void*)f_3902},
{"f_3825chicken.scm",(void*)f_3825},
{"f_1920chicken.scm",(void*)f_1920},
{"f_3608chicken.scm",(void*)f_3608},
{"f_3612chicken.scm",(void*)f_3612},
{"f_3615chicken.scm",(void*)f_3615},
{"f_3618chicken.scm",(void*)f_3618},
{"f_3621chicken.scm",(void*)f_3621},
{"f_3624chicken.scm",(void*)f_3624},
{"f_3633chicken.scm",(void*)f_3633},
{"f_3752chicken.scm",(void*)f_3752},
{"f_3780chicken.scm",(void*)f_3780},
{"f_3813chicken.scm",(void*)f_3813},
{"f_3786chicken.scm",(void*)f_3786},
{"f_3774chicken.scm",(void*)f_3774},
{"f_3755chicken.scm",(void*)f_3755},
{"f_3643chicken.scm",(void*)f_3643},
{"f_3646chicken.scm",(void*)f_3646},
{"f_3742chicken.scm",(void*)f_3742},
{"f_3707chicken.scm",(void*)f_3707},
{"f_3652chicken.scm",(void*)f_3652},
{"f_3675chicken.scm",(void*)f_3675},
{"f_3695chicken.scm",(void*)f_3695},
{"f_3606chicken.scm",(void*)f_3606},
{"f_1923chicken.scm",(void*)f_1923},
{"f_3331chicken.scm",(void*)f_3331},
{"f_3335chicken.scm",(void*)f_3335},
{"f_3338chicken.scm",(void*)f_3338},
{"f_3341chicken.scm",(void*)f_3341},
{"f_3344chicken.scm",(void*)f_3344},
{"f_3347chicken.scm",(void*)f_3347},
{"f_3350chicken.scm",(void*)f_3350},
{"f_3359chicken.scm",(void*)f_3359},
{"f_3505chicken.scm",(void*)f_3505},
{"f_3508chicken.scm",(void*)f_3508},
{"f_3517chicken.scm",(void*)f_3517},
{"f_3542chicken.scm",(void*)f_3542},
{"f_3567chicken.scm",(void*)f_3567},
{"f_3589chicken.scm",(void*)f_3589},
{"f_3582chicken.scm",(void*)f_3582},
{"f_3574chicken.scm",(void*)f_3574},
{"f_3561chicken.scm",(void*)f_3561},
{"f_3557chicken.scm",(void*)f_3557},
{"f_3536chicken.scm",(void*)f_3536},
{"f_3532chicken.scm",(void*)f_3532},
{"f_3499chicken.scm",(void*)f_3499},
{"f_3369chicken.scm",(void*)f_3369},
{"f_3376chicken.scm",(void*)f_3376},
{"f_3484chicken.scm",(void*)f_3484},
{"f_3472chicken.scm",(void*)f_3472},
{"f_3468chicken.scm",(void*)f_3468},
{"f_3404chicken.scm",(void*)f_3404},
{"f_3432chicken.scm",(void*)f_3432},
{"f_3444chicken.scm",(void*)f_3444},
{"f_3428chicken.scm",(void*)f_3428},
{"f_3329chicken.scm",(void*)f_3329},
{"f_1926chicken.scm",(void*)f_1926},
{"f_3227chicken.scm",(void*)f_3227},
{"f_3231chicken.scm",(void*)f_3231},
{"f_3237chicken.scm",(void*)f_3237},
{"f_3321chicken.scm",(void*)f_3321},
{"f_3282chicken.scm",(void*)f_3282},
{"f_3294chicken.scm",(void*)f_3294},
{"f_3225chicken.scm",(void*)f_3225},
{"f_1929chicken.scm",(void*)f_1929},
{"f_3119chicken.scm",(void*)f_3119},
{"f_3123chicken.scm",(void*)f_3123},
{"f_3197chicken.scm",(void*)f_3197},
{"f_3209chicken.scm",(void*)f_3209},
{"f_3138chicken.scm",(void*)f_3138},
{"f_3184chicken.scm",(void*)f_3184},
{"f_3141chicken.scm",(void*)f_3141},
{"f_3144chicken.scm",(void*)f_3144},
{"f_3154chicken.scm",(void*)f_3154},
{"f_3117chicken.scm",(void*)f_3117},
{"f_1932chicken.scm",(void*)f_1932},
{"f_3094chicken.scm",(void*)f_3094},
{"f_3098chicken.scm",(void*)f_3098},
{"f_3092chicken.scm",(void*)f_3092},
{"f_1935chicken.scm",(void*)f_1935},
{"f_3084chicken.scm",(void*)f_3084},
{"f_3082chicken.scm",(void*)f_3082},
{"f_1938chicken.scm",(void*)f_1938},
{"f_1941chicken.scm",(void*)f_1941},
{"f_1944chicken.scm",(void*)f_1944},
{"f_1948chicken.scm",(void*)f_1948},
{"f_2782chicken.scm",(void*)f_2782},
{"f_2789chicken.scm",(void*)f_2789},
{"f_2792chicken.scm",(void*)f_2792},
{"f_2795chicken.scm",(void*)f_2795},
{"f_2900chicken.scm",(void*)f_2900},
{"f_2913chicken.scm",(void*)f_2913},
{"f_3011chicken.scm",(void*)f_3011},
{"f_3009chicken.scm",(void*)f_3009},
{"f_2973chicken.scm",(void*)f_2973},
{"f_2997chicken.scm",(void*)f_2997},
{"f_2981chicken.scm",(void*)f_2981},
{"f_2985chicken.scm",(void*)f_2985},
{"f_2801chicken.scm",(void*)f_2801},
{"f_2811chicken.scm",(void*)f_2811},
{"f_2885chicken.scm",(void*)f_2885},
{"f_2865chicken.scm",(void*)f_2865},
{"f_2835chicken.scm",(void*)f_2835},
{"f_2831chicken.scm",(void*)f_2831},
{"f_2780chicken.scm",(void*)f_2780},
{"f_1951chicken.scm",(void*)f_1951},
{"f_2641chicken.scm",(void*)f_2641},
{"f_2645chicken.scm",(void*)f_2645},
{"f_2657chicken.scm",(void*)f_2657},
{"f_2757chicken.scm",(void*)f_2757},
{"f_2660chicken.scm",(void*)f_2660},
{"f_2667chicken.scm",(void*)f_2667},
{"f_2737chicken.scm",(void*)f_2737},
{"f_2753chicken.scm",(void*)f_2753},
{"f_2717chicken.scm",(void*)f_2717},
{"f_2691chicken.scm",(void*)f_2691},
{"f_2687chicken.scm",(void*)f_2687},
{"f_2639chicken.scm",(void*)f_2639},
{"f_1954chicken.scm",(void*)f_1954},
{"f_2491chicken.scm",(void*)f_2491},
{"f_2495chicken.scm",(void*)f_2495},
{"f_2504chicken.scm",(void*)f_2504},
{"f_2627chicken.scm",(void*)f_2627},
{"f_2635chicken.scm",(void*)f_2635},
{"f_2507chicken.scm",(void*)f_2507},
{"f_2603chicken.scm",(void*)f_2603},
{"f_2518chicken.scm",(void*)f_2518},
{"f_2601chicken.scm",(void*)f_2601},
{"f_2528chicken.scm",(void*)f_2528},
{"f_2526chicken.scm",(void*)f_2526},
{"f_2489chicken.scm",(void*)f_2489},
{"f_1957chicken.scm",(void*)f_1957},
{"f_2423chicken.scm",(void*)f_2423},
{"f_2427chicken.scm",(void*)f_2427},
{"f_2430chicken.scm",(void*)f_2430},
{"f_2437chicken.scm",(void*)f_2437},
{"f_2461chicken.scm",(void*)f_2461},
{"f_2481chicken.scm",(void*)f_2481},
{"f_2477chicken.scm",(void*)f_2477},
{"f_2421chicken.scm",(void*)f_2421},
{"f_1960chicken.scm",(void*)f_1960},
{"f_2367chicken.scm",(void*)f_2367},
{"f_2371chicken.scm",(void*)f_2371},
{"f_2374chicken.scm",(void*)f_2374},
{"f_2381chicken.scm",(void*)f_2381},
{"f_2397chicken.scm",(void*)f_2397},
{"f_2365chicken.scm",(void*)f_2365},
{"f_1963chicken.scm",(void*)f_1963},
{"f_2338chicken.scm",(void*)f_2338},
{"f_2342chicken.scm",(void*)f_2342},
{"f_2357chicken.scm",(void*)f_2357},
{"f_2336chicken.scm",(void*)f_2336},
{"f_1966chicken.scm",(void*)f_1966},
{"f_1969chicken.scm",(void*)f_1969},
{"f_2329chicken.scm",(void*)f_2329},
{"f_2325chicken.scm",(void*)f_2325},
{"f_2317chicken.scm",(void*)f_2317},
{"f_2307chicken.scm",(void*)f_2307},
{"f_2315chicken.scm",(void*)f_2315},
{"f_1973chicken.scm",(void*)f_1973},
{"f_2102chicken.scm",(void*)f_2102},
{"f_2114chicken.scm",(void*)f_2114},
{"f_2297chicken.scm",(void*)f_2297},
{"f_2290chicken.scm",(void*)f_2290},
{"f_2253chicken.scm",(void*)f_2253},
{"f_2199chicken.scm",(void*)f_2199},
{"f_2216chicken.scm",(void*)f_2216},
{"f_2202chicken.scm",(void*)f_2202},
{"f_2136chicken.scm",(void*)f_2136},
{"f_2179chicken.scm",(void*)f_2179},
{"f_2159chicken.scm",(void*)f_2159},
{"f_2139chicken.scm",(void*)f_2139},
{"f_2106chicken.scm",(void*)f_2106},
{"f_2109chicken.scm",(void*)f_2109},
{"f_2090chicken.scm",(void*)f_2090},
{"f_2097chicken.scm",(void*)f_2097},
{"f_2082chicken.scm",(void*)f_2082},
{"f_2088chicken.scm",(void*)f_2088},
{"f_2085chicken.scm",(void*)f_2085},
{"f_1975chicken.scm",(void*)f_1975},
{"f_1981chicken.scm",(void*)f_1981},
{"f_2016chicken.scm",(void*)f_2016},
{"f_2042chicken.scm",(void*)f_2042},
{"f_2038chicken.scm",(void*)f_2038},
{"f_1995chicken.scm",(void*)f_1995},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
