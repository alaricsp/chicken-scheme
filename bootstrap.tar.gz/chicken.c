/* Generated from chicken.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-08-25 23:21
   Version 4.0.0x - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11761	compiled 2008-08-25 on tesseract.thetesseract.org (Linux)
   command line: chicken.scm -optimize-level 2 -include-path . -include-path . -no-lambda-info -extend private-namespace.scm -output-file chicken.c
   used units: library eval data_structures ports extras srfi_69 srfi_1 srfi_4 utils files support compiler optimizer driver platform backend srfi_69
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_4_toplevel)
C_externimport void C_ccall C_srfi_4_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_support_toplevel)
C_externimport void C_ccall C_support_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_compiler_toplevel)
C_externimport void C_ccall C_compiler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_optimizer_toplevel)
C_externimport void C_ccall C_optimizer_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_driver_toplevel)
C_externimport void C_ccall C_driver_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_platform_toplevel)
C_externimport void C_ccall C_platform_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_backend_toplevel)
C_externimport void C_ccall C_backend_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[310];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1843)
static void C_ccall f_1843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1849)
static void C_ccall f_1849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1855)
static void C_ccall f_1855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1861)
static void C_ccall f_1861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1864)
static void C_ccall f_1864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1867)
static void C_ccall f_1867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1873)
static void C_ccall f_1873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1876)
static void C_ccall f_1876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1879)
static void C_ccall f_1879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1882)
static void C_ccall f_1882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1885)
static void C_ccall f_1885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1888)
static void C_ccall f_1888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1891)
static void C_ccall f_1891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1898)
static void C_ccall f_1898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9090)
static void C_ccall f_9090(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9094)
static void C_ccall f_9094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9103)
static void C_ccall f_9103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9109)
static void C_ccall f_9109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9112)
static void C_ccall f_9112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9115)
static void C_ccall f_9115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9118)
static void C_ccall f_9118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9528)
static void C_ccall f_9528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9488)
static void C_ccall f_9488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9520)
static void C_ccall f_9520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9480)
static void C_ccall f_9480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9436)
static void C_ccall f_9436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9147)
static void C_fcall f_9147(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9157)
static void C_ccall f_9157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9424)
static void C_ccall f_9424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9160)
static void C_ccall f_9160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9420)
static void C_ccall f_9420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9163)
static void C_ccall f_9163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9210)
static void C_fcall f_9210(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9174)
static void C_ccall f_9174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9145)
static void C_ccall f_9145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9141)
static void C_ccall f_9141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9088)
static void C_ccall f_9088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1901)
static void C_ccall f_1901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8947)
static void C_ccall f_8947(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8951)
static void C_ccall f_8951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8954)
static void C_ccall f_8954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8957)
static void C_ccall f_8957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8993)
static void C_ccall f_8993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9008)
static void C_fcall f_9008(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9062)
static void C_ccall f_9062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9023)
static void C_ccall f_9023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8986)
static void C_ccall f_8986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8945)
static void C_ccall f_8945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1904)
static void C_ccall f_1904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8848)
static void C_ccall f_8848(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8852)
static void C_ccall f_8852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8855)
static void C_ccall f_8855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8858)
static void C_ccall f_8858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8937)
static void C_ccall f_8937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8846)
static void C_ccall f_8846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1907)
static void C_ccall f_1907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8830)
static void C_ccall f_8830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8838)
static void C_ccall f_8838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8828)
static void C_ccall f_8828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1910)
static void C_ccall f_1910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8741)
static void C_ccall f_8741(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8745)
static void C_ccall f_8745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8748)
static void C_ccall f_8748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8751)
static void C_ccall f_8751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8817)
static void C_ccall f_8817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8754)
static void C_ccall f_8754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8767)
static void C_ccall f_8767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8811)
static void C_ccall f_8811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8778)
static void C_ccall f_8778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8786)
static void C_ccall f_8786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8788)
static void C_fcall f_8788(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8805)
static void C_ccall f_8805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8773)
static void C_ccall f_8773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8765)
static void C_ccall f_8765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8761)
static void C_ccall f_8761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8739)
static void C_ccall f_8739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1913)
static void C_ccall f_1913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8630)
static void C_ccall f_8630(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8634)
static void C_ccall f_8634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8643)
static void C_ccall f_8643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8646)
static void C_ccall f_8646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8649)
static void C_fcall f_8649(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8692)
static void C_ccall f_8692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8628)
static void C_ccall f_8628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1916)
static void C_ccall f_1916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8493)
static void C_ccall f_8493(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8497)
static void C_ccall f_8497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8509)
static void C_ccall f_8509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8512)
static void C_ccall f_8512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8515)
static void C_ccall f_8515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8566)
static void C_fcall f_8566(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8562)
static void C_ccall f_8562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8491)
static void C_ccall f_8491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1919)
static void C_ccall f_1919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8235)
static void C_ccall f_8235(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8239)
static void C_ccall f_8239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8248)
static void C_ccall f_8248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8479)
static void C_ccall f_8479(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8487)
static void C_ccall f_8487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8251)
static void C_ccall f_8251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8469)
static void C_ccall f_8469(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8477)
static void C_ccall f_8477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8254)
static void C_ccall f_8254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8257)
static void C_ccall f_8257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8260)
static void C_ccall f_8260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8467)
static void C_ccall f_8467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8427)
static void C_ccall f_8427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8445)
static void C_fcall f_8445(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8459)
static void C_ccall f_8459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8439)
static void C_ccall f_8439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8435)
static void C_ccall f_8435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8431)
static void C_ccall f_8431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8271)
static void C_ccall f_8271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8411)
static void C_ccall f_8411(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8379)
static void C_ccall f_8379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8397)
static void C_ccall f_8397(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8387)
static void C_ccall f_8387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8383)
static void C_ccall f_8383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8375)
static void C_ccall f_8375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8367)
static void C_ccall f_8367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8347)
static void C_ccall f_8347(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8315)
static void C_ccall f_8315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8333)
static void C_ccall f_8333(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8323)
static void C_ccall f_8323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8319)
static void C_ccall f_8319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8311)
static void C_ccall f_8311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8233)
static void C_ccall f_8233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1922)
static void C_ccall f_1922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8114)
static void C_ccall f_8114(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8118)
static void C_ccall f_8118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8124)
static void C_ccall f_8124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8225)
static void C_ccall f_8225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8130)
static void C_ccall f_8130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8133)
static void C_ccall f_8133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8136)
static void C_ccall f_8136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8176)
static void C_fcall f_8176(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8199)
static void C_ccall f_8199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8206)
static void C_ccall f_8206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8213)
static void C_ccall f_8213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8189)
static void C_ccall f_8189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8139)
static void C_ccall f_8139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8112)
static void C_ccall f_8112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1925)
static void C_ccall f_1925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7912)
static void C_ccall f_7912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7916)
static void C_ccall f_7916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7925)
static void C_ccall f_7925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7928)
static void C_ccall f_7928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7931)
static void C_ccall f_7931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7934)
static void C_ccall f_7934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7937)
static void C_ccall f_7937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8100)
static void C_ccall f_8100(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8108)
static void C_ccall f_8108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7940)
static void C_ccall f_7940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8090)
static void C_ccall f_8090(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8098)
static void C_ccall f_8098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7943)
static void C_ccall f_7943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8084)
static void C_ccall f_8084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8088)
static void C_ccall f_8088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7954)
static void C_ccall f_7954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8028)
static void C_ccall f_8028(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8026)
static void C_ccall f_8026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8022)
static void C_ccall f_8022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8002)
static void C_ccall f_8002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7910)
static void C_ccall f_7910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7867)
static void C_ccall f_7867(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7871)
static void C_ccall f_7871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7878)
static void C_ccall f_7878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7898)
static void C_ccall f_7898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7902)
static void C_ccall f_7902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7865)
static void C_ccall f_7865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1931)
static void C_ccall f_1931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7814)
static void C_ccall f_7814(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7818)
static void C_ccall f_7818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7825)
static void C_ccall f_7825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7853)
static void C_ccall f_7853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7857)
static void C_ccall f_7857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7812)
static void C_ccall f_7812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1934)
static void C_ccall f_1934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7669)
static void C_ccall f_7669(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7673)
static void C_ccall f_7673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7682)
static void C_ccall f_7682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7751)
static void C_ccall f_7751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7784)
static void C_ccall f_7784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7782)
static void C_ccall f_7782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7778)
static void C_ccall f_7778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7667)
static void C_ccall f_7667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1937)
static void C_ccall f_1937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7627)
static void C_ccall f_7627(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7631)
static void C_ccall f_7631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7651)
static void C_ccall f_7651(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7659)
static void C_ccall f_7659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7634)
static void C_ccall f_7634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7641)
static void C_ccall f_7641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7645)
static void C_ccall f_7645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7625)
static void C_ccall f_7625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7239)
static void C_ccall f_7239(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7243)
static void C_ccall f_7243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7252)
static void C_ccall f_7252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7255)
static void C_ccall f_7255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7330)
static void C_ccall f_7330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7583)
static void C_fcall f_7583(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7596)
static void C_ccall f_7596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7333)
static void C_ccall f_7333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7569)
static void C_ccall f_7569(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7581)
static void C_ccall f_7581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7577)
static void C_ccall f_7577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7336)
static void C_ccall f_7336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7523)
static void C_fcall f_7523(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7556)
static void C_ccall f_7556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7563)
static void C_ccall f_7563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7539)
static void C_fcall f_7539(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7348)
static void C_ccall f_7348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7517)
static void C_ccall f_7517(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7355)
static void C_ccall f_7355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7357)
static void C_fcall f_7357(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7511)
static void C_ccall f_7511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7395)
static void C_fcall f_7395(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7477)
static void C_ccall f_7477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7434)
static void C_ccall f_7434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7414)
static void C_ccall f_7414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7381)
static void C_ccall f_7381(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7389)
static void C_ccall f_7389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7375)
static void C_ccall f_7375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7379)
static void C_ccall f_7379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7337)
static void C_ccall f_7337(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7288)
static void C_fcall f_7288(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7311)
static void C_ccall f_7311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7315)
static void C_ccall f_7315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7257)
static void C_fcall f_7257(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7278)
static void C_ccall f_7278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7237)
static void C_ccall f_7237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1943)
static void C_ccall f_1943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7167)
static void C_ccall f_7167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7171)
static void C_ccall f_7171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7180)
static void C_ccall f_7180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7183)
static void C_ccall f_7183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7188)
static void C_fcall f_7188(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7225)
static void C_ccall f_7225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7206)
static void C_ccall f_7206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7165)
static void C_ccall f_7165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1946)
static void C_ccall f_1946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7001)
static void C_ccall f_7001(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7005)
static void C_ccall f_7005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7014)
static void C_ccall f_7014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7017)
static void C_ccall f_7017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7157)
static void C_ccall f_7157(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7155)
static void C_ccall f_7155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7020)
static void C_ccall f_7020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7139)
static void C_ccall f_7139(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7151)
static void C_ccall f_7151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7147)
static void C_ccall f_7147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7023)
static void C_ccall f_7023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7133)
static void C_ccall f_7133(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7043)
static void C_ccall f_7043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7057)
static void C_ccall f_7057(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7085)
static void C_ccall f_7085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7095)
static void C_ccall f_7095(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7111)
static void C_ccall f_7111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7093)
static void C_ccall f_7093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7089)
static void C_ccall f_7089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7051)
static void C_ccall f_7051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7055)
static void C_ccall f_7055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7047)
static void C_ccall f_7047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7024)
static void C_ccall f_7024(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6999)
static void C_ccall f_6999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1949)
static void C_ccall f_1949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6927)
static void C_ccall f_6927(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6931)
static void C_ccall f_6931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6934)
static void C_ccall f_6934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6937)
static void C_ccall f_6937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6940)
static void C_ccall f_6940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6925)
static void C_ccall f_6925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1952)
static void C_ccall f_1952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6826)
static void C_ccall f_6826(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6830)
static void C_ccall f_6830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6917)
static void C_ccall f_6917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6913)
static void C_ccall f_6913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6832)
static void C_fcall f_6832(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6836)
static void C_ccall f_6836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6893)
static void C_ccall f_6893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6845)
static void C_fcall f_6845(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6867)
static void C_ccall f_6867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6857)
static void C_fcall f_6857(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6848)
static void C_ccall f_6848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6824)
static void C_ccall f_6824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1955)
static void C_ccall f_1955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6663)
static void C_ccall f_6663(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6667)
static void C_ccall f_6667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6676)
static void C_ccall f_6676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6679)
static void C_ccall f_6679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6684)
static void C_fcall f_6684(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6729)
static void C_ccall f_6729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6796)
static void C_ccall f_6796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6758)
static void C_ccall f_6758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6698)
static void C_ccall f_6698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6702)
static void C_ccall f_6702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6661)
static void C_ccall f_6661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1958)
static void C_ccall f_1958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6494)
static void C_ccall f_6494(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6498)
static void C_ccall f_6498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6507)
static void C_ccall f_6507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6510)
static void C_ccall f_6510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6513)
static void C_ccall f_6513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6516)
static void C_ccall f_6516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6519)
static void C_ccall f_6519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6522)
static void C_ccall f_6522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6529)
static void C_ccall f_6529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6547)
static void C_fcall f_6547(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6563)
static void C_ccall f_6563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6569)
static void C_ccall f_6569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6625)
static void C_ccall f_6625(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6623)
static void C_ccall f_6623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6619)
static void C_ccall f_6619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6611)
static void C_ccall f_6611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6607)
static void C_ccall f_6607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6576)
static void C_ccall f_6576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6545)
static void C_ccall f_6545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6492)
static void C_ccall f_6492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1961)
static void C_ccall f_1961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6062)
static void C_ccall f_6062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6066)
static void C_ccall f_6066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6078)
static void C_ccall f_6078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6081)
static void C_ccall f_6081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6084)
static void C_ccall f_6084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6087)
static void C_ccall f_6087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6090)
static void C_ccall f_6090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6093)
static void C_ccall f_6093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6381)
static void C_ccall f_6381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6384)
static void C_ccall f_6384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6387)
static void C_ccall f_6387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6480)
static void C_ccall f_6480(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6488)
static void C_ccall f_6488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6403)
static void C_ccall f_6403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6406)
static void C_ccall f_6406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6409)
static void C_ccall f_6409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6412)
static void C_ccall f_6412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6470)
static void C_ccall f_6470(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6478)
static void C_ccall f_6478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6415)
static void C_ccall f_6415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6418)
static void C_ccall f_6418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6421)
static void C_ccall f_6421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6428)
static void C_ccall f_6428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6388)
static void C_fcall f_6388(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6400)
static void C_ccall f_6400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6396)
static void C_ccall f_6396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6192)
static void C_fcall f_6192(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6198)
static void C_fcall f_6198(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6374)
static void C_ccall f_6374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6318)
static void C_ccall f_6318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6260)
static void C_ccall f_6260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6095)
static void C_fcall f_6095(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6103)
static void C_ccall f_6103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6107)
static void C_ccall f_6107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6111)
static void C_ccall f_6111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6113)
static void C_fcall f_6113(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6166)
static void C_ccall f_6166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6182)
static void C_ccall f_6182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6178)
static void C_ccall f_6178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6134)
static void C_ccall f_6134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6060)
static void C_ccall f_6060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1964)
static void C_ccall f_1964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5878)
static void C_ccall f_5878(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5882)
static void C_ccall f_5882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5885)
static void C_ccall f_5885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5888)
static void C_ccall f_5888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5891)
static void C_ccall f_5891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5898)
static void C_ccall f_5898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5933)
static void C_ccall f_5933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6017)
static void C_ccall f_6017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5993)
static void C_ccall f_5993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5876)
static void C_ccall f_5876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1967)
static void C_ccall f_1967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5576)
static void C_ccall f_5576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5580)
static void C_ccall f_5580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5592)
static void C_ccall f_5592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5595)
static void C_ccall f_5595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5598)
static void C_ccall f_5598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5601)
static void C_ccall f_5601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5604)
static void C_ccall f_5604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5607)
static void C_ccall f_5607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5628)
static void C_fcall f_5628(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5856)
static void C_ccall f_5856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5718)
static void C_ccall f_5718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5737)
static void C_ccall f_5737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5694)
static void C_ccall f_5694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5626)
static void C_ccall f_5626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5574)
static void C_ccall f_5574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5155)
static void C_ccall f_5155(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5159)
static void C_ccall f_5159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5196)
static void C_ccall f_5196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5555)
static void C_ccall f_5555(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5565)
static void C_ccall f_5565(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5553)
static void C_ccall f_5553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5199)
static void C_ccall f_5199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5202)
static void C_ccall f_5202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5205)
static void C_ccall f_5205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5208)
static void C_ccall f_5208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5211)
static void C_ccall f_5211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5214)
static void C_ccall f_5214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5217)
static void C_ccall f_5217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5228)
static void C_ccall f_5228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5254)
static void C_ccall f_5254(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5264)
static void C_ccall f_5264(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5268)
static void C_ccall f_5268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5517)
static void C_ccall f_5517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5502)
static void C_ccall f_5502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5282)
static void C_fcall f_5282(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5306)
static void C_ccall f_5306(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5333)
static void C_fcall f_5333(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5489)
static void C_ccall f_5489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5401)
static void C_ccall f_5401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5481)
static void C_ccall f_5481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5461)
static void C_ccall f_5461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5420)
static void C_ccall f_5420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5390)
static void C_ccall f_5390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5358)
static void C_ccall f_5358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5310)
static void C_ccall f_5310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5327)
static void C_ccall f_5327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5296)
static void C_ccall f_5296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5304)
static void C_ccall f_5304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5290)
static void C_ccall f_5290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5252)
static void C_ccall f_5252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5161)
static void C_fcall f_5161(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5167)
static void C_fcall f_5167(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5193)
static void C_ccall f_5193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5181)
static void C_ccall f_5181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5185)
static void C_ccall f_5185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5153)
static void C_ccall f_5153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5057)
static void C_ccall f_5057(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5061)
static void C_ccall f_5061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5126)
static void C_ccall f_5126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5141)
static void C_ccall f_5141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5076)
static void C_ccall f_5076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5099)
static void C_ccall f_5099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5111)
static void C_ccall f_5111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5055)
static void C_ccall f_5055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1976)
static void C_ccall f_1976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4863)
static void C_ccall f_4863(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4867)
static void C_ccall f_4867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4870)
static void C_ccall f_4870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4873)
static void C_ccall f_4873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4876)
static void C_ccall f_4876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4887)
static void C_ccall f_4887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4915)
static void C_ccall f_4915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5007)
static void C_ccall f_5007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4861)
static void C_ccall f_4861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1979)
static void C_ccall f_1979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4536)
static void C_ccall f_4536(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4540)
static void C_ccall f_4540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4543)
static void C_ccall f_4543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4546)
static void C_ccall f_4546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4549)
static void C_ccall f_4549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4552)
static void C_ccall f_4552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4555)
static void C_ccall f_4555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4558)
static void C_ccall f_4558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4733)
static void C_ccall f_4733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4773)
static void C_ccall f_4773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4781)
static void C_ccall f_4781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4777)
static void C_ccall f_4777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4560)
static void C_ccall f_4560(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4684)
static void C_ccall f_4684(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4682)
static void C_ccall f_4682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4678)
static void C_ccall f_4678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4670)
static void C_ccall f_4670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4651)
static void C_ccall f_4651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4636)
static void C_fcall f_4636(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4621)
static void C_ccall f_4621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4602)
static void C_ccall f_4602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4587)
static void C_fcall f_4587(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4534)
static void C_ccall f_4534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1982)
static void C_ccall f_1982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4161)
static void C_ccall f_4161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4165)
static void C_ccall f_4165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4180)
static void C_ccall f_4180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4183)
static void C_ccall f_4183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4186)
static void C_ccall f_4186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4192)
static void C_ccall f_4192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4195)
static void C_ccall f_4195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4201)
static void C_ccall f_4201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4519)
static void C_ccall f_4519(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4517)
static void C_ccall f_4517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4513)
static void C_ccall f_4513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4230)
static void C_fcall f_4230(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4256)
static void C_fcall f_4256(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4296)
static void C_fcall f_4296(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4272)
static void C_ccall f_4272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4268)
static void C_ccall f_4268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4228)
static void C_ccall f_4228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4224)
static void C_ccall f_4224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4159)
static void C_ccall f_4159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1985)
static void C_ccall f_1985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3973)
static void C_ccall f_3973(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3977)
static void C_ccall f_3977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3980)
static void C_ccall f_3980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3983)
static void C_ccall f_3983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3986)
static void C_ccall f_3986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3989)
static void C_ccall f_3989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3998)
static void C_fcall f_3998(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4101)
static void C_ccall f_4101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4129)
static void C_ccall f_4129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4123)
static void C_ccall f_4123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4104)
static void C_ccall f_4104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4008)
static void C_ccall f_4008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4011)
static void C_ccall f_4011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4083)
static void C_ccall f_4083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4060)
static void C_ccall f_4060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4017)
static void C_ccall f_4017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4028)
static void C_ccall f_4028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4048)
static void C_ccall f_4048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3971)
static void C_ccall f_3971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1988)
static void C_ccall f_1988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3754)
static void C_ccall f_3754(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3758)
static void C_ccall f_3758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3761)
static void C_ccall f_3761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3764)
static void C_ccall f_3764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3767)
static void C_ccall f_3767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3770)
static void C_ccall f_3770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3779)
static void C_fcall f_3779(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3898)
static void C_ccall f_3898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3926)
static void C_ccall f_3926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3959)
static void C_ccall f_3959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3932)
static void C_ccall f_3932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3920)
static void C_ccall f_3920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3901)
static void C_ccall f_3901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3789)
static void C_ccall f_3789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3792)
static void C_ccall f_3792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3888)
static void C_ccall f_3888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3853)
static void C_ccall f_3853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3798)
static void C_ccall f_3798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3821)
static void C_ccall f_3821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3841)
static void C_ccall f_3841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3752)
static void C_ccall f_3752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1991)
static void C_ccall f_1991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3477)
static void C_ccall f_3477(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3481)
static void C_ccall f_3481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3484)
static void C_ccall f_3484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3487)
static void C_ccall f_3487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3490)
static void C_ccall f_3490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3493)
static void C_ccall f_3493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3496)
static void C_ccall f_3496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3505)
static void C_fcall f_3505(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3651)
static void C_fcall f_3651(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3654)
static void C_ccall f_3654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3663)
static void C_ccall f_3663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3688)
static void C_ccall f_3688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3713)
static void C_ccall f_3713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3735)
static void C_ccall f_3735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3728)
static void C_ccall f_3728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3720)
static void C_ccall f_3720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3707)
static void C_ccall f_3707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3703)
static void C_ccall f_3703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3682)
static void C_ccall f_3682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3678)
static void C_ccall f_3678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3645)
static void C_ccall f_3645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3515)
static void C_fcall f_3515(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3522)
static void C_ccall f_3522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3630)
static void C_ccall f_3630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3618)
static void C_ccall f_3618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3614)
static void C_ccall f_3614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3550)
static void C_ccall f_3550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3578)
static void C_ccall f_3578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3590)
static void C_ccall f_3590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3574)
static void C_ccall f_3574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3475)
static void C_ccall f_3475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1994)
static void C_ccall f_1994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3373)
static void C_ccall f_3373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3377)
static void C_ccall f_3377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3383)
static void C_ccall f_3383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3467)
static void C_ccall f_3467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3428)
static void C_ccall f_3428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3440)
static void C_ccall f_3440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3371)
static void C_ccall f_3371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1997)
static void C_ccall f_1997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3265)
static void C_ccall f_3265(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3269)
static void C_ccall f_3269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3343)
static void C_ccall f_3343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3355)
static void C_ccall f_3355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3284)
static void C_fcall f_3284(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3330)
static void C_ccall f_3330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3287)
static void C_ccall f_3287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3290)
static void C_ccall f_3290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3300)
static void C_ccall f_3300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3263)
static void C_ccall f_3263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2000)
static void C_ccall f_2000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3240)
static void C_ccall f_3240(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3244)
static void C_ccall f_3244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3238)
static void C_ccall f_3238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2003)
static void C_ccall f_2003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3230)
static void C_ccall f_3230(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3228)
static void C_ccall f_3228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2006)
static void C_ccall f_2006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2009)
static void C_ccall f_2009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2012)
static void C_ccall f_2012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2016)
static void C_ccall f_2016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2928)
static void C_ccall f_2928(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2935)
static void C_ccall f_2935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2938)
static void C_fcall f_2938(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2941)
static void C_fcall f_2941(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3059)
static void C_ccall f_3059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3157)
static void C_ccall f_3157(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3155)
static void C_ccall f_3155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3143)
static void C_ccall f_3143(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3127)
static void C_ccall f_3127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3131)
static void C_ccall f_3131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2947)
static void C_ccall f_2947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2957)
static void C_ccall f_2957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3031)
static void C_ccall f_3031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3011)
static void C_ccall f_3011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2981)
static void C_fcall f_2981(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2977)
static void C_ccall f_2977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2926)
static void C_ccall f_2926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2787)
static void C_ccall f_2787(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2791)
static void C_ccall f_2791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2803)
static void C_ccall f_2803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2903)
static void C_ccall f_2903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2806)
static void C_ccall f_2806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2813)
static void C_ccall f_2813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2883)
static void C_ccall f_2883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2899)
static void C_ccall f_2899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2863)
static void C_ccall f_2863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2837)
static void C_fcall f_2837(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2833)
static void C_ccall f_2833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2785)
static void C_ccall f_2785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2022)
static void C_ccall f_2022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2637)
static void C_ccall f_2637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2641)
static void C_ccall f_2641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2773)
static void C_ccall f_2773(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2781)
static void C_ccall f_2781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2653)
static void C_ccall f_2653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2749)
static void C_ccall f_2749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2664)
static void C_ccall f_2664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2747)
static void C_ccall f_2747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2674)
static void C_ccall f_2674(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2672)
static void C_ccall f_2672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2635)
static void C_ccall f_2635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2025)
static void C_ccall f_2025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2569)
static void C_ccall f_2569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2573)
static void C_ccall f_2573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2576)
static void C_ccall f_2576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2583)
static void C_ccall f_2583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2607)
static void C_ccall f_2607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2627)
static void C_ccall f_2627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2623)
static void C_ccall f_2623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2567)
static void C_ccall f_2567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2028)
static void C_ccall f_2028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2513)
static void C_ccall f_2513(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2517)
static void C_ccall f_2517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2520)
static void C_ccall f_2520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2527)
static void C_ccall f_2527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2543)
static void C_ccall f_2543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2511)
static void C_ccall f_2511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2031)
static void C_ccall f_2031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2484)
static void C_ccall f_2484(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2488)
static void C_ccall f_2488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2503)
static void C_ccall f_2503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2482)
static void C_ccall f_2482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2034)
static void C_ccall f_2034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2409)
static void C_ccall f_2409(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2413)
static void C_ccall f_2413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2431)
static void C_fcall f_2431(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2457)
static void C_ccall f_2457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2428)
static void C_ccall f_2428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2421)
static void C_fcall f_2421(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2407)
static void C_ccall f_2407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2037)
static void C_ccall f_2037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2040)
static void C_ccall f_2040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2403)
static void C_ccall f_2403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2396)
static void C_ccall f_2396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2392)
static void C_ccall f_2392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2384)
static void C_ccall f_2384(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2382)
static void C_ccall f_2382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2044)
static void C_ccall f_2044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2173)
static void C_ccall f_2173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2185)
static void C_fcall f_2185(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2361)
static void C_ccall f_2361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2324)
static void C_ccall f_2324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2270)
static void C_ccall f_2270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2287)
static void C_ccall f_2287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2273)
static void C_ccall f_2273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2207)
static void C_ccall f_2207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2250)
static void C_ccall f_2250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2230)
static void C_ccall f_2230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2210)
static void C_ccall f_2210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2177)
static void C_ccall f_2177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2180)
static void C_ccall f_2180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2161)
static void C_ccall f_2161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2153)
static void C_ccall f_2153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2159)
static void C_ccall f_2159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2156)
static void C_ccall f_2156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2046)
static void C_ccall f_2046(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2052)
static void C_fcall f_2052(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2087)
static void C_fcall f_2087(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2113)
static void C_ccall f_2113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2109)
static void C_ccall f_2109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2066)
static void C_ccall f_2066(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_9147)
static void C_fcall trf_9147(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9147(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9147(t0,t1,t2,t3);}

C_noret_decl(trf_9210)
static void C_fcall trf_9210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9210(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9210(t0,t1);}

C_noret_decl(trf_9008)
static void C_fcall trf_9008(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9008(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9008(t0,t1);}

C_noret_decl(trf_8788)
static void C_fcall trf_8788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8788(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8788(t0,t1,t2,t3);}

C_noret_decl(trf_8649)
static void C_fcall trf_8649(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8649(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8649(t0,t1);}

C_noret_decl(trf_8566)
static void C_fcall trf_8566(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8566(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8566(t0,t1);}

C_noret_decl(trf_8445)
static void C_fcall trf_8445(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8445(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8445(t0,t1,t2);}

C_noret_decl(trf_8176)
static void C_fcall trf_8176(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8176(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8176(t0,t1,t2);}

C_noret_decl(trf_7583)
static void C_fcall trf_7583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7583(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7583(t0,t1,t2,t3);}

C_noret_decl(trf_7523)
static void C_fcall trf_7523(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7523(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7523(t0,t1,t2,t3);}

C_noret_decl(trf_7539)
static void C_fcall trf_7539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7539(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7539(t0,t1);}

C_noret_decl(trf_7357)
static void C_fcall trf_7357(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7357(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7357(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7395)
static void C_fcall trf_7395(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7395(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7395(t0,t1);}

C_noret_decl(trf_7288)
static void C_fcall trf_7288(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7288(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7288(t0,t1,t2,t3);}

C_noret_decl(trf_7257)
static void C_fcall trf_7257(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7257(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7257(t0,t1,t2,t3);}

C_noret_decl(trf_7188)
static void C_fcall trf_7188(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7188(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7188(t0,t1,t2);}

C_noret_decl(trf_6832)
static void C_fcall trf_6832(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6832(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6832(t0,t1,t2,t3);}

C_noret_decl(trf_6845)
static void C_fcall trf_6845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6845(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6845(t0,t1);}

C_noret_decl(trf_6857)
static void C_fcall trf_6857(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6857(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6857(t0,t1);}

C_noret_decl(trf_6684)
static void C_fcall trf_6684(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6684(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6684(t0,t1,t2);}

C_noret_decl(trf_6547)
static void C_fcall trf_6547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6547(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6547(t0,t1,t2);}

C_noret_decl(trf_6388)
static void C_fcall trf_6388(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6388(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6388(t0,t1,t2);}

C_noret_decl(trf_6192)
static void C_fcall trf_6192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6192(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6192(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6198)
static void C_fcall trf_6198(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6198(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6198(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6095)
static void C_fcall trf_6095(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6095(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6095(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6113)
static void C_fcall trf_6113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6113(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6113(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5628)
static void C_fcall trf_5628(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5628(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5628(t0,t1,t2,t3);}

C_noret_decl(trf_5282)
static void C_fcall trf_5282(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5282(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5282(t0,t1);}

C_noret_decl(trf_5333)
static void C_fcall trf_5333(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5333(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5333(t0,t1,t2,t3);}

C_noret_decl(trf_5161)
static void C_fcall trf_5161(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5161(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5161(t0,t1,t2);}

C_noret_decl(trf_5167)
static void C_fcall trf_5167(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5167(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5167(t0,t1,t2);}

C_noret_decl(trf_4636)
static void C_fcall trf_4636(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4636(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4636(t0,t1);}

C_noret_decl(trf_4587)
static void C_fcall trf_4587(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4587(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4587(t0,t1);}

C_noret_decl(trf_4230)
static void C_fcall trf_4230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4230(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4230(t0,t1,t2,t3);}

C_noret_decl(trf_4256)
static void C_fcall trf_4256(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4256(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4256(t0,t1);}

C_noret_decl(trf_4296)
static void C_fcall trf_4296(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4296(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4296(t0,t1);}

C_noret_decl(trf_3998)
static void C_fcall trf_3998(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3998(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3998(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3779)
static void C_fcall trf_3779(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3779(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3779(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3505)
static void C_fcall trf_3505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3505(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3505(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3651)
static void C_fcall trf_3651(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3651(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3651(t0,t1);}

C_noret_decl(trf_3515)
static void C_fcall trf_3515(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3515(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3515(t0,t1);}

C_noret_decl(trf_3284)
static void C_fcall trf_3284(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3284(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3284(t0,t1);}

C_noret_decl(trf_2938)
static void C_fcall trf_2938(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2938(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2938(t0,t1);}

C_noret_decl(trf_2941)
static void C_fcall trf_2941(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2941(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2941(t0,t1);}

C_noret_decl(trf_2981)
static void C_fcall trf_2981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2981(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2981(t0,t1);}

C_noret_decl(trf_2837)
static void C_fcall trf_2837(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2837(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2837(t0,t1);}

C_noret_decl(trf_2431)
static void C_fcall trf_2431(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2431(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2431(t0,t1);}

C_noret_decl(trf_2421)
static void C_fcall trf_2421(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2421(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2421(t0,t1);}

C_noret_decl(trf_2185)
static void C_fcall trf_2185(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2185(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2185(t0,t1,t2);}

C_noret_decl(trf_2052)
static void C_fcall trf_2052(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2052(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2052(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2087)
static void C_fcall trf_2087(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2087(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2087(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(4033)){
C_save(t1);
C_rereclaim2(4033*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,310);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],29,"\003syschicken-macro-environment");
lf[3]=C_h_intern(&lf[3],33,"\003syschicken-ffi-macro-environment");
lf[4]=C_h_intern(&lf[4],27,"\010compilercompiler-arguments");
lf[5]=C_h_intern(&lf[5],29,"\010compilerprocess-command-line");
lf[6]=C_h_intern(&lf[6],7,"reverse");
lf[7]=C_h_intern(&lf[7],14,"string->symbol");
lf[8]=C_h_intern(&lf[8],9,"substring");
lf[9]=C_h_intern(&lf[9],25,"\003sysimplicit-exit-handler");
lf[10]=C_h_intern(&lf[10],17,"user-options-pass");
lf[11]=C_h_intern(&lf[11],4,"exit");
lf[12]=C_h_intern(&lf[12],19,"compile-source-file");
lf[13]=C_h_intern(&lf[13],14,"optimize-level");
lf[14]=C_h_intern(&lf[14],5,"cons*");
lf[15]=C_h_intern(&lf[15],22,"optimize-leaf-routines");
lf[16]=C_h_intern(&lf[16],6,"unsafe");
lf[17]=C_h_intern(&lf[17],25,"\010compilercompiler-warning");
lf[18]=C_h_intern(&lf[18],5,"usage");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\047invalid optimization level ~S - ignored");
lf[20]=C_h_intern(&lf[20],11,"debug-level");
lf[21]=C_h_intern(&lf[21],14,"no-lambda-info");
lf[22]=C_h_intern(&lf[22],8,"no-trace");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000 invalid debug level ~S - ignored");
lf[24]=C_h_intern(&lf[24],14,"benchmark-mode");
lf[25]=C_h_intern(&lf[25],17,"fixnum-arithmetic");
lf[26]=C_h_intern(&lf[26],18,"disable-interrupts");
lf[27]=C_h_intern(&lf[27],5,"block");
lf[28]=C_h_intern(&lf[28],11,"lambda-lift");
lf[29]=C_h_intern(&lf[29],31,"\010compilervalid-compiler-options");
lf[30]=C_h_intern(&lf[30],45,"\010compilervalid-compiler-options-with-argument");
lf[31]=C_h_intern(&lf[31],4,"quit");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~s\047 option");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000&invalid compiler option `~a\047 - ignored");
lf[34]=C_h_intern(&lf[34],4,"conc");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[36]=C_h_intern(&lf[36],6,"append");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[38]=C_h_intern(&lf[38],6,"remove");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[40]=C_h_intern(&lf[40],12,"string-split");
lf[41]=C_h_intern(&lf[41],6,"getenv");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\017CHICKEN_OPTIONS");
lf[43]=C_h_intern(&lf[43],4,"argv");
lf[44]=C_h_intern(&lf[44],16,"\003sysmacro-subset");
lf[45]=C_h_intern(&lf[45],28,"\003sysextend-macro-environment");
lf[46]=C_h_intern(&lf[46],21,"define-compiler-macro");
lf[47]=C_h_intern(&lf[47],12,"syntax-error");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000!invalid compiler macro definition");
lf[49]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[50]=C_h_intern(&lf[50],9,"compiling");
lf[51]=C_h_intern(&lf[51],12,"\003sysfeatures");
lf[52]=C_h_intern(&lf[52],7,"warning");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\0004compile macros are not available in interpreted code");
lf[54]=C_h_intern(&lf[54],32,"\010compilerregister-compiler-macro");
lf[55]=C_h_intern(&lf[55],16,"\003syscheck-syntax");
lf[56]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[57]=C_h_intern(&lf[57],18,"\003syser-transformer");
lf[58]=C_h_intern(&lf[58],15,"foreign-declare");
lf[59]=C_h_intern(&lf[59],12,"\004coredeclare");
lf[60]=C_h_intern(&lf[60],10,"\003sysappend");
lf[61]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\000");
lf[62]=C_h_intern(&lf[62],13,"foreign-value");
lf[63]=C_h_intern(&lf[63],23,"define-foreign-variable");
lf[64]=C_h_intern(&lf[64],5,"begin");
lf[65]=C_h_intern(&lf[65],6,"gensym");
lf[66]=C_h_intern(&lf[66],5,"code_");
lf[67]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[68]=C_h_intern(&lf[68],12,"foreign-code");
lf[69]=C_h_intern(&lf[69],11,"\004coreinline");
lf[70]=C_h_intern(&lf[70],7,"sprintf");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\0007static C_word ~A() { ~A\012; return C_SCHEME_UNDEFINED; }\012");
lf[72]=C_h_intern(&lf[72],18,"string-intersperse");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[74]=C_h_intern(&lf[74],7,"declare");
lf[75]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\000");
lf[76]=C_h_intern(&lf[76],12,"let-location");
lf[77]=C_h_intern(&lf[77],17,"\004corelet-location");
lf[78]=C_h_intern(&lf[78],10,"fold-right");
lf[79]=C_h_intern(&lf[79],10,"append-map");
lf[80]=C_h_intern(&lf[80],7,"\003sysmap");
lf[81]=C_h_intern(&lf[81],3,"let");
lf[82]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001\376\377\001\000\000"
"\000\000\376\001\000\000\001_");
lf[83]=C_h_intern(&lf[83],15,"define-location");
lf[84]=C_h_intern(&lf[84],9,"\004coreset!");
lf[85]=C_h_intern(&lf[85],24,"define-external-variable");
lf[86]=C_h_intern(&lf[86],14,"symbol->string");
lf[87]=C_h_intern(&lf[87],9,"\003syserror");
lf[88]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[89]=C_h_intern(&lf[89],15,"define-external");
lf[90]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[91]=C_h_intern(&lf[91],5,"quote");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[93]=C_h_intern(&lf[93],29,"\004coreforeign-callback-wrapper");
lf[94]=C_h_intern(&lf[94],6,"lambda");
lf[95]=C_h_intern(&lf[95],6,"define");
lf[96]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376"
"\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[97]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376"
"\001\000\000\001_\376\377\001\000\000\000\001");
lf[98]=C_h_intern(&lf[98],21,"\003sysmacro-environment");
lf[99]=C_h_intern(&lf[99],17,"register-feature!");
lf[100]=C_h_intern(&lf[100],6,"srfi-8");
lf[101]=C_h_intern(&lf[101],7,"srfi-16");
lf[102]=C_h_intern(&lf[102],7,"srfi-26");
lf[103]=C_h_intern(&lf[103],7,"srfi-31");
lf[104]=C_h_intern(&lf[104],7,"srfi-15");
lf[105]=C_h_intern(&lf[105],7,"srfi-11");
lf[106]=C_h_intern(&lf[106],12,"define-macro");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000<`define-macro\047 is not supported - please use `define-syntax\047");
lf[108]=C_h_intern(&lf[108],3,"use");
lf[109]=C_h_intern(&lf[109],22,"\004corerequire-extension");
lf[110]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[111]=C_h_intern(&lf[111],17,"define-for-syntax");
lf[112]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016\376\377\016");
lf[113]=C_h_intern(&lf[113],25,"\003sysenable-runtime-macros");
lf[114]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[115]=C_h_intern(&lf[115],28,"\003sysregister-meta-expression");
lf[116]=C_h_intern(&lf[116],4,"eval");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\022invalid identifier");
lf[118]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[119]=C_h_intern(&lf[119],3,"rec");
lf[120]=C_h_intern(&lf[120],6,"letrec");
lf[121]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[122]=C_h_intern(&lf[122],16,"define-extension");
lf[123]=C_h_intern(&lf[123],22,"chicken-compile-shared");
lf[124]=C_h_intern(&lf[124],4,"name");
lf[125]=C_h_intern(&lf[125],4,"unit");
lf[126]=C_h_intern(&lf[126],7,"provide");
lf[127]=C_h_intern(&lf[127],4,"else");
lf[128]=C_h_intern(&lf[128],3,"not");
lf[129]=C_h_intern(&lf[129],11,"cond-expand");
lf[130]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\007unquote\376\003\000\000\002\376\001\000\000\006%begin\376\377\016\376\377\016");
lf[131]=C_h_intern(&lf[131],4,"cdar");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid clause specifier");
lf[133]=C_h_intern(&lf[133],4,"caar");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid clause syntax");
lf[135]=C_h_intern(&lf[135],6,"export");
lf[136]=C_h_intern(&lf[136],7,"dynamic");
lf[137]=C_h_intern(&lf[137],6,"static");
lf[138]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\001_");
lf[139]=C_h_intern(&lf[139],4,"cute");
lf[140]=C_h_intern(&lf[140],5,"apply");
lf[141]=C_h_intern(&lf[141],5,"<...>");
lf[142]=C_h_intern(&lf[142],2,"<>");
lf[143]=C_h_intern(&lf[143],3,"cut");
lf[144]=C_h_intern(&lf[144],18,"define-record-type");
lf[145]=C_h_intern(&lf[145],18,"\003sysmake-structure");
lf[146]=C_h_intern(&lf[146],14,"\003sysstructure\077");
lf[147]=C_h_intern(&lf[147],15,"\000record-setters");
lf[148]=C_h_intern(&lf[148],19,"\003syscheck-structure");
lf[149]=C_h_intern(&lf[149],10,"\004corecheck");
lf[150]=C_h_intern(&lf[150],13,"\003sysblock-ref");
lf[151]=C_h_intern(&lf[151],14,"\003sysblock-set!");
lf[152]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[153]=C_h_intern(&lf[153],3,"car");
lf[154]=C_h_intern(&lf[154],18,"getter-with-setter");
lf[155]=C_h_intern(&lf[155],1,"y");
lf[156]=C_h_intern(&lf[156],1,"x");
lf[157]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\001\376\003\000\000\002\376\001\000\000\010variable\376\001\000"
"\000\001_");
lf[158]=C_h_intern(&lf[158],14,"condition-case");
lf[159]=C_h_intern(&lf[159],9,"condition");
lf[160]=C_h_intern(&lf[160],8,"\003sysslot");
lf[161]=C_h_intern(&lf[161],10,"\003syssignal");
lf[162]=C_h_intern(&lf[162],4,"cond");
lf[163]=C_h_intern(&lf[163],17,"handle-exceptions");
lf[164]=C_h_intern(&lf[164],4,"memv");
lf[165]=C_h_intern(&lf[165],3,"and");
lf[166]=C_h_intern(&lf[166],4,"kvar");
lf[167]=C_h_intern(&lf[167],5,"exvar");
lf[168]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[169]=C_h_intern(&lf[169],10,"\003sysvalues");
lf[170]=C_h_intern(&lf[170],9,"\003sysapply");
lf[171]=C_h_intern(&lf[171],20,"\003syscall-with-values");
lf[172]=C_h_intern(&lf[172],22,"with-exception-handler");
lf[173]=C_h_intern(&lf[173],30,"call-with-current-continuation");
lf[174]=C_h_intern(&lf[174],4,"args");
lf[175]=C_h_intern(&lf[175],1,"k");
lf[176]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[177]=C_h_intern(&lf[177],21,"define-record-printer");
lf[178]=C_h_intern(&lf[178],27,"\003sysregister-record-printer");
lf[179]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[180]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[181]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[182]=C_h_intern(&lf[182],11,"case-lambda");
lf[183]=C_h_intern(&lf[183],6,"length");
lf[184]=C_h_intern(&lf[184],9,"split-at!");
lf[185]=C_h_intern(&lf[185],4,"take");
lf[186]=C_h_intern(&lf[186],3,"map");
lf[187]=C_h_intern(&lf[187],4,"list");
lf[188]=C_h_intern(&lf[188],3,"cdr");
lf[189]=C_h_intern(&lf[189],4,"fx>=");
lf[190]=C_h_intern(&lf[190],3,"fx=");
lf[191]=C_h_intern(&lf[191],11,"lambda-list");
lf[192]=C_h_intern(&lf[192],25,"\003sysdecompose-lambda-list");
lf[193]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corecheck\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\003syserror\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreimmutable\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376B\000\0000no matching clause in call to \047case-lambda\047 form\376\377\016\376\377\016\376\377\016"
"\376\377\016");
lf[194]=C_h_intern(&lf[194],2,"if");
lf[195]=C_h_intern(&lf[195],4,"lvar");
lf[196]=C_h_intern(&lf[196],4,"rvar");
lf[197]=C_h_intern(&lf[197],3,"min");
lf[198]=C_h_intern(&lf[198],7,"require");
lf[199]=C_h_intern(&lf[199],6,"srfi-1");
lf[200]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[201]=C_h_intern(&lf[201],14,"let-optionals*");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[203]=C_h_intern(&lf[203],14,"\004coreimmutable");
lf[204]=C_h_intern(&lf[204],4,"tmp2");
lf[205]=C_h_intern(&lf[205],3,"tmp");
lf[206]=C_h_intern(&lf[206],5,"null\077");
lf[207]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[208]=C_h_intern(&lf[208],8,"optional");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[210]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[211]=C_h_intern(&lf[211],13,"let-optionals");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[213]=C_h_intern(&lf[213],13,"string-append");
lf[214]=C_h_intern(&lf[214],4,"let*");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\004def-");
lf[216]=C_h_intern(&lf[216],5,"%rest");
lf[217]=C_h_intern(&lf[217],4,"body");
lf[218]=C_h_intern(&lf[218],4,"cadr");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\001%");
lf[220]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[221]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[222]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[223]=C_h_intern(&lf[223],6,"select");
lf[224]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[225]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[226]=C_h_intern(&lf[226],4,"eqv\077");
lf[227]=C_h_intern(&lf[227],2,"or");
lf[228]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[229]=C_h_intern(&lf[229],8,"and-let*");
lf[230]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\001\000\000\001_");
lf[231]=C_h_intern(&lf[231],13,"define-inline");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000*invalid substitution form - must be lambda");
lf[233]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[234]=C_h_intern(&lf[234],18,"\004coredefine-inline");
lf[235]=C_h_intern(&lf[235],9,"nth-value");
lf[236]=C_h_intern(&lf[236],8,"list-ref");
lf[237]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[238]=C_h_intern(&lf[238],13,"letrec-values");
lf[239]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[240]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[241]=C_h_intern(&lf[241],11,"let*-values");
lf[242]=C_h_intern(&lf[242],10,"let-values");
lf[243]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[244]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[245]=C_h_intern(&lf[245],13,"define-values");
lf[246]=C_h_intern(&lf[246],11,"set!-values");
lf[247]=C_h_intern(&lf[247],19,"\003sysregister-export");
lf[248]=C_h_intern(&lf[248],18,"\003syscurrent-module");
lf[249]=C_h_intern(&lf[249],12,"\003sysfor-each");
lf[250]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[251]=C_h_intern(&lf[251],14,"\004coreundefined");
lf[252]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[253]=C_h_intern(&lf[253],6,"unless");
lf[254]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[255]=C_h_intern(&lf[255],4,"when");
lf[256]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[257]=C_h_intern(&lf[257],12,"parameterize");
lf[258]=C_h_intern(&lf[258],16,"\003sysdynamic-wind");
lf[259]=C_h_intern(&lf[259],1,"t");
lf[260]=C_h_intern(&lf[260],8,"\003syslist");
lf[261]=C_h_intern(&lf[261],4,"swap");
lf[262]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[263]=C_h_intern(&lf[263],9,"eval-when");
lf[264]=C_h_intern(&lf[264],10,"\000compiling");
lf[265]=C_h_intern(&lf[265],19,"\004corecompiletimetoo");
lf[266]=C_h_intern(&lf[266],20,"\004corecompiletimeonly");
lf[267]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[268]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid situation specifier");
lf[270]=C_h_intern(&lf[270],4,"load");
lf[271]=C_h_intern(&lf[271],7,"compile");
lf[272]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[273]=C_h_intern(&lf[273],9,"fluid-let");
lf[274]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\001\000\000\001_");
lf[275]=C_h_intern(&lf[275],6,"ensure");
lf[276]=C_h_intern(&lf[276],11,"\000type-error");
lf[277]=C_h_intern(&lf[277],15,"\003syssignal-hook");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\033argument has incorrect type");
lf[279]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\003");
lf[280]=C_h_intern(&lf[280],6,"assert");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\020assertion failed");
lf[282]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[283]=C_h_intern(&lf[283],7,"include");
lf[284]=C_h_intern(&lf[284],27,"\003syscurrent-source-filename");
lf[285]=C_h_intern(&lf[285],4,"read");
lf[286]=C_h_intern(&lf[286],20,"with-input-from-file");
lf[287]=C_h_intern(&lf[287],5,"print");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\014; including ");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[290]=C_h_intern(&lf[290],12,"load-verbose");
lf[291]=C_h_intern(&lf[291],28,"\003sysresolve-include-filename");
lf[292]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\377\016");
lf[293]=C_h_intern(&lf[293],4,"time");
lf[294]=C_h_intern(&lf[294],15,"\003sysstart-timer");
lf[295]=C_h_intern(&lf[295],14,"\003sysstop-timer");
lf[296]=C_h_intern(&lf[296],17,"\003sysdisplay-times");
lf[297]=C_h_intern(&lf[297],7,"receive");
lf[298]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[299]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[300]=C_h_intern(&lf[300],13,"define-record");
lf[301]=C_h_intern(&lf[301],3,"val");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\005-set!");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\001\077");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\005make-");
lf[307]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[308]=C_h_intern(&lf[308],11,"\003sysprovide");
lf[309]=C_h_intern(&lf[309],19,"chicken-more-macros");
C_register_lf2(lf,310,create_ptable());
t2=C_mutate(&lf[0] /* c955 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1843,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1841 */
static void C_ccall f_1843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1846,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1844 in k1841 */
static void C_ccall f_1846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1849,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1847 in k1844 in k1841 */
static void C_ccall f_1849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1852,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1855,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1858,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1861,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1864,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_4_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1867,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1870,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1873,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_support_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1876,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_compiler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1876,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1879,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1882,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_driver_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1885,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_platform_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1888,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_backend_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1888,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1891,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1894,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#provide");
t3=C_retrieve(lf[308]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[309]);}

/* k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1898,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#macro-environment");
t3=C_retrieve(lf[98]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1901,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9088,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9090,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a9089 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_9090(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9090,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9094,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[300],t2,lf[307]);}

/* k9092 in a9089 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_9094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9094,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9103,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("symbol->string");
t5=*((C_word*)lf[86]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k9101 in k9092 in a9089 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_9103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9103,2,t0,t1);}
t2=(C_word)C_i_memq(lf[147],C_retrieve(lf[51]));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9109,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
C_trace("r55");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[64]);}

/* k9107 in k9101 in k9092 in a9089 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_9109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9109,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9112,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("r55");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[95]);}

/* k9110 in k9107 in k9101 in k9092 in a9089 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_9112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9115,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("r55");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[154]);}

/* k9113 in k9110 in k9107 in k9101 in k9092 in a9089 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_9115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9115,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9118,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
C_trace("r55");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[94]);}

/* k9116 in k9113 in k9110 in k9107 in k9101 in k9092 in a9089 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_9118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9488,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9528,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("string-append");
t4=*((C_word*)lf[213]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[306],((C_word*)t0)[2]);}

/* k9526 in k9116 in k9113 in k9110 in k9107 in k9101 in k9092 in a9089 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_9528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("string->symbol");
t2=*((C_word*)lf[7]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9486 in k9116 in k9113 in k9110 in k9107 in k9101 in k9092 in a9089 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_9488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9488,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[91],t2);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9520,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t3,tmp=(C_word)a,a+=13,tmp);
C_trace("##sys#append");
t5=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);}

/* k9518 in k9486 in k9116 in k9113 in k9110 in k9107 in k9101 in k9092 in a9089 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_9520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9520,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[145],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t8);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9436,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t9,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9480,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
C_trace("string-append");
t12=*((C_word*)lf[213]+1);
((C_proc4)C_retrieve_proc(t12))(4,t12,t11,((C_word*)t0)[2],lf[305]);}

/* k9478 in k9518 in k9486 in k9116 in k9113 in k9110 in k9107 in k9101 in k9092 in a9089 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_9480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("string->symbol");
t2=*((C_word*)lf[7]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9434 in k9518 in k9486 in k9116 in k9113 in k9110 in k9107 in k9101 in k9092 in a9089 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_9436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9436,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[156],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[91],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[156],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[146],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t2,t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t1,t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t12);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9141,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t13,tmp=(C_word)a,a+=6,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9145,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9147,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t17,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp));
t19=((C_word*)t17)[1];
f_9147(t19,t15,((C_word*)t0)[2],C_fix(1));}

/* mapslots in k9434 in k9518 in k9486 in k9116 in k9113 in k9110 in k9107 in k9101 in k9092 in a9089 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_9147(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9147,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9157,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t3,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
C_trace("symbol->string");
t7=*((C_word*)lf[86]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}}

/* k9155 in mapslots in k9434 in k9518 in k9486 in k9116 in k9113 in k9110 in k9107 in k9101 in k9092 in a9089 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_9157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9157,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9160,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9424,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("string-append");
t4=*((C_word*)lf[213]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[2],lf[303],t1,lf[304]);}

/* k9422 in k9155 in mapslots in k9434 in k9518 in k9486 in k9116 in k9113 in k9110 in k9107 in k9101 in k9092 in a9089 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_9424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("string->symbol");
t2=*((C_word*)lf[7]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9158 in k9155 in mapslots in k9434 in k9518 in k9486 in k9116 in k9113 in k9110 in k9107 in k9101 in k9092 in a9089 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_9160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9163,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9420,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("string-append");
t4=*((C_word*)lf[213]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[3],lf[302],((C_word*)t0)[2]);}

/* k9418 in k9158 in k9155 in mapslots in k9434 in k9518 in k9486 in k9116 in k9113 in k9110 in k9107 in k9101 in k9092 in a9089 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_9420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("string->symbol");
t2=*((C_word*)lf[7]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9161 in k9158 in k9155 in mapslots in k9434 in k9518 in k9486 in k9116 in k9113 in k9110 in k9107 in k9101 in k9092 in a9089 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_9163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word ab[169],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9163,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[301],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[156],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[91],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[156],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[148],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[149],t9);
t11=(C_word)C_a_i_cons(&a,2,lf[301],C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[156],t12);
t14=(C_word)C_a_i_cons(&a,2,lf[151],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t10,t15);
t17=(C_word)C_a_i_cons(&a,2,t3,t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t19);
t21=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t20);
t22=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9210,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t21,a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[3])){
t23=(C_word)C_a_i_cons(&a,2,lf[156],C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,lf[91],t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,lf[156],t26);
t28=(C_word)C_a_i_cons(&a,2,lf[148],t27);
t29=(C_word)C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST);
t30=(C_word)C_a_i_cons(&a,2,lf[149],t29);
t31=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t32=(C_word)C_a_i_cons(&a,2,lf[156],t31);
t33=(C_word)C_a_i_cons(&a,2,lf[150],t32);
t34=(C_word)C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,t30,t34);
t36=(C_word)C_a_i_cons(&a,2,t23,t35);
t37=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t36);
t38=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t39=(C_word)C_a_i_cons(&a,2,t37,t38);
t40=t22;
f_9210(t40,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t39));}
else{
t23=(C_word)C_a_i_cons(&a,2,lf[156],C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,lf[91],t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,lf[156],t26);
t28=(C_word)C_a_i_cons(&a,2,lf[148],t27);
t29=(C_word)C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST);
t30=(C_word)C_a_i_cons(&a,2,lf[149],t29);
t31=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t32=(C_word)C_a_i_cons(&a,2,lf[156],t31);
t33=(C_word)C_a_i_cons(&a,2,lf[150],t32);
t34=(C_word)C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,t30,t34);
t36=(C_word)C_a_i_cons(&a,2,t23,t35);
t37=t22;
f_9210(t37,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t36));}}

/* k9208 in k9161 in k9158 in k9155 in mapslots in k9434 in k9518 in k9486 in k9116 in k9113 in k9110 in k9107 in k9101 in k9092 in a9089 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_9210(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9210,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9174,a[2]=t7,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t10=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
C_trace("mapslots82");
t11=((C_word*)((C_word*)t0)[2])[1];
f_9147(t11,t8,t9,t10);}

/* k9172 in k9208 in k9161 in k9158 in k9155 in mapslots in k9434 in k9518 in k9486 in k9116 in k9113 in k9110 in k9107 in k9101 in k9092 in a9089 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_9174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9174,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k9143 in k9434 in k9518 in k9486 in k9116 in k9113 in k9110 in k9107 in k9101 in k9092 in a9089 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_9145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k9139 in k9434 in k9518 in k9486 in k9116 in k9113 in k9110 in k9107 in k9101 in k9092 in a9089 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_9141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9141,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k9086 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_9088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[300],C_SCHEME_END_OF_LIST,t1);}

/* k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8945,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8947,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8946 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8947(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8947,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8951,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("r111");
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[94]);}

/* k8949 in a8946 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8954,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("r111");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[81]);}

/* k8952 in k8949 in a8946 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8957,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#check-syntax");
t3=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[297],((C_word*)t0)[4],lf[299]);}

/* k8955 in k8952 in k8949 in a8946 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8957,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8986,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
C_trace("##sys#append");
t5=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8993,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#check-syntax");
t4=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[297],((C_word*)t0)[5],lf[298]);}}

/* k8991 in k8955 in k8952 in k8949 in a8946 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8993,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9008,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cdr(t2);
t7=t5;
f_9008(t7,(C_word)C_i_nullp(t6));}
else{
t6=t5;
f_9008(t6,C_SCHEME_FALSE);}}

/* k9006 in k8991 in k8955 in k8952 in k8949 in a8946 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_9008(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9008,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9023,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#append");
t7=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9062,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#append");
t6=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}}

/* k9060 in k9006 in k8991 in k8955 in k8952 in k8949 in a8946 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_9062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9062,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[171],t5));}

/* k9021 in k9006 in k8991 in k8955 in k8952 in k8949 in a8946 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_9023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9023,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k8984 in k8955 in k8952 in k8949 in a8946 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8986,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[260],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[171],t5));}

/* k8943 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[297],C_SCHEME_END_OF_LIST,t1);}

/* k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1907,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8846,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8848,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8847 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8848(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8848,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8852,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("r145");
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[259]);}

/* k8850 in a8847 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8855,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("r145");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[64]);}

/* k8853 in k8850 in a8847 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8858,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("r145");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[94]);}

/* k8856 in k8853 in k8850 in a8847 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8858,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[294],C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8937,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("##sys#append");
t5=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k8935 in k8856 in k8853 in k8850 in a8847 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[54],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8937,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[295],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[296],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[169],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[170],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t6,t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,t3,t14);
t16=(C_word)C_a_i_cons(&a,2,lf[171],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t17);
t19=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t18));}

/* k8844 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[293],C_SCHEME_END_OF_LIST,t1);}

/* k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8828,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8830,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8829 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8830,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8838,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cdr(t2);
C_trace("##sys#append");
t7=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}

/* k8836 in a8829 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8838,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[59],t1));}

/* k8826 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[74],C_SCHEME_END_OF_LIST,t1);}

/* k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1913,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8739,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8741,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8740 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8741(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8741,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8745,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[283],t2,lf[292]);}

/* k8743 in a8740 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8748,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
C_trace("##sys#resolve-include-filename");
t4=C_retrieve(lf[291]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k8746 in k8743 in a8740 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8748,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8751,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("r165");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[64]);}

/* k8749 in k8746 in k8743 in a8740 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8754,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8817,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("load-verbose");
t4=C_retrieve(lf[290]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k8815 in k8749 in k8746 in k8743 in a8740 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("print");
t2=*((C_word*)lf[287]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[288],((C_word*)t0)[2],lf[289]);}
else{
t2=((C_word*)t0)[3];
f_8754(2,t2,C_SCHEME_UNDEFINED);}}

/* k8752 in k8749 in k8746 in k8743 in a8740 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8761,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8765,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8767,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("with-input-from-file");
t5=C_retrieve(lf[286]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}

/* a8766 in k8752 in k8749 in k8746 in k8743 in a8740 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8767,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8773,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8778,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8811,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#dynamic-wind");
t9=*((C_word*)lf[258]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t1,t6,t7,t8);}

/* a8810 in a8766 in k8752 in k8749 in k8746 in k8743 in a8740 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8811,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[284]));
t3=C_mutate((C_word*)lf[284]+1 /* current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a8777 in a8766 in k8752 in k8749 in k8746 in k8743 in a8740 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8786,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("read");
t3=*((C_word*)lf[285]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8784 in a8777 in a8766 in k8752 in k8749 in k8746 in k8743 in a8740 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8786,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8788,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_8788(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* doloop190 in k8784 in a8777 in a8766 in k8752 in k8749 in k8746 in k8743 in a8740 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_8788(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8788,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eofp(t2))){
C_trace("reverse");
t4=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8805,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("read");
t5=*((C_word*)lf[285]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k8803 in doloop190 in k8784 in a8777 in a8766 in k8752 in k8749 in k8746 in k8743 in a8740 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8805,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_8788(t3,((C_word*)t0)[2],t1,t2);}

/* a8772 in a8766 in k8752 in k8749 in k8746 in k8743 in a8740 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8773,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[284]));
t3=C_mutate((C_word*)lf[284]+1 /* current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k8763 in k8752 in k8749 in k8746 in k8743 in a8740 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8759 in k8752 in k8749 in k8746 in k8743 in a8740 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8761,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8737 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[283],C_SCHEME_END_OF_LIST,t1);}

/* k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8628,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8630,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8629 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8630(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8630,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8634,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[280],t2,lf[282]);}

/* k8632 in a8629 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8634,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8643,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("r210");
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[194]);}

/* k8641 in k8632 in a8629 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8646,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("r210");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[91]);}

/* k8644 in k8641 in k8632 in a8629 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8649,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,lf[281],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[91],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=t2;
f_8649(t7,(C_word)C_a_i_cons(&a,2,lf[203],t6));}
else{
t4=t2;
f_8649(t4,(C_word)C_i_car(((C_word*)t0)[2]));}}

/* k8647 in k8644 in k8641 in k8632 in a8629 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_8649(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8649,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[149],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[251],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8692,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t4,a[6]=t1,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_i_length(((C_word*)t0)[2]);
t9=(C_word)C_fixnum_greaterp(t8,C_fix(1));
t10=(C_truep(t9)?(C_word)C_i_cdr(((C_word*)t0)[2]):C_SCHEME_END_OF_LIST);
C_trace("##sys#append");
t11=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t7,t10,C_SCHEME_END_OF_LIST);}

/* k8690 in k8647 in k8644 in k8641 in k8632 in a8629 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8692,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[87],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k8626 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[280],C_SCHEME_END_OF_LIST,t1);}

/* k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1919,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8491,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8493,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8492 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8493(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8493,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8497,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[275],t2,lf[279]);}

/* k8495 in a8492 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8497,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8509,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
C_trace("r235");
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[205]);}

/* k8507 in k8495 in a8492 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("r235");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[81]);}

/* k8510 in k8507 in k8495 in a8492 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8515,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("r235");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[194]);}

/* k8513 in k8510 in k8507 in k8495 in a8492 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[59],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8515,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[149],t7);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8562,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t1,a[6]=t8,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8566,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t11=t10;
f_8566(t11,((C_word*)t0)[2]);}
else{
t11=(C_word)C_a_i_cons(&a,2,lf[278],C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,lf[91],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,lf[203],t13);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,lf[91],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t17);
t19=t10;
f_8566(t19,(C_word)C_a_i_cons(&a,2,t14,t18));}}

/* k8564 in k8513 in k8510 in k8507 in k8495 in a8492 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_8566(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8560 in k8513 in k8510 in k8507 in k8495 in a8492 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8562,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[276],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[277],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k8489 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[275],C_SCHEME_END_OF_LIST,t1);}

/* k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1922,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8233,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8235,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8235(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8235,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8239,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[273],t2,lf[274]);}

/* k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8239,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8248,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#map");
t5=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[153]+1),t2);}

/* k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8248,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8251,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8479,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#map");
t4=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a8478 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8479(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8479,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8487,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("gensym");
t4=C_retrieve(lf[65]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k8485 in a8478 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("r255");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8249 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8251,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8254,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8469,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#map");
t4=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a8468 in k8249 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8469(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8469,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8477,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("gensym");
t4=C_retrieve(lf[65]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k8475 in a8468 in k8249 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("r255");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8252 in k8249 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8254,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8257,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("r255");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[81]);}

/* k8255 in k8252 in k8249 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8260,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("r255");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[94]);}

/* k8258 in k8255 in k8252 in k8249 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8260,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8271,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8427,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8467,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#map");
t5=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[218]+1),((C_word*)t0)[2]);}

/* k8465 in k8258 in k8255 in k8252 in k8249 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[186]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[260]+1),((C_word*)t0)[2],t1);}

/* k8425 in k8258 in k8255 in k8252 in k8249 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8431,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8435,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8439,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_length(((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8445,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_8445(t9,t4,t5);}

/* loop in k8425 in k8258 in k8255 in k8252 in k8249 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_8445(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8445,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8459,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
C_trace("loop284");
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k8457 in loop in k8425 in k8258 in k8255 in k8252 in k8249 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8459,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1));}

/* k8437 in k8425 in k8258 in k8255 in k8252 in k8249 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[186]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[260]+1),((C_word*)t0)[2],t1);}

/* k8433 in k8425 in k8258 in k8255 in k8252 in k8249 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8429 in k8425 in k8258 in k8255 in k8252 in k8249 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8269 in k8258 in k8255 in k8252 in k8249 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8375,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8379,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8411,tmp=(C_word)a,a+=2,tmp);
C_trace("map");
t5=*((C_word*)lf[186]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* a8410 in k8269 in k8258 in k8255 in k8252 in k8249 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8411(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8411,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[84],t5));}

/* k8377 in k8269 in k8258 in k8255 in k8252 in k8249 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8383,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8387,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8397,tmp=(C_word)a,a+=2,tmp);
C_trace("map");
t5=*((C_word*)lf[186]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8396 in k8377 in k8269 in k8258 in k8255 in k8252 in k8249 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8397(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8397,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[84],t5));}

/* k8385 in k8377 in k8269 in k8258 in k8255 in k8252 in k8249 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8387,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[251],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
C_trace("##sys#append");
t4=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k8381 in k8377 in k8269 in k8258 in k8255 in k8252 in k8249 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8373 in k8269 in k8258 in k8255 in k8252 in k8249 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8375,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8367,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t3,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
C_trace("##sys#append");
t5=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k8365 in k8373 in k8269 in k8258 in k8255 in k8252 in k8249 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8367,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8311,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t3,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8315,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8347,tmp=(C_word)a,a+=2,tmp);
C_trace("map");
t7=*((C_word*)lf[186]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,t6,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a8346 in k8365 in k8373 in k8269 in k8258 in k8255 in k8252 in k8249 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8347(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8347,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[84],t5));}

/* k8313 in k8365 in k8373 in k8269 in k8258 in k8255 in k8252 in k8249 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8319,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8323,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8333,tmp=(C_word)a,a+=2,tmp);
C_trace("map");
t5=*((C_word*)lf[186]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8332 in k8313 in k8365 in k8373 in k8269 in k8258 in k8255 in k8252 in k8249 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8333(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8333,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[84],t5));}

/* k8321 in k8313 in k8365 in k8373 in k8269 in k8258 in k8255 in k8252 in k8249 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8323,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[251],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
C_trace("##sys#append");
t4=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k8317 in k8313 in k8365 in k8373 in k8269 in k8258 in k8255 in k8252 in k8249 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8309 in k8365 in k8373 in k8269 in k8258 in k8255 in k8252 in k8249 in k8246 in k8237 in a8234 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8311,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[258],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k8231 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[273],C_SCHEME_END_OF_LIST,t1);}

/* k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8112,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8114,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8113 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8114(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8114,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8118,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[263],t2,lf[272]);}

/* k8116 in a8113 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8118,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8124,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("r320");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[64]);}

/* k8122 in k8116 in a8113 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8124,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8225,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
C_trace("##sys#append");
t4=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k8223 in k8122 in k8116 in a8113 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8225,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8130,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_trace("r320");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[116]);}

/* k8128 in k8223 in k8122 in k8116 in a8113 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8130,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8133,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("r320");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[271]);}

/* k8131 in k8128 in k8223 in k8122 in k8116 in a8113 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8136,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("r320");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[270]);}

/* k8134 in k8131 in k8128 in k8223 in k8122 in k8116 in a8113 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8136,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8139,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t7,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8176,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=t7,a[8]=t3,a[9]=t10,tmp=(C_word)a,a+=10,tmp));
t12=((C_word*)t10)[1];
f_8176(t12,t8,((C_word*)t0)[2]);}

/* loop in k8134 in k8131 in k8128 in k8223 in k8122 in k8116 in a8113 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_8176(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8176,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8189,a[2]=t1,a[3]=((C_word*)t0)[9],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8199,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
C_trace("c321");
t6=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t3,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8197 in loop in k8134 in k8131 in k8128 in k8223 in k8122 in k8116 in a8113 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8199,2,t0,t1);}
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[10],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[9];
f_8189(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8206,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("c321");
t3=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k8204 in k8197 in loop in k8134 in k8131 in k8128 in k8223 in k8122 in k8116 in a8113 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8206,2,t0,t1);}
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[8],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[7];
f_8189(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8213,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
C_trace("c321");
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k8211 in k8204 in k8197 in loop in k8134 in k8131 in k8128 in k8223 in k8122 in k8116 in a8113 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[3];
f_8189(2,t3,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
C_trace("##sys#error");
t3=*((C_word*)lf[87]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],lf[269],t2);}}

/* k8187 in loop in k8134 in k8131 in k8128 in k8223 in k8122 in k8116 in a8113 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
C_trace("loop349");
t3=((C_word*)((C_word*)t0)[3])[1];
f_8176(t3,((C_word*)t0)[2],t2);}

/* k8137 in k8134 in k8131 in k8128 in k8223 in k8122 in k8116 in a8113 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8139,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[264],C_retrieve(lf[51])))){
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?((C_word*)((C_word*)t0)[5])[1]:C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[265],t3));}
else{
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[266],t3));}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)((C_word*)t0)[5])[1])?((C_word*)t0)[4]:lf[267]));}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)((C_word*)t0)[2])[1])?((C_word*)t0)[4]:lf[268]));}}

/* k8110 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[263],C_SCHEME_END_OF_LIST,t1);}

/* k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1928,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7910,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7912,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a7911 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7912,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7916,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[257],t2,lf[262]);}

/* k7914 in a7911 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7916,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7925,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("r385");
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[261]);}

/* k7923 in k7914 in a7911 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7928,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
C_trace("r385");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[81]);}

/* k7926 in k7923 in k7914 in a7911 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("r385");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[94]);}

/* k7929 in k7926 in k7923 in k7914 in a7911 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7934,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
C_trace("##sys#map");
t3=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[153]+1),((C_word*)t0)[2]);}

/* k7932 in k7929 in k7926 in k7923 in k7914 in a7911 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7937,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("##sys#map");
t3=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[218]+1),((C_word*)t0)[2]);}

/* k7935 in k7932 in k7929 in k7926 in k7923 in k7914 in a7911 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7940,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8100,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#map");
t4=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a8099 in k7935 in k7932 in k7929 in k7926 in k7923 in k7914 in a7911 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8100(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8100,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8108,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("gensym");
t4=C_retrieve(lf[65]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k8106 in a8099 in k7935 in k7932 in k7929 in k7926 in k7923 in k7914 in a7911 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("r385");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7938 in k7935 in k7932 in k7929 in k7926 in k7923 in k7914 in a7911 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7943,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8090,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#map");
t4=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a8089 in k7938 in k7935 in k7932 in k7929 in k7926 in k7923 in k7914 in a7911 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8090(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8090,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8098,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("gensym");
t4=C_retrieve(lf[65]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k8096 in a8089 in k7938 in k7935 in k7932 in k7929 in k7926 in k7923 in k7914 in a7911 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("r385");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7941 in k7938 in k7935 in k7932 in k7929 in k7926 in k7923 in k7914 in a7911 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7943,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7954,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8084,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("map");
t4=*((C_word*)lf[186]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[260]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k8082 in k7941 in k7938 in k7935 in k7932 in k7929 in k7926 in k7923 in k7914 in a7911 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8088,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t3=*((C_word*)lf[186]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[260]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8086 in k8082 in k7941 in k7938 in k7935 in k7932 in k7929 in k7926 in k7923 in k7914 in a7911 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7952 in k7941 in k7938 in k7935 in k7932 in k7929 in k7926 in k7923 in k7914 in a7911 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8022,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8026,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8028,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t5=*((C_word*)lf[186]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8027 in k7952 in k7941 in k7938 in k7935 in k7932 in k7929 in k7926 in k7923 in k7914 in a7911 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8028(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[39],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8028,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[259],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t2,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[259],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t3,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[84],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t9,t13);
t15=(C_word)C_a_i_cons(&a,2,t7,t14);
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t15));}

/* k8024 in k7952 in k7941 in k7938 in k7935 in k7932 in k7929 in k7926 in k7923 in k7914 in a7911 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8020 in k7952 in k7941 in k7938 in k7935 in k7932 in k7929 in k7926 in k7923 in k7914 in a7911 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8022,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8002,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("##sys#append");
t8=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k8000 in k8020 in k7952 in k7941 in k7938 in k7935 in k7932 in k7929 in k7926 in k7923 in k7914 in a7911 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_8002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8002,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[258],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t11);
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t12));}

/* k7908 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[257],C_SCHEME_END_OF_LIST,t1);}

/* k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7865,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7867,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a7866 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7867(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7867,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7871,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[255],t2,lf[256]);}

/* k7869 in a7866 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7878,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("r425");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[194]);}

/* k7876 in k7869 in a7866 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7878,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7898,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("r425");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[64]);}

/* k7896 in k7876 in k7869 in a7866 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7902,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
C_trace("##sys#append");
t4=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k7900 in k7896 in k7876 in k7869 in a7866 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7902,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k7863 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[255],C_SCHEME_END_OF_LIST,t1);}

/* k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1934,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7812,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7814,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a7813 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7814(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7814,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7818,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[253],t2,lf[254]);}

/* k7816 in a7813 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("r434");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[194]);}

/* k7823 in k7816 in a7813 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7825,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,lf[251],C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7853,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
C_trace("r434");
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[64]);}

/* k7851 in k7823 in k7816 in a7813 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7857,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
C_trace("##sys#append");
t4=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k7855 in k7851 in k7823 in k7816 in a7813 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7857,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k7810 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[253],C_SCHEME_END_OF_LIST,t1);}

/* k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1937,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7667,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7669,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a7668 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7669(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7669,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7673,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[246],t2,lf[252]);}

/* k7671 in a7668 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7673,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7682,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("r443");
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[94]);}

/* k7680 in k7671 in a7668 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7682,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[251],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t6);
t8=(C_word)C_a_i_cons(&a,2,t1,t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t4,t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[171],t10));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[84],t5));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7751,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("map");
t4=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_retrieve(lf[65]),((C_word*)t0)[4]);}}}

/* k7749 in k7680 in k7671 in a7668 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7751,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7778,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7782,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7784,tmp=(C_word)a,a+=2,tmp);
C_trace("map");
t8=*((C_word*)lf[186]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,t7,((C_word*)t0)[2],t1);}

/* a7783 in k7749 in k7680 in k7671 in a7668 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7784,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[84],t5));}

/* k7780 in k7749 in k7680 in k7671 in a7668 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7776 in k7749 in k7680 in k7671 in a7668 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7778,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[171],t5));}

/* k7665 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[246],C_SCHEME_END_OF_LIST,t1);}

/* k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1940,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7625,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7627,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a7626 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7627(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7627,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7631,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[245],t2,lf[250]);}

/* k7629 in a7626 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7634,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7651,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
C_trace("for-each");
t5=*((C_word*)lf[249]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a7650 in k7629 in a7626 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7651(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7651,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7659,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#current-module");
t4=C_retrieve(lf[248]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7657 in a7650 in k7629 in a7626 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#register-export");
t2=C_retrieve(lf[247]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7632 in k7629 in a7626 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7641,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("r480");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[246]);}

/* k7639 in k7632 in k7629 in a7626 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7645,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("##sys#append");
t4=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k7643 in k7639 in k7632 in k7629 in a7626 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7645,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7623 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[245],C_SCHEME_END_OF_LIST,t1);}

/* k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1943,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7237,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7239,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7239(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7239,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7243,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[242],t2,lf[244]);}

/* k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7243,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7252,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("r499");
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[81]);}

/* k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7255,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
C_trace("r499");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[94]);}

/* k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7255,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7257,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t7=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7288,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7330,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
C_trace("map");
t9=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,*((C_word*)lf[153]+1),((C_word*)t0)[3]);}

/* k7328 in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7333,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7583,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_7583(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* loop in k7328 in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_7583(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7583,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7596,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t4))){
C_trace("append");
t6=*((C_word*)lf[36]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t4))){
C_trace("append*508");
t6=((C_word*)((C_word*)t0)[2])[1];
f_7257(t6,t5,t4,t3);}
else{
t6=t5;
f_7596(2,t6,(C_word)C_a_i_cons(&a,2,t4,t3));}}}}

/* k7594 in loop in k7328 in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("loop531");
t3=((C_word*)((C_word*)t0)[3])[1];
f_7583(t3,((C_word*)t0)[2],t2,t1);}

/* k7331 in k7328 in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7336,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7569,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t4=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a7568 in k7331 in k7328 in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7569(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7569,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7577,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7581,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("gensym");
t5=C_retrieve(lf[65]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k7579 in a7568 in k7331 in k7328 in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("r499");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7575 in a7568 in k7331 in k7328 in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7577,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7334 in k7331 in k7328 in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7337,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7348,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7523,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_7523(t7,t3,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}

/* loop in k7334 in k7331 in k7328 in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_7523(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7523,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
C_trace("reverse");
t4=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7539,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7563,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_trace("map*509");
t7=((C_word*)((C_word*)t0)[3])[1];
f_7288(t7,t6,((C_word*)t0)[2],t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7556,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_trace("lookup556");
t7=((C_word*)t0)[2];
f_7337(3,t7,t6,t4);}}}

/* k7554 in loop in k7334 in k7331 in k7328 in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7556,2,t0,t1);}
t2=((C_word*)t0)[3];
f_7539(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k7561 in loop in k7334 in k7331 in k7328 in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7563,2,t0,t1);}
t2=((C_word*)t0)[3];
f_7539(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k7537 in loop in k7334 in k7331 in k7328 in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_7539(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("loop563");
t3=((C_word*)((C_word*)t0)[3])[1];
f_7523(t3,((C_word*)t0)[2],t2,t1);}

/* k7346 in k7334 in k7331 in k7328 in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7355,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7517,tmp=(C_word)a,a+=2,tmp);
C_trace("map");
t4=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7516 in k7346 in k7334 in k7331 in k7328 in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7517(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7517,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k7353 in k7346 in k7334 in k7331 in k7328 in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7355,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7357,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_7357(t5,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* fold in k7353 in k7346 in k7334 in k7331 in k7328 in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_7357(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7357,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7375,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7381,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t7=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7395,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_i_car(t4);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7511,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("cdar");
t8=*((C_word*)lf[131]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}
else{
t7=t5;
f_7395(t7,C_SCHEME_FALSE);}}}

/* k7509 in fold in k7353 in k7346 in k7334 in k7331 in k7328 in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7395(t2,(C_word)C_i_nullp(t1));}

/* k7393 in fold in k7353 in k7346 in k7334 in k7331 in k7328 in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_7395(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7395,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7434,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
C_trace("caar");
t3=*((C_word*)lf[133]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7477,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[5]);
t9=(C_word)C_i_cdr(((C_word*)t0)[8]);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("fold587");
t11=((C_word*)((C_word*)t0)[3])[1];
f_7357(t11,t7,t8,t9,t10);}}

/* k7475 in k7393 in fold in k7353 in k7346 in k7334 in k7331 in k7328 in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7477,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[171],t6));}

/* k7432 in k7393 in fold in k7353 in k7346 in k7334 in k7331 in k7328 in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7434,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7414,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
t8=(C_word)C_i_cdr(((C_word*)t0)[7]);
t9=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("fold587");
t10=((C_word*)((C_word*)t0)[2])[1];
f_7357(t10,t6,t7,t8,t9);}

/* k7412 in k7432 in k7393 in fold in k7353 in k7346 in k7334 in k7331 in k7328 in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7414,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* a7380 in fold in k7353 in k7346 in k7334 in k7331 in k7328 in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7381(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7381,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7389,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("lookup556");
t4=((C_word*)t0)[2];
f_7337(3,t4,t3,t2);}

/* k7387 in a7380 in fold in k7353 in k7346 in k7334 in k7331 in k7328 in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7389,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k7373 in fold in k7353 in k7346 in k7334 in k7331 in k7328 in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7379,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#append");
t3=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k7377 in k7373 in fold in k7353 in k7346 in k7334 in k7331 in k7328 in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7379,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* lookup in k7334 in k7331 in k7328 in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7337(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7337,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* map* in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_7288(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7288,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7311,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
C_trace("proc514");
t6=t2;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
C_trace("proc514");
t4=t2;
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}}}

/* k7309 in map* in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7315,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("map*509");
t4=((C_word*)((C_word*)t0)[3])[1];
f_7288(t4,t2,((C_word*)t0)[2],t3);}

/* k7313 in k7309 in map* in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7315,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* append* in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_7257(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7257,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7278,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
C_trace("append*508");
t8=t5;
t9=t6;
t10=t3;
t1=t8;
t2=t9;
t3=t10;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}}

/* k7276 in append* in k7253 in k7250 in k7241 in a7238 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7278,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7235 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[242],C_SCHEME_END_OF_LIST,t1);}

/* k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1943,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1946,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7165,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7167,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a7166 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7167,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7171,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[241],t2,lf[243]);}

/* k7169 in a7166 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7171,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7180,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("r624");
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[81]);}

/* k7178 in k7169 in a7166 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7183,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("r624");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[242]);}

/* k7181 in k7178 in k7169 in a7166 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7183,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7188,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7188(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fold in k7181 in k7178 in k7169 in a7166 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_7188(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7188,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7206,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#append");
t4=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7225,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(t2);
C_trace("fold634");
t9=t5;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}

/* k7223 in fold in k7181 in k7178 in k7169 in a7166 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7225,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k7204 in fold in k7181 in k7178 in k7169 in a7166 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7206,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k7163 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[241],C_SCHEME_END_OF_LIST,t1);}

/* k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6999,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7001,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a7000 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7001(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7001,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7005,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[238],t2,lf[240]);}

/* k7003 in a7000 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7005,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7014,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("r650");
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[81]);}

/* k7012 in k7003 in a7000 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7017,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("r650");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[94]);}

/* k7015 in k7012 in k7003 in a7000 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7020,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7155,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7157,tmp=(C_word)a,a+=2,tmp);
C_trace("map");
t5=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[3]);}

/* a7156 in k7015 in k7012 in k7003 in a7000 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7157(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7157,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k7153 in k7015 in k7012 in k7003 in a7000 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[60]+1),t1);}

/* k7018 in k7015 in k7012 in k7003 in a7000 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7023,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7139,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t4=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a7138 in k7018 in k7015 in k7012 in k7003 in a7000 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7139(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7139,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7147,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7151,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("gensym");
t5=C_retrieve(lf[65]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k7149 in a7138 in k7018 in k7015 in k7012 in k7003 in a7000 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("r650");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7145 in a7138 in k7018 in k7015 in k7012 in k7003 in a7000 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7147,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7021 in k7018 in k7015 in k7012 in k7003 in a7000 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7024,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7043,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7133,tmp=(C_word)a,a+=2,tmp);
C_trace("map");
t5=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7132 in k7021 in k7018 in k7015 in k7012 in k7003 in a7000 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7133(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7133,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,lf[239]));}

/* k7041 in k7021 in k7018 in k7015 in k7012 in k7003 in a7000 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7047,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7051,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7057,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t5=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7056 in k7041 in k7021 in k7018 in k7015 in k7012 in k7003 in a7000 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7057(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7057,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7085,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t6,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_i_car(t2);
C_trace("map");
t9=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,((C_word*)t0)[2],t8);}

/* k7083 in a7056 in k7041 in k7021 in k7018 in k7015 in k7012 in k7003 in a7000 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7085,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7089,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7093,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7095,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[2]);
C_trace("map");
t6=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a7094 in k7083 in a7056 in k7041 in k7021 in k7018 in k7015 in k7012 in k7003 in a7000 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7095(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7095,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7111,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("lookup667");
t4=((C_word*)t0)[2];
f_7024(3,t4,t3,t2);}

/* k7109 in a7094 in k7083 in a7056 in k7041 in k7021 in k7018 in k7015 in k7012 in k7003 in a7000 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7111,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[84],t3));}

/* k7091 in k7083 in a7056 in k7041 in k7021 in k7018 in k7015 in k7012 in k7003 in a7000 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7087 in k7083 in a7056 in k7041 in k7021 in k7018 in k7015 in k7012 in k7003 in a7000 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7089,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[171],t5));}

/* k7049 in k7041 in k7021 in k7018 in k7015 in k7012 in k7003 in a7000 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7055,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#append");
t3=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k7053 in k7049 in k7041 in k7021 in k7018 in k7015 in k7012 in k7003 in a7000 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7045 in k7041 in k7021 in k7018 in k7015 in k7012 in k7003 in a7000 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7047,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* lookup in k7021 in k7018 in k7015 in k7012 in k7003 in a7000 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_7024(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7024,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k6997 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[238],C_SCHEME_END_OF_LIST,t1);}

/* k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1952,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6925,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6927,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a6926 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6927(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6927,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6931,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[235],t2,lf[237]);}

/* k6929 in a6926 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6934,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("r692");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[205]);}

/* k6932 in k6929 in a6926 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6937,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("r692");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[236]);}

/* k6935 in k6932 in k6929 in a6926 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6940,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("r692");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[94]);}

/* k6938 in k6935 in k6932 in k6929 in a6926 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6940,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_i_cadr(((C_word*)t0)[5]);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t10);
t12=(C_word)C_a_i_cons(&a,2,t1,t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t5,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[171],t14));}

/* k6923 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[235],C_SCHEME_END_OF_LIST,t1);}

/* k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1955,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6824,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6826,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a6825 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6826(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6826,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6830,a[2]=t2,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
C_trace("r705");
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[94]);}

/* k6828 in a6825 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6830,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6832,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6913,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6917,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("quotify-proc711");
t6=t2;
f_6832(t6,t4,t5,lf[231]);}

/* k6915 in k6828 in a6825 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6911 in k6828 in a6825 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6913,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[234],t1));}

/* quotify-proc in k6828 in a6825 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_6832(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6832,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#check-syntax");
t5=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,t3,t2,lf[233]);}

/* k6834 in quotify-proc in k6828 in a6825 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6836,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6893,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[5]);
C_trace("##sys#append");
t9=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,C_SCHEME_END_OF_LIST);}
else{
t6=t5;
f_6845(t6,(C_word)C_i_cadr(((C_word*)t0)[5]));}}

/* k6891 in k6834 in quotify-proc in k6828 in a6825 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6893,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_6845(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k6843 in k6834 in quotify-proc in k6828 in a6825 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_6845(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6845,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6848,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_pairp(t1);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6857,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_6857(t6,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6867,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_car(t1);
C_trace("c706");
t8=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k6865 in k6843 in k6834 in quotify-proc in k6828 in a6825 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6857(t2,(C_word)C_i_not(t1));}

/* k6855 in k6843 in k6834 in quotify-proc in k6828 in a6825 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_6857(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("syntax-error");
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[231],lf[232],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_6848(2,t2,C_SCHEME_UNDEFINED);}}

/* k6846 in k6843 in k6834 in quotify-proc in k6828 in a6825 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6848,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k6822 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[231],C_SCHEME_END_OF_LIST,t1);}

/* k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6661,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6663,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a6662 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6663(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6663,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6667,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[229],t2,lf[230]);}

/* k6665 in a6662 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6667,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6676,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("r745");
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[194]);}

/* k6674 in k6665 in a6662 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("r745");
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[81]);}

/* k6677 in k6674 in k6665 in a6662 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6679,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6684,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_6684(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fold in k6677 in k6674 in k6665 in a6662 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_6684(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(30);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6684,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6698,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("r745");
t4=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[64]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=(C_word)C_i_car(t3);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6758,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
C_trace("fold755");
t17=t7;
t18=t4;
t1=t17;
t2=t18;
goto loop;}
else{
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_cadr(t3);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t6,t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6796,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t10,a[5]=((C_word*)t0)[4],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
C_trace("fold755");
t17=t11;
t18=t4;
t1=t17;
t2=t18;
goto loop;}}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6729,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("fold755");
t17=t5;
t18=t4;
t1=t17;
t2=t18;
goto loop;}}}

/* k6727 in fold in k6677 in k6674 in k6665 in a6662 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6729,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k6794 in fold in k6677 in k6674 in k6665 in a6662 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6796,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k6756 in fold in k6677 in k6674 in k6665 in a6662 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6758,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k6696 in fold in k6677 in k6674 in k6665 in a6662 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6702,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#append");
t3=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k6700 in k6696 in fold in k6677 in k6674 in k6665 in a6662 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6702,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6659 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[229],C_SCHEME_END_OF_LIST,t1);}

/* k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1961,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6492,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6494,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a6493 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6494(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6494,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6498,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[223],t2,lf[228]);}

/* k6496 in a6493 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6498,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6507,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_trace("r791");
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[205]);}

/* k6505 in k6496 in a6493 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6510,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("r791");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[194]);}

/* k6508 in k6505 in k6496 in a6493 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6513,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("r791");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[127]);}

/* k6511 in k6508 in k6505 in k6496 in a6493 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6516,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("r791");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[227]);}

/* k6514 in k6511 in k6508 in k6505 in k6496 in a6493 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6519,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("r791");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[226]);}

/* k6517 in k6514 in k6511 in k6508 in k6505 in k6496 in a6493 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
C_trace("r791");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[64]);}

/* k6520 in k6517 in k6514 in k6511 in k6508 in k6505 in k6496 in a6493 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6529,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
C_trace("r791");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[81]);}

/* k6527 in k6520 in k6517 in k6514 in k6511 in k6508 in k6505 in k6496 in a6493 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6529,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6545,a[2]=t1,a[3]=((C_word*)t0)[9],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6547,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=t7,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_6547(t9,t5,((C_word*)t0)[2]);}

/* expand in k6527 in k6520 in k6517 in k6514 in k6511 in k6508 in k6505 in k6496 in a6493 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_6547(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6547,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6563,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t3,a[11]=((C_word*)t0)[9],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[223],t3,lf[224]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[225]);}}

/* k6561 in expand in k6527 in k6520 in k6517 in k6514 in k6511 in k6508 in k6505 in k6496 in a6493 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6569,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[10]);
C_trace("c792");
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k6567 in k6561 in expand in k6527 in k6520 in k6517 in k6514 in k6511 in k6508 in k6505 in k6496 in a6493 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6569,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6576,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
C_trace("##sys#append");
t4=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6619,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6623,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6625,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[8]);
C_trace("map");
t6=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a6624 in k6567 in k6561 in expand in k6527 in k6520 in k6517 in k6514 in k6511 in k6508 in k6505 in k6496 in a6493 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6625(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6625,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k6621 in k6567 in k6561 in expand in k6527 in k6520 in k6517 in k6514 in k6511 in k6508 in k6505 in k6496 in a6493 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6617 in k6567 in k6561 in expand in k6527 in k6520 in k6517 in k6514 in k6511 in k6508 in k6505 in k6496 in a6493 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6619,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6611,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("##sys#append");
t5=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k6609 in k6617 in k6567 in k6561 in expand in k6527 in k6520 in k6517 in k6514 in k6511 in k6508 in k6505 in k6496 in a6493 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6611,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6607,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("expand809");
t4=((C_word*)((C_word*)t0)[3])[1];
f_6547(t4,t3,((C_word*)t0)[2]);}

/* k6605 in k6609 in k6617 in k6567 in k6561 in expand in k6527 in k6520 in k6517 in k6514 in k6511 in k6508 in k6505 in k6496 in a6493 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6607,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k6574 in k6567 in k6561 in expand in k6527 in k6520 in k6517 in k6514 in k6511 in k6508 in k6505 in k6496 in a6493 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6576,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6543 in k6527 in k6520 in k6517 in k6514 in k6511 in k6508 in k6505 in k6496 in a6493 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6545,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k6490 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[223],C_SCHEME_END_OF_LIST,t1);}

/* k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1964,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6060,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6062,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6062,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6066,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[211],t2,lf[222]);}

/* k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6066,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6078,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_trace("r835");
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[206]);}

/* k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6078,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6081,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("r835");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[194]);}

/* k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6081,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6084,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("r835");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[81]);}

/* k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6087,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("r835");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[153]);}

/* k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6087,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6090,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("r835");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[188]);}

/* k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6090,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6093,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
C_trace("r835");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[94]);}

/* k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6093,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6095,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6192,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6381,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
C_trace("##sys#check-syntax");
t5=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[211],((C_word*)t0)[2],lf[221]);}

/* k6379 in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6384,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
C_trace("##sys#check-syntax");
t3=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[211],((C_word*)t0)[8],lf[220]);}

/* k6382 in k6379 in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6387,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
C_trace("map");
t3=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[153]+1),((C_word*)t0)[2]);}

/* k6385 in k6382 in k6379 in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6388,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6403,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6480,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t5=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a6479 in k6385 in k6382 in k6379 in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6480(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6480,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6488,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("prefix-sym902");
f_6388(t3,lf[219],t2);}

/* k6486 in a6479 in k6385 in k6382 in k6379 in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("r835");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6401 in k6385 in k6382 in k6379 in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6406,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
C_trace("map");
t3=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[218]+1),((C_word*)t0)[2]);}

/* k6404 in k6401 in k6385 in k6382 in k6379 in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6409,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
C_trace("r835");
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[217]);}

/* k6407 in k6404 in k6401 in k6385 in k6382 in k6379 in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6412,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
C_trace("r835");
t3=((C_word*)t0)[7];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[216]);}

/* k6410 in k6407 in k6404 in k6401 in k6385 in k6382 in k6379 in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6415,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t1,a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t4=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[12]);}

/* a6469 in k6410 in k6407 in k6404 in k6401 in k6385 in k6382 in k6379 in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6470(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6470,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6478,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("prefix-sym902");
f_6388(t3,lf[215],t2);}

/* k6476 in a6469 in k6410 in k6407 in k6404 in k6401 in k6385 in k6382 in k6379 in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("r835");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6413 in k6410 in k6407 in k6404 in k6401 in k6385 in k6382 in k6379 in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6415,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6418,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
C_trace("make-default-procs847");
t3=((C_word*)t0)[3];
f_6095(t3,t2,((C_word*)t0)[4],((C_word*)t0)[8],t1,((C_word*)t0)[2]);}

/* k6416 in k6413 in k6410 in k6407 in k6404 in k6401 in k6385 in k6382 in k6379 in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6421,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
C_trace("make-if-tree848");
t3=((C_word*)t0)[4];
f_6192(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],((C_word*)t0)[11]);}

/* k6419 in k6416 in k6413 in k6410 in k6407 in k6404 in k6401 in k6385 in k6382 in k6379 in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6428,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
C_trace("r835");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[214]);}

/* k6426 in k6419 in k6416 in k6413 in k6410 in k6407 in k6404 in k6401 in k6385 in k6382 in k6379 in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6428,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)t0)[4]);
t9=(C_word)C_a_i_cons(&a,2,t3,t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t9,t10);
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,t1,t11));}

/* prefix-sym in k6385 in k6382 in k6379 in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_6388(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6388,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6396,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6400,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("symbol->string");
t6=*((C_word*)lf[86]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}

/* k6398 in prefix-sym in k6385 in k6382 in k6379 in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("string-append");
t2=*((C_word*)lf[213]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6394 in prefix-sym in k6385 in k6382 in k6379 in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("string->symbol");
t2=*((C_word*)lf[7]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* make-if-tree in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_6192(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6192,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6198,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=((C_word*)t0)[6],a[9]=t5,tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_6198(t9,t1,t2,t3,C_SCHEME_END_OF_LIST);}

/* recur in make-if-tree in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_6198(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6198,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[149],t7);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6260,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=t8,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("reverse");
t10=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t4);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[206],t6);
t8=(C_word)C_i_car(t3);
t9=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6374,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=t7,a[9]=((C_word*)t0)[3],a[10]=((C_word*)t0)[4],a[11]=t5,a[12]=((C_word*)t0)[5],a[13]=((C_word*)t0)[9],a[14]=t8,tmp=(C_word)a,a+=15,tmp);
C_trace("reverse");
t10=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t4);}}

/* k6372 in recur in make-if-tree in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6374,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[14],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t6,t11);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6318,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t2,a[6]=((C_word*)t0)[9],a[7]=t12,tmp=(C_word)a,a+=8,tmp);
t14=(C_word)C_i_cdr(((C_word*)t0)[5]);
t15=(C_word)C_i_cdr(((C_word*)t0)[4]);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],((C_word*)t0)[3]);
C_trace("recur881");
t17=((C_word*)((C_word*)t0)[2])[1];
f_6198(t17,t13,t14,t15,t16);}

/* k6316 in k6372 in recur in make-if-tree in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6318,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k6258 in recur in make-if-tree in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6260,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[212],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[91],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[203],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[87],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t2,t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t11);
t13=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t12));}

/* make-default-procs in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_6095(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6095,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6103,a[2]=t4,a[3]=t5,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
C_trace("reverse");
t7=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}

/* k6101 in make-default-procs in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6103,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6107,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("reverse");
t3=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6105 in k6101 in make-default-procs in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6107,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6111,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("reverse");
t3=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6109 in k6105 in k6101 in make-default-procs in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6111,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6113,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_6113(t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* recur in k6109 in k6105 in k6101 in make-default-procs in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_6113(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6113,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6166,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=t7,a[8]=((C_word*)t0)[3],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
C_trace("reverse");
t9=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t6);}}

/* k6164 in recur in k6109 in k6105 in k6101 in make-default-procs in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6166,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6178,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6182,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("reverse");
t4=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6180 in k6164 in recur in k6109 in k6105 in k6101 in make-default-procs in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6182,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
C_trace("##sys#append");
t4=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k6176 in k6164 in recur in k6109 in k6105 in k6101 in make-default-procs in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6178,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6134,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
t11=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("recur858");
t12=((C_word*)((C_word*)t0)[3])[1];
f_6113(t12,t8,((C_word*)t0)[2],t9,t10,t11);}

/* k6132 in k6176 in k6164 in recur in k6109 in k6105 in k6101 in make-default-procs in k6091 in k6088 in k6085 in k6082 in k6079 in k6076 in k6064 in a6061 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6134,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6058 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[211],C_SCHEME_END_OF_LIST,t1);}

/* k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1967,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5876,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5878,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a5877 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5878(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5878,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5882,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[208],t2,lf[210]);}

/* k5880 in a5877 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5885,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("r936");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[205]);}

/* k5883 in k5880 in a5877 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("r936");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[206]);}

/* k5886 in k5883 in k5880 in a5877 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5888,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("r936");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[194]);}

/* k5889 in k5886 in k5883 in k5880 in a5877 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5898,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("r936");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[81]);}

/* k5896 in k5889 in k5886 in k5883 in k5880 in a5877 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5898,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_i_cddr(((C_word*)t0)[7]);
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5933,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_nullp(t8))){
t10=t9;
f_5933(2,t10,C_SCHEME_FALSE);}
else{
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
t11=t9;
f_5933(2,t11,(C_word)C_i_car(t8));}
else{
C_trace("##sys#error");
t11=*((C_word*)lf[87]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,lf[0],t8);}}}

/* k5931 in k5896 in k5889 in k5886 in k5883 in k5880 in a5877 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6017,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("r936");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[188]);}

/* k6015 in k5931 in k5896 in k5889 in k5886 in k5883 in k5880 in a5877 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_6017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6017,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[149],t6);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5993,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t7,a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
C_trace("r936");
t9=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,lf[153]);}

/* k5991 in k6015 in k5931 in k5896 in k5889 in k5886 in k5883 in k5880 in a5877 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[60],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5993,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[209],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[91],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[203],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[87],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t3,t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t12);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t15);
t17=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t19);
t21=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t20));}

/* k5874 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[208],C_SCHEME_END_OF_LIST,t1);}

/* k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5574,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5576,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a5575 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5576,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5580,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[201],t2,lf[207]);}

/* k5578 in a5575 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5580,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5592,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_trace("r958");
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[81]);}

/* k5590 in k5578 in a5575 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("r958");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[194]);}

/* k5593 in k5590 in k5578 in a5575 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5598,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("r958");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[206]);}

/* k5596 in k5593 in k5590 in k5578 in a5575 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("r958");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[153]);}

/* k5599 in k5596 in k5593 in k5590 in k5578 in a5575 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("r958");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[188]);}

/* k5602 in k5599 in k5596 in k5593 in k5590 in k5578 in a5575 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
C_trace("r958");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[205]);}

/* k5605 in k5602 in k5599 in k5596 in k5593 in k5590 in k5578 in a5575 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5607,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5626,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5628,a[2]=((C_word*)t0)[3],a[3]=t7,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_5628(t9,t5,t1,((C_word*)t0)[2]);}

/* loop in k5605 in k5602 in k5599 in k5596 in k5593 in k5590 in k5578 in a5575 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_5628(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5628,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[149],t6);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5694,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=t7,a[5]=t2,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
C_trace("##sys#append");
t9=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5718,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
C_trace("r958");
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[204]);}
else{
t5=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5856,a[2]=((C_word*)t0)[8],a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#append");
t9=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}}}

/* k5854 in loop in k5605 in k5602 in k5599 in k5596 in k5593 in k5590 in k5578 in a5575 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5856,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k5716 in loop in k5605 in k5602 in k5599 in k5596 in k5593 in k5590 in k5578 in a5575 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[77],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5718,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[11]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[11]);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t5,t8);
t10=(C_word)C_a_i_cons(&a,2,t4,t9);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t2,t12);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t14);
t16=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,lf[91],t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t19=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t18);
t20=(C_word)C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,t17,t20);
t22=(C_word)C_a_i_cons(&a,2,t15,t21);
t23=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t22);
t24=(C_word)C_a_i_cons(&a,2,t23,C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,t1,t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,t13,t26);
t28=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5737,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t27,tmp=(C_word)a,a+=5,tmp);
t29=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("loop978");
t30=((C_word*)((C_word*)t0)[2])[1];
f_5628(t30,t28,t1,t29);}

/* k5735 in k5716 in loop in k5605 in k5602 in k5599 in k5596 in k5593 in k5590 in k5578 in a5575 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5737,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k5692 in loop in k5605 in k5602 in k5599 in k5596 in k5593 in k5590 in k5578 in a5575 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5694,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[202],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[91],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[203],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[87],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t3,t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t12);
t14=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t13));}

/* k5624 in k5605 in k5602 in k5599 in k5596 in k5593 in k5590 in k5578 in a5575 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5626,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k5572 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[201],C_SCHEME_END_OF_LIST,t1);}

/* k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1973,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5153,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5155,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5155(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5155,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5159,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[182],t2,lf[200]);}

/* k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5161,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5196,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("require");
t4=C_retrieve(lf[198]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[199]);}

/* k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5199,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5553,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5555,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("map");
t6=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a5554 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5555(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5555,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5565,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#decompose-lambda-list");
t5=C_retrieve(lf[192]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a5564 in a5554 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5565(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5565,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k5551 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[197]+1),t1);}

/* k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5199,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5202,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("genvars1006");
t3=((C_word*)t0)[2];
f_5161(t3,t2,t1);}

/* k5200 in k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("r1003");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[196]);}

/* k5203 in k5200 in k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5208,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("r1003");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[195]);}

/* k5206 in k5203 in k5200 in k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5208,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5211,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("r1003");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[94]);}

/* k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5211,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5214,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("r1003");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[81]);}

/* k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5217,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("r1003");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[194]);}

/* k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5228,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
C_trace("append");
t3=*((C_word*)lf[36]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[4],((C_word*)t0)[10]);}

/* k5226 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5228,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[183],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5252,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,a[5]=((C_word*)t0)[9],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5254,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("fold-right");
t10=C_retrieve(lf[78]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t7,t8,lf[193],t9);}

/* a5253 in k5226 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5254(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5254,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5264,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t3,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
C_trace("##sys#decompose-lambda-list");
t6=C_retrieve(lf[192]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t4,t5);}

/* a5263 in a5253 in k5226 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5264(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5264,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_5268,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=((C_word*)t0)[8],a[11]=t1,a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=t3,tmp=(C_word)a,a+=15,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("##sys#check-syntax");
t7=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,lf[182],t6,lf[191]);}

/* k5266 in a5263 in a5253 in k5226 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5268,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[14],((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5282,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[6])){
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=t3;
f_5282(t5,C_SCHEME_TRUE);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5502,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("r1003");
t6=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[189]);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5517,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("r1003");
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[190]);}}

/* k5515 in k5266 in a5263 in a5253 in k5226 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5517,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_5282(t4,(C_word)C_a_i_cons(&a,2,t1,t3));}

/* k5500 in k5266 in a5263 in a5253 in k5226 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5502,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_5282(t4,(C_word)C_a_i_cons(&a,2,t1,t3));}

/* k5280 in k5266 in a5263 in a5253 in k5226 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_5282(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5282,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5290,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=t1,a[5]=((C_word*)t0)[13],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5296,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5306,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t2,t3,t4);}

/* a5305 in k5280 in k5266 in a5263 in a5253 in k5226 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5306(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5306,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5310,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5333,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_5333(t8,t4,t3,((C_word*)t0)[2]);}

/* build in a5305 in k5280 in k5266 in a5263 in a5253 in k5226 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_5333(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5333,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[6])){
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5358,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("##sys#append");
t9=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cadr(((C_word*)t0)[4]));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5390,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("##sys#append");
t7=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}}}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5489,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("gensym");
t6=C_retrieve(lf[65]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}}

/* k5487 in build in a5305 in k5280 in k5266 in a5263 in a5253 in k5226 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("r1003");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5399 in build in a5305 in k5280 in k5266 in a5263 in a5253 in k5226 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5401,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5481,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=t2,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
C_trace("r1003");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[153]);}

/* k5479 in k5399 in build in a5305 in k5280 in k5266 in a5263 in a5253 in k5226 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5481,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5461,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
C_trace("r1003");
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[188]);}

/* k5459 in k5479 in k5399 in build in a5305 in k5280 in k5266 in a5263 in a5253 in k5226 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5461,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5420,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("build1074");
t11=((C_word*)((C_word*)t0)[2])[1];
f_5333(t11,t8,t10,((C_word*)t0)[7]);}
else{
C_trace("build1074");
t10=((C_word*)((C_word*)t0)[2])[1];
f_5333(t10,t8,C_SCHEME_END_OF_LIST,((C_word*)t0)[7]);}}

/* k5418 in k5459 in k5479 in k5399 in build in a5305 in k5280 in k5266 in a5263 in a5253 in k5226 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5420,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k5388 in build in a5305 in k5280 in k5266 in a5263 in a5253 in k5226 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5390,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k5356 in build in a5305 in k5280 in k5266 in a5263 in a5253 in k5226 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5358,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k5308 in a5305 in k5280 in k5266 in a5263 in a5253 in k5226 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5310,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5327,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("map");
t3=*((C_word*)lf[186]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[187]+1),((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k5325 in k5308 in a5305 in k5280 in k5266 in a5263 in a5253 in k5226 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5327,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* a5295 in k5280 in k5266 in a5263 in a5253 in k5226 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5304,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("take");
t3=C_retrieve(lf[185]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5302 in a5295 in k5280 in k5266 in a5263 in a5253 in k5226 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("split-at!");
t2=C_retrieve(lf[184]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5288 in k5280 in k5266 in a5263 in a5253 in k5226 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5290,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k5250 in k5226 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5252,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t6));}

/* genvars in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_5161(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5161,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5167,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_5167(t6,t1,C_fix(0));}

/* loop in genvars in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_5167(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5167,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5181,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5193,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("gensym");
t5=C_retrieve(lf[65]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k5191 in loop in genvars in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("r1003");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5179 in loop in genvars in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5181,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5185,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
C_trace("loop1012");
t4=((C_word*)((C_word*)t0)[2])[1];
f_5167(t4,t2,t3);}

/* k5183 in k5179 in loop in genvars in k5157 in a5154 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5185,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5151 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[182],C_SCHEME_END_OF_LIST,t1);}

/* k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1976,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5055,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5057,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a5056 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5057(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5057,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5061,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[177],t2,lf[181]);}

/* k5059 in a5056 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5061,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5076,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,lf[177],t5,lf[179]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5126,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,lf[177],t5,lf[180]);}}

/* k5124 in k5059 in a5056 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5126,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[91],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5141,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#append");
t5=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5139 in k5124 in k5059 in a5056 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5141,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[178],t2));}

/* k5074 in k5059 in a5056 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5076,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(0));
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[91],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5099,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("r1112");
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[94]);}

/* k5097 in k5074 in k5059 in a5056 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5099,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5111,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#append");
t4=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5109 in k5097 in k5074 in k5059 in a5056 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5111,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[178],t5));}

/* k5053 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[177],C_SCHEME_END_OF_LIST,t1);}

/* k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1979,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4861,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4863,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a4862 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4863(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4863,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4867,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[163],t2,lf[176]);}

/* k4865 in a4862 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4870,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("r1137");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[175]);}

/* k4868 in k4865 in a4862 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4873,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("r1137");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[174]);}

/* k4871 in k4868 in k4865 in a4862 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4876,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("r1137");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[94]);}

/* k4874 in k4871 in k4868 in k4865 in a4862 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4876,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4887,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("r1137");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[173]);}

/* k4885 in k4874 in k4871 in k4868 in k4865 in a4862 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4887,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4915,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
C_trace("r1137");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[172]);}

/* k4913 in k4885 in k4874 in k4871 in k4868 in k4865 in a4862 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4915,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_i_caddr(((C_word*)t0)[8]);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t3,t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t11);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t12,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t14=(C_word)C_i_cdddr(((C_word*)t0)[8]);
C_trace("##sys#append");
t15=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,t14,C_SCHEME_END_OF_LIST);}

/* k5005 in k4913 in k4885 in k4874 in k4871 in k4868 in k4865 in a4862 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_5007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word ab[84],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5007,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[169],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[170],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[94],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t12);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t3,t15);
t17=(C_word)C_a_i_cons(&a,2,lf[171],t16);
t18=(C_word)C_a_i_cons(&a,2,t17,C_SCHEME_END_OF_LIST);
t19=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t18);
t20=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t19);
t21=(C_word)C_a_i_cons(&a,2,t20,C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t21);
t23=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t22);
t24=(C_word)C_a_i_cons(&a,2,t23,C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t24);
t26=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t25);
t27=(C_word)C_a_i_cons(&a,2,t26,C_SCHEME_END_OF_LIST);
t28=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t27);
t29=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,(C_word)C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST));}

/* k4859 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[163],C_SCHEME_END_OF_LIST,t1);}

/* k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4534,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4536,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a4535 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4536(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4536,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4540,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[158],t2,lf[168]);}

/* k4538 in a4535 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4543,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("r1150");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[167]);}

/* k4541 in k4538 in a4535 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4546,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("r1150");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[166]);}

/* k4544 in k4541 in k4538 in a4535 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("r1150");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[165]);}

/* k4547 in k4544 in k4541 in k4538 in a4535 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("r1150");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[81]);}

/* k4550 in k4547 in k4544 in k4541 in k4538 in a4535 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("r1150");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[164]);}

/* k4553 in k4550 in k4547 in k4544 in k4541 in k4538 in a4535 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("r1150");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[127]);}

/* k4556 in k4553 in k4550 in k4547 in k4544 in k4541 in k4538 in a4535 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4560,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4733,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("r1150");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[163]);}

/* k4731 in k4556 in k4553 in k4550 in k4547 in k4544 in k4541 in k4538 in a4535 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4733,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[159],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[91],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[146],t5);
t7=(C_word)C_a_i_cons(&a,2,C_fix(1),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[160],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t6,t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4773,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t15,tmp=(C_word)a,a+=10,tmp);
C_trace("r1150");
t17=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t17))(3,t17,t16,lf[162]);}

/* k4771 in k4731 in k4556 in k4553 in k4550 in k4547 in k4544 in k4541 in k4538 in a4535 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4777,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4781,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[7]);
C_trace("map");
t5=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}

/* k4779 in k4771 in k4731 in k4556 in k4553 in k4550 in k4547 in k4544 in k4541 in k4538 in a4535 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4781,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[161],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
C_trace("##sys#append");
t7=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[2],t1,t6);}

/* k4775 in k4771 in k4731 in k4556 in k4553 in k4550 in k4547 in k4544 in k4541 in k4538 in a4535 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4777,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_i_cadr(((C_word*)t0)[5]);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t5,t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* parse-clause in k4556 in k4553 in k4550 in k4547 in k4544 in k4541 in k4538 in a4535 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4560(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[38],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4560,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_symbolp(t3);
t5=(C_truep(t4)?(C_word)C_i_car(t2):C_SCHEME_FALSE);
t6=(C_truep(t5)?(C_word)C_i_cadr(t2):(C_word)C_i_car(t2));
t7=(C_truep(t5)?(C_word)C_i_cddr(t2):(C_word)C_i_cdr(t2));
if(C_truep((C_word)C_i_nullp(t6))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4587,a[2]=((C_word*)t0)[7],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t5,t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4602,a[2]=((C_word*)t0)[5],a[3]=t8,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#append");
t13=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t12,t7,C_SCHEME_END_OF_LIST);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4621,a[2]=((C_word*)t0)[5],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#append");
t10=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t7,C_SCHEME_END_OF_LIST);}}
else{
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4678,a[2]=t7,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4682,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t11=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,t6);}}

/* a4683 in parse-clause in k4556 in k4553 in k4550 in k4547 in k4544 in k4541 in k4538 in a4535 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4684(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4684,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[91],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t6));}

/* k4680 in parse-clause in k4556 in k4553 in k4550 in k4547 in k4544 in k4541 in k4538 in a4535 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4676 in parse-clause in k4556 in k4553 in k4550 in k4547 in k4544 in k4541 in k4538 in a4535 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4678,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4636,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[5])){
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4651,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#append");
t9=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4670,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#append");
t6=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}

/* k4668 in k4676 in parse-clause in k4556 in k4553 in k4550 in k4547 in k4544 in k4541 in k4538 in a4535 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4670,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
f_4636(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k4649 in k4676 in parse-clause in k4556 in k4553 in k4550 in k4547 in k4544 in k4541 in k4538 in a4535 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4651,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_4636(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k4634 in k4676 in parse-clause in k4556 in k4553 in k4550 in k4547 in k4544 in k4541 in k4538 in a4535 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_4636(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4636,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k4619 in parse-clause in k4556 in k4553 in k4550 in k4547 in k4544 in k4541 in k4538 in a4535 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4621,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
f_4587(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k4600 in parse-clause in k4556 in k4553 in k4550 in k4547 in k4544 in k4541 in k4538 in a4535 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4602,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_4587(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k4585 in parse-clause in k4556 in k4553 in k4550 in k4547 in k4544 in k4541 in k4538 in a4535 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_4587(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4587,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k4532 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[158],C_SCHEME_END_OF_LIST,t1);}

/* k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4159,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4161,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a4160 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4161,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4165,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[144],t2,lf[157]);}

/* k4163 in a4160 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4165,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cadddr(((C_word*)t0)[4]);
t5=(C_word)C_i_cddddr(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4180,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
C_trace("r1210");
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[64]);}

/* k4178 in k4163 in a4160 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("r1210");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[94]);}

/* k4181 in k4178 in k4163 in a4160 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4186,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("r1210");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[95]);}

/* k4184 in k4181 in k4178 in k4163 in a4160 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4186,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4192,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
C_trace("r1210");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[156]);}

/* k4190 in k4184 in k4181 in k4178 in k4163 in a4160 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4195,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
C_trace("r1210");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[155]);}

/* k4193 in k4190 in k4184 in k4181 in k4178 in k4163 in a4160 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4198,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
C_trace("r1210");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[154]);}

/* k4196 in k4193 in k4190 in k4184 in k4181 in k4178 in k4163 in a4160 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4201,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
C_trace("map");
t3=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[153]+1),((C_word*)t0)[3]);}

/* k4199 in k4196 in k4193 in k4190 in k4184 in k4181 in k4178 in k4163 in a4160 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4201,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[91],t2);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4513,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t3,tmp=(C_word)a,a+=14,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4517,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4519,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t7=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t1);}

/* a4518 in k4199 in k4196 in k4193 in k4190 in k4184 in k4181 in k4178 in k4163 in a4160 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4519(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4519,3,t0,t1,t2);}
t3=(C_word)C_i_memq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:lf[152]));}

/* k4515 in k4199 in k4196 in k4193 in k4190 in k4184 in k4181 in k4178 in k4163 in a4160 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4511 in k4199 in k4196 in k4193 in k4190 in k4184 in k4181 in k4178 in k4163 in a4160 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[65],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4513,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[145],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[91],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[146],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,t8,t14);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t15);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4224,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t6,a[5]=t16,tmp=(C_word)a,a+=6,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4228,a[2]=t17,tmp=(C_word)a,a+=3,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4230,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t20,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp));
t22=((C_word*)t20)[1];
f_4230(t22,t18,((C_word*)t0)[2],C_fix(1));}

/* loop in k4511 in k4199 in k4196 in k4193 in k4190 in k4184 in k4181 in k4178 in k4163 in a4160 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_4230(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word ab[114],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4230,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_memq(lf[147],C_retrieve(lf[51]));
t6=(C_word)C_i_cddr(t4);
t7=(C_word)C_i_pairp(t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[91],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[148],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,lf[149],t14);
t16=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t16);
t18=(C_word)C_a_i_cons(&a,2,lf[150],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,t15,t19);
t21=(C_word)C_a_i_cons(&a,2,t8,t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t21);
t23=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4256,a[2]=((C_word*)t0)[3],a[3]=t22,a[4]=t5,a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=t2,a[9]=t1,a[10]=((C_word*)t0)[5],a[11]=t4,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t7)){
t24=(C_word)C_i_caddr(t4);
t25=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t26=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t25);
t27=(C_word)C_a_i_cons(&a,2,t24,t26);
t28=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t29=(C_word)C_a_i_cons(&a,2,lf[91],t28);
t30=(C_word)C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t30);
t32=(C_word)C_a_i_cons(&a,2,lf[148],t31);
t33=(C_word)C_a_i_cons(&a,2,t32,C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,lf[149],t33);
t35=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t36=(C_word)C_a_i_cons(&a,2,t3,t35);
t37=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t36);
t38=(C_word)C_a_i_cons(&a,2,lf[151],t37);
t39=(C_word)C_a_i_cons(&a,2,t38,C_SCHEME_END_OF_LIST);
t40=(C_word)C_a_i_cons(&a,2,t34,t39);
t41=(C_word)C_a_i_cons(&a,2,t27,t40);
t42=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t41);
t43=t23;
f_4256(t43,(C_word)C_a_i_cons(&a,2,t42,C_SCHEME_END_OF_LIST));}
else{
t24=t23;
f_4256(t24,C_SCHEME_END_OF_LIST);}}}

/* k4254 in loop in k4511 in k4199 in k4196 in k4193 in k4190 in k4184 in k4181 in k4178 in k4163 in a4160 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_4256(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4256,NULL,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4296,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[4]:C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[11]);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t6);
t8=t3;
f_4296(t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}
else{
t5=t3;
f_4296(t5,((C_word*)t0)[3]);}}

/* k4294 in k4254 in loop in k4511 in k4199 in k4196 in k4193 in k4190 in k4184 in k4181 in k4178 in k4163 in a4160 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_4296(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4296,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4268,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4272,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
t8=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
C_trace("loop1247");
t9=((C_word*)((C_word*)t0)[2])[1];
f_4230(t9,t6,t7,t8);}

/* k4270 in k4294 in k4254 in loop in k4511 in k4199 in k4196 in k4193 in k4190 in k4184 in k4181 in k4178 in k4163 in a4160 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4266 in k4294 in k4254 in loop in k4511 in k4199 in k4196 in k4193 in k4190 in k4184 in k4181 in k4178 in k4163 in a4160 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4268,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
C_trace("##sys#append");
t3=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4226 in k4511 in k4199 in k4196 in k4193 in k4190 in k4184 in k4181 in k4178 in k4163 in a4160 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4222 in k4511 in k4199 in k4196 in k4193 in k4190 in k4184 in k4181 in k4178 in k4163 in a4160 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4224,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k4157 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[144],C_SCHEME_END_OF_LIST,t1);}

/* k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1988,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3971,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3973,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a3972 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3973(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3973,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3977,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("r1284");
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[142]);}

/* k3975 in a3972 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3980,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("r1284");
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[141]);}

/* k3978 in k3975 in a3972 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("r1284");
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[140]);}

/* k3981 in k3978 in k3975 in a3972 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("r1284");
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[64]);}

/* k3984 in k3981 in k3978 in k3975 in a3972 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3989,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("r1284");
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[94]);}

/* k3987 in k3984 in k3981 in k3978 in k3975 in a3972 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3989,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3998,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_3998(t6,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k3987 in k3984 in k3981 in k3978 in k3975 in a3972 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_3998(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3998,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4008,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
C_trace("reverse");
t7=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4101,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=t3,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t7=(C_word)C_i_car(t2);
C_trace("c1285");
t8=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k4099 in loop in k3987 in k3984 in k3981 in k3978 in k3975 in a3972 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4101,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4104,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4123,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("gensym");
t4=C_retrieve(lf[65]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4129,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
C_trace("c1285");
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k4127 in k4099 in loop in k3987 in k3984 in k3981 in k3978 in k3975 in a3972 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4129,2,t0,t1);}
if(C_truep(t1)){
C_trace("loop1295");
t2=((C_word*)((C_word*)t0)[6])[1];
f_3998(t2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[2]);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
C_trace("loop1295");
t5=((C_word*)((C_word*)t0)[6])[1];
f_3998(t5,((C_word*)t0)[5],t2,((C_word*)t0)[4],t4,C_SCHEME_FALSE);}}

/* k4121 in k4099 in loop in k3987 in k3984 in k3981 in k3978 in k3975 in a3972 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("r1284");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4102 in k4099 in loop in k3987 in k3984 in k3981 in k3978 in k3975 in a3972 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4104,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
C_trace("loop1295");
t5=((C_word*)((C_word*)t0)[3])[1];
f_3998(t5,((C_word*)t0)[2],t2,t3,t4,C_SCHEME_FALSE);}

/* k4006 in loop in k3987 in k3984 in k3981 in k3978 in k3975 in a3972 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4011,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("reverse");
t3=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4009 in k4006 in loop in k3987 in k3984 in k3981 in k3978 in k3975 in a3972 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4011,2,t0,t1);}
if(C_truep(((C_word*)t0)[8])){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4017,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4060,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("gensym");
t4=C_retrieve(lf[65]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4083,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_cdr(t1);
C_trace("##sys#append");
t7=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}}

/* k4081 in k4009 in k4006 in loop in k3987 in k3984 in k3981 in k3978 in k3975 in a3972 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4083,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k4058 in k4009 in k4006 in loop in k3987 in k3984 in k3981 in k3978 in k3975 in a3972 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("r1284");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4015 in k4009 in k4006 in loop in k3987 in k3984 in k3981 in k3978 in k3975 in a3972 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4028,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("##sys#append");
t3=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k4026 in k4015 in k4009 in k4006 in loop in k3987 in k3984 in k3981 in k3978 in k3975 in a3972 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4028,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4048,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
C_trace("##sys#append");
t6=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k4046 in k4026 in k4015 in k4009 in k4006 in loop in k3987 in k3984 in k3981 in k3978 in k3975 in a3972 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_4048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4048,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k3969 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[143],C_SCHEME_END_OF_LIST,t1);}

/* k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3752,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3754,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a3753 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3754(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3754,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3758,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("r1327");
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[81]);}

/* k3756 in a3753 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3758,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3761,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("r1327");
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[94]);}

/* k3759 in k3756 in a3753 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("r1327");
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[142]);}

/* k3762 in k3759 in k3756 in a3753 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3764,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3767,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("r1327");
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[141]);}

/* k3765 in k3762 in k3759 in k3756 in a3753 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3767,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("r1327");
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[140]);}

/* k3768 in k3765 in k3762 in k3759 in k3756 in a3753 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3770,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3779,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_3779(t6,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k3768 in k3765 in k3762 in k3759 in k3756 in a3753 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_3779(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3779,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t2))){
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3789,a[2]=t5,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=t4,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t6,tmp=(C_word)a,a+=10,tmp);
C_trace("reverse");
t8=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3898,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t8=(C_word)C_i_car(t2);
C_trace("c1328");
t9=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t9))(4,t9,t7,((C_word*)t0)[2],t8);}}

/* k3896 in loop in k3768 in k3765 in k3762 in k3759 in k3756 in a3753 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3898,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3901,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3920,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("gensym");
t4=C_retrieve(lf[65]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3926,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[10]);
C_trace("c1328");
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k3924 in k3896 in loop in k3768 in k3765 in k3762 in k3759 in k3756 in a3753 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3926,2,t0,t1);}
if(C_truep(t1)){
C_trace("loop1338");
t2=((C_word*)((C_word*)t0)[8])[1];
f_3779(t2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3932,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3959,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("gensym");
t4=C_retrieve(lf[65]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k3957 in k3924 in k3896 in loop in k3768 in k3765 in k3762 in k3759 in k3756 in a3753 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("r1327");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3930 in k3924 in k3896 in loop in k3768 in k3765 in k3762 in k3759 in k3756 in a3753 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3932,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
t6=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
C_trace("loop1338");
t7=((C_word*)((C_word*)t0)[4])[1];
f_3779(t7,((C_word*)t0)[3],t2,((C_word*)t0)[2],t5,t6,C_SCHEME_FALSE);}

/* k3918 in k3896 in loop in k3768 in k3765 in k3762 in k3759 in k3756 in a3753 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("r1327");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3899 in k3896 in loop in k3768 in k3765 in k3762 in k3759 in k3756 in a3753 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3901,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
C_trace("loop1338");
t5=((C_word*)((C_word*)t0)[4])[1];
f_3779(t5,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2],t4,C_SCHEME_FALSE);}

/* k3787 in loop in k3768 in k3765 in k3762 in k3759 in k3756 in a3753 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3792,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
C_trace("reverse");
t3=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3790 in k3787 in loop in k3768 in k3765 in k3762 in k3759 in k3756 in a3753 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3792,2,t0,t1);}
if(C_truep(((C_word*)t0)[9])){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3798,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3853,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("gensym");
t4=C_retrieve(lf[65]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3888,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(t1);
C_trace("##sys#append");
t5=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}}

/* k3886 in k3790 in k3787 in loop in k3768 in k3765 in k3762 in k3759 in k3756 in a3753 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3888,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k3851 in k3790 in k3787 in loop in k3768 in k3765 in k3762 in k3759 in k3756 in a3753 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("r1327");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3796 in k3790 in k3787 in loop in k3768 in k3765 in k3762 in k3759 in k3756 in a3753 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3821,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("##sys#append");
t3=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k3819 in k3796 in k3790 in k3787 in loop in k3768 in k3765 in k3762 in k3759 in k3756 in a3753 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3821,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3841,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[8]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
C_trace("##sys#append");
t6=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k3839 in k3819 in k3796 in k3790 in k3787 in loop in k3768 in k3765 in k3762 in k3759 in k3756 in a3753 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3841,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t8));}

/* k3750 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[139],C_SCHEME_END_OF_LIST,t1);}

/* k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1994,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3475,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3477,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3477(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3477,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3481,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[122],t2,lf[138]);}

/* k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3481,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3484,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("r1373");
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[74]);}

/* k3482 in k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3487,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("r1373");
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[64]);}

/* k3485 in k3482 in k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3490,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("r1373");
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[137]);}

/* k3488 in k3485 in k3482 in k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3493,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("r1373");
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[136]);}

/* k3491 in k3488 in k3485 in k3482 in k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3496,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("r1373");
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[135]);}

/* k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3496,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[9]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3505,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_3505(t6,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t2,C_SCHEME_FALSE);}

/* loop in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_3505(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3505,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t4))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3515,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3645,a[2]=((C_word*)t0)[9],a[3]=t6,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#append");
t8=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t5,C_SCHEME_END_OF_LIST);}
else{
t7=t6;
f_3515(t7,lf[130]);}}
else{
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=t5,a[7]=t3,a[8]=t1,a[9]=((C_word*)t0)[5],a[10]=t2,a[11]=((C_word*)t0)[6],a[12]=t4,tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_i_car(t4);
t8=t6;
f_3651(t8,(C_word)C_i_pairp(t7));}
else{
t7=t6;
f_3651(t7,C_SCHEME_FALSE);}}}

/* k3649 in loop in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_3651(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3651,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3654,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
C_trace("caar");
t3=*((C_word*)lf[133]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[12]);}
else{
C_trace("syntax-error");
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[8],lf[122],lf[134],((C_word*)t0)[12]);}}

/* k3652 in k3649 in loop in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3654,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3663,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
C_trace("c1374");
t4=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],t1);}

/* k3661 in k3652 in k3649 in loop in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3663,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3678,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3682,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("cdar");
t4=*((C_word*)lf[131]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3688,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
C_trace("c1374");
t3=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k3686 in k3661 in k3652 in k3649 in loop in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3688,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3703,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3707,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("cdar");
t4=*((C_word*)lf[131]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3713,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
C_trace("c1374");
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k3711 in k3686 in k3661 in k3652 in k3649 in loop in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3713,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3720,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
t4=(C_truep(t3)?t3:C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3728,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("cdar");
t6=*((C_word*)lf[131]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3735,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
C_trace("caar");
t3=*((C_word*)lf[133]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k3733 in k3711 in k3686 in k3661 in k3652 in k3649 in loop in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("syntax-error");
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[122],lf[132],t1);}

/* k3726 in k3711 in k3686 in k3661 in k3652 in k3649 in loop in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("append");
t2=*((C_word*)lf[36]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3718 in k3711 in k3686 in k3661 in k3652 in k3649 in loop in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("loop1384");
t2=((C_word*)((C_word*)t0)[6])[1];
f_3505(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3705 in k3686 in k3661 in k3652 in k3649 in loop in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3701 in k3686 in k3661 in k3652 in k3649 in loop in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3703,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
C_trace("loop1384");
t4=((C_word*)((C_word*)t0)[6])[1];
f_3505(t4,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3680 in k3661 in k3652 in k3649 in loop in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3676 in k3661 in k3652 in k3649 in loop in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3678,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
C_trace("loop1384");
t4=((C_word*)((C_word*)t0)[6])[1];
f_3505(t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3643 in loop in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3645,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
f_3515(t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k3513 in loop in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_3515(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3515,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("r1373");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[129]);}

/* k3520 in k3513 in loop in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3630,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("##sys#append");
t3=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k3628 in k3520 in k3513 in loop in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3630,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[123],t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
C_trace("r1373");
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[128]);}

/* k3616 in k3628 in k3520 in k3513 in loop in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3618,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[50],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3614,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
C_trace("##sys#append");
t5=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k3612 in k3616 in k3628 in k3520 in k3513 in loop in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3614,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3550,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("r1373");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[127]);}

/* k3548 in k3612 in k3616 in k3628 in k3520 in k3513 in loop in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3550,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[124]),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[125],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3578,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=t5,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
C_trace("r1373");
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[126]);}

/* k3576 in k3548 in k3612 in k3616 in k3628 in k3520 in k3513 in loop in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3578,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3590,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
C_trace("r1373");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[91]);}

/* k3588 in k3576 in k3548 in k3612 in k3616 in k3628 in k3520 in k3513 in loop in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3590,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[124]),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t4);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3574,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
C_trace("##sys#append");
t7=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k3572 in k3588 in k3576 in k3548 in k3612 in k3616 in k3628 in k3520 in k3513 in loop in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in a3476 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3574,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t8));}

/* k3473 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[122],C_SCHEME_END_OF_LIST,t1);}

/* k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1997,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3371,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3373,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a3372 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3373,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3377,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[119],t2,lf[121]);}

/* k3375 in a3372 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3377,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3383,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("r1438");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[120]);}

/* k3381 in k3375 in a3372 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3383,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3428,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("r1438");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[94]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3467,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
C_trace("##sys#append");
t4=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}}

/* k3465 in k3381 in k3375 in a3372 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3467,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k3426 in k3381 in k3375 in a3372 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3428,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3440,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[2]);
C_trace("##sys#append");
t5=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k3438 in k3426 in k3381 in k3375 in a3372 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3440,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t6,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k3369 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[119],C_SCHEME_END_OF_LIST,t1);}

/* k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_1997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2000,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3263,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3265,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a3264 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3265(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3265,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3269,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[111],t2,lf[118]);}

/* k3267 in a3264 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3269,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[112]:t3);
t6=(C_word)C_i_pairp(t2);
t7=(C_truep(t6)?(C_word)C_i_car(t2):t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3284,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t7,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3343,a[2]=t5,a[3]=t8,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("r1454");
t10=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,lf[94]);}
else{
t9=t8;
f_3284(t9,(C_word)C_i_car(t5));}}

/* k3341 in k3267 in a3264 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3343,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3355,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#append");
t4=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k3353 in k3341 in k3267 in a3264 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3355,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_3284(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k3282 in k3267 in a3264 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_3284(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3284,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3287,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3330,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("eval");
t4=C_retrieve(lf[116]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}
else{
C_trace("syntax-error");
t3=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[111],lf[117],((C_word*)t0)[4]);}}

/* k3328 in k3282 in k3267 in a3264 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3287(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* k3285 in k3282 in k3267 in a3264 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3290,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_cons(&a,2,lf[95],t4);
C_trace("##sys#register-meta-expression");
t6=C_retrieve(lf[115]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t2,t5);}

/* k3288 in k3285 in k3282 in k3267 in a3264 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3290,2,t0,t1);}
if(C_truep(C_retrieve(lf[113]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3300,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("r1454");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[95]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[114]);}}

/* k3298 in k3288 in k3285 in k3282 in k3267 in a3264 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3300,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t1,t3));}

/* k3261 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[111],C_SCHEME_END_OF_LIST,t1);}

/* k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3238,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3240,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a3239 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3240(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3240,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3244,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[108],t2,lf[110]);}

/* k3242 in a3239 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3244,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[109],t4));}

/* k3236 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[108],C_SCHEME_END_OF_LIST,t1);}

/* k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2006,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3228,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3230,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a3229 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3230(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3230,5,t0,t1,t2,t3,t4);}
C_trace("syntax-error");
t5=C_retrieve(lf[47]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,lf[106],lf[107]);}

/* k3226 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[106],C_SCHEME_END_OF_LIST,t1);}

/* k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2009,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#macro-subset");
t3=C_retrieve(lf[44]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2009,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* chicken-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2012,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("register-feature!");
t4=C_retrieve(lf[99]);
((C_proc8)C_retrieve_proc(t4))(8,t4,t3,lf[100],lf[101],lf[102],lf[103],lf[104],lf[105]);}

/* k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2016,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#macro-environment");
t3=C_retrieve(lf[98]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2019,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2926,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2928,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a2927 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2928(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2928,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2935,a[2]=t3,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("r1542");
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[91]);}

/* k2933 in a2927 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2938,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=t2;
f_2938(t4,(C_word)C_i_stringp(t3));}
else{
t3=t2;
f_2938(t3,C_SCHEME_FALSE);}}

/* k2936 in k2933 in a2927 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_2938(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2938,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2941,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=t1;
if(C_truep(t3)){
t4=t2;
f_2941(t4,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_2941(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t2;
f_2941(t4,C_SCHEME_FALSE);}}}

/* k2939 in k2936 in k2933 in a2927 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_2941(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2941,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2947,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t3=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[89],((C_word*)t0)[5],lf[90]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3046,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("##sys#check-syntax");
t3=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[89],((C_word*)t0)[5],lf[96]);}
else{
C_trace("##sys#check-syntax");
t3=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[89],((C_word*)t0)[5],lf[97]);}}}

/* k3044 in k2939 in k2936 in k2933 in a2927 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3046,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_i_cadr(((C_word*)t0)[4]):(C_word)C_i_car(((C_word*)t0)[4]));
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3059,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
C_trace("r1542");
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[95]);}

/* k3057 in k3044 in k2939 in k2936 in k2933 in a2927 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3059,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[91],t4);
t6=(C_truep(((C_word*)t0)[6])?(C_word)C_i_car(((C_word*)t0)[5]):lf[92]);
t7=(C_truep(((C_word*)t0)[6])?(C_word)C_i_caddr(((C_word*)t0)[5]):(C_word)C_i_cadr(((C_word*)t0)[5]));
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,lf[91],t8);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3155,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=t2,a[9]=t5,a[10]=t6,a[11]=t9,tmp=(C_word)a,a+=12,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3157,tmp=(C_word)a,a+=2,tmp);
C_trace("map");
t12=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,((C_word*)t0)[3]);}

/* a3156 in k3057 in k3044 in k2939 in k2936 in k2933 in a2927 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3157(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3157,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k3153 in k3057 in k3044 in k2939 in k2936 in k2933 in a2927 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3155,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[91],t2);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3119,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
C_trace("r1542");
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[94]);}

/* k3117 in k3153 in k3057 in k3044 in k2939 in k2936 in k2933 in a2927 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3127,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3143,tmp=(C_word)a,a+=2,tmp);
C_trace("map");
t4=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3142 in k3117 in k3153 in k3057 in k3044 in k2939 in k2936 in k2933 in a2927 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3143(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3143,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k3125 in k3117 in k3153 in k3057 in k3044 in k2939 in k2936 in k2933 in a2927 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3131,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t3=(C_truep(((C_word*)t0)[3])?(C_word)C_i_cdddr(((C_word*)t0)[2]):(C_word)C_i_cddr(((C_word*)t0)[2]));
C_trace("##sys#append");
t4=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k3129 in k3125 in k3117 in k3153 in k3057 in k3044 in k2939 in k2936 in k2933 in a2927 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3131,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[93],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t10);
t12=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t11));}

/* k2945 in k2939 in k2936 in k2933 in a2927 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2947,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2957,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("r1542");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[64]);}

/* k2955 in k2945 in k2939 in k2936 in k2933 in a2927 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3031,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("r1542");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[63]);}

/* k3029 in k2955 in k2945 in k2939 in k2936 in k2933 in a2927 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3031,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3011,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("r1542");
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[85]);}

/* k3009 in k3029 in k2955 in k2945 in k2939 in k2936 in k2933 in a2927 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_3011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3011,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2981,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cddr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_caddr(((C_word*)t0)[6]);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[84],t12);
t14=t8;
f_2981(t14,(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST));}
else{
t10=t8;
f_2981(t10,C_SCHEME_END_OF_LIST);}}

/* k2979 in k3009 in k3029 in k2955 in k2945 in k2939 in k2936 in k2933 in a2927 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_2981(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2975 in k3009 in k3029 in k2955 in k2945 in k2939 in k2936 in k2933 in a2927 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2977,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k2924 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[89],C_SCHEME_END_OF_LIST,t1);}

/* k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2785,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2787,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a2786 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2787(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2787,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2791,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[83],t2,lf[88]);}

/* k2789 in a2786 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2791,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2803,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_2803(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_2803(2,t7,(C_word)C_i_car(t4));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[87]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k2801 in k2789 in a2786 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2806,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2903,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("gensym");
t4=C_retrieve(lf[65]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2901 in k2801 in k2789 in a2786 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("r1595");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2804 in k2801 in k2789 in a2786 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("r1595");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[64]);}

/* k2811 in k2804 in k2801 in k2789 in a2786 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("r1595");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[63]);}

/* k2881 in k2811 in k2804 in k2801 in k2789 in a2786 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("symbol->string");
t3=*((C_word*)lf[86]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k2897 in k2881 in k2811 in k2804 in k2801 in k2789 in a2786 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2899,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2863,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
C_trace("r1595");
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[85]);}

/* k2861 in k2897 in k2881 in k2811 in k2804 in k2801 in k2789 in a2786 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2863,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2833,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2837,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t9=(C_word)C_i_car(((C_word*)t0)[2]);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t10);
t12=(C_word)C_a_i_cons(&a,2,lf[84],t11);
t13=t8;
f_2837(t13,(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST));}
else{
t9=t8;
f_2837(t9,C_SCHEME_END_OF_LIST);}}

/* k2835 in k2861 in k2897 in k2881 in k2811 in k2804 in k2801 in k2789 in a2786 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_2837(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2831 in k2861 in k2897 in k2881 in k2811 in k2804 in k2801 in k2789 in a2786 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2833,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k2783 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[83],C_SCHEME_END_OF_LIST,t1);}

/* k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2635,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2637,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a2636 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2637,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2641,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[76],t2,lf[82]);}

/* k2639 in a2636 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2641,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2650,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("r1621");
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[81]);}

/* k2648 in k2639 in a2636 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2653,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2773,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t4=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a2772 in k2648 in k2639 in a2636 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2773(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2773,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2781,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("gensym");
t4=C_retrieve(lf[65]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2779 in a2772 in k2648 in k2639 in a2636 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("r1621");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2651 in k2648 in k2639 in a2636 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2664,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2749,tmp=(C_word)a,a+=2,tmp);
C_trace("append-map");
t4=C_retrieve(lf[79]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],t1);}

/* a2748 in k2651 in k2648 in k2639 in a2636 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2749,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cddr(t2);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}}

/* k2662 in k2651 in k2648 in k2639 in a2636 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2672,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2674,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2747,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("##sys#append");
t5=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k2745 in k2662 in k2651 in k2648 in k2639 in a2636 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2747,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
C_trace("fold-right");
t4=C_retrieve(lf[78]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2673 in k2662 in k2651 in k2648 in k2639 in a2636 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2674(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[27],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2674,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t2);
t6=(C_word)C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t3,t9);
t11=(C_word)C_a_i_cons(&a,2,t8,t10);
t12=(C_word)C_a_i_cons(&a,2,t7,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,lf[77],t12));}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t8,t9);
t11=(C_word)C_a_i_cons(&a,2,t7,t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,lf[77],t11));}}

/* k2670 in k2662 in k2651 in k2648 in k2639 in a2636 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2672,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k2633 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[76],C_SCHEME_END_OF_LIST,t1);}

/* k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2028,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2567,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2569,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a2568 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2569,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2573,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[68],t2,lf[75]);}

/* k2571 in a2568 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2573,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2576,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("gensym");
t3=C_retrieve(lf[65]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[66]);}

/* k2574 in k2571 in a2568 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("r1661");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[64]);}

/* k2581 in k2574 in k2571 in a2568 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2607,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("r1661");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[74]);}

/* k2605 in k2581 in k2574 in k2571 in a2568 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2623,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2627,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("string-intersperse");
t5=C_retrieve(lf[72]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,lf[73]);}

/* k2625 in k2605 in k2581 in k2574 in k2571 in a2568 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("sprintf");
t2=C_retrieve(lf[70]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[71],((C_word*)t0)[2],t1);}

/* k2621 in k2605 in k2581 in k2574 in k2571 in a2568 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2623,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[58],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[69],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t5,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k2565 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[68],C_SCHEME_END_OF_LIST,t1);}

/* k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2031,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2511,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2513,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a2512 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2513(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2513,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2517,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[62],t2,lf[67]);}

/* k2515 in a2512 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2520,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("gensym");
t3=C_retrieve(lf[65]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[66]);}

/* k2518 in k2515 in a2512 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("r1672");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[64]);}

/* k2525 in k2518 in k2515 in a2512 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2527,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2543,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("r1672");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[63]);}

/* k2541 in k2525 in k2518 in k2515 in a2512 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2543,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[5]);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,t1,t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k2509 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[62],C_SCHEME_END_OF_LIST,t1);}

/* k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2482,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2484,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a2483 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2484(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2484,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2488,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[58],t2,lf[61]);}

/* k2486 in a2483 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2503,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("##sys#append");
t4=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k2501 in k2486 in a2483 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2503,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[58],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[59],t3));}

/* k2480 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[58],C_SCHEME_END_OF_LIST,t1);}

/* k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2407,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2409,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a2408 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2409(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2409,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2413,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[46],t2,lf[56]);}

/* k2411 in a2408 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2413,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2421,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2428,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2431,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_i_car(t2);
t8=t6;
f_2431(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_2431(t7,C_SCHEME_FALSE);}}

/* k2429 in k2411 in a2408 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_2431(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2431,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_memq(lf[50],C_retrieve(lf[51])))){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("warning");
t3=C_retrieve(lf[52]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],lf[53],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2457,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
C_trace("##compiler#register-compiler-macro");
t5=C_retrieve(lf[54]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,t3,t4,((C_word*)t0)[2]);}}
else{
C_trace("bad1697");
t2=((C_word*)t0)[3];
f_2421(t2,((C_word*)t0)[4]);}}

/* k2455 in k2429 in k2411 in a2408 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2428(2,t2,C_SCHEME_UNDEFINED);}
else{
C_trace("bad1697");
t2=((C_word*)t0)[2];
f_2421(t2,((C_word*)t0)[3]);}}

/* k2426 in k2411 in a2408 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[49]);}

/* bad in k2411 in a2408 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_2421(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2421,NULL,2,t0,t1);}
C_trace("syntax-error");
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,lf[46],lf[48],((C_word*)t0)[2]);}

/* k2405 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[46],C_SCHEME_END_OF_LIST,t1);}

/* k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2040,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#macro-subset");
t3=C_retrieve(lf[44]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2040,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1 /* chicken-ffi-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2044,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2403,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken.scm: 80   argv");
t5=C_retrieve(lf[43]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k2401 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2403,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2382,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2384,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2392,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2396,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken.scm: 81   getenv");
t7=C_retrieve(lf[41]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[42]);}

/* k2394 in k2401 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[39]);
C_trace("chicken.scm: 81   string-split");
t3=C_retrieve(lf[40]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k2390 in k2401 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken.scm: 81   remove");
t2=C_retrieve(lf[38]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2383 in k2401 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2384(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2384,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_string_equal_p(t2,lf[37]));}

/* k2380 in k2401 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken.scm: 79   append");
t2=*((C_word*)lf[36]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2042 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2044,2,t0,t1);}
t2=C_mutate((C_word*)lf[4]+1 /* compiler-arguments ...) */,t1);
t3=C_mutate((C_word*)lf[5]+1 /* process-command-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2046,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2153,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2161,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2173,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t4,t5,t6);}

/* a2172 in k2042 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2173,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2177,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2185,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_2185(t9,t5,((C_word*)t4)[1]);}

/* loop in a2172 in k2042 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_2185(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(26);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2185,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_eqp(lf[13],t3);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2207,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t4);
C_trace("chicken.scm: 114  string->number");
C_string_to_number(3,0,t6,t7);}
else{
t6=(C_word)C_eqp(lf[20],t3);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2270,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_car(t4);
C_trace("chicken.scm: 128  string->number");
C_string_to_number(3,0,t7,t8);}
else{
t7=(C_word)C_eqp(lf[24],t3);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2324,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
C_trace("chicken.scm: 137  cons*");
t9=C_retrieve(lf[14]);
((C_proc11)C_retrieve_proc(t9))(11,t9,t8,lf[25],lf[26],lf[22],lf[16],lf[15],lf[27],lf[28],lf[21],((C_word*)((C_word*)t0)[2])[1]);}
else{
if(C_truep((C_word)C_i_memq(t3,C_retrieve(lf[29])))){
C_trace("chicken.scm: 141  loop");
t17=t1;
t18=t4;
t1=t17;
t2=t18;
goto loop;}
else{
if(C_truep((C_word)C_i_memq(t3,C_retrieve(lf[30])))){
if(C_truep((C_word)C_i_pairp(t4))){
t8=(C_word)C_i_cdr(t4);
C_trace("chicken.scm: 144  loop");
t17=t1;
t18=t8;
t1=t17;
t2=t18;
goto loop;}
else{
C_trace("chicken.scm: 145  quit");
t8=C_retrieve(lf[31]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,lf[32],t3);}}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2361,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2368,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_stringp(t3))){
t10=t9;
f_2368(2,t10,t3);}
else{
C_trace("chicken.scm: 149  conc");
t10=C_retrieve(lf[34]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,lf[35],t3);}}}}}}}}

/* k2366 in loop in a2172 in k2042 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken.scm: 147  compiler-warning");
t2=C_retrieve(lf[17]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[18],lf[33],t1);}

/* k2359 in loop in a2172 in k2042 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken.scm: 150  loop");
t2=((C_word*)((C_word*)t0)[4])[1];
f_2185(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2322 in loop in a2172 in k2042 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
C_trace("chicken.scm: 140  loop");
t3=((C_word*)((C_word*)t0)[4])[1];
f_2185(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2268 in loop in a2172 in k2042 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2273,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
switch(t1){
case C_fix(0):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2287,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("chicken.scm: 130  cons*");
t4=C_retrieve(lf[14]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[21],lf[22],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,lf[22],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_2273(2,t5,t4);
case C_fix(2):
t3=t2;
f_2273(2,t3,C_SCHEME_FALSE);
default:
t3=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("chicken.scm: 133  compiler-warning");
t4=C_retrieve(lf[17]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[18],lf[23],t3);}}

/* k2285 in k2268 in loop in a2172 in k2042 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2273(2,t3,t2);}

/* k2271 in k2268 in loop in a2172 in k2042 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("chicken.scm: 134  loop");
t3=((C_word*)((C_word*)t0)[3])[1];
f_2185(t3,((C_word*)t0)[2],t2);}

/* k2205 in loop in a2172 in k2042 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2210,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
switch(t1){
case C_fix(0):
t3=t2;
f_2210(2,t3,C_SCHEME_FALSE);
case C_fix(1):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2230,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("chicken.scm: 118  cons*");
t4=C_retrieve(lf[14]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[15],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(2):
t3=(C_word)C_a_i_cons(&a,2,lf[15],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_2210(2,t5,t4);
case C_fix(3):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2250,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("chicken.scm: 124  cons*");
t4=C_retrieve(lf[14]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[15],lf[16],((C_word*)((C_word*)t0)[2])[1]);
default:
t3=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("chicken.scm: 125  compiler-warning");
t4=C_retrieve(lf[17]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[18],lf[19],t3);}}

/* k2248 in k2205 in loop in a2172 in k2042 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2210(2,t3,t2);}

/* k2228 in k2205 in loop in a2172 in k2042 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2210(2,t3,t2);}

/* k2208 in k2205 in loop in a2172 in k2042 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("chicken.scm: 126  loop");
t3=((C_word*)((C_word*)t0)[3])[1];
f_2185(t3,((C_word*)t0)[2],t2);}

/* k2175 in a2172 in k2042 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2177,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2180,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t2,C_retrieve(lf[12]),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2178 in k2175 in a2172 in k2042 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken.scm: 152  exit");
t2=C_retrieve(lf[11]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a2160 in k2042 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2161,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2168,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken.scm: 108  user-options-pass");
t3=C_retrieve(lf[10]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2166 in a2160 in k2042 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_retrieve(lf[5]));
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_retrieve(lf[4]));}

/* k2151 in k2042 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2153,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2156,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2159,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#implicit-exit-handler");
t4=C_retrieve(lf[9]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2157 in k2151 in k2042 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k2154 in k2151 in k2042 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##compiler#process-command-line in k2042 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2046(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2046,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2052,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2052(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in ##compiler#process-command-line in k2042 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_2052(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2052,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2066,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("chicken.scm: 93   reverse");
t6=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_string_length(t5);
t7=(C_word)C_i_string_ref(t5,C_fix(0));
t8=(C_word)C_eqp(C_make_character(45),t7);
t9=(C_truep(t8)?(C_word)C_fixnum_greaterp(t6,C_fix(1)):C_SCHEME_FALSE);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2087,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t6,C_fix(1)))){
t11=(C_word)C_i_string_ref(t5,C_fix(1));
t12=t10;
f_2087(t12,(C_word)C_eqp(C_make_character(58),t11));}
else{
t11=t10;
f_2087(t11,C_SCHEME_FALSE);}}
else{
if(C_truep(t4)){
t10=(C_word)C_i_cdr(t2);
t11=(C_word)C_a_i_cons(&a,2,t5,t3);
C_trace("chicken.scm: 102  loop");
t17=t1;
t18=t10;
t19=t11;
t20=t4;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}
else{
t10=(C_word)C_i_cdr(t2);
C_trace("chicken.scm: 103  loop");
t17=t1;
t18=t10;
t19=t3;
t20=t5;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}}}}

/* k2085 in loop in ##compiler#process-command-line in k2042 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_fcall f_2087(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2087,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
C_trace("chicken.scm: 99   loop");
t3=((C_word*)((C_word*)t0)[7])[1];
f_2052(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2109,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2113,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken.scm: 100  substring");
t5=*((C_word*)lf[8]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]);}}

/* k2111 in k2085 in loop in ##compiler#process-command-line in k2042 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken.scm: 100  string->symbol");
t2=*((C_word*)lf[7]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2107 in k2085 in loop in ##compiler#process-command-line in k2042 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2109,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
C_trace("chicken.scm: 100  loop");
t3=((C_word*)((C_word*)t0)[5])[1];
f_2052(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k2064 in loop in ##compiler#process-command-line in k2042 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in k2014 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1914 in k1911 in k1908 in k1905 in k1902 in k1899 in k1896 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 */
static void C_ccall f_2066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken.scm: 93   values");
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[713] = {
{"toplevelchicken.scm",(void*)C_toplevel},
{"f_1843chicken.scm",(void*)f_1843},
{"f_1846chicken.scm",(void*)f_1846},
{"f_1849chicken.scm",(void*)f_1849},
{"f_1852chicken.scm",(void*)f_1852},
{"f_1855chicken.scm",(void*)f_1855},
{"f_1858chicken.scm",(void*)f_1858},
{"f_1861chicken.scm",(void*)f_1861},
{"f_1864chicken.scm",(void*)f_1864},
{"f_1867chicken.scm",(void*)f_1867},
{"f_1870chicken.scm",(void*)f_1870},
{"f_1873chicken.scm",(void*)f_1873},
{"f_1876chicken.scm",(void*)f_1876},
{"f_1879chicken.scm",(void*)f_1879},
{"f_1882chicken.scm",(void*)f_1882},
{"f_1885chicken.scm",(void*)f_1885},
{"f_1888chicken.scm",(void*)f_1888},
{"f_1891chicken.scm",(void*)f_1891},
{"f_1894chicken.scm",(void*)f_1894},
{"f_1898chicken.scm",(void*)f_1898},
{"f_9090chicken.scm",(void*)f_9090},
{"f_9094chicken.scm",(void*)f_9094},
{"f_9103chicken.scm",(void*)f_9103},
{"f_9109chicken.scm",(void*)f_9109},
{"f_9112chicken.scm",(void*)f_9112},
{"f_9115chicken.scm",(void*)f_9115},
{"f_9118chicken.scm",(void*)f_9118},
{"f_9528chicken.scm",(void*)f_9528},
{"f_9488chicken.scm",(void*)f_9488},
{"f_9520chicken.scm",(void*)f_9520},
{"f_9480chicken.scm",(void*)f_9480},
{"f_9436chicken.scm",(void*)f_9436},
{"f_9147chicken.scm",(void*)f_9147},
{"f_9157chicken.scm",(void*)f_9157},
{"f_9424chicken.scm",(void*)f_9424},
{"f_9160chicken.scm",(void*)f_9160},
{"f_9420chicken.scm",(void*)f_9420},
{"f_9163chicken.scm",(void*)f_9163},
{"f_9210chicken.scm",(void*)f_9210},
{"f_9174chicken.scm",(void*)f_9174},
{"f_9145chicken.scm",(void*)f_9145},
{"f_9141chicken.scm",(void*)f_9141},
{"f_9088chicken.scm",(void*)f_9088},
{"f_1901chicken.scm",(void*)f_1901},
{"f_8947chicken.scm",(void*)f_8947},
{"f_8951chicken.scm",(void*)f_8951},
{"f_8954chicken.scm",(void*)f_8954},
{"f_8957chicken.scm",(void*)f_8957},
{"f_8993chicken.scm",(void*)f_8993},
{"f_9008chicken.scm",(void*)f_9008},
{"f_9062chicken.scm",(void*)f_9062},
{"f_9023chicken.scm",(void*)f_9023},
{"f_8986chicken.scm",(void*)f_8986},
{"f_8945chicken.scm",(void*)f_8945},
{"f_1904chicken.scm",(void*)f_1904},
{"f_8848chicken.scm",(void*)f_8848},
{"f_8852chicken.scm",(void*)f_8852},
{"f_8855chicken.scm",(void*)f_8855},
{"f_8858chicken.scm",(void*)f_8858},
{"f_8937chicken.scm",(void*)f_8937},
{"f_8846chicken.scm",(void*)f_8846},
{"f_1907chicken.scm",(void*)f_1907},
{"f_8830chicken.scm",(void*)f_8830},
{"f_8838chicken.scm",(void*)f_8838},
{"f_8828chicken.scm",(void*)f_8828},
{"f_1910chicken.scm",(void*)f_1910},
{"f_8741chicken.scm",(void*)f_8741},
{"f_8745chicken.scm",(void*)f_8745},
{"f_8748chicken.scm",(void*)f_8748},
{"f_8751chicken.scm",(void*)f_8751},
{"f_8817chicken.scm",(void*)f_8817},
{"f_8754chicken.scm",(void*)f_8754},
{"f_8767chicken.scm",(void*)f_8767},
{"f_8811chicken.scm",(void*)f_8811},
{"f_8778chicken.scm",(void*)f_8778},
{"f_8786chicken.scm",(void*)f_8786},
{"f_8788chicken.scm",(void*)f_8788},
{"f_8805chicken.scm",(void*)f_8805},
{"f_8773chicken.scm",(void*)f_8773},
{"f_8765chicken.scm",(void*)f_8765},
{"f_8761chicken.scm",(void*)f_8761},
{"f_8739chicken.scm",(void*)f_8739},
{"f_1913chicken.scm",(void*)f_1913},
{"f_8630chicken.scm",(void*)f_8630},
{"f_8634chicken.scm",(void*)f_8634},
{"f_8643chicken.scm",(void*)f_8643},
{"f_8646chicken.scm",(void*)f_8646},
{"f_8649chicken.scm",(void*)f_8649},
{"f_8692chicken.scm",(void*)f_8692},
{"f_8628chicken.scm",(void*)f_8628},
{"f_1916chicken.scm",(void*)f_1916},
{"f_8493chicken.scm",(void*)f_8493},
{"f_8497chicken.scm",(void*)f_8497},
{"f_8509chicken.scm",(void*)f_8509},
{"f_8512chicken.scm",(void*)f_8512},
{"f_8515chicken.scm",(void*)f_8515},
{"f_8566chicken.scm",(void*)f_8566},
{"f_8562chicken.scm",(void*)f_8562},
{"f_8491chicken.scm",(void*)f_8491},
{"f_1919chicken.scm",(void*)f_1919},
{"f_8235chicken.scm",(void*)f_8235},
{"f_8239chicken.scm",(void*)f_8239},
{"f_8248chicken.scm",(void*)f_8248},
{"f_8479chicken.scm",(void*)f_8479},
{"f_8487chicken.scm",(void*)f_8487},
{"f_8251chicken.scm",(void*)f_8251},
{"f_8469chicken.scm",(void*)f_8469},
{"f_8477chicken.scm",(void*)f_8477},
{"f_8254chicken.scm",(void*)f_8254},
{"f_8257chicken.scm",(void*)f_8257},
{"f_8260chicken.scm",(void*)f_8260},
{"f_8467chicken.scm",(void*)f_8467},
{"f_8427chicken.scm",(void*)f_8427},
{"f_8445chicken.scm",(void*)f_8445},
{"f_8459chicken.scm",(void*)f_8459},
{"f_8439chicken.scm",(void*)f_8439},
{"f_8435chicken.scm",(void*)f_8435},
{"f_8431chicken.scm",(void*)f_8431},
{"f_8271chicken.scm",(void*)f_8271},
{"f_8411chicken.scm",(void*)f_8411},
{"f_8379chicken.scm",(void*)f_8379},
{"f_8397chicken.scm",(void*)f_8397},
{"f_8387chicken.scm",(void*)f_8387},
{"f_8383chicken.scm",(void*)f_8383},
{"f_8375chicken.scm",(void*)f_8375},
{"f_8367chicken.scm",(void*)f_8367},
{"f_8347chicken.scm",(void*)f_8347},
{"f_8315chicken.scm",(void*)f_8315},
{"f_8333chicken.scm",(void*)f_8333},
{"f_8323chicken.scm",(void*)f_8323},
{"f_8319chicken.scm",(void*)f_8319},
{"f_8311chicken.scm",(void*)f_8311},
{"f_8233chicken.scm",(void*)f_8233},
{"f_1922chicken.scm",(void*)f_1922},
{"f_8114chicken.scm",(void*)f_8114},
{"f_8118chicken.scm",(void*)f_8118},
{"f_8124chicken.scm",(void*)f_8124},
{"f_8225chicken.scm",(void*)f_8225},
{"f_8130chicken.scm",(void*)f_8130},
{"f_8133chicken.scm",(void*)f_8133},
{"f_8136chicken.scm",(void*)f_8136},
{"f_8176chicken.scm",(void*)f_8176},
{"f_8199chicken.scm",(void*)f_8199},
{"f_8206chicken.scm",(void*)f_8206},
{"f_8213chicken.scm",(void*)f_8213},
{"f_8189chicken.scm",(void*)f_8189},
{"f_8139chicken.scm",(void*)f_8139},
{"f_8112chicken.scm",(void*)f_8112},
{"f_1925chicken.scm",(void*)f_1925},
{"f_7912chicken.scm",(void*)f_7912},
{"f_7916chicken.scm",(void*)f_7916},
{"f_7925chicken.scm",(void*)f_7925},
{"f_7928chicken.scm",(void*)f_7928},
{"f_7931chicken.scm",(void*)f_7931},
{"f_7934chicken.scm",(void*)f_7934},
{"f_7937chicken.scm",(void*)f_7937},
{"f_8100chicken.scm",(void*)f_8100},
{"f_8108chicken.scm",(void*)f_8108},
{"f_7940chicken.scm",(void*)f_7940},
{"f_8090chicken.scm",(void*)f_8090},
{"f_8098chicken.scm",(void*)f_8098},
{"f_7943chicken.scm",(void*)f_7943},
{"f_8084chicken.scm",(void*)f_8084},
{"f_8088chicken.scm",(void*)f_8088},
{"f_7954chicken.scm",(void*)f_7954},
{"f_8028chicken.scm",(void*)f_8028},
{"f_8026chicken.scm",(void*)f_8026},
{"f_8022chicken.scm",(void*)f_8022},
{"f_8002chicken.scm",(void*)f_8002},
{"f_7910chicken.scm",(void*)f_7910},
{"f_1928chicken.scm",(void*)f_1928},
{"f_7867chicken.scm",(void*)f_7867},
{"f_7871chicken.scm",(void*)f_7871},
{"f_7878chicken.scm",(void*)f_7878},
{"f_7898chicken.scm",(void*)f_7898},
{"f_7902chicken.scm",(void*)f_7902},
{"f_7865chicken.scm",(void*)f_7865},
{"f_1931chicken.scm",(void*)f_1931},
{"f_7814chicken.scm",(void*)f_7814},
{"f_7818chicken.scm",(void*)f_7818},
{"f_7825chicken.scm",(void*)f_7825},
{"f_7853chicken.scm",(void*)f_7853},
{"f_7857chicken.scm",(void*)f_7857},
{"f_7812chicken.scm",(void*)f_7812},
{"f_1934chicken.scm",(void*)f_1934},
{"f_7669chicken.scm",(void*)f_7669},
{"f_7673chicken.scm",(void*)f_7673},
{"f_7682chicken.scm",(void*)f_7682},
{"f_7751chicken.scm",(void*)f_7751},
{"f_7784chicken.scm",(void*)f_7784},
{"f_7782chicken.scm",(void*)f_7782},
{"f_7778chicken.scm",(void*)f_7778},
{"f_7667chicken.scm",(void*)f_7667},
{"f_1937chicken.scm",(void*)f_1937},
{"f_7627chicken.scm",(void*)f_7627},
{"f_7631chicken.scm",(void*)f_7631},
{"f_7651chicken.scm",(void*)f_7651},
{"f_7659chicken.scm",(void*)f_7659},
{"f_7634chicken.scm",(void*)f_7634},
{"f_7641chicken.scm",(void*)f_7641},
{"f_7645chicken.scm",(void*)f_7645},
{"f_7625chicken.scm",(void*)f_7625},
{"f_1940chicken.scm",(void*)f_1940},
{"f_7239chicken.scm",(void*)f_7239},
{"f_7243chicken.scm",(void*)f_7243},
{"f_7252chicken.scm",(void*)f_7252},
{"f_7255chicken.scm",(void*)f_7255},
{"f_7330chicken.scm",(void*)f_7330},
{"f_7583chicken.scm",(void*)f_7583},
{"f_7596chicken.scm",(void*)f_7596},
{"f_7333chicken.scm",(void*)f_7333},
{"f_7569chicken.scm",(void*)f_7569},
{"f_7581chicken.scm",(void*)f_7581},
{"f_7577chicken.scm",(void*)f_7577},
{"f_7336chicken.scm",(void*)f_7336},
{"f_7523chicken.scm",(void*)f_7523},
{"f_7556chicken.scm",(void*)f_7556},
{"f_7563chicken.scm",(void*)f_7563},
{"f_7539chicken.scm",(void*)f_7539},
{"f_7348chicken.scm",(void*)f_7348},
{"f_7517chicken.scm",(void*)f_7517},
{"f_7355chicken.scm",(void*)f_7355},
{"f_7357chicken.scm",(void*)f_7357},
{"f_7511chicken.scm",(void*)f_7511},
{"f_7395chicken.scm",(void*)f_7395},
{"f_7477chicken.scm",(void*)f_7477},
{"f_7434chicken.scm",(void*)f_7434},
{"f_7414chicken.scm",(void*)f_7414},
{"f_7381chicken.scm",(void*)f_7381},
{"f_7389chicken.scm",(void*)f_7389},
{"f_7375chicken.scm",(void*)f_7375},
{"f_7379chicken.scm",(void*)f_7379},
{"f_7337chicken.scm",(void*)f_7337},
{"f_7288chicken.scm",(void*)f_7288},
{"f_7311chicken.scm",(void*)f_7311},
{"f_7315chicken.scm",(void*)f_7315},
{"f_7257chicken.scm",(void*)f_7257},
{"f_7278chicken.scm",(void*)f_7278},
{"f_7237chicken.scm",(void*)f_7237},
{"f_1943chicken.scm",(void*)f_1943},
{"f_7167chicken.scm",(void*)f_7167},
{"f_7171chicken.scm",(void*)f_7171},
{"f_7180chicken.scm",(void*)f_7180},
{"f_7183chicken.scm",(void*)f_7183},
{"f_7188chicken.scm",(void*)f_7188},
{"f_7225chicken.scm",(void*)f_7225},
{"f_7206chicken.scm",(void*)f_7206},
{"f_7165chicken.scm",(void*)f_7165},
{"f_1946chicken.scm",(void*)f_1946},
{"f_7001chicken.scm",(void*)f_7001},
{"f_7005chicken.scm",(void*)f_7005},
{"f_7014chicken.scm",(void*)f_7014},
{"f_7017chicken.scm",(void*)f_7017},
{"f_7157chicken.scm",(void*)f_7157},
{"f_7155chicken.scm",(void*)f_7155},
{"f_7020chicken.scm",(void*)f_7020},
{"f_7139chicken.scm",(void*)f_7139},
{"f_7151chicken.scm",(void*)f_7151},
{"f_7147chicken.scm",(void*)f_7147},
{"f_7023chicken.scm",(void*)f_7023},
{"f_7133chicken.scm",(void*)f_7133},
{"f_7043chicken.scm",(void*)f_7043},
{"f_7057chicken.scm",(void*)f_7057},
{"f_7085chicken.scm",(void*)f_7085},
{"f_7095chicken.scm",(void*)f_7095},
{"f_7111chicken.scm",(void*)f_7111},
{"f_7093chicken.scm",(void*)f_7093},
{"f_7089chicken.scm",(void*)f_7089},
{"f_7051chicken.scm",(void*)f_7051},
{"f_7055chicken.scm",(void*)f_7055},
{"f_7047chicken.scm",(void*)f_7047},
{"f_7024chicken.scm",(void*)f_7024},
{"f_6999chicken.scm",(void*)f_6999},
{"f_1949chicken.scm",(void*)f_1949},
{"f_6927chicken.scm",(void*)f_6927},
{"f_6931chicken.scm",(void*)f_6931},
{"f_6934chicken.scm",(void*)f_6934},
{"f_6937chicken.scm",(void*)f_6937},
{"f_6940chicken.scm",(void*)f_6940},
{"f_6925chicken.scm",(void*)f_6925},
{"f_1952chicken.scm",(void*)f_1952},
{"f_6826chicken.scm",(void*)f_6826},
{"f_6830chicken.scm",(void*)f_6830},
{"f_6917chicken.scm",(void*)f_6917},
{"f_6913chicken.scm",(void*)f_6913},
{"f_6832chicken.scm",(void*)f_6832},
{"f_6836chicken.scm",(void*)f_6836},
{"f_6893chicken.scm",(void*)f_6893},
{"f_6845chicken.scm",(void*)f_6845},
{"f_6867chicken.scm",(void*)f_6867},
{"f_6857chicken.scm",(void*)f_6857},
{"f_6848chicken.scm",(void*)f_6848},
{"f_6824chicken.scm",(void*)f_6824},
{"f_1955chicken.scm",(void*)f_1955},
{"f_6663chicken.scm",(void*)f_6663},
{"f_6667chicken.scm",(void*)f_6667},
{"f_6676chicken.scm",(void*)f_6676},
{"f_6679chicken.scm",(void*)f_6679},
{"f_6684chicken.scm",(void*)f_6684},
{"f_6729chicken.scm",(void*)f_6729},
{"f_6796chicken.scm",(void*)f_6796},
{"f_6758chicken.scm",(void*)f_6758},
{"f_6698chicken.scm",(void*)f_6698},
{"f_6702chicken.scm",(void*)f_6702},
{"f_6661chicken.scm",(void*)f_6661},
{"f_1958chicken.scm",(void*)f_1958},
{"f_6494chicken.scm",(void*)f_6494},
{"f_6498chicken.scm",(void*)f_6498},
{"f_6507chicken.scm",(void*)f_6507},
{"f_6510chicken.scm",(void*)f_6510},
{"f_6513chicken.scm",(void*)f_6513},
{"f_6516chicken.scm",(void*)f_6516},
{"f_6519chicken.scm",(void*)f_6519},
{"f_6522chicken.scm",(void*)f_6522},
{"f_6529chicken.scm",(void*)f_6529},
{"f_6547chicken.scm",(void*)f_6547},
{"f_6563chicken.scm",(void*)f_6563},
{"f_6569chicken.scm",(void*)f_6569},
{"f_6625chicken.scm",(void*)f_6625},
{"f_6623chicken.scm",(void*)f_6623},
{"f_6619chicken.scm",(void*)f_6619},
{"f_6611chicken.scm",(void*)f_6611},
{"f_6607chicken.scm",(void*)f_6607},
{"f_6576chicken.scm",(void*)f_6576},
{"f_6545chicken.scm",(void*)f_6545},
{"f_6492chicken.scm",(void*)f_6492},
{"f_1961chicken.scm",(void*)f_1961},
{"f_6062chicken.scm",(void*)f_6062},
{"f_6066chicken.scm",(void*)f_6066},
{"f_6078chicken.scm",(void*)f_6078},
{"f_6081chicken.scm",(void*)f_6081},
{"f_6084chicken.scm",(void*)f_6084},
{"f_6087chicken.scm",(void*)f_6087},
{"f_6090chicken.scm",(void*)f_6090},
{"f_6093chicken.scm",(void*)f_6093},
{"f_6381chicken.scm",(void*)f_6381},
{"f_6384chicken.scm",(void*)f_6384},
{"f_6387chicken.scm",(void*)f_6387},
{"f_6480chicken.scm",(void*)f_6480},
{"f_6488chicken.scm",(void*)f_6488},
{"f_6403chicken.scm",(void*)f_6403},
{"f_6406chicken.scm",(void*)f_6406},
{"f_6409chicken.scm",(void*)f_6409},
{"f_6412chicken.scm",(void*)f_6412},
{"f_6470chicken.scm",(void*)f_6470},
{"f_6478chicken.scm",(void*)f_6478},
{"f_6415chicken.scm",(void*)f_6415},
{"f_6418chicken.scm",(void*)f_6418},
{"f_6421chicken.scm",(void*)f_6421},
{"f_6428chicken.scm",(void*)f_6428},
{"f_6388chicken.scm",(void*)f_6388},
{"f_6400chicken.scm",(void*)f_6400},
{"f_6396chicken.scm",(void*)f_6396},
{"f_6192chicken.scm",(void*)f_6192},
{"f_6198chicken.scm",(void*)f_6198},
{"f_6374chicken.scm",(void*)f_6374},
{"f_6318chicken.scm",(void*)f_6318},
{"f_6260chicken.scm",(void*)f_6260},
{"f_6095chicken.scm",(void*)f_6095},
{"f_6103chicken.scm",(void*)f_6103},
{"f_6107chicken.scm",(void*)f_6107},
{"f_6111chicken.scm",(void*)f_6111},
{"f_6113chicken.scm",(void*)f_6113},
{"f_6166chicken.scm",(void*)f_6166},
{"f_6182chicken.scm",(void*)f_6182},
{"f_6178chicken.scm",(void*)f_6178},
{"f_6134chicken.scm",(void*)f_6134},
{"f_6060chicken.scm",(void*)f_6060},
{"f_1964chicken.scm",(void*)f_1964},
{"f_5878chicken.scm",(void*)f_5878},
{"f_5882chicken.scm",(void*)f_5882},
{"f_5885chicken.scm",(void*)f_5885},
{"f_5888chicken.scm",(void*)f_5888},
{"f_5891chicken.scm",(void*)f_5891},
{"f_5898chicken.scm",(void*)f_5898},
{"f_5933chicken.scm",(void*)f_5933},
{"f_6017chicken.scm",(void*)f_6017},
{"f_5993chicken.scm",(void*)f_5993},
{"f_5876chicken.scm",(void*)f_5876},
{"f_1967chicken.scm",(void*)f_1967},
{"f_5576chicken.scm",(void*)f_5576},
{"f_5580chicken.scm",(void*)f_5580},
{"f_5592chicken.scm",(void*)f_5592},
{"f_5595chicken.scm",(void*)f_5595},
{"f_5598chicken.scm",(void*)f_5598},
{"f_5601chicken.scm",(void*)f_5601},
{"f_5604chicken.scm",(void*)f_5604},
{"f_5607chicken.scm",(void*)f_5607},
{"f_5628chicken.scm",(void*)f_5628},
{"f_5856chicken.scm",(void*)f_5856},
{"f_5718chicken.scm",(void*)f_5718},
{"f_5737chicken.scm",(void*)f_5737},
{"f_5694chicken.scm",(void*)f_5694},
{"f_5626chicken.scm",(void*)f_5626},
{"f_5574chicken.scm",(void*)f_5574},
{"f_1970chicken.scm",(void*)f_1970},
{"f_5155chicken.scm",(void*)f_5155},
{"f_5159chicken.scm",(void*)f_5159},
{"f_5196chicken.scm",(void*)f_5196},
{"f_5555chicken.scm",(void*)f_5555},
{"f_5565chicken.scm",(void*)f_5565},
{"f_5553chicken.scm",(void*)f_5553},
{"f_5199chicken.scm",(void*)f_5199},
{"f_5202chicken.scm",(void*)f_5202},
{"f_5205chicken.scm",(void*)f_5205},
{"f_5208chicken.scm",(void*)f_5208},
{"f_5211chicken.scm",(void*)f_5211},
{"f_5214chicken.scm",(void*)f_5214},
{"f_5217chicken.scm",(void*)f_5217},
{"f_5228chicken.scm",(void*)f_5228},
{"f_5254chicken.scm",(void*)f_5254},
{"f_5264chicken.scm",(void*)f_5264},
{"f_5268chicken.scm",(void*)f_5268},
{"f_5517chicken.scm",(void*)f_5517},
{"f_5502chicken.scm",(void*)f_5502},
{"f_5282chicken.scm",(void*)f_5282},
{"f_5306chicken.scm",(void*)f_5306},
{"f_5333chicken.scm",(void*)f_5333},
{"f_5489chicken.scm",(void*)f_5489},
{"f_5401chicken.scm",(void*)f_5401},
{"f_5481chicken.scm",(void*)f_5481},
{"f_5461chicken.scm",(void*)f_5461},
{"f_5420chicken.scm",(void*)f_5420},
{"f_5390chicken.scm",(void*)f_5390},
{"f_5358chicken.scm",(void*)f_5358},
{"f_5310chicken.scm",(void*)f_5310},
{"f_5327chicken.scm",(void*)f_5327},
{"f_5296chicken.scm",(void*)f_5296},
{"f_5304chicken.scm",(void*)f_5304},
{"f_5290chicken.scm",(void*)f_5290},
{"f_5252chicken.scm",(void*)f_5252},
{"f_5161chicken.scm",(void*)f_5161},
{"f_5167chicken.scm",(void*)f_5167},
{"f_5193chicken.scm",(void*)f_5193},
{"f_5181chicken.scm",(void*)f_5181},
{"f_5185chicken.scm",(void*)f_5185},
{"f_5153chicken.scm",(void*)f_5153},
{"f_1973chicken.scm",(void*)f_1973},
{"f_5057chicken.scm",(void*)f_5057},
{"f_5061chicken.scm",(void*)f_5061},
{"f_5126chicken.scm",(void*)f_5126},
{"f_5141chicken.scm",(void*)f_5141},
{"f_5076chicken.scm",(void*)f_5076},
{"f_5099chicken.scm",(void*)f_5099},
{"f_5111chicken.scm",(void*)f_5111},
{"f_5055chicken.scm",(void*)f_5055},
{"f_1976chicken.scm",(void*)f_1976},
{"f_4863chicken.scm",(void*)f_4863},
{"f_4867chicken.scm",(void*)f_4867},
{"f_4870chicken.scm",(void*)f_4870},
{"f_4873chicken.scm",(void*)f_4873},
{"f_4876chicken.scm",(void*)f_4876},
{"f_4887chicken.scm",(void*)f_4887},
{"f_4915chicken.scm",(void*)f_4915},
{"f_5007chicken.scm",(void*)f_5007},
{"f_4861chicken.scm",(void*)f_4861},
{"f_1979chicken.scm",(void*)f_1979},
{"f_4536chicken.scm",(void*)f_4536},
{"f_4540chicken.scm",(void*)f_4540},
{"f_4543chicken.scm",(void*)f_4543},
{"f_4546chicken.scm",(void*)f_4546},
{"f_4549chicken.scm",(void*)f_4549},
{"f_4552chicken.scm",(void*)f_4552},
{"f_4555chicken.scm",(void*)f_4555},
{"f_4558chicken.scm",(void*)f_4558},
{"f_4733chicken.scm",(void*)f_4733},
{"f_4773chicken.scm",(void*)f_4773},
{"f_4781chicken.scm",(void*)f_4781},
{"f_4777chicken.scm",(void*)f_4777},
{"f_4560chicken.scm",(void*)f_4560},
{"f_4684chicken.scm",(void*)f_4684},
{"f_4682chicken.scm",(void*)f_4682},
{"f_4678chicken.scm",(void*)f_4678},
{"f_4670chicken.scm",(void*)f_4670},
{"f_4651chicken.scm",(void*)f_4651},
{"f_4636chicken.scm",(void*)f_4636},
{"f_4621chicken.scm",(void*)f_4621},
{"f_4602chicken.scm",(void*)f_4602},
{"f_4587chicken.scm",(void*)f_4587},
{"f_4534chicken.scm",(void*)f_4534},
{"f_1982chicken.scm",(void*)f_1982},
{"f_4161chicken.scm",(void*)f_4161},
{"f_4165chicken.scm",(void*)f_4165},
{"f_4180chicken.scm",(void*)f_4180},
{"f_4183chicken.scm",(void*)f_4183},
{"f_4186chicken.scm",(void*)f_4186},
{"f_4192chicken.scm",(void*)f_4192},
{"f_4195chicken.scm",(void*)f_4195},
{"f_4198chicken.scm",(void*)f_4198},
{"f_4201chicken.scm",(void*)f_4201},
{"f_4519chicken.scm",(void*)f_4519},
{"f_4517chicken.scm",(void*)f_4517},
{"f_4513chicken.scm",(void*)f_4513},
{"f_4230chicken.scm",(void*)f_4230},
{"f_4256chicken.scm",(void*)f_4256},
{"f_4296chicken.scm",(void*)f_4296},
{"f_4272chicken.scm",(void*)f_4272},
{"f_4268chicken.scm",(void*)f_4268},
{"f_4228chicken.scm",(void*)f_4228},
{"f_4224chicken.scm",(void*)f_4224},
{"f_4159chicken.scm",(void*)f_4159},
{"f_1985chicken.scm",(void*)f_1985},
{"f_3973chicken.scm",(void*)f_3973},
{"f_3977chicken.scm",(void*)f_3977},
{"f_3980chicken.scm",(void*)f_3980},
{"f_3983chicken.scm",(void*)f_3983},
{"f_3986chicken.scm",(void*)f_3986},
{"f_3989chicken.scm",(void*)f_3989},
{"f_3998chicken.scm",(void*)f_3998},
{"f_4101chicken.scm",(void*)f_4101},
{"f_4129chicken.scm",(void*)f_4129},
{"f_4123chicken.scm",(void*)f_4123},
{"f_4104chicken.scm",(void*)f_4104},
{"f_4008chicken.scm",(void*)f_4008},
{"f_4011chicken.scm",(void*)f_4011},
{"f_4083chicken.scm",(void*)f_4083},
{"f_4060chicken.scm",(void*)f_4060},
{"f_4017chicken.scm",(void*)f_4017},
{"f_4028chicken.scm",(void*)f_4028},
{"f_4048chicken.scm",(void*)f_4048},
{"f_3971chicken.scm",(void*)f_3971},
{"f_1988chicken.scm",(void*)f_1988},
{"f_3754chicken.scm",(void*)f_3754},
{"f_3758chicken.scm",(void*)f_3758},
{"f_3761chicken.scm",(void*)f_3761},
{"f_3764chicken.scm",(void*)f_3764},
{"f_3767chicken.scm",(void*)f_3767},
{"f_3770chicken.scm",(void*)f_3770},
{"f_3779chicken.scm",(void*)f_3779},
{"f_3898chicken.scm",(void*)f_3898},
{"f_3926chicken.scm",(void*)f_3926},
{"f_3959chicken.scm",(void*)f_3959},
{"f_3932chicken.scm",(void*)f_3932},
{"f_3920chicken.scm",(void*)f_3920},
{"f_3901chicken.scm",(void*)f_3901},
{"f_3789chicken.scm",(void*)f_3789},
{"f_3792chicken.scm",(void*)f_3792},
{"f_3888chicken.scm",(void*)f_3888},
{"f_3853chicken.scm",(void*)f_3853},
{"f_3798chicken.scm",(void*)f_3798},
{"f_3821chicken.scm",(void*)f_3821},
{"f_3841chicken.scm",(void*)f_3841},
{"f_3752chicken.scm",(void*)f_3752},
{"f_1991chicken.scm",(void*)f_1991},
{"f_3477chicken.scm",(void*)f_3477},
{"f_3481chicken.scm",(void*)f_3481},
{"f_3484chicken.scm",(void*)f_3484},
{"f_3487chicken.scm",(void*)f_3487},
{"f_3490chicken.scm",(void*)f_3490},
{"f_3493chicken.scm",(void*)f_3493},
{"f_3496chicken.scm",(void*)f_3496},
{"f_3505chicken.scm",(void*)f_3505},
{"f_3651chicken.scm",(void*)f_3651},
{"f_3654chicken.scm",(void*)f_3654},
{"f_3663chicken.scm",(void*)f_3663},
{"f_3688chicken.scm",(void*)f_3688},
{"f_3713chicken.scm",(void*)f_3713},
{"f_3735chicken.scm",(void*)f_3735},
{"f_3728chicken.scm",(void*)f_3728},
{"f_3720chicken.scm",(void*)f_3720},
{"f_3707chicken.scm",(void*)f_3707},
{"f_3703chicken.scm",(void*)f_3703},
{"f_3682chicken.scm",(void*)f_3682},
{"f_3678chicken.scm",(void*)f_3678},
{"f_3645chicken.scm",(void*)f_3645},
{"f_3515chicken.scm",(void*)f_3515},
{"f_3522chicken.scm",(void*)f_3522},
{"f_3630chicken.scm",(void*)f_3630},
{"f_3618chicken.scm",(void*)f_3618},
{"f_3614chicken.scm",(void*)f_3614},
{"f_3550chicken.scm",(void*)f_3550},
{"f_3578chicken.scm",(void*)f_3578},
{"f_3590chicken.scm",(void*)f_3590},
{"f_3574chicken.scm",(void*)f_3574},
{"f_3475chicken.scm",(void*)f_3475},
{"f_1994chicken.scm",(void*)f_1994},
{"f_3373chicken.scm",(void*)f_3373},
{"f_3377chicken.scm",(void*)f_3377},
{"f_3383chicken.scm",(void*)f_3383},
{"f_3467chicken.scm",(void*)f_3467},
{"f_3428chicken.scm",(void*)f_3428},
{"f_3440chicken.scm",(void*)f_3440},
{"f_3371chicken.scm",(void*)f_3371},
{"f_1997chicken.scm",(void*)f_1997},
{"f_3265chicken.scm",(void*)f_3265},
{"f_3269chicken.scm",(void*)f_3269},
{"f_3343chicken.scm",(void*)f_3343},
{"f_3355chicken.scm",(void*)f_3355},
{"f_3284chicken.scm",(void*)f_3284},
{"f_3330chicken.scm",(void*)f_3330},
{"f_3287chicken.scm",(void*)f_3287},
{"f_3290chicken.scm",(void*)f_3290},
{"f_3300chicken.scm",(void*)f_3300},
{"f_3263chicken.scm",(void*)f_3263},
{"f_2000chicken.scm",(void*)f_2000},
{"f_3240chicken.scm",(void*)f_3240},
{"f_3244chicken.scm",(void*)f_3244},
{"f_3238chicken.scm",(void*)f_3238},
{"f_2003chicken.scm",(void*)f_2003},
{"f_3230chicken.scm",(void*)f_3230},
{"f_3228chicken.scm",(void*)f_3228},
{"f_2006chicken.scm",(void*)f_2006},
{"f_2009chicken.scm",(void*)f_2009},
{"f_2012chicken.scm",(void*)f_2012},
{"f_2016chicken.scm",(void*)f_2016},
{"f_2928chicken.scm",(void*)f_2928},
{"f_2935chicken.scm",(void*)f_2935},
{"f_2938chicken.scm",(void*)f_2938},
{"f_2941chicken.scm",(void*)f_2941},
{"f_3046chicken.scm",(void*)f_3046},
{"f_3059chicken.scm",(void*)f_3059},
{"f_3157chicken.scm",(void*)f_3157},
{"f_3155chicken.scm",(void*)f_3155},
{"f_3119chicken.scm",(void*)f_3119},
{"f_3143chicken.scm",(void*)f_3143},
{"f_3127chicken.scm",(void*)f_3127},
{"f_3131chicken.scm",(void*)f_3131},
{"f_2947chicken.scm",(void*)f_2947},
{"f_2957chicken.scm",(void*)f_2957},
{"f_3031chicken.scm",(void*)f_3031},
{"f_3011chicken.scm",(void*)f_3011},
{"f_2981chicken.scm",(void*)f_2981},
{"f_2977chicken.scm",(void*)f_2977},
{"f_2926chicken.scm",(void*)f_2926},
{"f_2019chicken.scm",(void*)f_2019},
{"f_2787chicken.scm",(void*)f_2787},
{"f_2791chicken.scm",(void*)f_2791},
{"f_2803chicken.scm",(void*)f_2803},
{"f_2903chicken.scm",(void*)f_2903},
{"f_2806chicken.scm",(void*)f_2806},
{"f_2813chicken.scm",(void*)f_2813},
{"f_2883chicken.scm",(void*)f_2883},
{"f_2899chicken.scm",(void*)f_2899},
{"f_2863chicken.scm",(void*)f_2863},
{"f_2837chicken.scm",(void*)f_2837},
{"f_2833chicken.scm",(void*)f_2833},
{"f_2785chicken.scm",(void*)f_2785},
{"f_2022chicken.scm",(void*)f_2022},
{"f_2637chicken.scm",(void*)f_2637},
{"f_2641chicken.scm",(void*)f_2641},
{"f_2650chicken.scm",(void*)f_2650},
{"f_2773chicken.scm",(void*)f_2773},
{"f_2781chicken.scm",(void*)f_2781},
{"f_2653chicken.scm",(void*)f_2653},
{"f_2749chicken.scm",(void*)f_2749},
{"f_2664chicken.scm",(void*)f_2664},
{"f_2747chicken.scm",(void*)f_2747},
{"f_2674chicken.scm",(void*)f_2674},
{"f_2672chicken.scm",(void*)f_2672},
{"f_2635chicken.scm",(void*)f_2635},
{"f_2025chicken.scm",(void*)f_2025},
{"f_2569chicken.scm",(void*)f_2569},
{"f_2573chicken.scm",(void*)f_2573},
{"f_2576chicken.scm",(void*)f_2576},
{"f_2583chicken.scm",(void*)f_2583},
{"f_2607chicken.scm",(void*)f_2607},
{"f_2627chicken.scm",(void*)f_2627},
{"f_2623chicken.scm",(void*)f_2623},
{"f_2567chicken.scm",(void*)f_2567},
{"f_2028chicken.scm",(void*)f_2028},
{"f_2513chicken.scm",(void*)f_2513},
{"f_2517chicken.scm",(void*)f_2517},
{"f_2520chicken.scm",(void*)f_2520},
{"f_2527chicken.scm",(void*)f_2527},
{"f_2543chicken.scm",(void*)f_2543},
{"f_2511chicken.scm",(void*)f_2511},
{"f_2031chicken.scm",(void*)f_2031},
{"f_2484chicken.scm",(void*)f_2484},
{"f_2488chicken.scm",(void*)f_2488},
{"f_2503chicken.scm",(void*)f_2503},
{"f_2482chicken.scm",(void*)f_2482},
{"f_2034chicken.scm",(void*)f_2034},
{"f_2409chicken.scm",(void*)f_2409},
{"f_2413chicken.scm",(void*)f_2413},
{"f_2431chicken.scm",(void*)f_2431},
{"f_2457chicken.scm",(void*)f_2457},
{"f_2428chicken.scm",(void*)f_2428},
{"f_2421chicken.scm",(void*)f_2421},
{"f_2407chicken.scm",(void*)f_2407},
{"f_2037chicken.scm",(void*)f_2037},
{"f_2040chicken.scm",(void*)f_2040},
{"f_2403chicken.scm",(void*)f_2403},
{"f_2396chicken.scm",(void*)f_2396},
{"f_2392chicken.scm",(void*)f_2392},
{"f_2384chicken.scm",(void*)f_2384},
{"f_2382chicken.scm",(void*)f_2382},
{"f_2044chicken.scm",(void*)f_2044},
{"f_2173chicken.scm",(void*)f_2173},
{"f_2185chicken.scm",(void*)f_2185},
{"f_2368chicken.scm",(void*)f_2368},
{"f_2361chicken.scm",(void*)f_2361},
{"f_2324chicken.scm",(void*)f_2324},
{"f_2270chicken.scm",(void*)f_2270},
{"f_2287chicken.scm",(void*)f_2287},
{"f_2273chicken.scm",(void*)f_2273},
{"f_2207chicken.scm",(void*)f_2207},
{"f_2250chicken.scm",(void*)f_2250},
{"f_2230chicken.scm",(void*)f_2230},
{"f_2210chicken.scm",(void*)f_2210},
{"f_2177chicken.scm",(void*)f_2177},
{"f_2180chicken.scm",(void*)f_2180},
{"f_2161chicken.scm",(void*)f_2161},
{"f_2168chicken.scm",(void*)f_2168},
{"f_2153chicken.scm",(void*)f_2153},
{"f_2159chicken.scm",(void*)f_2159},
{"f_2156chicken.scm",(void*)f_2156},
{"f_2046chicken.scm",(void*)f_2046},
{"f_2052chicken.scm",(void*)f_2052},
{"f_2087chicken.scm",(void*)f_2087},
{"f_2113chicken.scm",(void*)f_2113},
{"f_2109chicken.scm",(void*)f_2109},
{"f_2066chicken.scm",(void*)f_2066},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
