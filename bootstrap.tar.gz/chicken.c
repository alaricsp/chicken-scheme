/* Generated from chicken.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-06-19 09:27
   Version 4.0.7 - SVN rev. 14630
   windows-mingw32-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-05-14 on lenovo-1 (MINGW32_NT-6.0)
   command line: chicken.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -no-lambda-info -inline -local -extend private-namespace.scm -output-file chicken.c
   used units: library eval data_structures ports extras srfi_69 chicken_syntax srfi_1 srfi_4 utils files support compiler optimizer scrutinizer driver platform backend srfi_69
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_syntax_toplevel)
C_externimport void C_ccall C_chicken_syntax_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_4_toplevel)
C_externimport void C_ccall C_srfi_4_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_support_toplevel)
C_externimport void C_ccall C_support_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_compiler_toplevel)
C_externimport void C_ccall C_compiler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_optimizer_toplevel)
C_externimport void C_ccall C_optimizer_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_scrutinizer_toplevel)
C_externimport void C_ccall C_scrutinizer_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_driver_toplevel)
C_externimport void C_ccall C_driver_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_platform_toplevel)
C_externimport void C_ccall C_platform_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_backend_toplevel)
C_externimport void C_ccall C_backend_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[89];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_334)
static void C_ccall f_334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_337)
static void C_ccall f_337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_340)
static void C_ccall f_340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_343)
static void C_ccall f_343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_346)
static void C_ccall f_346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_349)
static void C_ccall f_349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_352)
static void C_ccall f_352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_355)
static void C_ccall f_355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_358)
static void C_ccall f_358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_361)
static void C_ccall f_361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_364)
static void C_ccall f_364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_367)
static void C_ccall f_367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_370)
static void C_ccall f_370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_373)
static void C_ccall f_373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_376)
static void C_ccall f_376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_379)
static void C_ccall f_379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_382)
static void C_ccall f_382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_385)
static void C_ccall f_385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_388)
static void C_ccall f_388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_392)
static void C_ccall f_392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1236)
static void C_ccall f_1236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1243)
static void C_ccall f_1243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1246)
static void C_fcall f_1246(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1249)
static void C_fcall f_1249(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1354)
static void C_ccall f_1354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1367)
static void C_ccall f_1367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1465)
static void C_ccall f_1465(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1463)
static void C_ccall f_1463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1427)
static void C_ccall f_1427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1451)
static void C_ccall f_1451(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1435)
static void C_ccall f_1435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1439)
static void C_ccall f_1439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1255)
static void C_ccall f_1255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1265)
static void C_ccall f_1265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1339)
static void C_ccall f_1339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1319)
static void C_ccall f_1319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1289)
static void C_fcall f_1289(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1285)
static void C_ccall f_1285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1234)
static void C_ccall f_1234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_395)
static void C_ccall f_395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1095)
static void C_ccall f_1095(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1099)
static void C_ccall f_1099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1111)
static void C_ccall f_1111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1211)
static void C_ccall f_1211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1114)
static void C_ccall f_1114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1121)
static void C_ccall f_1121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1191)
static void C_ccall f_1191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1207)
static void C_ccall f_1207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1171)
static void C_ccall f_1171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1145)
static void C_fcall f_1145(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1141)
static void C_ccall f_1141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1093)
static void C_ccall f_1093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_398)
static void C_ccall f_398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_945)
static void C_ccall f_945(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_949)
static void C_ccall f_949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_958)
static void C_ccall f_958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1081)
static void C_ccall f_1081(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1089)
static void C_ccall f_1089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_961)
static void C_ccall f_961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1057)
static void C_ccall f_1057(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_972)
static void C_ccall f_972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1055)
static void C_ccall f_1055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_982)
static void C_ccall f_982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_980)
static void C_ccall f_980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_943)
static void C_ccall f_943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_401)
static void C_ccall f_401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_877)
static void C_ccall f_877(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_881)
static void C_ccall f_881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_884)
static void C_ccall f_884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_891)
static void C_ccall f_891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_915)
static void C_ccall f_915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_935)
static void C_ccall f_935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_931)
static void C_ccall f_931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_875)
static void C_ccall f_875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_404)
static void C_ccall f_404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_821)
static void C_ccall f_821(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_825)
static void C_ccall f_825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_828)
static void C_ccall f_828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_835)
static void C_ccall f_835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_851)
static void C_ccall f_851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_819)
static void C_ccall f_819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_407)
static void C_ccall f_407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_792)
static void C_ccall f_792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_796)
static void C_ccall f_796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_811)
static void C_ccall f_811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_790)
static void C_ccall f_790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_410)
static void C_ccall f_410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_413)
static void C_ccall f_413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_783)
static void C_ccall f_783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_779)
static void C_ccall f_779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_771)
static void C_ccall f_771(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_761)
static void C_ccall f_761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_769)
static void C_ccall f_769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_417)
static void C_ccall f_417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_546)
static void C_ccall f_546(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_558)
static void C_fcall f_558(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_751)
static void C_ccall f_751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_744)
static void C_ccall f_744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_707)
static void C_ccall f_707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_653)
static void C_ccall f_653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_670)
static void C_ccall f_670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_656)
static void C_ccall f_656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_580)
static void C_ccall f_580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_633)
static void C_ccall f_633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_623)
static void C_ccall f_623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_583)
static void C_ccall f_583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_550)
static void C_ccall f_550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_553)
static void C_ccall f_553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_534)
static void C_ccall f_534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_541)
static void C_ccall f_541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_526)
static void C_ccall f_526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_532)
static void C_ccall f_532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_529)
static void C_ccall f_529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_419)
static void C_ccall f_419(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_425)
static void C_fcall f_425(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_460)
static void C_fcall f_460(C_word t0,C_word t1) C_noret;
C_noret_decl(f_486)
static void C_ccall f_486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_482)
static void C_ccall f_482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_439)
static void C_ccall f_439(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1246)
static void C_fcall trf_1246(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1246(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1246(t0,t1);}

C_noret_decl(trf_1249)
static void C_fcall trf_1249(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1249(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1249(t0,t1);}

C_noret_decl(trf_1289)
static void C_fcall trf_1289(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1289(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1289(t0,t1);}

C_noret_decl(trf_1145)
static void C_fcall trf_1145(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1145(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1145(t0,t1);}

C_noret_decl(trf_558)
static void C_fcall trf_558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_558(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_558(t0,t1,t2);}

C_noret_decl(trf_425)
static void C_fcall trf_425(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_425(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_425(t0,t1,t2,t3,t4);}

C_noret_decl(trf_460)
static void C_fcall trf_460(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_460(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_460(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1098)){
C_save(t1);
C_rereclaim2(1098*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,89);
lf[0]=C_h_intern(&lf[0],33,"\003syschicken-ffi-macro-environment");
lf[1]=C_h_intern(&lf[1],27,"\010compilercompiler-arguments");
lf[2]=C_h_intern(&lf[2],29,"\010compilerprocess-command-line");
lf[3]=C_h_intern(&lf[3],7,"reverse");
lf[4]=C_h_intern(&lf[4],14,"string->symbol");
lf[5]=C_h_intern(&lf[5],9,"substring");
lf[6]=C_h_intern(&lf[6],25,"\003sysimplicit-exit-handler");
lf[7]=C_h_intern(&lf[7],17,"user-options-pass");
lf[8]=C_h_intern(&lf[8],4,"exit");
lf[9]=C_h_intern(&lf[9],19,"compile-source-file");
lf[10]=C_h_intern(&lf[10],14,"optimize-level");
lf[11]=C_h_intern(&lf[11],22,"optimize-leaf-routines");
lf[12]=C_h_intern(&lf[12],5,"cons*");
lf[13]=C_h_intern(&lf[13],5,"local");
lf[14]=C_h_intern(&lf[14],6,"inline");
lf[15]=C_h_intern(&lf[15],6,"unsafe");
lf[16]=C_h_intern(&lf[16],25,"\010compilercompiler-warning");
lf[17]=C_h_intern(&lf[17],5,"usage");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\047invalid optimization level ~S - ignored");
lf[19]=C_h_intern(&lf[19],11,"debug-level");
lf[20]=C_h_intern(&lf[20],14,"no-lambda-info");
lf[21]=C_h_intern(&lf[21],8,"no-trace");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000 invalid debug level ~S - ignored");
lf[23]=C_h_intern(&lf[23],14,"benchmark-mode");
lf[24]=C_h_intern(&lf[24],17,"fixnum-arithmetic");
lf[25]=C_h_intern(&lf[25],18,"disable-interrupts");
lf[26]=C_h_intern(&lf[26],5,"block");
lf[27]=C_h_intern(&lf[27],11,"lambda-lift");
lf[28]=C_h_intern(&lf[28],31,"\010compilervalid-compiler-options");
lf[29]=C_h_intern(&lf[29],45,"\010compilervalid-compiler-options-with-argument");
lf[30]=C_h_intern(&lf[30],4,"quit");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~s\047 option");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000&invalid compiler option `~a\047 - ignored");
lf[33]=C_h_intern(&lf[33],4,"conc");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[35]=C_h_intern(&lf[35],6,"append");
lf[36]=C_h_intern(&lf[36],4,"argv");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[38]=C_h_intern(&lf[38],6,"remove");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[40]=C_h_intern(&lf[40],12,"string-split");
lf[41]=C_h_intern(&lf[41],6,"getenv");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\017CHICKEN_OPTIONS");
lf[43]=C_h_intern(&lf[43],16,"\003sysmacro-subset");
lf[44]=C_h_intern(&lf[44],28,"\003sysextend-macro-environment");
lf[45]=C_h_intern(&lf[45],15,"foreign-declare");
lf[46]=C_h_intern(&lf[46],12,"\004coredeclare");
lf[47]=C_h_intern(&lf[47],10,"\003sysappend");
lf[48]=C_h_intern(&lf[48],16,"\003syscheck-syntax");
lf[49]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\000");
lf[50]=C_h_intern(&lf[50],18,"\003syser-transformer");
lf[51]=C_h_intern(&lf[51],13,"foreign-value");
lf[52]=C_h_intern(&lf[52],23,"define-foreign-variable");
lf[53]=C_h_intern(&lf[53],5,"begin");
lf[54]=C_h_intern(&lf[54],6,"gensym");
lf[55]=C_h_intern(&lf[55],5,"code_");
lf[56]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[57]=C_h_intern(&lf[57],12,"foreign-code");
lf[58]=C_h_intern(&lf[58],11,"\004coreinline");
lf[59]=C_h_intern(&lf[59],7,"sprintf");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\0007static C_word ~A() { ~A\012; return C_SCHEME_UNDEFINED; }\012");
lf[61]=C_h_intern(&lf[61],18,"string-intersperse");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[63]=C_h_intern(&lf[63],7,"declare");
lf[64]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\000");
lf[65]=C_h_intern(&lf[65],12,"let-location");
lf[66]=C_h_intern(&lf[66],17,"\004corelet-location");
lf[67]=C_h_intern(&lf[67],10,"fold-right");
lf[68]=C_h_intern(&lf[68],10,"append-map");
lf[69]=C_h_intern(&lf[69],7,"\003sysmap");
lf[70]=C_h_intern(&lf[70],3,"let");
lf[71]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001\376\377\001\000\000"
"\000\000\376\001\000\000\001_");
lf[72]=C_h_intern(&lf[72],15,"define-location");
lf[73]=C_h_intern(&lf[73],9,"\004coreset!");
lf[74]=C_h_intern(&lf[74],24,"define-external-variable");
lf[75]=C_h_intern(&lf[75],14,"symbol->string");
lf[76]=C_h_intern(&lf[76],9,"\003syserror");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[78]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[79]=C_h_intern(&lf[79],15,"define-external");
lf[80]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[81]=C_h_intern(&lf[81],5,"quote");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[83]=C_h_intern(&lf[83],29,"\004coreforeign-callback-wrapper");
lf[84]=C_h_intern(&lf[84],6,"lambda");
lf[85]=C_h_intern(&lf[85],6,"define");
lf[86]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376"
"\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[87]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376"
"\001\000\000\001_\376\377\001\000\000\000\001");
lf[88]=C_h_intern(&lf[88],21,"\003sysmacro-environment");
C_register_lf2(lf,89,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_334,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k332 */
static void C_ccall f_334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_337,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k335 in k332 */
static void C_ccall f_337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_340,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k338 in k335 in k332 */
static void C_ccall f_340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_343,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k341 in k338 in k335 in k332 */
static void C_ccall f_343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_346,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_349,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_352,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_syntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_355,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_358,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_4_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_358,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_361,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_364,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_367,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_support_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_370,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_compiler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_373,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_376,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_scrutinizer_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_379,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_driver_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_382,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_platform_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_385,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_backend_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_388,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_392,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[88]))(2,*((C_word*)lf[88]+1),t2);}

/* k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_395,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1234,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1236,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t3,t4);}

/* a1235 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1236,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1243,a[2]=t3,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* r59 */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[81]);}

/* k1241 in a1235 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1246,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=t2;
f_1246(t4,(C_word)C_i_stringp(t3));}
else{
t3=t2;
f_1246(t3,C_SCHEME_FALSE);}}

/* k1244 in k1241 in a1235 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_fcall f_1246(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1246,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1249,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=t1;
if(C_truep(t3)){
t4=t2;
f_1249(t4,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_1249(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t2;
f_1249(t4,C_SCHEME_FALSE);}}}

/* k1247 in k1244 in k1241 in a1235 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_fcall f_1249(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1249,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1255,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t2,lf[79],((C_word*)t0)[5],lf[80]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1354,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t2,lf[79],((C_word*)t0)[5],lf[86]);}
else{
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t2,lf[79],((C_word*)t0)[5],lf[87]);}}}

/* k1352 in k1247 in k1244 in k1241 in a1235 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1354,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_i_cadr(((C_word*)t0)[4]):(C_word)C_i_car(((C_word*)t0)[4]));
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1367,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* r59 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[85]);}

/* k1365 in k1352 in k1247 in k1244 in k1241 in a1235 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1367,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[81],t4);
t6=(C_truep(((C_word*)t0)[6])?(C_word)C_i_car(((C_word*)t0)[5]):lf[82]);
t7=(C_truep(((C_word*)t0)[6])?(C_word)C_i_caddr(((C_word*)t0)[5]):(C_word)C_i_cadr(((C_word*)t0)[5]));
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,lf[81],t8);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=t2,a[9]=t5,a[10]=t6,a[11]=t9,tmp=(C_word)a,a+=12,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1465,tmp=(C_word)a,a+=2,tmp);
/* map */
t12=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,((C_word*)t0)[3]);}

/* a1464 in k1365 in k1352 in k1247 in k1244 in k1241 in a1235 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1465(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1465,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k1461 in k1365 in k1352 in k1247 in k1244 in k1241 in a1235 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1463,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[81],t2);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1427,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
/* r59 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[84]);}

/* k1425 in k1461 in k1365 in k1352 in k1247 in k1244 in k1241 in a1235 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1435,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1451,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a1450 in k1425 in k1461 in k1365 in k1352 in k1247 in k1244 in k1241 in a1235 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1451(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1451,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k1433 in k1425 in k1461 in k1365 in k1352 in k1247 in k1244 in k1241 in a1235 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1439,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t3=(C_truep(((C_word*)t0)[3])?(C_word)C_i_cdddr(((C_word*)t0)[2]):(C_word)C_i_cddr(((C_word*)t0)[2]));
/* ##sys#append */
t4=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k1437 in k1433 in k1425 in k1461 in k1365 in k1352 in k1247 in k1244 in k1241 in a1235 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1439,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[83],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t10);
t12=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t11));}

/* k1253 in k1247 in k1244 in k1241 in a1235 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1255,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1265,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* r59 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[53]);}

/* k1263 in k1253 in k1247 in k1244 in k1241 in a1235 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1339,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* r59 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[52]);}

/* k1337 in k1263 in k1253 in k1247 in k1244 in k1241 in a1235 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1339,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1319,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* r59 */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[74]);}

/* k1317 in k1337 in k1263 in k1253 in k1247 in k1244 in k1241 in a1235 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1319,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1285,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1289,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cddr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_caddr(((C_word*)t0)[6]);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[73],t12);
t14=t8;
f_1289(t14,(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST));}
else{
t10=t8;
f_1289(t10,C_SCHEME_END_OF_LIST);}}

/* k1287 in k1317 in k1337 in k1263 in k1253 in k1247 in k1244 in k1241 in a1235 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_fcall f_1289(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k1283 in k1317 in k1337 in k1263 in k1253 in k1247 in k1244 in k1241 in a1235 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1285,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k1232 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[79],C_SCHEME_END_OF_LIST,t1);}

/* k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_398,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1093,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1095,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t3,t4);}

/* a1094 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1095(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1095,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1099,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t5,lf[72],t2,lf[78]);}

/* k1097 in a1094 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1099,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1111,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_1111(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_1111(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[77],t4);}}}

/* k1109 in k1097 in a1094 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1114,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1211,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
((C_proc2)C_retrieve_symbol_proc(lf[54]))(2,*((C_word*)lf[54]+1),t3);}

/* k1209 in k1109 in k1097 in a1094 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r112 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1112 in k1109 in k1097 in a1094 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1121,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* r112 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[53]);}

/* k1119 in k1112 in k1109 in k1097 in a1094 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1121,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1191,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* r112 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[52]);}

/* k1189 in k1119 in k1112 in k1109 in k1097 in a1094 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1191,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1207,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[75]+1)))(3,*((C_word*)lf[75]+1),t2,((C_word*)t0)[6]);}

/* k1205 in k1189 in k1119 in k1112 in k1109 in k1097 in a1094 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1207,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1171,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* r112 */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[74]);}

/* k1169 in k1205 in k1189 in k1119 in k1112 in k1109 in k1097 in a1094 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1171,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1141,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1145,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t9=(C_word)C_i_car(((C_word*)t0)[2]);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t10);
t12=(C_word)C_a_i_cons(&a,2,lf[73],t11);
t13=t8;
f_1145(t13,(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST));}
else{
t9=t8;
f_1145(t9,C_SCHEME_END_OF_LIST);}}

/* k1143 in k1169 in k1205 in k1189 in k1119 in k1112 in k1109 in k1097 in a1094 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_fcall f_1145(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k1139 in k1169 in k1205 in k1189 in k1119 in k1112 in k1109 in k1097 in a1094 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1141,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k1091 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[72],C_SCHEME_END_OF_LIST,t1);}

/* k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_943,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_945,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t3,t4);}

/* a944 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_945(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_945,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_949,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t5,lf[65],t2,lf[71]);}

/* k947 in a944 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_949,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_958,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* r139 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[70]);}

/* k956 in k947 in a944 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_961,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1081,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a1080 in k956 in k947 in a944 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1081(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1081,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1089,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
((C_proc2)C_retrieve_symbol_proc(lf[54]))(2,*((C_word*)lf[54]+1),t3);}

/* k1087 in a1080 in k956 in k947 in a944 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r139 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k959 in k956 in k947 in a944 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_972,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1057,tmp=(C_word)a,a+=2,tmp);
/* append-map */
((C_proc5)C_retrieve_symbol_proc(lf[68]))(5,*((C_word*)lf[68]+1),t2,t3,((C_word*)t0)[3],t1);}

/* a1056 in k959 in k956 in k947 in a944 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1057(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1057,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cddr(t2);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}}

/* k970 in k959 in k956 in k947 in a944 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_980,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_982,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1055,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#append */
t5=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1053 in k970 in k959 in k956 in k947 in a944 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_1055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1055,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
/* fold-right */
((C_proc6)C_retrieve_symbol_proc(lf[67]))(6,*((C_word*)lf[67]+1),((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a981 in k970 in k959 in k956 in k947 in a944 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_982,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t2);
t6=(C_word)C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t3,t9);
t11=(C_word)C_a_i_cons(&a,2,t8,t10);
t12=(C_word)C_a_i_cons(&a,2,t7,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,lf[66],t12));}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t8,t9);
t11=(C_word)C_a_i_cons(&a,2,t7,t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,lf[66],t11));}}

/* k978 in k970 in k959 in k956 in k947 in a944 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_980,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k941 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[65],C_SCHEME_END_OF_LIST,t1);}

/* k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_404,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_875,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_877,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t3,t4);}

/* a876 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_877(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_877,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_881,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t5,lf[57],t2,lf[64]);}

/* k879 in a876 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_884,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* gensym */
((C_proc3)C_retrieve_symbol_proc(lf[54]))(3,*((C_word*)lf[54]+1),t2,lf[55]);}

/* k882 in k879 in a876 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* r179 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[53]);}

/* k889 in k882 in k879 in a876 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_915,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* r179 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[63]);}

/* k913 in k889 in k882 in k879 in a876 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_931,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_935,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),t3,t4,lf[62]);}

/* k933 in k913 in k889 in k882 in k879 in a876 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[59]))(5,*((C_word*)lf[59]+1),((C_word*)t0)[3],lf[60],((C_word*)t0)[2],t1);}

/* k929 in k913 in k889 in k882 in k879 in a876 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_931,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[45],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[58],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t5,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k873 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[57],C_SCHEME_END_OF_LIST,t1);}

/* k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_407,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_819,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_821,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t3,t4);}

/* a820 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_821(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_821,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_825,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t5,lf[51],t2,lf[56]);}

/* k823 in a820 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_828,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* gensym */
((C_proc3)C_retrieve_symbol_proc(lf[54]))(3,*((C_word*)lf[54]+1),t2,lf[55]);}

/* k826 in k823 in a820 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_835,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* r190 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[53]);}

/* k833 in k826 in k823 in a820 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_835,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_851,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* r190 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[52]);}

/* k849 in k833 in k826 in k823 in a820 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_851,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[5]);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,t1,t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k817 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[51],C_SCHEME_END_OF_LIST,t1);}

/* k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_410,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_790,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_792,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t3,t4);}

/* a791 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_792,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_796,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t5,lf[45],t2,lf[49]);}

/* k794 in a791 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_811,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k809 in k794 in a791 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_811,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[45],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[46],t3));}

/* k788 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[45],C_SCHEME_END_OF_LIST,t1);}

/* k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_413,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#macro-subset */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t2,((C_word*)t0)[2]);}

/* k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_413,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! chicken-ffi-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_417,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_761,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_771,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_779,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_783,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 80   getenv */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t7,lf[42]);}

/* k781 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[39]);
/* chicken.scm: 80   string-split */
((C_proc3)C_retrieve_symbol_proc(lf[40]))(3,*((C_word*)lf[40]+1),((C_word*)t0)[2],t2);}

/* k777 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 78   remove */
((C_proc4)C_retrieve_symbol_proc(lf[38]))(4,*((C_word*)lf[38]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a770 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_771(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_771,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_string_equal_p(t2,lf[37]));}

/* k759 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_769,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 81   argv */
((C_proc2)C_retrieve_symbol_proc(lf[36]))(2,*((C_word*)lf[36]+1),t2);}

/* k767 in k759 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(t1);
/* chicken.scm: 77   append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[35]+1)))(4,*((C_word*)lf[35]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k415 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_417,2,t0,t1);}
t2=C_mutate((C_word*)lf[1]+1 /* (set! compiler-arguments ...) */,t1);
t3=C_mutate((C_word*)lf[2]+1 /* (set! process-command-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_419,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_526,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_534,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_546,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}

/* a545 in k415 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_546(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_546,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_550,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_558,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_558(t9,t5,((C_word*)t4)[1]);}

/* loop in a545 in k415 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_fcall f_558(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_558,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_eqp(lf[10],t3);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_580,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t4);
/* chicken.scm: 114  string->number */
C_string_to_number(3,0,t6,t7);}
else{
t6=(C_word)C_eqp(lf[19],t3);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_653,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_car(t4);
/* chicken.scm: 130  string->number */
C_string_to_number(3,0,t7,t8);}
else{
t7=(C_word)C_eqp(lf[23],t3);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_707,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 139  cons* */
((C_proc12)C_retrieve_symbol_proc(lf[12]))(12,*((C_word*)lf[12]+1),t8,lf[24],lf[25],lf[21],lf[15],lf[11],lf[26],lf[27],lf[20],lf[14],((C_word*)((C_word*)t0)[2])[1]);}
else{
if(C_truep((C_word)C_i_memq(t3,C_retrieve(lf[28])))){
/* chicken.scm: 144  loop */
t17=t1;
t18=t4;
t1=t17;
t2=t18;
goto loop;}
else{
if(C_truep((C_word)C_i_memq(t3,C_retrieve(lf[29])))){
if(C_truep((C_word)C_i_pairp(t4))){
t8=(C_word)C_i_cdr(t4);
/* chicken.scm: 147  loop */
t17=t1;
t18=t8;
t1=t17;
t2=t18;
goto loop;}
else{
/* chicken.scm: 148  quit */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t1,lf[31],t3);}}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_744,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_751,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_stringp(t3))){
t10=t9;
f_751(2,t10,t3);}
else{
/* chicken.scm: 152  conc */
((C_proc4)C_retrieve_symbol_proc(lf[33]))(4,*((C_word*)lf[33]+1),t9,lf[34],t3);}}}}}}}}

/* k749 in loop in a545 in k415 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 150  compiler-warning */
((C_proc5)C_retrieve_symbol_proc(lf[16]))(5,*((C_word*)lf[16]+1),((C_word*)t0)[2],lf[17],lf[32],t1);}

/* k742 in loop in a545 in k415 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 153  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_558(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k705 in loop in a545 in k415 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* chicken.scm: 143  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_558(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k651 in loop in a545 in k415 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_656,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
switch(t1){
case C_fix(0):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_670,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 132  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[12]))(5,*((C_word*)lf[12]+1),t3,lf[20],lf[21],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,lf[21],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_656(2,t5,t4);
case C_fix(2):
t3=t2;
f_656(2,t3,C_SCHEME_FALSE);
default:
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 135  compiler-warning */
((C_proc5)C_retrieve_symbol_proc(lf[16]))(5,*((C_word*)lf[16]+1),t2,lf[17],lf[22],t3);}}

/* k668 in k651 in loop in a545 in k415 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_656(2,t3,t2);}

/* k654 in k651 in loop in a545 in k415 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 136  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_558(t3,((C_word*)t0)[2],t2);}

/* k578 in loop in a545 in k415 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_583,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
switch(t1){
case C_fix(0):
t3=t2;
f_583(2,t3,C_SCHEME_FALSE);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,lf[11],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_583(2,t5,t4);
case C_fix(2):
t3=(C_word)C_a_i_cons(&a,2,lf[11],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_583(2,t5,t4);
case C_fix(3):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_623,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 123  cons* */
((C_proc6)C_retrieve_symbol_proc(lf[12]))(6,*((C_word*)lf[12]+1),t3,lf[11],lf[13],lf[14],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(4):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_633,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 126  cons* */
((C_proc7)C_retrieve_symbol_proc(lf[12]))(7,*((C_word*)lf[12]+1),t3,lf[11],lf[13],lf[14],lf[15],((C_word*)((C_word*)t0)[2])[1]);
default:
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 127  compiler-warning */
((C_proc5)C_retrieve_symbol_proc(lf[16]))(5,*((C_word*)lf[16]+1),t2,lf[17],lf[18],t3);}}

/* k631 in k578 in loop in a545 in k415 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_583(2,t3,t2);}

/* k621 in k578 in loop in a545 in k415 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_583(2,t3,t2);}

/* k581 in k578 in loop in a545 in k415 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 128  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_558(t3,((C_word*)t0)[2],t2);}

/* k548 in a545 in k415 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_553,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t2,C_retrieve(lf[9]),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k551 in k548 in a545 in k415 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 155  exit */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),((C_word*)t0)[2]);}

/* a533 in k415 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_534,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_541,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 108  user-options-pass */
((C_proc2)C_retrieve_symbol_proc(lf[7]))(2,*((C_word*)lf[7]+1),t2);}

/* k539 in a533 in k415 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_retrieve(lf[2]));
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_retrieve(lf[1]));}

/* k524 in k415 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_526,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_529,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_532,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[6]))(2,*((C_word*)lf[6]+1),t3);}

/* k530 in k524 in k415 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k527 in k524 in k415 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##compiler#process-command-line in k415 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_419(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_419,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_425,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_425(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in ##compiler#process-command-line in k415 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_fcall f_425(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_425,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_439,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 93   reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[3]+1)))(3,*((C_word*)lf[3]+1),t5,t3);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_string_length(t5);
t7=(C_word)C_i_string_ref(t5,C_fix(0));
t8=(C_word)C_eqp(C_make_character(45),t7);
t9=(C_truep(t8)?(C_word)C_fixnum_greaterp(t6,C_fix(1)):C_SCHEME_FALSE);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_460,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t6,C_fix(1)))){
t11=(C_word)C_i_string_ref(t5,C_fix(1));
t12=t10;
f_460(t12,(C_word)C_eqp(C_make_character(58),t11));}
else{
t11=t10;
f_460(t11,C_SCHEME_FALSE);}}
else{
if(C_truep(t4)){
t10=(C_word)C_i_cdr(t2);
t11=(C_word)C_a_i_cons(&a,2,t5,t3);
/* chicken.scm: 102  loop */
t17=t1;
t18=t10;
t19=t11;
t20=t4;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}
else{
t10=(C_word)C_i_cdr(t2);
/* chicken.scm: 103  loop */
t17=t1;
t18=t10;
t19=t3;
t20=t5;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}}}}

/* k458 in loop in ##compiler#process-command-line in k415 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_fcall f_460(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_460,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* chicken.scm: 99   loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_425(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_482,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_486,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 100  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[5]+1)))(5,*((C_word*)lf[5]+1),t4,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]);}}

/* k484 in k458 in loop in ##compiler#process-command-line in k415 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 100  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[4]+1)))(3,*((C_word*)lf[4]+1),((C_word*)t0)[2],t1);}

/* k480 in k458 in loop in ##compiler#process-command-line in k415 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_482,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* chicken.scm: 100  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_425(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k437 in loop in ##compiler#process-command-line in k415 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in k332 */
static void C_ccall f_439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 93   values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[121] = {
{"toplevel:chicken_scm",(void*)C_toplevel},
{"f_334:chicken_scm",(void*)f_334},
{"f_337:chicken_scm",(void*)f_337},
{"f_340:chicken_scm",(void*)f_340},
{"f_343:chicken_scm",(void*)f_343},
{"f_346:chicken_scm",(void*)f_346},
{"f_349:chicken_scm",(void*)f_349},
{"f_352:chicken_scm",(void*)f_352},
{"f_355:chicken_scm",(void*)f_355},
{"f_358:chicken_scm",(void*)f_358},
{"f_361:chicken_scm",(void*)f_361},
{"f_364:chicken_scm",(void*)f_364},
{"f_367:chicken_scm",(void*)f_367},
{"f_370:chicken_scm",(void*)f_370},
{"f_373:chicken_scm",(void*)f_373},
{"f_376:chicken_scm",(void*)f_376},
{"f_379:chicken_scm",(void*)f_379},
{"f_382:chicken_scm",(void*)f_382},
{"f_385:chicken_scm",(void*)f_385},
{"f_388:chicken_scm",(void*)f_388},
{"f_392:chicken_scm",(void*)f_392},
{"f_1236:chicken_scm",(void*)f_1236},
{"f_1243:chicken_scm",(void*)f_1243},
{"f_1246:chicken_scm",(void*)f_1246},
{"f_1249:chicken_scm",(void*)f_1249},
{"f_1354:chicken_scm",(void*)f_1354},
{"f_1367:chicken_scm",(void*)f_1367},
{"f_1465:chicken_scm",(void*)f_1465},
{"f_1463:chicken_scm",(void*)f_1463},
{"f_1427:chicken_scm",(void*)f_1427},
{"f_1451:chicken_scm",(void*)f_1451},
{"f_1435:chicken_scm",(void*)f_1435},
{"f_1439:chicken_scm",(void*)f_1439},
{"f_1255:chicken_scm",(void*)f_1255},
{"f_1265:chicken_scm",(void*)f_1265},
{"f_1339:chicken_scm",(void*)f_1339},
{"f_1319:chicken_scm",(void*)f_1319},
{"f_1289:chicken_scm",(void*)f_1289},
{"f_1285:chicken_scm",(void*)f_1285},
{"f_1234:chicken_scm",(void*)f_1234},
{"f_395:chicken_scm",(void*)f_395},
{"f_1095:chicken_scm",(void*)f_1095},
{"f_1099:chicken_scm",(void*)f_1099},
{"f_1111:chicken_scm",(void*)f_1111},
{"f_1211:chicken_scm",(void*)f_1211},
{"f_1114:chicken_scm",(void*)f_1114},
{"f_1121:chicken_scm",(void*)f_1121},
{"f_1191:chicken_scm",(void*)f_1191},
{"f_1207:chicken_scm",(void*)f_1207},
{"f_1171:chicken_scm",(void*)f_1171},
{"f_1145:chicken_scm",(void*)f_1145},
{"f_1141:chicken_scm",(void*)f_1141},
{"f_1093:chicken_scm",(void*)f_1093},
{"f_398:chicken_scm",(void*)f_398},
{"f_945:chicken_scm",(void*)f_945},
{"f_949:chicken_scm",(void*)f_949},
{"f_958:chicken_scm",(void*)f_958},
{"f_1081:chicken_scm",(void*)f_1081},
{"f_1089:chicken_scm",(void*)f_1089},
{"f_961:chicken_scm",(void*)f_961},
{"f_1057:chicken_scm",(void*)f_1057},
{"f_972:chicken_scm",(void*)f_972},
{"f_1055:chicken_scm",(void*)f_1055},
{"f_982:chicken_scm",(void*)f_982},
{"f_980:chicken_scm",(void*)f_980},
{"f_943:chicken_scm",(void*)f_943},
{"f_401:chicken_scm",(void*)f_401},
{"f_877:chicken_scm",(void*)f_877},
{"f_881:chicken_scm",(void*)f_881},
{"f_884:chicken_scm",(void*)f_884},
{"f_891:chicken_scm",(void*)f_891},
{"f_915:chicken_scm",(void*)f_915},
{"f_935:chicken_scm",(void*)f_935},
{"f_931:chicken_scm",(void*)f_931},
{"f_875:chicken_scm",(void*)f_875},
{"f_404:chicken_scm",(void*)f_404},
{"f_821:chicken_scm",(void*)f_821},
{"f_825:chicken_scm",(void*)f_825},
{"f_828:chicken_scm",(void*)f_828},
{"f_835:chicken_scm",(void*)f_835},
{"f_851:chicken_scm",(void*)f_851},
{"f_819:chicken_scm",(void*)f_819},
{"f_407:chicken_scm",(void*)f_407},
{"f_792:chicken_scm",(void*)f_792},
{"f_796:chicken_scm",(void*)f_796},
{"f_811:chicken_scm",(void*)f_811},
{"f_790:chicken_scm",(void*)f_790},
{"f_410:chicken_scm",(void*)f_410},
{"f_413:chicken_scm",(void*)f_413},
{"f_783:chicken_scm",(void*)f_783},
{"f_779:chicken_scm",(void*)f_779},
{"f_771:chicken_scm",(void*)f_771},
{"f_761:chicken_scm",(void*)f_761},
{"f_769:chicken_scm",(void*)f_769},
{"f_417:chicken_scm",(void*)f_417},
{"f_546:chicken_scm",(void*)f_546},
{"f_558:chicken_scm",(void*)f_558},
{"f_751:chicken_scm",(void*)f_751},
{"f_744:chicken_scm",(void*)f_744},
{"f_707:chicken_scm",(void*)f_707},
{"f_653:chicken_scm",(void*)f_653},
{"f_670:chicken_scm",(void*)f_670},
{"f_656:chicken_scm",(void*)f_656},
{"f_580:chicken_scm",(void*)f_580},
{"f_633:chicken_scm",(void*)f_633},
{"f_623:chicken_scm",(void*)f_623},
{"f_583:chicken_scm",(void*)f_583},
{"f_550:chicken_scm",(void*)f_550},
{"f_553:chicken_scm",(void*)f_553},
{"f_534:chicken_scm",(void*)f_534},
{"f_541:chicken_scm",(void*)f_541},
{"f_526:chicken_scm",(void*)f_526},
{"f_532:chicken_scm",(void*)f_532},
{"f_529:chicken_scm",(void*)f_529},
{"f_419:chicken_scm",(void*)f_419},
{"f_425:chicken_scm",(void*)f_425},
{"f_460:chicken_scm",(void*)f_460},
{"f_486:chicken_scm",(void*)f_486},
{"f_482:chicken_scm",(void*)f_482},
{"f_439:chicken_scm",(void*)f_439},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
