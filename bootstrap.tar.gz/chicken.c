/* Generated from chicken.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-04-18 09:45
   Version 3.1.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 10129	compiled 2008-03-23 on debian (Linux)
   command line: chicken.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -extend private-namespace.scm -output-file chicken.c
   used units: library eval extras srfi_1 match srfi_4 utils support compiler optimizer driver platform backend
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_match_toplevel)
C_externimport void C_ccall C_match_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_4_toplevel)
C_externimport void C_ccall C_srfi_4_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_support_toplevel)
C_externimport void C_ccall C_support_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_compiler_toplevel)
C_externimport void C_ccall C_compiler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_optimizer_toplevel)
C_externimport void C_ccall C_optimizer_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_driver_toplevel)
C_externimport void C_ccall C_driver_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_platform_toplevel)
C_externimport void C_ccall C_platform_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_backend_toplevel)
C_externimport void C_ccall C_backend_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[379];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_686)
static void C_ccall f_686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_689)
static void C_ccall f_689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_692)
static void C_ccall f_692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_695)
static void C_ccall f_695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_698)
static void C_ccall f_698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_701)
static void C_ccall f_701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_704)
static void C_ccall f_704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_707)
static void C_ccall f_707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_710)
static void C_ccall f_710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_713)
static void C_ccall f_713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_716)
static void C_ccall f_716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_719)
static void C_ccall f_719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_722)
static void C_ccall f_722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_728)
static void C_ccall f_728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6906)
static void C_ccall f_6906(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6906)
static void C_ccall f_6906r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6910)
static void C_ccall f_6910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6913)
static void C_ccall f_6913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6916)
static void C_ccall f_6916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6922)
static void C_ccall f_6922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7128)
static void C_ccall f_7128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7108)
static void C_ccall f_7108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7104)
static void C_ccall f_7104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7084)
static void C_ccall f_7084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6947)
static void C_fcall f_6947(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6957)
static void C_ccall f_6957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7076)
static void C_ccall f_7076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6960)
static void C_ccall f_6960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7072)
static void C_ccall f_7072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6963)
static void C_ccall f_6963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6994)
static void C_fcall f_6994(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6974)
static void C_ccall f_6974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6945)
static void C_ccall f_6945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_731)
static void C_ccall f_731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6818)
static void C_ccall f_6818(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6818)
static void C_ccall f_6818r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6835)
static void C_ccall f_6835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6838)
static void C_ccall f_6838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6844)
static void C_fcall f_6844(C_word t0,C_word t1) C_noret;
C_noret_decl(f_734)
static void C_ccall f_734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6777)
static void C_ccall f_6777(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6777)
static void C_ccall f_6777r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6781)
static void C_ccall f_6781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_737)
static void C_ccall f_737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6761)
static void C_ccall f_6761(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6761)
static void C_ccall f_6761r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6771)
static void C_ccall f_6771(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6769)
static void C_ccall f_6769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_740)
static void C_ccall f_740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6684)
static void C_ccall f_6684(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6688)
static void C_ccall f_6688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6756)
static void C_ccall f_6756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6691)
static void C_ccall f_6691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6700)
static void C_ccall f_6700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6747)
static void C_ccall f_6747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6714)
static void C_ccall f_6714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6722)
static void C_ccall f_6722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6724)
static void C_fcall f_6724(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6741)
static void C_ccall f_6741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6706)
static void C_ccall f_6706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6698)
static void C_ccall f_6698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_743)
static void C_ccall f_743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6624)
static void C_ccall f_6624(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6624)
static void C_ccall f_6624r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6628)
static void C_fcall f_6628(C_word t0,C_word t1) C_noret;
C_noret_decl(f_746)
static void C_ccall f_746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6565)
static void C_ccall f_6565(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6565)
static void C_ccall f_6565r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6569)
static void C_ccall f_6569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6596)
static void C_fcall f_6596(C_word t0,C_word t1) C_noret;
C_noret_decl(f_749)
static void C_ccall f_749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6391)
static void C_ccall f_6391(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6391)
static void C_ccall f_6391r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6395)
static void C_ccall f_6395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6398)
static void C_ccall f_6398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6559)
static void C_ccall f_6559(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6401)
static void C_ccall f_6401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6553)
static void C_ccall f_6553(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6404)
static void C_ccall f_6404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6551)
static void C_ccall f_6551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6515)
static void C_ccall f_6515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6529)
static void C_fcall f_6529(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6543)
static void C_ccall f_6543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6523)
static void C_ccall f_6523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6519)
static void C_ccall f_6519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6411)
static void C_ccall f_6411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6507)
static void C_ccall f_6507(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6483)
static void C_ccall f_6483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6501)
static void C_ccall f_6501(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6491)
static void C_ccall f_6491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6487)
static void C_ccall f_6487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6479)
static void C_ccall f_6479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6463)
static void C_ccall f_6463(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6439)
static void C_ccall f_6439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6457)
static void C_ccall f_6457(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6447)
static void C_ccall f_6447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6443)
static void C_ccall f_6443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6435)
static void C_ccall f_6435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_752)
static void C_ccall f_752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6296)
static void C_ccall f_6296(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6296)
static void C_ccall f_6296r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6332)
static void C_fcall f_6332(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6345)
static void C_ccall f_6345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6303)
static void C_ccall f_6303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_755)
static void C_ccall f_755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6186)
static void C_ccall f_6186(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6186)
static void C_ccall f_6186r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6190)
static void C_ccall f_6190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6193)
static void C_ccall f_6193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6196)
static void C_ccall f_6196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6199)
static void C_ccall f_6199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6290)
static void C_ccall f_6290(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6202)
static void C_ccall f_6202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6284)
static void C_ccall f_6284(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6205)
static void C_ccall f_6205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6278)
static void C_ccall f_6278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6282)
static void C_ccall f_6282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6212)
static void C_ccall f_6212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6250)
static void C_ccall f_6250(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6248)
static void C_ccall f_6248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_758)
static void C_ccall f_758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6176)
static void C_ccall f_6176(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6176)
static void C_ccall f_6176r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_761)
static void C_ccall f_761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6162)
static void C_ccall f_6162(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6162)
static void C_ccall f_6162r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_764)
static void C_ccall f_764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_838)
static void C_ccall f_838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_841)
static void C_ccall f_841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5900)
static void C_ccall f_5900(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5904)
static void C_ccall f_5904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5913)
static void C_ccall f_5913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6122)
static void C_fcall f_6122(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6135)
static void C_ccall f_6135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5916)
static void C_ccall f_5916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6112)
static void C_ccall f_6112(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6120)
static void C_ccall f_6120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5919)
static void C_ccall f_5919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6066)
static void C_fcall f_6066(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6099)
static void C_ccall f_6099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6106)
static void C_ccall f_6106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6082)
static void C_fcall f_6082(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5931)
static void C_ccall f_5931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6060)
static void C_ccall f_6060(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5938)
static void C_ccall f_5938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5940)
static void C_fcall f_5940(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6054)
static void C_ccall f_6054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5974)
static void C_fcall f_5974(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6028)
static void C_ccall f_6028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6005)
static void C_ccall f_6005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5985)
static void C_ccall f_5985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5960)
static void C_ccall f_5960(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5968)
static void C_ccall f_5968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5958)
static void C_ccall f_5958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5920)
static void C_ccall f_5920(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5860)
static void C_fcall f_5860(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5883)
static void C_ccall f_5883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5887)
static void C_ccall f_5887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5829)
static void C_fcall f_5829(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5850)
static void C_ccall f_5850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_844)
static void C_ccall f_844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5778)
static void C_ccall f_5778(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5782)
static void C_ccall f_5782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5793)
static void C_fcall f_5793(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5818)
static void C_ccall f_5818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_847)
static void C_ccall f_847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5658)
static void C_ccall f_5658(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5662)
static void C_ccall f_5662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5772)
static void C_ccall f_5772(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5770)
static void C_ccall f_5770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5671)
static void C_ccall f_5671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5758)
static void C_ccall f_5758(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5766)
static void C_ccall f_5766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5674)
static void C_ccall f_5674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5752)
static void C_ccall f_5752(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5694)
static void C_ccall f_5694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5704)
static void C_ccall f_5704(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5724)
static void C_ccall f_5724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5730)
static void C_ccall f_5730(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5738)
static void C_ccall f_5738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5728)
static void C_ccall f_5728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5702)
static void C_ccall f_5702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5698)
static void C_ccall f_5698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5675)
static void C_ccall f_5675(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_850)
static void C_ccall f_850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5637)
static void C_ccall f_5637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5641)
static void C_ccall f_5641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_853)
static void C_ccall f_853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5627)
static void C_ccall f_5627(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_859)
static void C_ccall f_859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_868)
static void C_fcall f_868(C_word t0,C_word t1) C_noret;
C_noret_decl(f_884)
static void C_fcall f_884(C_word t0,C_word t1) C_noret;
C_noret_decl(f_871)
static void C_ccall f_871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_932)
static void C_ccall f_932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5606)
static void C_ccall f_5606(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5610)
static void C_ccall f_5610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_935)
static void C_ccall f_935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5490)
static void C_ccall f_5490(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5494)
static void C_ccall f_5494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5503)
static void C_fcall f_5503(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5517)
static void C_fcall f_5517(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5581)
static void C_ccall f_5581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5563)
static void C_ccall f_5563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5546)
static void C_ccall f_5546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_938)
static void C_ccall f_938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5391)
static void C_ccall f_5391(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5401)
static void C_ccall f_5401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5414)
static void C_fcall f_5414(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5430)
static void C_ccall f_5430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5468)
static void C_ccall f_5468(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5466)
static void C_ccall f_5466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5458)
static void C_ccall f_5458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5412)
static void C_ccall f_5412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_941)
static void C_ccall f_941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5302)
static void C_ccall f_5302(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5312)
static void C_ccall f_5312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5325)
static void C_fcall f_5325(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5341)
static void C_ccall f_5341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5369)
static void C_ccall f_5369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5323)
static void C_ccall f_5323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_944)
static void C_ccall f_944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5016)
static void C_ccall f_5016(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5016)
static void C_ccall f_5016r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5213)
static void C_ccall f_5213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5216)
static void C_ccall f_5216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5219)
static void C_ccall f_5219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5292)
static void C_ccall f_5292(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5300)
static void C_ccall f_5300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5235)
static void C_ccall f_5235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5238)
static void C_ccall f_5238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5241)
static void C_ccall f_5241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5244)
static void C_ccall f_5244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5282)
static void C_ccall f_5282(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5290)
static void C_ccall f_5290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5247)
static void C_ccall f_5247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5027)
static void C_ccall f_5027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5031)
static void C_ccall f_5031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5035)
static void C_ccall f_5035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5037)
static void C_fcall f_5037(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5082)
static void C_ccall f_5082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5094)
static void C_ccall f_5094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5090)
static void C_ccall f_5090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5058)
static void C_ccall f_5058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5250)
static void C_ccall f_5250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5110)
static void C_fcall f_5110(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5210)
static void C_ccall f_5210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5174)
static void C_ccall f_5174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5144)
static void C_ccall f_5144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5253)
static void C_ccall f_5253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5220)
static void C_fcall f_5220(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5232)
static void C_ccall f_5232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5228)
static void C_ccall f_5228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_947)
static void C_ccall f_947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4959)
static void C_ccall f_4959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4963)
static void C_ccall f_4963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_950)
static void C_ccall f_950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4953)
static void C_ccall f_4953(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_953)
static void C_ccall f_953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4800)
static void C_ccall f_4800(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4800)
static void C_ccall f_4800r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4804)
static void C_ccall f_4804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4807)
static void C_ccall f_4807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4810)
static void C_ccall f_4810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4823)
static void C_fcall f_4823(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4873)
static void C_ccall f_4873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4884)
static void C_ccall f_4884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4821)
static void C_ccall f_4821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_956)
static void C_ccall f_956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4524)
static void C_ccall f_4524(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4558)
static void C_ccall f_4558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4561)
static void C_ccall f_4561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4787)
static void C_ccall f_4787(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4797)
static void C_ccall f_4797(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4785)
static void C_ccall f_4785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4564)
static void C_ccall f_4564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4533)
static void C_fcall f_4533(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4547)
static void C_ccall f_4547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4551)
static void C_ccall f_4551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4567)
static void C_ccall f_4567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4570)
static void C_ccall f_4570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4573)
static void C_ccall f_4573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4580)
static void C_ccall f_4580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4594)
static void C_ccall f_4594(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4604)
static void C_ccall f_4604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4608)
static void C_ccall f_4608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4618)
static void C_fcall f_4618(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4634)
static void C_ccall f_4634(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4653)
static void C_fcall f_4653(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4709)
static void C_ccall f_4709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4720)
static void C_ccall f_4720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4638)
static void C_ccall f_4638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4651)
static void C_ccall f_4651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4624)
static void C_ccall f_4624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4632)
static void C_ccall f_4632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4622)
static void C_ccall f_4622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4592)
static void C_ccall f_4592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_959)
static void C_ccall f_959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4467)
static void C_ccall f_4467(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4467)
static void C_ccall f_4467r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4507)
static void C_ccall f_4507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4477)
static void C_ccall f_4477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_962)
static void C_ccall f_962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4391)
static void C_ccall f_4391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4391)
static void C_ccall f_4391r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4395)
static void C_ccall f_4395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4398)
static void C_ccall f_4398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_965)
static void C_ccall f_965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4207)
static void C_ccall f_4207(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4207)
static void C_ccall f_4207r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4211)
static void C_ccall f_4211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4214)
static void C_ccall f_4214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4357)
static void C_ccall f_4357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4353)
static void C_ccall f_4353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4216)
static void C_ccall f_4216(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4304)
static void C_ccall f_4304(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4302)
static void C_ccall f_4302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4272)
static void C_fcall f_4272(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4239)
static void C_fcall f_4239(C_word t0,C_word t1) C_noret;
C_noret_decl(f_968)
static void C_ccall f_968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4017)
static void C_ccall f_4017(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_4017)
static void C_ccall f_4017r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_4024)
static void C_ccall f_4024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4196)
static void C_ccall f_4196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4049)
static void C_fcall f_4049(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4075)
static void C_fcall f_4075(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4103)
static void C_fcall f_4103(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4087)
static void C_ccall f_4087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4047)
static void C_ccall f_4047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_971)
static void C_ccall f_971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4008)
static void C_ccall f_4008(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4012)
static void C_ccall f_4012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_974)
static void C_ccall f_974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3989)
static void C_ccall f_3989(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3993)
static void C_ccall f_3993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4002)
static void C_ccall f_4002(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4000)
static void C_ccall f_4000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_977)
static void C_ccall f_977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3970)
static void C_ccall f_3970(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3974)
static void C_ccall f_3974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3983)
static void C_ccall f_3983(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3981)
static void C_ccall f_3981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_980)
static void C_ccall f_980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3842)
static void C_ccall f_3842(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3848)
static void C_fcall f_3848(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3929)
static void C_ccall f_3929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3858)
static void C_ccall f_3858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3861)
static void C_ccall f_3861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3867)
static void C_ccall f_3867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3874)
static void C_ccall f_3874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3890)
static void C_ccall f_3890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_983)
static void C_ccall f_983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3699)
static void C_ccall f_3699(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3705)
static void C_fcall f_3705(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3817)
static void C_ccall f_3817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3790)
static void C_ccall f_3790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3715)
static void C_ccall f_3715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3718)
static void C_ccall f_3718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3724)
static void C_ccall f_3724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3735)
static void C_ccall f_3735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3751)
static void C_ccall f_3751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_986)
static void C_ccall f_986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3640)
static void C_ccall f_3640(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_3640)
static void C_ccall f_3640r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_989)
static void C_ccall f_989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3475)
static void C_fcall f_3475(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3549)
static void C_fcall f_3549(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3552)
static void C_ccall f_3552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3625)
static void C_ccall f_3625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3618)
static void C_ccall f_3618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3610)
static void C_ccall f_3610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3597)
static void C_ccall f_3597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3576)
static void C_ccall f_3576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3485)
static void C_fcall f_3485(C_word t0,C_word t1) C_noret;
C_noret_decl(f_992)
static void C_ccall f_992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3418)
static void C_ccall f_3418(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3418)
static void C_ccall f_3418r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_995)
static void C_ccall f_995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3358)
static void C_ccall f_3358(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3358)
static void C_ccall f_3358r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3368)
static void C_fcall f_3368(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3387)
static void C_ccall f_3387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3371)
static void C_ccall f_3371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_998)
static void C_ccall f_998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1001)
static void C_ccall f_1001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3321)
static void C_ccall f_3321(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3325)
static void C_ccall f_3325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1004)
static void C_ccall f_1004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3302)
static void C_ccall f_3302(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3306)
static void C_ccall f_3306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3315)
static void C_ccall f_3315(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3313)
static void C_ccall f_3313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1007)
static void C_ccall f_1007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3283)
static void C_ccall f_3283(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3287)
static void C_ccall f_3287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3296)
static void C_ccall f_3296(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3294)
static void C_ccall f_3294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1010)
static void C_ccall f_1010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3264)
static void C_ccall f_3264(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3268)
static void C_ccall f_3268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3277)
static void C_ccall f_3277(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3275)
static void C_ccall f_3275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1013)
static void C_ccall f_1013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3245)
static void C_ccall f_3245(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3249)
static void C_ccall f_3249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3258)
static void C_ccall f_3258(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3256)
static void C_ccall f_3256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1016)
static void C_ccall f_1016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3226)
static void C_ccall f_3226(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3230)
static void C_ccall f_3230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3239)
static void C_ccall f_3239(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3237)
static void C_ccall f_3237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1019)
static void C_ccall f_1019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3207)
static void C_ccall f_3207(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3211)
static void C_ccall f_3211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3220)
static void C_ccall f_3220(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3218)
static void C_ccall f_3218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1022)
static void C_ccall f_1022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3107)
static void C_ccall f_3107(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3111)
static void C_ccall f_3111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3166)
static void C_ccall f_3166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3120)
static void C_ccall f_3120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1025)
static void C_ccall f_1025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2887)
static void C_ccall f_2887(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2891)
static void C_fcall f_2891(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2894)
static void C_fcall f_2894(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2975)
static void C_ccall f_2975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3042)
static void C_ccall f_3042(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3032)
static void C_ccall f_3032(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3020)
static void C_ccall f_3020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2900)
static void C_ccall f_2900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2926)
static void C_fcall f_2926(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1028)
static void C_ccall f_1028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2812)
static void C_ccall f_2812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2812)
static void C_ccall f_2812r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2816)
static void C_ccall f_2816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2885)
static void C_ccall f_2885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2839)
static void C_fcall f_2839(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1031)
static void C_ccall f_1031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2706)
static void C_ccall f_2706(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2706)
static void C_ccall f_2706r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2806)
static void C_ccall f_2806(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2710)
static void C_ccall f_2710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2782)
static void C_ccall f_2782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2717)
static void C_ccall f_2717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2723)
static void C_ccall f_2723(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2721)
static void C_ccall f_2721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1034)
static void C_ccall f_1034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2677)
static void C_ccall f_2677(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2681)
static void C_ccall f_2681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2704)
static void C_ccall f_2704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2700)
static void C_ccall f_2700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1037)
static void C_ccall f_1037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2664)
static void C_ccall f_2664(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2668)
static void C_ccall f_2668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1040)
static void C_ccall f_1040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1874)
static void C_ccall f_1874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1880)
static void C_ccall f_1880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1883)
static void C_ccall f_1883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1886)
static void C_ccall f_1886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1889)
static void C_ccall f_1889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2556)
static void C_fcall f_2556(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2635)
static void C_ccall f_2635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2631)
static void C_ccall f_2631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2566)
static void C_fcall f_2566(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2570)
static void C_ccall f_2570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2611)
static void C_ccall f_2611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2601)
static void C_ccall f_2601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2591)
static void C_ccall f_2591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2587)
static void C_ccall f_2587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2573)
static void C_ccall f_2573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1977)
static void C_ccall f_1977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1980)
static void C_ccall f_1980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2550)
static void C_ccall f_2550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2479)
static void C_ccall f_2479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2485)
static void C_ccall f_2485(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2539)
static void C_ccall f_2539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2531)
static void C_ccall f_2531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2502)
static void C_ccall f_2502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2483)
static void C_ccall f_2483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2467)
static void C_ccall f_2467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2463)
static void C_ccall f_2463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1991)
static void C_fcall f_1991(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2445)
static void C_ccall f_2445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1999)
static void C_fcall f_1999(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2007)
static void C_fcall f_2007(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2013)
static void C_ccall f_2013(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2290)
static void C_ccall f_2290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2402)
static void C_ccall f_2402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2398)
static void C_ccall f_2398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2367)
static void C_ccall f_2367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2390)
static void C_ccall f_2390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2379)
static void C_ccall f_2379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2308)
static void C_fcall f_2308(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2353)
static void C_ccall f_2353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2349)
static void C_ccall f_2349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2325)
static void C_ccall f_2325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2337)
static void C_ccall f_2337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2305)
static void C_fcall f_2305(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2035)
static void C_ccall f_2035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2275)
static void C_ccall f_2275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2271)
static void C_ccall f_2271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2176)
static void C_ccall f_2176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2259)
static void C_ccall f_2259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2248)
static void C_ccall f_2248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2053)
static void C_fcall f_2053(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2162)
static void C_ccall f_2162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2158)
static void C_ccall f_2158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2070)
static void C_ccall f_2070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2050)
static void C_fcall f_2050(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2011)
static void C_ccall f_2011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2003)
static void C_ccall f_2003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1995)
static void C_ccall f_1995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1987)
static void C_ccall f_1987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1934)
static void C_fcall f_1934(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1950)
static void C_ccall f_1950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1891)
static void C_fcall f_1891(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1043)
static void C_ccall f_1043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1856)
static void C_ccall f_1856(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1046)
static void C_ccall f_1046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1516)
static void C_ccall f_1516(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1516)
static void C_ccall f_1516r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1520)
static void C_fcall f_1520(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1523)
static void C_ccall f_1523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1828)
static void C_ccall f_1828(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1526)
static void C_ccall f_1526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1803)
static void C_ccall f_1803(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1529)
static void C_ccall f_1529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1771)
static void C_ccall f_1771(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1532)
static void C_ccall f_1532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1745)
static void C_ccall f_1745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1535)
static void C_fcall f_1535(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1538)
static void C_ccall f_1538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1733)
static void C_ccall f_1733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1541)
static void C_ccall f_1541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1729)
static void C_ccall f_1729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1544)
static void C_ccall f_1544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1717)
static void C_ccall f_1717(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1725)
static void C_ccall f_1725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1555)
static void C_ccall f_1555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1679)
static void C_ccall f_1679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1661)
static void C_ccall f_1661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1657)
static void C_ccall f_1657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1597)
static void C_ccall f_1597(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1587)
static void C_ccall f_1587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1583)
static void C_ccall f_1583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1551)
static void C_ccall f_1551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1049)
static void C_ccall f_1049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1482)
static void C_ccall f_1482(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1052)
static void C_ccall f_1052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1420)
static void C_ccall f_1420(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1420)
static void C_ccall f_1420r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1433)
static void C_fcall f_1433(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1459)
static void C_ccall f_1459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1430)
static void C_ccall f_1430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1423)
static void C_fcall f_1423(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1055)
static void C_ccall f_1055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1418)
static void C_ccall f_1418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1411)
static void C_ccall f_1411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1407)
static void C_ccall f_1407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1399)
static void C_ccall f_1399(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1397)
static void C_ccall f_1397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1059)
static void C_ccall f_1059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1188)
static void C_ccall f_1188(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1200)
static void C_fcall f_1200(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1383)
static void C_ccall f_1383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1376)
static void C_ccall f_1376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1339)
static void C_ccall f_1339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1285)
static void C_ccall f_1285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1302)
static void C_ccall f_1302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1288)
static void C_ccall f_1288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1222)
static void C_ccall f_1222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1265)
static void C_ccall f_1265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1245)
static void C_ccall f_1245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1225)
static void C_ccall f_1225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1192)
static void C_ccall f_1192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1195)
static void C_ccall f_1195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1176)
static void C_ccall f_1176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1183)
static void C_ccall f_1183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1168)
static void C_ccall f_1168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1174)
static void C_ccall f_1174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1171)
static void C_ccall f_1171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1061)
static void C_ccall f_1061(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1067)
static void C_fcall f_1067(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1102)
static void C_fcall f_1102(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1128)
static void C_ccall f_1128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1124)
static void C_ccall f_1124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1081)
static void C_ccall f_1081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_765)
static void C_ccall f_765(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_769)
static void C_ccall f_769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_806)
static void C_ccall f_806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_827)
static void C_ccall f_827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_825)
static void C_ccall f_825(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_6947)
static void C_fcall trf_6947(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6947(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6947(t0,t1,t2,t3);}

C_noret_decl(trf_6994)
static void C_fcall trf_6994(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6994(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6994(t0,t1);}

C_noret_decl(trf_6844)
static void C_fcall trf_6844(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6844(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6844(t0,t1);}

C_noret_decl(trf_6724)
static void C_fcall trf_6724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6724(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6724(t0,t1,t2,t3);}

C_noret_decl(trf_6628)
static void C_fcall trf_6628(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6628(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6628(t0,t1);}

C_noret_decl(trf_6596)
static void C_fcall trf_6596(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6596(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6596(t0,t1);}

C_noret_decl(trf_6529)
static void C_fcall trf_6529(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6529(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6529(t0,t1,t2);}

C_noret_decl(trf_6332)
static void C_fcall trf_6332(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6332(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6332(t0,t1,t2);}

C_noret_decl(trf_6122)
static void C_fcall trf_6122(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6122(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6122(t0,t1,t2,t3);}

C_noret_decl(trf_6066)
static void C_fcall trf_6066(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6066(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6066(t0,t1,t2,t3);}

C_noret_decl(trf_6082)
static void C_fcall trf_6082(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6082(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6082(t0,t1);}

C_noret_decl(trf_5940)
static void C_fcall trf_5940(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5940(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5940(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5974)
static void C_fcall trf_5974(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5974(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5974(t0,t1);}

C_noret_decl(trf_5860)
static void C_fcall trf_5860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5860(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5860(t0,t1,t2,t3);}

C_noret_decl(trf_5829)
static void C_fcall trf_5829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5829(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5829(t0,t1,t2,t3);}

C_noret_decl(trf_5793)
static void C_fcall trf_5793(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5793(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5793(t0,t1,t2);}

C_noret_decl(trf_868)
static void C_fcall trf_868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_868(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_868(t0,t1);}

C_noret_decl(trf_884)
static void C_fcall trf_884(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_884(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_884(t0,t1);}

C_noret_decl(trf_5503)
static void C_fcall trf_5503(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5503(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5503(t0,t1);}

C_noret_decl(trf_5517)
static void C_fcall trf_5517(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5517(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5517(t0,t1,t2);}

C_noret_decl(trf_5414)
static void C_fcall trf_5414(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5414(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5414(t0,t1,t2);}

C_noret_decl(trf_5325)
static void C_fcall trf_5325(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5325(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5325(t0,t1,t2);}

C_noret_decl(trf_5037)
static void C_fcall trf_5037(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5037(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5037(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5110)
static void C_fcall trf_5110(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5110(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5110(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5220)
static void C_fcall trf_5220(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5220(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5220(t0,t1,t2);}

C_noret_decl(trf_4823)
static void C_fcall trf_4823(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4823(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4823(t0,t1,t2,t3);}

C_noret_decl(trf_4533)
static void C_fcall trf_4533(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4533(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4533(t0,t1,t2);}

C_noret_decl(trf_4618)
static void C_fcall trf_4618(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4618(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4618(t0,t1);}

C_noret_decl(trf_4653)
static void C_fcall trf_4653(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4653(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4653(t0,t1,t2,t3);}

C_noret_decl(trf_4272)
static void C_fcall trf_4272(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4272(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4272(t0,t1);}

C_noret_decl(trf_4239)
static void C_fcall trf_4239(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4239(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4239(t0,t1);}

C_noret_decl(trf_4049)
static void C_fcall trf_4049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4049(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4049(t0,t1,t2,t3);}

C_noret_decl(trf_4075)
static void C_fcall trf_4075(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4075(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4075(t0,t1);}

C_noret_decl(trf_4103)
static void C_fcall trf_4103(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4103(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4103(t0,t1);}

C_noret_decl(trf_3848)
static void C_fcall trf_3848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3848(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3848(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3705)
static void C_fcall trf_3705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3705(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3705(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3475)
static void C_fcall trf_3475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3475(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3475(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3549)
static void C_fcall trf_3549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3549(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3549(t0,t1);}

C_noret_decl(trf_3485)
static void C_fcall trf_3485(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3485(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3485(t0,t1);}

C_noret_decl(trf_3368)
static void C_fcall trf_3368(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3368(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3368(t0,t1);}

C_noret_decl(trf_2891)
static void C_fcall trf_2891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2891(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2891(t0,t1);}

C_noret_decl(trf_2894)
static void C_fcall trf_2894(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2894(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2894(t0,t1);}

C_noret_decl(trf_2926)
static void C_fcall trf_2926(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2926(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2926(t0,t1);}

C_noret_decl(trf_2839)
static void C_fcall trf_2839(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2839(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2839(t0,t1);}

C_noret_decl(trf_2556)
static void C_fcall trf_2556(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2556(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2556(t0,t1,t2);}

C_noret_decl(trf_2566)
static void C_fcall trf_2566(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2566(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2566(t0,t1);}

C_noret_decl(trf_1991)
static void C_fcall trf_1991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1991(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1991(t0,t1);}

C_noret_decl(trf_1999)
static void C_fcall trf_1999(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1999(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1999(t0,t1);}

C_noret_decl(trf_2007)
static void C_fcall trf_2007(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2007(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2007(t0,t1);}

C_noret_decl(trf_2308)
static void C_fcall trf_2308(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2308(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2308(t0,t1);}

C_noret_decl(trf_2305)
static void C_fcall trf_2305(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2305(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2305(t0,t1);}

C_noret_decl(trf_2053)
static void C_fcall trf_2053(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2053(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2053(t0,t1);}

C_noret_decl(trf_2050)
static void C_fcall trf_2050(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2050(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2050(t0,t1);}

C_noret_decl(trf_1934)
static void C_fcall trf_1934(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1934(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1934(t0,t1,t2);}

C_noret_decl(trf_1891)
static void C_fcall trf_1891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1891(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1891(t0,t1,t2);}

C_noret_decl(trf_1520)
static void C_fcall trf_1520(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1520(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1520(t0,t1);}

C_noret_decl(trf_1535)
static void C_fcall trf_1535(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1535(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1535(t0,t1);}

C_noret_decl(trf_1433)
static void C_fcall trf_1433(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1433(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1433(t0,t1);}

C_noret_decl(trf_1423)
static void C_fcall trf_1423(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1423(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1423(t0,t1);}

C_noret_decl(trf_1200)
static void C_fcall trf_1200(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1200(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1200(t0,t1,t2);}

C_noret_decl(trf_1067)
static void C_fcall trf_1067(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1067(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1067(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1102)
static void C_fcall trf_1102(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1102(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1102(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(4053)){
C_save(t1);
C_rereclaim2(4053*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,379);
lf[0]=C_h_intern(&lf[0],19,"\003sysundefined-value");
lf[1]=C_h_intern(&lf[1],3,"map");
lf[2]=C_h_intern(&lf[2],6,"lambda");
lf[3]=C_h_intern(&lf[3],14,"\004coreundefined");
lf[4]=C_h_intern(&lf[4],20,"\003syscall-with-values");
lf[5]=C_h_intern(&lf[5],9,"\004coreset!");
lf[6]=C_h_intern(&lf[6],6,"gensym");
lf[7]=C_h_intern(&lf[7],16,"\003syscheck-syntax");
lf[8]=C_h_intern(&lf[8],25,"set!-values/define-values");
lf[9]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[10]=C_h_intern(&lf[10],27,"\010compilercompiler-arguments");
lf[11]=C_h_intern(&lf[11],29,"\010compilerprocess-command-line");
lf[12]=C_h_intern(&lf[12],7,"reverse");
lf[13]=C_h_intern(&lf[13],14,"string->symbol");
lf[14]=C_h_intern(&lf[14],9,"substring");
lf[15]=C_h_intern(&lf[15],25,"\003sysimplicit-exit-handler");
lf[16]=C_h_intern(&lf[16],17,"user-options-pass");
lf[17]=C_h_intern(&lf[17],4,"exit");
lf[18]=C_h_intern(&lf[18],19,"compile-source-file");
lf[19]=C_h_intern(&lf[19],14,"optimize-level");
lf[20]=C_h_intern(&lf[20],5,"cons*");
lf[21]=C_h_intern(&lf[21],22,"optimize-leaf-routines");
lf[22]=C_h_intern(&lf[22],6,"unsafe");
lf[23]=C_h_intern(&lf[23],25,"\010compilercompiler-warning");
lf[24]=C_h_intern(&lf[24],5,"usage");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\047invalid optimization level ~S - ignored");
lf[26]=C_h_intern(&lf[26],11,"debug-level");
lf[27]=C_h_intern(&lf[27],14,"no-lambda-info");
lf[28]=C_h_intern(&lf[28],8,"no-trace");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000 invalid debug level ~S - ignored");
lf[30]=C_h_intern(&lf[30],14,"benchmark-mode");
lf[31]=C_h_intern(&lf[31],17,"fixnum-arithmetic");
lf[32]=C_h_intern(&lf[32],18,"disable-interrupts");
lf[33]=C_h_intern(&lf[33],5,"block");
lf[34]=C_h_intern(&lf[34],11,"lambda-lift");
lf[35]=C_h_intern(&lf[35],31,"\010compilervalid-compiler-options");
lf[36]=C_h_intern(&lf[36],45,"\010compilervalid-compiler-options-with-argument");
lf[37]=C_h_intern(&lf[37],4,"quit");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~s\047 option");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000&invalid compiler option `~a\047 - ignored");
lf[40]=C_h_intern(&lf[40],4,"conc");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[42]=C_h_intern(&lf[42],6,"append");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[44]=C_h_intern(&lf[44],6,"remove");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[46]=C_h_intern(&lf[46],12,"string-split");
lf[47]=C_h_intern(&lf[47],6,"getenv");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\017CHICKEN_OPTIONS");
lf[49]=C_h_intern(&lf[49],4,"argv");
lf[50]=C_h_intern(&lf[50],12,"syntax-error");
lf[51]=C_h_intern(&lf[51],21,"define-compiler-macro");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000!invalid compiler macro definition");
lf[53]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004void\376\377\016");
lf[54]=C_h_intern(&lf[54],9,"compiling");
lf[55]=C_h_intern(&lf[55],12,"\003sysfeatures");
lf[56]=C_h_intern(&lf[56],7,"warning");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\0004compile macros are not available in interpreted code");
lf[58]=C_h_intern(&lf[58],32,"\010compilerregister-compiler-macro");
lf[59]=C_h_intern(&lf[59],18,"\003sysregister-macro");
lf[60]=C_h_intern(&lf[60],4,"args");
lf[61]=C_h_intern(&lf[61],5,"quote");
lf[62]=C_h_intern(&lf[62],7,"sprintf");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000$`~s\047 is deprecated, use `~s\047 instead");
lf[64]=C_h_intern(&lf[64],4,"cons");
lf[65]=C_h_intern(&lf[65],12,"define-macro");
lf[66]=C_h_intern(&lf[66],23,"define-deprecated-macro");
lf[67]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016");
lf[68]=C_h_intern(&lf[68],5,"begin");
lf[69]=C_h_intern(&lf[69],4,"syms");
lf[70]=C_h_intern(&lf[70],7,"symbol\077");
lf[71]=C_h_intern(&lf[71],4,"list");
lf[72]=C_h_intern(&lf[72],2,"if");
lf[73]=C_h_intern(&lf[73],3,"sum");
lf[74]=C_h_intern(&lf[74],5,"null\077");
lf[75]=C_h_intern(&lf[75],3,"cdr");
lf[76]=C_h_intern(&lf[76],3,"car");
lf[77]=C_h_intern(&lf[77],3,"val");
lf[78]=C_h_intern(&lf[78],4,"case");
lf[79]=C_h_intern(&lf[79],3,"let");
lf[80]=C_h_intern(&lf[80],11,"bitwise-ior");
lf[81]=C_h_intern(&lf[81],4,"loop");
lf[82]=C_h_intern(&lf[82],6,"define");
lf[83]=C_h_intern(&lf[83],4,"cond");
lf[84]=C_h_intern(&lf[84],19,"define-foreign-type");
lf[85]=C_h_intern(&lf[85],10,"\003sysappend");
lf[86]=C_h_intern(&lf[86],4,"else");
lf[87]=C_h_intern(&lf[87],1,"=");
lf[88]=C_h_intern(&lf[88],5,"error");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\024not a member of enum");
lf[90]=C_h_intern(&lf[90],23,"define-foreign-variable");
lf[91]=C_h_intern(&lf[91],8,"->string");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\010number->");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\010->number");
lf[94]=C_h_intern(&lf[94],7,"\003sysmap");
lf[95]=C_h_intern(&lf[95],19,"define-foreign-enum");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid type specification");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid enum specification");
lf[98]=C_h_intern(&lf[98],15,"foreign-declare");
lf[99]=C_h_intern(&lf[99],12,"\004coredeclare");
lf[100]=C_h_intern(&lf[100],20,"\003sysregister-macro-2");
lf[101]=C_h_intern(&lf[101],8,"identity");
lf[102]=C_h_intern(&lf[102],5,"const");
lf[103]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\005union\376\377\016");
lf[104]=C_h_intern(&lf[104],9,"c-pointer");
lf[105]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\005union\376\377\016");
lf[106]=C_h_intern(&lf[106],3,"int");
lf[107]=C_h_intern(&lf[107],15,"foreign-lambda*");
lf[108]=C_h_intern(&lf[108],4,"fx>=");
lf[109]=C_h_intern(&lf[109],3,"fx<");
lf[110]=C_h_intern(&lf[110],3,"and");
lf[111]=C_h_intern(&lf[111],10,"\004corecheck");
lf[112]=C_h_intern(&lf[112],21,"define-foreign-record");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\031array access out of range");
lf[114]=C_h_intern(&lf[114],4,"void");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\031array access out of range");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\020~A->~A[~A] = ~A;");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\012~A-~A-set!");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\025return(~A~A->~A[~A]);");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\005~A-~A");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\014~A->~A = ~A;");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\012~A-~A-set!");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\021return(~A~A->~A);");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\005~A-~A");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\015bad slot spec");
lf[129]=C_h_intern(&lf[129],3,"ptr");
lf[130]=C_h_intern(&lf[130],11,"\004coreinline");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\007C_qfree");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000#return((~a *)C_malloc(sizeof(~a)));");
lf[133]=C_h_intern(&lf[133],7,"declare");
lf[134]=C_h_intern(&lf[134],18,"string-intersperse");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\002};");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\007~A[~A];");
lf[138]=C_h_intern(&lf[138],33,"\010compilerforeign-type-declaration");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\003~A;");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\015bad slot spec");
lf[141]=C_h_intern(&lf[141],13,"string-append");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\007struct ");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\003 { ");
lf[144]=C_h_intern(&lf[144],19,"\003syshash-table-set!");
lf[145]=C_h_intern(&lf[145],27,"\010compilerforeign-type-table");
lf[146]=C_h_intern(&lf[146],7,"\000rename");
lf[147]=C_h_intern(&lf[147],4,"eval");
lf[148]=C_h_intern(&lf[148],5,"cadar");
lf[149]=C_h_intern(&lf[149],12,"\000constructor");
lf[150]=C_h_intern(&lf[150],11,"\000destructor");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000)invalid foreign record-type specification");
lf[152]=C_h_intern(&lf[152],4,"caar");
lf[153]=C_h_intern(&lf[153],8,"keyword\077");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\011struct ~A");
lf[155]=C_h_intern(&lf[155],5,"code_");
lf[156]=C_h_intern(&lf[156],13,"foreign-value");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\0007static C_word ~A() { ~A\012; return C_SCHEME_UNDEFINED; }\012");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[159]=C_h_intern(&lf[159],12,"foreign-code");
lf[160]=C_h_intern(&lf[160],17,"\004corelet-location");
lf[161]=C_h_intern(&lf[161],10,"fold-right");
lf[162]=C_h_intern(&lf[162],10,"append-map");
lf[163]=C_h_intern(&lf[163],12,"let-location");
lf[164]=C_h_intern(&lf[164],28,"\004coredefine-foreign-variable");
lf[165]=C_h_intern(&lf[165],29,"\004coredefine-external-variable");
lf[166]=C_h_intern(&lf[166],14,"symbol->string");
lf[167]=C_h_intern(&lf[167],15,"define-location");
lf[168]=C_h_intern(&lf[168],15,"define-external");
lf[169]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[171]=C_h_intern(&lf[171],29,"\004coreforeign-callback-wrapper");
lf[172]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376"
"\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[173]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376"
"\001\000\000\001_\376\377\001\000\000\000\001");
lf[174]=C_h_intern(&lf[174],20,"foreign-safe-wrapper");
lf[175]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006lambda\376\003\000\000\002"
"\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001\376\377\016");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[177]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006lambda\376\003\000\000\002\376\001\000\000\013lambda-list"
"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001\376\377\016");
lf[178]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[179]=C_h_intern(&lf[179],22,"\004coreforeign-primitive");
lf[180]=C_h_intern(&lf[180],17,"foreign-primitive");
lf[181]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[182]=C_h_intern(&lf[182],29,"\004coreforeign-callback-lambda*");
lf[183]=C_h_intern(&lf[183],20,"foreign-safe-lambda*");
lf[184]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\001");
lf[185]=C_h_intern(&lf[185],28,"\004coreforeign-callback-lambda");
lf[186]=C_h_intern(&lf[186],19,"foreign-safe-lambda");
lf[187]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[188]=C_h_intern(&lf[188],20,"\004coreforeign-lambda*");
lf[189]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\001");
lf[190]=C_h_intern(&lf[190],19,"\004coreforeign-lambda");
lf[191]=C_h_intern(&lf[191],14,"foreign-lambda");
lf[192]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[193]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[194]=C_h_intern(&lf[194],24,"\004coredefine-foreign-type");
lf[195]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\001\376\377\001\000\000\000\003");
lf[196]=C_h_intern(&lf[196],17,"register-feature!");
lf[197]=C_h_intern(&lf[197],6,"srfi-8");
lf[198]=C_h_intern(&lf[198],7,"srfi-16");
lf[199]=C_h_intern(&lf[199],7,"srfi-26");
lf[200]=C_h_intern(&lf[200],7,"srfi-31");
lf[201]=C_h_intern(&lf[201],7,"srfi-15");
lf[202]=C_h_intern(&lf[202],7,"srfi-11");
lf[203]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004void\376\377\016\376\377\016");
lf[204]=C_h_intern(&lf[204],25,"\003sysenable-runtime-macros");
lf[205]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\377\016");
lf[206]=C_h_intern(&lf[206],17,"define-for-syntax");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\022invalid identifier");
lf[208]=C_h_intern(&lf[208],6,"letrec");
lf[209]=C_h_intern(&lf[209],3,"rec");
lf[210]=C_h_intern(&lf[210],22,"chicken-compile-shared");
lf[211]=C_h_intern(&lf[211],3,"not");
lf[212]=C_h_intern(&lf[212],4,"unit");
lf[213]=C_h_intern(&lf[213],7,"provide");
lf[214]=C_h_intern(&lf[214],11,"cond-expand");
lf[215]=C_h_intern(&lf[215],6,"export");
lf[216]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\377\016");
lf[217]=C_h_intern(&lf[217],6,"static");
lf[218]=C_h_intern(&lf[218],4,"cdar");
lf[219]=C_h_intern(&lf[219],7,"dynamic");
lf[220]=C_h_intern(&lf[220],16,"define-extension");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid clause specifier");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid clause syntax");
lf[223]=C_h_intern(&lf[223],22,"string-parse-start+end");
lf[224]=C_h_intern(&lf[224],7,"receive");
lf[225]=C_h_intern(&lf[225],28,"string-parse-final-start+end");
lf[226]=C_h_intern(&lf[226],20,"let-string-start+end");
lf[227]=C_h_intern(&lf[227],5,"apply");
lf[228]=C_h_intern(&lf[228],2,"<>");
lf[229]=C_h_intern(&lf[229],5,"<...>");
lf[230]=C_h_intern(&lf[230],4,"cute");
lf[231]=C_h_intern(&lf[231],3,"cut");
lf[232]=C_h_intern(&lf[232],22,"\004corerequire-extension");
lf[233]=C_h_intern(&lf[233],3,"use");
lf[234]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[235]=C_h_intern(&lf[235],17,"require-extension");
lf[236]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[237]=C_h_intern(&lf[237],23,"\004corerequire-for-syntax");
lf[238]=C_h_intern(&lf[238],18,"require-for-syntax");
lf[239]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[240]=C_h_intern(&lf[240],18,"\003sysmake-structure");
lf[241]=C_h_intern(&lf[241],1,"x");
lf[242]=C_h_intern(&lf[242],14,"\003sysstructure\077");
lf[243]=C_h_intern(&lf[243],15,"\000record-setters");
lf[244]=C_h_intern(&lf[244],19,"\003syscheck-structure");
lf[245]=C_h_intern(&lf[245],13,"\003sysblock-ref");
lf[246]=C_h_intern(&lf[246],18,"getter-with-setter");
lf[247]=C_h_intern(&lf[247],1,"y");
lf[248]=C_h_intern(&lf[248],14,"\003sysblock-set!");
lf[249]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[250]=C_h_intern(&lf[250],18,"define-record-type");
lf[251]=C_h_intern(&lf[251],4,"memv");
lf[252]=C_h_intern(&lf[252],9,"condition");
lf[253]=C_h_intern(&lf[253],8,"\003sysslot");
lf[254]=C_h_intern(&lf[254],17,"handle-exceptions");
lf[255]=C_h_intern(&lf[255],10,"\003syssignal");
lf[256]=C_h_intern(&lf[256],14,"condition-case");
lf[257]=C_h_intern(&lf[257],9,"\003sysapply");
lf[258]=C_h_intern(&lf[258],10,"\003sysvalues");
lf[259]=C_h_intern(&lf[259],22,"with-exception-handler");
lf[260]=C_h_intern(&lf[260],30,"call-with-current-continuation");
lf[261]=C_h_intern(&lf[261],27,"\003sysregister-record-printer");
lf[262]=C_h_intern(&lf[262],21,"define-record-printer");
lf[263]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[264]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[265]=C_h_intern(&lf[265],6,"length");
lf[266]=C_h_intern(&lf[266],9,"split-at!");
lf[267]=C_h_intern(&lf[267],4,"take");
lf[268]=C_h_intern(&lf[268],3,"fx=");
lf[269]=C_h_intern(&lf[269],11,"case-lambda");
lf[270]=C_h_intern(&lf[270],11,"lambda-list");
lf[271]=C_h_intern(&lf[271],25,"\003sysdecompose-lambda-list");
lf[272]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corecheck\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\003syserror\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreimmutable\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376B\000\0000no matching clause in call to \047case-lambda\047 form\376\377\016\376\377\016\376\377\016"
"\376\377\016");
lf[273]=C_h_intern(&lf[273],3,"min");
lf[274]=C_h_intern(&lf[274],7,"require");
lf[275]=C_h_intern(&lf[275],6,"srfi-1");
lf[276]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[278]=C_h_intern(&lf[278],14,"\004coreimmutable");
lf[279]=C_h_intern(&lf[279],9,"\003syserror");
lf[280]=C_h_intern(&lf[280],14,"let-optionals*");
lf[281]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[282]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[283]=C_h_intern(&lf[283],8,"optional");
lf[284]=C_h_intern(&lf[284],9,":optional");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[286]=C_h_intern(&lf[286],4,"let*");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\004def-");
lf[289]=C_h_intern(&lf[289],5,"%rest");
lf[290]=C_h_intern(&lf[290],4,"body");
lf[291]=C_h_intern(&lf[291],4,"cadr");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\001%");
lf[293]=C_h_intern(&lf[293],13,"let-optionals");
lf[294]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[295]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[296]=C_h_intern(&lf[296],4,"eqv\077");
lf[297]=C_h_intern(&lf[297],6,"switch");
lf[298]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[299]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[300]=C_h_intern(&lf[300],2,"or");
lf[301]=C_h_intern(&lf[301],6,"select");
lf[302]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[303]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[304]=C_h_intern(&lf[304],21,"\003syssyntax-error-hook");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\037syntax error in \047and-let*\047 form");
lf[306]=C_h_intern(&lf[306],8,"and-let*");
lf[307]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[308]=C_h_intern(&lf[308],20,"\004coredefine-constant");
lf[309]=C_h_intern(&lf[309],15,"define-constant");
lf[310]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[311]=C_h_intern(&lf[311],18,"\004coredefine-inline");
lf[312]=C_h_intern(&lf[312],13,"define-inline");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000*invalid substitution form - must be lambda");
lf[314]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[315]=C_h_intern(&lf[315],8,"list-ref");
lf[316]=C_h_intern(&lf[316],9,"nth-value");
lf[317]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[318]=C_h_intern(&lf[318],13,"letrec-values");
lf[319]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[320]=C_h_intern(&lf[320],10,"let-values");
lf[321]=C_h_intern(&lf[321],11,"let*-values");
lf[322]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[323]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[324]=C_h_intern(&lf[324],13,"define-values");
lf[325]=C_h_intern(&lf[325],11,"set!-values");
lf[326]=C_h_intern(&lf[326],6,"unless");
lf[327]=C_h_intern(&lf[327],4,"when");
lf[328]=C_h_intern(&lf[328],16,"\003sysdynamic-wind");
lf[329]=C_h_intern(&lf[329],1,"t");
lf[330]=C_h_intern(&lf[330],8,"\003syslist");
lf[331]=C_h_intern(&lf[331],12,"parameterize");
lf[332]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[333]=C_h_intern(&lf[333],10,"\000compiling");
lf[334]=C_h_intern(&lf[334],19,"\004corecompiletimetoo");
lf[335]=C_h_intern(&lf[335],20,"\004corecompiletimeonly");
lf[336]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[337]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[338]=C_h_intern(&lf[338],4,"load");
lf[339]=C_h_intern(&lf[339],8,"run-time");
lf[340]=C_h_intern(&lf[340],7,"compile");
lf[341]=C_h_intern(&lf[341],12,"compile-time");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid situation specifier");
lf[343]=C_h_intern(&lf[343],9,"eval-when");
lf[344]=C_h_intern(&lf[344],8,"\003sysvoid");
lf[345]=C_h_intern(&lf[345],9,"fluid-let");
lf[346]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[347]=C_h_intern(&lf[347],11,"\000type-error");
lf[348]=C_h_intern(&lf[348],15,"\003syssignal-hook");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\033argument has incorrect type");
lf[350]=C_h_intern(&lf[350],6,"ensure");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\020assertion failed");
lf[352]=C_h_intern(&lf[352],6,"assert");
lf[353]=C_h_intern(&lf[353],20,"with-input-from-file");
lf[354]=C_h_intern(&lf[354],4,"read");
lf[355]=C_h_intern(&lf[355],27,"\003syscurrent-source-filename");
lf[356]=C_h_intern(&lf[356],5,"print");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\014; including ");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[359]=C_h_intern(&lf[359],12,"load-verbose");
lf[360]=C_h_intern(&lf[360],28,"\003sysresolve-include-filename");
lf[361]=C_h_intern(&lf[361],7,"include");
lf[362]=C_h_intern(&lf[362],15,"\003sysstart-timer");
lf[363]=C_h_intern(&lf[363],14,"\003sysstop-timer");
lf[364]=C_h_intern(&lf[364],17,"\003sysdisplay-times");
lf[365]=C_h_intern(&lf[365],4,"time");
lf[366]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[367]=C_h_intern(&lf[367],28,"\003sysstring->qualified-symbol");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\005-set!");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\001\077");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\005make-");
lf[373]=C_h_intern(&lf[373],27,"\003sysqualified-symbol-prefix");
lf[374]=C_h_intern(&lf[374],13,"define-record");
lf[375]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[376]=C_h_intern(&lf[376],6,"symbol");
lf[377]=C_h_intern(&lf[377],11,"\003sysprovide");
lf[378]=C_h_intern(&lf[378],19,"chicken-more-macros");
C_register_lf2(lf,379,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_686,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k684 */
static void C_ccall f_686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_689,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k687 in k684 */
static void C_ccall f_689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_692,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k690 in k687 in k684 */
static void C_ccall f_692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_692,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_695,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k693 in k690 in k687 in k684 */
static void C_ccall f_695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_695,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_698,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_match_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_701,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_4_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_701,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_704,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_707,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_support_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_710,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_compiler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_710,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_713,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_716,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_driver_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_719,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_platform_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_719,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_722,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_backend_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_722,2,t0,t1);}
t2=C_retrieve(lf[0]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_728,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#provide */
t4=C_retrieve(lf[377]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[378]);}

/* k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_731,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[166]+1);
t4=*((C_word*)lf[13]+1);
t5=*((C_word*)lf[141]+1);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6906,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t7=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[374],t6);}

/* a6905 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6906(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_6906r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6906r(t0,t1,t2,t3);}}

static void C_ccall f_6906r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t5=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[374],t2,lf[376]);}

/* k6908 in a6905 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6913,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[374],((C_word*)t0)[5],lf[375]);}

/* k6911 in k6908 in a6905 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   symbol->string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k6914 in k6911 in k6908 in a6905 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6916,2,t0,t1);}
t2=(C_word)C_i_memq(lf[243],C_retrieve(lf[55]));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6922,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* chicken.scm: 71   ##sys#qualified-symbol-prefix */
t4=C_retrieve(lf[373]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}

/* k6920 in k6914 in k6911 in k6908 in a6905 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7108,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7128,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   string-append */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[372],((C_word*)t0)[3]);}

/* k7126 in k6920 in k6914 in k6911 in k6908 in a6905 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_7128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[367]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7106 in k6920 in k6914 in k6911 in k6908 in a6905 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_7108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7108,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
t4=(C_word)C_a_i_cons(&a,2,lf[240],t3);
t5=(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_list(&a,3,lf[82],t1,t5);
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7084,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t6,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7104,a[2]=((C_word*)t0)[5],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   string-append */
t9=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,((C_word*)t0)[3],lf[371]);}

/* k7102 in k7106 in k6920 in k6914 in k6911 in k6908 in a6905 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_7104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[367]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7082 in k7106 in k6920 in k6914 in k6911 in k6908 in a6905 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_7084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7084,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[241]);
t3=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[10]);
t4=(C_word)C_a_i_list(&a,3,lf[242],lf[241],t3);
t5=(C_word)C_a_i_list(&a,3,lf[2],t2,t4);
t6=(C_word)C_a_i_list(&a,3,lf[82],t1,t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6945,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6947,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t9,a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp));
t11=((C_word*)t9)[1];
f_6947(t11,t7,((C_word*)t0)[2],C_fix(1));}

/* mapslots in k7082 in k7106 in k6920 in k6914 in k6911 in k6908 in a6905 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_6947(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6947,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6957,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=t1,a[9]=t3,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* chicken.scm: 71   symbol->string */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}}

/* k6955 in mapslots in k7082 in k7106 in k6920 in k6914 in k6911 in k6908 in a6905 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6960,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7076,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   string-append */
t4=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[2],lf[369],t1,lf[370]);}

/* k7074 in k6955 in mapslots in k7082 in k7106 in k6920 in k6914 in k6911 in k6908 in a6905 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_7076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[367]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6958 in k6955 in mapslots in k7082 in k7106 in k6920 in k6914 in k6911 in k6908 in a6905 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6963,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t1,a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7072,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   string-append */
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[3],lf[368],((C_word*)t0)[2]);}

/* k7070 in k6958 in k6955 in mapslots in k7082 in k7106 in k6920 in k6914 in k6911 in k6908 in a6905 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_7072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[367]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6961 in k6958 in k6955 in mapslots in k7082 in k7106 in k6920 in k6914 in k6911 in k6908 in a6905 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[167],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6963,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[241],lf[77]);
t3=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[8]);
t4=(C_word)C_a_i_list(&a,3,lf[244],lf[241],t3);
t5=(C_word)C_a_i_list(&a,2,lf[111],t4);
t6=(C_word)C_a_i_list(&a,4,lf[248],lf[241],((C_word*)t0)[7],lf[77]);
t7=(C_word)C_a_i_list(&a,4,lf[2],t2,t5,t6);
t8=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[6],t7);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6994,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t8,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t10=(C_word)C_a_i_list(&a,1,lf[241]);
t11=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[8]);
t12=(C_word)C_a_i_list(&a,3,lf[244],lf[241],t11);
t13=(C_word)C_a_i_list(&a,2,lf[111],t12);
t14=(C_word)C_a_i_list(&a,3,lf[245],lf[241],((C_word*)t0)[7]);
t15=(C_word)C_a_i_list(&a,4,lf[2],t10,t13,t14);
t16=t9;
f_6994(t16,(C_word)C_a_i_list(&a,3,lf[246],t15,((C_word*)t0)[6]));}
else{
t10=(C_word)C_a_i_list(&a,1,lf[241]);
t11=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[8]);
t12=(C_word)C_a_i_list(&a,3,lf[244],lf[241],t11);
t13=(C_word)C_a_i_list(&a,2,lf[111],t12);
t14=(C_word)C_a_i_list(&a,3,lf[245],lf[241],((C_word*)t0)[7]);
t15=t9;
f_6994(t15,(C_word)C_a_i_list(&a,4,lf[2],t10,t13,t14));}}

/* k6992 in k6961 in k6958 in k6955 in mapslots in k7082 in k7106 in k6920 in k6914 in k6911 in k6908 in a6905 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_6994(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6994,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_list(&a,3,lf[68],((C_word*)t0)[6],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6974,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t6=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* chicken.scm: 71   mapslots */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6947(t7,t4,t5,t6);}

/* k6972 in k6992 in k6961 in k6958 in k6955 in mapslots in k7082 in k7106 in k6920 in k6914 in k6911 in k6908 in a6905 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6974,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6943 in k7082 in k7106 in k6920 in k6914 in k6911 in k6908 in a6905 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6945,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[68],t3));}

/* k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_734,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6818,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[224],t3);}

/* a6817 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6818(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+23)){
C_save_and_reclaim((void*)tr3r,(void*)f_6818r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6818r(t0,t1,t2,t3);}}

static void C_ccall f_6818r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(23);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[4],t4,lf[330]));}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6835,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t5=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[224],t2,lf[270]);}}

/* k6833 in a6817 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6835,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6838,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[224],((C_word*)t0)[3],lf[366]);}

/* k6836 in k6833 in a6817 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6838,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6844,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=t2;
f_6844(t4,(C_word)C_i_nullp(t3));}
else{
t3=t2;
f_6844(t3,C_SCHEME_FALSE);}}

/* k6842 in k6836 in k6833 in a6817 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_6844(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6844,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[79],t7));}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[2],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[4],t3,t6));}}

/* k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_737,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[6]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6777,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t5=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[365],t4);}

/* a6776 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6777(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_6777r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6777r(t0,t1,t2);}}

static void C_ccall f_6777r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6781,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   gensym */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[329]);}

/* k6779 in a6776 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6781,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[362]);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,lf[2],t3);
t5=(C_word)C_a_i_list(&a,1,lf[363]);
t6=(C_word)C_a_i_list(&a,2,lf[364],t5);
t7=(C_word)C_a_i_list(&a,3,lf[257],lf[258],t1);
t8=(C_word)C_a_i_list(&a,4,lf[2],t1,t6,t7);
t9=(C_word)C_a_i_list(&a,3,lf[4],t4,t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,3,lf[68],t2,t9));}

/* k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_737,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_740,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6761,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[133],t3);}

/* a6760 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6761(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_6761r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6761r(t0,t1,t2);}}

static void C_ccall f_6761r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6769,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6771,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a6770 in a6760 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6771(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6771,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k6767 in a6760 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6769,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[99],t1));}

/* k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_740,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_743,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[353]);
t4=*((C_word*)lf[354]+1);
t5=*((C_word*)lf[12]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6684,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t7=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[361],t6);}

/* a6683 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6684(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6684,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6688,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#resolve-include-filename */
t4=C_retrieve(lf[360]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,C_SCHEME_TRUE);}

/* k6686 in a6683 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6691,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6756,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   load-verbose */
t4=C_retrieve(lf[359]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k6754 in k6686 in a6683 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken.scm: 71   print */
t2=*((C_word*)lf[356]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[357],((C_word*)t0)[2],lf[358]);}
else{
t2=((C_word*)t0)[3];
f_6691(2,t2,C_SCHEME_UNDEFINED);}}

/* k6689 in k6686 in a6683 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6691,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6698,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6700,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   with-input-from-file */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[5],t3);}

/* a6699 in k6689 in k6686 in a6683 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6700,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6706,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6714,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6747,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[328]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t1,t6,t7,t8);}

/* a6746 in a6699 in k6689 in k6686 in a6683 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6747,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[355]));
t3=C_mutate((C_word*)lf[355]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[0]));}

/* a6713 in a6699 in k6689 in k6686 in a6683 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6722,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   read */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6720 in a6713 in a6699 in k6689 in k6686 in a6683 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6722,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6724,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6724(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* do44 in k6720 in a6713 in a6699 in k6689 in k6686 in a6683 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_6724(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6724,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eofp(t2))){
/* chicken.scm: 71   reverse */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6741,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   read */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k6739 in do44 in k6720 in a6713 in a6699 in k6689 in k6686 in a6683 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6741,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_6724(t3,((C_word*)t0)[2],t1,t2);}

/* a6705 in a6699 in k6689 in k6686 in a6683 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6706,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[355]));
t3=C_mutate((C_word*)lf[355]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[0]));}

/* k6696 in k6689 in k6686 in a6683 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6698,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[68],t1));}

/* k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_746,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6624,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[352],t3);}

/* a6623 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6624(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_6624r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6624r(t0,t1,t2,t3);}}

static void C_ccall f_6624r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6628,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t3);
if(C_truep(t5)){
t6=(C_word)C_a_i_list(&a,2,lf[61],lf[351]);
t7=t4;
f_6628(t7,(C_word)C_a_i_list(&a,2,lf[278],t6));}
else{
t6=t4;
f_6628(t6,(C_word)C_slot(t3,C_fix(0)));}}

/* k6626 in a6623 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_6628(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6628,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[111],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,lf[3]);
t4=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=(C_word)C_fixnum_greaterp(t5,C_fix(1));
t7=(C_truep(t6)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t4,t7);
t9=(C_word)C_a_i_cons(&a,2,t1,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[279],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[72],t2,t3,t10));}

/* k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_746,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_749,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6565,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[350],t3);}

/* a6564 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6565(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_6565r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6565r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6565r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6569,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   gensym */
t6=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k6567 in a6564 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[54],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6569,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t5=(C_word)C_a_i_list(&a,2,lf[111],t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6596,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t7=t6;
f_6596(t7,((C_word*)t0)[2]);}
else{
t7=(C_word)C_a_i_list(&a,2,lf[61],lf[349]);
t8=(C_word)C_a_i_list(&a,2,lf[278],t7);
t9=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t10=t6;
f_6596(t10,(C_word)C_a_i_list(&a,3,t8,t1,t9));}}

/* k6594 in k6567 in a6564 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_6596(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6596,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[347],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[348],t2);
t4=(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[5],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t4));}

/* k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_749,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_752,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[6]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6391,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t5=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[345],t4);}

/* a6390 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6391(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_6391r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6391r(t0,t1,t2,t3);}}

static void C_ccall f_6391r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6395,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t5=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[345],t2,lf[346]);}

/* k6393 in a6390 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6398,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[76]+1),((C_word*)t0)[3]);}

/* k6396 in k6393 in a6390 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6559,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a6558 in k6396 in k6393 in a6390 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6559(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6559,3,t0,t1,t2);}
/* chicken.scm: 71   gensym */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k6399 in k6396 in k6393 in a6390 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6404,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6553,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a6552 in k6399 in k6396 in k6393 in a6390 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6553(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6553,3,t0,t1,t2);}
/* chicken.scm: 71   gensym */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k6402 in k6399 in k6396 in k6393 in a6390 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6411,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6515,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6551,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[291]+1),((C_word*)t0)[2]);}

/* k6549 in k6402 in k6399 in k6396 in k6393 in a6390 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   map */
t2=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[330]+1),((C_word*)t0)[2],t1);}

/* k6513 in k6402 in k6399 in k6396 in k6393 in a6390 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6519,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6523,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(((C_word*)t0)[2]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6529,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_6529(t8,t3,t4);}

/* loop in k6513 in k6402 in k6399 in k6396 in k6393 in a6390 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_6529(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6529,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6543,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
/* chicken.scm: 71   loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k6541 in loop in k6513 in k6402 in k6399 in k6396 in k6393 in a6390 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6543,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1));}

/* k6521 in k6513 in k6402 in k6399 in k6396 in k6393 in a6390 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   map */
t2=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[330]+1),((C_word*)t0)[2],t1);}

/* k6517 in k6513 in k6402 in k6399 in k6396 in k6393 in a6390 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6409 in k6402 in k6399 in k6396 in k6393 in a6390 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6479,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6483,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6507,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   map */
t5=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* a6506 in k6409 in k6402 in k6399 in k6396 in k6393 in a6390 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6507(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6507,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t2,t3));}

/* k6481 in k6409 in k6402 in k6399 in k6396 in k6393 in a6390 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6487,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6491,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6501,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   map */
t5=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6500 in k6481 in k6409 in k6402 in k6399 in k6396 in k6393 in a6390 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6501(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6501,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t2,t3));}

/* k6489 in k6481 in k6409 in k6402 in k6399 in k6396 in k6393 in a6390 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6491,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[344]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k6485 in k6481 in k6409 in k6402 in k6399 in k6396 in k6393 in a6390 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6477 in k6409 in k6402 in k6399 in k6396 in k6393 in a6390 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6479,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[2],t2);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,lf[2],t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6435,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6439,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6463,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   map */
t9=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,t8,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a6462 in k6477 in k6409 in k6402 in k6399 in k6396 in k6393 in a6390 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6463(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6463,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t2,t3));}

/* k6437 in k6477 in k6409 in k6402 in k6399 in k6396 in k6393 in a6390 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6443,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6447,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6457,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   map */
t5=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6456 in k6437 in k6477 in k6409 in k6402 in k6399 in k6396 in k6393 in a6390 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6457(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6457,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t2,t3));}

/* k6445 in k6437 in k6477 in k6409 in k6402 in k6399 in k6396 in k6393 in a6390 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6447,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[344]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k6441 in k6437 in k6477 in k6409 in k6402 in k6399 in k6396 in k6393 in a6390 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6433 in k6477 in k6409 in k6402 in k6399 in k6396 in k6393 in a6390 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6435,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[2],t2);
t4=(C_word)C_a_i_list(&a,4,lf[328],((C_word*)t0)[5],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t4));}

/* k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_752,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_755,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6296,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[343],t3);}

/* a6295 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6296(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr3r,(void*)f_6296r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6296r(t0,t1,t2,t3);}}

static void C_ccall f_6296r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(24);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(C_word)C_a_i_cons(&a,2,lf[68],t3);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6303,a[2]=t5,a[3]=t10,a[4]=t1,a[5]=t9,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6332,a[2]=t7,a[3]=t9,a[4]=t5,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_6332(t15,t11,t2);}

/* loop in a6295 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_6332(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6332,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6345,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(t3,lf[147]);
if(C_truep(t5)){
t6=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t7=t4;
f_6345(2,t7,t6);}
else{
t6=(C_word)C_eqp(t3,lf[338]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t3,lf[339]));
if(C_truep(t7)){
t8=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t9=t4;
f_6345(2,t9,t8);}
else{
t8=(C_word)C_eqp(t3,lf[340]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[341]));
if(C_truep(t9)){
t10=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t11=t4;
f_6345(2,t11,t10);}
else{
t10=(C_word)C_slot(t2,C_fix(0));
/* chicken.scm: 71   ##sys#error */
t11=*((C_word*)lf[279]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t4,lf[342],t10);}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6343 in loop in a6295 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* chicken.scm: 71   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6332(t3,((C_word*)t0)[2],t2);}

/* k6301 in a6295 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6303,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[333],C_retrieve(lf[55])))){
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?((C_word*)((C_word*)t0)[5])[1]:C_SCHEME_FALSE);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_a_i_list(&a,2,lf[334],((C_word*)t0)[3]):(C_truep(((C_word*)((C_word*)t0)[6])[1])?(C_word)C_a_i_list(&a,2,lf[335],((C_word*)t0)[3]):(C_truep(((C_word*)((C_word*)t0)[5])[1])?((C_word*)t0)[3]:lf[336]))));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)((C_word*)t0)[2])[1])?((C_word*)t0)[3]:lf[337]));}}

/* k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_755,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_758,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[76]+1);
t4=*((C_word*)lf[291]+1);
t5=*((C_word*)lf[1]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6186,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t7=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[331],t6);}

/* a6185 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6186(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_6186r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6186r(t0,t1,t2,t3);}}

static void C_ccall f_6186r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6190,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t5=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[331],t2,lf[332]);}

/* k6188 in a6185 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6191 in k6188 in a6185 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6196,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   ##sys#map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k6194 in k6191 in k6188 in a6185 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6199,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   ##sys#map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6197 in k6194 in k6191 in k6188 in a6185 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6199,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6202,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6290,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a6289 in k6197 in k6194 in k6191 in k6188 in a6185 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6290(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6290,3,t0,t1,t2);}
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k6200 in k6197 in k6194 in k6191 in k6188 in a6185 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6284,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a6283 in k6200 in k6197 in k6194 in k6191 in k6188 in a6185 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6284(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6284,3,t0,t1,t2);}
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k6203 in k6200 in k6197 in k6194 in k6191 in k6188 in a6185 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6212,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6278,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   map */
t4=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[330]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k6276 in k6203 in k6200 in k6197 in k6194 in k6191 in k6188 in a6185 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6278,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6282,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   map */
t3=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[330]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6280 in k6276 in k6203 in k6200 in k6197 in k6194 in k6191 in k6188 in a6185 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6210 in k6203 in k6200 in k6197 in k6194 in k6191 in k6188 in a6185 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6248,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6250,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   map */
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6249 in k6210 in k6203 in k6200 in k6197 in k6194 in k6191 in k6188 in a6185 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6250(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[39],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6250,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t2);
t5=(C_word)C_a_i_list(&a,2,lf[329],t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_list(&a,2,t2,t3);
t8=(C_word)C_a_i_list(&a,3,lf[5],t3,lf[329]);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_list(&a,4,lf[79],t6,t7,t8));}

/* k6246 in k6210 in k6203 in k6200 in k6197 in k6194 in k6191 in k6188 in a6185 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6248,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[2],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t7=(C_word)C_a_i_cons(&a,2,lf[2],t6);
t8=(C_word)C_a_i_list(&a,4,lf[328],((C_word*)t0)[5],t7,((C_word*)t0)[5]);
t9=(C_word)C_a_i_list(&a,3,lf[79],t5,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t9));}

/* k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_758,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_761,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6176,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[327],t3);}

/* a6175 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6176(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_6176r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6176r(t0,t1,t2,t3);}}

static void C_ccall f_6176r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(12);
t4=(C_word)C_a_i_cons(&a,2,lf[68],t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[72],t2,t4));}

/* k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_764,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6162,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[326],t3);}

/* a6161 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6162(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr3r,(void*)f_6162r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6162r(t0,t1,t2,t3);}}

static void C_ccall f_6162r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(18);
t4=(C_word)C_a_i_list(&a,1,lf[3]);
t5=(C_word)C_a_i_cons(&a,2,lf[68],t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,4,lf[72],t2,t4,t5));}

/* k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_764,2,t0,t1);}
t2=*((C_word*)lf[1]+1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_765,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_838,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t5=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[325],t3);}

/* k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_838,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_841,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t3=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[324],((C_word*)t0)[2]);}

/* k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_844,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5829,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5860,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5900,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t10=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t2,lf[320],t9);}

/* a5827 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5900(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5900,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[320],t2,lf[323]);}

/* k5902 in a5827 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5904,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5913,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[76]+1),t2);}

/* k5911 in k5902 in a5827 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5916,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6122,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6122(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* loop in k5911 in k5902 in a5827 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_6122(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6122,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6135,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t4))){
/* chicken.scm: 71   append */
t6=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t4))){
/* chicken.scm: 71   append* */
t6=((C_word*)((C_word*)t0)[2])[1];
f_5829(t6,t5,t4,t3);}
else{
t6=t5;
f_6135(2,t6,(C_word)C_a_i_cons(&a,2,t4,t3));}}}}

/* k6133 in loop in k5911 in k5902 in a5827 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 71   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6122(t3,((C_word*)t0)[2],t2,t1);}

/* k5914 in k5911 in k5902 in a5827 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5919,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6112,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a6111 in k5914 in k5911 in k5902 in a5827 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6112(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6112,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6120,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   gensym */
t4=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6118 in a6111 in k5914 in k5911 in k5902 in a5827 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6120,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5917 in k5914 in k5911 in k5902 in a5827 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5920,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5931,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6066,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_6066(t7,t3,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}

/* loop in k5917 in k5914 in k5911 in k5902 in a5827 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_6066(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6066,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* chicken.scm: 71   reverse */
t4=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6082,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6106,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   map* */
t7=((C_word*)((C_word*)t0)[3])[1];
f_5860(t7,t6,((C_word*)t0)[2],t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6099,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   lookup */
t7=((C_word*)t0)[2];
f_5920(3,t7,t6,t4);}}}

/* k6097 in loop in k5917 in k5914 in k5911 in k5902 in a5827 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6099,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6082(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k6104 in loop in k5917 in k5914 in k5911 in k5902 in a5827 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6106,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6082(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k6080 in loop in k5917 in k5914 in k5911 in k5902 in a5827 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_6082(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 71   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6066(t3,((C_word*)t0)[2],t2,t1);}

/* k5929 in k5917 in k5914 in k5911 in k5902 in a5827 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5938,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6060,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a6059 in k5929 in k5917 in k5914 in k5911 in k5902 in a5827 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6060(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6060,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k5936 in k5929 in k5917 in k5914 in k5911 in k5902 in a5827 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5938,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5940,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_5940(t5,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* fold in k5936 in k5929 in k5917 in k5914 in k5911 in k5902 in a5827 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_5940(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5940,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5958,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5960,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* map */
t7=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5974,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(t4);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6054,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   cdar */
t8=*((C_word*)lf[218]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}
else{
t7=t5;
f_5974(t7,C_SCHEME_FALSE);}}}

/* k6052 in fold in k5936 in k5929 in k5917 in k5914 in k5911 in k5902 in a5827 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5974(t2,(C_word)C_i_nullp(t1));}

/* k5972 in fold in k5936 in k5929 in k5917 in k5914 in k5911 in k5902 in a5827 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_5974(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5974,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6005,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   caar */
t3=*((C_word*)lf[152]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6028,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[6]);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken.scm: 71   fold */
t9=((C_word*)((C_word*)t0)[2])[1];
f_5940(t9,t5,t6,t7,t8);}}

/* k6026 in k5972 in fold in k5936 in k5929 in k5917 in k5914 in k5911 in k5902 in a5827 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6028,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[4],((C_word*)t0)[2],t2));}

/* k6003 in k5972 in fold in k5936 in k5929 in k5917 in k5914 in k5911 in k5902 in a5827 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_6005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6005,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5985,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[6]);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken.scm: 71   fold */
t9=((C_word*)((C_word*)t0)[2])[1];
f_5940(t9,t5,t6,t7,t8);}

/* k5983 in k6003 in k5972 in fold in k5936 in k5929 in k5917 in k5914 in k5911 in k5902 in a5827 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5985,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* a5959 in fold in k5936 in k5929 in k5917 in k5914 in k5911 in k5902 in a5827 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5960(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5960,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5968,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   lookup */
t4=((C_word*)t0)[2];
f_5920(3,t4,t3,t2);}

/* k5966 in a5959 in fold in k5936 in k5929 in k5917 in k5914 in k5911 in k5902 in a5827 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5968,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k5956 in fold in k5936 in k5929 in k5917 in k5914 in k5911 in k5902 in a5827 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5958,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[79],t2));}

/* lookup in k5917 in k5914 in k5911 in k5902 in a5827 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5920(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5920,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* map* in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_5860(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5860,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5883,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* chicken.scm: 71   proc */
t6=t2;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
/* chicken.scm: 71   proc */
t4=t2;
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}}}

/* k5881 in map* in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5887,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 71   map* */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5860(t4,t2,((C_word*)t0)[2],t3);}

/* k5885 in k5881 in map* in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5887,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* append* in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_5829(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5829,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5850,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* chicken.scm: 71   append* */
t8=t5;
t9=t6;
t10=t3;
t1=t8;
t2=t9;
t3=t10;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}}

/* k5848 in append* in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5850,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_844,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_847,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5778,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[321],t3);}

/* a5777 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5778(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5778,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5782,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[321],t2,lf[322]);}

/* k5780 in a5777 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5782,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5793,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5793(t7,((C_word*)t0)[2],t2);}

/* fold in k5780 in a5777 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_5793(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5793,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[79],t3));}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5818,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* chicken.scm: 71   fold */
t9=t5;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}

/* k5816 in fold in k5780 in a5777 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5818,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[320],((C_word*)t0)[2],t1));}

/* k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_847,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_850,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5658,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[318],t3);}

/* a5657 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5658(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5658,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5662,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[318],t2,lf[319]);}

/* k5660 in a5657 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5662,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5671,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5770,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5772,tmp=(C_word)a,a+=2,tmp);
/* map */
t7=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a5771 in k5660 in a5657 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5772(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5772,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k5768 in k5660 in a5657 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[85]+1),t1);}

/* k5669 in k5660 in a5657 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5674,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5758,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a5757 in k5669 in k5660 in a5657 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5758(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5758,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5766,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   gensym */
t4=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5764 in a5757 in k5669 in k5660 in a5657 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5766,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5672 in k5669 in k5660 in a5657 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5674,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5675,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5694,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5752,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a5751 in k5672 in k5669 in k5660 in a5657 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5752(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5752,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,lf[317]));}

/* k5692 in k5672 in k5669 in k5660 in a5657 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5694,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5698,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5702,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5704,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a5703 in k5692 in k5672 in k5669 in k5660 in a5657 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5704(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5704,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5724,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t2);
/* map */
t7=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}

/* k5722 in a5703 in k5692 in k5672 in k5669 in k5660 in a5657 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5728,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5730,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[2]);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a5729 in k5722 in a5703 in k5692 in k5672 in k5669 in k5660 in a5657 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5730(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5730,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5738,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   lookup */
t4=((C_word*)t0)[2];
f_5675(3,t4,t3,t2);}

/* k5736 in a5729 in k5722 in a5703 in k5692 in k5672 in k5669 in k5660 in a5657 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5738,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[5],((C_word*)t0)[2],t1));}

/* k5726 in k5722 in a5703 in k5692 in k5672 in k5669 in k5660 in a5657 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5728,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[2],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[4],((C_word*)t0)[2],t3));}

/* k5700 in k5692 in k5672 in k5669 in k5660 in a5657 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5696 in k5692 in k5672 in k5669 in k5660 in a5657 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5698,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[79],t2));}

/* lookup in k5672 in k5669 in k5660 in a5657 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5675(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5675,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_853,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5637,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[316],t3);}

/* a5636 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5637,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5641,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   gensym */
t5=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k5639 in a5636 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5641,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,3,lf[315],t1,((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,3,lf[2],t1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[4],t2,t4));}

/* k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_932,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5627,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[312],t3);}

/* a5626 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5627(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5627,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_859,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[312],t2,lf[314]);}

/* k857 in a5626 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_859,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_868,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(((C_word*)t0)[3]);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=t5;
f_868(t9,(C_word)C_a_i_cons(&a,2,lf[2],t8));}
else{
t6=t5;
f_868(t6,(C_word)C_i_cadr(((C_word*)t0)[3]));}}

/* k866 in k857 in a5626 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_868(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_868,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_871,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_pairp(t1);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_884,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_884(t6,t4);}
else{
t6=(C_word)C_i_car(t1);
t7=(C_word)C_eqp(lf[2],t6);
t8=t5;
f_884(t8,(C_word)C_i_not(t7));}}

/* k882 in k866 in k857 in a5626 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_884(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken.scm: 71   syntax-error */
t2=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[312],lf[313],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_871(2,t2,C_SCHEME_UNDEFINED);}}

/* k869 in k866 in k857 in a5626 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_871,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[311],t3));}

/* k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_932,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_935,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5606,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[309],t3);}

/* a5605 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5606(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5606,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5610,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[309],t2,lf[310]);}

/* k5608 in a5605 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5610,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[308],t3,t4));}

/* k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_938,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5490,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[306],t3);}

/* a5489 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5490(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5490,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5494,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[306],t2,lf[307]);}

/* k5492 in a5489 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5494,2,t0,t1);}
t2=(C_word)C_i_listp(((C_word*)t0)[3]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5503,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_5503(t5,t3);}
else{
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=t4;
f_5503(t6,(C_word)C_fixnum_lessp(t5,C_fix(2)));}}

/* k5501 in k5492 in a5489 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_5503(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5503,NULL,2,t0,t1);}
if(C_truep(t1)){
/* chicken.scm: 71   ##sys#syntax-error-hook */
t2=C_retrieve(lf[304]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[305],((C_word*)t0)[2]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[2],C_fix(0));
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5517,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5517(t7,((C_word*)t0)[3],t2);}}

/* fold in k5501 in k5492 in a5489 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_5517(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(25);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5517,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[68],((C_word*)t0)[3]));}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_not_pair_p(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5546,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   fold */
t15=t5;
t16=t4;
t1=t15;
t2=t16;
goto loop;}
else{
t5=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t5))){
t6=(C_word)C_slot(t3,C_fix(0));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5563,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   fold */
t15=t7;
t16=t4;
t1=t15;
t2=t16;
goto loop;}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_i_cadr(t3);
t8=(C_word)C_a_i_list(&a,2,t6,t7);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5581,a[2]=t9,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   fold */
t15=t10;
t16=t4;
t1=t15;
t2=t16;
goto loop;}}}}

/* k5579 in fold in k5501 in k5492 in a5489 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5581,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[4],t1,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t2));}

/* k5561 in fold in k5501 in k5492 in a5489 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5563,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[2],t1,C_SCHEME_FALSE));}

/* k5544 in fold in k5501 in k5492 in a5489 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5546,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[2],t1,C_SCHEME_FALSE));}

/* k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_941,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[6]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5391,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t5=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[301],t4);}

/* a5390 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5391(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5391,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5401,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   gensym */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k5399 in a5390 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5401,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5412,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5414,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_5414(t8,t4,((C_word*)t0)[2]);}

/* expand in k5399 in a5390 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_5414(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5414,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5430,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[301],t3,lf[302]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[303]);}}

/* k5428 in expand in k5399 in a5390 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5430,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[86],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[68],t4));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5466,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5468,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[6]);
/* map */
t7=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}}

/* a5467 in k5428 in expand in k5399 in a5390 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5468(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5468,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[296],((C_word*)t0)[2],t2));}

/* k5464 in k5428 in expand in k5399 in a5390 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5466,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[300],t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,lf[68],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5458,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   expand */
t6=((C_word*)((C_word*)t0)[3])[1];
f_5414(t6,t5,((C_word*)t0)[2]);}

/* k5456 in k5464 in k5428 in expand in k5399 in a5390 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5458,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k5410 in k5399 in a5390 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5412,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_944,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[6]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5302,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t5=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[297],t4);}

/* a5301 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5302(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5302,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5312,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   gensym */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k5310 in a5301 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5312,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5323,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5325,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_5325(t8,t4,((C_word*)t0)[2]);}

/* expand in k5310 in a5301 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_5325(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5325,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5341,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[297],t3,lf[298]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[299]);}}

/* k5339 in expand in k5310 in a5301 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5341,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[86],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[68],t4));}
else{
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,3,lf[296],((C_word*)t0)[4],t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_cons(&a,2,lf[68],t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5369,a[2]=t7,a[3]=t5,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   expand */
t9=((C_word*)((C_word*)t0)[3])[1];
f_5325(t9,t8,((C_word*)t0)[2]);}}

/* k5367 in k5339 in expand in k5310 in a5301 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5369,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k5321 in k5310 in a5301 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5323,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_947,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5016,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[293],t3);}

/* a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5016(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_5016r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5016r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5016r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5213,a[2]=t3,a[3]=t1,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[293],t3,lf[295]);}

/* k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5216,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[293],((C_word*)t0)[4],lf[294]);}

/* k5214 in k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5216,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5219,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[76]+1),((C_word*)t0)[2]);}

/* k5217 in k5214 in k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5219,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5220,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5235,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5292,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a5291 in k5217 in k5214 in k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5292(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5292,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5300,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   prefix-sym */
f_5220(t3,lf[292],t2);}

/* k5298 in a5291 in k5217 in k5214 in k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   gensym */
t2=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5233 in k5217 in k5214 in k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5238,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[291]+1),((C_word*)t0)[2]);}

/* k5236 in k5233 in k5217 in k5214 in k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5241,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[290]);}

/* k5239 in k5236 in k5233 in k5217 in k5214 in k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5244,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[289]);}

/* k5242 in k5239 in k5236 in k5233 in k5217 in k5214 in k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5247,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5282,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[8]);}

/* a5281 in k5242 in k5239 in k5236 in k5233 in k5217 in k5214 in k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5282(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5282,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5290,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   prefix-sym */
f_5220(t3,lf[288],t2);}

/* k5288 in a5281 in k5242 in k5239 in k5236 in k5233 in k5217 in k5214 in k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   gensym */
t2=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5245 in k5242 in k5239 in k5236 in k5233 in k5217 in k5214 in k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5250,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[5];
t5=t1;
t6=((C_word*)t0)[2];
t7=C_retrieve(lf[6]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5027,a[2]=t5,a[3]=t6,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   reverse */
t9=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t3);}

/* k5025 in k5245 in k5242 in k5239 in k5236 in k5233 in k5217 in k5214 in k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5031,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   reverse */
t3=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5029 in k5025 in k5245 in k5242 in k5239 in k5236 in k5233 in k5217 in k5214 in k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5035,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   reverse */
t3=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5033 in k5029 in k5025 in k5245 in k5242 in k5239 in k5236 in k5233 in k5217 in k5214 in k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5035,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5037,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_5037(t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* recur in k5033 in k5029 in k5025 in k5245 in k5242 in k5239 in k5236 in k5233 in k5217 in k5214 in k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_5037(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5037,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5082,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=t7,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* chicken.scm: 71   reverse */
t9=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t6);}}

/* k5080 in recur in k5033 in k5029 in k5025 in k5245 in k5242 in k5239 in k5236 in k5233 in k5217 in k5214 in k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5090,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5094,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   reverse */
t4=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5092 in k5080 in recur in k5033 in k5029 in k5025 in k5245 in k5242 in k5239 in k5236 in k5233 in k5217 in k5214 in k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5094,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k5088 in k5080 in recur in k5033 in k5029 in k5025 in k5245 in k5242 in k5239 in k5236 in k5233 in k5217 in k5214 in k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5090,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5058,a[2]=t4,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
t8=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 71   recur */
t9=((C_word*)((C_word*)t0)[3])[1];
f_5037(t9,t5,((C_word*)t0)[2],t6,t7,t8);}

/* k5056 in k5088 in k5080 in recur in k5033 in k5029 in k5025 in k5245 in k5242 in k5239 in k5236 in k5233 in k5217 in k5214 in k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5058,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5248 in k5245 in k5242 in k5239 in k5236 in k5233 in k5217 in k5214 in k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5253,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[9];
t7=C_retrieve(lf[6]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5110,a[2]=t9,a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_5110(t11,t2,t3,t4,C_SCHEME_END_OF_LIST);}

/* recur in k5248 in k5245 in k5242 in k5239 in k5236 in k5233 in k5217 in k5214 in k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_5110(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5110,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(C_word)C_a_i_list(&a,2,lf[74],((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,lf[111],t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5144,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   reverse */
t8=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_list(&a,2,lf[74],((C_word*)t0)[4]);
t7=(C_word)C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5210,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t6,a[7]=t1,a[8]=t5,a[9]=((C_word*)t0)[4],a[10]=t7,tmp=(C_word)a,a+=11,tmp);
/* chicken.scm: 71   reverse */
t9=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t4);}}

/* k5208 in recur in k5248 in k5245 in k5242 in k5239 in k5236 in k5233 in k5217 in k5214 in k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5210,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_list(&a,2,lf[76],((C_word*)t0)[9]);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_list(&a,2,lf[75],((C_word*)t0)[9]);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],t5);
t7=(C_word)C_a_i_list(&a,2,t4,t6);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5174,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[3]);
/* chicken.scm: 71   recur */
t12=((C_word*)((C_word*)t0)[2])[1];
f_5110(t12,t8,t9,t10,t11);}

/* k5172 in k5208 in recur in k5248 in k5245 in k5242 in k5239 in k5236 in k5233 in k5217 in k5214 in k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5174,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k5142 in recur in k5248 in k5245 in k5242 in k5239 in k5236 in k5233 in k5217 in k5214 in k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5144,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,2,lf[61],lf[287]);
t4=(C_word)C_a_i_list(&a,2,lf[278],t3);
t5=(C_word)C_a_i_list(&a,3,lf[279],t4,((C_word*)t0)[4]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[2],t2,t5));}

/* k5251 in k5248 in k5245 in k5242 in k5239 in k5236 in k5233 in k5217 in k5214 in k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5253,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,lf[2],t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,3,lf[286],t7,t1));}

/* prefix-sym in k5217 in k5214 in k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_5220(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5220,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5228,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5232,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   symbol->string */
t6=*((C_word*)lf[166]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}

/* k5230 in prefix-sym in k5217 in k5214 in k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   string-append */
t2=*((C_word*)lf[141]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5226 in prefix-sym in k5217 in k5214 in k5211 in a5015 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_5228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_950,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4959,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[283],t3);}

/* a4958 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4959,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4963,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   gensym */
t5=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k4961 in a4958 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[93],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4963,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,lf[74],t1);
t5=(C_word)C_a_i_list(&a,2,lf[75],t1);
t6=(C_word)C_a_i_list(&a,2,lf[74],t5);
t7=(C_word)C_a_i_list(&a,2,lf[111],t6);
t8=(C_word)C_a_i_list(&a,2,lf[76],t1);
t9=(C_word)C_a_i_list(&a,2,lf[61],lf[285]);
t10=(C_word)C_a_i_list(&a,2,lf[278],t9);
t11=(C_word)C_a_i_list(&a,3,lf[279],t10,t1);
t12=(C_word)C_a_i_list(&a,4,lf[72],t7,t8,t11);
t13=(C_word)C_a_i_list(&a,4,lf[72],t4,((C_word*)t0)[3],t12);
t14=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,3,lf[79],t3,t13));}

/* k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_953,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4953,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[284],t3);}

/* a4952 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4953(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4953,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[283],t2));}

/* k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_953,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_956,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4800,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[280],t3);}

/* a4799 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4800(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4800r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4800r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4800r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4804,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[280],t3,lf[282]);}

/* k4802 in a4799 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4807,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[280],((C_word*)t0)[3],lf[281]);}

/* k4805 in k4802 in a4799 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4810,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4808 in k4805 in k4802 in a4799 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4810,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4821,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4823,a[2]=t6,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4823(t8,t4,t1,((C_word*)t0)[2]);}

/* loop in k4808 in k4805 in k4802 in a4799 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_4823(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4823,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_a_i_list(&a,2,lf[74],t2);
t5=(C_word)C_a_i_list(&a,2,lf[111],t4);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,lf[79],t6);
t8=(C_word)C_a_i_list(&a,2,lf[61],lf[277]);
t9=(C_word)C_a_i_list(&a,2,lf[278],t8);
t10=(C_word)C_a_i_list(&a,3,lf[279],t9,t2);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[72],t5,t7,t10));}
else{
t4=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4873,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   gensym */
t6=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=(C_word)C_a_i_list(&a,2,t4,t2);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[3]);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[79],t7));}}}

/* k4871 in loop in k4808 in k4805 in k4802 in a4799 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[76],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4873,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,lf[74],((C_word*)t0)[5]);
t4=(C_word)C_i_cadr(((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,2,lf[76],((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,4,lf[72],t3,t4,t5);
t7=(C_word)C_a_i_list(&a,2,t2,t6);
t8=(C_word)C_a_i_list(&a,2,lf[74],((C_word*)t0)[5]);
t9=(C_word)C_a_i_list(&a,2,lf[61],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_list(&a,2,lf[75],((C_word*)t0)[5]);
t11=(C_word)C_a_i_list(&a,4,lf[72],t8,t9,t10);
t12=(C_word)C_a_i_list(&a,2,t1,t11);
t13=(C_word)C_a_i_list(&a,2,t7,t12);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4884,a[2]=t13,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken.scm: 71   loop */
t16=((C_word*)((C_word*)t0)[2])[1];
f_4823(t16,t14,t1,t15);}

/* k4882 in k4871 in loop in k4808 in k4805 in k4802 in a4799 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4884,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k4819 in k4808 in k4805 in k4802 in a4799 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4821,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_959,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4524,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[269],t3);}

/* a4523 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4524(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4524,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4558,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[269],t2,lf[276]);}

/* k4556 in a4523 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4561,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   require */
t3=C_retrieve(lf[274]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[275]);}

/* k4559 in k4556 in a4523 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4564,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4785,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4787,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a4786 in k4559 in k4556 in a4523 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4787(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4787,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4797,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#decompose-lambda-list */
t5=C_retrieve(lf[271]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a4796 in a4786 in k4559 in k4556 in a4523 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4797(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4797,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k4783 in k4559 in k4556 in a4523 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[273]+1),t1);}

/* k4562 in k4559 in k4556 in a4523 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4567,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=t1;
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4533,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4533(t7,t2,C_fix(0));}

/* loop in k4562 in k4559 in k4556 in a4523 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_4533(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4533,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4547,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   gensym */
t4=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k4545 in loop in k4562 in k4559 in k4556 in a4523 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4551,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* chicken.scm: 71   loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4533(t4,t2,t3);}

/* k4549 in k4545 in loop in k4562 in k4559 in k4556 in a4523 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4551,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4565 in k4562 in k4559 in k4556 in a4523 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4567,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4570,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4568 in k4565 in k4562 in k4559 in k4556 in a4523 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4570,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4573,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4571 in k4568 in k4565 in k4562 in k4559 in k4556 in a4523 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4573,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4580,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   append */
t3=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[6]);}

/* k4578 in k4571 in k4568 in k4565 in k4562 in k4559 in k4556 in a4523 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4580,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[265],((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4592,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4594,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   fold-right */
t7=C_retrieve(lf[161]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,t6,lf[272],((C_word*)t0)[2]);}

/* a4593 in k4578 in k4571 in k4568 in k4565 in k4562 in k4559 in k4556 in a4523 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4594(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4594,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   ##sys#decompose-lambda-list */
t6=C_retrieve(lf[271]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t4,t5);}

/* a4603 in a4593 in k4578 in k4571 in k4568 in k4565 in k4562 in k4559 in k4556 in a4523 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4604,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4608,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=((C_word*)t0)[7],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* chicken.scm: 71   ##sys#check-syntax */
t7=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,lf[269],t6,lf[270]);}

/* k4606 in a4603 in a4593 in k4578 in k4571 in k4568 in k4565 in k4562 in k4559 in k4556 in a4523 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4608,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[11],((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4618,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=(C_word)C_eqp(t2,C_fix(0));
t5=t3;
f_4618(t5,(C_truep(t4)?C_SCHEME_TRUE:(C_word)C_a_i_list(&a,3,lf[108],((C_word*)t0)[2],t2)));}
else{
t4=t3;
f_4618(t4,(C_word)C_a_i_list(&a,3,lf[268],((C_word*)t0)[2],t2));}}

/* k4616 in k4606 in a4603 in a4593 in k4578 in k4571 in k4568 in k4565 in k4562 in k4559 in k4556 in a4523 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_4618(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4618,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4622,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4624,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4634,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a4633 in k4616 in k4606 in a4603 in a4593 in k4578 in k4571 in k4568 in k4565 in k4562 in k4559 in k4556 in a4523 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4634(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4634,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4638,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4653,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4653(t8,t4,t3,((C_word*)t0)[2]);}

/* build in a4633 in k4616 in k4606 in a4603 in a4593 in k4578 in k4571 in k4568 in k4565 in k4562 in k4559 in k4556 in a4523 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_4653(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4653,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[4])){
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[79],t7));}
else{
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cadr(((C_word*)t0)[3]));}
else{
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[79],t6));}}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4709,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   gensym */
t5=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k4707 in build in a4633 in k4616 in k4606 in a4603 in a4593 in k4578 in k4571 in k4568 in k4565 in k4562 in k4559 in k4556 in a4523 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4709,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,lf[76],((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,2,lf[75],((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,t1,t5);
t7=(C_word)C_a_i_list(&a,2,t4,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4720,a[2]=t7,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken.scm: 71   build */
t11=((C_word*)((C_word*)t0)[2])[1];
f_4653(t11,t8,t10,t1);}
else{
/* chicken.scm: 71   build */
t10=((C_word*)((C_word*)t0)[2])[1];
f_4653(t10,t8,C_SCHEME_END_OF_LIST,t1);}}

/* k4718 in k4707 in build in a4633 in k4616 in k4606 in a4603 in a4593 in k4578 in k4571 in k4568 in k4565 in k4562 in k4559 in k4556 in a4523 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4720,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k4636 in a4633 in k4616 in k4606 in a4603 in a4593 in k4578 in k4571 in k4568 in k4565 in k4562 in k4559 in k4556 in a4523 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4638,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4651,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   map */
t3=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[71]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k4649 in k4636 in a4633 in k4616 in k4606 in a4603 in a4593 in k4578 in k4571 in k4568 in k4565 in k4562 in k4559 in k4556 in a4523 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4651,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],t1,((C_word*)t0)[2]));}

/* a4623 in k4616 in k4606 in a4603 in a4593 in k4578 in k4571 in k4568 in k4565 in k4562 in k4559 in k4556 in a4523 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4632,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   take */
t3=C_retrieve(lf[267]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4630 in a4623 in k4616 in k4606 in a4603 in a4593 in k4578 in k4571 in k4568 in k4565 in k4562 in k4559 in k4556 in a4523 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   split-at! */
t2=C_retrieve(lf[266]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4620 in k4616 in k4606 in a4603 in a4593 in k4578 in k4571 in k4568 in k4565 in k4562 in k4559 in k4556 in a4523 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4622,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[3],t1,((C_word*)t0)[2]));}

/* k4590 in k4578 in k4571 in k4568 in k4565 in k4562 in k4559 in k4556 in a4523 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4592,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[2],t2));}

/* k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_962,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4467,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[262],t3);}

/* a4466 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4467(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr3r,(void*)f_4467r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4467r(t0,t1,t2,t3);}}

static void C_ccall f_4467r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(16);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4477,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* chicken.scm: 71   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,lf[262],t5,lf[263]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4507,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* chicken.scm: 71   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,lf[262],t5,lf[264]);}}

/* k4505 in a4466 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4507,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[261],t3));}

/* k4475 in a4466 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4477,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(0));
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=(C_word)C_a_i_cons(&a,2,lf[2],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[261],t3,t6));}

/* k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_965,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4391,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[254],t3);}

/* a4390 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4391r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4391r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4391r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4395,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   gensym */
t6=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k4393 in a4390 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4398,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4396 in k4393 in a4390 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[114],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4398,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_list(&a,3,lf[2],t3,t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t8=(C_word)C_a_i_cons(&a,2,lf[2],t7);
t9=(C_word)C_a_i_list(&a,3,lf[257],lf[258],t1);
t10=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t9);
t11=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t10);
t12=(C_word)C_a_i_list(&a,3,lf[2],t1,t11);
t13=(C_word)C_a_i_list(&a,3,lf[4],t8,t12);
t14=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t13);
t15=(C_word)C_a_i_list(&a,3,lf[259],t6,t14);
t16=(C_word)C_a_i_list(&a,3,lf[2],t2,t15);
t17=(C_word)C_a_i_list(&a,2,lf[260],t16);
t18=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_list(&a,1,t17));}

/* k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_968,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4207,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[256],t3);}

/* a4206 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4207(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4207r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4207r(t0,t1,t2,t3);}}

static void C_ccall f_4207r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4211,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   gensym */
t5=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k4209 in a4206 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4211,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4214,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4212 in k4209 in a4206 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4216,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,2,lf[61],lf[252]);
t4=(C_word)C_a_i_list(&a,3,lf[242],((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_list(&a,3,lf[253],((C_word*)t0)[5],C_fix(1));
t6=(C_word)C_a_i_list(&a,3,lf[110],t4,t5);
t7=(C_word)C_a_i_list(&a,2,t1,t6);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4353,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4357,a[2]=t9,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t11=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,t2,((C_word*)t0)[2]);}

/* k4355 in k4212 in k4209 in a4206 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4357,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[255],((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[86],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* ##sys#append */
t5=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k4351 in k4212 in k4209 in a4206 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4353,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[83],t1);
t3=(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[5],t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,4,lf[254],((C_word*)t0)[3],t3,((C_word*)t0)[2]));}

/* parse-clause in k4212 in k4209 in a4206 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4216(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[34],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4216,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_symbolp(t3);
t5=(C_truep(t4)?(C_word)C_i_car(t2):C_SCHEME_FALSE);
t6=(C_truep(t5)?(C_word)C_i_cadr(t2):(C_word)C_i_car(t2));
t7=(C_truep(t5)?(C_word)C_i_cddr(t2):(C_word)C_i_cdr(t2));
if(C_truep((C_word)C_i_nullp(t6))){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4239,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t5)){
t9=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[3]);
t10=(C_word)C_a_i_list(&a,1,t9);
t11=(C_word)C_a_i_cons(&a,2,t10,t7);
t12=t8;
f_4239(t12,(C_word)C_a_i_cons(&a,2,lf[79],t11));}
else{
t9=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t7);
t10=t8;
f_4239(t10,(C_word)C_a_i_cons(&a,2,lf[79],t9));}}
else{
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4302,a[2]=t7,a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4304,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t10=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t9,t6);}}

/* a4303 in parse-clause in k4212 in k4209 in a4206 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4304(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4304,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[251],t3,((C_word*)t0)[2]));}

/* k4300 in parse-clause in k4212 in k4209 in a4206 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4302,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[110],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4272,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[2]);
t8=t4;
f_4272(t8,(C_word)C_a_i_cons(&a,2,lf[79],t7));}
else{
t5=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t6=t4;
f_4272(t6,(C_word)C_a_i_cons(&a,2,lf[79],t5));}}

/* k4270 in k4300 in parse-clause in k4212 in k4209 in a4206 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_4272(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4272,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k4237 in parse-clause in k4212 in k4209 in a4206 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_4239(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4239,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[86],t1));}

/* k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_971,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4017,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[250],t3);}

/* a4016 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4017(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_4017r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_4017r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_4017r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t6=(C_word)C_i_cdr(t3);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4024,a[2]=t6,a[3]=t5,a[4]=t1,a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* map */
t8=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,*((C_word*)lf[76]+1),t5);}

/* k4022 in a4016 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4024,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4196,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4198,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a4197 in k4022 in a4016 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4198(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4198,3,t0,t1,t2);}
t3=(C_word)C_i_memq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:lf[249]));}

/* k4194 in k4022 in a4016 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4196,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[240],t2);
t4=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],lf[241]);
t6=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t7=(C_word)C_a_i_list(&a,3,lf[242],lf[241],t6);
t8=(C_word)C_a_i_list(&a,3,lf[82],t5,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4047,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4049,a[2]=t11,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t13=((C_word*)t11)[1];
f_4049(t13,t9,((C_word*)t0)[2],C_fix(1));}

/* loop in k4194 in k4022 in a4016 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_4049(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[112],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4049,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_memq(lf[243],C_retrieve(lf[55]));
t6=(C_word)C_i_cddr(t4);
t7=(C_word)C_i_pairp(t6);
t8=(C_word)C_a_i_list(&a,1,lf[241]);
t9=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[3]);
t10=(C_word)C_a_i_list(&a,3,lf[244],lf[241],t9);
t11=(C_word)C_a_i_list(&a,2,lf[111],t10);
t12=(C_word)C_a_i_list(&a,3,lf[245],lf[241],t3);
t13=(C_word)C_a_i_list(&a,4,lf[2],t8,t11,t12);
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4075,a[2]=t13,a[3]=t5,a[4]=t7,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,a[8]=t1,a[9]=t4,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t7)){
t15=(C_word)C_i_caddr(t4);
t16=(C_word)C_a_i_list(&a,3,t15,lf[241],lf[247]);
t17=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[3]);
t18=(C_word)C_a_i_list(&a,3,lf[244],lf[241],t17);
t19=(C_word)C_a_i_list(&a,2,lf[111],t18);
t20=(C_word)C_a_i_list(&a,4,lf[248],lf[241],t3,lf[247]);
t21=(C_word)C_a_i_list(&a,4,lf[82],t16,t19,t20);
t22=t14;
f_4075(t22,(C_word)C_a_i_list(&a,1,t21));}
else{
t15=t14;
f_4075(t15,C_SCHEME_END_OF_LIST);}}}

/* k4073 in loop in k4194 in k4022 in a4016 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_4075(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4075,NULL,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4103,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[3]:C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[9]);
t6=t3;
f_4103(t6,(C_word)C_a_i_list(&a,3,lf[246],((C_word*)t0)[2],t5));}
else{
t5=t3;
f_4103(t5,((C_word*)t0)[2]);}}

/* k4101 in k4073 in loop in k4194 in k4022 in a4016 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_4103(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4103,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4087,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* chicken.scm: 71   loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_4049(t6,t3,t4,t5);}

/* k4085 in k4101 in k4073 in loop in k4194 in k4022 in a4016 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4087,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* ##sys#append */
t3=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4045 in k4194 in k4022 in a4016 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4047,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[68],t3));}

/* k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_974,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4008,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[238],t3);}

/* a4007 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4008(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4008,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4012,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[238],t2,lf[239]);}

/* k4010 in a4007 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4012,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[237],((C_word*)t0)[2]));}

/* k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_977,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3989,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[235],t3);}

/* a3988 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3989(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3989,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3993,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[235],t2,lf[236]);}

/* k3991 in a3988 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4000,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4002,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4001 in k3991 in a3988 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4002(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4002,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3998 in k3991 in a3988 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_4000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4000,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[232],t1));}

/* k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_980,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3970,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[233],t3);}

/* a3969 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3970(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3970,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3974,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[233],t2,lf[234]);}

/* k3972 in a3969 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3981,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3983,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3982 in k3972 in a3969 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3983(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3983,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3979 in k3972 in a3969 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3981,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[232],t1));}

/* k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_983,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3842,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[231],t3);}

/* a3841 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3842(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3842,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3848,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3848(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in a3841 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_3848(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(15);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3848,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3858,a[2]=t4,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   reverse */
t7=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t3);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[228]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3929,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   gensym */
t9=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t9))(2,t9,t8);}
else{
t8=(C_word)C_eqp(t6,lf[229]);
if(C_truep(t8)){
/* chicken.scm: 71   loop */
t15=t1;
t16=C_SCHEME_END_OF_LIST;
t17=t3;
t18=t4;
t19=C_SCHEME_TRUE;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
t5=t19;
goto loop;}
else{
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_car(t2);
t11=(C_word)C_a_i_cons(&a,2,t10,t4);
/* chicken.scm: 71   loop */
t15=t1;
t16=t9;
t17=t3;
t18=t11;
t19=C_SCHEME_FALSE;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
t5=t19;
goto loop;}}}}

/* k3927 in loop in a3841 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3929,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* chicken.scm: 71   loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3848(t5,((C_word*)t0)[2],t2,t3,t4,C_SCHEME_FALSE);}

/* k3856 in loop in a3841 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3861,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   reverse */
t3=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3859 in k3856 in loop in a3841 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3861,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3867,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_a_i_list(&a,2,lf[68],t2);
t4=(C_word)C_i_cdr(t1);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[2],t5));}}

/* k3865 in k3859 in k3856 in loop in a3841 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3874,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k3872 in k3865 in k3859 in k3856 in loop in a3841 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3874,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3890,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* ##sys#append */
t6=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k3888 in k3872 in k3865 in k3859 in k3856 in loop in a3841 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3890,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[227],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[2],t3));}

/* k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_986,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3699,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[230],t3);}

/* a3698 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3699(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3699,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3705,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3705(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in a3698 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_3705(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(22);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3705,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t2))){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3715,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   reverse */
t8=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_eqp(t7,lf[228]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3790,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   gensym */
t10=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t10))(2,t10,t9);}
else{
t9=(C_word)C_eqp(t7,lf[229]);
if(C_truep(t9)){
/* chicken.scm: 71   loop */
t14=t1;
t15=C_SCHEME_END_OF_LIST;
t16=t3;
t17=t4;
t18=t5;
t19=C_SCHEME_TRUE;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
t5=t18;
t6=t19;
goto loop;}
else{
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3817,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t4,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   gensym */
t11=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t11))(2,t11,t10);}}}}

/* k3815 in loop in a3698 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3817,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
t6=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* chicken.scm: 71   loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_3705(t7,((C_word*)t0)[3],t2,((C_word*)t0)[2],t5,t6,C_SCHEME_FALSE);}

/* k3788 in loop in a3698 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3790,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* chicken.scm: 71   loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3705(t5,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2],t4,C_SCHEME_FALSE);}

/* k3713 in loop in a3698 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3718,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   reverse */
t3=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3716 in k3713 in loop in a3698 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3718,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3724,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[2],t4);
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[3],t5));}}

/* k3722 in k3716 in k3713 in loop in a3698 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3735,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k3733 in k3722 in k3716 in k3713 in loop in a3698 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3735,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3751,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* ##sys#append */
t6=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k3749 in k3733 in k3722 in k3716 in k3713 in loop in a3698 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3751,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[227],t2);
t4=(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t4));}

/* k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_989,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3640,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[226],t3);}

/* a3639 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3640(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc_2(c,6,t0);
if(!C_demand(c*C_SIZEOF_PAIR+51)){
C_save_and_reclaim((void*)tr6r,(void*)f_3640r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_3640r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_3640r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(51);
t7=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_i_caddr(t2);
t9=(C_word)C_i_car(t2);
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_a_i_list(&a,3,t8,t9,t10);
t12=(C_word)C_a_i_list(&a,4,lf[223],t3,t4,t5);
t13=(C_word)C_a_i_cons(&a,2,t12,t6);
t14=(C_word)C_a_i_cons(&a,2,t11,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[224],t14));}
else{
t8=(C_word)C_a_i_list(&a,4,lf[225],t3,t4,t5);
t9=(C_word)C_a_i_cons(&a,2,t8,t6);
t10=(C_word)C_a_i_cons(&a,2,t2,t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[224],t10));}}

/* k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_992,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3469,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[220],t3);}

/* a3468 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_3469r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3469r(t0,t1,t2,t3);}}

static void C_ccall f_3469r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3475,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3475(t7,t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t3,C_SCHEME_FALSE);}

/* loop in a3468 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_3475(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3475,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t4))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3485,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=(C_word)C_a_i_cons(&a,2,lf[215],t5);
t8=t6;
f_3485(t8,(C_word)C_a_i_list(&a,2,lf[133],t7));}
else{
t7=t6;
f_3485(t7,lf[216]);}}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3549,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_i_car(t4);
t8=t6;
f_3549(t8,(C_word)C_i_pairp(t7));}
else{
t7=t6;
f_3549(t7,C_SCHEME_FALSE);}}}

/* k3547 in loop in a3468 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_3549(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3549,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   caar */
t3=*((C_word*)lf[152]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
/* chicken.scm: 71   syntax-error */
t2=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[220],lf[222],((C_word*)t0)[7]);}}

/* k3550 in k3547 in loop in a3468 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3552,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_eqp(lf[217],t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3576,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   cdar */
t5=*((C_word*)lf[218]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(lf[219],t1);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3597,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   cdar */
t6=*((C_word*)lf[218]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(lf[215],t1);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3610,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=((C_word*)t0)[2];
t8=(C_truep(t7)?t7:C_SCHEME_END_OF_LIST);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3618,a[2]=t8,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   cdar */
t10=*((C_word*)lf[218]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[7]);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3625,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   caar */
t7=*((C_word*)lf[152]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[7]);}}}}

/* k3623 in k3550 in k3547 in loop in a3468 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   syntax-error */
t2=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[220],lf[221],t1);}

/* k3616 in k3550 in k3547 in loop in a3468 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   append */
t2=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3608 in k3550 in k3547 in loop in a3468 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   loop */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3475(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3595 in k3550 in k3547 in loop in a3468 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3597,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[68],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* chicken.scm: 71   loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3475(t4,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3574 in k3550 in k3547 in loop in a3468 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3576,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[68],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* chicken.scm: 71   loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3475(t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3483 in loop in a3468 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_3485(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[63],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3485,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,lf[210],t2);
t4=(C_word)C_a_i_list(&a,2,lf[211],lf[54]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,lf[212],((C_word*)t0)[4]);
t7=(C_word)C_a_i_list(&a,2,lf[133],t6);
t8=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t9=(C_word)C_a_i_list(&a,2,lf[213],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)t0)[3]);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,t7,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[86],t12);
t14=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,4,lf[214],t3,t5,t13));}

/* k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_995,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3418,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[209],t3);}

/* a3417 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3418(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+39)){
C_save_and_reclaim((void*)tr3r,(void*)f_3418r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3418r(t0,t1,t2,t3);}}

static void C_ccall f_3418r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(39);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,t5,t3);
t7=(C_word)C_a_i_cons(&a,2,lf[2],t6);
t8=(C_word)C_a_i_list(&a,2,t4,t7);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(C_word)C_i_car(t2);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,3,lf[208],t9,t10));}
else{
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[208],t5,t2));}}

/* k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_998,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3358,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[206],t3);}

/* a3357 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3358(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_3358r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3358r(t0,t1,t2,t3);}}

static void C_ccall f_3358r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[203]:t3);
t6=(C_word)C_i_pairp(t2);
t7=(C_truep(t6)?(C_word)C_i_car(t2):t2);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3368,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,t5);
t11=t8;
f_3368(t11,(C_word)C_a_i_cons(&a,2,lf[2],t10));}
else{
t9=t8;
f_3368(t9,(C_word)C_i_car(t5));}}

/* k3366 in a3357 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_3368(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3368,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3371,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3387,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   eval */
t4=C_retrieve(lf[147]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}
else{
/* chicken.scm: 71   syntax-error */
t3=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[206],lf[207],((C_word*)t0)[2]);}}

/* k3385 in k3366 in a3357 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3371(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* k3369 in k3366 in a3357 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3371,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[204]))?(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[3],((C_word*)t0)[2]):lf[205]));}

/* k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_998,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1001,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   register-feature! */
t3=C_retrieve(lf[196]);
((C_proc8)C_retrieve_proc(t3))(8,t3,t2,lf[197],lf[198],lf[199],lf[200],lf[201],lf[202]);}

/* k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1004,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3321,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[84],t3);}

/* a3320 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3321(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3321,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3325,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[84],t2,lf[195]);}

/* k3323 in a3320 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3325,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,2,lf[61],t4);
t6=(C_word)C_i_cddr(((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,t3,t7);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[194],t8));}

/* k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1007,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3302,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[90],t3);}

/* a3301 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3302(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3302,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3306,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[90],t2,lf[193]);}

/* k3304 in a3301 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3313,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3315,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3314 in k3304 in a3301 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3315(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3315,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3311 in k3304 in a3301 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3313,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[164],t1));}

/* k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1010,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3283,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[191],t3);}

/* a3282 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3283(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3283,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3287,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[191],t2,lf[192]);}

/* k3285 in a3282 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3294,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3296,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3295 in k3285 in a3282 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3296(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3296,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3292 in k3285 in a3282 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3294,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[190],t1));}

/* k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1013,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3264,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[107],t3);}

/* a3263 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3264(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3264,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3268,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[107],t2,lf[189]);}

/* k3266 in a3263 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3275,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3277,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3276 in k3266 in a3263 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3277(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3277,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3273 in k3266 in a3263 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3275,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[188],t1));}

/* k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1016,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3245,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[186],t3);}

/* a3244 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3245(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3245,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3249,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[186],t2,lf[187]);}

/* k3247 in a3244 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3256,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3258,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3257 in k3247 in a3244 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3258(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3258,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3254 in k3247 in a3244 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3256,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[185],t1));}

/* k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1019,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3226,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[183],t3);}

/* a3225 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3226(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3226,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3230,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[183],t2,lf[184]);}

/* k3228 in a3225 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3230,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3237,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3239,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3238 in k3228 in a3225 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3239(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3239,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3235 in k3228 in a3225 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3237,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[182],t1));}

/* k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1022,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3207,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[180],t3);}

/* a3206 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3207(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3207,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3211,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[180],t2,lf[181]);}

/* k3209 in a3206 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3211,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3218,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3220,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3219 in k3209 in a3206 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3220(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3220,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3216 in k3209 in a3206 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3218,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[179],t1));}

/* k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1025,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3107,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[174],t3);}

/* a3106 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3107(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3107,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3111,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[174],t2,lf[178]);}

/* k3109 in a3106 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3111,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_stringp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3120,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[174],((C_word*)t0)[3],lf[175]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3166,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[174],((C_word*)t0)[3],lf[177]);}}

/* k3164 in k3109 in a3106 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3166,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_a_i_list(&a,2,lf[61],lf[176]);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(C_word)C_a_i_list(&a,2,lf[61],t5);
t7=(C_word)C_i_caddr(((C_word*)t0)[3]);
t8=(C_word)C_a_i_list(&a,2,lf[61],t7);
t9=(C_word)C_i_cadddr(((C_word*)t0)[3]);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,6,lf[171],t3,t4,t6,t8,t9));}

/* k3118 in k3109 in a3106 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3120,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_i_caddr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,2,lf[61],t4);
t6=(C_word)C_i_car(((C_word*)t0)[3]);
t7=(C_word)C_a_i_list(&a,2,lf[61],t6);
t8=(C_word)C_i_cadddr(((C_word*)t0)[3]);
t9=(C_word)C_a_i_list(&a,2,lf[61],t8);
t10=(C_word)C_i_cdr(((C_word*)t0)[3]);
t11=(C_word)C_i_cadddr(t10);
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_list(&a,6,lf[171],t3,t5,t7,t9,t11));}

/* k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1028,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2887,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[168],t3);}

/* a2886 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2887(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2887,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2891,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=t3;
f_2891(t5,(C_word)C_i_stringp(t4));}
else{
t4=t3;
f_2891(t4,C_SCHEME_FALSE);}}

/* k2889 in a2886 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_2891(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2891,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2894,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=t1;
if(C_truep(t3)){
t4=t2;
f_2894(t4,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=t2;
f_2894(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t2;
f_2894(t4,C_SCHEME_FALSE);}}}

/* k2892 in k2889 in a2886 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_2894(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2894,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2900,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[168],((C_word*)t0)[4],lf[169]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2975,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* chicken.scm: 72   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[168],((C_word*)t0)[4],lf[172]);}
else{
/* chicken.scm: 72   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[168],((C_word*)t0)[4],lf[173]);}}}

/* k2973 in k2892 in k2889 in a2886 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2975,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cadr(((C_word*)t0)[3]):(C_word)C_i_car(((C_word*)t0)[3]));
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_list(&a,2,lf[61],t5);
t7=(C_truep(((C_word*)t0)[4])?(C_word)C_i_car(((C_word*)t0)[3]):lf[170]);
t8=(C_word)C_a_i_list(&a,2,lf[61],t7);
t9=(C_truep(((C_word*)t0)[4])?(C_word)C_i_caddr(((C_word*)t0)[3]):(C_word)C_i_cadr(((C_word*)t0)[3]));
t10=(C_word)C_a_i_list(&a,2,lf[61],t9);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3040,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t10,a[6]=t8,a[7]=t6,a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[4],tmp=(C_word)a,a+=10,tmp);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3042,tmp=(C_word)a,a+=2,tmp);
/* map */
t13=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,t12,t3);}

/* a3041 in k2973 in k2892 in k2889 in a2886 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3042(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3042,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k3038 in k2973 in k2892 in k2889 in a2886 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3040,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3020,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3032,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a3031 in k3038 in k2973 in k2892 in k2889 in a2886 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3032(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3032,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k3018 in k3038 in k2973 in k2892 in k2889 in a2886 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_3020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3020,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[9])?(C_word)C_i_cdddr(((C_word*)t0)[8]):(C_word)C_i_cddr(((C_word*)t0)[8]));
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[2],t3);
t5=(C_word)C_a_i_list(&a,6,lf[171],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[2],t5));}

/* k2898 in k2892 in k2889 in a2886 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[68],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2900,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,2,lf[61],t4);
t6=(C_word)C_a_i_list(&a,3,lf[164],t3,t5);
t7=(C_word)C_a_i_list(&a,2,lf[61],t2);
t8=(C_word)C_i_cadr(((C_word*)t0)[3]);
t9=(C_word)C_a_i_list(&a,2,lf[61],t8);
t10=(C_word)C_a_i_list(&a,2,lf[61],C_SCHEME_TRUE);
t11=(C_word)C_a_i_list(&a,4,lf[165],t7,t9,t10);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2926,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
t13=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t13))){
t14=(C_word)C_i_caddr(((C_word*)t0)[3]);
t15=(C_word)C_a_i_list(&a,3,lf[5],t2,t14);
t16=t12;
f_2926(t16,(C_word)C_a_i_list(&a,1,t15));}
else{
t14=t12;
f_2926(t14,C_SCHEME_END_OF_LIST);}}

/* k2924 in k2898 in k2892 in k2889 in a2886 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_2926(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2926,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[68],t3));}

/* k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1031,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2812,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[167],t3);}

/* a2811 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2812r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2812r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2812r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2816,a[2]=t4,a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 72   gensym */
t6=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k2814 in a2811 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2816,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2885,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* chicken.scm: 72   symbol->string */
t5=*((C_word*)lf[166]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}

/* k2883 in k2814 in a2811 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[74],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2885,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],t1);
t3=(C_word)C_a_i_list(&a,4,lf[164],((C_word*)t0)[8],((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,lf[61],C_SCHEME_FALSE);
t7=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t8=(C_word)C_a_i_list(&a,5,lf[165],t4,t5,t6,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2839,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[2]))){
t10=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t11=(C_word)C_a_i_list(&a,3,lf[5],((C_word*)t0)[6],t10);
t12=t9;
f_2839(t12,(C_word)C_a_i_list(&a,1,t11));}
else{
t10=t9;
f_2839(t10,C_SCHEME_END_OF_LIST);}}

/* k2837 in k2883 in k2814 in a2811 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_2839(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2839,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[68],t3));}

/* k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1034,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2706,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[163],t3);}

/* a2705 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2706(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_2706r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2706r(t0,t1,t2,t3);}}

static void C_ccall f_2706r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2710,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2806,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a2805 in a2705 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2806(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2806,3,t0,t1,t2);}
/* chicken.scm: 72   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k2708 in a2705 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2710,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2717,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2782,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   append-map */
t4=C_retrieve(lf[162]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],t1);}

/* a2781 in k2708 in a2705 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2782,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cddr(t2);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}}

/* k2715 in k2708 in a2705 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2721,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2723,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t5=(C_word)C_a_i_cons(&a,2,lf[79],t4);
/* chicken.scm: 72   fold-right */
t6=C_retrieve(lf[161]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t2,t3,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2722 in k2715 in k2708 in a2705 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2723(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[51],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2723,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t2);
t6=(C_word)C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_a_i_list(&a,2,lf[61],t7);
t9=(C_word)C_i_cadr(t2);
t10=(C_word)C_a_i_list(&a,2,lf[61],t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,5,lf[160],t8,t10,t3,t4));}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_a_i_list(&a,2,lf[61],t7);
t9=(C_word)C_i_cadr(t2);
t10=(C_word)C_a_i_list(&a,2,lf[61],t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[160],t8,t10,t4));}}

/* k2719 in k2715 in k2708 in a2705 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2721,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1037,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2677,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[159],t3);}

/* a2676 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2677(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2677,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2681,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   gensym */
t4=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[155]);}

/* k2679 in a2676 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2700,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2704,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   string-intersperse */
t4=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[158]);}

/* k2702 in k2679 in a2676 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   sprintf */
t2=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[157],((C_word*)t0)[2],t1);}

/* k2698 in k2679 in a2676 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2700,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[98],t1);
t3=(C_word)C_a_i_list(&a,2,lf[133],t2);
t4=(C_word)C_a_i_list(&a,2,lf[130],((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[68],t3,t4));}

/* k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1040,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2664,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[156],t3);}

/* a2663 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2664(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2664,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2668,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 72   gensym */
t5=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[155]);}

/* k2666 in a2663 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2668,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[90],t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[68],t2,t1));}

/* k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1043,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1870,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[112],t3);}

/* a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1870(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_1870r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1870r(t0,t1,t2,t3);}}

static void C_ccall f_1870r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1874,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cadr(t2);
/* chicken.scm: 72   ->string */
t7=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
/* chicken.scm: 72   sprintf */
t6=C_retrieve(lf[62]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[154],t2);}}

/* k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1874,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[4]):((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1880,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 72   gensym */
t5=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1880,2,t0,t1);}
t2=*((C_word*)lf[101]+1);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=t1,a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
/* chicken.scm: 72   gensym */
t9=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t9))(2,t9,t8);}

/* k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1886,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken.scm: 72   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1889,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* chicken.scm: 72   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1889,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1891,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t7=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1934,a[2]=t5,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=t5,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t1,a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[11],tmp=(C_word)a,a+=16,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2556,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=t10,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_2556(t12,t8,((C_word*)((C_word*)t0)[6])[1]);}

/* do539 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_2556(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2556,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2566,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_2566(t5,t3);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_pairp(t5);
t7=(C_word)C_i_not(t6);
if(C_truep(t7)){
t8=t4;
f_2566(t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2631,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2635,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 72   caar */
t10=*((C_word*)lf[152]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t2);}}}

/* k2633 in do539 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   keyword? */
t2=C_retrieve(lf[153]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2629 in do539 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2566(t2,(C_word)C_i_not(t1));}

/* k2564 in do539 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_2566(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2566,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 72   caar */
t3=*((C_word*)lf[152]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}}

/* k2568 in k2564 in do539 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2570,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2573,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[146]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2587,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2591,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 72   cadar */
t6=*((C_word*)lf[148]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(t1,lf[149]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2601,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   cadar */
t6=*((C_word*)lf[148]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(t1,lf[150]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2611,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   cadar */
t7=*((C_word*)lf[148]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[7]);}
else{
t6=(C_word)C_i_car(((C_word*)t0)[7]);
/* chicken.scm: 72   syntax-error */
t7=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t2,lf[112],lf[151],t6);}}}}

/* k2609 in k2568 in k2564 in do539 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2573(2,t3,t2);}

/* k2599 in k2568 in k2564 in do539 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2573(2,t3,t2);}

/* k2589 in k2568 in k2564 in do539 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   eval */
t2=C_retrieve(lf[147]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2585 in k2568 in k2564 in do539 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2573(2,t3,t2);}

/* k2571 in k2568 in k2564 in do539 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2556(t3,((C_word*)t0)[2],t2);}

/* k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1980,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t3=(C_word)C_a_i_list(&a,2,lf[104],((C_word*)t0)[3]);
/* chicken.scm: 72   ##sys#hash-table-set! */
t4=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[145]),((C_word*)t0)[14],t3);}

/* k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1987,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1991,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=t2,tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=t3;
f_1991(t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2463,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2467,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2479,a[2]=((C_word*)t0)[6],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2550,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 72   ->string */
t8=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[2]);}}

/* k2548 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string-append */
t2=*((C_word*)lf[141]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[142],t1,lf[143]);}

/* k2477 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2483,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2485,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a2484 in k2477 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2485(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2485,3,t0,t1,t2);}
t3=(C_word)C_i_length(t2);
switch(t3){
case C_fix(3):
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2502,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2514,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cadr(t2);
/* chicken.scm: 72   ->string */
t8=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);
case C_fix(2):
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2531,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2539,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cadr(t2);
/* chicken.scm: 72   ->string */
t8=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);
default:
/* chicken.scm: 72   syntax-error */
t4=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[112],lf[140],t2);}}

/* k2537 in a2484 in k2477 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   ##compiler#foreign-type-declaration */
t2=C_retrieve(lf[138]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2529 in a2484 in k2477 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   sprintf */
t2=C_retrieve(lf[62]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[139],t1);}

/* k2512 in a2484 in k2477 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   ##compiler#foreign-type-declaration */
t2=C_retrieve(lf[138]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2500 in a2484 in k2477 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_caddr(((C_word*)t0)[3]);
/* chicken.scm: 72   sprintf */
t3=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[137],t1,t2);}

/* k2481 in k2477 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2483,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_list(&a,1,lf[136]);
/* chicken.scm: 72   append */
t4=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t2,t3);}

/* k2465 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string-intersperse */
t2=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[135]);}

/* k2461 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2463,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[98],t1);
t3=(C_word)C_a_i_list(&a,2,lf[133],t2);
t4=((C_word*)t0)[2];
f_1991(t4,(C_word)C_a_i_list(&a,1,t3));}

/* k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_1991(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1991,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1995,a[2]=t1,a[3]=((C_word*)t0)[14],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1999,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2445,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 72   sprintf */
t6=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[132],((C_word*)t0)[2],((C_word*)t0)[2]);}
else{
t5=t3;
f_1999(t5,C_SCHEME_END_OF_LIST);}}

/* k2443 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2445,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[107],((C_word*)t0)[4],C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)((C_word*)t0)[3])[1],t2);
t4=((C_word*)t0)[2];
f_1999(t4,(C_word)C_a_i_list(&a,1,t3));}

/* k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_1999(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1999,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2003,a[2]=t1,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2007,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
t4=((C_word*)((C_word*)t0)[2])[1];
if(C_truep(t4)){
t5=(C_word)C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],lf[129]);
t6=(C_word)C_a_i_list(&a,3,lf[130],lf[131],lf[129]);
t7=(C_word)C_a_i_list(&a,3,lf[110],lf[129],t6);
t8=(C_word)C_a_i_list(&a,3,lf[82],t5,t7);
t9=t3;
f_2007(t9,(C_word)C_a_i_list(&a,1,t8));}
else{
t5=t3;
f_2007(t5,C_SCHEME_END_OF_LIST);}}

/* k2005 in k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_2007(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2007,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2011,a[2]=t1,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2013,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a2012 in k2005 in k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2013(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2013,3,t0,t1,t2);}
t3=(C_word)C_i_length(t2);
switch(t3){
case C_fix(3):
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_caddr(t2);
t7=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2035,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t1,a[8]=t6,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* chicken.scm: 72   stype */
t8=((C_word*)((C_word*)t0)[2])[1];
f_1891(t8,t7,t4);
case C_fix(2):
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cadr(t2);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2290,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* chicken.scm: 72   stype */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1891(t7,t6,t4);
default:
/* chicken.scm: 72   syntax-error */
t4=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[112],lf[128],t2);}}

/* k2288 in a2012 in k2005 in k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2367,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2398,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2402,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   sprintf */
t5=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[127],((C_word*)t0)[9],((C_word*)t0)[4]);}

/* k2400 in k2288 in a2012 in k2005 in k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   renamer */
t2=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2396 in k2288 in a2012 in k2005 in k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2365 in k2288 in a2012 in k2005 in k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2367,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2379,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=t3,a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2390,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 72   strtype */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1934(t6,t5,((C_word*)t0)[6]);}

/* k2388 in k2365 in k2288 in a2012 in k2005 in k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[124]:lf[125]);
/* chicken.scm: 72   sprintf */
t3=C_retrieve(lf[62]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],lf[126],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2377 in k2365 in k2288 in a2012 in k2005 in k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2379,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[107],((C_word*)t0)[11],((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[9],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2305,a[2]=((C_word*)t0)[8],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2308,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[7],a[9]=t4,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t6=(C_word)C_i_car(((C_word*)t0)[7]);
t7=t5;
f_2308(t7,(C_word)C_eqp(lf[102],t6));}
else{
t6=t5;
f_2308(t6,C_SCHEME_FALSE);}}

/* k2306 in k2377 in k2365 in k2288 in a2012 in k2005 in k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_2308(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2308,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
f_2305(t2,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[8],((C_word*)t0)[7]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2325,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2349,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2353,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   sprintf */
t6=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[123],((C_word*)t0)[6],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[9];
f_2305(t3,C_SCHEME_END_OF_LIST);}}}

/* k2351 in k2306 in k2377 in k2365 in k2288 in a2012 in k2005 in k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   renamer */
t2=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2347 in k2306 in k2377 in k2365 in k2288 in a2012 in k2005 in k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2323 in k2306 in k2377 in k2365 in k2288 in a2012 in k2005 in k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2325,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2337,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 72   sprintf */
t6=C_retrieve(lf[62]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,lf[122],((C_word*)t0)[6],((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k2335 in k2323 in k2306 in k2377 in k2365 in k2288 in a2012 in k2005 in k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2337,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[107],lf[114],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_2305(t4,(C_word)C_a_i_list(&a,1,t3));}

/* k2303 in k2377 in k2365 in k2288 in a2012 in k2005 in k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_2305(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2305,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[68],t2));}

/* k2033 in a2012 in k2005 in k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2176,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2271,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2275,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   sprintf */
t5=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[121],((C_word*)t0)[12],((C_word*)t0)[4]);}

/* k2273 in k2033 in a2012 in k2005 in k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   renamer */
t2=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2269 in k2033 in a2012 in k2005 in k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2174 in k2033 in a2012 in k2005 in k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2176,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[13],((C_word*)t0)[12]);
t3=(C_word)C_a_i_list(&a,2,lf[106],((C_word*)t0)[11]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2248,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[9],a[13]=t4,a[14]=((C_word*)t0)[10],tmp=(C_word)a,a+=15,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2259,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[12],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 72   strtype */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1934(t7,t6,((C_word*)t0)[6]);}

/* k2257 in k2174 in k2033 in a2012 in k2005 in k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[118]:lf[119]);
/* chicken.scm: 72   sprintf */
t3=C_retrieve(lf[62]);
((C_proc7)C_retrieve_proc(t3))(7,t3,((C_word*)t0)[5],lf[120],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2246 in k2174 in k2033 in a2012 in k2005 in k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[161],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2248,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[107],((C_word*)t0)[14],((C_word*)t0)[13],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[12],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[11],((C_word*)t0)[10]);
t6=(C_word)C_a_i_list(&a,3,lf[108],((C_word*)t0)[10],C_fix(0));
t7=(C_word)C_a_i_list(&a,3,lf[109],((C_word*)t0)[10],((C_word*)t0)[9]);
t8=(C_word)C_a_i_list(&a,3,lf[110],t6,t7);
t9=(C_word)C_a_i_list(&a,2,lf[111],t8);
t10=(C_word)C_a_i_list(&a,3,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10]);
t11=(C_word)C_a_i_list(&a,2,lf[61],lf[112]);
t12=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[8]);
t13=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[10]);
t14=(C_word)C_a_i_list(&a,6,lf[50],t11,lf[113],t12,t13,((C_word*)t0)[9]);
t15=(C_word)C_a_i_list(&a,4,lf[72],t9,t10,t14);
t16=(C_word)C_a_i_list(&a,3,lf[2],t5,t15);
t17=(C_word)C_a_i_list(&a,3,lf[79],t4,t16);
t18=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[7],t17);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2050,a[2]=((C_word*)t0)[6],a[3]=t18,tmp=(C_word)a,a+=4,tmp);
t20=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2053,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[5],a[12]=t19,tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t21=(C_word)C_i_car(((C_word*)t0)[5]);
t22=t20;
f_2053(t22,(C_word)C_eqp(lf[102],t21));}
else{
t21=t20;
f_2053(t21,C_SCHEME_FALSE);}}

/* k2051 in k2246 in k2174 in k2033 in a2012 in k2005 in k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_2053(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2053,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[12];
f_2050(t2,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[11],((C_word*)t0)[10]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2070,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2158,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2162,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   sprintf */
t6=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[117],((C_word*)t0)[9],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[12];
f_2050(t3,C_SCHEME_END_OF_LIST);}}}

/* k2160 in k2051 in k2246 in k2174 in k2033 in a2012 in k2005 in k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   renamer */
t2=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2156 in k2051 in k2246 in k2174 in k2033 in a2012 in k2005 in k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2068 in k2051 in k2246 in k2174 in k2033 in a2012 in k2005 in k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2070,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(C_word)C_a_i_list(&a,2,lf[106],((C_word*)t0)[8]);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,3,t2,t3,t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2142,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[5],a[10]=t5,tmp=(C_word)a,a+=11,tmp);
/* chicken.scm: 72   sprintf */
t7=C_retrieve(lf[62]);
((C_proc7)C_retrieve_proc(t7))(7,t7,t6,lf[116],((C_word*)t0)[9],((C_word*)t0)[2],((C_word*)t0)[8],((C_word*)t0)[6]);}

/* k2140 in k2068 in k2051 in k2246 in k2174 in k2033 in a2012 in k2005 in k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[153],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2142,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[107],lf[114],((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_a_i_list(&a,3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t6=(C_word)C_a_i_list(&a,3,lf[108],((C_word*)t0)[7],C_fix(0));
t7=(C_word)C_a_i_list(&a,3,lf[109],((C_word*)t0)[7],((C_word*)t0)[5]);
t8=(C_word)C_a_i_list(&a,3,lf[110],t6,t7);
t9=(C_word)C_a_i_list(&a,2,lf[111],t8);
t10=(C_word)C_a_i_list(&a,4,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t11=(C_word)C_a_i_list(&a,2,lf[61],lf[112]);
t12=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t13=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[7]);
t14=(C_word)C_a_i_list(&a,6,lf[50],t11,lf[115],t12,t13,((C_word*)t0)[5]);
t15=(C_word)C_a_i_list(&a,4,lf[72],t9,t10,t14);
t16=(C_word)C_a_i_list(&a,3,lf[2],t5,t15);
t17=(C_word)C_a_i_list(&a,3,lf[79],t4,t16);
t18=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[3],t17);
t19=((C_word*)t0)[2];
f_2050(t19,(C_word)C_a_i_list(&a,1,t18));}

/* k2048 in k2246 in k2174 in k2033 in a2012 in k2005 in k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_2050(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2050,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[68],t2));}

/* k2009 in k2005 in k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2001 in k1997 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_2003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1993 in k1989 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1985 in k1978 in k1975 in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1987,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[68],t1));}

/* strtype in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_1934(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1934,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1950,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(lf[102],t5);
if(C_truep(t6)){
t7=(C_word)C_i_cadr(t2);
/* chicken.scm: 72   strtype */
t9=t4;
t10=t7;
t1=t9;
t2=t10;
goto loop;}
else{
t7=t4;
f_1950(2,t7,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* k1948 in strtype in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_memq(t2,lf[105]));}}

/* stype in k1887 in k1884 in k1881 in k1878 in k1872 in a1869 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_1891(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1891,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(lf[102],t3);
if(C_truep(t4)){
t5=(C_word)C_i_cadr(t2);
/* chicken.scm: 72   stype */
t9=t1;
t10=t5;
t1=t9;
t2=t10;
goto loop;}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_memq(t5,lf[103]);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?(C_word)C_a_i_list(&a,2,lf[104],t2):t2));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1046,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1856,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[98],t3);}

/* a1855 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1856(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1856,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,lf[98],t2);
t4=(C_word)C_a_i_list(&a,2,lf[61],t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,lf[99],t4));}

/* k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1049,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1516,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[95],t3);}

/* a1515 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1516(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_1516r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1516r(t0,t1,t2,t3);}}

static void C_ccall f_1516r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(7);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1520,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t4)[1]))){
t6=(C_word)C_i_car(((C_word*)t4)[1]);
if(C_truep((C_word)C_booleanp(t6))){
t7=(C_word)C_i_cdr(((C_word*)t4)[1]);
t8=C_set_block_item(t4,0,t7);
t9=t5;
f_1520(t9,t6);}
else{
t7=t5;
f_1520(t7,C_SCHEME_TRUE);}}
else{
t6=t5;
f_1520(t6,C_SCHEME_TRUE);}}

/* k1518 in a1515 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_1520(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1520,NULL,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1523,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 72   ->string */
t5=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}

/* k1521 in k1518 in a1515 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1523,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=lf[67];
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1828,tmp=(C_word)a,a+=2,tmp);
/* map */
t8=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)((C_word*)t0)[2])[1]);}

/* a1827 in k1521 in k1518 in a1515 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1828(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1828,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_car(t2):t2));}

/* k1524 in k1521 in k1518 in a1515 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1526,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1529,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1803,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a1802 in k1524 in k1521 in k1518 in a1515 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1803(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1803,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cadr(t2));}
else{
/* chicken.scm: 72   syntax-error */
t4=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[95],lf[97],t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1527 in k1524 in k1521 in k1518 in a1515 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1529,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1532,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1771,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a1770 in k1527 in k1524 in k1521 in k1518 in a1515 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1771(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1771,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_caddr(t2));}
else{
t4=(C_word)C_i_car(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,lf[61],t4));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}}

/* k1530 in k1527 in k1524 in k1521 in k1518 in a1515 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1535,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[2]))){
t3=(C_word)C_i_length(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1745,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_and((C_word)C_fixnum_less_or_equal_p(C_fix(2),t3),(C_word)C_fixnum_less_or_equal_p(t3,C_fix(3))))){
t5=t4;
f_1745(2,t5,C_SCHEME_UNDEFINED);}
else{
/* chicken.scm: 72   syntax-error */
t5=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[95],lf[96],((C_word*)t0)[2]);}}
else{
t3=t2;
f_1535(t3,C_SCHEME_UNDEFINED);}}

/* k1743 in k1530 in k1527 in k1524 in k1521 in k1518 in a1515 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[7]);
t5=C_mutate(((C_word *)((C_word*)t0)[5])+1,t4);
t6=(C_word)C_eqp(C_fix(3),((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(C_word)C_i_caddr(((C_word*)t0)[7]);
t8=C_mutate(((C_word *)((C_word*)t0)[3])+1,t7);
t9=((C_word*)t0)[2];
f_1535(t9,t8);}
else{
t7=((C_word*)t0)[2];
f_1535(t7,C_SCHEME_UNDEFINED);}}

/* k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in a1515 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_1535(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1535,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1538,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[2])){
/* map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[6]),((C_word*)t0)[4]);}
else{
t3=t2;
f_1538(2,t3,((C_word*)t0)[4]);}}

/* k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in a1515 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1541,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1733,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 72   conc */
t4=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[7])[1],lf[93]);}

/* k1731 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in a1515 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in a1515 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1544,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1729,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 72   conc */
t4=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[92],((C_word*)((C_word*)t0)[8])[1]);}

/* k1727 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in a1515 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in a1515 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1551,a[2]=((C_word*)t0)[10],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1555,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1717,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 72   map */
t5=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* a1716 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in a1515 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1717(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1717,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1725,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 72   ->string */
t5=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k1723 in a1716 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in a1515 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1725,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[90],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1));}

/* k1553 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in a1515 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[97],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1555,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[10],lf[69]);
t3=(C_word)C_a_i_list(&a,2,lf[70],lf[69]);
t4=(C_word)C_a_i_list(&a,2,lf[71],lf[69]);
t5=(C_word)C_a_i_list(&a,4,lf[72],t3,t4,lf[69]);
t6=(C_word)C_a_i_list(&a,2,lf[69],t5);
t7=(C_word)C_a_i_list(&a,2,lf[73],C_fix(0));
t8=(C_word)C_a_i_list(&a,2,t6,t7);
t9=(C_word)C_a_i_list(&a,2,lf[74],lf[69]);
t10=(C_word)C_a_i_list(&a,2,lf[75],lf[69]);
t11=(C_word)C_a_i_list(&a,2,lf[76],lf[69]);
t12=(C_word)C_a_i_list(&a,2,lf[77],t11);
t13=(C_word)C_a_i_list(&a,1,t12);
t14=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1657,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t2,a[12]=t8,a[13]=t9,a[14]=t10,a[15]=t13,tmp=(C_word)a,a+=16,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1661,a[2]=t14,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t16=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1679,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   map */
t17=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t17))(5,t17,t15,t16,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* a1678 in k1553 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in a1515 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1679,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,t4,t2));}

/* k1659 in k1553 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in a1515 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1661,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)((C_word*)t0)[3])[1]);
t3=(C_word)C_a_i_list(&a,4,lf[88],lf[89],lf[77],t2);
t4=(C_word)C_a_i_list(&a,2,lf[86],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* ##sys#append */
t6=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[2],t1,t5);}

/* k1655 in k1553 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in a1515 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[88],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1657,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[77],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[78],t2);
t4=(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[15],t3);
t5=(C_word)C_a_i_list(&a,3,lf[80],lf[73],t4);
t6=(C_word)C_a_i_list(&a,3,lf[81],((C_word*)t0)[14],t5);
t7=(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[13],lf[73],t6);
t8=(C_word)C_a_i_list(&a,4,lf[79],lf[81],((C_word*)t0)[12],t7);
t9=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[11],t8);
t10=(C_word)C_a_i_list(&a,2,((C_word*)t0)[10],lf[77]);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1583,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t9,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t10,tmp=(C_word)a,a+=10,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1587,a[2]=t11,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1597,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   map */
t14=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t14))(5,t14,t12,t13,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1596 in k1655 in k1553 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in a1515 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1597(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1597,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,3,lf[87],lf[77],t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,t4,t3));}

/* k1585 in k1655 in k1553 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in a1515 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1587,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[86],((C_word*)((C_word*)t0)[3])[1]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k1581 in k1655 in k1553 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in a1515 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1583,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[83],t1);
t3=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_list(&a,5,lf[84],((C_word*)((C_word*)t0)[8])[1],((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],t3,t4);
/* ##sys#append */
t6=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[3],((C_word*)t0)[2],t5);}

/* k1549 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in a1515 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1551,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[68],t1));}

/* k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1052,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1482,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[66],t3);}

/* a1481 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1482(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[60],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1482,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t2,lf[60]);
t5=(C_word)C_a_i_list(&a,2,lf[61],t2);
t6=(C_word)C_a_i_list(&a,2,lf[61],t3);
t7=(C_word)C_a_i_list(&a,4,lf[62],lf[63],t5,t6);
t8=(C_word)C_a_i_list(&a,2,lf[56],t7);
t9=(C_word)C_a_i_list(&a,2,lf[61],t3);
t10=(C_word)C_a_i_list(&a,3,lf[64],t9,lf[60]);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[65],t4,t8,t10));}

/* k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1055,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1420,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[51],t3);}

/* a1419 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1420(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_1420r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1420r(t0,t1,t2,t3);}}

static void C_ccall f_1420r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1423,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1430,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1433,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_i_car(t2);
t8=t6;
f_1433(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_1433(t7,C_SCHEME_FALSE);}}

/* k1431 in a1419 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_1433(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1433,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_memq(lf[54],C_retrieve(lf[55])))){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 72   warning */
t3=C_retrieve(lf[56]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],lf[57],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1459,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken.scm: 72   ##compiler#register-compiler-macro */
t5=C_retrieve(lf[58]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,t3,t4,((C_word*)t0)[2]);}}
else{
/* chicken.scm: 72   bad */
t2=((C_word*)t0)[3];
f_1423(t2,((C_word*)t0)[4]);}}

/* k1457 in k1431 in a1419 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_1430(2,t2,C_SCHEME_UNDEFINED);}
else{
/* chicken.scm: 72   bad */
t2=((C_word*)t0)[2];
f_1423(t2,((C_word*)t0)[3]);}}

/* k1428 in a1419 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[53]);}

/* bad in a1419 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_1423(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1423,NULL,2,t0,t1);}
/* chicken.scm: 72   syntax-error */
t2=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,lf[51],lf[52],((C_word*)t0)[2]);}

/* k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1059,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1418,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 79   argv */
t4=C_retrieve(lf[49]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k1416 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1418,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1397,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1399,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1407,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1411,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 80   getenv */
t7=C_retrieve(lf[47]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[48]);}

/* k1409 in k1416 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[45]);
/* chicken.scm: 80   string-split */
t3=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k1405 in k1416 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 80   remove */
t2=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1398 in k1416 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1399(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1399,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_string_equal_p(t2,lf[43]));}

/* k1395 in k1416 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 78   append */
t2=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1057 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1059,2,t0,t1);}
t2=C_mutate((C_word*)lf[10]+1,t1);
t3=C_mutate((C_word*)lf[11]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1061,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1168,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1176,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1188,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 107  ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}

/* a1187 in k1057 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1188(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1188,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1192,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1200,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_1200(t9,t5,((C_word*)t4)[1]);}

/* loop in a1187 in k1057 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_1200(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(26);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1200,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_eqp(lf[19],t3);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1222,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t4);
/* chicken.scm: 113  string->number */
C_string_to_number(3,0,t6,t7);}
else{
t6=(C_word)C_eqp(lf[26],t3);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1285,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_car(t4);
/* chicken.scm: 127  string->number */
C_string_to_number(3,0,t7,t8);}
else{
t7=(C_word)C_eqp(lf[30],t3);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1339,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 136  cons* */
t9=C_retrieve(lf[20]);
((C_proc11)C_retrieve_proc(t9))(11,t9,t8,lf[31],lf[32],lf[28],lf[22],lf[21],lf[33],lf[34],lf[27],((C_word*)((C_word*)t0)[2])[1]);}
else{
if(C_truep((C_word)C_i_memq(t3,C_retrieve(lf[35])))){
/* chicken.scm: 140  loop */
t17=t1;
t18=t4;
t1=t17;
t2=t18;
goto loop;}
else{
if(C_truep((C_word)C_i_memq(t3,C_retrieve(lf[36])))){
if(C_truep((C_word)C_i_pairp(t4))){
t8=(C_word)C_i_cdr(t4);
/* chicken.scm: 143  loop */
t17=t1;
t18=t8;
t1=t17;
t2=t18;
goto loop;}
else{
/* chicken.scm: 144  quit */
t8=C_retrieve(lf[37]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,lf[38],t3);}}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1376,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1383,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_stringp(t3))){
t10=t9;
f_1383(2,t10,t3);}
else{
/* chicken.scm: 148  conc */
t10=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,lf[41],t3);}}}}}}}}

/* k1381 in loop in a1187 in k1057 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 146  compiler-warning */
t2=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[24],lf[39],t1);}

/* k1374 in loop in a1187 in k1057 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 149  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1200(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1337 in loop in a1187 in k1057 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* chicken.scm: 139  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1200(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1283 in loop in a1187 in k1057 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1288,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
switch(t1){
case C_fix(0):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1302,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 129  cons* */
t4=C_retrieve(lf[20]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[27],lf[28],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,lf[28],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_1288(2,t5,t4);
case C_fix(2):
t3=t2;
f_1288(2,t3,C_SCHEME_FALSE);
default:
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 132  compiler-warning */
t4=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[24],lf[29],t3);}}

/* k1300 in k1283 in loop in a1187 in k1057 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1288(2,t3,t2);}

/* k1286 in k1283 in loop in a1187 in k1057 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 133  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1200(t3,((C_word*)t0)[2],t2);}

/* k1220 in loop in a1187 in k1057 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1222,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1225,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
switch(t1){
case C_fix(0):
t3=t2;
f_1225(2,t3,C_SCHEME_FALSE);
case C_fix(1):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1245,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 117  cons* */
t4=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[21],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(2):
t3=(C_word)C_a_i_cons(&a,2,lf[21],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_1225(2,t5,t4);
case C_fix(3):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1265,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 123  cons* */
t4=C_retrieve(lf[20]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[21],lf[22],((C_word*)((C_word*)t0)[2])[1]);
default:
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 124  compiler-warning */
t4=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[24],lf[25],t3);}}

/* k1263 in k1220 in loop in a1187 in k1057 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1225(2,t3,t2);}

/* k1243 in k1220 in loop in a1187 in k1057 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1225(2,t3,t2);}

/* k1223 in k1220 in loop in a1187 in k1057 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 125  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1200(t3,((C_word*)t0)[2],t2);}

/* k1190 in a1187 in k1057 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1195,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t2,C_retrieve(lf[18]),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k1193 in k1190 in a1187 in k1057 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 151  exit */
t2=C_retrieve(lf[17]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a1175 in k1057 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1183,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 107  user-options-pass */
t3=C_retrieve(lf[16]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1181 in a1175 in k1057 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_retrieve(lf[11]));
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_retrieve(lf[10]));}

/* k1166 in k1057 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1171,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1174,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
t4=C_retrieve(lf[15]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k1172 in k1166 in k1057 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1169 in k1166 in k1057 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##compiler#process-command-line in k1057 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1061(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1061,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1067,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_1067(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in ##compiler#process-command-line in k1057 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_1067(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1067,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1081,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 92   reverse */
t6=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_string_length(t5);
t7=(C_word)C_i_string_ref(t5,C_fix(0));
t8=(C_word)C_eqp(C_make_character(45),t7);
t9=(C_truep(t8)?(C_word)C_fixnum_greaterp(t6,C_fix(1)):C_SCHEME_FALSE);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1102,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t6,C_fix(1)))){
t11=(C_word)C_i_string_ref(t5,C_fix(1));
t12=t10;
f_1102(t12,(C_word)C_eqp(C_make_character(58),t11));}
else{
t11=t10;
f_1102(t11,C_SCHEME_FALSE);}}
else{
if(C_truep(t4)){
t10=(C_word)C_i_cdr(t2);
t11=(C_word)C_a_i_cons(&a,2,t5,t3);
/* chicken.scm: 101  loop */
t17=t1;
t18=t10;
t19=t11;
t20=t4;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}
else{
t10=(C_word)C_i_cdr(t2);
/* chicken.scm: 102  loop */
t17=t1;
t18=t10;
t19=t3;
t20=t5;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}}}}

/* k1100 in loop in ##compiler#process-command-line in k1057 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_fcall f_1102(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1102,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* chicken.scm: 98   loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_1067(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1124,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1128,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 99   substring */
t5=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]);}}

/* k1126 in k1100 in loop in ##compiler#process-command-line in k1057 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 99   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1122 in k1100 in loop in ##compiler#process-command-line in k1057 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1124,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* chicken.scm: 99   loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1067(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1079 in loop in ##compiler#process-command-line in k1057 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k933 in k930 in k851 in k848 in k845 in k842 in k839 in k836 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_1081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 92   values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* assign in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_765(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_765,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_769,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t5=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[8],t2,lf[9]);}

/* k767 in assign in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_769,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t2=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,lf[3]);
t4=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[4],t2,t4));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t3,((C_word*)t0)[4]));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_806,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   map */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[6]),((C_word*)t0)[5]);}}}

/* k804 in k767 in assign in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_806,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_825,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_827,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   map */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[2],t1);}

/* a826 in k804 in k767 in assign in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_827,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t2,t3));}

/* k823 in k804 in k767 in assign in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k735 in k732 in k729 in k726 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 in k684 */
static void C_ccall f_825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_825,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[2],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[4],((C_word*)t0)[2],t3));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[576] = {
{"toplevelchicken.scm",(void*)C_toplevel},
{"f_686chicken.scm",(void*)f_686},
{"f_689chicken.scm",(void*)f_689},
{"f_692chicken.scm",(void*)f_692},
{"f_695chicken.scm",(void*)f_695},
{"f_698chicken.scm",(void*)f_698},
{"f_701chicken.scm",(void*)f_701},
{"f_704chicken.scm",(void*)f_704},
{"f_707chicken.scm",(void*)f_707},
{"f_710chicken.scm",(void*)f_710},
{"f_713chicken.scm",(void*)f_713},
{"f_716chicken.scm",(void*)f_716},
{"f_719chicken.scm",(void*)f_719},
{"f_722chicken.scm",(void*)f_722},
{"f_728chicken.scm",(void*)f_728},
{"f_6906chicken.scm",(void*)f_6906},
{"f_6910chicken.scm",(void*)f_6910},
{"f_6913chicken.scm",(void*)f_6913},
{"f_6916chicken.scm",(void*)f_6916},
{"f_6922chicken.scm",(void*)f_6922},
{"f_7128chicken.scm",(void*)f_7128},
{"f_7108chicken.scm",(void*)f_7108},
{"f_7104chicken.scm",(void*)f_7104},
{"f_7084chicken.scm",(void*)f_7084},
{"f_6947chicken.scm",(void*)f_6947},
{"f_6957chicken.scm",(void*)f_6957},
{"f_7076chicken.scm",(void*)f_7076},
{"f_6960chicken.scm",(void*)f_6960},
{"f_7072chicken.scm",(void*)f_7072},
{"f_6963chicken.scm",(void*)f_6963},
{"f_6994chicken.scm",(void*)f_6994},
{"f_6974chicken.scm",(void*)f_6974},
{"f_6945chicken.scm",(void*)f_6945},
{"f_731chicken.scm",(void*)f_731},
{"f_6818chicken.scm",(void*)f_6818},
{"f_6835chicken.scm",(void*)f_6835},
{"f_6838chicken.scm",(void*)f_6838},
{"f_6844chicken.scm",(void*)f_6844},
{"f_734chicken.scm",(void*)f_734},
{"f_6777chicken.scm",(void*)f_6777},
{"f_6781chicken.scm",(void*)f_6781},
{"f_737chicken.scm",(void*)f_737},
{"f_6761chicken.scm",(void*)f_6761},
{"f_6771chicken.scm",(void*)f_6771},
{"f_6769chicken.scm",(void*)f_6769},
{"f_740chicken.scm",(void*)f_740},
{"f_6684chicken.scm",(void*)f_6684},
{"f_6688chicken.scm",(void*)f_6688},
{"f_6756chicken.scm",(void*)f_6756},
{"f_6691chicken.scm",(void*)f_6691},
{"f_6700chicken.scm",(void*)f_6700},
{"f_6747chicken.scm",(void*)f_6747},
{"f_6714chicken.scm",(void*)f_6714},
{"f_6722chicken.scm",(void*)f_6722},
{"f_6724chicken.scm",(void*)f_6724},
{"f_6741chicken.scm",(void*)f_6741},
{"f_6706chicken.scm",(void*)f_6706},
{"f_6698chicken.scm",(void*)f_6698},
{"f_743chicken.scm",(void*)f_743},
{"f_6624chicken.scm",(void*)f_6624},
{"f_6628chicken.scm",(void*)f_6628},
{"f_746chicken.scm",(void*)f_746},
{"f_6565chicken.scm",(void*)f_6565},
{"f_6569chicken.scm",(void*)f_6569},
{"f_6596chicken.scm",(void*)f_6596},
{"f_749chicken.scm",(void*)f_749},
{"f_6391chicken.scm",(void*)f_6391},
{"f_6395chicken.scm",(void*)f_6395},
{"f_6398chicken.scm",(void*)f_6398},
{"f_6559chicken.scm",(void*)f_6559},
{"f_6401chicken.scm",(void*)f_6401},
{"f_6553chicken.scm",(void*)f_6553},
{"f_6404chicken.scm",(void*)f_6404},
{"f_6551chicken.scm",(void*)f_6551},
{"f_6515chicken.scm",(void*)f_6515},
{"f_6529chicken.scm",(void*)f_6529},
{"f_6543chicken.scm",(void*)f_6543},
{"f_6523chicken.scm",(void*)f_6523},
{"f_6519chicken.scm",(void*)f_6519},
{"f_6411chicken.scm",(void*)f_6411},
{"f_6507chicken.scm",(void*)f_6507},
{"f_6483chicken.scm",(void*)f_6483},
{"f_6501chicken.scm",(void*)f_6501},
{"f_6491chicken.scm",(void*)f_6491},
{"f_6487chicken.scm",(void*)f_6487},
{"f_6479chicken.scm",(void*)f_6479},
{"f_6463chicken.scm",(void*)f_6463},
{"f_6439chicken.scm",(void*)f_6439},
{"f_6457chicken.scm",(void*)f_6457},
{"f_6447chicken.scm",(void*)f_6447},
{"f_6443chicken.scm",(void*)f_6443},
{"f_6435chicken.scm",(void*)f_6435},
{"f_752chicken.scm",(void*)f_752},
{"f_6296chicken.scm",(void*)f_6296},
{"f_6332chicken.scm",(void*)f_6332},
{"f_6345chicken.scm",(void*)f_6345},
{"f_6303chicken.scm",(void*)f_6303},
{"f_755chicken.scm",(void*)f_755},
{"f_6186chicken.scm",(void*)f_6186},
{"f_6190chicken.scm",(void*)f_6190},
{"f_6193chicken.scm",(void*)f_6193},
{"f_6196chicken.scm",(void*)f_6196},
{"f_6199chicken.scm",(void*)f_6199},
{"f_6290chicken.scm",(void*)f_6290},
{"f_6202chicken.scm",(void*)f_6202},
{"f_6284chicken.scm",(void*)f_6284},
{"f_6205chicken.scm",(void*)f_6205},
{"f_6278chicken.scm",(void*)f_6278},
{"f_6282chicken.scm",(void*)f_6282},
{"f_6212chicken.scm",(void*)f_6212},
{"f_6250chicken.scm",(void*)f_6250},
{"f_6248chicken.scm",(void*)f_6248},
{"f_758chicken.scm",(void*)f_758},
{"f_6176chicken.scm",(void*)f_6176},
{"f_761chicken.scm",(void*)f_761},
{"f_6162chicken.scm",(void*)f_6162},
{"f_764chicken.scm",(void*)f_764},
{"f_838chicken.scm",(void*)f_838},
{"f_841chicken.scm",(void*)f_841},
{"f_5900chicken.scm",(void*)f_5900},
{"f_5904chicken.scm",(void*)f_5904},
{"f_5913chicken.scm",(void*)f_5913},
{"f_6122chicken.scm",(void*)f_6122},
{"f_6135chicken.scm",(void*)f_6135},
{"f_5916chicken.scm",(void*)f_5916},
{"f_6112chicken.scm",(void*)f_6112},
{"f_6120chicken.scm",(void*)f_6120},
{"f_5919chicken.scm",(void*)f_5919},
{"f_6066chicken.scm",(void*)f_6066},
{"f_6099chicken.scm",(void*)f_6099},
{"f_6106chicken.scm",(void*)f_6106},
{"f_6082chicken.scm",(void*)f_6082},
{"f_5931chicken.scm",(void*)f_5931},
{"f_6060chicken.scm",(void*)f_6060},
{"f_5938chicken.scm",(void*)f_5938},
{"f_5940chicken.scm",(void*)f_5940},
{"f_6054chicken.scm",(void*)f_6054},
{"f_5974chicken.scm",(void*)f_5974},
{"f_6028chicken.scm",(void*)f_6028},
{"f_6005chicken.scm",(void*)f_6005},
{"f_5985chicken.scm",(void*)f_5985},
{"f_5960chicken.scm",(void*)f_5960},
{"f_5968chicken.scm",(void*)f_5968},
{"f_5958chicken.scm",(void*)f_5958},
{"f_5920chicken.scm",(void*)f_5920},
{"f_5860chicken.scm",(void*)f_5860},
{"f_5883chicken.scm",(void*)f_5883},
{"f_5887chicken.scm",(void*)f_5887},
{"f_5829chicken.scm",(void*)f_5829},
{"f_5850chicken.scm",(void*)f_5850},
{"f_844chicken.scm",(void*)f_844},
{"f_5778chicken.scm",(void*)f_5778},
{"f_5782chicken.scm",(void*)f_5782},
{"f_5793chicken.scm",(void*)f_5793},
{"f_5818chicken.scm",(void*)f_5818},
{"f_847chicken.scm",(void*)f_847},
{"f_5658chicken.scm",(void*)f_5658},
{"f_5662chicken.scm",(void*)f_5662},
{"f_5772chicken.scm",(void*)f_5772},
{"f_5770chicken.scm",(void*)f_5770},
{"f_5671chicken.scm",(void*)f_5671},
{"f_5758chicken.scm",(void*)f_5758},
{"f_5766chicken.scm",(void*)f_5766},
{"f_5674chicken.scm",(void*)f_5674},
{"f_5752chicken.scm",(void*)f_5752},
{"f_5694chicken.scm",(void*)f_5694},
{"f_5704chicken.scm",(void*)f_5704},
{"f_5724chicken.scm",(void*)f_5724},
{"f_5730chicken.scm",(void*)f_5730},
{"f_5738chicken.scm",(void*)f_5738},
{"f_5728chicken.scm",(void*)f_5728},
{"f_5702chicken.scm",(void*)f_5702},
{"f_5698chicken.scm",(void*)f_5698},
{"f_5675chicken.scm",(void*)f_5675},
{"f_850chicken.scm",(void*)f_850},
{"f_5637chicken.scm",(void*)f_5637},
{"f_5641chicken.scm",(void*)f_5641},
{"f_853chicken.scm",(void*)f_853},
{"f_5627chicken.scm",(void*)f_5627},
{"f_859chicken.scm",(void*)f_859},
{"f_868chicken.scm",(void*)f_868},
{"f_884chicken.scm",(void*)f_884},
{"f_871chicken.scm",(void*)f_871},
{"f_932chicken.scm",(void*)f_932},
{"f_5606chicken.scm",(void*)f_5606},
{"f_5610chicken.scm",(void*)f_5610},
{"f_935chicken.scm",(void*)f_935},
{"f_5490chicken.scm",(void*)f_5490},
{"f_5494chicken.scm",(void*)f_5494},
{"f_5503chicken.scm",(void*)f_5503},
{"f_5517chicken.scm",(void*)f_5517},
{"f_5581chicken.scm",(void*)f_5581},
{"f_5563chicken.scm",(void*)f_5563},
{"f_5546chicken.scm",(void*)f_5546},
{"f_938chicken.scm",(void*)f_938},
{"f_5391chicken.scm",(void*)f_5391},
{"f_5401chicken.scm",(void*)f_5401},
{"f_5414chicken.scm",(void*)f_5414},
{"f_5430chicken.scm",(void*)f_5430},
{"f_5468chicken.scm",(void*)f_5468},
{"f_5466chicken.scm",(void*)f_5466},
{"f_5458chicken.scm",(void*)f_5458},
{"f_5412chicken.scm",(void*)f_5412},
{"f_941chicken.scm",(void*)f_941},
{"f_5302chicken.scm",(void*)f_5302},
{"f_5312chicken.scm",(void*)f_5312},
{"f_5325chicken.scm",(void*)f_5325},
{"f_5341chicken.scm",(void*)f_5341},
{"f_5369chicken.scm",(void*)f_5369},
{"f_5323chicken.scm",(void*)f_5323},
{"f_944chicken.scm",(void*)f_944},
{"f_5016chicken.scm",(void*)f_5016},
{"f_5213chicken.scm",(void*)f_5213},
{"f_5216chicken.scm",(void*)f_5216},
{"f_5219chicken.scm",(void*)f_5219},
{"f_5292chicken.scm",(void*)f_5292},
{"f_5300chicken.scm",(void*)f_5300},
{"f_5235chicken.scm",(void*)f_5235},
{"f_5238chicken.scm",(void*)f_5238},
{"f_5241chicken.scm",(void*)f_5241},
{"f_5244chicken.scm",(void*)f_5244},
{"f_5282chicken.scm",(void*)f_5282},
{"f_5290chicken.scm",(void*)f_5290},
{"f_5247chicken.scm",(void*)f_5247},
{"f_5027chicken.scm",(void*)f_5027},
{"f_5031chicken.scm",(void*)f_5031},
{"f_5035chicken.scm",(void*)f_5035},
{"f_5037chicken.scm",(void*)f_5037},
{"f_5082chicken.scm",(void*)f_5082},
{"f_5094chicken.scm",(void*)f_5094},
{"f_5090chicken.scm",(void*)f_5090},
{"f_5058chicken.scm",(void*)f_5058},
{"f_5250chicken.scm",(void*)f_5250},
{"f_5110chicken.scm",(void*)f_5110},
{"f_5210chicken.scm",(void*)f_5210},
{"f_5174chicken.scm",(void*)f_5174},
{"f_5144chicken.scm",(void*)f_5144},
{"f_5253chicken.scm",(void*)f_5253},
{"f_5220chicken.scm",(void*)f_5220},
{"f_5232chicken.scm",(void*)f_5232},
{"f_5228chicken.scm",(void*)f_5228},
{"f_947chicken.scm",(void*)f_947},
{"f_4959chicken.scm",(void*)f_4959},
{"f_4963chicken.scm",(void*)f_4963},
{"f_950chicken.scm",(void*)f_950},
{"f_4953chicken.scm",(void*)f_4953},
{"f_953chicken.scm",(void*)f_953},
{"f_4800chicken.scm",(void*)f_4800},
{"f_4804chicken.scm",(void*)f_4804},
{"f_4807chicken.scm",(void*)f_4807},
{"f_4810chicken.scm",(void*)f_4810},
{"f_4823chicken.scm",(void*)f_4823},
{"f_4873chicken.scm",(void*)f_4873},
{"f_4884chicken.scm",(void*)f_4884},
{"f_4821chicken.scm",(void*)f_4821},
{"f_956chicken.scm",(void*)f_956},
{"f_4524chicken.scm",(void*)f_4524},
{"f_4558chicken.scm",(void*)f_4558},
{"f_4561chicken.scm",(void*)f_4561},
{"f_4787chicken.scm",(void*)f_4787},
{"f_4797chicken.scm",(void*)f_4797},
{"f_4785chicken.scm",(void*)f_4785},
{"f_4564chicken.scm",(void*)f_4564},
{"f_4533chicken.scm",(void*)f_4533},
{"f_4547chicken.scm",(void*)f_4547},
{"f_4551chicken.scm",(void*)f_4551},
{"f_4567chicken.scm",(void*)f_4567},
{"f_4570chicken.scm",(void*)f_4570},
{"f_4573chicken.scm",(void*)f_4573},
{"f_4580chicken.scm",(void*)f_4580},
{"f_4594chicken.scm",(void*)f_4594},
{"f_4604chicken.scm",(void*)f_4604},
{"f_4608chicken.scm",(void*)f_4608},
{"f_4618chicken.scm",(void*)f_4618},
{"f_4634chicken.scm",(void*)f_4634},
{"f_4653chicken.scm",(void*)f_4653},
{"f_4709chicken.scm",(void*)f_4709},
{"f_4720chicken.scm",(void*)f_4720},
{"f_4638chicken.scm",(void*)f_4638},
{"f_4651chicken.scm",(void*)f_4651},
{"f_4624chicken.scm",(void*)f_4624},
{"f_4632chicken.scm",(void*)f_4632},
{"f_4622chicken.scm",(void*)f_4622},
{"f_4592chicken.scm",(void*)f_4592},
{"f_959chicken.scm",(void*)f_959},
{"f_4467chicken.scm",(void*)f_4467},
{"f_4507chicken.scm",(void*)f_4507},
{"f_4477chicken.scm",(void*)f_4477},
{"f_962chicken.scm",(void*)f_962},
{"f_4391chicken.scm",(void*)f_4391},
{"f_4395chicken.scm",(void*)f_4395},
{"f_4398chicken.scm",(void*)f_4398},
{"f_965chicken.scm",(void*)f_965},
{"f_4207chicken.scm",(void*)f_4207},
{"f_4211chicken.scm",(void*)f_4211},
{"f_4214chicken.scm",(void*)f_4214},
{"f_4357chicken.scm",(void*)f_4357},
{"f_4353chicken.scm",(void*)f_4353},
{"f_4216chicken.scm",(void*)f_4216},
{"f_4304chicken.scm",(void*)f_4304},
{"f_4302chicken.scm",(void*)f_4302},
{"f_4272chicken.scm",(void*)f_4272},
{"f_4239chicken.scm",(void*)f_4239},
{"f_968chicken.scm",(void*)f_968},
{"f_4017chicken.scm",(void*)f_4017},
{"f_4024chicken.scm",(void*)f_4024},
{"f_4198chicken.scm",(void*)f_4198},
{"f_4196chicken.scm",(void*)f_4196},
{"f_4049chicken.scm",(void*)f_4049},
{"f_4075chicken.scm",(void*)f_4075},
{"f_4103chicken.scm",(void*)f_4103},
{"f_4087chicken.scm",(void*)f_4087},
{"f_4047chicken.scm",(void*)f_4047},
{"f_971chicken.scm",(void*)f_971},
{"f_4008chicken.scm",(void*)f_4008},
{"f_4012chicken.scm",(void*)f_4012},
{"f_974chicken.scm",(void*)f_974},
{"f_3989chicken.scm",(void*)f_3989},
{"f_3993chicken.scm",(void*)f_3993},
{"f_4002chicken.scm",(void*)f_4002},
{"f_4000chicken.scm",(void*)f_4000},
{"f_977chicken.scm",(void*)f_977},
{"f_3970chicken.scm",(void*)f_3970},
{"f_3974chicken.scm",(void*)f_3974},
{"f_3983chicken.scm",(void*)f_3983},
{"f_3981chicken.scm",(void*)f_3981},
{"f_980chicken.scm",(void*)f_980},
{"f_3842chicken.scm",(void*)f_3842},
{"f_3848chicken.scm",(void*)f_3848},
{"f_3929chicken.scm",(void*)f_3929},
{"f_3858chicken.scm",(void*)f_3858},
{"f_3861chicken.scm",(void*)f_3861},
{"f_3867chicken.scm",(void*)f_3867},
{"f_3874chicken.scm",(void*)f_3874},
{"f_3890chicken.scm",(void*)f_3890},
{"f_983chicken.scm",(void*)f_983},
{"f_3699chicken.scm",(void*)f_3699},
{"f_3705chicken.scm",(void*)f_3705},
{"f_3817chicken.scm",(void*)f_3817},
{"f_3790chicken.scm",(void*)f_3790},
{"f_3715chicken.scm",(void*)f_3715},
{"f_3718chicken.scm",(void*)f_3718},
{"f_3724chicken.scm",(void*)f_3724},
{"f_3735chicken.scm",(void*)f_3735},
{"f_3751chicken.scm",(void*)f_3751},
{"f_986chicken.scm",(void*)f_986},
{"f_3640chicken.scm",(void*)f_3640},
{"f_989chicken.scm",(void*)f_989},
{"f_3469chicken.scm",(void*)f_3469},
{"f_3475chicken.scm",(void*)f_3475},
{"f_3549chicken.scm",(void*)f_3549},
{"f_3552chicken.scm",(void*)f_3552},
{"f_3625chicken.scm",(void*)f_3625},
{"f_3618chicken.scm",(void*)f_3618},
{"f_3610chicken.scm",(void*)f_3610},
{"f_3597chicken.scm",(void*)f_3597},
{"f_3576chicken.scm",(void*)f_3576},
{"f_3485chicken.scm",(void*)f_3485},
{"f_992chicken.scm",(void*)f_992},
{"f_3418chicken.scm",(void*)f_3418},
{"f_995chicken.scm",(void*)f_995},
{"f_3358chicken.scm",(void*)f_3358},
{"f_3368chicken.scm",(void*)f_3368},
{"f_3387chicken.scm",(void*)f_3387},
{"f_3371chicken.scm",(void*)f_3371},
{"f_998chicken.scm",(void*)f_998},
{"f_1001chicken.scm",(void*)f_1001},
{"f_3321chicken.scm",(void*)f_3321},
{"f_3325chicken.scm",(void*)f_3325},
{"f_1004chicken.scm",(void*)f_1004},
{"f_3302chicken.scm",(void*)f_3302},
{"f_3306chicken.scm",(void*)f_3306},
{"f_3315chicken.scm",(void*)f_3315},
{"f_3313chicken.scm",(void*)f_3313},
{"f_1007chicken.scm",(void*)f_1007},
{"f_3283chicken.scm",(void*)f_3283},
{"f_3287chicken.scm",(void*)f_3287},
{"f_3296chicken.scm",(void*)f_3296},
{"f_3294chicken.scm",(void*)f_3294},
{"f_1010chicken.scm",(void*)f_1010},
{"f_3264chicken.scm",(void*)f_3264},
{"f_3268chicken.scm",(void*)f_3268},
{"f_3277chicken.scm",(void*)f_3277},
{"f_3275chicken.scm",(void*)f_3275},
{"f_1013chicken.scm",(void*)f_1013},
{"f_3245chicken.scm",(void*)f_3245},
{"f_3249chicken.scm",(void*)f_3249},
{"f_3258chicken.scm",(void*)f_3258},
{"f_3256chicken.scm",(void*)f_3256},
{"f_1016chicken.scm",(void*)f_1016},
{"f_3226chicken.scm",(void*)f_3226},
{"f_3230chicken.scm",(void*)f_3230},
{"f_3239chicken.scm",(void*)f_3239},
{"f_3237chicken.scm",(void*)f_3237},
{"f_1019chicken.scm",(void*)f_1019},
{"f_3207chicken.scm",(void*)f_3207},
{"f_3211chicken.scm",(void*)f_3211},
{"f_3220chicken.scm",(void*)f_3220},
{"f_3218chicken.scm",(void*)f_3218},
{"f_1022chicken.scm",(void*)f_1022},
{"f_3107chicken.scm",(void*)f_3107},
{"f_3111chicken.scm",(void*)f_3111},
{"f_3166chicken.scm",(void*)f_3166},
{"f_3120chicken.scm",(void*)f_3120},
{"f_1025chicken.scm",(void*)f_1025},
{"f_2887chicken.scm",(void*)f_2887},
{"f_2891chicken.scm",(void*)f_2891},
{"f_2894chicken.scm",(void*)f_2894},
{"f_2975chicken.scm",(void*)f_2975},
{"f_3042chicken.scm",(void*)f_3042},
{"f_3040chicken.scm",(void*)f_3040},
{"f_3032chicken.scm",(void*)f_3032},
{"f_3020chicken.scm",(void*)f_3020},
{"f_2900chicken.scm",(void*)f_2900},
{"f_2926chicken.scm",(void*)f_2926},
{"f_1028chicken.scm",(void*)f_1028},
{"f_2812chicken.scm",(void*)f_2812},
{"f_2816chicken.scm",(void*)f_2816},
{"f_2885chicken.scm",(void*)f_2885},
{"f_2839chicken.scm",(void*)f_2839},
{"f_1031chicken.scm",(void*)f_1031},
{"f_2706chicken.scm",(void*)f_2706},
{"f_2806chicken.scm",(void*)f_2806},
{"f_2710chicken.scm",(void*)f_2710},
{"f_2782chicken.scm",(void*)f_2782},
{"f_2717chicken.scm",(void*)f_2717},
{"f_2723chicken.scm",(void*)f_2723},
{"f_2721chicken.scm",(void*)f_2721},
{"f_1034chicken.scm",(void*)f_1034},
{"f_2677chicken.scm",(void*)f_2677},
{"f_2681chicken.scm",(void*)f_2681},
{"f_2704chicken.scm",(void*)f_2704},
{"f_2700chicken.scm",(void*)f_2700},
{"f_1037chicken.scm",(void*)f_1037},
{"f_2664chicken.scm",(void*)f_2664},
{"f_2668chicken.scm",(void*)f_2668},
{"f_1040chicken.scm",(void*)f_1040},
{"f_1870chicken.scm",(void*)f_1870},
{"f_1874chicken.scm",(void*)f_1874},
{"f_1880chicken.scm",(void*)f_1880},
{"f_1883chicken.scm",(void*)f_1883},
{"f_1886chicken.scm",(void*)f_1886},
{"f_1889chicken.scm",(void*)f_1889},
{"f_2556chicken.scm",(void*)f_2556},
{"f_2635chicken.scm",(void*)f_2635},
{"f_2631chicken.scm",(void*)f_2631},
{"f_2566chicken.scm",(void*)f_2566},
{"f_2570chicken.scm",(void*)f_2570},
{"f_2611chicken.scm",(void*)f_2611},
{"f_2601chicken.scm",(void*)f_2601},
{"f_2591chicken.scm",(void*)f_2591},
{"f_2587chicken.scm",(void*)f_2587},
{"f_2573chicken.scm",(void*)f_2573},
{"f_1977chicken.scm",(void*)f_1977},
{"f_1980chicken.scm",(void*)f_1980},
{"f_2550chicken.scm",(void*)f_2550},
{"f_2479chicken.scm",(void*)f_2479},
{"f_2485chicken.scm",(void*)f_2485},
{"f_2539chicken.scm",(void*)f_2539},
{"f_2531chicken.scm",(void*)f_2531},
{"f_2514chicken.scm",(void*)f_2514},
{"f_2502chicken.scm",(void*)f_2502},
{"f_2483chicken.scm",(void*)f_2483},
{"f_2467chicken.scm",(void*)f_2467},
{"f_2463chicken.scm",(void*)f_2463},
{"f_1991chicken.scm",(void*)f_1991},
{"f_2445chicken.scm",(void*)f_2445},
{"f_1999chicken.scm",(void*)f_1999},
{"f_2007chicken.scm",(void*)f_2007},
{"f_2013chicken.scm",(void*)f_2013},
{"f_2290chicken.scm",(void*)f_2290},
{"f_2402chicken.scm",(void*)f_2402},
{"f_2398chicken.scm",(void*)f_2398},
{"f_2367chicken.scm",(void*)f_2367},
{"f_2390chicken.scm",(void*)f_2390},
{"f_2379chicken.scm",(void*)f_2379},
{"f_2308chicken.scm",(void*)f_2308},
{"f_2353chicken.scm",(void*)f_2353},
{"f_2349chicken.scm",(void*)f_2349},
{"f_2325chicken.scm",(void*)f_2325},
{"f_2337chicken.scm",(void*)f_2337},
{"f_2305chicken.scm",(void*)f_2305},
{"f_2035chicken.scm",(void*)f_2035},
{"f_2275chicken.scm",(void*)f_2275},
{"f_2271chicken.scm",(void*)f_2271},
{"f_2176chicken.scm",(void*)f_2176},
{"f_2259chicken.scm",(void*)f_2259},
{"f_2248chicken.scm",(void*)f_2248},
{"f_2053chicken.scm",(void*)f_2053},
{"f_2162chicken.scm",(void*)f_2162},
{"f_2158chicken.scm",(void*)f_2158},
{"f_2070chicken.scm",(void*)f_2070},
{"f_2142chicken.scm",(void*)f_2142},
{"f_2050chicken.scm",(void*)f_2050},
{"f_2011chicken.scm",(void*)f_2011},
{"f_2003chicken.scm",(void*)f_2003},
{"f_1995chicken.scm",(void*)f_1995},
{"f_1987chicken.scm",(void*)f_1987},
{"f_1934chicken.scm",(void*)f_1934},
{"f_1950chicken.scm",(void*)f_1950},
{"f_1891chicken.scm",(void*)f_1891},
{"f_1043chicken.scm",(void*)f_1043},
{"f_1856chicken.scm",(void*)f_1856},
{"f_1046chicken.scm",(void*)f_1046},
{"f_1516chicken.scm",(void*)f_1516},
{"f_1520chicken.scm",(void*)f_1520},
{"f_1523chicken.scm",(void*)f_1523},
{"f_1828chicken.scm",(void*)f_1828},
{"f_1526chicken.scm",(void*)f_1526},
{"f_1803chicken.scm",(void*)f_1803},
{"f_1529chicken.scm",(void*)f_1529},
{"f_1771chicken.scm",(void*)f_1771},
{"f_1532chicken.scm",(void*)f_1532},
{"f_1745chicken.scm",(void*)f_1745},
{"f_1535chicken.scm",(void*)f_1535},
{"f_1538chicken.scm",(void*)f_1538},
{"f_1733chicken.scm",(void*)f_1733},
{"f_1541chicken.scm",(void*)f_1541},
{"f_1729chicken.scm",(void*)f_1729},
{"f_1544chicken.scm",(void*)f_1544},
{"f_1717chicken.scm",(void*)f_1717},
{"f_1725chicken.scm",(void*)f_1725},
{"f_1555chicken.scm",(void*)f_1555},
{"f_1679chicken.scm",(void*)f_1679},
{"f_1661chicken.scm",(void*)f_1661},
{"f_1657chicken.scm",(void*)f_1657},
{"f_1597chicken.scm",(void*)f_1597},
{"f_1587chicken.scm",(void*)f_1587},
{"f_1583chicken.scm",(void*)f_1583},
{"f_1551chicken.scm",(void*)f_1551},
{"f_1049chicken.scm",(void*)f_1049},
{"f_1482chicken.scm",(void*)f_1482},
{"f_1052chicken.scm",(void*)f_1052},
{"f_1420chicken.scm",(void*)f_1420},
{"f_1433chicken.scm",(void*)f_1433},
{"f_1459chicken.scm",(void*)f_1459},
{"f_1430chicken.scm",(void*)f_1430},
{"f_1423chicken.scm",(void*)f_1423},
{"f_1055chicken.scm",(void*)f_1055},
{"f_1418chicken.scm",(void*)f_1418},
{"f_1411chicken.scm",(void*)f_1411},
{"f_1407chicken.scm",(void*)f_1407},
{"f_1399chicken.scm",(void*)f_1399},
{"f_1397chicken.scm",(void*)f_1397},
{"f_1059chicken.scm",(void*)f_1059},
{"f_1188chicken.scm",(void*)f_1188},
{"f_1200chicken.scm",(void*)f_1200},
{"f_1383chicken.scm",(void*)f_1383},
{"f_1376chicken.scm",(void*)f_1376},
{"f_1339chicken.scm",(void*)f_1339},
{"f_1285chicken.scm",(void*)f_1285},
{"f_1302chicken.scm",(void*)f_1302},
{"f_1288chicken.scm",(void*)f_1288},
{"f_1222chicken.scm",(void*)f_1222},
{"f_1265chicken.scm",(void*)f_1265},
{"f_1245chicken.scm",(void*)f_1245},
{"f_1225chicken.scm",(void*)f_1225},
{"f_1192chicken.scm",(void*)f_1192},
{"f_1195chicken.scm",(void*)f_1195},
{"f_1176chicken.scm",(void*)f_1176},
{"f_1183chicken.scm",(void*)f_1183},
{"f_1168chicken.scm",(void*)f_1168},
{"f_1174chicken.scm",(void*)f_1174},
{"f_1171chicken.scm",(void*)f_1171},
{"f_1061chicken.scm",(void*)f_1061},
{"f_1067chicken.scm",(void*)f_1067},
{"f_1102chicken.scm",(void*)f_1102},
{"f_1128chicken.scm",(void*)f_1128},
{"f_1124chicken.scm",(void*)f_1124},
{"f_1081chicken.scm",(void*)f_1081},
{"f_765chicken.scm",(void*)f_765},
{"f_769chicken.scm",(void*)f_769},
{"f_806chicken.scm",(void*)f_806},
{"f_827chicken.scm",(void*)f_827},
{"f_825chicken.scm",(void*)f_825},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
