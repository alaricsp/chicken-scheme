/* Generated from chicken.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-01-18 12:14
   Version 3.0.0rc1 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook lockts ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-01-17 on dill (Linux)
   command line: chicken.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -extend private-namespace.scm -output-file chicken.c
   used units: library eval extras srfi_1 match srfi_4 utils support compiler optimizer driver platform backend
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_match_toplevel)
C_externimport void C_ccall C_match_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_4_toplevel)
C_externimport void C_ccall C_srfi_4_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_support_toplevel)
C_externimport void C_ccall C_support_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_compiler_toplevel)
C_externimport void C_ccall C_compiler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_optimizer_toplevel)
C_externimport void C_ccall C_optimizer_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_driver_toplevel)
C_externimport void C_ccall C_driver_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_platform_toplevel)
C_externimport void C_ccall C_platform_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_backend_toplevel)
C_externimport void C_ccall C_backend_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[383];


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_709)
static void C_ccall f_709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_712)
static void C_ccall f_712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_715)
static void C_ccall f_715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_718)
static void C_ccall f_718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_721)
static void C_ccall f_721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_724)
static void C_ccall f_724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_727)
static void C_ccall f_727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_730)
static void C_ccall f_730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_733)
static void C_ccall f_733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_736)
static void C_ccall f_736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_739)
static void C_ccall f_739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_742)
static void C_ccall f_742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_745)
static void C_ccall f_745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_751)
static void C_ccall f_751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7178)
static void C_ccall f_7178(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7178)
static void C_ccall f_7178r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7182)
static void C_ccall f_7182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7185)
static void C_ccall f_7185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7188)
static void C_ccall f_7188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7194)
static void C_ccall f_7194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7400)
static void C_ccall f_7400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7380)
static void C_ccall f_7380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7376)
static void C_ccall f_7376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7356)
static void C_ccall f_7356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7219)
static void C_fcall f_7219(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7229)
static void C_ccall f_7229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7348)
static void C_ccall f_7348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7232)
static void C_ccall f_7232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7344)
static void C_ccall f_7344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7235)
static void C_ccall f_7235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7266)
static void C_fcall f_7266(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7246)
static void C_ccall f_7246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7217)
static void C_ccall f_7217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_754)
static void C_ccall f_754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7090)
static void C_ccall f_7090(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7090)
static void C_ccall f_7090r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7107)
static void C_ccall f_7107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7110)
static void C_ccall f_7110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7116)
static void C_fcall f_7116(C_word t0,C_word t1) C_noret;
C_noret_decl(f_757)
static void C_ccall f_757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7049)
static void C_ccall f_7049(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7049)
static void C_ccall f_7049r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7053)
static void C_ccall f_7053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_760)
static void C_ccall f_760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7033)
static void C_ccall f_7033(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7033)
static void C_ccall f_7033r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7043)
static void C_ccall f_7043(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7041)
static void C_ccall f_7041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_763)
static void C_ccall f_763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6956)
static void C_ccall f_6956(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6960)
static void C_ccall f_6960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7028)
static void C_ccall f_7028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6963)
static void C_ccall f_6963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6972)
static void C_ccall f_6972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7019)
static void C_ccall f_7019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6986)
static void C_ccall f_6986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6994)
static void C_ccall f_6994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6996)
static void C_fcall f_6996(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7013)
static void C_ccall f_7013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6978)
static void C_ccall f_6978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6970)
static void C_ccall f_6970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_766)
static void C_ccall f_766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6896)
static void C_ccall f_6896(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6896)
static void C_ccall f_6896r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6900)
static void C_fcall f_6900(C_word t0,C_word t1) C_noret;
C_noret_decl(f_769)
static void C_ccall f_769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6837)
static void C_ccall f_6837(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6837)
static void C_ccall f_6837r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6841)
static void C_ccall f_6841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6868)
static void C_fcall f_6868(C_word t0,C_word t1) C_noret;
C_noret_decl(f_772)
static void C_ccall f_772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6663)
static void C_ccall f_6663(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6663)
static void C_ccall f_6663r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6667)
static void C_ccall f_6667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6670)
static void C_ccall f_6670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6831)
static void C_ccall f_6831(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6673)
static void C_ccall f_6673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6825)
static void C_ccall f_6825(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6676)
static void C_ccall f_6676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6823)
static void C_ccall f_6823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6787)
static void C_ccall f_6787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6801)
static void C_fcall f_6801(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6815)
static void C_ccall f_6815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6795)
static void C_ccall f_6795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6791)
static void C_ccall f_6791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6683)
static void C_ccall f_6683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6779)
static void C_ccall f_6779(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6755)
static void C_ccall f_6755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6773)
static void C_ccall f_6773(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6763)
static void C_ccall f_6763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6759)
static void C_ccall f_6759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6751)
static void C_ccall f_6751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6735)
static void C_ccall f_6735(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6711)
static void C_ccall f_6711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6729)
static void C_ccall f_6729(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6719)
static void C_ccall f_6719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6715)
static void C_ccall f_6715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6707)
static void C_ccall f_6707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_775)
static void C_ccall f_775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6568)
static void C_ccall f_6568(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6568)
static void C_ccall f_6568r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6604)
static void C_fcall f_6604(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6617)
static void C_ccall f_6617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6575)
static void C_ccall f_6575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_778)
static void C_ccall f_778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6458)
static void C_ccall f_6458(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6458)
static void C_ccall f_6458r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6462)
static void C_ccall f_6462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6465)
static void C_ccall f_6465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6468)
static void C_ccall f_6468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6471)
static void C_ccall f_6471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6562)
static void C_ccall f_6562(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6474)
static void C_ccall f_6474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6556)
static void C_ccall f_6556(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6477)
static void C_ccall f_6477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6550)
static void C_ccall f_6550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6554)
static void C_ccall f_6554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6484)
static void C_ccall f_6484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6522)
static void C_ccall f_6522(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6520)
static void C_ccall f_6520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_781)
static void C_ccall f_781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6448)
static void C_ccall f_6448(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6448)
static void C_ccall f_6448r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_784)
static void C_ccall f_784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6434)
static void C_ccall f_6434(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6434)
static void C_ccall f_6434r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_787)
static void C_ccall f_787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_861)
static void C_ccall f_861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_864)
static void C_ccall f_864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6172)
static void C_ccall f_6172(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6176)
static void C_ccall f_6176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6185)
static void C_ccall f_6185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6394)
static void C_fcall f_6394(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6407)
static void C_ccall f_6407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6188)
static void C_ccall f_6188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6384)
static void C_ccall f_6384(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6392)
static void C_ccall f_6392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6191)
static void C_ccall f_6191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6338)
static void C_fcall f_6338(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6371)
static void C_ccall f_6371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6378)
static void C_ccall f_6378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6354)
static void C_fcall f_6354(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6203)
static void C_ccall f_6203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6332)
static void C_ccall f_6332(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6210)
static void C_ccall f_6210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6212)
static void C_fcall f_6212(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6326)
static void C_ccall f_6326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6246)
static void C_fcall f_6246(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6300)
static void C_ccall f_6300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6277)
static void C_ccall f_6277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6257)
static void C_ccall f_6257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6232)
static void C_ccall f_6232(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6240)
static void C_ccall f_6240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6230)
static void C_ccall f_6230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6192)
static void C_ccall f_6192(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6132)
static void C_fcall f_6132(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6155)
static void C_ccall f_6155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6159)
static void C_ccall f_6159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6101)
static void C_fcall f_6101(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6122)
static void C_ccall f_6122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_867)
static void C_ccall f_867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6050)
static void C_ccall f_6050(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6054)
static void C_ccall f_6054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6065)
static void C_fcall f_6065(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6090)
static void C_ccall f_6090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_870)
static void C_ccall f_870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5930)
static void C_ccall f_5930(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5934)
static void C_ccall f_5934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6044)
static void C_ccall f_6044(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6042)
static void C_ccall f_6042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5943)
static void C_ccall f_5943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6030)
static void C_ccall f_6030(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6038)
static void C_ccall f_6038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5946)
static void C_ccall f_5946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6024)
static void C_ccall f_6024(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5966)
static void C_ccall f_5966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5976)
static void C_ccall f_5976(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5996)
static void C_ccall f_5996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6002)
static void C_ccall f_6002(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6010)
static void C_ccall f_6010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6000)
static void C_ccall f_6000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5974)
static void C_ccall f_5974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5970)
static void C_ccall f_5970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5947)
static void C_ccall f_5947(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_873)
static void C_ccall f_873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5909)
static void C_ccall f_5909(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5913)
static void C_ccall f_5913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_876)
static void C_ccall f_876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5899)
static void C_ccall f_5899(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_882)
static void C_ccall f_882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_891)
static void C_fcall f_891(C_word t0,C_word t1) C_noret;
C_noret_decl(f_907)
static void C_fcall f_907(C_word t0,C_word t1) C_noret;
C_noret_decl(f_894)
static void C_ccall f_894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_955)
static void C_ccall f_955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5878)
static void C_ccall f_5878(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5882)
static void C_ccall f_5882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_958)
static void C_ccall f_958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5762)
static void C_ccall f_5762(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5766)
static void C_ccall f_5766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5775)
static void C_fcall f_5775(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5789)
static void C_fcall f_5789(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5853)
static void C_ccall f_5853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5835)
static void C_ccall f_5835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5818)
static void C_ccall f_5818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_961)
static void C_ccall f_961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5516)
static void C_ccall f_5516(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5671)
static void C_fcall f_5671(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5742)
static void C_ccall f_5742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5687)
static void C_ccall f_5687(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5685)
static void C_ccall f_5685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5529)
static void C_fcall f_5529(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5655)
static void C_ccall f_5655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5617)
static void C_ccall f_5617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5578)
static void C_ccall f_5578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5519)
static void C_fcall f_5519(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_964)
static void C_ccall f_964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5417)
static void C_ccall f_5417(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5427)
static void C_ccall f_5427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5440)
static void C_fcall f_5440(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5456)
static void C_ccall f_5456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5494)
static void C_ccall f_5494(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5492)
static void C_ccall f_5492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5484)
static void C_ccall f_5484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5438)
static void C_ccall f_5438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_967)
static void C_ccall f_967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5328)
static void C_ccall f_5328(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5338)
static void C_ccall f_5338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5351)
static void C_fcall f_5351(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5367)
static void C_ccall f_5367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5395)
static void C_ccall f_5395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5349)
static void C_ccall f_5349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_970)
static void C_ccall f_970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5042)
static void C_ccall f_5042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5042)
static void C_ccall f_5042r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5239)
static void C_ccall f_5239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5242)
static void C_ccall f_5242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5245)
static void C_ccall f_5245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5318)
static void C_ccall f_5318(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5326)
static void C_ccall f_5326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5261)
static void C_ccall f_5261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5264)
static void C_ccall f_5264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5267)
static void C_ccall f_5267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5270)
static void C_ccall f_5270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5308)
static void C_ccall f_5308(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5316)
static void C_ccall f_5316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5273)
static void C_ccall f_5273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5053)
static void C_ccall f_5053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5057)
static void C_ccall f_5057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5061)
static void C_ccall f_5061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5063)
static void C_fcall f_5063(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5108)
static void C_ccall f_5108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5120)
static void C_ccall f_5120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5116)
static void C_ccall f_5116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5084)
static void C_ccall f_5084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5276)
static void C_ccall f_5276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5136)
static void C_fcall f_5136(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5236)
static void C_ccall f_5236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5200)
static void C_ccall f_5200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5170)
static void C_ccall f_5170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5279)
static void C_ccall f_5279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5246)
static void C_fcall f_5246(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5258)
static void C_ccall f_5258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5254)
static void C_ccall f_5254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_973)
static void C_ccall f_973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4985)
static void C_ccall f_4985(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4989)
static void C_ccall f_4989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_976)
static void C_ccall f_976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4979)
static void C_ccall f_4979(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_979)
static void C_ccall f_979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4826)
static void C_ccall f_4826(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4826)
static void C_ccall f_4826r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4830)
static void C_ccall f_4830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4833)
static void C_ccall f_4833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4836)
static void C_ccall f_4836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4849)
static void C_fcall f_4849(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4899)
static void C_ccall f_4899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4910)
static void C_ccall f_4910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4847)
static void C_ccall f_4847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_982)
static void C_ccall f_982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4550)
static void C_ccall f_4550(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4584)
static void C_ccall f_4584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4587)
static void C_ccall f_4587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4813)
static void C_ccall f_4813(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4823)
static void C_ccall f_4823(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4811)
static void C_ccall f_4811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4590)
static void C_ccall f_4590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4559)
static void C_fcall f_4559(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4573)
static void C_ccall f_4573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4577)
static void C_ccall f_4577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4593)
static void C_ccall f_4593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4596)
static void C_ccall f_4596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4599)
static void C_ccall f_4599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4606)
static void C_ccall f_4606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4620)
static void C_ccall f_4620(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4630)
static void C_ccall f_4630(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4634)
static void C_ccall f_4634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4644)
static void C_fcall f_4644(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4660)
static void C_ccall f_4660(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4679)
static void C_fcall f_4679(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4735)
static void C_ccall f_4735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4746)
static void C_ccall f_4746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4664)
static void C_ccall f_4664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4677)
static void C_ccall f_4677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4650)
static void C_ccall f_4650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4658)
static void C_ccall f_4658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4648)
static void C_ccall f_4648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4618)
static void C_ccall f_4618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_985)
static void C_ccall f_985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4493)
static void C_ccall f_4493(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4493)
static void C_ccall f_4493r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4533)
static void C_ccall f_4533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4503)
static void C_ccall f_4503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_988)
static void C_ccall f_988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4417)
static void C_ccall f_4417(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4417)
static void C_ccall f_4417r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4421)
static void C_ccall f_4421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4424)
static void C_ccall f_4424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_991)
static void C_ccall f_991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4233)
static void C_ccall f_4233(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4233)
static void C_ccall f_4233r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4237)
static void C_ccall f_4237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4240)
static void C_ccall f_4240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4383)
static void C_ccall f_4383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4379)
static void C_ccall f_4379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4242)
static void C_ccall f_4242(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4330)
static void C_ccall f_4330(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4328)
static void C_ccall f_4328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4298)
static void C_fcall f_4298(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4265)
static void C_fcall f_4265(C_word t0,C_word t1) C_noret;
C_noret_decl(f_994)
static void C_ccall f_994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4043)
static void C_ccall f_4043(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_4043)
static void C_ccall f_4043r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_4050)
static void C_ccall f_4050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4224)
static void C_ccall f_4224(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4222)
static void C_ccall f_4222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4075)
static void C_fcall f_4075(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4101)
static void C_fcall f_4101(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4129)
static void C_fcall f_4129(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4113)
static void C_ccall f_4113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4073)
static void C_ccall f_4073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_997)
static void C_ccall f_997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4034)
static void C_ccall f_4034(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4038)
static void C_ccall f_4038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1000)
static void C_ccall f_1000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4015)
static void C_ccall f_4015(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4019)
static void C_ccall f_4019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4028)
static void C_ccall f_4028(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4026)
static void C_ccall f_4026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1003)
static void C_ccall f_1003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3996)
static void C_ccall f_3996(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4000)
static void C_ccall f_4000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4007)
static void C_ccall f_4007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1006)
static void C_ccall f_1006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3868)
static void C_ccall f_3868(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3874)
static void C_fcall f_3874(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3955)
static void C_ccall f_3955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3884)
static void C_ccall f_3884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3887)
static void C_ccall f_3887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3893)
static void C_ccall f_3893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3900)
static void C_ccall f_3900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3916)
static void C_ccall f_3916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1009)
static void C_ccall f_1009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3725)
static void C_ccall f_3725(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3731)
static void C_fcall f_3731(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3843)
static void C_ccall f_3843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3816)
static void C_ccall f_3816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3741)
static void C_ccall f_3741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3744)
static void C_ccall f_3744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3750)
static void C_ccall f_3750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3761)
static void C_ccall f_3761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3777)
static void C_ccall f_3777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1012)
static void C_ccall f_1012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3666)
static void C_ccall f_3666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_3666)
static void C_ccall f_3666r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_1015)
static void C_ccall f_1015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3495)
static void C_ccall f_3495(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3495)
static void C_ccall f_3495r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3501)
static void C_fcall f_3501(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3575)
static void C_fcall f_3575(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3578)
static void C_ccall f_3578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3651)
static void C_ccall f_3651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3644)
static void C_ccall f_3644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3636)
static void C_ccall f_3636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3623)
static void C_ccall f_3623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3602)
static void C_ccall f_3602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3511)
static void C_fcall f_3511(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1018)
static void C_ccall f_1018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3444)
static void C_ccall f_3444(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3444)
static void C_ccall f_3444r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1021)
static void C_ccall f_1021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3384)
static void C_ccall f_3384(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3384)
static void C_ccall f_3384r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3394)
static void C_fcall f_3394(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3413)
static void C_ccall f_3413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3397)
static void C_ccall f_3397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1024)
static void C_ccall f_1024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1027)
static void C_ccall f_1027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3347)
static void C_ccall f_3347(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3351)
static void C_ccall f_3351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1030)
static void C_ccall f_1030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3328)
static void C_ccall f_3328(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3332)
static void C_ccall f_3332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3341)
static void C_ccall f_3341(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3339)
static void C_ccall f_3339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1033)
static void C_ccall f_1033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3309)
static void C_ccall f_3309(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3313)
static void C_ccall f_3313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3322)
static void C_ccall f_3322(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3320)
static void C_ccall f_3320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1036)
static void C_ccall f_1036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3290)
static void C_ccall f_3290(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3294)
static void C_ccall f_3294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3303)
static void C_ccall f_3303(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3301)
static void C_ccall f_3301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1039)
static void C_ccall f_1039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3271)
static void C_ccall f_3271(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3275)
static void C_ccall f_3275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3284)
static void C_ccall f_3284(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3282)
static void C_ccall f_3282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1042)
static void C_ccall f_1042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3252)
static void C_ccall f_3252(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3256)
static void C_ccall f_3256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3265)
static void C_ccall f_3265(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3263)
static void C_ccall f_3263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1045)
static void C_ccall f_1045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3233)
static void C_ccall f_3233(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3237)
static void C_ccall f_3237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3246)
static void C_ccall f_3246(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3244)
static void C_ccall f_3244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1048)
static void C_ccall f_1048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3137)
static void C_ccall f_3137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3192)
static void C_ccall f_3192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3146)
static void C_ccall f_3146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1051)
static void C_ccall f_1051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2913)
static void C_ccall f_2913(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2917)
static void C_fcall f_2917(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2920)
static void C_fcall f_2920(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3001)
static void C_ccall f_3001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3068)
static void C_ccall f_3068(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3066)
static void C_ccall f_3066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3058)
static void C_ccall f_3058(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2926)
static void C_ccall f_2926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2952)
static void C_fcall f_2952(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1054)
static void C_ccall f_1054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2911)
static void C_ccall f_2911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2865)
static void C_fcall f_2865(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1057)
static void C_ccall f_1057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2732)
static void C_ccall f_2732(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2732)
static void C_ccall f_2732r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2832)
static void C_ccall f_2832(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2736)
static void C_ccall f_2736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2808)
static void C_ccall f_2808(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2743)
static void C_ccall f_2743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2749)
static void C_ccall f_2749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2747)
static void C_ccall f_2747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1060)
static void C_ccall f_1060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2703)
static void C_ccall f_2703(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2707)
static void C_ccall f_2707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2730)
static void C_ccall f_2730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2726)
static void C_ccall f_2726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1063)
static void C_ccall f_1063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2690)
static void C_ccall f_2690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2694)
static void C_ccall f_2694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1066)
static void C_ccall f_1066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1896)
static void C_ccall f_1896(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1896)
static void C_ccall f_1896r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1909)
static void C_ccall f_1909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1912)
static void C_ccall f_1912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1915)
static void C_ccall f_1915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2582)
static void C_fcall f_2582(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2661)
static void C_ccall f_2661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2657)
static void C_ccall f_2657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2592)
static void C_fcall f_2592(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2596)
static void C_ccall f_2596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2637)
static void C_ccall f_2637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2627)
static void C_ccall f_2627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2617)
static void C_ccall f_2617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2613)
static void C_ccall f_2613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2599)
static void C_ccall f_2599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2003)
static void C_ccall f_2003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2006)
static void C_ccall f_2006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2576)
static void C_ccall f_2576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2511)
static void C_ccall f_2511(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2565)
static void C_ccall f_2565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2557)
static void C_ccall f_2557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2540)
static void C_ccall f_2540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2528)
static void C_ccall f_2528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2509)
static void C_ccall f_2509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2493)
static void C_ccall f_2493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2489)
static void C_ccall f_2489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2017)
static void C_fcall f_2017(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2471)
static void C_ccall f_2471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2025)
static void C_fcall f_2025(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2033)
static void C_fcall f_2033(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2039)
static void C_ccall f_2039(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2316)
static void C_ccall f_2316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2428)
static void C_ccall f_2428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2424)
static void C_ccall f_2424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2393)
static void C_ccall f_2393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2416)
static void C_ccall f_2416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2405)
static void C_ccall f_2405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2334)
static void C_fcall f_2334(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2379)
static void C_ccall f_2379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2375)
static void C_ccall f_2375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2351)
static void C_ccall f_2351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2363)
static void C_ccall f_2363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2331)
static void C_fcall f_2331(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2061)
static void C_ccall f_2061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2301)
static void C_ccall f_2301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2202)
static void C_ccall f_2202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2285)
static void C_ccall f_2285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2274)
static void C_ccall f_2274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2079)
static void C_fcall f_2079(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2188)
static void C_ccall f_2188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2184)
static void C_ccall f_2184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2096)
static void C_ccall f_2096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2076)
static void C_fcall f_2076(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2037)
static void C_ccall f_2037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2029)
static void C_ccall f_2029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2021)
static void C_ccall f_2021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2013)
static void C_ccall f_2013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1960)
static void C_fcall f_1960(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1976)
static void C_ccall f_1976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1917)
static void C_fcall f_1917(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1069)
static void C_ccall f_1069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1882)
static void C_ccall f_1882(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1072)
static void C_ccall f_1072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1542)
static void C_ccall f_1542(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1542)
static void C_ccall f_1542r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1546)
static void C_fcall f_1546(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1549)
static void C_ccall f_1549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1854)
static void C_ccall f_1854(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1552)
static void C_ccall f_1552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1829)
static void C_ccall f_1829(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1555)
static void C_ccall f_1555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1797)
static void C_ccall f_1797(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1558)
static void C_ccall f_1558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1771)
static void C_ccall f_1771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1561)
static void C_fcall f_1561(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1564)
static void C_ccall f_1564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1759)
static void C_ccall f_1759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1567)
static void C_ccall f_1567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1755)
static void C_ccall f_1755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1570)
static void C_ccall f_1570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1743)
static void C_ccall f_1743(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1751)
static void C_ccall f_1751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1581)
static void C_ccall f_1581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1705)
static void C_ccall f_1705(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1687)
static void C_ccall f_1687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1683)
static void C_ccall f_1683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1623)
static void C_ccall f_1623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1613)
static void C_ccall f_1613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1609)
static void C_ccall f_1609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1577)
static void C_ccall f_1577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1075)
static void C_ccall f_1075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1508)
static void C_ccall f_1508(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1078)
static void C_ccall f_1078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1446)
static void C_ccall f_1446(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1446)
static void C_ccall f_1446r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1459)
static void C_fcall f_1459(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1485)
static void C_ccall f_1485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1456)
static void C_ccall f_1456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1449)
static void C_fcall f_1449(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1081)
static void C_ccall f_1081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1444)
static void C_ccall f_1444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1437)
static void C_ccall f_1437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1433)
static void C_ccall f_1433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1425)
static void C_ccall f_1425(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1423)
static void C_ccall f_1423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1085)
static void C_ccall f_1085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1214)
static void C_ccall f_1214(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1226)
static void C_fcall f_1226(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1409)
static void C_ccall f_1409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1402)
static void C_ccall f_1402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1365)
static void C_ccall f_1365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1311)
static void C_ccall f_1311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1328)
static void C_ccall f_1328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1314)
static void C_ccall f_1314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1248)
static void C_ccall f_1248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1291)
static void C_ccall f_1291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1271)
static void C_ccall f_1271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1251)
static void C_ccall f_1251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1218)
static void C_ccall f_1218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1221)
static void C_ccall f_1221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1202)
static void C_ccall f_1202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1209)
static void C_ccall f_1209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1194)
static void C_ccall f_1194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1200)
static void C_ccall f_1200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1197)
static void C_ccall f_1197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1087)
static void C_ccall f_1087(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1093)
static void C_fcall f_1093(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1128)
static void C_fcall f_1128(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1154)
static void C_ccall f_1154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1150)
static void C_ccall f_1150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1107)
static void C_ccall f_1107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_788)
static void C_ccall f_788(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_792)
static void C_ccall f_792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_829)
static void C_ccall f_829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_850)
static void C_ccall f_850(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_848)
static void C_ccall f_848(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_7219)
static void C_fcall trf_7219(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7219(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7219(t0,t1,t2,t3);}

C_noret_decl(trf_7266)
static void C_fcall trf_7266(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7266(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7266(t0,t1);}

C_noret_decl(trf_7116)
static void C_fcall trf_7116(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7116(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7116(t0,t1);}

C_noret_decl(trf_6996)
static void C_fcall trf_6996(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6996(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6996(t0,t1,t2,t3);}

C_noret_decl(trf_6900)
static void C_fcall trf_6900(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6900(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6900(t0,t1);}

C_noret_decl(trf_6868)
static void C_fcall trf_6868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6868(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6868(t0,t1);}

C_noret_decl(trf_6801)
static void C_fcall trf_6801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6801(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6801(t0,t1,t2);}

C_noret_decl(trf_6604)
static void C_fcall trf_6604(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6604(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6604(t0,t1,t2);}

C_noret_decl(trf_6394)
static void C_fcall trf_6394(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6394(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6394(t0,t1,t2,t3);}

C_noret_decl(trf_6338)
static void C_fcall trf_6338(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6338(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6338(t0,t1,t2,t3);}

C_noret_decl(trf_6354)
static void C_fcall trf_6354(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6354(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6354(t0,t1);}

C_noret_decl(trf_6212)
static void C_fcall trf_6212(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6212(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6212(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6246)
static void C_fcall trf_6246(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6246(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6246(t0,t1);}

C_noret_decl(trf_6132)
static void C_fcall trf_6132(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6132(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6132(t0,t1,t2,t3);}

C_noret_decl(trf_6101)
static void C_fcall trf_6101(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6101(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6101(t0,t1,t2,t3);}

C_noret_decl(trf_6065)
static void C_fcall trf_6065(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6065(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6065(t0,t1,t2);}

C_noret_decl(trf_891)
static void C_fcall trf_891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_891(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_891(t0,t1);}

C_noret_decl(trf_907)
static void C_fcall trf_907(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_907(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_907(t0,t1);}

C_noret_decl(trf_5775)
static void C_fcall trf_5775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5775(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5775(t0,t1);}

C_noret_decl(trf_5789)
static void C_fcall trf_5789(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5789(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5789(t0,t1,t2);}

C_noret_decl(trf_5671)
static void C_fcall trf_5671(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5671(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5671(t0,t1,t2);}

C_noret_decl(trf_5529)
static void C_fcall trf_5529(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5529(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5529(t0,t1,t2);}

C_noret_decl(trf_5519)
static void C_fcall trf_5519(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5519(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5519(t0,t1,t2);}

C_noret_decl(trf_5440)
static void C_fcall trf_5440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5440(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5440(t0,t1,t2);}

C_noret_decl(trf_5351)
static void C_fcall trf_5351(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5351(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5351(t0,t1,t2);}

C_noret_decl(trf_5063)
static void C_fcall trf_5063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5063(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5063(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5136)
static void C_fcall trf_5136(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5136(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5136(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5246)
static void C_fcall trf_5246(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5246(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5246(t0,t1,t2);}

C_noret_decl(trf_4849)
static void C_fcall trf_4849(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4849(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4849(t0,t1,t2,t3);}

C_noret_decl(trf_4559)
static void C_fcall trf_4559(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4559(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4559(t0,t1,t2);}

C_noret_decl(trf_4644)
static void C_fcall trf_4644(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4644(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4644(t0,t1);}

C_noret_decl(trf_4679)
static void C_fcall trf_4679(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4679(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4679(t0,t1,t2,t3);}

C_noret_decl(trf_4298)
static void C_fcall trf_4298(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4298(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4298(t0,t1);}

C_noret_decl(trf_4265)
static void C_fcall trf_4265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4265(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4265(t0,t1);}

C_noret_decl(trf_4075)
static void C_fcall trf_4075(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4075(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4075(t0,t1,t2,t3);}

C_noret_decl(trf_4101)
static void C_fcall trf_4101(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4101(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4101(t0,t1);}

C_noret_decl(trf_4129)
static void C_fcall trf_4129(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4129(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4129(t0,t1);}

C_noret_decl(trf_3874)
static void C_fcall trf_3874(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3874(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3874(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3731)
static void C_fcall trf_3731(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3731(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3731(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3501)
static void C_fcall trf_3501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3501(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3501(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3575)
static void C_fcall trf_3575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3575(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3575(t0,t1);}

C_noret_decl(trf_3511)
static void C_fcall trf_3511(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3511(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3511(t0,t1);}

C_noret_decl(trf_3394)
static void C_fcall trf_3394(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3394(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3394(t0,t1);}

C_noret_decl(trf_2917)
static void C_fcall trf_2917(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2917(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2917(t0,t1);}

C_noret_decl(trf_2920)
static void C_fcall trf_2920(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2920(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2920(t0,t1);}

C_noret_decl(trf_2952)
static void C_fcall trf_2952(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2952(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2952(t0,t1);}

C_noret_decl(trf_2865)
static void C_fcall trf_2865(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2865(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2865(t0,t1);}

C_noret_decl(trf_2582)
static void C_fcall trf_2582(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2582(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2582(t0,t1,t2);}

C_noret_decl(trf_2592)
static void C_fcall trf_2592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2592(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2592(t0,t1);}

C_noret_decl(trf_2017)
static void C_fcall trf_2017(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2017(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2017(t0,t1);}

C_noret_decl(trf_2025)
static void C_fcall trf_2025(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2025(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2025(t0,t1);}

C_noret_decl(trf_2033)
static void C_fcall trf_2033(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2033(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2033(t0,t1);}

C_noret_decl(trf_2334)
static void C_fcall trf_2334(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2334(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2334(t0,t1);}

C_noret_decl(trf_2331)
static void C_fcall trf_2331(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2331(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2331(t0,t1);}

C_noret_decl(trf_2079)
static void C_fcall trf_2079(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2079(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2079(t0,t1);}

C_noret_decl(trf_2076)
static void C_fcall trf_2076(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2076(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2076(t0,t1);}

C_noret_decl(trf_1960)
static void C_fcall trf_1960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1960(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1960(t0,t1,t2);}

C_noret_decl(trf_1917)
static void C_fcall trf_1917(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1917(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1917(t0,t1,t2);}

C_noret_decl(trf_1546)
static void C_fcall trf_1546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1546(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1546(t0,t1);}

C_noret_decl(trf_1561)
static void C_fcall trf_1561(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1561(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1561(t0,t1);}

C_noret_decl(trf_1459)
static void C_fcall trf_1459(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1459(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1459(t0,t1);}

C_noret_decl(trf_1449)
static void C_fcall trf_1449(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1449(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1449(t0,t1);}

C_noret_decl(trf_1226)
static void C_fcall trf_1226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1226(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1226(t0,t1,t2);}

C_noret_decl(trf_1093)
static void C_fcall trf_1093(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1093(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1093(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1128)
static void C_fcall trf_1128(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1128(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1128(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(4076)){
C_save(t1);
C_rereclaim2(4076*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,383);
lf[0]=C_h_intern(&lf[0],19,"\003sysundefined-value");
lf[1]=C_h_intern(&lf[1],3,"map");
lf[2]=C_h_intern(&lf[2],6,"lambda");
lf[3]=C_h_intern(&lf[3],14,"\004coreundefined");
lf[4]=C_h_intern(&lf[4],20,"\003syscall-with-values");
lf[5]=C_h_intern(&lf[5],9,"\004coreset!");
lf[6]=C_h_intern(&lf[6],6,"gensym");
lf[7]=C_h_intern(&lf[7],16,"\003syscheck-syntax");
lf[8]=C_h_intern(&lf[8],25,"set!-values/define-values");
lf[9]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[10]=C_h_intern(&lf[10],27,"\010compilercompiler-arguments");
lf[11]=C_h_intern(&lf[11],29,"\010compilerprocess-command-line");
lf[12]=C_h_intern(&lf[12],7,"reverse");
lf[13]=C_h_intern(&lf[13],14,"string->symbol");
lf[14]=C_h_intern(&lf[14],9,"substring");
lf[15]=C_h_intern(&lf[15],25,"\003sysimplicit-exit-handler");
lf[16]=C_h_intern(&lf[16],17,"user-options-pass");
lf[17]=C_h_intern(&lf[17],4,"exit");
lf[18]=C_h_intern(&lf[18],19,"compile-source-file");
lf[19]=C_h_intern(&lf[19],14,"optimize-level");
lf[20]=C_h_intern(&lf[20],5,"cons*");
lf[21]=C_h_intern(&lf[21],22,"optimize-leaf-routines");
lf[22]=C_h_intern(&lf[22],6,"unsafe");
lf[23]=C_h_intern(&lf[23],25,"\010compilercompiler-warning");
lf[24]=C_h_intern(&lf[24],5,"usage");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\047invalid optimization level ~S - ignored");
lf[26]=C_h_intern(&lf[26],11,"debug-level");
lf[27]=C_h_intern(&lf[27],14,"no-lambda-info");
lf[28]=C_h_intern(&lf[28],8,"no-trace");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000 invalid debug level ~S - ignored");
lf[30]=C_h_intern(&lf[30],14,"benchmark-mode");
lf[31]=C_h_intern(&lf[31],17,"fixnum-arithmetic");
lf[32]=C_h_intern(&lf[32],18,"disable-interrupts");
lf[33]=C_h_intern(&lf[33],5,"block");
lf[34]=C_h_intern(&lf[34],11,"lambda-lift");
lf[35]=C_h_intern(&lf[35],31,"\010compilervalid-compiler-options");
lf[36]=C_h_intern(&lf[36],45,"\010compilervalid-compiler-options-with-argument");
lf[37]=C_h_intern(&lf[37],4,"quit");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~s\047 option");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000&invalid compiler option `~a\047 - ignored");
lf[40]=C_h_intern(&lf[40],4,"conc");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[42]=C_h_intern(&lf[42],6,"append");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[44]=C_h_intern(&lf[44],6,"remove");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[46]=C_h_intern(&lf[46],12,"string-split");
lf[47]=C_h_intern(&lf[47],6,"getenv");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\017CHICKEN_OPTIONS");
lf[49]=C_h_intern(&lf[49],4,"argv");
lf[50]=C_h_intern(&lf[50],12,"syntax-error");
lf[51]=C_h_intern(&lf[51],21,"define-compiler-macro");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000!invalid compiler macro definition");
lf[53]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004void\376\377\016");
lf[54]=C_h_intern(&lf[54],9,"compiling");
lf[55]=C_h_intern(&lf[55],12,"\003sysfeatures");
lf[56]=C_h_intern(&lf[56],7,"warning");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\0004compile macros are not available in interpreted code");
lf[58]=C_h_intern(&lf[58],32,"\010compilerregister-compiler-macro");
lf[59]=C_h_intern(&lf[59],18,"\003sysregister-macro");
lf[60]=C_h_intern(&lf[60],4,"args");
lf[61]=C_h_intern(&lf[61],5,"quote");
lf[62]=C_h_intern(&lf[62],7,"sprintf");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000$`~s\047 is deprecated, use `~s\047 instead");
lf[64]=C_h_intern(&lf[64],4,"cons");
lf[65]=C_h_intern(&lf[65],12,"define-macro");
lf[66]=C_h_intern(&lf[66],23,"define-deprecated-macro");
lf[67]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016");
lf[68]=C_h_intern(&lf[68],5,"begin");
lf[69]=C_h_intern(&lf[69],4,"syms");
lf[70]=C_h_intern(&lf[70],7,"symbol\077");
lf[71]=C_h_intern(&lf[71],4,"list");
lf[72]=C_h_intern(&lf[72],2,"if");
lf[73]=C_h_intern(&lf[73],3,"sum");
lf[74]=C_h_intern(&lf[74],5,"null\077");
lf[75]=C_h_intern(&lf[75],3,"cdr");
lf[76]=C_h_intern(&lf[76],3,"car");
lf[77]=C_h_intern(&lf[77],3,"val");
lf[78]=C_h_intern(&lf[78],4,"case");
lf[79]=C_h_intern(&lf[79],3,"let");
lf[80]=C_h_intern(&lf[80],11,"bitwise-ior");
lf[81]=C_h_intern(&lf[81],4,"loop");
lf[82]=C_h_intern(&lf[82],6,"define");
lf[83]=C_h_intern(&lf[83],4,"cond");
lf[84]=C_h_intern(&lf[84],19,"define-foreign-type");
lf[85]=C_h_intern(&lf[85],10,"\003sysappend");
lf[86]=C_h_intern(&lf[86],4,"else");
lf[87]=C_h_intern(&lf[87],1,"=");
lf[88]=C_h_intern(&lf[88],5,"error");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\024not a member of enum");
lf[90]=C_h_intern(&lf[90],23,"define-foreign-variable");
lf[91]=C_h_intern(&lf[91],8,"->string");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\010number->");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\010->number");
lf[94]=C_h_intern(&lf[94],7,"\003sysmap");
lf[95]=C_h_intern(&lf[95],19,"define-foreign-enum");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid type specification");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid enum specification");
lf[98]=C_h_intern(&lf[98],15,"foreign-declare");
lf[99]=C_h_intern(&lf[99],12,"\004coredeclare");
lf[100]=C_h_intern(&lf[100],20,"\003sysregister-macro-2");
lf[101]=C_h_intern(&lf[101],8,"identity");
lf[102]=C_h_intern(&lf[102],5,"const");
lf[103]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\005union\376\377\016");
lf[104]=C_h_intern(&lf[104],9,"c-pointer");
lf[105]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\005union\376\377\016");
lf[106]=C_h_intern(&lf[106],3,"int");
lf[107]=C_h_intern(&lf[107],15,"foreign-lambda*");
lf[108]=C_h_intern(&lf[108],4,"fx>=");
lf[109]=C_h_intern(&lf[109],3,"fx<");
lf[110]=C_h_intern(&lf[110],3,"and");
lf[111]=C_h_intern(&lf[111],10,"\004corecheck");
lf[112]=C_h_intern(&lf[112],21,"define-foreign-record");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\031array access out of range");
lf[114]=C_h_intern(&lf[114],4,"void");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\031array access out of range");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\020~A->~A[~A] = ~A;");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\012~A-~A-set!");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\025return(~A~A->~A[~A]);");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\005~A-~A");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\014~A->~A = ~A;");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\012~A-~A-set!");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\021return(~A~A->~A);");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\005~A-~A");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\015bad slot spec");
lf[129]=C_h_intern(&lf[129],3,"ptr");
lf[130]=C_h_intern(&lf[130],11,"\004coreinline");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\007C_qfree");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000#return((~a *)C_malloc(sizeof(~a)));");
lf[133]=C_h_intern(&lf[133],7,"declare");
lf[134]=C_h_intern(&lf[134],18,"string-intersperse");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\002};");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\007~A[~A];");
lf[138]=C_h_intern(&lf[138],33,"\010compilerforeign-type-declaration");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\003~A;");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\015bad slot spec");
lf[141]=C_h_intern(&lf[141],13,"string-append");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\007struct ");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\003 { ");
lf[144]=C_h_intern(&lf[144],19,"\003syshash-table-set!");
lf[145]=C_h_intern(&lf[145],27,"\010compilerforeign-type-table");
lf[146]=C_h_intern(&lf[146],7,"\000rename");
lf[147]=C_h_intern(&lf[147],4,"eval");
lf[148]=C_h_intern(&lf[148],5,"cadar");
lf[149]=C_h_intern(&lf[149],12,"\000constructor");
lf[150]=C_h_intern(&lf[150],11,"\000destructor");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000)invalid foreign record-type specification");
lf[152]=C_h_intern(&lf[152],4,"caar");
lf[153]=C_h_intern(&lf[153],8,"keyword\077");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\011struct ~A");
lf[155]=C_h_intern(&lf[155],5,"code_");
lf[156]=C_h_intern(&lf[156],13,"foreign-value");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\0007static C_word ~A() { ~A\012; return C_SCHEME_UNDEFINED; }\012");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[159]=C_h_intern(&lf[159],12,"foreign-code");
lf[160]=C_h_intern(&lf[160],17,"\004corelet-location");
lf[161]=C_h_intern(&lf[161],10,"fold-right");
lf[162]=C_h_intern(&lf[162],10,"append-map");
lf[163]=C_h_intern(&lf[163],12,"let-location");
lf[164]=C_h_intern(&lf[164],28,"\004coredefine-foreign-variable");
lf[165]=C_h_intern(&lf[165],29,"\004coredefine-external-variable");
lf[166]=C_h_intern(&lf[166],14,"symbol->string");
lf[167]=C_h_intern(&lf[167],15,"define-location");
lf[168]=C_h_intern(&lf[168],15,"define-external");
lf[169]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[171]=C_h_intern(&lf[171],29,"\004coreforeign-callback-wrapper");
lf[172]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376"
"\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[173]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376"
"\001\000\000\001_\376\377\001\000\000\000\001");
lf[174]=C_h_intern(&lf[174],20,"foreign-safe-wrapper");
lf[175]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006lambda\376\003\000\000\002"
"\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001\376\377\016");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[177]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006lambda\376\003\000\000\002\376\001\000\000\013lambda-list"
"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001\376\377\016");
lf[178]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[179]=C_h_intern(&lf[179],22,"\004coreforeign-primitive");
lf[180]=C_h_intern(&lf[180],17,"foreign-primitive");
lf[181]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[182]=C_h_intern(&lf[182],29,"\004coreforeign-callback-lambda*");
lf[183]=C_h_intern(&lf[183],20,"foreign-safe-lambda*");
lf[184]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\001");
lf[185]=C_h_intern(&lf[185],28,"\004coreforeign-callback-lambda");
lf[186]=C_h_intern(&lf[186],19,"foreign-safe-lambda");
lf[187]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[188]=C_h_intern(&lf[188],20,"\004coreforeign-lambda*");
lf[189]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\001");
lf[190]=C_h_intern(&lf[190],19,"\004coreforeign-lambda");
lf[191]=C_h_intern(&lf[191],14,"foreign-lambda");
lf[192]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[193]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[194]=C_h_intern(&lf[194],24,"\004coredefine-foreign-type");
lf[195]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\001\376\377\001\000\000\000\003");
lf[196]=C_h_intern(&lf[196],17,"register-feature!");
lf[197]=C_h_intern(&lf[197],6,"srfi-8");
lf[198]=C_h_intern(&lf[198],7,"srfi-16");
lf[199]=C_h_intern(&lf[199],7,"srfi-26");
lf[200]=C_h_intern(&lf[200],7,"srfi-31");
lf[201]=C_h_intern(&lf[201],7,"srfi-15");
lf[202]=C_h_intern(&lf[202],7,"srfi-11");
lf[203]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004void\376\377\016\376\377\016");
lf[204]=C_h_intern(&lf[204],25,"\003sysenable-runtime-macros");
lf[205]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\377\016");
lf[206]=C_h_intern(&lf[206],17,"define-for-syntax");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\022invalid identifier");
lf[208]=C_h_intern(&lf[208],6,"letrec");
lf[209]=C_h_intern(&lf[209],3,"rec");
lf[210]=C_h_intern(&lf[210],22,"chicken-compile-shared");
lf[211]=C_h_intern(&lf[211],3,"not");
lf[212]=C_h_intern(&lf[212],4,"unit");
lf[213]=C_h_intern(&lf[213],7,"provide");
lf[214]=C_h_intern(&lf[214],11,"cond-expand");
lf[215]=C_h_intern(&lf[215],6,"export");
lf[216]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\377\016");
lf[217]=C_h_intern(&lf[217],6,"static");
lf[218]=C_h_intern(&lf[218],4,"cdar");
lf[219]=C_h_intern(&lf[219],7,"dynamic");
lf[220]=C_h_intern(&lf[220],16,"define-extension");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid clause specifier");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid clause syntax");
lf[223]=C_h_intern(&lf[223],22,"string-parse-start+end");
lf[224]=C_h_intern(&lf[224],7,"receive");
lf[225]=C_h_intern(&lf[225],28,"string-parse-final-start+end");
lf[226]=C_h_intern(&lf[226],20,"let-string-start+end");
lf[227]=C_h_intern(&lf[227],5,"apply");
lf[228]=C_h_intern(&lf[228],2,"<>");
lf[229]=C_h_intern(&lf[229],5,"<...>");
lf[230]=C_h_intern(&lf[230],4,"cute");
lf[231]=C_h_intern(&lf[231],3,"cut");
lf[232]=C_h_intern(&lf[232],22,"\004corerequire-extension");
lf[233]=C_h_intern(&lf[233],3,"use");
lf[234]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[235]=C_h_intern(&lf[235],17,"require-extension");
lf[236]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[237]=C_h_intern(&lf[237],23,"\004corerequire-for-syntax");
lf[238]=C_h_intern(&lf[238],18,"require-for-syntax");
lf[239]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[240]=C_h_intern(&lf[240],18,"\003sysmake-structure");
lf[241]=C_h_intern(&lf[241],1,"x");
lf[242]=C_h_intern(&lf[242],14,"\003sysstructure\077");
lf[243]=C_h_intern(&lf[243],15,"\000record-setters");
lf[244]=C_h_intern(&lf[244],19,"\003syscheck-structure");
lf[245]=C_h_intern(&lf[245],13,"\003sysblock-ref");
lf[246]=C_h_intern(&lf[246],18,"getter-with-setter");
lf[247]=C_h_intern(&lf[247],1,"y");
lf[248]=C_h_intern(&lf[248],14,"\003sysblock-set!");
lf[249]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[250]=C_h_intern(&lf[250],18,"define-record-type");
lf[251]=C_h_intern(&lf[251],4,"memv");
lf[252]=C_h_intern(&lf[252],9,"condition");
lf[253]=C_h_intern(&lf[253],8,"\003sysslot");
lf[254]=C_h_intern(&lf[254],17,"handle-exceptions");
lf[255]=C_h_intern(&lf[255],10,"\003syssignal");
lf[256]=C_h_intern(&lf[256],14,"condition-case");
lf[257]=C_h_intern(&lf[257],9,"\003sysapply");
lf[258]=C_h_intern(&lf[258],10,"\003sysvalues");
lf[259]=C_h_intern(&lf[259],22,"with-exception-handler");
lf[260]=C_h_intern(&lf[260],30,"call-with-current-continuation");
lf[261]=C_h_intern(&lf[261],27,"\003sysregister-record-printer");
lf[262]=C_h_intern(&lf[262],21,"define-record-printer");
lf[263]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[264]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[265]=C_h_intern(&lf[265],6,"length");
lf[266]=C_h_intern(&lf[266],9,"split-at!");
lf[267]=C_h_intern(&lf[267],4,"take");
lf[268]=C_h_intern(&lf[268],3,"fx=");
lf[269]=C_h_intern(&lf[269],11,"case-lambda");
lf[270]=C_h_intern(&lf[270],11,"lambda-list");
lf[271]=C_h_intern(&lf[271],25,"\003sysdecompose-lambda-list");
lf[272]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corecheck\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\003syserror\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreimmutable\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376B\000\0000no matching clause in call to \047case-lambda\047 form\376\377\016\376\377\016\376\377\016"
"\376\377\016");
lf[273]=C_h_intern(&lf[273],3,"min");
lf[274]=C_h_intern(&lf[274],7,"require");
lf[275]=C_h_intern(&lf[275],6,"srfi-1");
lf[276]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[278]=C_h_intern(&lf[278],14,"\004coreimmutable");
lf[279]=C_h_intern(&lf[279],9,"\003syserror");
lf[280]=C_h_intern(&lf[280],14,"let-optionals*");
lf[281]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[282]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[283]=C_h_intern(&lf[283],8,"optional");
lf[284]=C_h_intern(&lf[284],9,":optional");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[286]=C_h_intern(&lf[286],4,"let*");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\004def-");
lf[289]=C_h_intern(&lf[289],5,"%rest");
lf[290]=C_h_intern(&lf[290],4,"body");
lf[291]=C_h_intern(&lf[291],4,"cadr");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\001%");
lf[293]=C_h_intern(&lf[293],13,"let-optionals");
lf[294]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[295]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[296]=C_h_intern(&lf[296],4,"eqv\077");
lf[297]=C_h_intern(&lf[297],6,"switch");
lf[298]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[299]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[300]=C_h_intern(&lf[300],2,"or");
lf[301]=C_h_intern(&lf[301],6,"select");
lf[302]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[303]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\042syntax error in `cond-expand\047 form");
lf[305]=C_h_intern(&lf[305],12,"\003sysfeature\077");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000(no matching clause in `cond-expand\047 form");
lf[307]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[308]=C_h_intern(&lf[308],21,"\003syssyntax-error-hook");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\037syntax error in \047and-let*\047 form");
lf[310]=C_h_intern(&lf[310],8,"and-let*");
lf[311]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[312]=C_h_intern(&lf[312],20,"\004coredefine-constant");
lf[313]=C_h_intern(&lf[313],15,"define-constant");
lf[314]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[315]=C_h_intern(&lf[315],18,"\004coredefine-inline");
lf[316]=C_h_intern(&lf[316],13,"define-inline");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000*invalid substitution form - must be lambda");
lf[318]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[319]=C_h_intern(&lf[319],8,"list-ref");
lf[320]=C_h_intern(&lf[320],9,"nth-value");
lf[321]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[322]=C_h_intern(&lf[322],13,"letrec-values");
lf[323]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[324]=C_h_intern(&lf[324],10,"let-values");
lf[325]=C_h_intern(&lf[325],11,"let*-values");
lf[326]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[327]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[328]=C_h_intern(&lf[328],13,"define-values");
lf[329]=C_h_intern(&lf[329],11,"set!-values");
lf[330]=C_h_intern(&lf[330],6,"unless");
lf[331]=C_h_intern(&lf[331],4,"when");
lf[332]=C_h_intern(&lf[332],16,"\003sysdynamic-wind");
lf[333]=C_h_intern(&lf[333],1,"t");
lf[334]=C_h_intern(&lf[334],8,"\003syslist");
lf[335]=C_h_intern(&lf[335],12,"parameterize");
lf[336]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[337]=C_h_intern(&lf[337],10,"\000compiling");
lf[338]=C_h_intern(&lf[338],19,"\004corecompiletimetoo");
lf[339]=C_h_intern(&lf[339],20,"\004corecompiletimeonly");
lf[340]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[341]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[342]=C_h_intern(&lf[342],4,"load");
lf[343]=C_h_intern(&lf[343],8,"run-time");
lf[344]=C_h_intern(&lf[344],7,"compile");
lf[345]=C_h_intern(&lf[345],12,"compile-time");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid situation specifier");
lf[347]=C_h_intern(&lf[347],9,"eval-when");
lf[348]=C_h_intern(&lf[348],8,"\003sysvoid");
lf[349]=C_h_intern(&lf[349],9,"fluid-let");
lf[350]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[351]=C_h_intern(&lf[351],11,"\000type-error");
lf[352]=C_h_intern(&lf[352],15,"\003syssignal-hook");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\033argument has incorrect type");
lf[354]=C_h_intern(&lf[354],6,"ensure");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\020assertion failed");
lf[356]=C_h_intern(&lf[356],6,"assert");
lf[357]=C_h_intern(&lf[357],20,"with-input-from-file");
lf[358]=C_h_intern(&lf[358],4,"read");
lf[359]=C_h_intern(&lf[359],27,"\003syscurrent-source-filename");
lf[360]=C_h_intern(&lf[360],5,"print");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\014; including ");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[363]=C_h_intern(&lf[363],12,"load-verbose");
lf[364]=C_h_intern(&lf[364],28,"\003sysresolve-include-filename");
lf[365]=C_h_intern(&lf[365],7,"include");
lf[366]=C_h_intern(&lf[366],15,"\003sysstart-timer");
lf[367]=C_h_intern(&lf[367],14,"\003sysstop-timer");
lf[368]=C_h_intern(&lf[368],17,"\003sysdisplay-times");
lf[369]=C_h_intern(&lf[369],4,"time");
lf[370]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[371]=C_h_intern(&lf[371],28,"\003sysstring->qualified-symbol");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\005-set!");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\001\077");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\005make-");
lf[377]=C_h_intern(&lf[377],27,"\003sysqualified-symbol-prefix");
lf[378]=C_h_intern(&lf[378],13,"define-record");
lf[379]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[380]=C_h_intern(&lf[380],6,"symbol");
lf[381]=C_h_intern(&lf[381],11,"\003sysprovide");
lf[382]=C_h_intern(&lf[382],19,"chicken-more-macros");
C_register_lf2(lf,383,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_709,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k707 */
static void C_ccall f_709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_712,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k710 in k707 */
static void C_ccall f_712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_715,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k713 in k710 in k707 */
static void C_ccall f_715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_718,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k716 in k713 in k710 in k707 */
static void C_ccall f_718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_721,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_match_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_724,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_4_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_727,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_730,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_support_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_733,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_compiler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_736,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_739,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_driver_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_742,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_platform_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_745,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_backend_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_745,2,t0,t1);}
t2=C_retrieve(lf[0]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_751,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 79   ##sys#provide */
t4=C_retrieve(lf[381]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[382]);}

/* k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_754,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[166]+1);
t4=*((C_word*)lf[13]+1);
t5=*((C_word*)lf[141]+1);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7178,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   ##sys#register-macro */
t7=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[378],t6);}

/* a7177 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_7178(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_7178r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7178r(t0,t1,t2,t3);}}

static void C_ccall f_7178r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7182,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 79   ##sys#check-syntax */
t5=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[378],t2,lf[380]);}

/* k7180 in a7177 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_7182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7182,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7185,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 79   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[378],((C_word*)t0)[5],lf[379]);}

/* k7183 in k7180 in a7177 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_7185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7188,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 79   symbol->string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k7186 in k7183 in k7180 in a7177 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_7188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7188,2,t0,t1);}
t2=(C_word)C_i_memq(lf[243],C_retrieve(lf[55]));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7194,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* chicken.scm: 79   ##sys#qualified-symbol-prefix */
t4=C_retrieve(lf[377]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}

/* k7192 in k7186 in k7183 in k7180 in a7177 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_7194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7380,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7400,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   string-append */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[376],((C_word*)t0)[3]);}

/* k7398 in k7192 in k7186 in k7183 in k7180 in a7177 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_7400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 79   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[371]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7378 in k7192 in k7186 in k7183 in k7180 in a7177 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_7380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7380,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
t4=(C_word)C_a_i_cons(&a,2,lf[240],t3);
t5=(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_list(&a,3,lf[82],t1,t5);
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7356,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t6,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7376,a[2]=((C_word*)t0)[5],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   string-append */
t9=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,((C_word*)t0)[3],lf[375]);}

/* k7374 in k7378 in k7192 in k7186 in k7183 in k7180 in a7177 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_7376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 79   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[371]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7354 in k7378 in k7192 in k7186 in k7183 in k7180 in a7177 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_7356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7356,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[241]);
t3=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[10]);
t4=(C_word)C_a_i_list(&a,3,lf[242],lf[241],t3);
t5=(C_word)C_a_i_list(&a,3,lf[2],t2,t4);
t6=(C_word)C_a_i_list(&a,3,lf[82],t1,t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7217,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7219,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t9,a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp));
t11=((C_word*)t9)[1];
f_7219(t11,t7,((C_word*)t0)[2],C_fix(1));}

/* mapslots in k7354 in k7378 in k7192 in k7186 in k7183 in k7180 in a7177 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_7219(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7219,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7229,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=t1,a[9]=t3,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* chicken.scm: 79   symbol->string */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}}

/* k7227 in mapslots in k7354 in k7378 in k7192 in k7186 in k7183 in k7180 in a7177 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_7229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7232,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7348,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   string-append */
t4=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[2],lf[373],t1,lf[374]);}

/* k7346 in k7227 in mapslots in k7354 in k7378 in k7192 in k7186 in k7183 in k7180 in a7177 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_7348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 79   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[371]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7230 in k7227 in mapslots in k7354 in k7378 in k7192 in k7186 in k7183 in k7180 in a7177 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_7232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7235,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t1,a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7344,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   string-append */
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[3],lf[372],((C_word*)t0)[2]);}

/* k7342 in k7230 in k7227 in mapslots in k7354 in k7378 in k7192 in k7186 in k7183 in k7180 in a7177 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_7344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 79   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[371]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7233 in k7230 in k7227 in mapslots in k7354 in k7378 in k7192 in k7186 in k7183 in k7180 in a7177 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_7235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[167],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7235,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[241],lf[77]);
t3=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[8]);
t4=(C_word)C_a_i_list(&a,3,lf[244],lf[241],t3);
t5=(C_word)C_a_i_list(&a,2,lf[111],t4);
t6=(C_word)C_a_i_list(&a,4,lf[248],lf[241],((C_word*)t0)[7],lf[77]);
t7=(C_word)C_a_i_list(&a,4,lf[2],t2,t5,t6);
t8=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[6],t7);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7266,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t8,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t10=(C_word)C_a_i_list(&a,1,lf[241]);
t11=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[8]);
t12=(C_word)C_a_i_list(&a,3,lf[244],lf[241],t11);
t13=(C_word)C_a_i_list(&a,2,lf[111],t12);
t14=(C_word)C_a_i_list(&a,3,lf[245],lf[241],((C_word*)t0)[7]);
t15=(C_word)C_a_i_list(&a,4,lf[2],t10,t13,t14);
t16=t9;
f_7266(t16,(C_word)C_a_i_list(&a,3,lf[246],t15,((C_word*)t0)[6]));}
else{
t10=(C_word)C_a_i_list(&a,1,lf[241]);
t11=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[8]);
t12=(C_word)C_a_i_list(&a,3,lf[244],lf[241],t11);
t13=(C_word)C_a_i_list(&a,2,lf[111],t12);
t14=(C_word)C_a_i_list(&a,3,lf[245],lf[241],((C_word*)t0)[7]);
t15=t9;
f_7266(t15,(C_word)C_a_i_list(&a,4,lf[2],t10,t13,t14));}}

/* k7264 in k7233 in k7230 in k7227 in mapslots in k7354 in k7378 in k7192 in k7186 in k7183 in k7180 in a7177 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_7266(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7266,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_list(&a,3,lf[68],((C_word*)t0)[6],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7246,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t6=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* chicken.scm: 79   mapslots */
t7=((C_word*)((C_word*)t0)[2])[1];
f_7219(t7,t4,t5,t6);}

/* k7244 in k7264 in k7233 in k7230 in k7227 in mapslots in k7354 in k7378 in k7192 in k7186 in k7183 in k7180 in a7177 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_7246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7246,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7215 in k7354 in k7378 in k7192 in k7186 in k7183 in k7180 in a7177 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_7217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7217,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[68],t3));}

/* k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_757,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7090,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[224],t3);}

/* a7089 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_7090(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+23)){
C_save_and_reclaim((void*)tr3r,(void*)f_7090r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7090r(t0,t1,t2,t3);}}

static void C_ccall f_7090r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(23);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[4],t4,lf[334]));}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7107,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 79   ##sys#check-syntax */
t5=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[224],t2,lf[270]);}}

/* k7105 in a7089 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_7107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7107,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7110,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 79   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[224],((C_word*)t0)[3],lf[370]);}

/* k7108 in k7105 in a7089 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_7110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7110,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7116,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=t2;
f_7116(t4,(C_word)C_i_nullp(t3));}
else{
t3=t2;
f_7116(t3,C_SCHEME_FALSE);}}

/* k7114 in k7108 in k7105 in a7089 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_7116(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7116,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[79],t7));}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[2],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[4],t3,t6));}}

/* k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_757,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_760,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[6]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7049,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 79   ##sys#register-macro */
t5=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[369],t4);}

/* a7048 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_7049(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_7049r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7049r(t0,t1,t2);}}

static void C_ccall f_7049r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7053,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   gensym */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[333]);}

/* k7051 in a7048 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_7053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7053,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[366]);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,lf[2],t3);
t5=(C_word)C_a_i_list(&a,1,lf[367]);
t6=(C_word)C_a_i_list(&a,2,lf[368],t5);
t7=(C_word)C_a_i_list(&a,3,lf[257],lf[258],t1);
t8=(C_word)C_a_i_list(&a,4,lf[2],t1,t6,t7);
t9=(C_word)C_a_i_list(&a,3,lf[4],t4,t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,3,lf[68],t2,t9));}

/* k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_763,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7033,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[133],t3);}

/* a7032 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_7033(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_7033r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7033r(t0,t1,t2);}}

static void C_ccall f_7033r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7041,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7043,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a7042 in a7032 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_7043(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7043,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k7039 in a7032 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_7041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7041,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[99],t1));}

/* k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_766,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[357]);
t4=*((C_word*)lf[358]+1);
t5=*((C_word*)lf[12]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6956,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 79   ##sys#register-macro */
t7=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[365],t6);}

/* a6955 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6956(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6956,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6960,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 79   ##sys#resolve-include-filename */
t4=C_retrieve(lf[364]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,C_SCHEME_TRUE);}

/* k6958 in a6955 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6963,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7028,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   load-verbose */
t4=C_retrieve(lf[363]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7026 in k6958 in a6955 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_7028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken.scm: 79   print */
t2=*((C_word*)lf[360]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[361],((C_word*)t0)[2],lf[362]);}
else{
t2=((C_word*)t0)[3];
f_6963(2,t2,C_SCHEME_UNDEFINED);}}

/* k6961 in k6958 in a6955 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6970,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6972,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 79   with-input-from-file */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[5],t3);}

/* a6971 in k6961 in k6958 in a6955 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6972,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6978,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7019,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[332]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t1,t6,t7,t8);}

/* a7018 in a6971 in k6961 in k6958 in a6955 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_7019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7019,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[359]));
t3=C_mutate((C_word*)lf[359]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[0]));}

/* a6985 in a6971 in k6961 in k6958 in a6955 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6994,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 79   read */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6992 in a6985 in a6971 in k6961 in k6958 in a6955 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6994,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6996,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6996(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* do44 in k6992 in a6985 in a6971 in k6961 in k6958 in a6955 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_6996(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6996,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eofp(t2))){
/* chicken.scm: 79   reverse */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7013,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 79   read */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k7011 in do44 in k6992 in a6985 in a6971 in k6961 in k6958 in a6955 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_7013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7013,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_6996(t3,((C_word*)t0)[2],t1,t2);}

/* a6977 in a6971 in k6961 in k6958 in a6955 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6978,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[359]));
t3=C_mutate((C_word*)lf[359]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[0]));}

/* k6968 in k6961 in k6958 in a6955 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6970,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[68],t1));}

/* k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_769,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6896,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[356],t3);}

/* a6895 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6896(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_6896r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6896r(t0,t1,t2,t3);}}

static void C_ccall f_6896r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6900,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t3);
if(C_truep(t5)){
t6=(C_word)C_a_i_list(&a,2,lf[61],lf[355]);
t7=t4;
f_6900(t7,(C_word)C_a_i_list(&a,2,lf[278],t6));}
else{
t6=t4;
f_6900(t6,(C_word)C_slot(t3,C_fix(0)));}}

/* k6898 in a6895 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_6900(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6900,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[111],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,lf[3]);
t4=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=(C_word)C_fixnum_greaterp(t5,C_fix(1));
t7=(C_truep(t6)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t4,t7);
t9=(C_word)C_a_i_cons(&a,2,t1,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[279],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[72],t2,t3,t10));}

/* k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_772,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6837,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[354],t3);}

/* a6836 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6837(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_6837r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6837r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6837r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6841,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 79   gensym */
t6=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k6839 in a6836 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[54],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6841,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t5=(C_word)C_a_i_list(&a,2,lf[111],t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6868,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t7=t6;
f_6868(t7,((C_word*)t0)[2]);}
else{
t7=(C_word)C_a_i_list(&a,2,lf[61],lf[353]);
t8=(C_word)C_a_i_list(&a,2,lf[278],t7);
t9=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t10=t6;
f_6868(t10,(C_word)C_a_i_list(&a,3,t8,t1,t9));}}

/* k6866 in k6839 in a6836 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_6868(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6868,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[351],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[352],t2);
t4=(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[5],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t4));}

/* k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_772,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_775,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[6]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6663,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 79   ##sys#register-macro */
t5=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[349],t4);}

/* a6662 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6663(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_6663r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6663r(t0,t1,t2,t3);}}

static void C_ccall f_6663r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6667,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 79   ##sys#check-syntax */
t5=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[349],t2,lf[350]);}

/* k6665 in a6662 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6670,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 79   ##sys#map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[76]+1),((C_word*)t0)[3]);}

/* k6668 in k6665 in a6662 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6831,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 79   ##sys#map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a6830 in k6668 in k6665 in a6662 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6831(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6831,3,t0,t1,t2);}
/* chicken.scm: 79   gensym */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k6671 in k6668 in k6665 in a6662 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6676,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6825,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 79   ##sys#map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a6824 in k6671 in k6668 in k6665 in a6662 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6825(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6825,3,t0,t1,t2);}
/* chicken.scm: 79   gensym */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k6674 in k6671 in k6668 in k6665 in a6662 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6683,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6787,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6823,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   ##sys#map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[291]+1),((C_word*)t0)[2]);}

/* k6821 in k6674 in k6671 in k6668 in k6665 in a6662 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 79   map */
t2=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[334]+1),((C_word*)t0)[2],t1);}

/* k6785 in k6674 in k6671 in k6668 in k6665 in a6662 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6791,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6795,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(((C_word*)t0)[2]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6801,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_6801(t8,t3,t4);}

/* loop in k6785 in k6674 in k6671 in k6668 in k6665 in a6662 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_6801(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6801,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6815,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
/* chicken.scm: 79   loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k6813 in loop in k6785 in k6674 in k6671 in k6668 in k6665 in a6662 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6815,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1));}

/* k6793 in k6785 in k6674 in k6671 in k6668 in k6665 in a6662 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 79   map */
t2=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[334]+1),((C_word*)t0)[2],t1);}

/* k6789 in k6785 in k6674 in k6671 in k6668 in k6665 in a6662 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6681 in k6674 in k6671 in k6668 in k6665 in a6662 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6683,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6751,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6755,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6779,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   map */
t5=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* a6778 in k6681 in k6674 in k6671 in k6668 in k6665 in a6662 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6779(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6779,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t2,t3));}

/* k6753 in k6681 in k6674 in k6671 in k6668 in k6665 in a6662 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6755,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6759,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6763,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6773,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   map */
t5=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6772 in k6753 in k6681 in k6674 in k6671 in k6668 in k6665 in a6662 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6773(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6773,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t2,t3));}

/* k6761 in k6753 in k6681 in k6674 in k6671 in k6668 in k6665 in a6662 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6763,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[348]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k6757 in k6753 in k6681 in k6674 in k6671 in k6668 in k6665 in a6662 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6749 in k6681 in k6674 in k6671 in k6668 in k6665 in a6662 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6751,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[2],t2);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,lf[2],t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6707,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6711,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6735,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   map */
t9=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,t8,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a6734 in k6749 in k6681 in k6674 in k6671 in k6668 in k6665 in a6662 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6735(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6735,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t2,t3));}

/* k6709 in k6749 in k6681 in k6674 in k6671 in k6668 in k6665 in a6662 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6715,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6719,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6729,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   map */
t5=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6728 in k6709 in k6749 in k6681 in k6674 in k6671 in k6668 in k6665 in a6662 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6729(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6729,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t2,t3));}

/* k6717 in k6709 in k6749 in k6681 in k6674 in k6671 in k6668 in k6665 in a6662 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6719,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[348]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k6713 in k6709 in k6749 in k6681 in k6674 in k6671 in k6668 in k6665 in a6662 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6705 in k6749 in k6681 in k6674 in k6671 in k6668 in k6665 in a6662 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6707,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[2],t2);
t4=(C_word)C_a_i_list(&a,4,lf[332],((C_word*)t0)[5],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t4));}

/* k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_778,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6568,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[347],t3);}

/* a6567 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6568(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr3r,(void*)f_6568r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6568r(t0,t1,t2,t3);}}

static void C_ccall f_6568r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(24);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(C_word)C_a_i_cons(&a,2,lf[68],t3);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6575,a[2]=t5,a[3]=t10,a[4]=t1,a[5]=t9,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6604,a[2]=t7,a[3]=t9,a[4]=t5,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_6604(t15,t11,t2);}

/* loop in a6567 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_6604(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6604,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6617,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(t3,lf[147]);
if(C_truep(t5)){
t6=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t7=t4;
f_6617(2,t7,t6);}
else{
t6=(C_word)C_eqp(t3,lf[342]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t3,lf[343]));
if(C_truep(t7)){
t8=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t9=t4;
f_6617(2,t9,t8);}
else{
t8=(C_word)C_eqp(t3,lf[344]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[345]));
if(C_truep(t9)){
t10=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t11=t4;
f_6617(2,t11,t10);}
else{
t10=(C_word)C_slot(t2,C_fix(0));
/* chicken.scm: 79   ##sys#error */
t11=*((C_word*)lf[279]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t4,lf[346],t10);}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6615 in loop in a6567 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* chicken.scm: 79   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6604(t3,((C_word*)t0)[2],t2);}

/* k6573 in a6567 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6575,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[337],C_retrieve(lf[55])))){
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?((C_word*)((C_word*)t0)[5])[1]:C_SCHEME_FALSE);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_a_i_list(&a,2,lf[338],((C_word*)t0)[3]):(C_truep(((C_word*)((C_word*)t0)[6])[1])?(C_word)C_a_i_list(&a,2,lf[339],((C_word*)t0)[3]):(C_truep(((C_word*)((C_word*)t0)[5])[1])?((C_word*)t0)[3]:lf[340]))));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)((C_word*)t0)[2])[1])?((C_word*)t0)[3]:lf[341]));}}

/* k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_781,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[76]+1);
t4=*((C_word*)lf[291]+1);
t5=*((C_word*)lf[1]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6458,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 79   ##sys#register-macro */
t7=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[335],t6);}

/* a6457 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6458(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_6458r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6458r(t0,t1,t2,t3);}}

static void C_ccall f_6458r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6462,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 79   ##sys#check-syntax */
t5=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[335],t2,lf[336]);}

/* k6460 in a6457 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 79   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6463 in k6460 in a6457 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6468,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 79   ##sys#map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k6466 in k6463 in k6460 in a6457 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6471,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 79   ##sys#map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6469 in k6466 in k6463 in k6460 in a6457 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6474,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6562,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a6561 in k6469 in k6466 in k6463 in k6460 in a6457 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6562(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6562,3,t0,t1,t2);}
/* chicken.scm: 79   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k6472 in k6469 in k6466 in k6463 in k6460 in a6457 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6556,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a6555 in k6472 in k6469 in k6466 in k6463 in k6460 in a6457 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6556(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6556,3,t0,t1,t2);}
/* chicken.scm: 79   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k6475 in k6472 in k6469 in k6466 in k6463 in k6460 in a6457 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6484,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6550,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 79   map */
t4=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[334]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k6548 in k6475 in k6472 in k6469 in k6466 in k6463 in k6460 in a6457 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6554,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   map */
t3=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[334]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6552 in k6548 in k6475 in k6472 in k6469 in k6466 in k6463 in k6460 in a6457 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 79   ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6482 in k6475 in k6472 in k6469 in k6466 in k6463 in k6460 in a6457 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6520,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6522,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   map */
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6521 in k6482 in k6475 in k6472 in k6469 in k6466 in k6463 in k6460 in a6457 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6522(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[39],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6522,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t2);
t5=(C_word)C_a_i_list(&a,2,lf[333],t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_list(&a,2,t2,t3);
t8=(C_word)C_a_i_list(&a,3,lf[5],t3,lf[333]);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_list(&a,4,lf[79],t6,t7,t8));}

/* k6518 in k6482 in k6475 in k6472 in k6469 in k6466 in k6463 in k6460 in a6457 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6520,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[2],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t7=(C_word)C_a_i_cons(&a,2,lf[2],t6);
t8=(C_word)C_a_i_list(&a,4,lf[332],((C_word*)t0)[5],t7,((C_word*)t0)[5]);
t9=(C_word)C_a_i_list(&a,3,lf[79],t5,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t9));}

/* k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_781,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_784,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6448,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[331],t3);}

/* a6447 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6448(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_6448r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6448r(t0,t1,t2,t3);}}

static void C_ccall f_6448r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(12);
t4=(C_word)C_a_i_cons(&a,2,lf[68],t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[72],t2,t4));}

/* k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_787,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6434,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[330],t3);}

/* a6433 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6434(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr3r,(void*)f_6434r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6434r(t0,t1,t2,t3);}}

static void C_ccall f_6434r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(18);
t4=(C_word)C_a_i_list(&a,1,lf[3]);
t5=(C_word)C_a_i_cons(&a,2,lf[68],t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,4,lf[72],t2,t4,t5));}

/* k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_787,2,t0,t1);}
t2=*((C_word*)lf[1]+1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_788,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_861,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   ##sys#register-macro */
t5=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[329],t3);}

/* k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_864,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 79   ##sys#register-macro */
t3=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[328],((C_word*)t0)[2]);}

/* k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_867,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6101,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6132,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6172,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   ##sys#register-macro-2 */
t10=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t2,lf[324],t9);}

/* a6099 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6172(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6172,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6176,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 79   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[324],t2,lf[327]);}

/* k6174 in a6099 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6176,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6185,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[76]+1),t2);}

/* k6183 in k6174 in a6099 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6188,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6394,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6394(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* loop in k6183 in k6174 in a6099 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_6394(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6394,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6407,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t4))){
/* chicken.scm: 79   append */
t6=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t4))){
/* chicken.scm: 79   append* */
t6=((C_word*)((C_word*)t0)[2])[1];
f_6101(t6,t5,t4,t3);}
else{
t6=t5;
f_6407(2,t6,(C_word)C_a_i_cons(&a,2,t4,t3));}}}}

/* k6405 in loop in k6183 in k6174 in a6099 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 79   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6394(t3,((C_word*)t0)[2],t2,t1);}

/* k6186 in k6183 in k6174 in a6099 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6191,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6384,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a6383 in k6186 in k6183 in k6174 in a6099 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6384(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6384,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6392,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   gensym */
t4=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6390 in a6383 in k6186 in k6183 in k6174 in a6099 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6392,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6189 in k6186 in k6183 in k6174 in a6099 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6191,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6192,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6203,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6338,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_6338(t7,t3,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}

/* loop in k6189 in k6186 in k6183 in k6174 in a6099 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_6338(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6338,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* chicken.scm: 79   reverse */
t4=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6354,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6378,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   map* */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6132(t7,t6,((C_word*)t0)[2],t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6371,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   lookup */
t7=((C_word*)t0)[2];
f_6192(3,t7,t6,t4);}}}

/* k6369 in loop in k6189 in k6186 in k6183 in k6174 in a6099 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6371,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6354(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k6376 in loop in k6189 in k6186 in k6183 in k6174 in a6099 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6378,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6354(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k6352 in loop in k6189 in k6186 in k6183 in k6174 in a6099 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_6354(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 79   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6338(t3,((C_word*)t0)[2],t2,t1);}

/* k6201 in k6189 in k6186 in k6183 in k6174 in a6099 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6210,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6332,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a6331 in k6201 in k6189 in k6186 in k6183 in k6174 in a6099 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6332(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6332,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k6208 in k6201 in k6189 in k6186 in k6183 in k6174 in a6099 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6210,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6212,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_6212(t5,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* fold in k6208 in k6201 in k6189 in k6186 in k6183 in k6174 in a6099 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_6212(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6212,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6230,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6232,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* map */
t7=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6246,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(t4);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6326,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 79   cdar */
t8=*((C_word*)lf[218]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}
else{
t7=t5;
f_6246(t7,C_SCHEME_FALSE);}}}

/* k6324 in fold in k6208 in k6201 in k6189 in k6186 in k6183 in k6174 in a6099 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6246(t2,(C_word)C_i_nullp(t1));}

/* k6244 in fold in k6208 in k6201 in k6189 in k6186 in k6183 in k6174 in a6099 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_6246(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6246,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6277,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 79   caar */
t3=*((C_word*)lf[152]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6300,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[6]);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken.scm: 79   fold */
t9=((C_word*)((C_word*)t0)[2])[1];
f_6212(t9,t5,t6,t7,t8);}}

/* k6298 in k6244 in fold in k6208 in k6201 in k6189 in k6186 in k6183 in k6174 in a6099 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6300,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[4],((C_word*)t0)[2],t2));}

/* k6275 in k6244 in fold in k6208 in k6201 in k6189 in k6186 in k6183 in k6174 in a6099 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6277,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6257,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[6]);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken.scm: 79   fold */
t9=((C_word*)((C_word*)t0)[2])[1];
f_6212(t9,t5,t6,t7,t8);}

/* k6255 in k6275 in k6244 in fold in k6208 in k6201 in k6189 in k6186 in k6183 in k6174 in a6099 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6257,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* a6231 in fold in k6208 in k6201 in k6189 in k6186 in k6183 in k6174 in a6099 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6232(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6232,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6240,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   lookup */
t4=((C_word*)t0)[2];
f_6192(3,t4,t3,t2);}

/* k6238 in a6231 in fold in k6208 in k6201 in k6189 in k6186 in k6183 in k6174 in a6099 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6240,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k6228 in fold in k6208 in k6201 in k6189 in k6186 in k6183 in k6174 in a6099 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6230,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[79],t2));}

/* lookup in k6189 in k6186 in k6183 in k6174 in a6099 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6192(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6192,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* map* in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_6132(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6132,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6155,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* chicken.scm: 79   proc */
t6=t2;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
/* chicken.scm: 79   proc */
t4=t2;
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}}}

/* k6153 in map* in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6159,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 79   map* */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6132(t4,t2,((C_word*)t0)[2],t3);}

/* k6157 in k6153 in map* in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6159,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* append* in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_6101(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6101,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6122,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* chicken.scm: 79   append* */
t8=t5;
t9=t6;
t10=t3;
t1=t8;
t2=t9;
t3=t10;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}}

/* k6120 in append* in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6122,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_870,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6050,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[325],t3);}

/* a6049 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6050(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6050,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6054,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[325],t2,lf[326]);}

/* k6052 in a6049 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6054,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6065,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_6065(t7,((C_word*)t0)[2],t2);}

/* fold in k6052 in a6049 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_6065(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6065,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[79],t3));}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6090,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* chicken.scm: 79   fold */
t9=t5;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}

/* k6088 in fold in k6052 in a6049 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6090,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[324],((C_word*)t0)[2],t1));}

/* k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_873,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5930,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[322],t3);}

/* a5929 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5930(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5930,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5934,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[322],t2,lf[323]);}

/* k5932 in a5929 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5934,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5943,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6042,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6044,tmp=(C_word)a,a+=2,tmp);
/* map */
t7=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a6043 in k5932 in a5929 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6044(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6044,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k6040 in k5932 in a5929 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[85]+1),t1);}

/* k5941 in k5932 in a5929 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5943,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5946,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6030,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a6029 in k5941 in k5932 in a5929 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6030(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6030,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6038,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   gensym */
t4=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6036 in a6029 in k5941 in k5932 in a5929 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6038,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5944 in k5941 in k5932 in a5929 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5947,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5966,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6024,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a6023 in k5944 in k5941 in k5932 in a5929 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6024(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6024,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,lf[321]));}

/* k5964 in k5944 in k5941 in k5932 in a5929 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5970,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5974,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5976,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a5975 in k5964 in k5944 in k5941 in k5932 in a5929 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5976(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5976,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5996,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t2);
/* map */
t7=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}

/* k5994 in a5975 in k5964 in k5944 in k5941 in k5932 in a5929 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6000,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6002,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[2]);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a6001 in k5994 in a5975 in k5964 in k5944 in k5941 in k5932 in a5929 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6002(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6002,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6010,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   lookup */
t4=((C_word*)t0)[2];
f_5947(3,t4,t3,t2);}

/* k6008 in a6001 in k5994 in a5975 in k5964 in k5944 in k5941 in k5932 in a5929 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6010,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[5],((C_word*)t0)[2],t1));}

/* k5998 in k5994 in a5975 in k5964 in k5944 in k5941 in k5932 in a5929 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_6000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6000,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[2],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[4],((C_word*)t0)[2],t3));}

/* k5972 in k5964 in k5944 in k5941 in k5932 in a5929 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5968 in k5964 in k5944 in k5941 in k5932 in a5929 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5970,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[79],t2));}

/* lookup in k5944 in k5941 in k5932 in a5929 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5947(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5947,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_876,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5909,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[320],t3);}

/* a5908 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5909(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5909,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5913,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 79   gensym */
t5=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k5911 in a5908 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5913,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,3,lf[319],t1,((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,3,lf[2],t1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[4],t2,t4));}

/* k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_876,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_955,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5899,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[316],t3);}

/* a5898 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5899(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5899,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_882,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[316],t2,lf[318]);}

/* k880 in a5898 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_882,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_891,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(((C_word*)t0)[3]);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=t5;
f_891(t9,(C_word)C_a_i_cons(&a,2,lf[2],t8));}
else{
t6=t5;
f_891(t6,(C_word)C_i_cadr(((C_word*)t0)[3]));}}

/* k889 in k880 in a5898 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_891(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_891,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_894,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_pairp(t1);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_907,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_907(t6,t4);}
else{
t6=(C_word)C_i_car(t1);
t7=(C_word)C_eqp(lf[2],t6);
t8=t5;
f_907(t8,(C_word)C_i_not(t7));}}

/* k905 in k889 in k880 in a5898 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_907(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken.scm: 79   syntax-error */
t2=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[316],lf[317],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_894(2,t2,C_SCHEME_UNDEFINED);}}

/* k892 in k889 in k880 in a5898 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_894,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[315],t3));}

/* k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_958,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5878,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[313],t3);}

/* a5877 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5878(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5878,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5882,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[313],t2,lf[314]);}

/* k5880 in a5877 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5882,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[312],t3,t4));}

/* k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_961,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5762,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[310],t3);}

/* a5761 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5762(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5762,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5766,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[310],t2,lf[311]);}

/* k5764 in a5761 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5766,2,t0,t1);}
t2=(C_word)C_i_listp(((C_word*)t0)[3]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5775,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_5775(t5,t3);}
else{
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=t4;
f_5775(t6,(C_word)C_fixnum_lessp(t5,C_fix(2)));}}

/* k5773 in k5764 in a5761 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_5775(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5775,NULL,2,t0,t1);}
if(C_truep(t1)){
/* chicken.scm: 79   ##sys#syntax-error-hook */
t2=C_retrieve(lf[308]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[309],((C_word*)t0)[2]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[2],C_fix(0));
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5789,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5789(t7,((C_word*)t0)[3],t2);}}

/* fold in k5773 in k5764 in a5761 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_5789(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(25);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5789,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[68],((C_word*)t0)[3]));}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_not_pair_p(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5818,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   fold */
t15=t5;
t16=t4;
t1=t15;
t2=t16;
goto loop;}
else{
t5=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t5))){
t6=(C_word)C_slot(t3,C_fix(0));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5835,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   fold */
t15=t7;
t16=t4;
t1=t15;
t2=t16;
goto loop;}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_i_cadr(t3);
t8=(C_word)C_a_i_list(&a,2,t6,t7);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5853,a[2]=t9,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 79   fold */
t15=t10;
t16=t4;
t1=t15;
t2=t16;
goto loop;}}}}

/* k5851 in fold in k5773 in k5764 in a5761 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5853,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[4],t1,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t2));}

/* k5833 in fold in k5773 in k5764 in a5761 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5835,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[2],t1,C_SCHEME_FALSE));}

/* k5816 in fold in k5773 in k5764 in a5761 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5818,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[2],t1,C_SCHEME_FALSE));}

/* k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_964,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5516,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[214],t3);}

/* a5515 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5516(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5516,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5519,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5529,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5671,a[2]=t3,a[3]=t5,a[4]=t8,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_5671(t10,t1,t2);}

/* expand in a5515 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_5671(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5671,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5685,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5687,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_slot(t4,C_fix(0));
t7=(C_word)C_eqp(t6,lf[86]);
if(C_truep(t7)){
t8=(C_word)C_slot(t4,C_fix(1));
t9=(C_word)C_eqp(t8,C_SCHEME_END_OF_LIST);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_truep(t9)?lf[307]:(C_word)C_a_i_cons(&a,2,lf[68],t8)));}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5742,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 79   test */
t9=((C_word*)((C_word*)t0)[3])[1];
f_5529(t9,t8,t6);}}
else{
/* chicken.scm: 79   err */
t6=((C_word*)t0)[2];
f_5519(t6,t1,t4);}}
else{
/* chicken.scm: 79   err */
t4=((C_word*)t0)[2];
f_5519(t4,t1,t2);}}}

/* k5740 in expand in a5515 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5742,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[68],t2));}
else{
/* chicken.scm: 79   expand */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5671(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* a5686 in expand in a5515 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5687(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5687,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k5683 in expand in a5515 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[279]+1),lf[306],t1);}

/* test in a5515 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_5529(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5529,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* chicken.scm: 79   ##sys#feature? */
t3=C_retrieve(lf[305]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_eqp(t4,lf[110]);
if(C_truep(t5)){
t6=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5578,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_slot(t3,C_fix(0));
/* chicken.scm: 79   test */
t17=t7;
t18=t8;
t1=t17;
t2=t18;
goto loop;}
else{
/* chicken.scm: 79   err */
t7=((C_word*)t0)[2];
f_5519(t7,t1,t2);}}}
else{
t6=(C_word)C_eqp(t4,lf[300]);
if(C_truep(t6)){
t7=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5617,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_slot(t3,C_fix(0));
/* chicken.scm: 79   test */
t17=t8;
t18=t9;
t1=t17;
t2=t18;
goto loop;}
else{
/* chicken.scm: 79   err */
t8=((C_word*)t0)[2];
f_5519(t8,t1,t2);}}}
else{
t7=(C_word)C_eqp(t4,lf[211]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5655,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cadr(t2);
/* chicken.scm: 79   test */
t17=t8;
t18=t9;
t1=t17;
t2=t18;
goto loop;}
else{
/* chicken.scm: 79   err */
t8=((C_word*)t0)[2];
f_5519(t8,t1,t2);}}}}
else{
/* chicken.scm: 79   err */
t3=((C_word*)t0)[2];
f_5519(t3,t1,t2);}}}

/* k5653 in test in a5515 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k5615 in test in a5515 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5617,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,lf[300],t2);
/* chicken.scm: 79   test */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5529(t4,((C_word*)t0)[4],t3);}}

/* k5576 in test in a5515 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5578,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,lf[110],t2);
/* chicken.scm: 79   test */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5529(t4,((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* err in a5515 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_5519(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5519,NULL,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,lf[214],((C_word*)t0)[2]);
/* chicken.scm: 79   ##sys#error */
t4=*((C_word*)lf[279]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[304],t2,t3);}

/* k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_967,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[6]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5417,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 79   ##sys#register-macro-2 */
t5=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[301],t4);}

/* a5416 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5417(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5417,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5427,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 79   gensym */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k5425 in a5416 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5427,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5438,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5440,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_5440(t8,t4,((C_word*)t0)[2]);}

/* expand in k5425 in a5416 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_5440(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5440,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5456,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 79   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[301],t3,lf[302]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[303]);}}

/* k5454 in expand in k5425 in a5416 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5456,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[86],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[68],t4));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5492,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5494,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[6]);
/* map */
t7=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}}

/* a5493 in k5454 in expand in k5425 in a5416 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5494(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5494,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[296],((C_word*)t0)[2],t2));}

/* k5490 in k5454 in expand in k5425 in a5416 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5492,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[300],t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,lf[68],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5484,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 79   expand */
t6=((C_word*)((C_word*)t0)[3])[1];
f_5440(t6,t5,((C_word*)t0)[2]);}

/* k5482 in k5490 in k5454 in expand in k5425 in a5416 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5484,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k5436 in k5425 in a5416 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5438,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_970,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[6]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5328,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 79   ##sys#register-macro-2 */
t5=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[297],t4);}

/* a5327 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5328(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5328,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5338,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 79   gensym */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k5336 in a5327 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5338,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5349,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5351,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_5351(t8,t4,((C_word*)t0)[2]);}

/* expand in k5336 in a5327 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_5351(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5351,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5367,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 79   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[297],t3,lf[298]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[299]);}}

/* k5365 in expand in k5336 in a5327 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5367,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[86],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[68],t4));}
else{
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,3,lf[296],((C_word*)t0)[4],t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_cons(&a,2,lf[68],t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5395,a[2]=t7,a[3]=t5,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 79   expand */
t9=((C_word*)((C_word*)t0)[3])[1];
f_5351(t9,t8,((C_word*)t0)[2]);}}

/* k5393 in k5365 in expand in k5336 in a5327 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5395,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k5347 in k5336 in a5327 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5349,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_973,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5042,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[293],t3);}

/* a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_5042r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5042r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5042r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5239,a[2]=t3,a[3]=t1,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 79   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[293],t3,lf[295]);}

/* k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5242,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 79   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[293],((C_word*)t0)[4],lf[294]);}

/* k5240 in k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[76]+1),((C_word*)t0)[2]);}

/* k5243 in k5240 in k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5246,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5261,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5318,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a5317 in k5243 in k5240 in k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5318(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5318,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5326,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 79   prefix-sym */
f_5246(t3,lf[292],t2);}

/* k5324 in a5317 in k5243 in k5240 in k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 79   gensym */
t2=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5259 in k5243 in k5240 in k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5264,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[291]+1),((C_word*)t0)[2]);}

/* k5262 in k5259 in k5243 in k5240 in k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5267,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken.scm: 79   gensym */
t3=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[290]);}

/* k5265 in k5262 in k5259 in k5243 in k5240 in k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5270,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken.scm: 79   gensym */
t3=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[289]);}

/* k5268 in k5265 in k5262 in k5259 in k5243 in k5240 in k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5273,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5308,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[8]);}

/* a5307 in k5268 in k5265 in k5262 in k5259 in k5243 in k5240 in k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5308(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5308,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5316,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 79   prefix-sym */
f_5246(t3,lf[288],t2);}

/* k5314 in a5307 in k5268 in k5265 in k5262 in k5259 in k5243 in k5240 in k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 79   gensym */
t2=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5271 in k5268 in k5265 in k5262 in k5259 in k5243 in k5240 in k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5273,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5276,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[5];
t5=t1;
t6=((C_word*)t0)[2];
t7=C_retrieve(lf[6]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5053,a[2]=t5,a[3]=t6,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 79   reverse */
t9=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t3);}

/* k5051 in k5271 in k5268 in k5265 in k5262 in k5259 in k5243 in k5240 in k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5053,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5057,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 79   reverse */
t3=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5055 in k5051 in k5271 in k5268 in k5265 in k5262 in k5259 in k5243 in k5240 in k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5061,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 79   reverse */
t3=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5059 in k5055 in k5051 in k5271 in k5268 in k5265 in k5262 in k5259 in k5243 in k5240 in k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5061,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5063,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_5063(t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* recur in k5059 in k5055 in k5051 in k5271 in k5268 in k5265 in k5262 in k5259 in k5243 in k5240 in k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_5063(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5063,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5108,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=t7,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* chicken.scm: 79   reverse */
t9=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t6);}}

/* k5106 in recur in k5059 in k5055 in k5051 in k5271 in k5268 in k5265 in k5262 in k5259 in k5243 in k5240 in k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5108,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5116,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5120,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   reverse */
t4=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5118 in k5106 in recur in k5059 in k5055 in k5051 in k5271 in k5268 in k5265 in k5262 in k5259 in k5243 in k5240 in k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5120,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k5114 in k5106 in recur in k5059 in k5055 in k5051 in k5271 in k5268 in k5265 in k5262 in k5259 in k5243 in k5240 in k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5116,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5084,a[2]=t4,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
t8=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 79   recur */
t9=((C_word*)((C_word*)t0)[3])[1];
f_5063(t9,t5,((C_word*)t0)[2],t6,t7,t8);}

/* k5082 in k5114 in k5106 in recur in k5059 in k5055 in k5051 in k5271 in k5268 in k5265 in k5262 in k5259 in k5243 in k5240 in k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5084,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in k5243 in k5240 in k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5279,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[9];
t7=C_retrieve(lf[6]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5136,a[2]=t9,a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_5136(t11,t2,t3,t4,C_SCHEME_END_OF_LIST);}

/* recur in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in k5243 in k5240 in k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_5136(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5136,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(C_word)C_a_i_list(&a,2,lf[74],((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,lf[111],t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5170,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 79   reverse */
t8=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_list(&a,2,lf[74],((C_word*)t0)[4]);
t7=(C_word)C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5236,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t6,a[7]=t1,a[8]=t5,a[9]=((C_word*)t0)[4],a[10]=t7,tmp=(C_word)a,a+=11,tmp);
/* chicken.scm: 79   reverse */
t9=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t4);}}

/* k5234 in recur in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in k5243 in k5240 in k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5236,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_list(&a,2,lf[76],((C_word*)t0)[9]);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_list(&a,2,lf[75],((C_word*)t0)[9]);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],t5);
t7=(C_word)C_a_i_list(&a,2,t4,t6);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5200,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[3]);
/* chicken.scm: 79   recur */
t12=((C_word*)((C_word*)t0)[2])[1];
f_5136(t12,t8,t9,t10,t11);}

/* k5198 in k5234 in recur in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in k5243 in k5240 in k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5200,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k5168 in recur in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in k5243 in k5240 in k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5170,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,2,lf[61],lf[287]);
t4=(C_word)C_a_i_list(&a,2,lf[278],t3);
t5=(C_word)C_a_i_list(&a,3,lf[279],t4,((C_word*)t0)[4]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[2],t2,t5));}

/* k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in k5243 in k5240 in k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5279,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,lf[2],t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,3,lf[286],t7,t1));}

/* prefix-sym in k5243 in k5240 in k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_5246(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5246,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5254,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5258,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   symbol->string */
t6=*((C_word*)lf[166]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}

/* k5256 in prefix-sym in k5243 in k5240 in k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 79   string-append */
t2=*((C_word*)lf[141]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5252 in prefix-sym in k5243 in k5240 in k5237 in a5041 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_5254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 79   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_976,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4985,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[283],t3);}

/* a4984 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4985(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4985,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4989,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 79   gensym */
t5=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k4987 in a4984 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[93],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4989,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,lf[74],t1);
t5=(C_word)C_a_i_list(&a,2,lf[75],t1);
t6=(C_word)C_a_i_list(&a,2,lf[74],t5);
t7=(C_word)C_a_i_list(&a,2,lf[111],t6);
t8=(C_word)C_a_i_list(&a,2,lf[76],t1);
t9=(C_word)C_a_i_list(&a,2,lf[61],lf[285]);
t10=(C_word)C_a_i_list(&a,2,lf[278],t9);
t11=(C_word)C_a_i_list(&a,3,lf[279],t10,t1);
t12=(C_word)C_a_i_list(&a,4,lf[72],t7,t8,t11);
t13=(C_word)C_a_i_list(&a,4,lf[72],t4,((C_word*)t0)[3],t12);
t14=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,3,lf[79],t3,t13));}

/* k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_979,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4979,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[284],t3);}

/* a4978 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4979(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4979,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[283],t2));}

/* k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_982,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4826,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[280],t3);}

/* a4825 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4826(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4826r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4826r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4826r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4830,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 79   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[280],t3,lf[282]);}

/* k4828 in a4825 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4830,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4833,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 79   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[280],((C_word*)t0)[3],lf[281]);}

/* k4831 in k4828 in a4825 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4833,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 79   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4834 in k4831 in k4828 in a4825 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4836,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4847,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4849,a[2]=t6,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4849(t8,t4,t1,((C_word*)t0)[2]);}

/* loop in k4834 in k4831 in k4828 in a4825 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_4849(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4849,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_a_i_list(&a,2,lf[74],t2);
t5=(C_word)C_a_i_list(&a,2,lf[111],t4);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,lf[79],t6);
t8=(C_word)C_a_i_list(&a,2,lf[61],lf[277]);
t9=(C_word)C_a_i_list(&a,2,lf[278],t8);
t10=(C_word)C_a_i_list(&a,3,lf[279],t9,t2);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[72],t5,t7,t10));}
else{
t4=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4899,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 79   gensym */
t6=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=(C_word)C_a_i_list(&a,2,t4,t2);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[3]);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[79],t7));}}}

/* k4897 in loop in k4834 in k4831 in k4828 in a4825 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[76],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4899,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,lf[74],((C_word*)t0)[5]);
t4=(C_word)C_i_cadr(((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,2,lf[76],((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,4,lf[72],t3,t4,t5);
t7=(C_word)C_a_i_list(&a,2,t2,t6);
t8=(C_word)C_a_i_list(&a,2,lf[74],((C_word*)t0)[5]);
t9=(C_word)C_a_i_list(&a,2,lf[61],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_list(&a,2,lf[75],((C_word*)t0)[5]);
t11=(C_word)C_a_i_list(&a,4,lf[72],t8,t9,t10);
t12=(C_word)C_a_i_list(&a,2,t1,t11);
t13=(C_word)C_a_i_list(&a,2,t7,t12);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4910,a[2]=t13,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken.scm: 79   loop */
t16=((C_word*)((C_word*)t0)[2])[1];
f_4849(t16,t14,t1,t15);}

/* k4908 in k4897 in loop in k4834 in k4831 in k4828 in a4825 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4910,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k4845 in k4834 in k4831 in k4828 in a4825 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4847,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_985,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4550,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[269],t3);}

/* a4549 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4550(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4550,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4584,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[269],t2,lf[276]);}

/* k4582 in a4549 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4587,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   require */
t3=C_retrieve(lf[274]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[275]);}

/* k4585 in k4582 in a4549 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4587,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4590,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4811,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4813,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a4812 in k4585 in k4582 in a4549 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4813(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4813,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4823,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#decompose-lambda-list */
t5=C_retrieve(lf[271]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a4822 in a4812 in k4585 in k4582 in a4549 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4823(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4823,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k4809 in k4585 in k4582 in a4549 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[273]+1),t1);}

/* k4588 in k4585 in k4582 in a4549 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4593,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=t1;
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4559,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4559(t7,t2,C_fix(0));}

/* loop in k4588 in k4585 in k4582 in a4549 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_4559(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4559,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4573,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 79   gensym */
t4=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k4571 in loop in k4588 in k4585 in k4582 in a4549 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4573,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4577,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* chicken.scm: 79   loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4559(t4,t2,t3);}

/* k4575 in k4571 in loop in k4588 in k4585 in k4582 in a4549 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4577,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4591 in k4588 in k4585 in k4582 in a4549 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4593,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4596,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 79   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4594 in k4591 in k4588 in k4585 in k4582 in a4549 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4596,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4599,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 79   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4597 in k4594 in k4591 in k4588 in k4585 in k4582 in a4549 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4599,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4606,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 79   append */
t3=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[6]);}

/* k4604 in k4597 in k4594 in k4591 in k4588 in k4585 in k4582 in a4549 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4606,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[265],((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4618,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4620,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 79   fold-right */
t7=C_retrieve(lf[161]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,t6,lf[272],((C_word*)t0)[2]);}

/* a4619 in k4604 in k4597 in k4594 in k4591 in k4588 in k4585 in k4582 in a4549 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4620(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4620,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4630,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 79   ##sys#decompose-lambda-list */
t6=C_retrieve(lf[271]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t4,t5);}

/* a4629 in a4619 in k4604 in k4597 in k4594 in k4591 in k4588 in k4585 in k4582 in a4549 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4630(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4630,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4634,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=((C_word*)t0)[7],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* chicken.scm: 79   ##sys#check-syntax */
t7=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,lf[269],t6,lf[270]);}

/* k4632 in a4629 in a4619 in k4604 in k4597 in k4594 in k4591 in k4588 in k4585 in k4582 in a4549 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4634,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[11],((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4644,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=(C_word)C_eqp(t2,C_fix(0));
t5=t3;
f_4644(t5,(C_truep(t4)?C_SCHEME_TRUE:(C_word)C_a_i_list(&a,3,lf[108],((C_word*)t0)[2],t2)));}
else{
t4=t3;
f_4644(t4,(C_word)C_a_i_list(&a,3,lf[268],((C_word*)t0)[2],t2));}}

/* k4642 in k4632 in a4629 in a4619 in k4604 in k4597 in k4594 in k4591 in k4588 in k4585 in k4582 in a4549 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_4644(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4644,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4648,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4650,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4660,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 79   ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a4659 in k4642 in k4632 in a4629 in a4619 in k4604 in k4597 in k4594 in k4591 in k4588 in k4585 in k4582 in a4549 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4660(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4660,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4664,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4679,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4679(t8,t4,t3,((C_word*)t0)[2]);}

/* build in a4659 in k4642 in k4632 in a4629 in a4619 in k4604 in k4597 in k4594 in k4591 in k4588 in k4585 in k4582 in a4549 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_4679(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4679,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[4])){
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[79],t7));}
else{
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cadr(((C_word*)t0)[3]));}
else{
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[79],t6));}}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4735,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 79   gensym */
t5=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k4733 in build in a4659 in k4642 in k4632 in a4629 in a4619 in k4604 in k4597 in k4594 in k4591 in k4588 in k4585 in k4582 in a4549 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4735,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,lf[76],((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,2,lf[75],((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,t1,t5);
t7=(C_word)C_a_i_list(&a,2,t4,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4746,a[2]=t7,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken.scm: 79   build */
t11=((C_word*)((C_word*)t0)[2])[1];
f_4679(t11,t8,t10,t1);}
else{
/* chicken.scm: 79   build */
t10=((C_word*)((C_word*)t0)[2])[1];
f_4679(t10,t8,C_SCHEME_END_OF_LIST,t1);}}

/* k4744 in k4733 in build in a4659 in k4642 in k4632 in a4629 in a4619 in k4604 in k4597 in k4594 in k4591 in k4588 in k4585 in k4582 in a4549 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4746,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k4662 in a4659 in k4642 in k4632 in a4629 in a4619 in k4604 in k4597 in k4594 in k4591 in k4588 in k4585 in k4582 in a4549 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4664,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4677,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   map */
t3=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[71]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k4675 in k4662 in a4659 in k4642 in k4632 in a4629 in a4619 in k4604 in k4597 in k4594 in k4591 in k4588 in k4585 in k4582 in a4549 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4677,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],t1,((C_word*)t0)[2]));}

/* a4649 in k4642 in k4632 in a4629 in a4619 in k4604 in k4597 in k4594 in k4591 in k4588 in k4585 in k4582 in a4549 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4658,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   take */
t3=C_retrieve(lf[267]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4656 in a4649 in k4642 in k4632 in a4629 in a4619 in k4604 in k4597 in k4594 in k4591 in k4588 in k4585 in k4582 in a4549 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 79   split-at! */
t2=C_retrieve(lf[266]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4646 in k4642 in k4632 in a4629 in a4619 in k4604 in k4597 in k4594 in k4591 in k4588 in k4585 in k4582 in a4549 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4648,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[3],t1,((C_word*)t0)[2]));}

/* k4616 in k4604 in k4597 in k4594 in k4591 in k4588 in k4585 in k4582 in a4549 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4618,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[2],t2));}

/* k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_988,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4493,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[262],t3);}

/* a4492 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4493(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr3r,(void*)f_4493r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4493r(t0,t1,t2,t3);}}

static void C_ccall f_4493r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(16);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4503,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* chicken.scm: 79   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,lf[262],t5,lf[263]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4533,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* chicken.scm: 79   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,lf[262],t5,lf[264]);}}

/* k4531 in a4492 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4533,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[261],t3));}

/* k4501 in a4492 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4503,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(0));
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=(C_word)C_a_i_cons(&a,2,lf[2],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[261],t3,t6));}

/* k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_991,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4417,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[254],t3);}

/* a4416 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4417(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4417r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4417r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4417r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4421,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 79   gensym */
t6=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k4419 in a4416 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4424,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 79   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4422 in k4419 in a4416 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[114],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4424,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_list(&a,3,lf[2],t3,t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t8=(C_word)C_a_i_cons(&a,2,lf[2],t7);
t9=(C_word)C_a_i_list(&a,3,lf[257],lf[258],t1);
t10=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t9);
t11=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t10);
t12=(C_word)C_a_i_list(&a,3,lf[2],t1,t11);
t13=(C_word)C_a_i_list(&a,3,lf[4],t8,t12);
t14=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t13);
t15=(C_word)C_a_i_list(&a,3,lf[259],t6,t14);
t16=(C_word)C_a_i_list(&a,3,lf[2],t2,t15);
t17=(C_word)C_a_i_list(&a,2,lf[260],t16);
t18=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_list(&a,1,t17));}

/* k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_994,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4233,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[256],t3);}

/* a4232 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4233(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4233r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4233r(t0,t1,t2,t3);}}

static void C_ccall f_4233r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4237,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 79   gensym */
t5=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k4235 in a4232 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4240,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 79   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4238 in k4235 in a4232 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4242,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,2,lf[61],lf[252]);
t4=(C_word)C_a_i_list(&a,3,lf[242],((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_list(&a,3,lf[253],((C_word*)t0)[5],C_fix(1));
t6=(C_word)C_a_i_list(&a,3,lf[110],t4,t5);
t7=(C_word)C_a_i_list(&a,2,t1,t6);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4379,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4383,a[2]=t9,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t11=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,t2,((C_word*)t0)[2]);}

/* k4381 in k4238 in k4235 in a4232 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4383,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[255],((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[86],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* ##sys#append */
t5=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k4377 in k4238 in k4235 in a4232 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4379,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[83],t1);
t3=(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[5],t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,4,lf[254],((C_word*)t0)[3],t3,((C_word*)t0)[2]));}

/* parse-clause in k4238 in k4235 in a4232 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4242(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[34],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4242,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_symbolp(t3);
t5=(C_truep(t4)?(C_word)C_i_car(t2):C_SCHEME_FALSE);
t6=(C_truep(t5)?(C_word)C_i_cadr(t2):(C_word)C_i_car(t2));
t7=(C_truep(t5)?(C_word)C_i_cddr(t2):(C_word)C_i_cdr(t2));
if(C_truep((C_word)C_i_nullp(t6))){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4265,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t5)){
t9=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[3]);
t10=(C_word)C_a_i_list(&a,1,t9);
t11=(C_word)C_a_i_cons(&a,2,t10,t7);
t12=t8;
f_4265(t12,(C_word)C_a_i_cons(&a,2,lf[79],t11));}
else{
t9=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t7);
t10=t8;
f_4265(t10,(C_word)C_a_i_cons(&a,2,lf[79],t9));}}
else{
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4328,a[2]=t7,a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4330,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t10=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t9,t6);}}

/* a4329 in parse-clause in k4238 in k4235 in a4232 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4330(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4330,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[251],t3,((C_word*)t0)[2]));}

/* k4326 in parse-clause in k4238 in k4235 in a4232 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4328,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[110],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4298,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[2]);
t8=t4;
f_4298(t8,(C_word)C_a_i_cons(&a,2,lf[79],t7));}
else{
t5=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t6=t4;
f_4298(t6,(C_word)C_a_i_cons(&a,2,lf[79],t5));}}

/* k4296 in k4326 in parse-clause in k4238 in k4235 in a4232 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_4298(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4298,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k4263 in parse-clause in k4238 in k4235 in a4232 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_4265(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4265,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[86],t1));}

/* k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_997,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4043,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[250],t3);}

/* a4042 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4043(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_4043r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_4043r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_4043r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t6=(C_word)C_i_cdr(t3);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4050,a[2]=t6,a[3]=t5,a[4]=t1,a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* map */
t8=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,*((C_word*)lf[76]+1),t5);}

/* k4048 in a4042 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4050,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4222,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4224,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a4223 in k4048 in a4042 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4224(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4224,3,t0,t1,t2);}
t3=(C_word)C_i_memq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:lf[249]));}

/* k4220 in k4048 in a4042 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4222,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[240],t2);
t4=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],lf[241]);
t6=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t7=(C_word)C_a_i_list(&a,3,lf[242],lf[241],t6);
t8=(C_word)C_a_i_list(&a,3,lf[82],t5,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4073,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4075,a[2]=t11,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t13=((C_word*)t11)[1];
f_4075(t13,t9,((C_word*)t0)[2],C_fix(1));}

/* loop in k4220 in k4048 in a4042 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_4075(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[112],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4075,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_memq(lf[243],C_retrieve(lf[55]));
t6=(C_word)C_i_cddr(t4);
t7=(C_word)C_i_pairp(t6);
t8=(C_word)C_a_i_list(&a,1,lf[241]);
t9=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[3]);
t10=(C_word)C_a_i_list(&a,3,lf[244],lf[241],t9);
t11=(C_word)C_a_i_list(&a,2,lf[111],t10);
t12=(C_word)C_a_i_list(&a,3,lf[245],lf[241],t3);
t13=(C_word)C_a_i_list(&a,4,lf[2],t8,t11,t12);
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4101,a[2]=t13,a[3]=t5,a[4]=t7,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,a[8]=t1,a[9]=t4,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t7)){
t15=(C_word)C_i_caddr(t4);
t16=(C_word)C_a_i_list(&a,3,t15,lf[241],lf[247]);
t17=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[3]);
t18=(C_word)C_a_i_list(&a,3,lf[244],lf[241],t17);
t19=(C_word)C_a_i_list(&a,2,lf[111],t18);
t20=(C_word)C_a_i_list(&a,4,lf[248],lf[241],t3,lf[247]);
t21=(C_word)C_a_i_list(&a,4,lf[82],t16,t19,t20);
t22=t14;
f_4101(t22,(C_word)C_a_i_list(&a,1,t21));}
else{
t15=t14;
f_4101(t15,C_SCHEME_END_OF_LIST);}}}

/* k4099 in loop in k4220 in k4048 in a4042 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_4101(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4101,NULL,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4129,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[3]:C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[9]);
t6=t3;
f_4129(t6,(C_word)C_a_i_list(&a,3,lf[246],((C_word*)t0)[2],t5));}
else{
t5=t3;
f_4129(t5,((C_word*)t0)[2]);}}

/* k4127 in k4099 in loop in k4220 in k4048 in a4042 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_4129(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4129,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4113,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* chicken.scm: 79   loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_4075(t6,t3,t4,t5);}

/* k4111 in k4127 in k4099 in loop in k4220 in k4048 in a4042 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4113,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* ##sys#append */
t3=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4071 in k4220 in k4048 in a4042 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4073,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[68],t3));}

/* k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1000,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4034,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[238],t3);}

/* a4033 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4034(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4034,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4038,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[238],t2,lf[239]);}

/* k4036 in a4033 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4038,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[237],((C_word*)t0)[2]));}

/* k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1003,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4015,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[235],t3);}

/* a4014 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4015(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4015,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4019,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[235],t2,lf[236]);}

/* k4017 in a4014 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4026,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4028,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4027 in k4017 in a4014 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4028(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4028,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k4024 in k4017 in a4014 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4026,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[232],t1));}

/* k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1006,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3996,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[233],t3);}

/* a3995 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3996(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3996,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4000,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[233],t2,lf[234]);}

/* k3998 in a3995 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4007,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4009,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4008 in k3998 in a3995 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4009(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4009,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k4005 in k3998 in a3995 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_4007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4007,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[232],t1));}

/* k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1009,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3868,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[231],t3);}

/* a3867 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3868(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3868,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3874,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3874(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in a3867 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_3874(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(15);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3874,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3884,a[2]=t4,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 79   reverse */
t7=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t3);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[228]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3955,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 79   gensym */
t9=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t9))(2,t9,t8);}
else{
t8=(C_word)C_eqp(t6,lf[229]);
if(C_truep(t8)){
/* chicken.scm: 79   loop */
t15=t1;
t16=C_SCHEME_END_OF_LIST;
t17=t3;
t18=t4;
t19=C_SCHEME_TRUE;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
t5=t19;
goto loop;}
else{
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_car(t2);
t11=(C_word)C_a_i_cons(&a,2,t10,t4);
/* chicken.scm: 79   loop */
t15=t1;
t16=t9;
t17=t3;
t18=t11;
t19=C_SCHEME_FALSE;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
t5=t19;
goto loop;}}}}

/* k3953 in loop in a3867 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3955,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* chicken.scm: 79   loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3874(t5,((C_word*)t0)[2],t2,t3,t4,C_SCHEME_FALSE);}

/* k3882 in loop in a3867 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3887,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 79   reverse */
t3=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3885 in k3882 in loop in a3867 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3887,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 79   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_a_i_list(&a,2,lf[68],t2);
t4=(C_word)C_i_cdr(t1);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[2],t5));}}

/* k3891 in k3885 in k3882 in loop in a3867 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3900,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k3898 in k3891 in k3885 in k3882 in loop in a3867 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3900,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3916,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* ##sys#append */
t6=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k3914 in k3898 in k3891 in k3885 in k3882 in loop in a3867 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3916,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[227],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[2],t3));}

/* k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1012,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3725,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[230],t3);}

/* a3724 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3725(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3725,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3731,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3731(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in a3724 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_3731(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(22);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3731,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t2))){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3741,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 79   reverse */
t8=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_eqp(t7,lf[228]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3816,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 79   gensym */
t10=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t10))(2,t10,t9);}
else{
t9=(C_word)C_eqp(t7,lf[229]);
if(C_truep(t9)){
/* chicken.scm: 79   loop */
t14=t1;
t15=C_SCHEME_END_OF_LIST;
t16=t3;
t17=t4;
t18=t5;
t19=C_SCHEME_TRUE;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
t5=t18;
t6=t19;
goto loop;}
else{
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3843,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t4,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 79   gensym */
t11=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t11))(2,t11,t10);}}}}

/* k3841 in loop in a3724 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3843,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
t6=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* chicken.scm: 79   loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_3731(t7,((C_word*)t0)[3],t2,((C_word*)t0)[2],t5,t6,C_SCHEME_FALSE);}

/* k3814 in loop in a3724 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3816,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* chicken.scm: 79   loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3731(t5,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2],t4,C_SCHEME_FALSE);}

/* k3739 in loop in a3724 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3744,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 79   reverse */
t3=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3742 in k3739 in loop in a3724 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3744,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3750,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 79   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[2],t4);
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[3],t5));}}

/* k3748 in k3742 in k3739 in loop in a3724 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3761,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k3759 in k3748 in k3742 in k3739 in loop in a3724 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3761,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3777,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* ##sys#append */
t6=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k3775 in k3759 in k3748 in k3742 in k3739 in loop in a3724 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3777,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[227],t2);
t4=(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t4));}

/* k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1015,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3666,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[226],t3);}

/* a3665 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc_2(c,6,t0);
if(!C_demand(c*C_SIZEOF_PAIR+51)){
C_save_and_reclaim((void*)tr6r,(void*)f_3666r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_3666r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_3666r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(51);
t7=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_i_caddr(t2);
t9=(C_word)C_i_car(t2);
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_a_i_list(&a,3,t8,t9,t10);
t12=(C_word)C_a_i_list(&a,4,lf[223],t3,t4,t5);
t13=(C_word)C_a_i_cons(&a,2,t12,t6);
t14=(C_word)C_a_i_cons(&a,2,t11,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[224],t14));}
else{
t8=(C_word)C_a_i_list(&a,4,lf[225],t3,t4,t5);
t9=(C_word)C_a_i_cons(&a,2,t8,t6);
t10=(C_word)C_a_i_cons(&a,2,t2,t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[224],t10));}}

/* k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1018,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3495,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[220],t3);}

/* a3494 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3495(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_3495r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3495r(t0,t1,t2,t3);}}

static void C_ccall f_3495r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3501,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3501(t7,t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t3,C_SCHEME_FALSE);}

/* loop in a3494 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_3501(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3501,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t4))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3511,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=(C_word)C_a_i_cons(&a,2,lf[215],t5);
t8=t6;
f_3511(t8,(C_word)C_a_i_list(&a,2,lf[133],t7));}
else{
t7=t6;
f_3511(t7,lf[216]);}}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3575,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_i_car(t4);
t8=t6;
f_3575(t8,(C_word)C_i_pairp(t7));}
else{
t7=t6;
f_3575(t7,C_SCHEME_FALSE);}}}

/* k3573 in loop in a3494 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_3575(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3575,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3578,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 79   caar */
t3=*((C_word*)lf[152]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
/* chicken.scm: 79   syntax-error */
t2=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[220],lf[222],((C_word*)t0)[7]);}}

/* k3576 in k3573 in loop in a3494 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3578,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_eqp(lf[217],t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3602,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 79   cdar */
t5=*((C_word*)lf[218]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(lf[219],t1);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3623,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 79   cdar */
t6=*((C_word*)lf[218]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(lf[215],t1);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3636,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=((C_word*)t0)[2];
t8=(C_truep(t7)?t7:C_SCHEME_END_OF_LIST);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3644,a[2]=t8,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   cdar */
t10=*((C_word*)lf[218]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[7]);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3651,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 79   caar */
t7=*((C_word*)lf[152]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[7]);}}}}

/* k3649 in k3576 in k3573 in loop in a3494 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 79   syntax-error */
t2=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[220],lf[221],t1);}

/* k3642 in k3576 in k3573 in loop in a3494 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 79   append */
t2=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3634 in k3576 in k3573 in loop in a3494 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 79   loop */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3501(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3621 in k3576 in k3573 in loop in a3494 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3623,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[68],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* chicken.scm: 79   loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3501(t4,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3600 in k3576 in k3573 in loop in a3494 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3602,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[68],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* chicken.scm: 79   loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3501(t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3509 in loop in a3494 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_3511(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[63],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3511,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,lf[210],t2);
t4=(C_word)C_a_i_list(&a,2,lf[211],lf[54]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,lf[212],((C_word*)t0)[4]);
t7=(C_word)C_a_i_list(&a,2,lf[133],t6);
t8=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t9=(C_word)C_a_i_list(&a,2,lf[213],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)t0)[3]);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,t7,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[86],t12);
t14=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,4,lf[214],t3,t5,t13));}

/* k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1021,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3444,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[209],t3);}

/* a3443 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3444(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+39)){
C_save_and_reclaim((void*)tr3r,(void*)f_3444r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3444r(t0,t1,t2,t3);}}

static void C_ccall f_3444r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(39);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,t5,t3);
t7=(C_word)C_a_i_cons(&a,2,lf[2],t6);
t8=(C_word)C_a_i_list(&a,2,t4,t7);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(C_word)C_i_car(t2);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,3,lf[208],t9,t10));}
else{
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[208],t5,t2));}}

/* k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1024,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3384,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[206],t3);}

/* a3383 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3384(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_3384r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3384r(t0,t1,t2,t3);}}

static void C_ccall f_3384r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[203]:t3);
t6=(C_word)C_i_pairp(t2);
t7=(C_truep(t6)?(C_word)C_i_car(t2):t2);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3394,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,t5);
t11=t8;
f_3394(t11,(C_word)C_a_i_cons(&a,2,lf[2],t10));}
else{
t9=t8;
f_3394(t9,(C_word)C_i_car(t5));}}

/* k3392 in a3383 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_3394(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3394,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3397,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3413,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 79   eval */
t4=C_retrieve(lf[147]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}
else{
/* chicken.scm: 79   syntax-error */
t3=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[206],lf[207],((C_word*)t0)[2]);}}

/* k3411 in k3392 in a3383 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3397(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* k3395 in k3392 in a3383 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3397,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[204]))?(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[3],((C_word*)t0)[2]):lf[205]));}

/* k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1027,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 79   register-feature! */
t3=C_retrieve(lf[196]);
((C_proc8)C_retrieve_proc(t3))(8,t3,t2,lf[197],lf[198],lf[199],lf[200],lf[201],lf[202]);}

/* k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1030,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3347,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 80   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[84],t3);}

/* a3346 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3347(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3347,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3351,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 80   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[84],t2,lf[195]);}

/* k3349 in a3346 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3351,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,2,lf[61],t4);
t6=(C_word)C_i_cddr(((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,t3,t7);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[194],t8));}

/* k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1033,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3328,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 80   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[90],t3);}

/* a3327 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3328(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3328,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3332,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 80   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[90],t2,lf[193]);}

/* k3330 in a3327 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3339,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3341,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3340 in k3330 in a3327 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3341(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3341,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3337 in k3330 in a3327 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3339,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[164],t1));}

/* k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1036,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3309,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 80   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[191],t3);}

/* a3308 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3309(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3309,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3313,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 80   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[191],t2,lf[192]);}

/* k3311 in a3308 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3320,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3322,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3321 in k3311 in a3308 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3322(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3322,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3318 in k3311 in a3308 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3320,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[190],t1));}

/* k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1039,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3290,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 80   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[107],t3);}

/* a3289 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3290(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3290,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3294,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 80   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[107],t2,lf[189]);}

/* k3292 in a3289 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3301,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3303,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3302 in k3292 in a3289 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3303(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3303,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3299 in k3292 in a3289 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3301,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[188],t1));}

/* k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1039,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1042,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3271,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 80   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[186],t3);}

/* a3270 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3271(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3271,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3275,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 80   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[186],t2,lf[187]);}

/* k3273 in a3270 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3282,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3284,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3283 in k3273 in a3270 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3284(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3284,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3280 in k3273 in a3270 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3282,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[185],t1));}

/* k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1045,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3252,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 80   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[183],t3);}

/* a3251 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3252(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3252,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3256,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 80   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[183],t2,lf[184]);}

/* k3254 in a3251 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3263,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3265,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3264 in k3254 in a3251 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3265(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3265,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3261 in k3254 in a3251 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3263,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[182],t1));}

/* k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1048,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3233,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 80   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[180],t3);}

/* a3232 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3233(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3233,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3237,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 80   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[180],t2,lf[181]);}

/* k3235 in a3232 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3244,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3246,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3245 in k3235 in a3232 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3246(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3246,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3242 in k3235 in a3232 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3244,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[179],t1));}

/* k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1051,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3133,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 80   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[174],t3);}

/* a3132 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3133(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3133,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3137,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 80   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[174],t2,lf[178]);}

/* k3135 in a3132 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3137,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_stringp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3146,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 80   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[174],((C_word*)t0)[3],lf[175]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3192,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 80   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[174],((C_word*)t0)[3],lf[177]);}}

/* k3190 in k3135 in a3132 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3192,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_a_i_list(&a,2,lf[61],lf[176]);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(C_word)C_a_i_list(&a,2,lf[61],t5);
t7=(C_word)C_i_caddr(((C_word*)t0)[3]);
t8=(C_word)C_a_i_list(&a,2,lf[61],t7);
t9=(C_word)C_i_cadddr(((C_word*)t0)[3]);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,6,lf[171],t3,t4,t6,t8,t9));}

/* k3144 in k3135 in a3132 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3146,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_i_caddr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,2,lf[61],t4);
t6=(C_word)C_i_car(((C_word*)t0)[3]);
t7=(C_word)C_a_i_list(&a,2,lf[61],t6);
t8=(C_word)C_i_cadddr(((C_word*)t0)[3]);
t9=(C_word)C_a_i_list(&a,2,lf[61],t8);
t10=(C_word)C_i_cdr(((C_word*)t0)[3]);
t11=(C_word)C_i_cadddr(t10);
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_list(&a,6,lf[171],t3,t5,t7,t9,t11));}

/* k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1054,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2913,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 80   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[168],t3);}

/* a2912 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2913(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2913,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2917,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=t3;
f_2917(t5,(C_word)C_i_stringp(t4));}
else{
t4=t3;
f_2917(t4,C_SCHEME_FALSE);}}

/* k2915 in a2912 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_2917(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2917,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2920,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=t1;
if(C_truep(t3)){
t4=t2;
f_2920(t4,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=t2;
f_2920(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t2;
f_2920(t4,C_SCHEME_FALSE);}}}

/* k2918 in k2915 in a2912 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_2920(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2920,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2926,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 80   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[168],((C_word*)t0)[4],lf[169]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3001,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* chicken.scm: 80   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[168],((C_word*)t0)[4],lf[172]);}
else{
/* chicken.scm: 80   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[168],((C_word*)t0)[4],lf[173]);}}}

/* k2999 in k2918 in k2915 in a2912 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3001,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cadr(((C_word*)t0)[3]):(C_word)C_i_car(((C_word*)t0)[3]));
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_list(&a,2,lf[61],t5);
t7=(C_truep(((C_word*)t0)[4])?(C_word)C_i_car(((C_word*)t0)[3]):lf[170]);
t8=(C_word)C_a_i_list(&a,2,lf[61],t7);
t9=(C_truep(((C_word*)t0)[4])?(C_word)C_i_caddr(((C_word*)t0)[3]):(C_word)C_i_cadr(((C_word*)t0)[3]));
t10=(C_word)C_a_i_list(&a,2,lf[61],t9);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3066,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t10,a[6]=t8,a[7]=t6,a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[4],tmp=(C_word)a,a+=10,tmp);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3068,tmp=(C_word)a,a+=2,tmp);
/* map */
t13=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,t12,t3);}

/* a3067 in k2999 in k2918 in k2915 in a2912 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3068(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3068,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k3064 in k2999 in k2918 in k2915 in a2912 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3066,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3046,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3058,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a3057 in k3064 in k2999 in k2918 in k2915 in a2912 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3058(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3058,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k3044 in k3064 in k2999 in k2918 in k2915 in a2912 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_3046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3046,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[9])?(C_word)C_i_cdddr(((C_word*)t0)[8]):(C_word)C_i_cddr(((C_word*)t0)[8]));
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[2],t3);
t5=(C_word)C_a_i_list(&a,6,lf[171],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[2],t5));}

/* k2924 in k2918 in k2915 in a2912 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[68],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2926,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,2,lf[61],t4);
t6=(C_word)C_a_i_list(&a,3,lf[164],t3,t5);
t7=(C_word)C_a_i_list(&a,2,lf[61],t2);
t8=(C_word)C_i_cadr(((C_word*)t0)[3]);
t9=(C_word)C_a_i_list(&a,2,lf[61],t8);
t10=(C_word)C_a_i_list(&a,2,lf[61],C_SCHEME_TRUE);
t11=(C_word)C_a_i_list(&a,4,lf[165],t7,t9,t10);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2952,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
t13=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t13))){
t14=(C_word)C_i_caddr(((C_word*)t0)[3]);
t15=(C_word)C_a_i_list(&a,3,lf[5],t2,t14);
t16=t12;
f_2952(t16,(C_word)C_a_i_list(&a,1,t15));}
else{
t14=t12;
f_2952(t14,C_SCHEME_END_OF_LIST);}}

/* k2950 in k2924 in k2918 in k2915 in a2912 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_2952(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2952,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[68],t3));}

/* k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1057,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2838,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 80   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[167],t3);}

/* a2837 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2838(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2838r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2838r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2838r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2842,a[2]=t4,a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 80   gensym */
t6=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k2840 in a2837 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2842,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2911,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* chicken.scm: 80   symbol->string */
t5=*((C_word*)lf[166]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}

/* k2909 in k2840 in a2837 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[74],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2911,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],t1);
t3=(C_word)C_a_i_list(&a,4,lf[164],((C_word*)t0)[8],((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,lf[61],C_SCHEME_FALSE);
t7=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t8=(C_word)C_a_i_list(&a,5,lf[165],t4,t5,t6,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2865,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[2]))){
t10=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t11=(C_word)C_a_i_list(&a,3,lf[5],((C_word*)t0)[6],t10);
t12=t9;
f_2865(t12,(C_word)C_a_i_list(&a,1,t11));}
else{
t10=t9;
f_2865(t10,C_SCHEME_END_OF_LIST);}}

/* k2863 in k2909 in k2840 in a2837 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_2865(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2865,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[68],t3));}

/* k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1060,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2732,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 80   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[163],t3);}

/* a2731 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2732(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_2732r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2732r(t0,t1,t2,t3);}}

static void C_ccall f_2732r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2736,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2832,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a2831 in a2731 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2832(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2832,3,t0,t1,t2);}
/* chicken.scm: 80   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k2734 in a2731 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2743,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2808,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 80   append-map */
t4=C_retrieve(lf[162]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],t1);}

/* a2807 in k2734 in a2731 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2808(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2808,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cddr(t2);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}}

/* k2741 in k2734 in a2731 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2747,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2749,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t5=(C_word)C_a_i_cons(&a,2,lf[79],t4);
/* chicken.scm: 80   fold-right */
t6=C_retrieve(lf[161]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t2,t3,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2748 in k2741 in k2734 in a2731 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[51],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2749,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t2);
t6=(C_word)C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_a_i_list(&a,2,lf[61],t7);
t9=(C_word)C_i_cadr(t2);
t10=(C_word)C_a_i_list(&a,2,lf[61],t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,5,lf[160],t8,t10,t3,t4));}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_a_i_list(&a,2,lf[61],t7);
t9=(C_word)C_i_cadr(t2);
t10=(C_word)C_a_i_list(&a,2,lf[61],t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[160],t8,t10,t4));}}

/* k2745 in k2741 in k2734 in a2731 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2747,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1063,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2703,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 80   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[159],t3);}

/* a2702 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2703(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2703,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2707,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 80   gensym */
t4=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[155]);}

/* k2705 in a2702 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2726,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2730,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 80   string-intersperse */
t4=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[158]);}

/* k2728 in k2705 in a2702 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 80   sprintf */
t2=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[157],((C_word*)t0)[2],t1);}

/* k2724 in k2705 in a2702 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2726,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[98],t1);
t3=(C_word)C_a_i_list(&a,2,lf[133],t2);
t4=(C_word)C_a_i_list(&a,2,lf[130],((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[68],t3,t4));}

/* k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1066,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2690,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 80   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[156],t3);}

/* a2689 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2690,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2694,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 80   gensym */
t5=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[155]);}

/* k2692 in a2689 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2694,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[90],t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[68],t2,t1));}

/* k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1069,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1896,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 80   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[112],t3);}

/* a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1896(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_1896r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1896r(t0,t1,t2,t3);}}

static void C_ccall f_1896r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1900,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cadr(t2);
/* chicken.scm: 80   ->string */
t7=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
/* chicken.scm: 80   sprintf */
t6=C_retrieve(lf[62]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[154],t2);}}

/* k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1900,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[4]):((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1906,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 80   gensym */
t5=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1906,2,t0,t1);}
t2=*((C_word*)lf[101]+1);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1909,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=t1,a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
/* chicken.scm: 80   gensym */
t9=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t9))(2,t9,t8);}

/* k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1912,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken.scm: 80   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1915,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* chicken.scm: 80   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1915,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1917,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t7=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1960,a[2]=t5,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=t5,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t1,a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[11],tmp=(C_word)a,a+=16,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2582,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=t10,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_2582(t12,t8,((C_word*)((C_word*)t0)[6])[1]);}

/* do562 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_2582(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2582,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_2592(t5,t3);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_pairp(t5);
t7=(C_word)C_i_not(t6);
if(C_truep(t7)){
t8=t4;
f_2592(t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2657,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2661,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 80   caar */
t10=*((C_word*)lf[152]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t2);}}}

/* k2659 in do562 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 80   keyword? */
t2=C_retrieve(lf[153]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2655 in do562 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2592(t2,(C_word)C_i_not(t1));}

/* k2590 in do562 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_2592(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2592,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2596,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 80   caar */
t3=*((C_word*)lf[152]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}}

/* k2594 in k2590 in do562 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2596,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2599,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[146]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2613,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2617,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 80   cadar */
t6=*((C_word*)lf[148]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(t1,lf[149]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2627,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 80   cadar */
t6=*((C_word*)lf[148]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(t1,lf[150]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2637,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 80   cadar */
t7=*((C_word*)lf[148]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[7]);}
else{
t6=(C_word)C_i_car(((C_word*)t0)[7]);
/* chicken.scm: 80   syntax-error */
t7=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t2,lf[112],lf[151],t6);}}}}

/* k2635 in k2594 in k2590 in do562 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2599(2,t3,t2);}

/* k2625 in k2594 in k2590 in do562 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2599(2,t3,t2);}

/* k2615 in k2594 in k2590 in do562 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 80   eval */
t2=C_retrieve(lf[147]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2611 in k2594 in k2590 in do562 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2599(2,t3,t2);}

/* k2597 in k2594 in k2590 in do562 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2582(t3,((C_word*)t0)[2],t2);}

/* k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2006,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t3=(C_word)C_a_i_list(&a,2,lf[104],((C_word*)t0)[3]);
/* chicken.scm: 80   ##sys#hash-table-set! */
t4=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[145]),((C_word*)t0)[14],t3);}

/* k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2013,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2017,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=t2,tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=t3;
f_2017(t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2489,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2493,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2505,a[2]=((C_word*)t0)[6],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2576,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 80   ->string */
t8=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[2]);}}

/* k2574 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 80   string-append */
t2=*((C_word*)lf[141]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[142],t1,lf[143]);}

/* k2503 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2509,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2511,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a2510 in k2503 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2511(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2511,3,t0,t1,t2);}
t3=(C_word)C_i_length(t2);
switch(t3){
case C_fix(3):
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2528,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2540,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cadr(t2);
/* chicken.scm: 80   ->string */
t8=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);
case C_fix(2):
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2557,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2565,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cadr(t2);
/* chicken.scm: 80   ->string */
t8=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);
default:
/* chicken.scm: 80   syntax-error */
t4=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[112],lf[140],t2);}}

/* k2563 in a2510 in k2503 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 80   ##compiler#foreign-type-declaration */
t2=C_retrieve(lf[138]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2555 in a2510 in k2503 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 80   sprintf */
t2=C_retrieve(lf[62]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[139],t1);}

/* k2538 in a2510 in k2503 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 80   ##compiler#foreign-type-declaration */
t2=C_retrieve(lf[138]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2526 in a2510 in k2503 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_caddr(((C_word*)t0)[3]);
/* chicken.scm: 80   sprintf */
t3=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[137],t1,t2);}

/* k2507 in k2503 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2509,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_list(&a,1,lf[136]);
/* chicken.scm: 80   append */
t4=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t2,t3);}

/* k2491 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 80   string-intersperse */
t2=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[135]);}

/* k2487 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2489,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[98],t1);
t3=(C_word)C_a_i_list(&a,2,lf[133],t2);
t4=((C_word*)t0)[2];
f_2017(t4,(C_word)C_a_i_list(&a,1,t3));}

/* k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_2017(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2017,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2021,a[2]=t1,a[3]=((C_word*)t0)[14],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2025,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2471,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 80   sprintf */
t6=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[132],((C_word*)t0)[2],((C_word*)t0)[2]);}
else{
t5=t3;
f_2025(t5,C_SCHEME_END_OF_LIST);}}

/* k2469 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2471,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[107],((C_word*)t0)[4],C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)((C_word*)t0)[3])[1],t2);
t4=((C_word*)t0)[2];
f_2025(t4,(C_word)C_a_i_list(&a,1,t3));}

/* k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_2025(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2025,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2029,a[2]=t1,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2033,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
t4=((C_word*)((C_word*)t0)[2])[1];
if(C_truep(t4)){
t5=(C_word)C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],lf[129]);
t6=(C_word)C_a_i_list(&a,3,lf[130],lf[131],lf[129]);
t7=(C_word)C_a_i_list(&a,3,lf[110],lf[129],t6);
t8=(C_word)C_a_i_list(&a,3,lf[82],t5,t7);
t9=t3;
f_2033(t9,(C_word)C_a_i_list(&a,1,t8));}
else{
t5=t3;
f_2033(t5,C_SCHEME_END_OF_LIST);}}

/* k2031 in k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_2033(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2033,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2037,a[2]=t1,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2039,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a2038 in k2031 in k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2039(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2039,3,t0,t1,t2);}
t3=(C_word)C_i_length(t2);
switch(t3){
case C_fix(3):
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_caddr(t2);
t7=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2061,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t1,a[8]=t6,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* chicken.scm: 80   stype */
t8=((C_word*)((C_word*)t0)[2])[1];
f_1917(t8,t7,t4);
case C_fix(2):
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cadr(t2);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2316,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* chicken.scm: 80   stype */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1917(t7,t6,t4);
default:
/* chicken.scm: 80   syntax-error */
t4=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[112],lf[128],t2);}}

/* k2314 in a2038 in k2031 in k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2393,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2424,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2428,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 80   sprintf */
t5=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[127],((C_word*)t0)[9],((C_word*)t0)[4]);}

/* k2426 in k2314 in a2038 in k2031 in k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 80   renamer */
t2=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2422 in k2314 in a2038 in k2031 in k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 80   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2391 in k2314 in a2038 in k2031 in k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2393,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2405,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=t3,a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2416,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 80   strtype */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1960(t6,t5,((C_word*)t0)[6]);}

/* k2414 in k2391 in k2314 in a2038 in k2031 in k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[124]:lf[125]);
/* chicken.scm: 80   sprintf */
t3=C_retrieve(lf[62]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],lf[126],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2403 in k2391 in k2314 in a2038 in k2031 in k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2405,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[107],((C_word*)t0)[11],((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[9],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2331,a[2]=((C_word*)t0)[8],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2334,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[7],a[9]=t4,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t6=(C_word)C_i_car(((C_word*)t0)[7]);
t7=t5;
f_2334(t7,(C_word)C_eqp(lf[102],t6));}
else{
t6=t5;
f_2334(t6,C_SCHEME_FALSE);}}

/* k2332 in k2403 in k2391 in k2314 in a2038 in k2031 in k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_2334(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2334,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
f_2331(t2,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[8],((C_word*)t0)[7]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2351,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2375,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2379,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 80   sprintf */
t6=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[123],((C_word*)t0)[6],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[9];
f_2331(t3,C_SCHEME_END_OF_LIST);}}}

/* k2377 in k2332 in k2403 in k2391 in k2314 in a2038 in k2031 in k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 80   renamer */
t2=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2373 in k2332 in k2403 in k2391 in k2314 in a2038 in k2031 in k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 80   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2349 in k2332 in k2403 in k2391 in k2314 in a2038 in k2031 in k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2351,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2363,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 80   sprintf */
t6=C_retrieve(lf[62]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,lf[122],((C_word*)t0)[6],((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k2361 in k2349 in k2332 in k2403 in k2391 in k2314 in a2038 in k2031 in k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2363,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[107],lf[114],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_2331(t4,(C_word)C_a_i_list(&a,1,t3));}

/* k2329 in k2403 in k2391 in k2314 in a2038 in k2031 in k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_2331(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2331,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[68],t2));}

/* k2059 in a2038 in k2031 in k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2297,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2301,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 80   sprintf */
t5=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[121],((C_word*)t0)[12],((C_word*)t0)[4]);}

/* k2299 in k2059 in a2038 in k2031 in k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 80   renamer */
t2=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2295 in k2059 in a2038 in k2031 in k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 80   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2200 in k2059 in a2038 in k2031 in k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2202,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[13],((C_word*)t0)[12]);
t3=(C_word)C_a_i_list(&a,2,lf[106],((C_word*)t0)[11]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2274,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[9],a[13]=t4,a[14]=((C_word*)t0)[10],tmp=(C_word)a,a+=15,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2285,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[12],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 80   strtype */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1960(t7,t6,((C_word*)t0)[6]);}

/* k2283 in k2200 in k2059 in a2038 in k2031 in k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[118]:lf[119]);
/* chicken.scm: 80   sprintf */
t3=C_retrieve(lf[62]);
((C_proc7)C_retrieve_proc(t3))(7,t3,((C_word*)t0)[5],lf[120],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2272 in k2200 in k2059 in a2038 in k2031 in k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[161],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2274,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[107],((C_word*)t0)[14],((C_word*)t0)[13],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[12],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[11],((C_word*)t0)[10]);
t6=(C_word)C_a_i_list(&a,3,lf[108],((C_word*)t0)[10],C_fix(0));
t7=(C_word)C_a_i_list(&a,3,lf[109],((C_word*)t0)[10],((C_word*)t0)[9]);
t8=(C_word)C_a_i_list(&a,3,lf[110],t6,t7);
t9=(C_word)C_a_i_list(&a,2,lf[111],t8);
t10=(C_word)C_a_i_list(&a,3,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10]);
t11=(C_word)C_a_i_list(&a,2,lf[61],lf[112]);
t12=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[8]);
t13=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[10]);
t14=(C_word)C_a_i_list(&a,6,lf[50],t11,lf[113],t12,t13,((C_word*)t0)[9]);
t15=(C_word)C_a_i_list(&a,4,lf[72],t9,t10,t14);
t16=(C_word)C_a_i_list(&a,3,lf[2],t5,t15);
t17=(C_word)C_a_i_list(&a,3,lf[79],t4,t16);
t18=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[7],t17);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2076,a[2]=((C_word*)t0)[6],a[3]=t18,tmp=(C_word)a,a+=4,tmp);
t20=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[5],a[12]=t19,tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t21=(C_word)C_i_car(((C_word*)t0)[5]);
t22=t20;
f_2079(t22,(C_word)C_eqp(lf[102],t21));}
else{
t21=t20;
f_2079(t21,C_SCHEME_FALSE);}}

/* k2077 in k2272 in k2200 in k2059 in a2038 in k2031 in k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_2079(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2079,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[12];
f_2076(t2,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[11],((C_word*)t0)[10]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2096,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2184,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2188,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 80   sprintf */
t6=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[117],((C_word*)t0)[9],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[12];
f_2076(t3,C_SCHEME_END_OF_LIST);}}}

/* k2186 in k2077 in k2272 in k2200 in k2059 in a2038 in k2031 in k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 80   renamer */
t2=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2182 in k2077 in k2272 in k2200 in k2059 in a2038 in k2031 in k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 80   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2094 in k2077 in k2272 in k2200 in k2059 in a2038 in k2031 in k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2096,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(C_word)C_a_i_list(&a,2,lf[106],((C_word*)t0)[8]);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,3,t2,t3,t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2168,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[5],a[10]=t5,tmp=(C_word)a,a+=11,tmp);
/* chicken.scm: 80   sprintf */
t7=C_retrieve(lf[62]);
((C_proc7)C_retrieve_proc(t7))(7,t7,t6,lf[116],((C_word*)t0)[9],((C_word*)t0)[2],((C_word*)t0)[8],((C_word*)t0)[6]);}

/* k2166 in k2094 in k2077 in k2272 in k2200 in k2059 in a2038 in k2031 in k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[153],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2168,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[107],lf[114],((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_a_i_list(&a,3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t6=(C_word)C_a_i_list(&a,3,lf[108],((C_word*)t0)[7],C_fix(0));
t7=(C_word)C_a_i_list(&a,3,lf[109],((C_word*)t0)[7],((C_word*)t0)[5]);
t8=(C_word)C_a_i_list(&a,3,lf[110],t6,t7);
t9=(C_word)C_a_i_list(&a,2,lf[111],t8);
t10=(C_word)C_a_i_list(&a,4,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t11=(C_word)C_a_i_list(&a,2,lf[61],lf[112]);
t12=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t13=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[7]);
t14=(C_word)C_a_i_list(&a,6,lf[50],t11,lf[115],t12,t13,((C_word*)t0)[5]);
t15=(C_word)C_a_i_list(&a,4,lf[72],t9,t10,t14);
t16=(C_word)C_a_i_list(&a,3,lf[2],t5,t15);
t17=(C_word)C_a_i_list(&a,3,lf[79],t4,t16);
t18=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[3],t17);
t19=((C_word*)t0)[2];
f_2076(t19,(C_word)C_a_i_list(&a,1,t18));}

/* k2074 in k2272 in k2200 in k2059 in a2038 in k2031 in k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_2076(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2076,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[68],t2));}

/* k2035 in k2031 in k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 80   ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2027 in k2023 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 80   ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2019 in k2015 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 80   ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2011 in k2004 in k2001 in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_2013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2013,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[68],t1));}

/* strtype in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_1960(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1960,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1976,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(lf[102],t5);
if(C_truep(t6)){
t7=(C_word)C_i_cadr(t2);
/* chicken.scm: 80   strtype */
t9=t4;
t10=t7;
t1=t9;
t2=t10;
goto loop;}
else{
t7=t4;
f_1976(2,t7,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* k1974 in strtype in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_memq(t2,lf[105]));}}

/* stype in k1913 in k1910 in k1907 in k1904 in k1898 in a1895 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_1917(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1917,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(lf[102],t3);
if(C_truep(t4)){
t5=(C_word)C_i_cadr(t2);
/* chicken.scm: 80   stype */
t9=t1;
t10=t5;
t1=t9;
t2=t10;
goto loop;}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_memq(t5,lf[103]);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?(C_word)C_a_i_list(&a,2,lf[104],t2):t2));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1069,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1072,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1882,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 80   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[98],t3);}

/* a1881 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1882(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1882,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,lf[98],t2);
t4=(C_word)C_a_i_list(&a,2,lf[61],t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,lf[99],t4));}

/* k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1072,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1075,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1542,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 80   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[95],t3);}

/* a1541 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1542(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_1542r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1542r(t0,t1,t2,t3);}}

static void C_ccall f_1542r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(7);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1546,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t4)[1]))){
t6=(C_word)C_i_car(((C_word*)t4)[1]);
if(C_truep((C_word)C_booleanp(t6))){
t7=(C_word)C_i_cdr(((C_word*)t4)[1]);
t8=C_set_block_item(t4,0,t7);
t9=t5;
f_1546(t9,t6);}
else{
t7=t5;
f_1546(t7,C_SCHEME_TRUE);}}
else{
t6=t5;
f_1546(t6,C_SCHEME_TRUE);}}

/* k1544 in a1541 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_1546(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1546,NULL,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 80   ->string */
t5=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}

/* k1547 in k1544 in a1541 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1549,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=lf[67];
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1854,tmp=(C_word)a,a+=2,tmp);
/* map */
t8=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)((C_word*)t0)[2])[1]);}

/* a1853 in k1547 in k1544 in a1541 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1854(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1854,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_car(t2):t2));}

/* k1550 in k1547 in k1544 in a1541 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1829,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a1828 in k1550 in k1547 in k1544 in a1541 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1829(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1829,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cadr(t2));}
else{
/* chicken.scm: 80   syntax-error */
t4=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[95],lf[97],t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1553 in k1550 in k1547 in k1544 in a1541 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1558,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1797,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a1796 in k1553 in k1550 in k1547 in k1544 in a1541 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1797(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1797,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_caddr(t2));}
else{
t4=(C_word)C_i_car(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,lf[61],t4));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}}

/* k1556 in k1553 in k1550 in k1547 in k1544 in a1541 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1561,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[2]))){
t3=(C_word)C_i_length(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1771,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_and((C_word)C_fixnum_less_or_equal_p(C_fix(2),t3),(C_word)C_fixnum_less_or_equal_p(t3,C_fix(3))))){
t5=t4;
f_1771(2,t5,C_SCHEME_UNDEFINED);}
else{
/* chicken.scm: 80   syntax-error */
t5=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[95],lf[96],((C_word*)t0)[2]);}}
else{
t3=t2;
f_1561(t3,C_SCHEME_UNDEFINED);}}

/* k1769 in k1556 in k1553 in k1550 in k1547 in k1544 in a1541 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[7]);
t5=C_mutate(((C_word *)((C_word*)t0)[5])+1,t4);
t6=(C_word)C_eqp(C_fix(3),((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(C_word)C_i_caddr(((C_word*)t0)[7]);
t8=C_mutate(((C_word *)((C_word*)t0)[3])+1,t7);
t9=((C_word*)t0)[2];
f_1561(t9,t8);}
else{
t7=((C_word*)t0)[2];
f_1561(t7,C_SCHEME_UNDEFINED);}}

/* k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in a1541 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_1561(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1561,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1564,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[2])){
/* map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[6]),((C_word*)t0)[4]);}
else{
t3=t2;
f_1564(2,t3,((C_word*)t0)[4]);}}

/* k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in a1541 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1759,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 80   conc */
t4=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[7])[1],lf[93]);}

/* k1757 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in a1541 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 80   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in a1541 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1567,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1755,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 80   conc */
t4=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[92],((C_word*)((C_word*)t0)[8])[1]);}

/* k1753 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in a1541 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 80   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in a1541 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1570,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1577,a[2]=((C_word*)t0)[10],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1581,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1743,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 80   map */
t5=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* a1742 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in a1541 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1743(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1743,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1751,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 80   ->string */
t5=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k1749 in a1742 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in a1541 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1751,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[90],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1));}

/* k1579 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in a1541 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[97],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1581,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[10],lf[69]);
t3=(C_word)C_a_i_list(&a,2,lf[70],lf[69]);
t4=(C_word)C_a_i_list(&a,2,lf[71],lf[69]);
t5=(C_word)C_a_i_list(&a,4,lf[72],t3,t4,lf[69]);
t6=(C_word)C_a_i_list(&a,2,lf[69],t5);
t7=(C_word)C_a_i_list(&a,2,lf[73],C_fix(0));
t8=(C_word)C_a_i_list(&a,2,t6,t7);
t9=(C_word)C_a_i_list(&a,2,lf[74],lf[69]);
t10=(C_word)C_a_i_list(&a,2,lf[75],lf[69]);
t11=(C_word)C_a_i_list(&a,2,lf[76],lf[69]);
t12=(C_word)C_a_i_list(&a,2,lf[77],t11);
t13=(C_word)C_a_i_list(&a,1,t12);
t14=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1683,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t2,a[12]=t8,a[13]=t9,a[14]=t10,a[15]=t13,tmp=(C_word)a,a+=16,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1687,a[2]=t14,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t16=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1705,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 80   map */
t17=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t17))(5,t17,t15,t16,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* a1704 in k1579 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in a1541 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1705(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1705,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,t4,t2));}

/* k1685 in k1579 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in a1541 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1687,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)((C_word*)t0)[3])[1]);
t3=(C_word)C_a_i_list(&a,4,lf[88],lf[89],lf[77],t2);
t4=(C_word)C_a_i_list(&a,2,lf[86],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* ##sys#append */
t6=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[2],t1,t5);}

/* k1681 in k1579 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in a1541 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[88],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1683,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[77],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[78],t2);
t4=(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[15],t3);
t5=(C_word)C_a_i_list(&a,3,lf[80],lf[73],t4);
t6=(C_word)C_a_i_list(&a,3,lf[81],((C_word*)t0)[14],t5);
t7=(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[13],lf[73],t6);
t8=(C_word)C_a_i_list(&a,4,lf[79],lf[81],((C_word*)t0)[12],t7);
t9=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[11],t8);
t10=(C_word)C_a_i_list(&a,2,((C_word*)t0)[10],lf[77]);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1609,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t9,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t10,tmp=(C_word)a,a+=10,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1613,a[2]=t11,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1623,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 80   map */
t14=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t14))(5,t14,t12,t13,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1622 in k1681 in k1579 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in a1541 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1623,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,3,lf[87],lf[77],t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,t4,t3));}

/* k1611 in k1681 in k1579 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in a1541 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1613,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[86],((C_word*)((C_word*)t0)[3])[1]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k1607 in k1681 in k1579 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in a1541 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1609,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[83],t1);
t3=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_list(&a,5,lf[84],((C_word*)((C_word*)t0)[8])[1],((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],t3,t4);
/* ##sys#append */
t6=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[3],((C_word*)t0)[2],t5);}

/* k1575 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in a1541 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1577,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[68],t1));}

/* k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1075,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1078,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1508,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 80   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[66],t3);}

/* a1507 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1508(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[60],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1508,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t2,lf[60]);
t5=(C_word)C_a_i_list(&a,2,lf[61],t2);
t6=(C_word)C_a_i_list(&a,2,lf[61],t3);
t7=(C_word)C_a_i_list(&a,4,lf[62],lf[63],t5,t6);
t8=(C_word)C_a_i_list(&a,2,lf[56],t7);
t9=(C_word)C_a_i_list(&a,2,lf[61],t3);
t10=(C_word)C_a_i_list(&a,3,lf[64],t9,lf[60]);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[65],t4,t8,t10));}

/* k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1078,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1081,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1446,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 80   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[51],t3);}

/* a1445 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1446(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_1446r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1446r(t0,t1,t2,t3);}}

static void C_ccall f_1446r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1449,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1456,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1459,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_i_car(t2);
t8=t6;
f_1459(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_1459(t7,C_SCHEME_FALSE);}}

/* k1457 in a1445 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_1459(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1459,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_memq(lf[54],C_retrieve(lf[55])))){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 80   warning */
t3=C_retrieve(lf[56]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],lf[57],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1485,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken.scm: 80   ##compiler#register-compiler-macro */
t5=C_retrieve(lf[58]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,t3,t4,((C_word*)t0)[2]);}}
else{
/* chicken.scm: 80   bad */
t2=((C_word*)t0)[3];
f_1449(t2,((C_word*)t0)[4]);}}

/* k1483 in k1457 in a1445 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_1456(2,t2,C_SCHEME_UNDEFINED);}
else{
/* chicken.scm: 80   bad */
t2=((C_word*)t0)[2];
f_1449(t2,((C_word*)t0)[3]);}}

/* k1454 in a1445 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[53]);}

/* bad in a1445 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_1449(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1449,NULL,2,t0,t1);}
/* chicken.scm: 80   syntax-error */
t2=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,lf[51],lf[52],((C_word*)t0)[2]);}

/* k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1081,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1085,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1444,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 89   argv */
t4=C_retrieve(lf[49]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k1442 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1444,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1423,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1425,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1433,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1437,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 90   getenv */
t7=C_retrieve(lf[47]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[48]);}

/* k1435 in k1442 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[45]);
/* chicken.scm: 90   string-split */
t3=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k1431 in k1442 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 90   remove */
t2=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1424 in k1442 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1425(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1425,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_string_equal_p(t2,lf[43]));}

/* k1421 in k1442 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 88   append */
t2=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1083 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1085,2,t0,t1);}
t2=C_mutate((C_word*)lf[10]+1,t1);
t3=C_mutate((C_word*)lf[11]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1087,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1194,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1202,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1214,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 117  ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}

/* a1213 in k1083 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1214(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1214,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1218,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1226,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_1226(t9,t5,((C_word*)t4)[1]);}

/* loop in a1213 in k1083 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_1226(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(26);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1226,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_eqp(lf[19],t3);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1248,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t4);
/* chicken.scm: 123  string->number */
C_string_to_number(3,0,t6,t7);}
else{
t6=(C_word)C_eqp(lf[26],t3);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1311,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_car(t4);
/* chicken.scm: 137  string->number */
C_string_to_number(3,0,t7,t8);}
else{
t7=(C_word)C_eqp(lf[30],t3);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1365,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 146  cons* */
t9=C_retrieve(lf[20]);
((C_proc11)C_retrieve_proc(t9))(11,t9,t8,lf[31],lf[32],lf[28],lf[22],lf[21],lf[33],lf[34],lf[27],((C_word*)((C_word*)t0)[2])[1]);}
else{
if(C_truep((C_word)C_i_memq(t3,C_retrieve(lf[35])))){
/* chicken.scm: 150  loop */
t17=t1;
t18=t4;
t1=t17;
t2=t18;
goto loop;}
else{
if(C_truep((C_word)C_i_memq(t3,C_retrieve(lf[36])))){
if(C_truep((C_word)C_i_pairp(t4))){
t8=(C_word)C_i_cdr(t4);
/* chicken.scm: 153  loop */
t17=t1;
t18=t8;
t1=t17;
t2=t18;
goto loop;}
else{
/* chicken.scm: 154  quit */
t8=C_retrieve(lf[37]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,lf[38],t3);}}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1402,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1409,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_stringp(t3))){
t10=t9;
f_1409(2,t10,t3);}
else{
/* chicken.scm: 158  conc */
t10=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,lf[41],t3);}}}}}}}}

/* k1407 in loop in a1213 in k1083 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 156  compiler-warning */
t2=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[24],lf[39],t1);}

/* k1400 in loop in a1213 in k1083 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 159  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1226(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1363 in loop in a1213 in k1083 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* chicken.scm: 149  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1226(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1309 in loop in a1213 in k1083 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1314,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
switch(t1){
case C_fix(0):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1328,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 139  cons* */
t4=C_retrieve(lf[20]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[27],lf[28],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,lf[28],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_1314(2,t5,t4);
case C_fix(2):
t3=t2;
f_1314(2,t3,C_SCHEME_FALSE);
default:
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 142  compiler-warning */
t4=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[24],lf[29],t3);}}

/* k1326 in k1309 in loop in a1213 in k1083 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1314(2,t3,t2);}

/* k1312 in k1309 in loop in a1213 in k1083 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 143  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1226(t3,((C_word*)t0)[2],t2);}

/* k1246 in loop in a1213 in k1083 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1248,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1251,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
switch(t1){
case C_fix(0):
t3=t2;
f_1251(2,t3,C_SCHEME_FALSE);
case C_fix(1):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1271,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 127  cons* */
t4=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[21],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(2):
t3=(C_word)C_a_i_cons(&a,2,lf[21],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_1251(2,t5,t4);
case C_fix(3):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1291,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 133  cons* */
t4=C_retrieve(lf[20]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[21],lf[22],((C_word*)((C_word*)t0)[2])[1]);
default:
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 134  compiler-warning */
t4=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[24],lf[25],t3);}}

/* k1289 in k1246 in loop in a1213 in k1083 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1251(2,t3,t2);}

/* k1269 in k1246 in loop in a1213 in k1083 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1251(2,t3,t2);}

/* k1249 in k1246 in loop in a1213 in k1083 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 135  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1226(t3,((C_word*)t0)[2],t2);}

/* k1216 in a1213 in k1083 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1221,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t2,C_retrieve(lf[18]),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k1219 in k1216 in a1213 in k1083 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 161  exit */
t2=C_retrieve(lf[17]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a1201 in k1083 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1209,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 117  user-options-pass */
t3=C_retrieve(lf[16]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1207 in a1201 in k1083 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_retrieve(lf[11]));
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_retrieve(lf[10]));}

/* k1192 in k1083 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1197,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1200,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
t4=C_retrieve(lf[15]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k1198 in k1192 in k1083 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1195 in k1192 in k1083 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##compiler#process-command-line in k1083 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1087(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1087,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1093,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_1093(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in ##compiler#process-command-line in k1083 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_1093(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1093,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1107,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 102  reverse */
t6=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_string_length(t5);
t7=(C_word)C_i_string_ref(t5,C_fix(0));
t8=(C_word)C_eqp(C_make_character(45),t7);
t9=(C_truep(t8)?(C_word)C_fixnum_greaterp(t6,C_fix(1)):C_SCHEME_FALSE);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1128,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t6,C_fix(1)))){
t11=(C_word)C_i_string_ref(t5,C_fix(1));
t12=t10;
f_1128(t12,(C_word)C_eqp(C_make_character(58),t11));}
else{
t11=t10;
f_1128(t11,C_SCHEME_FALSE);}}
else{
if(C_truep(t4)){
t10=(C_word)C_i_cdr(t2);
t11=(C_word)C_a_i_cons(&a,2,t5,t3);
/* chicken.scm: 111  loop */
t17=t1;
t18=t10;
t19=t11;
t20=t4;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}
else{
t10=(C_word)C_i_cdr(t2);
/* chicken.scm: 112  loop */
t17=t1;
t18=t10;
t19=t3;
t20=t5;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}}}}

/* k1126 in loop in ##compiler#process-command-line in k1083 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_fcall f_1128(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1128,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* chicken.scm: 108  loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_1093(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1150,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1154,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 109  substring */
t5=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]);}}

/* k1152 in k1126 in loop in ##compiler#process-command-line in k1083 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 109  string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1148 in k1126 in loop in ##compiler#process-command-line in k1083 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1150,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* chicken.scm: 109  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1093(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1105 in loop in ##compiler#process-command-line in k1083 in k1079 in k1076 in k1073 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k874 in k871 in k868 in k865 in k862 in k859 in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_1107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 102  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* assign in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_788(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_788,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_792,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 79   ##sys#check-syntax */
t5=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[8],t2,lf[9]);}

/* k790 in assign in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_792,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t2=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,lf[3]);
t4=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[4],t2,t4));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t3,((C_word*)t0)[4]));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_829,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 79   map */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[6]),((C_word*)t0)[5]);}}}

/* k827 in k790 in assign in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_829,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_848,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_850,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 79   map */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[2],t1);}

/* a849 in k827 in k790 in assign in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_850(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_850,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t2,t3));}

/* k846 in k827 in k790 in assign in k785 in k782 in k779 in k776 in k773 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k743 in k740 in k737 in k734 in k731 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 */
static void C_ccall f_848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_848,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[2],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[4],((C_word*)t0)[2],t3));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[587] = {
{"toplevelchicken.scm",(void*)C_toplevel},
{"f_709chicken.scm",(void*)f_709},
{"f_712chicken.scm",(void*)f_712},
{"f_715chicken.scm",(void*)f_715},
{"f_718chicken.scm",(void*)f_718},
{"f_721chicken.scm",(void*)f_721},
{"f_724chicken.scm",(void*)f_724},
{"f_727chicken.scm",(void*)f_727},
{"f_730chicken.scm",(void*)f_730},
{"f_733chicken.scm",(void*)f_733},
{"f_736chicken.scm",(void*)f_736},
{"f_739chicken.scm",(void*)f_739},
{"f_742chicken.scm",(void*)f_742},
{"f_745chicken.scm",(void*)f_745},
{"f_751chicken.scm",(void*)f_751},
{"f_7178chicken.scm",(void*)f_7178},
{"f_7182chicken.scm",(void*)f_7182},
{"f_7185chicken.scm",(void*)f_7185},
{"f_7188chicken.scm",(void*)f_7188},
{"f_7194chicken.scm",(void*)f_7194},
{"f_7400chicken.scm",(void*)f_7400},
{"f_7380chicken.scm",(void*)f_7380},
{"f_7376chicken.scm",(void*)f_7376},
{"f_7356chicken.scm",(void*)f_7356},
{"f_7219chicken.scm",(void*)f_7219},
{"f_7229chicken.scm",(void*)f_7229},
{"f_7348chicken.scm",(void*)f_7348},
{"f_7232chicken.scm",(void*)f_7232},
{"f_7344chicken.scm",(void*)f_7344},
{"f_7235chicken.scm",(void*)f_7235},
{"f_7266chicken.scm",(void*)f_7266},
{"f_7246chicken.scm",(void*)f_7246},
{"f_7217chicken.scm",(void*)f_7217},
{"f_754chicken.scm",(void*)f_754},
{"f_7090chicken.scm",(void*)f_7090},
{"f_7107chicken.scm",(void*)f_7107},
{"f_7110chicken.scm",(void*)f_7110},
{"f_7116chicken.scm",(void*)f_7116},
{"f_757chicken.scm",(void*)f_757},
{"f_7049chicken.scm",(void*)f_7049},
{"f_7053chicken.scm",(void*)f_7053},
{"f_760chicken.scm",(void*)f_760},
{"f_7033chicken.scm",(void*)f_7033},
{"f_7043chicken.scm",(void*)f_7043},
{"f_7041chicken.scm",(void*)f_7041},
{"f_763chicken.scm",(void*)f_763},
{"f_6956chicken.scm",(void*)f_6956},
{"f_6960chicken.scm",(void*)f_6960},
{"f_7028chicken.scm",(void*)f_7028},
{"f_6963chicken.scm",(void*)f_6963},
{"f_6972chicken.scm",(void*)f_6972},
{"f_7019chicken.scm",(void*)f_7019},
{"f_6986chicken.scm",(void*)f_6986},
{"f_6994chicken.scm",(void*)f_6994},
{"f_6996chicken.scm",(void*)f_6996},
{"f_7013chicken.scm",(void*)f_7013},
{"f_6978chicken.scm",(void*)f_6978},
{"f_6970chicken.scm",(void*)f_6970},
{"f_766chicken.scm",(void*)f_766},
{"f_6896chicken.scm",(void*)f_6896},
{"f_6900chicken.scm",(void*)f_6900},
{"f_769chicken.scm",(void*)f_769},
{"f_6837chicken.scm",(void*)f_6837},
{"f_6841chicken.scm",(void*)f_6841},
{"f_6868chicken.scm",(void*)f_6868},
{"f_772chicken.scm",(void*)f_772},
{"f_6663chicken.scm",(void*)f_6663},
{"f_6667chicken.scm",(void*)f_6667},
{"f_6670chicken.scm",(void*)f_6670},
{"f_6831chicken.scm",(void*)f_6831},
{"f_6673chicken.scm",(void*)f_6673},
{"f_6825chicken.scm",(void*)f_6825},
{"f_6676chicken.scm",(void*)f_6676},
{"f_6823chicken.scm",(void*)f_6823},
{"f_6787chicken.scm",(void*)f_6787},
{"f_6801chicken.scm",(void*)f_6801},
{"f_6815chicken.scm",(void*)f_6815},
{"f_6795chicken.scm",(void*)f_6795},
{"f_6791chicken.scm",(void*)f_6791},
{"f_6683chicken.scm",(void*)f_6683},
{"f_6779chicken.scm",(void*)f_6779},
{"f_6755chicken.scm",(void*)f_6755},
{"f_6773chicken.scm",(void*)f_6773},
{"f_6763chicken.scm",(void*)f_6763},
{"f_6759chicken.scm",(void*)f_6759},
{"f_6751chicken.scm",(void*)f_6751},
{"f_6735chicken.scm",(void*)f_6735},
{"f_6711chicken.scm",(void*)f_6711},
{"f_6729chicken.scm",(void*)f_6729},
{"f_6719chicken.scm",(void*)f_6719},
{"f_6715chicken.scm",(void*)f_6715},
{"f_6707chicken.scm",(void*)f_6707},
{"f_775chicken.scm",(void*)f_775},
{"f_6568chicken.scm",(void*)f_6568},
{"f_6604chicken.scm",(void*)f_6604},
{"f_6617chicken.scm",(void*)f_6617},
{"f_6575chicken.scm",(void*)f_6575},
{"f_778chicken.scm",(void*)f_778},
{"f_6458chicken.scm",(void*)f_6458},
{"f_6462chicken.scm",(void*)f_6462},
{"f_6465chicken.scm",(void*)f_6465},
{"f_6468chicken.scm",(void*)f_6468},
{"f_6471chicken.scm",(void*)f_6471},
{"f_6562chicken.scm",(void*)f_6562},
{"f_6474chicken.scm",(void*)f_6474},
{"f_6556chicken.scm",(void*)f_6556},
{"f_6477chicken.scm",(void*)f_6477},
{"f_6550chicken.scm",(void*)f_6550},
{"f_6554chicken.scm",(void*)f_6554},
{"f_6484chicken.scm",(void*)f_6484},
{"f_6522chicken.scm",(void*)f_6522},
{"f_6520chicken.scm",(void*)f_6520},
{"f_781chicken.scm",(void*)f_781},
{"f_6448chicken.scm",(void*)f_6448},
{"f_784chicken.scm",(void*)f_784},
{"f_6434chicken.scm",(void*)f_6434},
{"f_787chicken.scm",(void*)f_787},
{"f_861chicken.scm",(void*)f_861},
{"f_864chicken.scm",(void*)f_864},
{"f_6172chicken.scm",(void*)f_6172},
{"f_6176chicken.scm",(void*)f_6176},
{"f_6185chicken.scm",(void*)f_6185},
{"f_6394chicken.scm",(void*)f_6394},
{"f_6407chicken.scm",(void*)f_6407},
{"f_6188chicken.scm",(void*)f_6188},
{"f_6384chicken.scm",(void*)f_6384},
{"f_6392chicken.scm",(void*)f_6392},
{"f_6191chicken.scm",(void*)f_6191},
{"f_6338chicken.scm",(void*)f_6338},
{"f_6371chicken.scm",(void*)f_6371},
{"f_6378chicken.scm",(void*)f_6378},
{"f_6354chicken.scm",(void*)f_6354},
{"f_6203chicken.scm",(void*)f_6203},
{"f_6332chicken.scm",(void*)f_6332},
{"f_6210chicken.scm",(void*)f_6210},
{"f_6212chicken.scm",(void*)f_6212},
{"f_6326chicken.scm",(void*)f_6326},
{"f_6246chicken.scm",(void*)f_6246},
{"f_6300chicken.scm",(void*)f_6300},
{"f_6277chicken.scm",(void*)f_6277},
{"f_6257chicken.scm",(void*)f_6257},
{"f_6232chicken.scm",(void*)f_6232},
{"f_6240chicken.scm",(void*)f_6240},
{"f_6230chicken.scm",(void*)f_6230},
{"f_6192chicken.scm",(void*)f_6192},
{"f_6132chicken.scm",(void*)f_6132},
{"f_6155chicken.scm",(void*)f_6155},
{"f_6159chicken.scm",(void*)f_6159},
{"f_6101chicken.scm",(void*)f_6101},
{"f_6122chicken.scm",(void*)f_6122},
{"f_867chicken.scm",(void*)f_867},
{"f_6050chicken.scm",(void*)f_6050},
{"f_6054chicken.scm",(void*)f_6054},
{"f_6065chicken.scm",(void*)f_6065},
{"f_6090chicken.scm",(void*)f_6090},
{"f_870chicken.scm",(void*)f_870},
{"f_5930chicken.scm",(void*)f_5930},
{"f_5934chicken.scm",(void*)f_5934},
{"f_6044chicken.scm",(void*)f_6044},
{"f_6042chicken.scm",(void*)f_6042},
{"f_5943chicken.scm",(void*)f_5943},
{"f_6030chicken.scm",(void*)f_6030},
{"f_6038chicken.scm",(void*)f_6038},
{"f_5946chicken.scm",(void*)f_5946},
{"f_6024chicken.scm",(void*)f_6024},
{"f_5966chicken.scm",(void*)f_5966},
{"f_5976chicken.scm",(void*)f_5976},
{"f_5996chicken.scm",(void*)f_5996},
{"f_6002chicken.scm",(void*)f_6002},
{"f_6010chicken.scm",(void*)f_6010},
{"f_6000chicken.scm",(void*)f_6000},
{"f_5974chicken.scm",(void*)f_5974},
{"f_5970chicken.scm",(void*)f_5970},
{"f_5947chicken.scm",(void*)f_5947},
{"f_873chicken.scm",(void*)f_873},
{"f_5909chicken.scm",(void*)f_5909},
{"f_5913chicken.scm",(void*)f_5913},
{"f_876chicken.scm",(void*)f_876},
{"f_5899chicken.scm",(void*)f_5899},
{"f_882chicken.scm",(void*)f_882},
{"f_891chicken.scm",(void*)f_891},
{"f_907chicken.scm",(void*)f_907},
{"f_894chicken.scm",(void*)f_894},
{"f_955chicken.scm",(void*)f_955},
{"f_5878chicken.scm",(void*)f_5878},
{"f_5882chicken.scm",(void*)f_5882},
{"f_958chicken.scm",(void*)f_958},
{"f_5762chicken.scm",(void*)f_5762},
{"f_5766chicken.scm",(void*)f_5766},
{"f_5775chicken.scm",(void*)f_5775},
{"f_5789chicken.scm",(void*)f_5789},
{"f_5853chicken.scm",(void*)f_5853},
{"f_5835chicken.scm",(void*)f_5835},
{"f_5818chicken.scm",(void*)f_5818},
{"f_961chicken.scm",(void*)f_961},
{"f_5516chicken.scm",(void*)f_5516},
{"f_5671chicken.scm",(void*)f_5671},
{"f_5742chicken.scm",(void*)f_5742},
{"f_5687chicken.scm",(void*)f_5687},
{"f_5685chicken.scm",(void*)f_5685},
{"f_5529chicken.scm",(void*)f_5529},
{"f_5655chicken.scm",(void*)f_5655},
{"f_5617chicken.scm",(void*)f_5617},
{"f_5578chicken.scm",(void*)f_5578},
{"f_5519chicken.scm",(void*)f_5519},
{"f_964chicken.scm",(void*)f_964},
{"f_5417chicken.scm",(void*)f_5417},
{"f_5427chicken.scm",(void*)f_5427},
{"f_5440chicken.scm",(void*)f_5440},
{"f_5456chicken.scm",(void*)f_5456},
{"f_5494chicken.scm",(void*)f_5494},
{"f_5492chicken.scm",(void*)f_5492},
{"f_5484chicken.scm",(void*)f_5484},
{"f_5438chicken.scm",(void*)f_5438},
{"f_967chicken.scm",(void*)f_967},
{"f_5328chicken.scm",(void*)f_5328},
{"f_5338chicken.scm",(void*)f_5338},
{"f_5351chicken.scm",(void*)f_5351},
{"f_5367chicken.scm",(void*)f_5367},
{"f_5395chicken.scm",(void*)f_5395},
{"f_5349chicken.scm",(void*)f_5349},
{"f_970chicken.scm",(void*)f_970},
{"f_5042chicken.scm",(void*)f_5042},
{"f_5239chicken.scm",(void*)f_5239},
{"f_5242chicken.scm",(void*)f_5242},
{"f_5245chicken.scm",(void*)f_5245},
{"f_5318chicken.scm",(void*)f_5318},
{"f_5326chicken.scm",(void*)f_5326},
{"f_5261chicken.scm",(void*)f_5261},
{"f_5264chicken.scm",(void*)f_5264},
{"f_5267chicken.scm",(void*)f_5267},
{"f_5270chicken.scm",(void*)f_5270},
{"f_5308chicken.scm",(void*)f_5308},
{"f_5316chicken.scm",(void*)f_5316},
{"f_5273chicken.scm",(void*)f_5273},
{"f_5053chicken.scm",(void*)f_5053},
{"f_5057chicken.scm",(void*)f_5057},
{"f_5061chicken.scm",(void*)f_5061},
{"f_5063chicken.scm",(void*)f_5063},
{"f_5108chicken.scm",(void*)f_5108},
{"f_5120chicken.scm",(void*)f_5120},
{"f_5116chicken.scm",(void*)f_5116},
{"f_5084chicken.scm",(void*)f_5084},
{"f_5276chicken.scm",(void*)f_5276},
{"f_5136chicken.scm",(void*)f_5136},
{"f_5236chicken.scm",(void*)f_5236},
{"f_5200chicken.scm",(void*)f_5200},
{"f_5170chicken.scm",(void*)f_5170},
{"f_5279chicken.scm",(void*)f_5279},
{"f_5246chicken.scm",(void*)f_5246},
{"f_5258chicken.scm",(void*)f_5258},
{"f_5254chicken.scm",(void*)f_5254},
{"f_973chicken.scm",(void*)f_973},
{"f_4985chicken.scm",(void*)f_4985},
{"f_4989chicken.scm",(void*)f_4989},
{"f_976chicken.scm",(void*)f_976},
{"f_4979chicken.scm",(void*)f_4979},
{"f_979chicken.scm",(void*)f_979},
{"f_4826chicken.scm",(void*)f_4826},
{"f_4830chicken.scm",(void*)f_4830},
{"f_4833chicken.scm",(void*)f_4833},
{"f_4836chicken.scm",(void*)f_4836},
{"f_4849chicken.scm",(void*)f_4849},
{"f_4899chicken.scm",(void*)f_4899},
{"f_4910chicken.scm",(void*)f_4910},
{"f_4847chicken.scm",(void*)f_4847},
{"f_982chicken.scm",(void*)f_982},
{"f_4550chicken.scm",(void*)f_4550},
{"f_4584chicken.scm",(void*)f_4584},
{"f_4587chicken.scm",(void*)f_4587},
{"f_4813chicken.scm",(void*)f_4813},
{"f_4823chicken.scm",(void*)f_4823},
{"f_4811chicken.scm",(void*)f_4811},
{"f_4590chicken.scm",(void*)f_4590},
{"f_4559chicken.scm",(void*)f_4559},
{"f_4573chicken.scm",(void*)f_4573},
{"f_4577chicken.scm",(void*)f_4577},
{"f_4593chicken.scm",(void*)f_4593},
{"f_4596chicken.scm",(void*)f_4596},
{"f_4599chicken.scm",(void*)f_4599},
{"f_4606chicken.scm",(void*)f_4606},
{"f_4620chicken.scm",(void*)f_4620},
{"f_4630chicken.scm",(void*)f_4630},
{"f_4634chicken.scm",(void*)f_4634},
{"f_4644chicken.scm",(void*)f_4644},
{"f_4660chicken.scm",(void*)f_4660},
{"f_4679chicken.scm",(void*)f_4679},
{"f_4735chicken.scm",(void*)f_4735},
{"f_4746chicken.scm",(void*)f_4746},
{"f_4664chicken.scm",(void*)f_4664},
{"f_4677chicken.scm",(void*)f_4677},
{"f_4650chicken.scm",(void*)f_4650},
{"f_4658chicken.scm",(void*)f_4658},
{"f_4648chicken.scm",(void*)f_4648},
{"f_4618chicken.scm",(void*)f_4618},
{"f_985chicken.scm",(void*)f_985},
{"f_4493chicken.scm",(void*)f_4493},
{"f_4533chicken.scm",(void*)f_4533},
{"f_4503chicken.scm",(void*)f_4503},
{"f_988chicken.scm",(void*)f_988},
{"f_4417chicken.scm",(void*)f_4417},
{"f_4421chicken.scm",(void*)f_4421},
{"f_4424chicken.scm",(void*)f_4424},
{"f_991chicken.scm",(void*)f_991},
{"f_4233chicken.scm",(void*)f_4233},
{"f_4237chicken.scm",(void*)f_4237},
{"f_4240chicken.scm",(void*)f_4240},
{"f_4383chicken.scm",(void*)f_4383},
{"f_4379chicken.scm",(void*)f_4379},
{"f_4242chicken.scm",(void*)f_4242},
{"f_4330chicken.scm",(void*)f_4330},
{"f_4328chicken.scm",(void*)f_4328},
{"f_4298chicken.scm",(void*)f_4298},
{"f_4265chicken.scm",(void*)f_4265},
{"f_994chicken.scm",(void*)f_994},
{"f_4043chicken.scm",(void*)f_4043},
{"f_4050chicken.scm",(void*)f_4050},
{"f_4224chicken.scm",(void*)f_4224},
{"f_4222chicken.scm",(void*)f_4222},
{"f_4075chicken.scm",(void*)f_4075},
{"f_4101chicken.scm",(void*)f_4101},
{"f_4129chicken.scm",(void*)f_4129},
{"f_4113chicken.scm",(void*)f_4113},
{"f_4073chicken.scm",(void*)f_4073},
{"f_997chicken.scm",(void*)f_997},
{"f_4034chicken.scm",(void*)f_4034},
{"f_4038chicken.scm",(void*)f_4038},
{"f_1000chicken.scm",(void*)f_1000},
{"f_4015chicken.scm",(void*)f_4015},
{"f_4019chicken.scm",(void*)f_4019},
{"f_4028chicken.scm",(void*)f_4028},
{"f_4026chicken.scm",(void*)f_4026},
{"f_1003chicken.scm",(void*)f_1003},
{"f_3996chicken.scm",(void*)f_3996},
{"f_4000chicken.scm",(void*)f_4000},
{"f_4009chicken.scm",(void*)f_4009},
{"f_4007chicken.scm",(void*)f_4007},
{"f_1006chicken.scm",(void*)f_1006},
{"f_3868chicken.scm",(void*)f_3868},
{"f_3874chicken.scm",(void*)f_3874},
{"f_3955chicken.scm",(void*)f_3955},
{"f_3884chicken.scm",(void*)f_3884},
{"f_3887chicken.scm",(void*)f_3887},
{"f_3893chicken.scm",(void*)f_3893},
{"f_3900chicken.scm",(void*)f_3900},
{"f_3916chicken.scm",(void*)f_3916},
{"f_1009chicken.scm",(void*)f_1009},
{"f_3725chicken.scm",(void*)f_3725},
{"f_3731chicken.scm",(void*)f_3731},
{"f_3843chicken.scm",(void*)f_3843},
{"f_3816chicken.scm",(void*)f_3816},
{"f_3741chicken.scm",(void*)f_3741},
{"f_3744chicken.scm",(void*)f_3744},
{"f_3750chicken.scm",(void*)f_3750},
{"f_3761chicken.scm",(void*)f_3761},
{"f_3777chicken.scm",(void*)f_3777},
{"f_1012chicken.scm",(void*)f_1012},
{"f_3666chicken.scm",(void*)f_3666},
{"f_1015chicken.scm",(void*)f_1015},
{"f_3495chicken.scm",(void*)f_3495},
{"f_3501chicken.scm",(void*)f_3501},
{"f_3575chicken.scm",(void*)f_3575},
{"f_3578chicken.scm",(void*)f_3578},
{"f_3651chicken.scm",(void*)f_3651},
{"f_3644chicken.scm",(void*)f_3644},
{"f_3636chicken.scm",(void*)f_3636},
{"f_3623chicken.scm",(void*)f_3623},
{"f_3602chicken.scm",(void*)f_3602},
{"f_3511chicken.scm",(void*)f_3511},
{"f_1018chicken.scm",(void*)f_1018},
{"f_3444chicken.scm",(void*)f_3444},
{"f_1021chicken.scm",(void*)f_1021},
{"f_3384chicken.scm",(void*)f_3384},
{"f_3394chicken.scm",(void*)f_3394},
{"f_3413chicken.scm",(void*)f_3413},
{"f_3397chicken.scm",(void*)f_3397},
{"f_1024chicken.scm",(void*)f_1024},
{"f_1027chicken.scm",(void*)f_1027},
{"f_3347chicken.scm",(void*)f_3347},
{"f_3351chicken.scm",(void*)f_3351},
{"f_1030chicken.scm",(void*)f_1030},
{"f_3328chicken.scm",(void*)f_3328},
{"f_3332chicken.scm",(void*)f_3332},
{"f_3341chicken.scm",(void*)f_3341},
{"f_3339chicken.scm",(void*)f_3339},
{"f_1033chicken.scm",(void*)f_1033},
{"f_3309chicken.scm",(void*)f_3309},
{"f_3313chicken.scm",(void*)f_3313},
{"f_3322chicken.scm",(void*)f_3322},
{"f_3320chicken.scm",(void*)f_3320},
{"f_1036chicken.scm",(void*)f_1036},
{"f_3290chicken.scm",(void*)f_3290},
{"f_3294chicken.scm",(void*)f_3294},
{"f_3303chicken.scm",(void*)f_3303},
{"f_3301chicken.scm",(void*)f_3301},
{"f_1039chicken.scm",(void*)f_1039},
{"f_3271chicken.scm",(void*)f_3271},
{"f_3275chicken.scm",(void*)f_3275},
{"f_3284chicken.scm",(void*)f_3284},
{"f_3282chicken.scm",(void*)f_3282},
{"f_1042chicken.scm",(void*)f_1042},
{"f_3252chicken.scm",(void*)f_3252},
{"f_3256chicken.scm",(void*)f_3256},
{"f_3265chicken.scm",(void*)f_3265},
{"f_3263chicken.scm",(void*)f_3263},
{"f_1045chicken.scm",(void*)f_1045},
{"f_3233chicken.scm",(void*)f_3233},
{"f_3237chicken.scm",(void*)f_3237},
{"f_3246chicken.scm",(void*)f_3246},
{"f_3244chicken.scm",(void*)f_3244},
{"f_1048chicken.scm",(void*)f_1048},
{"f_3133chicken.scm",(void*)f_3133},
{"f_3137chicken.scm",(void*)f_3137},
{"f_3192chicken.scm",(void*)f_3192},
{"f_3146chicken.scm",(void*)f_3146},
{"f_1051chicken.scm",(void*)f_1051},
{"f_2913chicken.scm",(void*)f_2913},
{"f_2917chicken.scm",(void*)f_2917},
{"f_2920chicken.scm",(void*)f_2920},
{"f_3001chicken.scm",(void*)f_3001},
{"f_3068chicken.scm",(void*)f_3068},
{"f_3066chicken.scm",(void*)f_3066},
{"f_3058chicken.scm",(void*)f_3058},
{"f_3046chicken.scm",(void*)f_3046},
{"f_2926chicken.scm",(void*)f_2926},
{"f_2952chicken.scm",(void*)f_2952},
{"f_1054chicken.scm",(void*)f_1054},
{"f_2838chicken.scm",(void*)f_2838},
{"f_2842chicken.scm",(void*)f_2842},
{"f_2911chicken.scm",(void*)f_2911},
{"f_2865chicken.scm",(void*)f_2865},
{"f_1057chicken.scm",(void*)f_1057},
{"f_2732chicken.scm",(void*)f_2732},
{"f_2832chicken.scm",(void*)f_2832},
{"f_2736chicken.scm",(void*)f_2736},
{"f_2808chicken.scm",(void*)f_2808},
{"f_2743chicken.scm",(void*)f_2743},
{"f_2749chicken.scm",(void*)f_2749},
{"f_2747chicken.scm",(void*)f_2747},
{"f_1060chicken.scm",(void*)f_1060},
{"f_2703chicken.scm",(void*)f_2703},
{"f_2707chicken.scm",(void*)f_2707},
{"f_2730chicken.scm",(void*)f_2730},
{"f_2726chicken.scm",(void*)f_2726},
{"f_1063chicken.scm",(void*)f_1063},
{"f_2690chicken.scm",(void*)f_2690},
{"f_2694chicken.scm",(void*)f_2694},
{"f_1066chicken.scm",(void*)f_1066},
{"f_1896chicken.scm",(void*)f_1896},
{"f_1900chicken.scm",(void*)f_1900},
{"f_1906chicken.scm",(void*)f_1906},
{"f_1909chicken.scm",(void*)f_1909},
{"f_1912chicken.scm",(void*)f_1912},
{"f_1915chicken.scm",(void*)f_1915},
{"f_2582chicken.scm",(void*)f_2582},
{"f_2661chicken.scm",(void*)f_2661},
{"f_2657chicken.scm",(void*)f_2657},
{"f_2592chicken.scm",(void*)f_2592},
{"f_2596chicken.scm",(void*)f_2596},
{"f_2637chicken.scm",(void*)f_2637},
{"f_2627chicken.scm",(void*)f_2627},
{"f_2617chicken.scm",(void*)f_2617},
{"f_2613chicken.scm",(void*)f_2613},
{"f_2599chicken.scm",(void*)f_2599},
{"f_2003chicken.scm",(void*)f_2003},
{"f_2006chicken.scm",(void*)f_2006},
{"f_2576chicken.scm",(void*)f_2576},
{"f_2505chicken.scm",(void*)f_2505},
{"f_2511chicken.scm",(void*)f_2511},
{"f_2565chicken.scm",(void*)f_2565},
{"f_2557chicken.scm",(void*)f_2557},
{"f_2540chicken.scm",(void*)f_2540},
{"f_2528chicken.scm",(void*)f_2528},
{"f_2509chicken.scm",(void*)f_2509},
{"f_2493chicken.scm",(void*)f_2493},
{"f_2489chicken.scm",(void*)f_2489},
{"f_2017chicken.scm",(void*)f_2017},
{"f_2471chicken.scm",(void*)f_2471},
{"f_2025chicken.scm",(void*)f_2025},
{"f_2033chicken.scm",(void*)f_2033},
{"f_2039chicken.scm",(void*)f_2039},
{"f_2316chicken.scm",(void*)f_2316},
{"f_2428chicken.scm",(void*)f_2428},
{"f_2424chicken.scm",(void*)f_2424},
{"f_2393chicken.scm",(void*)f_2393},
{"f_2416chicken.scm",(void*)f_2416},
{"f_2405chicken.scm",(void*)f_2405},
{"f_2334chicken.scm",(void*)f_2334},
{"f_2379chicken.scm",(void*)f_2379},
{"f_2375chicken.scm",(void*)f_2375},
{"f_2351chicken.scm",(void*)f_2351},
{"f_2363chicken.scm",(void*)f_2363},
{"f_2331chicken.scm",(void*)f_2331},
{"f_2061chicken.scm",(void*)f_2061},
{"f_2301chicken.scm",(void*)f_2301},
{"f_2297chicken.scm",(void*)f_2297},
{"f_2202chicken.scm",(void*)f_2202},
{"f_2285chicken.scm",(void*)f_2285},
{"f_2274chicken.scm",(void*)f_2274},
{"f_2079chicken.scm",(void*)f_2079},
{"f_2188chicken.scm",(void*)f_2188},
{"f_2184chicken.scm",(void*)f_2184},
{"f_2096chicken.scm",(void*)f_2096},
{"f_2168chicken.scm",(void*)f_2168},
{"f_2076chicken.scm",(void*)f_2076},
{"f_2037chicken.scm",(void*)f_2037},
{"f_2029chicken.scm",(void*)f_2029},
{"f_2021chicken.scm",(void*)f_2021},
{"f_2013chicken.scm",(void*)f_2013},
{"f_1960chicken.scm",(void*)f_1960},
{"f_1976chicken.scm",(void*)f_1976},
{"f_1917chicken.scm",(void*)f_1917},
{"f_1069chicken.scm",(void*)f_1069},
{"f_1882chicken.scm",(void*)f_1882},
{"f_1072chicken.scm",(void*)f_1072},
{"f_1542chicken.scm",(void*)f_1542},
{"f_1546chicken.scm",(void*)f_1546},
{"f_1549chicken.scm",(void*)f_1549},
{"f_1854chicken.scm",(void*)f_1854},
{"f_1552chicken.scm",(void*)f_1552},
{"f_1829chicken.scm",(void*)f_1829},
{"f_1555chicken.scm",(void*)f_1555},
{"f_1797chicken.scm",(void*)f_1797},
{"f_1558chicken.scm",(void*)f_1558},
{"f_1771chicken.scm",(void*)f_1771},
{"f_1561chicken.scm",(void*)f_1561},
{"f_1564chicken.scm",(void*)f_1564},
{"f_1759chicken.scm",(void*)f_1759},
{"f_1567chicken.scm",(void*)f_1567},
{"f_1755chicken.scm",(void*)f_1755},
{"f_1570chicken.scm",(void*)f_1570},
{"f_1743chicken.scm",(void*)f_1743},
{"f_1751chicken.scm",(void*)f_1751},
{"f_1581chicken.scm",(void*)f_1581},
{"f_1705chicken.scm",(void*)f_1705},
{"f_1687chicken.scm",(void*)f_1687},
{"f_1683chicken.scm",(void*)f_1683},
{"f_1623chicken.scm",(void*)f_1623},
{"f_1613chicken.scm",(void*)f_1613},
{"f_1609chicken.scm",(void*)f_1609},
{"f_1577chicken.scm",(void*)f_1577},
{"f_1075chicken.scm",(void*)f_1075},
{"f_1508chicken.scm",(void*)f_1508},
{"f_1078chicken.scm",(void*)f_1078},
{"f_1446chicken.scm",(void*)f_1446},
{"f_1459chicken.scm",(void*)f_1459},
{"f_1485chicken.scm",(void*)f_1485},
{"f_1456chicken.scm",(void*)f_1456},
{"f_1449chicken.scm",(void*)f_1449},
{"f_1081chicken.scm",(void*)f_1081},
{"f_1444chicken.scm",(void*)f_1444},
{"f_1437chicken.scm",(void*)f_1437},
{"f_1433chicken.scm",(void*)f_1433},
{"f_1425chicken.scm",(void*)f_1425},
{"f_1423chicken.scm",(void*)f_1423},
{"f_1085chicken.scm",(void*)f_1085},
{"f_1214chicken.scm",(void*)f_1214},
{"f_1226chicken.scm",(void*)f_1226},
{"f_1409chicken.scm",(void*)f_1409},
{"f_1402chicken.scm",(void*)f_1402},
{"f_1365chicken.scm",(void*)f_1365},
{"f_1311chicken.scm",(void*)f_1311},
{"f_1328chicken.scm",(void*)f_1328},
{"f_1314chicken.scm",(void*)f_1314},
{"f_1248chicken.scm",(void*)f_1248},
{"f_1291chicken.scm",(void*)f_1291},
{"f_1271chicken.scm",(void*)f_1271},
{"f_1251chicken.scm",(void*)f_1251},
{"f_1218chicken.scm",(void*)f_1218},
{"f_1221chicken.scm",(void*)f_1221},
{"f_1202chicken.scm",(void*)f_1202},
{"f_1209chicken.scm",(void*)f_1209},
{"f_1194chicken.scm",(void*)f_1194},
{"f_1200chicken.scm",(void*)f_1200},
{"f_1197chicken.scm",(void*)f_1197},
{"f_1087chicken.scm",(void*)f_1087},
{"f_1093chicken.scm",(void*)f_1093},
{"f_1128chicken.scm",(void*)f_1128},
{"f_1154chicken.scm",(void*)f_1154},
{"f_1150chicken.scm",(void*)f_1150},
{"f_1107chicken.scm",(void*)f_1107},
{"f_788chicken.scm",(void*)f_788},
{"f_792chicken.scm",(void*)f_792},
{"f_829chicken.scm",(void*)f_829},
{"f_850chicken.scm",(void*)f_850},
{"f_848chicken.scm",(void*)f_848},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
