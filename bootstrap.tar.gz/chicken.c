/* Generated from chicken.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-11-07 15:24
   Version 4.0.0x1 - SVN rev. 12338
   linux-unix-gnu-x86 [ dload ptables applyhook ]
   compiled 2008-11-03 on dill (Linux)
   command line: chicken.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -no-lambda-info -inline -local -extend private-namespace.scm -output-file chicken.c
   used units: library eval data_structures ports extras srfi_69 srfi_1 srfi_4 utils files support compiler optimizer driver platform backend srfi_69
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_4_toplevel)
C_externimport void C_ccall C_srfi_4_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_support_toplevel)
C_externimport void C_ccall C_support_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_compiler_toplevel)
C_externimport void C_ccall C_compiler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_optimizer_toplevel)
C_externimport void C_ccall C_optimizer_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_driver_toplevel)
C_externimport void C_ccall C_driver_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_platform_toplevel)
C_externimport void C_ccall C_platform_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_backend_toplevel)
C_externimport void C_ccall C_backend_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[305];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1779)
static void C_ccall f_1779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1782)
static void C_ccall f_1782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1785)
static void C_ccall f_1785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1788)
static void C_ccall f_1788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1794)
static void C_ccall f_1794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1797)
static void C_ccall f_1797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1800)
static void C_ccall f_1800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1803)
static void C_ccall f_1803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1806)
static void C_ccall f_1806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1809)
static void C_ccall f_1809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1812)
static void C_ccall f_1812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1815)
static void C_ccall f_1815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1818)
static void C_ccall f_1818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1821)
static void C_ccall f_1821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1824)
static void C_ccall f_1824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1827)
static void C_ccall f_1827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1830)
static void C_ccall f_1830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1834)
static void C_ccall f_1834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8958)
static void C_ccall f_8958(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8962)
static void C_ccall f_8962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8971)
static void C_ccall f_8971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8977)
static void C_ccall f_8977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8980)
static void C_ccall f_8980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8983)
static void C_ccall f_8983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8986)
static void C_ccall f_8986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9396)
static void C_ccall f_9396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9356)
static void C_ccall f_9356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9388)
static void C_ccall f_9388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9348)
static void C_ccall f_9348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9304)
static void C_ccall f_9304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9015)
static void C_fcall f_9015(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9025)
static void C_ccall f_9025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9292)
static void C_ccall f_9292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9028)
static void C_ccall f_9028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9288)
static void C_ccall f_9288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9031)
static void C_ccall f_9031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9078)
static void C_fcall f_9078(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9042)
static void C_ccall f_9042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9013)
static void C_ccall f_9013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9009)
static void C_ccall f_9009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8956)
static void C_ccall f_8956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8815)
static void C_ccall f_8815(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8819)
static void C_ccall f_8819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8822)
static void C_ccall f_8822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8825)
static void C_ccall f_8825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8861)
static void C_ccall f_8861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8876)
static void C_fcall f_8876(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8930)
static void C_ccall f_8930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8891)
static void C_ccall f_8891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8854)
static void C_ccall f_8854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8813)
static void C_ccall f_8813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1840)
static void C_ccall f_1840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8716)
static void C_ccall f_8716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8720)
static void C_ccall f_8720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8723)
static void C_ccall f_8723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8726)
static void C_ccall f_8726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8805)
static void C_ccall f_8805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8714)
static void C_ccall f_8714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1843)
static void C_ccall f_1843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8698)
static void C_ccall f_8698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8706)
static void C_ccall f_8706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8696)
static void C_ccall f_8696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8609)
static void C_ccall f_8609(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8613)
static void C_ccall f_8613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8616)
static void C_ccall f_8616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8619)
static void C_ccall f_8619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8685)
static void C_ccall f_8685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8622)
static void C_ccall f_8622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8635)
static void C_ccall f_8635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8679)
static void C_ccall f_8679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8646)
static void C_ccall f_8646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8654)
static void C_ccall f_8654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8656)
static void C_fcall f_8656(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8673)
static void C_ccall f_8673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8641)
static void C_ccall f_8641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8633)
static void C_ccall f_8633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8629)
static void C_ccall f_8629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8607)
static void C_ccall f_8607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1849)
static void C_ccall f_1849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8498)
static void C_ccall f_8498(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8502)
static void C_ccall f_8502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8511)
static void C_ccall f_8511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8514)
static void C_ccall f_8514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8517)
static void C_fcall f_8517(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8560)
static void C_ccall f_8560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8496)
static void C_ccall f_8496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8361)
static void C_ccall f_8361(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8365)
static void C_ccall f_8365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8377)
static void C_ccall f_8377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8380)
static void C_ccall f_8380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8383)
static void C_ccall f_8383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8434)
static void C_fcall f_8434(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8430)
static void C_ccall f_8430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8359)
static void C_ccall f_8359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1855)
static void C_ccall f_1855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8103)
static void C_ccall f_8103(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8107)
static void C_ccall f_8107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8116)
static void C_ccall f_8116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8347)
static void C_ccall f_8347(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8355)
static void C_ccall f_8355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8119)
static void C_ccall f_8119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8337)
static void C_ccall f_8337(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8345)
static void C_ccall f_8345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8122)
static void C_ccall f_8122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8125)
static void C_ccall f_8125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8128)
static void C_ccall f_8128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8335)
static void C_ccall f_8335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8295)
static void C_ccall f_8295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8313)
static void C_fcall f_8313(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8327)
static void C_ccall f_8327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8307)
static void C_ccall f_8307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8303)
static void C_ccall f_8303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8299)
static void C_ccall f_8299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8139)
static void C_ccall f_8139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8279)
static void C_ccall f_8279(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8247)
static void C_ccall f_8247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8265)
static void C_ccall f_8265(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8255)
static void C_ccall f_8255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8251)
static void C_ccall f_8251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8243)
static void C_ccall f_8243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8235)
static void C_ccall f_8235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8215)
static void C_ccall f_8215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8183)
static void C_ccall f_8183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8201)
static void C_ccall f_8201(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8191)
static void C_ccall f_8191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8187)
static void C_ccall f_8187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8179)
static void C_ccall f_8179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8101)
static void C_ccall f_8101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7982)
static void C_ccall f_7982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7986)
static void C_ccall f_7986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7992)
static void C_ccall f_7992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8093)
static void C_ccall f_8093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7998)
static void C_ccall f_7998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8001)
static void C_ccall f_8001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8004)
static void C_ccall f_8004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8044)
static void C_fcall f_8044(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8067)
static void C_ccall f_8067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8074)
static void C_ccall f_8074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8081)
static void C_ccall f_8081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8057)
static void C_ccall f_8057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8007)
static void C_ccall f_8007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7980)
static void C_ccall f_7980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1861)
static void C_ccall f_1861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7780)
static void C_ccall f_7780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7784)
static void C_ccall f_7784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7793)
static void C_ccall f_7793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7796)
static void C_ccall f_7796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7799)
static void C_ccall f_7799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7802)
static void C_ccall f_7802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7805)
static void C_ccall f_7805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7968)
static void C_ccall f_7968(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7976)
static void C_ccall f_7976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7808)
static void C_ccall f_7808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7958)
static void C_ccall f_7958(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7966)
static void C_ccall f_7966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7811)
static void C_ccall f_7811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7952)
static void C_ccall f_7952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7956)
static void C_ccall f_7956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7822)
static void C_ccall f_7822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7896)
static void C_ccall f_7896(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7894)
static void C_ccall f_7894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7890)
static void C_ccall f_7890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7870)
static void C_ccall f_7870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7778)
static void C_ccall f_7778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1864)
static void C_ccall f_1864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7735)
static void C_ccall f_7735(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7739)
static void C_ccall f_7739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7746)
static void C_ccall f_7746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7766)
static void C_ccall f_7766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7770)
static void C_ccall f_7770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7733)
static void C_ccall f_7733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1867)
static void C_ccall f_1867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7682)
static void C_ccall f_7682(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7686)
static void C_ccall f_7686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7693)
static void C_ccall f_7693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7721)
static void C_ccall f_7721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7725)
static void C_ccall f_7725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7680)
static void C_ccall f_7680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7537)
static void C_ccall f_7537(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7541)
static void C_ccall f_7541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7550)
static void C_ccall f_7550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7619)
static void C_ccall f_7619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7652)
static void C_ccall f_7652(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7650)
static void C_ccall f_7650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7646)
static void C_ccall f_7646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7535)
static void C_ccall f_7535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1873)
static void C_ccall f_1873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7495)
static void C_ccall f_7495(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7499)
static void C_ccall f_7499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7519)
static void C_ccall f_7519(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7527)
static void C_ccall f_7527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7502)
static void C_ccall f_7502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7509)
static void C_ccall f_7509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7513)
static void C_ccall f_7513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7493)
static void C_ccall f_7493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1876)
static void C_ccall f_1876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7107)
static void C_ccall f_7107(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7111)
static void C_ccall f_7111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7120)
static void C_ccall f_7120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7123)
static void C_ccall f_7123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7198)
static void C_ccall f_7198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7451)
static void C_fcall f_7451(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7464)
static void C_ccall f_7464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7201)
static void C_ccall f_7201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7437)
static void C_ccall f_7437(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7449)
static void C_ccall f_7449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7445)
static void C_ccall f_7445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7204)
static void C_ccall f_7204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7391)
static void C_fcall f_7391(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7424)
static void C_ccall f_7424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7431)
static void C_ccall f_7431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7407)
static void C_fcall f_7407(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7216)
static void C_ccall f_7216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7385)
static void C_ccall f_7385(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7223)
static void C_ccall f_7223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7225)
static void C_fcall f_7225(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7379)
static void C_ccall f_7379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7263)
static void C_fcall f_7263(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7345)
static void C_ccall f_7345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7302)
static void C_ccall f_7302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7282)
static void C_ccall f_7282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7249)
static void C_ccall f_7249(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7257)
static void C_ccall f_7257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7243)
static void C_ccall f_7243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7247)
static void C_ccall f_7247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7205)
static void C_ccall f_7205(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7156)
static void C_fcall f_7156(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7179)
static void C_ccall f_7179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7183)
static void C_ccall f_7183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7125)
static void C_fcall f_7125(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7146)
static void C_ccall f_7146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7105)
static void C_ccall f_7105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1879)
static void C_ccall f_1879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7035)
static void C_ccall f_7035(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7039)
static void C_ccall f_7039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7048)
static void C_ccall f_7048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7051)
static void C_ccall f_7051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7056)
static void C_fcall f_7056(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7093)
static void C_ccall f_7093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7074)
static void C_ccall f_7074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7033)
static void C_ccall f_7033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1882)
static void C_ccall f_1882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6869)
static void C_ccall f_6869(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6873)
static void C_ccall f_6873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6882)
static void C_ccall f_6882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6885)
static void C_ccall f_6885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7025)
static void C_ccall f_7025(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7023)
static void C_ccall f_7023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6888)
static void C_ccall f_6888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7007)
static void C_ccall f_7007(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7019)
static void C_ccall f_7019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7015)
static void C_ccall f_7015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6891)
static void C_ccall f_6891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7001)
static void C_ccall f_7001(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6911)
static void C_ccall f_6911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6925)
static void C_ccall f_6925(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6953)
static void C_ccall f_6953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6963)
static void C_ccall f_6963(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6979)
static void C_ccall f_6979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6961)
static void C_ccall f_6961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6957)
static void C_ccall f_6957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6919)
static void C_ccall f_6919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6923)
static void C_ccall f_6923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6915)
static void C_ccall f_6915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6892)
static void C_ccall f_6892(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6867)
static void C_ccall f_6867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1885)
static void C_ccall f_1885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6795)
static void C_ccall f_6795(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6799)
static void C_ccall f_6799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6802)
static void C_ccall f_6802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6805)
static void C_ccall f_6805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6808)
static void C_ccall f_6808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6793)
static void C_ccall f_6793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1888)
static void C_ccall f_1888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6694)
static void C_ccall f_6694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6698)
static void C_ccall f_6698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6785)
static void C_ccall f_6785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6781)
static void C_ccall f_6781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6700)
static void C_fcall f_6700(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6704)
static void C_ccall f_6704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6761)
static void C_ccall f_6761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6713)
static void C_fcall f_6713(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6735)
static void C_ccall f_6735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6725)
static void C_fcall f_6725(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6716)
static void C_ccall f_6716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6692)
static void C_ccall f_6692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1891)
static void C_ccall f_1891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6531)
static void C_ccall f_6531(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6535)
static void C_ccall f_6535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6544)
static void C_ccall f_6544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6547)
static void C_ccall f_6547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6552)
static void C_fcall f_6552(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6597)
static void C_ccall f_6597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6664)
static void C_ccall f_6664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6626)
static void C_ccall f_6626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6566)
static void C_ccall f_6566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6570)
static void C_ccall f_6570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6529)
static void C_ccall f_6529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6362)
static void C_ccall f_6362(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6366)
static void C_ccall f_6366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6375)
static void C_ccall f_6375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6378)
static void C_ccall f_6378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6381)
static void C_ccall f_6381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6384)
static void C_ccall f_6384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6387)
static void C_ccall f_6387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6390)
static void C_ccall f_6390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6397)
static void C_ccall f_6397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6415)
static void C_fcall f_6415(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6431)
static void C_ccall f_6431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6437)
static void C_ccall f_6437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6493)
static void C_ccall f_6493(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6491)
static void C_ccall f_6491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6487)
static void C_ccall f_6487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6479)
static void C_ccall f_6479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6475)
static void C_ccall f_6475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6444)
static void C_ccall f_6444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6413)
static void C_ccall f_6413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6360)
static void C_ccall f_6360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1897)
static void C_ccall f_1897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5930)
static void C_ccall f_5930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5934)
static void C_ccall f_5934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5946)
static void C_ccall f_5946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5949)
static void C_ccall f_5949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5952)
static void C_ccall f_5952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5955)
static void C_ccall f_5955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5958)
static void C_ccall f_5958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5961)
static void C_ccall f_5961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6249)
static void C_ccall f_6249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6252)
static void C_ccall f_6252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6255)
static void C_ccall f_6255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6348)
static void C_ccall f_6348(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6356)
static void C_ccall f_6356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6271)
static void C_ccall f_6271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6274)
static void C_ccall f_6274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6277)
static void C_ccall f_6277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6280)
static void C_ccall f_6280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6338)
static void C_ccall f_6338(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6346)
static void C_ccall f_6346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6283)
static void C_ccall f_6283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6286)
static void C_ccall f_6286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6289)
static void C_ccall f_6289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6296)
static void C_ccall f_6296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6256)
static void C_fcall f_6256(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6268)
static void C_ccall f_6268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6264)
static void C_ccall f_6264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6060)
static void C_fcall f_6060(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6066)
static void C_fcall f_6066(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6242)
static void C_ccall f_6242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6186)
static void C_ccall f_6186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6128)
static void C_ccall f_6128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5963)
static void C_fcall f_5963(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5971)
static void C_ccall f_5971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5975)
static void C_ccall f_5975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5979)
static void C_ccall f_5979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5981)
static void C_fcall f_5981(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6034)
static void C_ccall f_6034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6050)
static void C_ccall f_6050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6046)
static void C_ccall f_6046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6002)
static void C_ccall f_6002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5928)
static void C_ccall f_5928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5746)
static void C_ccall f_5746(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5750)
static void C_ccall f_5750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5753)
static void C_ccall f_5753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5756)
static void C_ccall f_5756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5759)
static void C_ccall f_5759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5766)
static void C_ccall f_5766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5801)
static void C_ccall f_5801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5885)
static void C_ccall f_5885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5861)
static void C_ccall f_5861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5744)
static void C_ccall f_5744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1903)
static void C_ccall f_1903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5444)
static void C_ccall f_5444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5448)
static void C_ccall f_5448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5460)
static void C_ccall f_5460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5463)
static void C_ccall f_5463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5466)
static void C_ccall f_5466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5469)
static void C_ccall f_5469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5472)
static void C_ccall f_5472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5475)
static void C_ccall f_5475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5496)
static void C_fcall f_5496(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5724)
static void C_ccall f_5724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5586)
static void C_ccall f_5586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5605)
static void C_ccall f_5605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5562)
static void C_ccall f_5562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5494)
static void C_ccall f_5494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5442)
static void C_ccall f_5442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5023)
static void C_ccall f_5023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5027)
static void C_ccall f_5027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5064)
static void C_ccall f_5064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5423)
static void C_ccall f_5423(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5433)
static void C_ccall f_5433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5421)
static void C_ccall f_5421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5067)
static void C_ccall f_5067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5070)
static void C_ccall f_5070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5073)
static void C_ccall f_5073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5076)
static void C_ccall f_5076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5079)
static void C_ccall f_5079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5082)
static void C_ccall f_5082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5085)
static void C_ccall f_5085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5096)
static void C_ccall f_5096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5122)
static void C_ccall f_5122(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5132)
static void C_ccall f_5132(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5136)
static void C_ccall f_5136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5385)
static void C_ccall f_5385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5370)
static void C_ccall f_5370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5150)
static void C_fcall f_5150(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5174)
static void C_ccall f_5174(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5201)
static void C_fcall f_5201(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5357)
static void C_ccall f_5357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5269)
static void C_ccall f_5269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5349)
static void C_ccall f_5349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5329)
static void C_ccall f_5329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5288)
static void C_ccall f_5288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5258)
static void C_ccall f_5258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5226)
static void C_ccall f_5226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5178)
static void C_ccall f_5178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5195)
static void C_ccall f_5195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5164)
static void C_ccall f_5164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5172)
static void C_ccall f_5172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5158)
static void C_ccall f_5158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5120)
static void C_ccall f_5120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5029)
static void C_fcall f_5029(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5035)
static void C_fcall f_5035(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5061)
static void C_ccall f_5061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5049)
static void C_ccall f_5049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5053)
static void C_ccall f_5053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5021)
static void C_ccall f_5021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1909)
static void C_ccall f_1909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4925)
static void C_ccall f_4925(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4929)
static void C_ccall f_4929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4994)
static void C_ccall f_4994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5009)
static void C_ccall f_5009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4944)
static void C_ccall f_4944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4967)
static void C_ccall f_4967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4979)
static void C_ccall f_4979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4923)
static void C_ccall f_4923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1912)
static void C_ccall f_1912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4731)
static void C_ccall f_4731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4735)
static void C_ccall f_4735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4738)
static void C_ccall f_4738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4741)
static void C_ccall f_4741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4744)
static void C_ccall f_4744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4755)
static void C_ccall f_4755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4783)
static void C_ccall f_4783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4875)
static void C_ccall f_4875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4729)
static void C_ccall f_4729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1915)
static void C_ccall f_1915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4404)
static void C_ccall f_4404(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4408)
static void C_ccall f_4408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4411)
static void C_ccall f_4411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4414)
static void C_ccall f_4414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4417)
static void C_ccall f_4417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4420)
static void C_ccall f_4420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4423)
static void C_ccall f_4423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4426)
static void C_ccall f_4426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4641)
static void C_ccall f_4641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4649)
static void C_ccall f_4649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4645)
static void C_ccall f_4645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4428)
static void C_ccall f_4428(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4552)
static void C_ccall f_4552(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4550)
static void C_ccall f_4550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4546)
static void C_ccall f_4546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4538)
static void C_ccall f_4538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4519)
static void C_ccall f_4519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4504)
static void C_fcall f_4504(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4489)
static void C_ccall f_4489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4470)
static void C_ccall f_4470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4455)
static void C_fcall f_4455(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4402)
static void C_ccall f_4402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1918)
static void C_ccall f_1918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4029)
static void C_ccall f_4029(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4033)
static void C_ccall f_4033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4048)
static void C_ccall f_4048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4051)
static void C_ccall f_4051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4054)
static void C_ccall f_4054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4060)
static void C_ccall f_4060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4063)
static void C_ccall f_4063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4066)
static void C_ccall f_4066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4069)
static void C_ccall f_4069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4387)
static void C_ccall f_4387(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4385)
static void C_ccall f_4385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4381)
static void C_ccall f_4381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4098)
static void C_fcall f_4098(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4124)
static void C_fcall f_4124(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4164)
static void C_fcall f_4164(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4140)
static void C_ccall f_4140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4136)
static void C_ccall f_4136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4096)
static void C_ccall f_4096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4092)
static void C_ccall f_4092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4027)
static void C_ccall f_4027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1921)
static void C_ccall f_1921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3841)
static void C_ccall f_3841(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3845)
static void C_ccall f_3845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3848)
static void C_ccall f_3848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3851)
static void C_ccall f_3851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3854)
static void C_ccall f_3854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3857)
static void C_ccall f_3857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3866)
static void C_fcall f_3866(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3969)
static void C_ccall f_3969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3997)
static void C_ccall f_3997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3991)
static void C_ccall f_3991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3972)
static void C_ccall f_3972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3876)
static void C_ccall f_3876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3879)
static void C_ccall f_3879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3951)
static void C_ccall f_3951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3928)
static void C_ccall f_3928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3885)
static void C_ccall f_3885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3896)
static void C_ccall f_3896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3916)
static void C_ccall f_3916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3839)
static void C_ccall f_3839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1924)
static void C_ccall f_1924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3622)
static void C_ccall f_3622(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3626)
static void C_ccall f_3626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3629)
static void C_ccall f_3629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3632)
static void C_ccall f_3632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3635)
static void C_ccall f_3635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3638)
static void C_ccall f_3638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3647)
static void C_fcall f_3647(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3766)
static void C_ccall f_3766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3794)
static void C_ccall f_3794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3827)
static void C_ccall f_3827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3800)
static void C_ccall f_3800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3788)
static void C_ccall f_3788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3769)
static void C_ccall f_3769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3657)
static void C_ccall f_3657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3660)
static void C_ccall f_3660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3756)
static void C_ccall f_3756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3666)
static void C_ccall f_3666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3689)
static void C_ccall f_3689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3709)
static void C_ccall f_3709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3620)
static void C_ccall f_3620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1927)
static void C_ccall f_1927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3345)
static void C_ccall f_3345(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3349)
static void C_ccall f_3349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3352)
static void C_ccall f_3352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3355)
static void C_ccall f_3355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3358)
static void C_ccall f_3358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3361)
static void C_ccall f_3361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3364)
static void C_ccall f_3364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3373)
static void C_fcall f_3373(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3519)
static void C_fcall f_3519(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3522)
static void C_ccall f_3522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3531)
static void C_ccall f_3531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3556)
static void C_ccall f_3556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3581)
static void C_ccall f_3581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3603)
static void C_ccall f_3603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3596)
static void C_ccall f_3596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3588)
static void C_ccall f_3588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3575)
static void C_ccall f_3575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3571)
static void C_ccall f_3571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3550)
static void C_ccall f_3550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3546)
static void C_ccall f_3546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3513)
static void C_ccall f_3513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3383)
static void C_fcall f_3383(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3390)
static void C_ccall f_3390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3498)
static void C_ccall f_3498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3486)
static void C_ccall f_3486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3482)
static void C_ccall f_3482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3418)
static void C_ccall f_3418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3446)
static void C_ccall f_3446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3458)
static void C_ccall f_3458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3442)
static void C_ccall f_3442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3343)
static void C_ccall f_3343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1930)
static void C_ccall f_1930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3241)
static void C_ccall f_3241(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3245)
static void C_ccall f_3245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3251)
static void C_ccall f_3251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3335)
static void C_ccall f_3335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3296)
static void C_ccall f_3296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3308)
static void C_ccall f_3308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3239)
static void C_ccall f_3239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1933)
static void C_ccall f_1933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3137)
static void C_ccall f_3137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3211)
static void C_ccall f_3211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3223)
static void C_ccall f_3223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3152)
static void C_fcall f_3152(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3198)
static void C_ccall f_3198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3155)
static void C_ccall f_3155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3158)
static void C_ccall f_3158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3168)
static void C_ccall f_3168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3131)
static void C_ccall f_3131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1936)
static void C_ccall f_1936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3108)
static void C_ccall f_3108(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3112)
static void C_ccall f_3112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1939)
static void C_ccall f_1939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3098)
static void C_ccall f_3098(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3096)
static void C_ccall f_3096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1948)
static void C_ccall f_1948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1952)
static void C_ccall f_1952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2796)
static void C_ccall f_2796(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2803)
static void C_ccall f_2803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2806)
static void C_fcall f_2806(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2809)
static void C_fcall f_2809(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2914)
static void C_ccall f_2914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2927)
static void C_ccall f_2927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3025)
static void C_ccall f_3025(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3023)
static void C_ccall f_3023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3011)
static void C_ccall f_3011(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2995)
static void C_ccall f_2995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2999)
static void C_ccall f_2999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2815)
static void C_ccall f_2815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2825)
static void C_ccall f_2825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2899)
static void C_ccall f_2899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2879)
static void C_ccall f_2879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2849)
static void C_fcall f_2849(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2845)
static void C_ccall f_2845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2794)
static void C_ccall f_2794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1955)
static void C_ccall f_1955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2655)
static void C_ccall f_2655(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2659)
static void C_ccall f_2659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2671)
static void C_ccall f_2671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2771)
static void C_ccall f_2771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2674)
static void C_ccall f_2674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2681)
static void C_ccall f_2681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2751)
static void C_ccall f_2751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2731)
static void C_ccall f_2731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2705)
static void C_fcall f_2705(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2701)
static void C_ccall f_2701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2653)
static void C_ccall f_2653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1958)
static void C_ccall f_1958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2509)
static void C_ccall f_2509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2518)
static void C_ccall f_2518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2641)
static void C_ccall f_2641(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2649)
static void C_ccall f_2649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2617)
static void C_ccall f_2617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2532)
static void C_ccall f_2532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2615)
static void C_ccall f_2615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2542)
static void C_ccall f_2542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2540)
static void C_ccall f_2540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2503)
static void C_ccall f_2503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1961)
static void C_ccall f_1961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2437)
static void C_ccall f_2437(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2441)
static void C_ccall f_2441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2444)
static void C_ccall f_2444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2451)
static void C_ccall f_2451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2475)
static void C_ccall f_2475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2495)
static void C_ccall f_2495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2491)
static void C_ccall f_2491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2435)
static void C_ccall f_2435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1964)
static void C_ccall f_1964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2381)
static void C_ccall f_2381(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2385)
static void C_ccall f_2385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2388)
static void C_ccall f_2388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2395)
static void C_ccall f_2395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2411)
static void C_ccall f_2411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2379)
static void C_ccall f_2379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1967)
static void C_ccall f_1967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2352)
static void C_ccall f_2352(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2356)
static void C_ccall f_2356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2371)
static void C_ccall f_2371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2350)
static void C_ccall f_2350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2343)
static void C_ccall f_2343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2339)
static void C_ccall f_2339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2331)
static void C_ccall f_2331(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2321)
static void C_ccall f_2321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2329)
static void C_ccall f_2329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1977)
static void C_ccall f_1977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2106)
static void C_ccall f_2106(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2118)
static void C_fcall f_2118(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2311)
static void C_ccall f_2311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2304)
static void C_ccall f_2304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2267)
static void C_ccall f_2267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2213)
static void C_ccall f_2213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2230)
static void C_ccall f_2230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2216)
static void C_ccall f_2216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2140)
static void C_ccall f_2140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2193)
static void C_ccall f_2193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2183)
static void C_ccall f_2183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2143)
static void C_ccall f_2143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2110)
static void C_ccall f_2110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2113)
static void C_ccall f_2113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2094)
static void C_ccall f_2094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2101)
static void C_ccall f_2101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2086)
static void C_ccall f_2086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2092)
static void C_ccall f_2092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2089)
static void C_ccall f_2089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1979)
static void C_ccall f_1979(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1985)
static void C_fcall f_1985(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2020)
static void C_fcall f_2020(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2046)
static void C_ccall f_2046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2042)
static void C_ccall f_2042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1999)
static void C_ccall f_1999(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_9015)
static void C_fcall trf_9015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9015(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9015(t0,t1,t2,t3);}

C_noret_decl(trf_9078)
static void C_fcall trf_9078(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9078(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9078(t0,t1);}

C_noret_decl(trf_8876)
static void C_fcall trf_8876(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8876(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8876(t0,t1);}

C_noret_decl(trf_8656)
static void C_fcall trf_8656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8656(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8656(t0,t1,t2,t3);}

C_noret_decl(trf_8517)
static void C_fcall trf_8517(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8517(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8517(t0,t1);}

C_noret_decl(trf_8434)
static void C_fcall trf_8434(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8434(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8434(t0,t1);}

C_noret_decl(trf_8313)
static void C_fcall trf_8313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8313(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8313(t0,t1,t2);}

C_noret_decl(trf_8044)
static void C_fcall trf_8044(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8044(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8044(t0,t1,t2);}

C_noret_decl(trf_7451)
static void C_fcall trf_7451(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7451(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7451(t0,t1,t2,t3);}

C_noret_decl(trf_7391)
static void C_fcall trf_7391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7391(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7391(t0,t1,t2,t3);}

C_noret_decl(trf_7407)
static void C_fcall trf_7407(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7407(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7407(t0,t1);}

C_noret_decl(trf_7225)
static void C_fcall trf_7225(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7225(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7225(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7263)
static void C_fcall trf_7263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7263(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7263(t0,t1);}

C_noret_decl(trf_7156)
static void C_fcall trf_7156(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7156(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7156(t0,t1,t2,t3);}

C_noret_decl(trf_7125)
static void C_fcall trf_7125(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7125(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7125(t0,t1,t2,t3);}

C_noret_decl(trf_7056)
static void C_fcall trf_7056(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7056(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7056(t0,t1,t2);}

C_noret_decl(trf_6700)
static void C_fcall trf_6700(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6700(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6700(t0,t1,t2,t3);}

C_noret_decl(trf_6713)
static void C_fcall trf_6713(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6713(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6713(t0,t1);}

C_noret_decl(trf_6725)
static void C_fcall trf_6725(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6725(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6725(t0,t1);}

C_noret_decl(trf_6552)
static void C_fcall trf_6552(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6552(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6552(t0,t1,t2);}

C_noret_decl(trf_6415)
static void C_fcall trf_6415(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6415(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6415(t0,t1,t2);}

C_noret_decl(trf_6256)
static void C_fcall trf_6256(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6256(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6256(t0,t1,t2);}

C_noret_decl(trf_6060)
static void C_fcall trf_6060(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6060(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6060(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6066)
static void C_fcall trf_6066(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6066(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6066(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5963)
static void C_fcall trf_5963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5963(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5963(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5981)
static void C_fcall trf_5981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5981(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5981(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5496)
static void C_fcall trf_5496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5496(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5496(t0,t1,t2,t3);}

C_noret_decl(trf_5150)
static void C_fcall trf_5150(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5150(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5150(t0,t1);}

C_noret_decl(trf_5201)
static void C_fcall trf_5201(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5201(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5201(t0,t1,t2,t3);}

C_noret_decl(trf_5029)
static void C_fcall trf_5029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5029(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5029(t0,t1,t2);}

C_noret_decl(trf_5035)
static void C_fcall trf_5035(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5035(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5035(t0,t1,t2);}

C_noret_decl(trf_4504)
static void C_fcall trf_4504(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4504(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4504(t0,t1);}

C_noret_decl(trf_4455)
static void C_fcall trf_4455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4455(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4455(t0,t1);}

C_noret_decl(trf_4098)
static void C_fcall trf_4098(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4098(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4098(t0,t1,t2,t3);}

C_noret_decl(trf_4124)
static void C_fcall trf_4124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4124(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4124(t0,t1);}

C_noret_decl(trf_4164)
static void C_fcall trf_4164(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4164(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4164(t0,t1);}

C_noret_decl(trf_3866)
static void C_fcall trf_3866(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3866(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3866(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3647)
static void C_fcall trf_3647(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3647(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3647(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3373)
static void C_fcall trf_3373(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3373(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3373(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3519)
static void C_fcall trf_3519(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3519(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3519(t0,t1);}

C_noret_decl(trf_3383)
static void C_fcall trf_3383(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3383(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3383(t0,t1);}

C_noret_decl(trf_3152)
static void C_fcall trf_3152(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3152(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3152(t0,t1);}

C_noret_decl(trf_2806)
static void C_fcall trf_2806(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2806(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2806(t0,t1);}

C_noret_decl(trf_2809)
static void C_fcall trf_2809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2809(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2809(t0,t1);}

C_noret_decl(trf_2849)
static void C_fcall trf_2849(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2849(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2849(t0,t1);}

C_noret_decl(trf_2705)
static void C_fcall trf_2705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2705(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2705(t0,t1);}

C_noret_decl(trf_2118)
static void C_fcall trf_2118(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2118(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2118(t0,t1,t2);}

C_noret_decl(trf_1985)
static void C_fcall trf_1985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1985(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1985(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2020)
static void C_fcall trf_2020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2020(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2020(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3987)){
C_save(t1);
C_rereclaim2(3987*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,305);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],29,"\003syschicken-macro-environment");
lf[3]=C_h_intern(&lf[3],33,"\003syschicken-ffi-macro-environment");
lf[4]=C_h_intern(&lf[4],27,"\010compilercompiler-arguments");
lf[5]=C_h_intern(&lf[5],29,"\010compilerprocess-command-line");
lf[6]=C_h_intern(&lf[6],7,"reverse");
lf[7]=C_h_intern(&lf[7],14,"string->symbol");
lf[8]=C_h_intern(&lf[8],9,"substring");
lf[9]=C_h_intern(&lf[9],25,"\003sysimplicit-exit-handler");
lf[10]=C_h_intern(&lf[10],17,"user-options-pass");
lf[11]=C_h_intern(&lf[11],4,"exit");
lf[12]=C_h_intern(&lf[12],19,"compile-source-file");
lf[13]=C_h_intern(&lf[13],14,"optimize-level");
lf[14]=C_h_intern(&lf[14],22,"optimize-leaf-routines");
lf[15]=C_h_intern(&lf[15],5,"cons*");
lf[16]=C_h_intern(&lf[16],5,"local");
lf[17]=C_h_intern(&lf[17],6,"inline");
lf[18]=C_h_intern(&lf[18],6,"unsafe");
lf[19]=C_h_intern(&lf[19],25,"\010compilercompiler-warning");
lf[20]=C_h_intern(&lf[20],5,"usage");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\047invalid optimization level ~S - ignored");
lf[22]=C_h_intern(&lf[22],11,"debug-level");
lf[23]=C_h_intern(&lf[23],14,"no-lambda-info");
lf[24]=C_h_intern(&lf[24],8,"no-trace");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000 invalid debug level ~S - ignored");
lf[26]=C_h_intern(&lf[26],14,"benchmark-mode");
lf[27]=C_h_intern(&lf[27],17,"fixnum-arithmetic");
lf[28]=C_h_intern(&lf[28],18,"disable-interrupts");
lf[29]=C_h_intern(&lf[29],5,"block");
lf[30]=C_h_intern(&lf[30],11,"lambda-lift");
lf[31]=C_h_intern(&lf[31],31,"\010compilervalid-compiler-options");
lf[32]=C_h_intern(&lf[32],45,"\010compilervalid-compiler-options-with-argument");
lf[33]=C_h_intern(&lf[33],4,"quit");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~s\047 option");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000&invalid compiler option `~a\047 - ignored");
lf[36]=C_h_intern(&lf[36],4,"conc");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[38]=C_h_intern(&lf[38],6,"append");
lf[39]=C_h_intern(&lf[39],4,"argv");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[41]=C_h_intern(&lf[41],6,"remove");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[43]=C_h_intern(&lf[43],12,"string-split");
lf[44]=C_h_intern(&lf[44],6,"getenv");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\017CHICKEN_OPTIONS");
lf[46]=C_h_intern(&lf[46],16,"\003sysmacro-subset");
lf[47]=C_h_intern(&lf[47],28,"\003sysextend-macro-environment");
lf[48]=C_h_intern(&lf[48],15,"foreign-declare");
lf[49]=C_h_intern(&lf[49],12,"\004coredeclare");
lf[50]=C_h_intern(&lf[50],10,"\003sysappend");
lf[51]=C_h_intern(&lf[51],16,"\003syscheck-syntax");
lf[52]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\000");
lf[53]=C_h_intern(&lf[53],18,"\003syser-transformer");
lf[54]=C_h_intern(&lf[54],13,"foreign-value");
lf[55]=C_h_intern(&lf[55],23,"define-foreign-variable");
lf[56]=C_h_intern(&lf[56],5,"begin");
lf[57]=C_h_intern(&lf[57],6,"gensym");
lf[58]=C_h_intern(&lf[58],5,"code_");
lf[59]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[60]=C_h_intern(&lf[60],12,"foreign-code");
lf[61]=C_h_intern(&lf[61],11,"\004coreinline");
lf[62]=C_h_intern(&lf[62],7,"sprintf");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\0007static C_word ~A() { ~A\012; return C_SCHEME_UNDEFINED; }\012");
lf[64]=C_h_intern(&lf[64],18,"string-intersperse");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[66]=C_h_intern(&lf[66],7,"declare");
lf[67]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\000");
lf[68]=C_h_intern(&lf[68],12,"let-location");
lf[69]=C_h_intern(&lf[69],17,"\004corelet-location");
lf[70]=C_h_intern(&lf[70],10,"fold-right");
lf[71]=C_h_intern(&lf[71],10,"append-map");
lf[72]=C_h_intern(&lf[72],7,"\003sysmap");
lf[73]=C_h_intern(&lf[73],3,"let");
lf[74]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001\376\377\001\000\000"
"\000\000\376\001\000\000\001_");
lf[75]=C_h_intern(&lf[75],15,"define-location");
lf[76]=C_h_intern(&lf[76],9,"\004coreset!");
lf[77]=C_h_intern(&lf[77],24,"define-external-variable");
lf[78]=C_h_intern(&lf[78],14,"symbol->string");
lf[79]=C_h_intern(&lf[79],9,"\003syserror");
lf[80]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[81]=C_h_intern(&lf[81],15,"define-external");
lf[82]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[83]=C_h_intern(&lf[83],5,"quote");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[85]=C_h_intern(&lf[85],29,"\004coreforeign-callback-wrapper");
lf[86]=C_h_intern(&lf[86],6,"lambda");
lf[87]=C_h_intern(&lf[87],6,"define");
lf[88]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376"
"\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[89]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376"
"\001\000\000\001_\376\377\001\000\000\000\001");
lf[90]=C_h_intern(&lf[90],21,"\003sysmacro-environment");
lf[91]=C_h_intern(&lf[91],17,"register-feature!");
lf[92]=C_h_intern(&lf[92],6,"srfi-8");
lf[93]=C_h_intern(&lf[93],7,"srfi-16");
lf[94]=C_h_intern(&lf[94],7,"srfi-26");
lf[95]=C_h_intern(&lf[95],7,"srfi-31");
lf[96]=C_h_intern(&lf[96],7,"srfi-15");
lf[97]=C_h_intern(&lf[97],7,"srfi-11");
lf[98]=C_h_intern(&lf[98],12,"define-macro");
lf[99]=C_h_intern(&lf[99],12,"syntax-error");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000<`define-macro\047 is not supported - please use `define-syntax\047");
lf[101]=C_h_intern(&lf[101],3,"use");
lf[102]=C_h_intern(&lf[102],22,"\004corerequire-extension");
lf[103]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[104]=C_h_intern(&lf[104],17,"define-for-syntax");
lf[105]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016\376\377\016");
lf[106]=C_h_intern(&lf[106],25,"\003sysenable-runtime-macros");
lf[107]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[108]=C_h_intern(&lf[108],28,"\003sysregister-meta-expression");
lf[109]=C_h_intern(&lf[109],4,"eval");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\022invalid identifier");
lf[111]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[112]=C_h_intern(&lf[112],3,"rec");
lf[113]=C_h_intern(&lf[113],6,"letrec");
lf[114]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[115]=C_h_intern(&lf[115],16,"define-extension");
lf[116]=C_h_intern(&lf[116],22,"chicken-compile-shared");
lf[117]=C_h_intern(&lf[117],9,"compiling");
lf[118]=C_h_intern(&lf[118],4,"name");
lf[119]=C_h_intern(&lf[119],4,"unit");
lf[120]=C_h_intern(&lf[120],7,"provide");
lf[121]=C_h_intern(&lf[121],4,"else");
lf[122]=C_h_intern(&lf[122],3,"not");
lf[123]=C_h_intern(&lf[123],11,"cond-expand");
lf[124]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\007unquote\376\003\000\000\002\376\001\000\000\006%begin\376\377\016\376\377\016");
lf[125]=C_h_intern(&lf[125],4,"cdar");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid clause specifier");
lf[127]=C_h_intern(&lf[127],4,"caar");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid clause syntax");
lf[129]=C_h_intern(&lf[129],6,"export");
lf[130]=C_h_intern(&lf[130],7,"dynamic");
lf[131]=C_h_intern(&lf[131],6,"static");
lf[132]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\001_");
lf[133]=C_h_intern(&lf[133],4,"cute");
lf[134]=C_h_intern(&lf[134],5,"apply");
lf[135]=C_h_intern(&lf[135],5,"<...>");
lf[136]=C_h_intern(&lf[136],2,"<>");
lf[137]=C_h_intern(&lf[137],3,"cut");
lf[138]=C_h_intern(&lf[138],18,"define-record-type");
lf[139]=C_h_intern(&lf[139],18,"\003sysmake-structure");
lf[140]=C_h_intern(&lf[140],14,"\003sysstructure\077");
lf[141]=C_h_intern(&lf[141],15,"\000record-setters");
lf[142]=C_h_intern(&lf[142],12,"\003sysfeatures");
lf[143]=C_h_intern(&lf[143],19,"\003syscheck-structure");
lf[144]=C_h_intern(&lf[144],10,"\004corecheck");
lf[145]=C_h_intern(&lf[145],13,"\003sysblock-ref");
lf[146]=C_h_intern(&lf[146],14,"\003sysblock-set!");
lf[147]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[148]=C_h_intern(&lf[148],3,"car");
lf[149]=C_h_intern(&lf[149],18,"getter-with-setter");
lf[150]=C_h_intern(&lf[150],1,"y");
lf[151]=C_h_intern(&lf[151],1,"x");
lf[152]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\001\376\003\000\000\002\376\001\000\000\010variable\376\001\000"
"\000\001_");
lf[153]=C_h_intern(&lf[153],14,"condition-case");
lf[154]=C_h_intern(&lf[154],9,"condition");
lf[155]=C_h_intern(&lf[155],8,"\003sysslot");
lf[156]=C_h_intern(&lf[156],10,"\003syssignal");
lf[157]=C_h_intern(&lf[157],4,"cond");
lf[158]=C_h_intern(&lf[158],17,"handle-exceptions");
lf[159]=C_h_intern(&lf[159],4,"memv");
lf[160]=C_h_intern(&lf[160],3,"and");
lf[161]=C_h_intern(&lf[161],4,"kvar");
lf[162]=C_h_intern(&lf[162],5,"exvar");
lf[163]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[164]=C_h_intern(&lf[164],10,"\003sysvalues");
lf[165]=C_h_intern(&lf[165],9,"\003sysapply");
lf[166]=C_h_intern(&lf[166],20,"\003syscall-with-values");
lf[167]=C_h_intern(&lf[167],22,"with-exception-handler");
lf[168]=C_h_intern(&lf[168],30,"call-with-current-continuation");
lf[169]=C_h_intern(&lf[169],4,"args");
lf[170]=C_h_intern(&lf[170],1,"k");
lf[171]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[172]=C_h_intern(&lf[172],21,"define-record-printer");
lf[173]=C_h_intern(&lf[173],27,"\003sysregister-record-printer");
lf[174]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[175]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[176]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[177]=C_h_intern(&lf[177],11,"case-lambda");
lf[178]=C_h_intern(&lf[178],6,"length");
lf[179]=C_h_intern(&lf[179],9,"split-at!");
lf[180]=C_h_intern(&lf[180],4,"take");
lf[181]=C_h_intern(&lf[181],3,"map");
lf[182]=C_h_intern(&lf[182],4,"list");
lf[183]=C_h_intern(&lf[183],3,"cdr");
lf[184]=C_h_intern(&lf[184],4,"fx>=");
lf[185]=C_h_intern(&lf[185],3,"fx=");
lf[186]=C_h_intern(&lf[186],11,"lambda-list");
lf[187]=C_h_intern(&lf[187],25,"\003sysdecompose-lambda-list");
lf[188]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corecheck\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\003syserror\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreimmutable\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376B\000\0000no matching clause in call to \047case-lambda\047 form\376\377\016\376\377\016\376\377\016"
"\376\377\016");
lf[189]=C_h_intern(&lf[189],2,"if");
lf[190]=C_h_intern(&lf[190],4,"lvar");
lf[191]=C_h_intern(&lf[191],4,"rvar");
lf[192]=C_h_intern(&lf[192],3,"min");
lf[193]=C_h_intern(&lf[193],7,"require");
lf[194]=C_h_intern(&lf[194],6,"srfi-1");
lf[195]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[196]=C_h_intern(&lf[196],14,"let-optionals*");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[198]=C_h_intern(&lf[198],14,"\004coreimmutable");
lf[199]=C_h_intern(&lf[199],4,"tmp2");
lf[200]=C_h_intern(&lf[200],3,"tmp");
lf[201]=C_h_intern(&lf[201],5,"null\077");
lf[202]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[203]=C_h_intern(&lf[203],8,"optional");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[205]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[206]=C_h_intern(&lf[206],13,"let-optionals");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[208]=C_h_intern(&lf[208],13,"string-append");
lf[209]=C_h_intern(&lf[209],4,"let*");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\004def-");
lf[211]=C_h_intern(&lf[211],5,"%rest");
lf[212]=C_h_intern(&lf[212],4,"body");
lf[213]=C_h_intern(&lf[213],4,"cadr");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\001%");
lf[215]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[216]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[217]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[218]=C_h_intern(&lf[218],6,"select");
lf[219]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[220]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[221]=C_h_intern(&lf[221],4,"eqv\077");
lf[222]=C_h_intern(&lf[222],2,"or");
lf[223]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[224]=C_h_intern(&lf[224],8,"and-let*");
lf[225]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\001\000\000\001_");
lf[226]=C_h_intern(&lf[226],13,"define-inline");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000*invalid substitution form - must be lambda");
lf[228]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[229]=C_h_intern(&lf[229],18,"\004coredefine-inline");
lf[230]=C_h_intern(&lf[230],9,"nth-value");
lf[231]=C_h_intern(&lf[231],8,"list-ref");
lf[232]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[233]=C_h_intern(&lf[233],13,"letrec-values");
lf[234]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[235]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[236]=C_h_intern(&lf[236],11,"let*-values");
lf[237]=C_h_intern(&lf[237],10,"let-values");
lf[238]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[239]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[240]=C_h_intern(&lf[240],13,"define-values");
lf[241]=C_h_intern(&lf[241],11,"set!-values");
lf[242]=C_h_intern(&lf[242],19,"\003sysregister-export");
lf[243]=C_h_intern(&lf[243],18,"\003syscurrent-module");
lf[244]=C_h_intern(&lf[244],12,"\003sysfor-each");
lf[245]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[246]=C_h_intern(&lf[246],14,"\004coreundefined");
lf[247]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[248]=C_h_intern(&lf[248],6,"unless");
lf[249]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[250]=C_h_intern(&lf[250],4,"when");
lf[251]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[252]=C_h_intern(&lf[252],12,"parameterize");
lf[253]=C_h_intern(&lf[253],16,"\003sysdynamic-wind");
lf[254]=C_h_intern(&lf[254],1,"t");
lf[255]=C_h_intern(&lf[255],8,"\003syslist");
lf[256]=C_h_intern(&lf[256],4,"swap");
lf[257]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[258]=C_h_intern(&lf[258],9,"eval-when");
lf[259]=C_h_intern(&lf[259],10,"\000compiling");
lf[260]=C_h_intern(&lf[260],19,"\004corecompiletimetoo");
lf[261]=C_h_intern(&lf[261],20,"\004corecompiletimeonly");
lf[262]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[263]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid situation specifier");
lf[265]=C_h_intern(&lf[265],4,"load");
lf[266]=C_h_intern(&lf[266],7,"compile");
lf[267]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[268]=C_h_intern(&lf[268],9,"fluid-let");
lf[269]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\001\000\000\001_");
lf[270]=C_h_intern(&lf[270],6,"ensure");
lf[271]=C_h_intern(&lf[271],11,"\000type-error");
lf[272]=C_h_intern(&lf[272],15,"\003syssignal-hook");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\033argument has incorrect type");
lf[274]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\003");
lf[275]=C_h_intern(&lf[275],6,"assert");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\020assertion failed");
lf[277]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[278]=C_h_intern(&lf[278],7,"include");
lf[279]=C_h_intern(&lf[279],27,"\003syscurrent-source-filename");
lf[280]=C_h_intern(&lf[280],4,"read");
lf[281]=C_h_intern(&lf[281],20,"with-input-from-file");
lf[282]=C_h_intern(&lf[282],5,"print");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\014; including ");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[285]=C_h_intern(&lf[285],12,"load-verbose");
lf[286]=C_h_intern(&lf[286],28,"\003sysresolve-include-filename");
lf[287]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\377\016");
lf[288]=C_h_intern(&lf[288],4,"time");
lf[289]=C_h_intern(&lf[289],15,"\003sysstart-timer");
lf[290]=C_h_intern(&lf[290],14,"\003sysstop-timer");
lf[291]=C_h_intern(&lf[291],17,"\003sysdisplay-times");
lf[292]=C_h_intern(&lf[292],7,"receive");
lf[293]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[294]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[295]=C_h_intern(&lf[295],13,"define-record");
lf[296]=C_h_intern(&lf[296],3,"val");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\005-set!");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\001\077");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\005make-");
lf[302]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[303]=C_h_intern(&lf[303],11,"\003sysprovide");
lf[304]=C_h_intern(&lf[304],19,"chicken-more-macros");
C_register_lf2(lf,305,create_ptable());
t2=C_mutate(&lf[0] /* (set! c933 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1779,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1777 */
static void C_ccall f_1779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1782,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1780 in k1777 */
static void C_ccall f_1782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1785,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1783 in k1780 in k1777 */
static void C_ccall f_1785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1788,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1791,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1794,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1797,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1800,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_4_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1803,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1806,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1809,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_support_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1812,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_compiler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1812,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1815,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1818,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_driver_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1821,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_platform_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1824,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_backend_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1827,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1830,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#provide */
t3=C_retrieve(lf[303]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[304]);}

/* k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1830,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1834,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#macro-environment */
t3=C_retrieve(lf[90]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1837,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8956,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8958,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8957 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8958(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8958,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8962,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[295],t2,lf[302]);}

/* k8960 in a8957 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8962,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8971,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* symbol->string */
t5=*((C_word*)lf[78]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k8969 in k8960 in a8957 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8971,2,t0,t1);}
t2=(C_word)C_i_memq(lf[141],C_retrieve(lf[142]));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8977,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* r59 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[56]);}

/* k8975 in k8969 in k8960 in a8957 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8980,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* r59 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[87]);}

/* k8978 in k8975 in k8969 in k8960 in a8957 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* r59 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[149]);}

/* k8981 in k8978 in k8975 in k8969 in k8960 in a8957 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8986,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* r59 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[86]);}

/* k8984 in k8981 in k8978 in k8975 in k8969 in k8960 in a8957 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9356,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9396,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* string-append */
t4=*((C_word*)lf[208]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[301],((C_word*)t0)[2]);}

/* k9394 in k8984 in k8981 in k8978 in k8975 in k8969 in k8960 in a8957 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_9396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->symbol */
t2=*((C_word*)lf[7]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9354 in k8984 in k8981 in k8978 in k8975 in k8969 in k8960 in a8957 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_9356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9356,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[83],t2);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9388,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t3,tmp=(C_word)a,a+=13,tmp);
/* ##sys#append */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);}

/* k9386 in k9354 in k8984 in k8981 in k8978 in k8975 in k8969 in k8960 in a8957 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_9388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9388,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[139],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t8);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9304,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t9,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9348,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* string-append */
t12=*((C_word*)lf[208]+1);
((C_proc4)C_retrieve_proc(t12))(4,t12,t11,((C_word*)t0)[2],lf[300]);}

/* k9346 in k9386 in k9354 in k8984 in k8981 in k8978 in k8975 in k8969 in k8960 in a8957 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_9348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->symbol */
t2=*((C_word*)lf[7]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9302 in k9386 in k9354 in k8984 in k8981 in k8978 in k8975 in k8969 in k8960 in a8957 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_9304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9304,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[151],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[83],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[151],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[140],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t2,t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t1,t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t12);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9009,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t13,tmp=(C_word)a,a+=6,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9013,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9015,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t17,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp));
t19=((C_word*)t17)[1];
f_9015(t19,t15,((C_word*)t0)[2],C_fix(1));}

/* mapslots in k9302 in k9386 in k9354 in k8984 in k8981 in k8978 in k8975 in k8969 in k8960 in a8957 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_9015(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9015,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t3,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* symbol->string */
t7=*((C_word*)lf[78]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}}

/* k9023 in mapslots in k9302 in k9386 in k9354 in k8984 in k8981 in k8978 in k8975 in k8969 in k8960 in a8957 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_9025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9028,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9292,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* string-append */
t4=*((C_word*)lf[208]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[2],lf[298],t1,lf[299]);}

/* k9290 in k9023 in mapslots in k9302 in k9386 in k9354 in k8984 in k8981 in k8978 in k8975 in k8969 in k8960 in a8957 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_9292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->symbol */
t2=*((C_word*)lf[7]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9026 in k9023 in mapslots in k9302 in k9386 in k9354 in k8984 in k8981 in k8978 in k8975 in k8969 in k8960 in a8957 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_9028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9031,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9288,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* string-append */
t4=*((C_word*)lf[208]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[3],lf[297],((C_word*)t0)[2]);}

/* k9286 in k9026 in k9023 in mapslots in k9302 in k9386 in k9354 in k8984 in k8981 in k8978 in k8975 in k8969 in k8960 in a8957 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_9288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->symbol */
t2=*((C_word*)lf[7]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9029 in k9026 in k9023 in mapslots in k9302 in k9386 in k9354 in k8984 in k8981 in k8978 in k8975 in k8969 in k8960 in a8957 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_9031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word ab[124],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9031,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[296],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[151],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[83],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[151],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[143],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[144],t9);
t11=(C_word)C_a_i_cons(&a,2,lf[296],C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[151],t12);
t14=(C_word)C_a_i_cons(&a,2,lf[146],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t10,t15);
t17=(C_word)C_a_i_cons(&a,2,t3,t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t19);
t21=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t20);
t22=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9078,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t21,a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[3])){
t23=(C_word)C_a_i_cons(&a,2,lf[151],C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,lf[83],t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,lf[151],t26);
t28=(C_word)C_a_i_cons(&a,2,lf[143],t27);
t29=(C_word)C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST);
t30=(C_word)C_a_i_cons(&a,2,lf[144],t29);
t31=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t32=(C_word)C_a_i_cons(&a,2,lf[151],t31);
t33=(C_word)C_a_i_cons(&a,2,lf[145],t32);
t34=(C_word)C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,t30,t34);
t36=(C_word)C_a_i_cons(&a,2,t23,t35);
t37=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t36);
t38=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t39=(C_word)C_a_i_cons(&a,2,t37,t38);
t40=t22;
f_9078(t40,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t39));}
else{
t23=(C_word)C_a_i_cons(&a,2,lf[151],C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,lf[83],t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,lf[151],t26);
t28=(C_word)C_a_i_cons(&a,2,lf[143],t27);
t29=(C_word)C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST);
t30=(C_word)C_a_i_cons(&a,2,lf[144],t29);
t31=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t32=(C_word)C_a_i_cons(&a,2,lf[151],t31);
t33=(C_word)C_a_i_cons(&a,2,lf[145],t32);
t34=(C_word)C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,t30,t34);
t36=(C_word)C_a_i_cons(&a,2,t23,t35);
t37=t22;
f_9078(t37,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t36));}}

/* k9076 in k9029 in k9026 in k9023 in mapslots in k9302 in k9386 in k9354 in k8984 in k8981 in k8978 in k8975 in k8969 in k8960 in a8957 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_9078(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9078,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9042,a[2]=t7,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t10=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* mapslots84 */
t11=((C_word*)((C_word*)t0)[2])[1];
f_9015(t11,t8,t9,t10);}

/* k9040 in k9076 in k9029 in k9026 in k9023 in mapslots in k9302 in k9386 in k9354 in k8984 in k8981 in k8978 in k8975 in k8969 in k8960 in a8957 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_9042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9042,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k9011 in k9302 in k9386 in k9354 in k8984 in k8981 in k8978 in k8975 in k8969 in k8960 in a8957 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_9013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k9007 in k9302 in k9386 in k9354 in k8984 in k8981 in k8978 in k8975 in k8969 in k8960 in a8957 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_9009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9009,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k8954 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[295],C_SCHEME_END_OF_LIST,t1);}

/* k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1840,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8813,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8815,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8814 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8815(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8815,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8819,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* r113 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[86]);}

/* k8817 in a8814 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8819,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8822,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* r113 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[73]);}

/* k8820 in k8817 in a8814 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8825,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#check-syntax */
t3=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[292],((C_word*)t0)[4],lf[294]);}

/* k8823 in k8820 in k8817 in a8814 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8825,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8854,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* ##sys#append */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8861,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* ##sys#check-syntax */
t4=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[292],((C_word*)t0)[5],lf[293]);}}

/* k8859 in k8823 in k8820 in k8817 in a8814 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8861,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8876,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cdr(t2);
t7=t5;
f_8876(t7,(C_word)C_i_nullp(t6));}
else{
t6=t5;
f_8876(t6,C_SCHEME_FALSE);}}

/* k8874 in k8859 in k8823 in k8820 in k8817 in a8814 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_8876(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8876,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8891,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8930,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}}

/* k8928 in k8874 in k8859 in k8823 in k8820 in k8817 in a8814 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8930,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[166],t5));}

/* k8889 in k8874 in k8859 in k8823 in k8820 in k8817 in a8814 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8891,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k8852 in k8823 in k8820 in k8817 in a8814 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8854,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[255],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[166],t5));}

/* k8811 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[292],C_SCHEME_END_OF_LIST,t1);}

/* k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1843,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8714,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8716,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8715 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8716,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8720,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* r147 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[254]);}

/* k8718 in a8715 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8723,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* r147 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[56]);}

/* k8721 in k8718 in a8715 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8726,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* r147 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[86]);}

/* k8724 in k8721 in k8718 in a8715 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8726,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[289],C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8805,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k8803 in k8724 in k8721 in k8718 in a8715 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[54],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8805,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[290],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[291],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[164],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[165],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t6,t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,t3,t14);
t16=(C_word)C_a_i_cons(&a,2,lf[166],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t17);
t19=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t18));}

/* k8712 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[288],C_SCHEME_END_OF_LIST,t1);}

/* k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8696,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8698,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8697 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8698,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8706,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cdr(t2);
/* ##sys#append */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}

/* k8704 in a8697 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8706,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[49],t1));}

/* k8694 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[66],C_SCHEME_END_OF_LIST,t1);}

/* k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1849,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8607,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8609,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8608 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8609(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8609,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8613,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[278],t2,lf[287]);}

/* k8611 in a8608 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8616,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* ##sys#resolve-include-filename */
t4=C_retrieve(lf[286]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k8614 in k8611 in a8608 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8619,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* r167 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[56]);}

/* k8617 in k8614 in k8611 in a8608 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8622,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8685,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* load-verbose */
t4=C_retrieve(lf[285]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k8683 in k8617 in k8614 in k8611 in a8608 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* print */
t2=*((C_word*)lf[282]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[283],((C_word*)t0)[2],lf[284]);}
else{
t2=((C_word*)t0)[3];
f_8622(2,t2,C_SCHEME_UNDEFINED);}}

/* k8620 in k8617 in k8614 in k8611 in a8608 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8629,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8633,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8635,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* with-input-from-file */
t5=C_retrieve(lf[281]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}

/* a8634 in k8620 in k8617 in k8614 in k8611 in a8608 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8635,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8641,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8646,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8679,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[253]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t1,t6,t7,t8);}

/* a8678 in a8634 in k8620 in k8617 in k8614 in k8611 in a8608 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8679,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[279]));
t3=C_mutate((C_word*)lf[279]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a8645 in a8634 in k8620 in k8617 in k8614 in k8611 in a8608 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8654,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* read */
t3=*((C_word*)lf[280]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8652 in a8645 in a8634 in k8620 in k8617 in k8614 in k8611 in a8608 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8654,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8656,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_8656(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* doloop192 in k8652 in a8645 in a8634 in k8620 in k8617 in k8614 in k8611 in a8608 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_8656(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8656,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eofp(t2))){
/* reverse */
t4=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8673,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* read */
t5=*((C_word*)lf[280]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k8671 in doloop192 in k8652 in a8645 in a8634 in k8620 in k8617 in k8614 in k8611 in a8608 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8673,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_8656(t3,((C_word*)t0)[2],t1,t2);}

/* a8640 in a8634 in k8620 in k8617 in k8614 in k8611 in a8608 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8641,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[279]));
t3=C_mutate((C_word*)lf[279]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k8631 in k8620 in k8617 in k8614 in k8611 in a8608 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8627 in k8620 in k8617 in k8614 in k8611 in a8608 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8629,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8605 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[278],C_SCHEME_END_OF_LIST,t1);}

/* k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8496,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8498,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8497 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8498(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8498,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8502,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[275],t2,lf[277]);}

/* k8500 in a8497 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8502,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8511,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* r210 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[189]);}

/* k8509 in k8500 in a8497 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8514,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* r210 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[83]);}

/* k8512 in k8509 in k8500 in a8497 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8517,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,lf[276],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[83],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=t2;
f_8517(t7,(C_word)C_a_i_cons(&a,2,lf[198],t6));}
else{
t4=t2;
f_8517(t4,(C_word)C_i_car(((C_word*)t0)[2]));}}

/* k8515 in k8512 in k8509 in k8500 in a8497 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_8517(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8517,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[144],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[246],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8560,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t4,a[6]=t1,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_i_length(((C_word*)t0)[2]);
t9=(C_word)C_fixnum_greaterp(t8,C_fix(1));
t10=(C_truep(t9)?(C_word)C_i_cdr(((C_word*)t0)[2]):C_SCHEME_END_OF_LIST);
/* ##sys#append */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t7,t10,C_SCHEME_END_OF_LIST);}

/* k8558 in k8515 in k8512 in k8509 in k8500 in a8497 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8560,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[79],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k8494 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[275],C_SCHEME_END_OF_LIST,t1);}

/* k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1855,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8359,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8361,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8360 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8361(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8361,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8365,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[270],t2,lf[274]);}

/* k8363 in a8360 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8365,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8377,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* r235 */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[200]);}

/* k8375 in k8363 in a8360 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8380,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* r235 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[73]);}

/* k8378 in k8375 in k8363 in a8360 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8383,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* r235 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[189]);}

/* k8381 in k8378 in k8375 in k8363 in a8360 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[59],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8383,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[144],t7);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8430,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t1,a[6]=t8,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8434,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t11=t10;
f_8434(t11,((C_word*)t0)[2]);}
else{
t11=(C_word)C_a_i_cons(&a,2,lf[273],C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,lf[83],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,lf[198],t13);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,lf[83],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t17);
t19=t10;
f_8434(t19,(C_word)C_a_i_cons(&a,2,t14,t18));}}

/* k8432 in k8381 in k8378 in k8375 in k8363 in a8360 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_8434(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8428 in k8381 in k8378 in k8375 in k8363 in a8360 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8430,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[271],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[272],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k8357 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[270],C_SCHEME_END_OF_LIST,t1);}

/* k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8101,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8103,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8103(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8103,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8107,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[268],t2,lf[269]);}

/* k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8107,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8116,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* ##sys#map */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[148]+1),t2);}

/* k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8116,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8119,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8347,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a8346 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8347(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8347,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8355,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t4=C_retrieve(lf[57]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k8353 in a8346 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r255 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8117 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8122,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8337,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a8336 in k8117 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8337(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8337,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8345,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t4=C_retrieve(lf[57]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k8343 in a8336 in k8117 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r255 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8120 in k8117 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8125,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* r255 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[73]);}

/* k8123 in k8120 in k8117 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8128,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* r255 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[86]);}

/* k8126 in k8123 in k8120 in k8117 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8128,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8139,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8295,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8335,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#map */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[213]+1),((C_word*)t0)[2]);}

/* k8333 in k8126 in k8123 in k8120 in k8117 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[181]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[255]+1),((C_word*)t0)[2],t1);}

/* k8293 in k8126 in k8123 in k8120 in k8117 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8299,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8303,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8307,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_length(((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8313,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_8313(t9,t4,t5);}

/* loop in k8293 in k8126 in k8123 in k8120 in k8117 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_8313(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8313,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8327,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
/* loop282 */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k8325 in loop in k8293 in k8126 in k8123 in k8120 in k8117 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8327,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1));}

/* k8305 in k8293 in k8126 in k8123 in k8120 in k8117 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[181]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[255]+1),((C_word*)t0)[2],t1);}

/* k8301 in k8293 in k8126 in k8123 in k8120 in k8117 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8297 in k8293 in k8126 in k8123 in k8120 in k8117 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8137 in k8126 in k8123 in k8120 in k8117 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8243,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8247,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8279,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[181]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* a8278 in k8137 in k8126 in k8123 in k8120 in k8117 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8279(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8279,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[76],t5));}

/* k8245 in k8137 in k8126 in k8123 in k8120 in k8117 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8251,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8255,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8265,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[181]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8264 in k8245 in k8137 in k8126 in k8123 in k8120 in k8117 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8265(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8265,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[76],t5));}

/* k8253 in k8245 in k8137 in k8126 in k8123 in k8120 in k8117 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8255,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[246],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k8249 in k8245 in k8137 in k8126 in k8123 in k8120 in k8117 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8241 in k8137 in k8126 in k8123 in k8120 in k8117 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8243,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8235,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t3,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* ##sys#append */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k8233 in k8241 in k8137 in k8126 in k8123 in k8120 in k8117 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8235,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8179,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t3,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8183,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8215,tmp=(C_word)a,a+=2,tmp);
/* map */
t7=*((C_word*)lf[181]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,t6,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a8214 in k8233 in k8241 in k8137 in k8126 in k8123 in k8120 in k8117 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8215,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[76],t5));}

/* k8181 in k8233 in k8241 in k8137 in k8126 in k8123 in k8120 in k8117 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8187,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8191,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8201,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[181]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8200 in k8181 in k8233 in k8241 in k8137 in k8126 in k8123 in k8120 in k8117 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8201(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8201,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[76],t5));}

/* k8189 in k8181 in k8233 in k8241 in k8137 in k8126 in k8123 in k8120 in k8117 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8191,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[246],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k8185 in k8181 in k8233 in k8241 in k8137 in k8126 in k8123 in k8120 in k8117 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8177 in k8233 in k8241 in k8137 in k8126 in k8123 in k8120 in k8117 in k8114 in k8105 in a8102 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8179,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[253],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k8099 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[268],C_SCHEME_END_OF_LIST,t1);}

/* k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1861,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7980,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7982,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a7981 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7982,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7986,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[258],t2,lf[267]);}

/* k7984 in a7981 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7986,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7992,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* r318 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[56]);}

/* k7990 in k7984 in a7981 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8093,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k8091 in k7990 in k7984 in a7981 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8093,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* r318 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[109]);}

/* k7996 in k8091 in k7990 in k7984 in a7981 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7998,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* r318 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[266]);}

/* k7999 in k7996 in k8091 in k7990 in k7984 in a7981 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8004,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* r318 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[265]);}

/* k8002 in k7999 in k7996 in k8091 in k7990 in k7984 in a7981 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8004,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8007,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t7,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8044,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=t7,a[8]=t3,a[9]=t10,tmp=(C_word)a,a+=10,tmp));
t12=((C_word*)t10)[1];
f_8044(t12,t8,((C_word*)t0)[2]);}

/* loop in k8002 in k7999 in k7996 in k8091 in k7990 in k7984 in a7981 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_8044(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8044,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8057,a[2]=t1,a[3]=((C_word*)t0)[9],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8067,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* c319 */
t6=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t3,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8065 in loop in k8002 in k7999 in k7996 in k8091 in k7990 in k7984 in a7981 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8067,2,t0,t1);}
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[10],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[9];
f_8057(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8074,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c319 */
t3=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k8072 in k8065 in loop in k8002 in k7999 in k7996 in k8091 in k7990 in k7984 in a7981 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8074,2,t0,t1);}
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[8],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[7];
f_8057(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8081,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c319 */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k8079 in k8072 in k8065 in loop in k8002 in k7999 in k7996 in k8091 in k7990 in k7984 in a7981 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[3];
f_8057(2,t3,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
/* ##sys#error */
t3=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],lf[264],t2);}}

/* k8055 in loop in k8002 in k7999 in k7996 in k8091 in k7990 in k7984 in a7981 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* loop345 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8044(t3,((C_word*)t0)[2],t2);}

/* k8005 in k8002 in k7999 in k7996 in k8091 in k7990 in k7984 in a7981 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_8007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8007,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[259],C_retrieve(lf[142])))){
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?((C_word*)((C_word*)t0)[5])[1]:C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[260],t3));}
else{
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[261],t3));}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)((C_word*)t0)[5])[1])?((C_word*)t0)[4]:lf[262]));}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)((C_word*)t0)[2])[1])?((C_word*)t0)[4]:lf[263]));}}

/* k7978 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[258],C_SCHEME_END_OF_LIST,t1);}

/* k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7778,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7780,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a7779 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7780,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7784,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[252],t2,lf[257]);}

/* k7782 in a7779 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7784,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7793,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* r381 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[256]);}

/* k7791 in k7782 in a7779 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7796,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* r381 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[73]);}

/* k7794 in k7791 in k7782 in a7779 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* r381 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[86]);}

/* k7797 in k7794 in k7791 in k7782 in a7779 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7799,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7802,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* ##sys#map */
t3=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[148]+1),((C_word*)t0)[2]);}

/* k7800 in k7797 in k7794 in k7791 in k7782 in a7779 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7805,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* ##sys#map */
t3=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[213]+1),((C_word*)t0)[2]);}

/* k7803 in k7800 in k7797 in k7794 in k7791 in k7782 in a7779 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7805,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7808,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7968,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a7967 in k7803 in k7800 in k7797 in k7794 in k7791 in k7782 in a7779 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7968(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7968,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7976,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t4=C_retrieve(lf[57]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7974 in a7967 in k7803 in k7800 in k7797 in k7794 in k7791 in k7782 in a7779 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r381 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7806 in k7803 in k7800 in k7797 in k7794 in k7791 in k7782 in a7779 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7808,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7811,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7958,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a7957 in k7806 in k7803 in k7800 in k7797 in k7794 in k7791 in k7782 in a7779 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7958(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7958,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7966,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t4=C_retrieve(lf[57]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7964 in a7957 in k7806 in k7803 in k7800 in k7797 in k7794 in k7791 in k7782 in a7779 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r381 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7809 in k7806 in k7803 in k7800 in k7797 in k7794 in k7791 in k7782 in a7779 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7811,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7822,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7952,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[181]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[255]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k7950 in k7809 in k7806 in k7803 in k7800 in k7797 in k7794 in k7791 in k7782 in a7779 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7956,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[181]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[255]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7954 in k7950 in k7809 in k7806 in k7803 in k7800 in k7797 in k7794 in k7791 in k7782 in a7779 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7820 in k7809 in k7806 in k7803 in k7800 in k7797 in k7794 in k7791 in k7782 in a7779 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7890,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7894,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7896,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[181]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7895 in k7820 in k7809 in k7806 in k7803 in k7800 in k7797 in k7794 in k7791 in k7782 in a7779 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7896(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[39],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7896,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[254],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t2,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[254],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t3,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[76],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t9,t13);
t15=(C_word)C_a_i_cons(&a,2,t7,t14);
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t15));}

/* k7892 in k7820 in k7809 in k7806 in k7803 in k7800 in k7797 in k7794 in k7791 in k7782 in a7779 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7888 in k7820 in k7809 in k7806 in k7803 in k7800 in k7797 in k7794 in k7791 in k7782 in a7779 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7890,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7870,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* ##sys#append */
t8=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k7868 in k7888 in k7820 in k7809 in k7806 in k7803 in k7800 in k7797 in k7794 in k7791 in k7782 in a7779 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7870,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[253],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t11);
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t12));}

/* k7776 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[252],C_SCHEME_END_OF_LIST,t1);}

/* k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1867,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7733,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7735,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a7734 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7735(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7735,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7739,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[250],t2,lf[251]);}

/* k7737 in a7734 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7746,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* r421 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[189]);}

/* k7744 in k7737 in a7734 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7746,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7766,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* r421 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[56]);}

/* k7764 in k7744 in k7737 in a7734 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7770,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k7768 in k7764 in k7744 in k7737 in a7734 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7770,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k7731 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[250],C_SCHEME_END_OF_LIST,t1);}

/* k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1870,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7680,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7682,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a7681 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7682(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7682,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7686,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[248],t2,lf[249]);}

/* k7684 in a7681 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7693,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* r430 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[189]);}

/* k7691 in k7684 in a7681 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7693,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,lf[246],C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7721,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* r430 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[56]);}

/* k7719 in k7691 in k7684 in a7681 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7725,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k7723 in k7719 in k7691 in k7684 in a7681 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7725,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k7678 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[248],C_SCHEME_END_OF_LIST,t1);}

/* k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1873,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7535,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7537,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a7536 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7537(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7537,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7541,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[241],t2,lf[247]);}

/* k7539 in a7536 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7541,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7550,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* r439 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[86]);}

/* k7548 in k7539 in a7536 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7550,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[246],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t6);
t8=(C_word)C_a_i_cons(&a,2,t1,t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t4,t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[166],t10));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[76],t5));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7619,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_retrieve(lf[57]),((C_word*)t0)[4]);}}}

/* k7617 in k7548 in k7539 in a7536 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7619,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7646,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7650,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7652,tmp=(C_word)a,a+=2,tmp);
/* map */
t8=*((C_word*)lf[181]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,t7,((C_word*)t0)[2],t1);}

/* a7651 in k7617 in k7548 in k7539 in a7536 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7652(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7652,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[76],t5));}

/* k7648 in k7617 in k7548 in k7539 in a7536 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7644 in k7617 in k7548 in k7539 in a7536 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7646,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[166],t5));}

/* k7533 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[241],C_SCHEME_END_OF_LIST,t1);}

/* k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1876,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7493,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7495,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a7494 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7495(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7495,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7499,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[240],t2,lf[245]);}

/* k7497 in a7494 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7502,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7519,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* for-each */
t5=*((C_word*)lf[244]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a7518 in k7497 in a7494 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7519(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7519,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7527,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#current-module */
t4=C_retrieve(lf[243]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7525 in a7518 in k7497 in a7494 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#register-export */
t2=C_retrieve(lf[242]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7500 in k7497 in a7494 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7509,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* r476 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[241]);}

/* k7507 in k7500 in k7497 in a7494 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7513,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k7511 in k7507 in k7500 in k7497 in a7494 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7513,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7491 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[240],C_SCHEME_END_OF_LIST,t1);}

/* k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1876,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7105,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7107,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7107(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7107,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7111,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[237],t2,lf[239]);}

/* k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7111,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7120,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* r495 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[73]);}

/* k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7120,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7123,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* r495 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[86]);}

/* k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7123,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7125,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t7=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7156,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7198,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* map */
t9=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,*((C_word*)lf[148]+1),((C_word*)t0)[3]);}

/* k7196 in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7201,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7451,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_7451(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* loop in k7196 in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_7451(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7451,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7464,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t4))){
/* append */
t6=*((C_word*)lf[38]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t4))){
/* append*503 */
t6=((C_word*)((C_word*)t0)[2])[1];
f_7125(t6,t5,t4,t3);}
else{
t6=t5;
f_7464(2,t6,(C_word)C_a_i_cons(&a,2,t4,t3));}}}}

/* k7462 in loop in k7196 in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* loop524 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7451(t3,((C_word*)t0)[2],t2,t1);}

/* k7199 in k7196 in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7201,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7204,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7437,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a7436 in k7199 in k7196 in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7437(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7437,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7445,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7449,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k7447 in a7436 in k7199 in k7196 in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r495 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7443 in a7436 in k7199 in k7196 in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7445,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7202 in k7199 in k7196 in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7205,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7216,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7391,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_7391(t7,t3,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}

/* loop in k7202 in k7199 in k7196 in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_7391(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7391,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* reverse */
t4=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7407,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7431,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* map*504 */
t7=((C_word*)((C_word*)t0)[3])[1];
f_7156(t7,t6,((C_word*)t0)[2],t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7424,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* lookup549 */
t7=((C_word*)t0)[2];
f_7205(3,t7,t6,t4);}}}

/* k7422 in loop in k7202 in k7199 in k7196 in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7424,2,t0,t1);}
t2=((C_word*)t0)[3];
f_7407(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k7429 in loop in k7202 in k7199 in k7196 in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7431,2,t0,t1);}
t2=((C_word*)t0)[3];
f_7407(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k7405 in loop in k7202 in k7199 in k7196 in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_7407(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* loop554 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7391(t3,((C_word*)t0)[2],t2,t1);}

/* k7214 in k7202 in k7199 in k7196 in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7216,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7223,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7385,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7384 in k7214 in k7202 in k7199 in k7196 in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7385(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7385,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k7221 in k7214 in k7202 in k7199 in k7196 in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7223,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7225,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_7225(t5,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* fold in k7221 in k7214 in k7202 in k7199 in k7196 in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_7225(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7225,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7243,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7249,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* map */
t7=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7263,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_i_car(t4);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7379,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* cdar */
t8=*((C_word*)lf[125]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}
else{
t7=t5;
f_7263(t7,C_SCHEME_FALSE);}}}

/* k7377 in fold in k7221 in k7214 in k7202 in k7199 in k7196 in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7263(t2,(C_word)C_i_nullp(t1));}

/* k7261 in fold in k7221 in k7214 in k7202 in k7199 in k7196 in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_7263(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7263,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7302,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* caar */
t3=*((C_word*)lf[127]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7345,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[5]);
t9=(C_word)C_i_cdr(((C_word*)t0)[8]);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* fold576 */
t11=((C_word*)((C_word*)t0)[3])[1];
f_7225(t11,t7,t8,t9,t10);}}

/* k7343 in k7261 in fold in k7221 in k7214 in k7202 in k7199 in k7196 in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7345,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[166],t6));}

/* k7300 in k7261 in fold in k7221 in k7214 in k7202 in k7199 in k7196 in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7302,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7282,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
t8=(C_word)C_i_cdr(((C_word*)t0)[7]);
t9=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* fold576 */
t10=((C_word*)((C_word*)t0)[2])[1];
f_7225(t10,t6,t7,t8,t9);}

/* k7280 in k7300 in k7261 in fold in k7221 in k7214 in k7202 in k7199 in k7196 in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7282,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* a7248 in fold in k7221 in k7214 in k7202 in k7199 in k7196 in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7249(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7249,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7257,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lookup549 */
t4=((C_word*)t0)[2];
f_7205(3,t4,t3,t2);}

/* k7255 in a7248 in fold in k7221 in k7214 in k7202 in k7199 in k7196 in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7257,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k7241 in fold in k7221 in k7214 in k7202 in k7199 in k7196 in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7247,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k7245 in k7241 in fold in k7221 in k7214 in k7202 in k7199 in k7196 in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7247,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* lookup in k7202 in k7199 in k7196 in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7205(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7205,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* map* in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_7156(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7156,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7179,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* proc509 */
t6=t2;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
/* proc509 */
t4=t2;
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}}}

/* k7177 in map* in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7179,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7183,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* map*504 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7156(t4,t2,((C_word*)t0)[2],t3);}

/* k7181 in k7177 in map* in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7183,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* append* in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_7125(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7125,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7146,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* append*503 */
t8=t5;
t9=t6;
t10=t3;
t1=t8;
t2=t9;
t3=t10;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}}

/* k7144 in append* in k7121 in k7118 in k7109 in a7106 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7146,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7103 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[237],C_SCHEME_END_OF_LIST,t1);}

/* k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1882,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7033,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7035,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a7034 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7035(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7035,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7039,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[236],t2,lf[238]);}

/* k7037 in a7034 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7039,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7048,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* r613 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[73]);}

/* k7046 in k7037 in a7034 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7051,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* r613 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[237]);}

/* k7049 in k7046 in k7037 in a7034 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7051,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7056,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7056(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fold in k7049 in k7046 in k7037 in a7034 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_7056(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7056,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7074,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7093,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(t2);
/* fold621 */
t9=t5;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}

/* k7091 in fold in k7049 in k7046 in k7037 in a7034 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7093,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k7072 in fold in k7049 in k7046 in k7037 in a7034 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7074,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k7031 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[236],C_SCHEME_END_OF_LIST,t1);}

/* k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1885,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6867,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6869,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a6868 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6869(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6869,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6873,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[233],t2,lf[235]);}

/* k6871 in a6868 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6873,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6882,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* r637 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[73]);}

/* k6880 in k6871 in a6868 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6885,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* r637 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[86]);}

/* k6883 in k6880 in k6871 in a6868 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7023,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7025,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[3]);}

/* a7024 in k6883 in k6880 in k6871 in a6868 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7025(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7025,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k7021 in k6883 in k6880 in k6871 in a6868 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[50]+1),t1);}

/* k6886 in k6883 in k6880 in k6871 in a6868 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6888,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6891,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7007,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a7006 in k6886 in k6883 in k6880 in k6871 in a6868 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7007(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7007,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7015,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7019,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k7017 in a7006 in k6886 in k6883 in k6880 in k6871 in a6868 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r637 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7013 in a7006 in k6886 in k6883 in k6880 in k6871 in a6868 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7015,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6889 in k6886 in k6883 in k6880 in k6871 in a6868 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6892,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6911,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7001,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7000 in k6889 in k6886 in k6883 in k6880 in k6871 in a6868 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_7001(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7001,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,lf[234]));}

/* k6909 in k6889 in k6886 in k6883 in k6880 in k6871 in a6868 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6915,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6919,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6925,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a6924 in k6909 in k6889 in k6886 in k6883 in k6880 in k6871 in a6868 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6925(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6925,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6953,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t6,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_i_car(t2);
/* map */
t9=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,((C_word*)t0)[2],t8);}

/* k6951 in a6924 in k6909 in k6889 in k6886 in k6883 in k6880 in k6871 in a6868 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6953,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6957,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6961,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6963,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a6962 in k6951 in a6924 in k6909 in k6889 in k6886 in k6883 in k6880 in k6871 in a6868 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6963(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6963,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6979,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lookup654 */
t4=((C_word*)t0)[2];
f_6892(3,t4,t3,t2);}

/* k6977 in a6962 in k6951 in a6924 in k6909 in k6889 in k6886 in k6883 in k6880 in k6871 in a6868 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6979,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[76],t3));}

/* k6959 in k6951 in a6924 in k6909 in k6889 in k6886 in k6883 in k6880 in k6871 in a6868 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6955 in k6951 in a6924 in k6909 in k6889 in k6886 in k6883 in k6880 in k6871 in a6868 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6957,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[166],t5));}

/* k6917 in k6909 in k6889 in k6886 in k6883 in k6880 in k6871 in a6868 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6923,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k6921 in k6917 in k6909 in k6889 in k6886 in k6883 in k6880 in k6871 in a6868 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6913 in k6909 in k6889 in k6886 in k6883 in k6880 in k6871 in a6868 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6915,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* lookup in k6889 in k6886 in k6883 in k6880 in k6871 in a6868 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6892(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6892,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k6865 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[233],C_SCHEME_END_OF_LIST,t1);}

/* k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6793,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6795,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a6794 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6795(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6795,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6799,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[230],t2,lf[232]);}

/* k6797 in a6794 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6799,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6802,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* r679 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[200]);}

/* k6800 in k6797 in a6794 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6805,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* r679 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[231]);}

/* k6803 in k6800 in k6797 in a6794 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6805,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6808,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* r679 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[86]);}

/* k6806 in k6803 in k6800 in k6797 in a6794 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6808,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_i_cadr(((C_word*)t0)[5]);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t10);
t12=(C_word)C_a_i_cons(&a,2,t1,t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t5,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[166],t14));}

/* k6791 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[230],C_SCHEME_END_OF_LIST,t1);}

/* k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1888,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6692,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6694,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a6693 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6694,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6698,a[2]=t2,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* r692 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[86]);}

/* k6696 in a6693 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6700,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6781,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6785,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* quotify-proc697 */
t6=t2;
f_6700(t6,t4,t5,lf[226]);}

/* k6783 in k6696 in a6693 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6779 in k6696 in a6693 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6781,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[229],t1));}

/* quotify-proc in k6696 in a6693 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_6700(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6700,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6704,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#check-syntax */
t5=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,t3,t2,lf[228]);}

/* k6702 in quotify-proc in k6696 in a6693 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6704,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6713,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6761,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* ##sys#append */
t9=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,C_SCHEME_END_OF_LIST);}
else{
t6=t5;
f_6713(t6,(C_word)C_i_cadr(((C_word*)t0)[5]));}}

/* k6759 in k6702 in quotify-proc in k6696 in a6693 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6761,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_6713(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k6711 in k6702 in quotify-proc in k6696 in a6693 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_6713(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6713,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6716,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_pairp(t1);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6725,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_6725(t6,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6735,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_car(t1);
/* c693 */
t8=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k6733 in k6711 in k6702 in quotify-proc in k6696 in a6693 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6725(t2,(C_word)C_i_not(t1));}

/* k6723 in k6711 in k6702 in quotify-proc in k6696 in a6693 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_6725(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* syntax-error */
t2=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[226],lf[227],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_6716(2,t2,C_SCHEME_UNDEFINED);}}

/* k6714 in k6711 in k6702 in quotify-proc in k6696 in a6693 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6716,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k6690 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[226],C_SCHEME_END_OF_LIST,t1);}

/* k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1894,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6529,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6531,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a6530 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6531(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6531,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6535,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[224],t2,lf[225]);}

/* k6533 in a6530 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6535,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6544,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* r731 */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[189]);}

/* k6542 in k6533 in a6530 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6547,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* r731 */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[73]);}

/* k6545 in k6542 in k6533 in a6530 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6547,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6552,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_6552(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fold in k6545 in k6542 in k6533 in a6530 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_6552(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6552,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6566,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* r731 */
t4=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[56]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=(C_word)C_i_car(t3);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6626,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* fold739 */
t17=t7;
t18=t4;
t1=t17;
t2=t18;
goto loop;}
else{
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_cadr(t3);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t6,t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6664,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t10,a[5]=((C_word*)t0)[4],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* fold739 */
t17=t11;
t18=t4;
t1=t17;
t2=t18;
goto loop;}}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6597,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* fold739 */
t17=t5;
t18=t4;
t1=t17;
t2=t18;
goto loop;}}}

/* k6595 in fold in k6545 in k6542 in k6533 in a6530 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6597,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k6662 in fold in k6545 in k6542 in k6533 in a6530 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6664,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k6624 in fold in k6545 in k6542 in k6533 in a6530 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6626,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k6564 in fold in k6545 in k6542 in k6533 in a6530 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6570,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k6568 in k6564 in fold in k6545 in k6542 in k6533 in a6530 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6570,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6527 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[224],C_SCHEME_END_OF_LIST,t1);}

/* k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6360,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6362,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a6361 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6362(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6362,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6366,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[218],t2,lf[223]);}

/* k6364 in a6361 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6366,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6375,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* r775 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[200]);}

/* k6373 in k6364 in a6361 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6378,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* r775 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[189]);}

/* k6376 in k6373 in k6364 in a6361 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6381,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* r775 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[121]);}

/* k6379 in k6376 in k6373 in k6364 in a6361 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6384,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* r775 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[222]);}

/* k6382 in k6379 in k6376 in k6373 in k6364 in a6361 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6387,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* r775 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[221]);}

/* k6385 in k6382 in k6379 in k6376 in k6373 in k6364 in a6361 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6390,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* r775 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[56]);}

/* k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6364 in a6361 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6397,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* r775 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[73]);}

/* k6395 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6364 in a6361 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6397,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6413,a[2]=t1,a[3]=((C_word*)t0)[9],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6415,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=t7,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_6415(t9,t5,((C_word*)t0)[2]);}

/* expand in k6395 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6364 in a6361 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_6415(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6415,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6431,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t3,a[11]=((C_word*)t0)[9],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[218],t3,lf[219]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[220]);}}

/* k6429 in expand in k6395 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6364 in a6361 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6437,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[10]);
/* c776 */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k6435 in k6429 in expand in k6395 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6364 in a6361 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6437,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6444,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* ##sys#append */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6487,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6491,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6493,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[8]);
/* map */
t6=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a6492 in k6435 in k6429 in expand in k6395 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6364 in a6361 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6493(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6493,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k6489 in k6435 in k6429 in expand in k6395 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6364 in a6361 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6485 in k6435 in k6429 in expand in k6395 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6364 in a6361 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6487,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6479,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k6477 in k6485 in k6435 in k6429 in expand in k6395 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6364 in a6361 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6479,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6475,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand791 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6415(t4,t3,((C_word*)t0)[2]);}

/* k6473 in k6477 in k6485 in k6435 in k6429 in expand in k6395 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6364 in a6361 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6475,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k6442 in k6435 in k6429 in expand in k6395 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6364 in a6361 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6444,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6411 in k6395 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6364 in a6361 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6413,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k6358 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[218],C_SCHEME_END_OF_LIST,t1);}

/* k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5928,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5930,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5930,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5934,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[206],t2,lf[217]);}

/* k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5934,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5946,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* r817 */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[201]);}

/* k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* r817 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[189]);}

/* k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5952,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* r817 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[73]);}

/* k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5955,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* r817 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[148]);}

/* k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* r817 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[183]);}

/* k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5961,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* r817 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[86]);}

/* k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5963,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6060,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6249,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* ##sys#check-syntax */
t5=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[206],((C_word*)t0)[2],lf[216]);}

/* k6247 in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6252,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* ##sys#check-syntax */
t3=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[206],((C_word*)t0)[8],lf[215]);}

/* k6250 in k6247 in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6255,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* map */
t3=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[148]+1),((C_word*)t0)[2]);}

/* k6253 in k6250 in k6247 in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6256,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6271,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6348,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a6347 in k6253 in k6250 in k6247 in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6348(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6348,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6356,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* prefix-sym880 */
f_6256(t3,lf[214],t2);}

/* k6354 in a6347 in k6253 in k6250 in k6247 in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r817 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6269 in k6253 in k6250 in k6247 in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6274,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* map */
t3=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[213]+1),((C_word*)t0)[2]);}

/* k6272 in k6269 in k6253 in k6250 in k6247 in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6277,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* r817 */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[212]);}

/* k6275 in k6272 in k6269 in k6253 in k6250 in k6247 in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6280,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* r817 */
t3=((C_word*)t0)[7];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[211]);}

/* k6278 in k6275 in k6272 in k6269 in k6253 in k6250 in k6247 in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6283,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t1,a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6338,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[12]);}

/* a6337 in k6278 in k6275 in k6272 in k6269 in k6253 in k6250 in k6247 in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6338(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6338,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6346,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* prefix-sym880 */
f_6256(t3,lf[210],t2);}

/* k6344 in a6337 in k6278 in k6275 in k6272 in k6269 in k6253 in k6250 in k6247 in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r817 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6281 in k6278 in k6275 in k6272 in k6269 in k6253 in k6250 in k6247 in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6286,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* make-default-procs829 */
t3=((C_word*)t0)[3];
f_5963(t3,t2,((C_word*)t0)[4],((C_word*)t0)[8],t1,((C_word*)t0)[2]);}

/* k6284 in k6281 in k6278 in k6275 in k6272 in k6269 in k6253 in k6250 in k6247 in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6286,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6289,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* make-if-tree830 */
t3=((C_word*)t0)[4];
f_6060(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],((C_word*)t0)[11]);}

/* k6287 in k6284 in k6281 in k6278 in k6275 in k6272 in k6269 in k6253 in k6250 in k6247 in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6296,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* r817 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[209]);}

/* k6294 in k6287 in k6284 in k6281 in k6278 in k6275 in k6272 in k6269 in k6253 in k6250 in k6247 in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6296,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)t0)[4]);
t9=(C_word)C_a_i_cons(&a,2,t3,t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t9,t10);
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,t1,t11));}

/* prefix-sym in k6253 in k6250 in k6247 in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_6256(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6256,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6264,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6268,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* symbol->string */
t6=*((C_word*)lf[78]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}

/* k6266 in prefix-sym in k6253 in k6250 in k6247 in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-append */
t2=*((C_word*)lf[208]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6262 in prefix-sym in k6253 in k6250 in k6247 in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->symbol */
t2=*((C_word*)lf[7]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* make-if-tree in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_6060(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6060,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6066,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=((C_word*)t0)[6],a[9]=t5,tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_6066(t9,t1,t2,t3,C_SCHEME_END_OF_LIST);}

/* recur in make-if-tree in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_6066(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6066,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[144],t7);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6128,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=t8,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* reverse */
t10=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t4);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[201],t6);
t8=(C_word)C_i_car(t3);
t9=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6242,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=t7,a[9]=((C_word*)t0)[3],a[10]=((C_word*)t0)[4],a[11]=t5,a[12]=((C_word*)t0)[5],a[13]=((C_word*)t0)[9],a[14]=t8,tmp=(C_word)a,a+=15,tmp);
/* reverse */
t10=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t4);}}

/* k6240 in recur in make-if-tree in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6242,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[14],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t6,t11);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6186,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t2,a[6]=((C_word*)t0)[9],a[7]=t12,tmp=(C_word)a,a+=8,tmp);
t14=(C_word)C_i_cdr(((C_word*)t0)[5]);
t15=(C_word)C_i_cdr(((C_word*)t0)[4]);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],((C_word*)t0)[3]);
/* recur859 */
t17=((C_word*)((C_word*)t0)[2])[1];
f_6066(t17,t13,t14,t15,t16);}

/* k6184 in k6240 in recur in make-if-tree in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6186,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k6126 in recur in make-if-tree in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6128,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[207],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[83],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[198],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[79],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t2,t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t11);
t13=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t12));}

/* make-default-procs in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_5963(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5963,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5971,a[2]=t4,a[3]=t5,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* reverse */
t7=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}

/* k5969 in make-default-procs in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5975,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* reverse */
t3=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5973 in k5969 in make-default-procs in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5979,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* reverse */
t3=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5977 in k5973 in k5969 in make-default-procs in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5979,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5981,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5981(t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* recur in k5977 in k5973 in k5969 in make-default-procs in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_5981(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5981,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6034,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=t7,a[8]=((C_word*)t0)[3],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
/* reverse */
t9=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t6);}}

/* k6032 in recur in k5977 in k5973 in k5969 in make-default-procs in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6046,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6050,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* reverse */
t4=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6048 in k6032 in recur in k5977 in k5973 in k5969 in make-default-procs in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6050,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k6044 in k6032 in recur in k5977 in k5973 in k5969 in make-default-procs in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6046,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6002,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
t11=(C_word)C_i_car(((C_word*)t0)[5]);
/* recur838 */
t12=((C_word*)((C_word*)t0)[3])[1];
f_5981(t12,t8,((C_word*)t0)[2],t9,t10,t11);}

/* k6000 in k6044 in k6032 in recur in k5977 in k5973 in k5969 in make-default-procs in k5959 in k5956 in k5953 in k5950 in k5947 in k5944 in k5932 in a5929 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_6002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6002,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5926 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[206],C_SCHEME_END_OF_LIST,t1);}

/* k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1903,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5744,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5746,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a5745 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5746(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5746,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5750,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[203],t2,lf[205]);}

/* k5748 in a5745 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5753,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* r914 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[200]);}

/* k5751 in k5748 in a5745 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5756,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* r914 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[201]);}

/* k5754 in k5751 in k5748 in a5745 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5759,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* r914 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[189]);}

/* k5757 in k5754 in k5751 in k5748 in a5745 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5759,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5766,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* r914 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[73]);}

/* k5764 in k5757 in k5754 in k5751 in k5748 in a5745 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5766,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_i_cddr(((C_word*)t0)[7]);
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5801,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_nullp(t8))){
t10=t9;
f_5801(2,t10,C_SCHEME_FALSE);}
else{
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
t11=t9;
f_5801(2,t11,(C_word)C_i_car(t8));}
else{
/* ##sys#error */
t11=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,lf[0],t8);}}}

/* k5799 in k5764 in k5757 in k5754 in k5751 in k5748 in a5745 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5885,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* r914 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[183]);}

/* k5883 in k5799 in k5764 in k5757 in k5754 in k5751 in k5748 in a5745 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5885,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[144],t6);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5861,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t7,a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* r914 */
t9=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,lf[148]);}

/* k5859 in k5883 in k5799 in k5764 in k5757 in k5754 in k5751 in k5748 in a5745 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[60],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5861,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[204],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[83],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[198],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[79],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t3,t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t12);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t15);
t17=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t19);
t21=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t20));}

/* k5742 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[203],C_SCHEME_END_OF_LIST,t1);}

/* k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1906,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5442,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5444,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a5443 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5444,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5448,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[196],t2,lf[202]);}

/* k5446 in a5443 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5448,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5460,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* r936 */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[73]);}

/* k5458 in k5446 in a5443 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* r936 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[189]);}

/* k5461 in k5458 in k5446 in a5443 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5466,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* r936 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[201]);}

/* k5464 in k5461 in k5458 in k5446 in a5443 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5469,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* r936 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[148]);}

/* k5467 in k5464 in k5461 in k5458 in k5446 in a5443 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* r936 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[183]);}

/* k5470 in k5467 in k5464 in k5461 in k5458 in k5446 in a5443 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5472,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5475,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* r936 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[200]);}

/* k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5446 in a5443 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5475,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5494,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5496,a[2]=((C_word*)t0)[3],a[3]=t7,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_5496(t9,t5,t1,((C_word*)t0)[2]);}

/* loop in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5446 in a5443 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_5496(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5496,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[144],t6);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5562,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=t7,a[5]=t2,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* ##sys#append */
t9=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5586,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
/* r936 */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[199]);}
else{
t5=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5724,a[2]=((C_word*)t0)[8],a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t9=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}}}

/* k5722 in loop in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5446 in a5443 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5724,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k5584 in loop in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5446 in a5443 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[77],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5586,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[11]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[11]);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t5,t8);
t10=(C_word)C_a_i_cons(&a,2,t4,t9);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t2,t12);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t14);
t16=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,lf[83],t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t19=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t18);
t20=(C_word)C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,t17,t20);
t22=(C_word)C_a_i_cons(&a,2,t15,t21);
t23=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t22);
t24=(C_word)C_a_i_cons(&a,2,t23,C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,t1,t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,t13,t26);
t28=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5605,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t27,tmp=(C_word)a,a+=5,tmp);
t29=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* loop954 */
t30=((C_word*)((C_word*)t0)[2])[1];
f_5496(t30,t28,t1,t29);}

/* k5603 in k5584 in loop in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5446 in a5443 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5605,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k5560 in loop in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5446 in a5443 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5562,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[197],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[83],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[198],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[79],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t3,t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t12);
t14=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t13));}

/* k5492 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5446 in a5443 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5494,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k5440 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[196],C_SCHEME_END_OF_LIST,t1);}

/* k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1909,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5021,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5023,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5023,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5027,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[177],t2,lf[195]);}

/* k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5029,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5064,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* require */
t4=C_retrieve(lf[193]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[194]);}

/* k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5067,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5421,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5423,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a5422 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5423(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5423,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5433,tmp=(C_word)a,a+=2,tmp);
/* ##sys#decompose-lambda-list */
t5=C_retrieve(lf[187]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a5432 in a5422 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5433,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k5419 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[192]+1),t1);}

/* k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5070,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* genvars982 */
t3=((C_word*)t0)[2];
f_5029(t3,t2,t1);}

/* k5068 in k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5073,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* r979 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[191]);}

/* k5071 in k5068 in k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5076,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* r979 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[190]);}

/* k5074 in k5071 in k5068 in k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5076,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* r979 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[86]);}

/* k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5079,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5082,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* r979 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[73]);}

/* k5080 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5085,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* r979 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[189]);}

/* k5083 in k5080 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5085,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5096,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* append */
t3=*((C_word*)lf[38]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[4],((C_word*)t0)[10]);}

/* k5094 in k5083 in k5080 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5096,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[178],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5120,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,a[5]=((C_word*)t0)[9],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5122,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* fold-right */
t10=C_retrieve(lf[70]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t7,t8,lf[188],t9);}

/* a5121 in k5094 in k5083 in k5080 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5122(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5122,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5132,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t3,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* ##sys#decompose-lambda-list */
t6=C_retrieve(lf[187]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t4,t5);}

/* a5131 in a5121 in k5094 in k5083 in k5080 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5132(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5132,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_5136,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=((C_word*)t0)[8],a[11]=t1,a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=t3,tmp=(C_word)a,a+=15,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[5]);
/* ##sys#check-syntax */
t7=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,lf[177],t6,lf[186]);}

/* k5134 in a5131 in a5121 in k5094 in k5083 in k5080 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5136,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[14],((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5150,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[6])){
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=t3;
f_5150(t5,C_SCHEME_TRUE);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5370,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* r979 */
t6=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[184]);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5385,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* r979 */
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[185]);}}

/* k5383 in k5134 in a5131 in a5121 in k5094 in k5083 in k5080 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5385,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_5150(t4,(C_word)C_a_i_cons(&a,2,t1,t3));}

/* k5368 in k5134 in a5131 in a5121 in k5094 in k5083 in k5080 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5370,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_5150(t4,(C_word)C_a_i_cons(&a,2,t1,t3));}

/* k5148 in k5134 in a5131 in a5121 in k5094 in k5083 in k5080 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_5150(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5150,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5158,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=t1,a[5]=((C_word*)t0)[13],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5164,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5174,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a5173 in k5148 in k5134 in a5131 in a5121 in k5094 in k5083 in k5080 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5174(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5174,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5178,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5201,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_5201(t8,t4,t3,((C_word*)t0)[2]);}

/* build in a5173 in k5148 in k5134 in a5131 in a5121 in k5094 in k5083 in k5080 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_5201(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5201,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[6])){
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5226,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* ##sys#append */
t9=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cadr(((C_word*)t0)[4]));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5258,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* ##sys#append */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}}}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5269,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5357,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t6=C_retrieve(lf[57]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}}

/* k5355 in build in a5173 in k5148 in k5134 in a5131 in a5121 in k5094 in k5083 in k5080 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r979 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5267 in build in a5173 in k5148 in k5134 in a5131 in a5121 in k5094 in k5083 in k5080 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5269,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5349,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=t2,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* r979 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[148]);}

/* k5347 in k5267 in build in a5173 in k5148 in k5134 in a5131 in a5121 in k5094 in k5083 in k5080 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5349,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5329,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* r979 */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[183]);}

/* k5327 in k5347 in k5267 in build in a5173 in k5148 in k5134 in a5131 in a5121 in k5094 in k5083 in k5080 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5329,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5288,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* build1046 */
t11=((C_word*)((C_word*)t0)[2])[1];
f_5201(t11,t8,t10,((C_word*)t0)[7]);}
else{
/* build1046 */
t10=((C_word*)((C_word*)t0)[2])[1];
f_5201(t10,t8,C_SCHEME_END_OF_LIST,((C_word*)t0)[7]);}}

/* k5286 in k5327 in k5347 in k5267 in build in a5173 in k5148 in k5134 in a5131 in a5121 in k5094 in k5083 in k5080 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5288,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k5256 in build in a5173 in k5148 in k5134 in a5131 in a5121 in k5094 in k5083 in k5080 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5258,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k5224 in build in a5173 in k5148 in k5134 in a5131 in a5121 in k5094 in k5083 in k5080 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5226,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k5176 in a5173 in k5148 in k5134 in a5131 in a5121 in k5094 in k5083 in k5080 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5178,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5195,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* map */
t3=*((C_word*)lf[181]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[182]+1),((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k5193 in k5176 in a5173 in k5148 in k5134 in a5131 in a5121 in k5094 in k5083 in k5080 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5195,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* a5163 in k5148 in k5134 in a5131 in a5121 in k5094 in k5083 in k5080 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5172,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* take */
t3=C_retrieve(lf[180]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5170 in a5163 in k5148 in k5134 in a5131 in a5121 in k5094 in k5083 in k5080 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* split-at! */
t2=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5156 in k5148 in k5134 in a5131 in a5121 in k5094 in k5083 in k5080 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5158,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k5118 in k5094 in k5083 in k5080 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5120,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t6));}

/* genvars in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_5029(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5029,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5035,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_5035(t6,t1,C_fix(0));}

/* loop in genvars in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_5035(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5035,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5049,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5061,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t5=C_retrieve(lf[57]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k5059 in loop in genvars in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r979 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5047 in loop in genvars in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5053,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* loop986 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5035(t4,t2,t3);}

/* k5051 in k5047 in loop in genvars in k5025 in a5022 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5053,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5019 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[177],C_SCHEME_END_OF_LIST,t1);}

/* k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1912,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4923,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4925,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a4924 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4925(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4925,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4929,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[172],t2,lf[176]);}

/* k4927 in a4924 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4929,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4944,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,lf[172],t5,lf[174]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4994,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,lf[172],t5,lf[175]);}}

/* k4992 in k4927 in a4924 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4994,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[83],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5009,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5007 in k4992 in k4927 in a4924 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_5009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5009,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[173],t2));}

/* k4942 in k4927 in a4924 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4944,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(0));
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[83],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4967,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* r1084 */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[86]);}

/* k4965 in k4942 in k4927 in a4924 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4967,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4979,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4977 in k4965 in k4942 in k4927 in a4924 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4979,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[173],t5));}

/* k4921 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[172],C_SCHEME_END_OF_LIST,t1);}

/* k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1915,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4729,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4731,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a4730 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4731,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4735,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[158],t2,lf[171]);}

/* k4733 in a4730 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4735,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4738,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* r1109 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[170]);}

/* k4736 in k4733 in a4730 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4738,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4741,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* r1109 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[169]);}

/* k4739 in k4736 in k4733 in a4730 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4744,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* r1109 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[86]);}

/* k4742 in k4739 in k4736 in k4733 in a4730 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4755,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* r1109 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[168]);}

/* k4753 in k4742 in k4739 in k4736 in k4733 in a4730 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4755,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4783,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* r1109 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[167]);}

/* k4781 in k4753 in k4742 in k4739 in k4736 in k4733 in a4730 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4783,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_i_caddr(((C_word*)t0)[8]);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t3,t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t11);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4875,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t12,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t14=(C_word)C_i_cdddr(((C_word*)t0)[8]);
/* ##sys#append */
t15=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,t14,C_SCHEME_END_OF_LIST);}

/* k4873 in k4781 in k4753 in k4742 in k4739 in k4736 in k4733 in a4730 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word ab[84],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4875,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[164],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[165],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[86],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t12);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t3,t15);
t17=(C_word)C_a_i_cons(&a,2,lf[166],t16);
t18=(C_word)C_a_i_cons(&a,2,t17,C_SCHEME_END_OF_LIST);
t19=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t18);
t20=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t19);
t21=(C_word)C_a_i_cons(&a,2,t20,C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t21);
t23=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t22);
t24=(C_word)C_a_i_cons(&a,2,t23,C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t24);
t26=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t25);
t27=(C_word)C_a_i_cons(&a,2,t26,C_SCHEME_END_OF_LIST);
t28=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t27);
t29=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,(C_word)C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST));}

/* k4727 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[158],C_SCHEME_END_OF_LIST,t1);}

/* k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1918,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4402,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4404,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a4403 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4404(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4404,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4408,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[153],t2,lf[163]);}

/* k4406 in a4403 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4411,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* r1122 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[162]);}

/* k4409 in k4406 in a4403 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4414,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* r1122 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[161]);}

/* k4412 in k4409 in k4406 in a4403 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4417,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* r1122 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[160]);}

/* k4415 in k4412 in k4409 in k4406 in a4403 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4417,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4420,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* r1122 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[73]);}

/* k4418 in k4415 in k4412 in k4409 in k4406 in a4403 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4423,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* r1122 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[159]);}

/* k4421 in k4418 in k4415 in k4412 in k4409 in k4406 in a4403 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4426,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* r1122 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[121]);}

/* k4424 in k4421 in k4418 in k4415 in k4412 in k4409 in k4406 in a4403 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4428,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4601,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* r1122 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[158]);}

/* k4599 in k4424 in k4421 in k4418 in k4415 in k4412 in k4409 in k4406 in a4403 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4601,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[154],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[83],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[140],t5);
t7=(C_word)C_a_i_cons(&a,2,C_fix(1),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[155],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t6,t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4641,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t15,tmp=(C_word)a,a+=10,tmp);
/* r1122 */
t17=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t17))(3,t17,t16,lf[157]);}

/* k4639 in k4599 in k4424 in k4421 in k4418 in k4415 in k4412 in k4409 in k4406 in a4403 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4645,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4649,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[7]);
/* map */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}

/* k4647 in k4639 in k4599 in k4424 in k4421 in k4418 in k4415 in k4412 in k4409 in k4406 in a4403 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4649,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[156],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[2],t1,t6);}

/* k4643 in k4639 in k4599 in k4424 in k4421 in k4418 in k4415 in k4412 in k4409 in k4406 in a4403 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4645,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_i_cadr(((C_word*)t0)[5]);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t5,t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* parse-clause in k4424 in k4421 in k4418 in k4415 in k4412 in k4409 in k4406 in a4403 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4428(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[18],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4428,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_symbolp(t3);
t5=(C_truep(t4)?(C_word)C_i_car(t2):C_SCHEME_FALSE);
t6=(C_truep(t5)?(C_word)C_i_cadr(t2):(C_word)C_i_car(t2));
t7=(C_truep(t5)?(C_word)C_i_cddr(t2):(C_word)C_i_cdr(t2));
if(C_truep((C_word)C_i_nullp(t6))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4455,a[2]=((C_word*)t0)[7],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t5,t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4470,a[2]=((C_word*)t0)[5],a[3]=t8,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t13=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t12,t7,C_SCHEME_END_OF_LIST);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4489,a[2]=((C_word*)t0)[5],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t10=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t7,C_SCHEME_END_OF_LIST);}}
else{
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4546,a[2]=t7,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4550,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t11=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,t6);}}

/* a4551 in parse-clause in k4424 in k4421 in k4418 in k4415 in k4412 in k4409 in k4406 in a4403 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4552(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4552,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[83],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t6));}

/* k4548 in parse-clause in k4424 in k4421 in k4418 in k4415 in k4412 in k4409 in k4406 in a4403 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4544 in parse-clause in k4424 in k4421 in k4418 in k4415 in k4412 in k4409 in k4406 in a4403 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4546,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4504,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[5])){
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4519,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t9=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4538,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}

/* k4536 in k4544 in parse-clause in k4424 in k4421 in k4418 in k4415 in k4412 in k4409 in k4406 in a4403 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4538,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
f_4504(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k4517 in k4544 in parse-clause in k4424 in k4421 in k4418 in k4415 in k4412 in k4409 in k4406 in a4403 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4519,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_4504(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k4502 in k4544 in parse-clause in k4424 in k4421 in k4418 in k4415 in k4412 in k4409 in k4406 in a4403 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_4504(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4504,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k4487 in parse-clause in k4424 in k4421 in k4418 in k4415 in k4412 in k4409 in k4406 in a4403 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4489,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
f_4455(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k4468 in parse-clause in k4424 in k4421 in k4418 in k4415 in k4412 in k4409 in k4406 in a4403 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4470,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_4455(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k4453 in parse-clause in k4424 in k4421 in k4418 in k4415 in k4412 in k4409 in k4406 in a4403 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_4455(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4455,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k4400 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[153],C_SCHEME_END_OF_LIST,t1);}

/* k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1918,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1921,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4027,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4029,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a4028 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4029(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4029,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4033,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[138],t2,lf[152]);}

/* k4031 in a4028 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4033,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cadddr(((C_word*)t0)[4]);
t5=(C_word)C_i_cddddr(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4048,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* r1182 */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[56]);}

/* k4046 in k4031 in a4028 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4051,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* r1182 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[86]);}

/* k4049 in k4046 in k4031 in a4028 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4054,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* r1182 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[87]);}

/* k4052 in k4049 in k4046 in k4031 in a4028 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4054,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4060,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* r1182 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[151]);}

/* k4058 in k4052 in k4049 in k4046 in k4031 in a4028 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4063,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* r1182 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[150]);}

/* k4061 in k4058 in k4052 in k4049 in k4046 in k4031 in a4028 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4066,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* r1182 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[149]);}

/* k4064 in k4061 in k4058 in k4052 in k4049 in k4046 in k4031 in a4028 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* map */
t3=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[148]+1),((C_word*)t0)[3]);}

/* k4067 in k4064 in k4061 in k4058 in k4052 in k4049 in k4046 in k4031 in a4028 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4069,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[83],t2);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4381,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t3,tmp=(C_word)a,a+=14,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4385,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4387,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t7=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t1);}

/* a4386 in k4067 in k4064 in k4061 in k4058 in k4052 in k4049 in k4046 in k4031 in a4028 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4387(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4387,3,t0,t1,t2);}
t3=(C_word)C_i_memq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:lf[147]));}

/* k4383 in k4067 in k4064 in k4061 in k4058 in k4052 in k4049 in k4046 in k4031 in a4028 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4379 in k4067 in k4064 in k4061 in k4058 in k4052 in k4049 in k4046 in k4031 in a4028 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[65],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4381,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[139],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[83],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[140],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,t8,t14);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t15);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4092,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t6,a[5]=t16,tmp=(C_word)a,a+=6,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4096,a[2]=t17,tmp=(C_word)a,a+=3,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4098,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t20,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp));
t22=((C_word*)t20)[1];
f_4098(t22,t18,((C_word*)t0)[2],C_fix(1));}

/* loop in k4379 in k4067 in k4064 in k4061 in k4058 in k4052 in k4049 in k4046 in k4031 in a4028 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_4098(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word ab[114],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4098,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_memq(lf[141],C_retrieve(lf[142]));
t6=(C_word)C_i_cddr(t4);
t7=(C_word)C_i_pairp(t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[83],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[143],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,lf[144],t14);
t16=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t16);
t18=(C_word)C_a_i_cons(&a,2,lf[145],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,t15,t19);
t21=(C_word)C_a_i_cons(&a,2,t8,t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t21);
t23=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4124,a[2]=((C_word*)t0)[3],a[3]=t22,a[4]=t5,a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=t2,a[9]=t1,a[10]=((C_word*)t0)[5],a[11]=t4,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t7)){
t24=(C_word)C_i_caddr(t4);
t25=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t26=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t25);
t27=(C_word)C_a_i_cons(&a,2,t24,t26);
t28=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t29=(C_word)C_a_i_cons(&a,2,lf[83],t28);
t30=(C_word)C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t30);
t32=(C_word)C_a_i_cons(&a,2,lf[143],t31);
t33=(C_word)C_a_i_cons(&a,2,t32,C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,lf[144],t33);
t35=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t36=(C_word)C_a_i_cons(&a,2,t3,t35);
t37=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t36);
t38=(C_word)C_a_i_cons(&a,2,lf[146],t37);
t39=(C_word)C_a_i_cons(&a,2,t38,C_SCHEME_END_OF_LIST);
t40=(C_word)C_a_i_cons(&a,2,t34,t39);
t41=(C_word)C_a_i_cons(&a,2,t27,t40);
t42=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t41);
t43=t23;
f_4124(t43,(C_word)C_a_i_cons(&a,2,t42,C_SCHEME_END_OF_LIST));}
else{
t24=t23;
f_4124(t24,C_SCHEME_END_OF_LIST);}}}

/* k4122 in loop in k4379 in k4067 in k4064 in k4061 in k4058 in k4052 in k4049 in k4046 in k4031 in a4028 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_4124(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4124,NULL,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4164,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[4]:C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[11]);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t6);
t8=t3;
f_4164(t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}
else{
t5=t3;
f_4164(t5,((C_word*)t0)[3]);}}

/* k4162 in k4122 in loop in k4379 in k4067 in k4064 in k4061 in k4058 in k4052 in k4049 in k4046 in k4031 in a4028 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_4164(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4164,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4136,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4140,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
t8=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* loop1217 */
t9=((C_word*)((C_word*)t0)[2])[1];
f_4098(t9,t6,t7,t8);}

/* k4138 in k4162 in k4122 in loop in k4379 in k4067 in k4064 in k4061 in k4058 in k4052 in k4049 in k4046 in k4031 in a4028 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4134 in k4162 in k4122 in loop in k4379 in k4067 in k4064 in k4061 in k4058 in k4052 in k4049 in k4046 in k4031 in a4028 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4136,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* ##sys#append */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4094 in k4379 in k4067 in k4064 in k4061 in k4058 in k4052 in k4049 in k4046 in k4031 in a4028 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4090 in k4379 in k4067 in k4064 in k4061 in k4058 in k4052 in k4049 in k4046 in k4031 in a4028 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4092,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k4025 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_4027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[138],C_SCHEME_END_OF_LIST,t1);}

/* k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3839,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3841,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a3840 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3841(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3841,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3845,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* r1254 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[136]);}

/* k3843 in a3840 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3848,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* r1254 */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[135]);}

/* k3846 in k3843 in a3840 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* r1254 */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[134]);}

/* k3849 in k3846 in k3843 in a3840 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* r1254 */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[56]);}

/* k3852 in k3849 in k3846 in k3843 in a3840 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3857,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* r1254 */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[86]);}

/* k3855 in k3852 in k3849 in k3846 in k3843 in a3840 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3857,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3866,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_3866(t6,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k3855 in k3852 in k3849 in k3846 in k3843 in a3840 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_3866(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3866,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3876,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* reverse */
t7=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3969,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=t3,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t7=(C_word)C_i_car(t2);
/* c1255 */
t8=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k3967 in loop in k3855 in k3852 in k3849 in k3846 in k3843 in a3840 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3969,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3972,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3991,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t4=C_retrieve(lf[57]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3997,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* c1255 */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k3995 in k3967 in loop in k3855 in k3852 in k3849 in k3846 in k3843 in a3840 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3997,2,t0,t1);}
if(C_truep(t1)){
/* loop1263 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3866(t2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[2]);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
/* loop1263 */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3866(t5,((C_word*)t0)[5],t2,((C_word*)t0)[4],t4,C_SCHEME_FALSE);}}

/* k3989 in k3967 in loop in k3855 in k3852 in k3849 in k3846 in k3843 in a3840 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r1254 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3970 in k3967 in loop in k3855 in k3852 in k3849 in k3846 in k3843 in a3840 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3972,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* loop1263 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3866(t5,((C_word*)t0)[2],t2,t3,t4,C_SCHEME_FALSE);}

/* k3874 in loop in k3855 in k3852 in k3849 in k3846 in k3843 in a3840 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3876,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3879,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* reverse */
t3=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3877 in k3874 in loop in k3855 in k3852 in k3849 in k3846 in k3843 in a3840 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3879,2,t0,t1);}
if(C_truep(((C_word*)t0)[8])){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3885,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3928,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t4=C_retrieve(lf[57]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3951,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_cdr(t1);
/* ##sys#append */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}}

/* k3949 in k3877 in k3874 in loop in k3855 in k3852 in k3849 in k3846 in k3843 in a3840 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3951,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k3926 in k3877 in k3874 in loop in k3855 in k3852 in k3849 in k3846 in k3843 in a3840 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r1254 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3883 in k3877 in k3874 in loop in k3855 in k3852 in k3849 in k3846 in k3843 in a3840 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3896,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* ##sys#append */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k3894 in k3883 in k3877 in k3874 in loop in k3855 in k3852 in k3849 in k3846 in k3843 in a3840 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3896,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3916,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
/* ##sys#append */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k3914 in k3894 in k3883 in k3877 in k3874 in loop in k3855 in k3852 in k3849 in k3846 in k3843 in a3840 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3916,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k3837 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[137],C_SCHEME_END_OF_LIST,t1);}

/* k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3620,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3622,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a3621 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3622(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3622,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3626,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* r1295 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[73]);}

/* k3624 in a3621 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3629,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* r1295 */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[86]);}

/* k3627 in k3624 in a3621 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3629,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3632,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* r1295 */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[136]);}

/* k3630 in k3627 in k3624 in a3621 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3635,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* r1295 */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[135]);}

/* k3633 in k3630 in k3627 in k3624 in a3621 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3638,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* r1295 */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[134]);}

/* k3636 in k3633 in k3630 in k3627 in k3624 in a3621 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3638,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3647,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_3647(t6,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k3636 in k3633 in k3630 in k3627 in k3624 in a3621 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_3647(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3647,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t2))){
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3657,a[2]=t5,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=t4,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t6,tmp=(C_word)a,a+=10,tmp);
/* reverse */
t8=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3766,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t8=(C_word)C_i_car(t2);
/* c1296 */
t9=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t9))(4,t9,t7,((C_word*)t0)[2],t8);}}

/* k3764 in loop in k3636 in k3633 in k3630 in k3627 in k3624 in a3621 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3766,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3769,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3788,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t4=C_retrieve(lf[57]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3794,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[10]);
/* c1296 */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k3792 in k3764 in loop in k3636 in k3633 in k3630 in k3627 in k3624 in a3621 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3794,2,t0,t1);}
if(C_truep(t1)){
/* loop1304 */
t2=((C_word*)((C_word*)t0)[8])[1];
f_3647(t2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3800,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3827,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t4=C_retrieve(lf[57]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k3825 in k3792 in k3764 in loop in k3636 in k3633 in k3630 in k3627 in k3624 in a3621 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r1295 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3798 in k3792 in k3764 in loop in k3636 in k3633 in k3630 in k3627 in k3624 in a3621 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3800,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
t6=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* loop1304 */
t7=((C_word*)((C_word*)t0)[4])[1];
f_3647(t7,((C_word*)t0)[3],t2,((C_word*)t0)[2],t5,t6,C_SCHEME_FALSE);}

/* k3786 in k3764 in loop in k3636 in k3633 in k3630 in k3627 in k3624 in a3621 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r1295 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3767 in k3764 in loop in k3636 in k3633 in k3630 in k3627 in k3624 in a3621 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3769,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* loop1304 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3647(t5,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2],t4,C_SCHEME_FALSE);}

/* k3655 in loop in k3636 in k3633 in k3630 in k3627 in k3624 in a3621 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3660,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* reverse */
t3=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3658 in k3655 in loop in k3636 in k3633 in k3630 in k3627 in k3624 in a3621 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3660,2,t0,t1);}
if(C_truep(((C_word*)t0)[9])){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3666,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3721,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t4=C_retrieve(lf[57]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3756,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(t1);
/* ##sys#append */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}}

/* k3754 in k3658 in k3655 in loop in k3636 in k3633 in k3630 in k3627 in k3624 in a3621 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3756,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k3719 in k3658 in k3655 in loop in k3636 in k3633 in k3630 in k3627 in k3624 in a3621 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r1295 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3664 in k3658 in k3655 in loop in k3636 in k3633 in k3630 in k3627 in k3624 in a3621 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3689,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* ##sys#append */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k3687 in k3664 in k3658 in k3655 in loop in k3636 in k3633 in k3630 in k3627 in k3624 in a3621 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3689,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3709,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[8]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
/* ##sys#append */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k3707 in k3687 in k3664 in k3658 in k3655 in loop in k3636 in k3633 in k3630 in k3627 in k3624 in a3621 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3709,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t8));}

/* k3618 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[133],C_SCHEME_END_OF_LIST,t1);}

/* k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3343,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3345,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3345(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3345,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3349,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[115],t2,lf[132]);}

/* k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3352,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* r1339 */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[66]);}

/* k3350 in k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3355,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* r1339 */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[56]);}

/* k3353 in k3350 in k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3358,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* r1339 */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[131]);}

/* k3356 in k3353 in k3350 in k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3358,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3361,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* r1339 */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[130]);}

/* k3359 in k3356 in k3353 in k3350 in k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3364,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* r1339 */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[129]);}

/* k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3364,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[9]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3373,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_3373(t6,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t2,C_SCHEME_FALSE);}

/* loop in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_3373(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3373,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t4))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3383,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3513,a[2]=((C_word*)t0)[9],a[3]=t6,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t8=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t5,C_SCHEME_END_OF_LIST);}
else{
t7=t6;
f_3383(t7,lf[124]);}}
else{
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3519,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=t5,a[7]=t3,a[8]=t1,a[9]=((C_word*)t0)[5],a[10]=t2,a[11]=((C_word*)t0)[6],a[12]=t4,tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_i_car(t4);
t8=t6;
f_3519(t8,(C_word)C_i_pairp(t7));}
else{
t7=t6;
f_3519(t7,C_SCHEME_FALSE);}}}

/* k3517 in loop in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_3519(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3519,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* caar */
t3=*((C_word*)lf[127]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[12]);}
else{
/* syntax-error */
t2=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[8],lf[115],lf[128],((C_word*)t0)[12]);}}

/* k3520 in k3517 in loop in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3522,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3531,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
/* c1340 */
t4=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],t1);}

/* k3529 in k3520 in k3517 in loop in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3531,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3546,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3550,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* cdar */
t4=*((C_word*)lf[125]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3556,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* c1340 */
t3=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k3554 in k3529 in k3520 in k3517 in loop in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3556,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3571,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3575,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* cdar */
t4=*((C_word*)lf[125]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3581,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* c1340 */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k3579 in k3554 in k3529 in k3520 in k3517 in loop in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3581,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3588,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
t4=(C_truep(t3)?t3:C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3596,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* cdar */
t6=*((C_word*)lf[125]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3603,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* caar */
t3=*((C_word*)lf[127]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k3601 in k3579 in k3554 in k3529 in k3520 in k3517 in loop in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* syntax-error */
t2=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[115],lf[126],t1);}

/* k3594 in k3579 in k3554 in k3529 in k3520 in k3517 in loop in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[38]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3586 in k3579 in k3554 in k3529 in k3520 in k3517 in loop in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* loop1348 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3373(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3573 in k3554 in k3529 in k3520 in k3517 in loop in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3569 in k3554 in k3529 in k3520 in k3517 in loop in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3571,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* loop1348 */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3373(t4,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3548 in k3529 in k3520 in k3517 in loop in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3544 in k3529 in k3520 in k3517 in loop in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3546,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* loop1348 */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3373(t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3511 in loop in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3513,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
f_3383(t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k3381 in loop in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_3383(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3383,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3390,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* r1339 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[123]);}

/* k3388 in k3381 in loop in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3498,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* ##sys#append */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k3496 in k3388 in k3381 in loop in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3498,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[116],t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* r1339 */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[122]);}

/* k3484 in k3496 in k3388 in k3381 in loop in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3486,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[117],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3482,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
/* ##sys#append */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k3480 in k3484 in k3496 in k3388 in k3381 in loop in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3482,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3418,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* r1339 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[121]);}

/* k3416 in k3480 in k3484 in k3496 in k3388 in k3381 in loop in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3418,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[118]),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[119],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3446,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=t5,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* r1339 */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[120]);}

/* k3444 in k3416 in k3480 in k3484 in k3496 in k3388 in k3381 in loop in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3458,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* r1339 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[83]);}

/* k3456 in k3444 in k3416 in k3480 in k3484 in k3496 in k3388 in k3381 in loop in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3458,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[118]),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t4);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3442,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
/* ##sys#append */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k3440 in k3456 in k3444 in k3416 in k3480 in k3484 in k3496 in k3388 in k3381 in loop in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in a3344 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3442,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t8));}

/* k3341 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[115],C_SCHEME_END_OF_LIST,t1);}

/* k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1933,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3239,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3241,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a3240 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3241(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3241,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3245,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[112],t2,lf[114]);}

/* k3243 in a3240 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3245,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3251,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* r1402 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[113]);}

/* k3249 in k3243 in a3240 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3251,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3296,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* r1402 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[86]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3335,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* ##sys#append */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}}

/* k3333 in k3249 in k3243 in a3240 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3335,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k3294 in k3249 in k3243 in a3240 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3296,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3308,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k3306 in k3294 in k3249 in k3243 in a3240 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3308,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t6,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k3237 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[112],C_SCHEME_END_OF_LIST,t1);}

/* k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1936,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3131,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3133,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a3132 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3133(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3133,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3137,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[104],t2,lf[111]);}

/* k3135 in a3132 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3137,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[105]:t3);
t6=(C_word)C_i_pairp(t2);
t7=(C_truep(t6)?(C_word)C_i_car(t2):t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3152,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t7,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3211,a[2]=t5,a[3]=t8,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* r1418 */
t10=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,lf[86]);}
else{
t9=t8;
f_3152(t9,(C_word)C_i_car(t5));}}

/* k3209 in k3135 in a3132 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3211,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3223,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k3221 in k3209 in k3135 in a3132 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3223,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_3152(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k3150 in k3135 in a3132 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_3152(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3152,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3155,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3198,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval */
t4=C_retrieve(lf[109]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}
else{
/* syntax-error */
t3=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[104],lf[110],((C_word*)t0)[4]);}}

/* k3196 in k3150 in k3135 in a3132 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3155(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* k3153 in k3150 in k3135 in a3132 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3158,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_cons(&a,2,lf[87],t4);
/* ##sys#register-meta-expression */
t6=C_retrieve(lf[108]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t2,t5);}

/* k3156 in k3153 in k3150 in k3135 in a3132 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3158,2,t0,t1);}
if(C_truep(C_retrieve(lf[106]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3168,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* r1418 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[87]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[107]);}}

/* k3166 in k3156 in k3153 in k3150 in k3135 in a3132 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3168,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t1,t3));}

/* k3129 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[104],C_SCHEME_END_OF_LIST,t1);}

/* k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3106,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3108,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a3107 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3108(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3108,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3112,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[101],t2,lf[103]);}

/* k3110 in a3107 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3112,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[102],t4));}

/* k3104 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[101],C_SCHEME_END_OF_LIST,t1);}

/* k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1942,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3096,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3098,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a3097 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3098(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3098,5,t0,t1,t2,t3,t4);}
/* syntax-error */
t5=C_retrieve(lf[99]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,lf[98],lf[100]);}

/* k3094 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[98],C_SCHEME_END_OF_LIST,t1);}

/* k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1945,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#macro-subset */
t3=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1945,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! chicken-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1948,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* register-feature! */
t4=C_retrieve(lf[91]);
((C_proc8)C_retrieve_proc(t4))(8,t4,t3,lf[92],lf[93],lf[94],lf[95],lf[96],lf[97]);}

/* k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1952,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#macro-environment */
t3=C_retrieve(lf[90]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1955,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2794,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2796,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a2795 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2796(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2796,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2803,a[2]=t3,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* r1506 */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[83]);}

/* k2801 in a2795 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2806,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=t2;
f_2806(t4,(C_word)C_i_stringp(t3));}
else{
t3=t2;
f_2806(t3,C_SCHEME_FALSE);}}

/* k2804 in k2801 in a2795 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_2806(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2806,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2809,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=t1;
if(C_truep(t3)){
t4=t2;
f_2809(t4,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_2809(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t2;
f_2809(t4,C_SCHEME_FALSE);}}}

/* k2807 in k2804 in k2801 in a2795 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_2809(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2809,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2815,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t3=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[81],((C_word*)t0)[5],lf[82]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2914,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
/* ##sys#check-syntax */
t3=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[81],((C_word*)t0)[5],lf[88]);}
else{
/* ##sys#check-syntax */
t3=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[81],((C_word*)t0)[5],lf[89]);}}}

/* k2912 in k2807 in k2804 in k2801 in a2795 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2914,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_i_cadr(((C_word*)t0)[4]):(C_word)C_i_car(((C_word*)t0)[4]));
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2927,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* r1506 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[87]);}

/* k2925 in k2912 in k2807 in k2804 in k2801 in a2795 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2927,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[83],t4);
t6=(C_truep(((C_word*)t0)[6])?(C_word)C_i_car(((C_word*)t0)[5]):lf[84]);
t7=(C_truep(((C_word*)t0)[6])?(C_word)C_i_caddr(((C_word*)t0)[5]):(C_word)C_i_cadr(((C_word*)t0)[5]));
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,lf[83],t8);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3023,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=t2,a[9]=t5,a[10]=t6,a[11]=t9,tmp=(C_word)a,a+=12,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3025,tmp=(C_word)a,a+=2,tmp);
/* map */
t12=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,((C_word*)t0)[3]);}

/* a3024 in k2925 in k2912 in k2807 in k2804 in k2801 in a2795 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3025(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3025,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k3021 in k2925 in k2912 in k2807 in k2804 in k2801 in a2795 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3023,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[83],t2);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2987,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
/* r1506 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[86]);}

/* k2985 in k3021 in k2925 in k2912 in k2807 in k2804 in k2801 in a2795 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2995,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3011,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3010 in k2985 in k3021 in k2925 in k2912 in k2807 in k2804 in k2801 in a2795 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_3011(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3011,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k2993 in k2985 in k3021 in k2925 in k2912 in k2807 in k2804 in k2801 in a2795 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2999,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t3=(C_truep(((C_word*)t0)[3])?(C_word)C_i_cdddr(((C_word*)t0)[2]):(C_word)C_i_cddr(((C_word*)t0)[2]));
/* ##sys#append */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k2997 in k2993 in k2985 in k3021 in k2925 in k2912 in k2807 in k2804 in k2801 in a2795 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2999,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[85],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t10);
t12=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t11));}

/* k2813 in k2807 in k2804 in k2801 in a2795 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2815,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* r1506 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[56]);}

/* k2823 in k2813 in k2807 in k2804 in k2801 in a2795 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2899,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* r1506 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[55]);}

/* k2897 in k2823 in k2813 in k2807 in k2804 in k2801 in a2795 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2899,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2879,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* r1506 */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[77]);}

/* k2877 in k2897 in k2823 in k2813 in k2807 in k2804 in k2801 in a2795 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2879,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2849,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cddr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_caddr(((C_word*)t0)[6]);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[76],t12);
t14=t8;
f_2849(t14,(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST));}
else{
t10=t8;
f_2849(t10,C_SCHEME_END_OF_LIST);}}

/* k2847 in k2877 in k2897 in k2823 in k2813 in k2807 in k2804 in k2801 in a2795 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_2849(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2843 in k2877 in k2897 in k2823 in k2813 in k2807 in k2804 in k2801 in a2795 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2845,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k2792 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[81],C_SCHEME_END_OF_LIST,t1);}

/* k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2653,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2655,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a2654 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2655(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2655,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2659,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[75],t2,lf[80]);}

/* k2657 in a2654 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2659,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2671,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_2671(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_2671(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k2669 in k2657 in a2654 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2674,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2771,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t4=C_retrieve(lf[57]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2769 in k2669 in k2657 in a2654 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r1559 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2672 in k2669 in k2657 in a2654 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2674,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* r1559 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[56]);}

/* k2679 in k2672 in k2669 in k2657 in a2654 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2751,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* r1559 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[55]);}

/* k2749 in k2679 in k2672 in k2669 in k2657 in a2654 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2767,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* symbol->string */
t3=*((C_word*)lf[78]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k2765 in k2749 in k2679 in k2672 in k2669 in k2657 in a2654 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2767,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2731,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* r1559 */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[77]);}

/* k2729 in k2765 in k2749 in k2679 in k2672 in k2669 in k2657 in a2654 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2731,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2701,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2705,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t9=(C_word)C_i_car(((C_word*)t0)[2]);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t10);
t12=(C_word)C_a_i_cons(&a,2,lf[76],t11);
t13=t8;
f_2705(t13,(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST));}
else{
t9=t8;
f_2705(t9,C_SCHEME_END_OF_LIST);}}

/* k2703 in k2729 in k2765 in k2749 in k2679 in k2672 in k2669 in k2657 in a2654 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_2705(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2699 in k2729 in k2765 in k2749 in k2679 in k2672 in k2669 in k2657 in a2654 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2701,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k2651 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[75],C_SCHEME_END_OF_LIST,t1);}

/* k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1961,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2503,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2505,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a2504 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2505(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2505,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2509,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[68],t2,lf[74]);}

/* k2507 in a2504 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2509,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2518,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* r1585 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[73]);}

/* k2516 in k2507 in a2504 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2521,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2641,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a2640 in k2516 in k2507 in a2504 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2641(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2641,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2649,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
t4=C_retrieve(lf[57]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2647 in a2640 in k2516 in k2507 in a2504 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r1585 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2519 in k2516 in k2507 in a2504 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2532,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2617,tmp=(C_word)a,a+=2,tmp);
/* append-map */
t4=C_retrieve(lf[71]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],t1);}

/* a2616 in k2519 in k2516 in k2507 in a2504 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2617,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cddr(t2);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}}

/* k2530 in k2519 in k2516 in k2507 in a2504 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2540,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2542,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2615,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#append */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k2613 in k2530 in k2519 in k2516 in k2507 in a2504 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2615,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
/* fold-right */
t4=C_retrieve(lf[70]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2541 in k2530 in k2519 in k2516 in k2507 in a2504 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2542,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t2);
t6=(C_word)C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t3,t9);
t11=(C_word)C_a_i_cons(&a,2,t8,t10);
t12=(C_word)C_a_i_cons(&a,2,t7,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,lf[69],t12));}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t8,t9);
t11=(C_word)C_a_i_cons(&a,2,t7,t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,lf[69],t11));}}

/* k2538 in k2530 in k2519 in k2516 in k2507 in a2504 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2540,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k2501 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[68],C_SCHEME_END_OF_LIST,t1);}

/* k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1964,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2435,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2437,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a2436 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2437(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2437,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2441,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[60],t2,lf[67]);}

/* k2439 in a2436 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2444,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* gensym */
t3=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[58]);}

/* k2442 in k2439 in a2436 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2451,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* r1625 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[56]);}

/* k2449 in k2442 in k2439 in a2436 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2475,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* r1625 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[66]);}

/* k2473 in k2449 in k2442 in k2439 in a2436 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2491,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2495,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* string-intersperse */
t5=C_retrieve(lf[64]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,lf[65]);}

/* k2493 in k2473 in k2449 in k2442 in k2439 in a2436 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sprintf */
t2=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[63],((C_word*)t0)[2],t1);}

/* k2489 in k2473 in k2449 in k2442 in k2439 in a2436 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2491,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[48],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[61],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t5,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k2433 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[60],C_SCHEME_END_OF_LIST,t1);}

/* k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1967,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2379,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2381,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a2380 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2381(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2381,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2385,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[54],t2,lf[59]);}

/* k2383 in a2380 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2388,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* gensym */
t3=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[58]);}

/* k2386 in k2383 in a2380 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2395,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* r1636 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[56]);}

/* k2393 in k2386 in k2383 in a2380 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2411,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* r1636 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[55]);}

/* k2409 in k2393 in k2386 in k2383 in a2380 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2411,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[5]);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,t1,t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k2377 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[54],C_SCHEME_END_OF_LIST,t1);}

/* k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2350,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2352,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a2351 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2352(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2352,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2356,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[48],t2,lf[52]);}

/* k2354 in a2351 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2371,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k2369 in k2354 in a2351 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2371,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[48],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[49],t3));}

/* k2348 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[48],C_SCHEME_END_OF_LIST,t1);}

/* k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1973,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#macro-subset */
t3=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1973,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1 /* (set! chicken-ffi-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1977,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2321,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2331,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2339,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2343,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 82   getenv */
t8=C_retrieve(lf[44]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,lf[45]);}

/* k2341 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[42]);
/* chicken.scm: 82   string-split */
t3=C_retrieve(lf[43]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k2337 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 80   remove */
t2=C_retrieve(lf[41]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2330 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2331(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2331,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_string_equal_p(t2,lf[40]));}

/* k2319 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2329,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 83   argv */
t3=C_retrieve(lf[39]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2327 in k2319 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(t1);
/* chicken.scm: 79   append */
t3=*((C_word*)lf[38]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k1975 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1977,2,t0,t1);}
t2=C_mutate((C_word*)lf[4]+1 /* (set! compiler-arguments ...) */,t1);
t3=C_mutate((C_word*)lf[5]+1 /* (set! process-command-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1979,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2086,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2094,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2106,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}

/* a2105 in k1975 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2106(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2106,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2110,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2118,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_2118(t9,t5,((C_word*)t4)[1]);}

/* loop in a2105 in k1975 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_2118(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2118,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_eqp(lf[13],t3);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2140,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t4);
/* chicken.scm: 116  string->number */
C_string_to_number(3,0,t6,t7);}
else{
t6=(C_word)C_eqp(lf[22],t3);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2213,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_car(t4);
/* chicken.scm: 132  string->number */
C_string_to_number(3,0,t7,t8);}
else{
t7=(C_word)C_eqp(lf[26],t3);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2267,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 141  cons* */
t9=C_retrieve(lf[15]);
((C_proc12)C_retrieve_proc(t9))(12,t9,t8,lf[27],lf[28],lf[24],lf[18],lf[14],lf[29],lf[30],lf[23],lf[17],((C_word*)((C_word*)t0)[2])[1]);}
else{
if(C_truep((C_word)C_i_memq(t3,C_retrieve(lf[31])))){
/* chicken.scm: 146  loop */
t17=t1;
t18=t4;
t1=t17;
t2=t18;
goto loop;}
else{
if(C_truep((C_word)C_i_memq(t3,C_retrieve(lf[32])))){
if(C_truep((C_word)C_i_pairp(t4))){
t8=(C_word)C_i_cdr(t4);
/* chicken.scm: 149  loop */
t17=t1;
t18=t8;
t1=t17;
t2=t18;
goto loop;}
else{
/* chicken.scm: 150  quit */
t8=C_retrieve(lf[33]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,lf[34],t3);}}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2304,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2311,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_stringp(t3))){
t10=t9;
f_2311(2,t10,t3);}
else{
/* chicken.scm: 154  conc */
t10=C_retrieve(lf[36]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,lf[37],t3);}}}}}}}}

/* k2309 in loop in a2105 in k1975 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 152  compiler-warning */
t2=C_retrieve(lf[19]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[20],lf[35],t1);}

/* k2302 in loop in a2105 in k1975 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 155  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2118(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2265 in loop in a2105 in k1975 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* chicken.scm: 145  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2118(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2211 in loop in a2105 in k1975 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2216,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
switch(t1){
case C_fix(0):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2230,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 134  cons* */
t4=C_retrieve(lf[15]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[23],lf[24],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,lf[24],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_2216(2,t5,t4);
case C_fix(2):
t3=t2;
f_2216(2,t3,C_SCHEME_FALSE);
default:
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 137  compiler-warning */
t4=C_retrieve(lf[19]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[20],lf[25],t3);}}

/* k2228 in k2211 in loop in a2105 in k1975 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2216(2,t3,t2);}

/* k2214 in k2211 in loop in a2105 in k1975 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 138  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2118(t3,((C_word*)t0)[2],t2);}

/* k2138 in loop in a2105 in k1975 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2140,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2143,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
switch(t1){
case C_fix(0):
t3=t2;
f_2143(2,t3,C_SCHEME_FALSE);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,lf[14],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_2143(2,t5,t4);
case C_fix(2):
t3=(C_word)C_a_i_cons(&a,2,lf[14],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_2143(2,t5,t4);
case C_fix(3):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2183,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 125  cons* */
t4=C_retrieve(lf[15]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,lf[14],lf[16],lf[17],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(4):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2193,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 128  cons* */
t4=C_retrieve(lf[15]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t3,lf[14],lf[16],lf[17],lf[18],((C_word*)((C_word*)t0)[2])[1]);
default:
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 129  compiler-warning */
t4=C_retrieve(lf[19]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[20],lf[21],t3);}}

/* k2191 in k2138 in loop in a2105 in k1975 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2143(2,t3,t2);}

/* k2181 in k2138 in loop in a2105 in k1975 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2143(2,t3,t2);}

/* k2141 in k2138 in loop in a2105 in k1975 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 130  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2118(t3,((C_word*)t0)[2],t2);}

/* k2108 in a2105 in k1975 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2110,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2113,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t2,C_retrieve(lf[12]),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2111 in k2108 in a2105 in k1975 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 157  exit */
t2=C_retrieve(lf[11]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a2093 in k1975 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2101,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 110  user-options-pass */
t3=C_retrieve(lf[10]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2099 in a2093 in k1975 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_retrieve(lf[5]));
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_retrieve(lf[4]));}

/* k2084 in k1975 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2089,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2092,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
t4=C_retrieve(lf[9]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2090 in k2084 in k1975 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k2087 in k2084 in k1975 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##compiler#process-command-line in k1975 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1979(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1979,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1985,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_1985(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in ##compiler#process-command-line in k1975 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_1985(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1985,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1999,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 95   reverse */
t6=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_string_length(t5);
t7=(C_word)C_i_string_ref(t5,C_fix(0));
t8=(C_word)C_eqp(C_make_character(45),t7);
t9=(C_truep(t8)?(C_word)C_fixnum_greaterp(t6,C_fix(1)):C_SCHEME_FALSE);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2020,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t6,C_fix(1)))){
t11=(C_word)C_i_string_ref(t5,C_fix(1));
t12=t10;
f_2020(t12,(C_word)C_eqp(C_make_character(58),t11));}
else{
t11=t10;
f_2020(t11,C_SCHEME_FALSE);}}
else{
if(C_truep(t4)){
t10=(C_word)C_i_cdr(t2);
t11=(C_word)C_a_i_cons(&a,2,t5,t3);
/* chicken.scm: 104  loop */
t17=t1;
t18=t10;
t19=t11;
t20=t4;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}
else{
t10=(C_word)C_i_cdr(t2);
/* chicken.scm: 105  loop */
t17=t1;
t18=t10;
t19=t3;
t20=t5;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}}}}

/* k2018 in loop in ##compiler#process-command-line in k1975 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_fcall f_2020(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2020,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* chicken.scm: 101  loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_1985(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2042,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2046,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 102  substring */
t5=*((C_word*)lf[8]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]);}}

/* k2044 in k2018 in loop in ##compiler#process-command-line in k1975 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 102  string->symbol */
t2=*((C_word*)lf[7]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2040 in k2018 in loop in ##compiler#process-command-line in k1975 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_2042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2042,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* chicken.scm: 102  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1985(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1997 in loop in ##compiler#process-command-line in k1975 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1777 */
static void C_ccall f_1999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 95   values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[705] = {
{"toplevelchicken.scm",(void*)C_toplevel},
{"f_1779chicken.scm",(void*)f_1779},
{"f_1782chicken.scm",(void*)f_1782},
{"f_1785chicken.scm",(void*)f_1785},
{"f_1788chicken.scm",(void*)f_1788},
{"f_1791chicken.scm",(void*)f_1791},
{"f_1794chicken.scm",(void*)f_1794},
{"f_1797chicken.scm",(void*)f_1797},
{"f_1800chicken.scm",(void*)f_1800},
{"f_1803chicken.scm",(void*)f_1803},
{"f_1806chicken.scm",(void*)f_1806},
{"f_1809chicken.scm",(void*)f_1809},
{"f_1812chicken.scm",(void*)f_1812},
{"f_1815chicken.scm",(void*)f_1815},
{"f_1818chicken.scm",(void*)f_1818},
{"f_1821chicken.scm",(void*)f_1821},
{"f_1824chicken.scm",(void*)f_1824},
{"f_1827chicken.scm",(void*)f_1827},
{"f_1830chicken.scm",(void*)f_1830},
{"f_1834chicken.scm",(void*)f_1834},
{"f_8958chicken.scm",(void*)f_8958},
{"f_8962chicken.scm",(void*)f_8962},
{"f_8971chicken.scm",(void*)f_8971},
{"f_8977chicken.scm",(void*)f_8977},
{"f_8980chicken.scm",(void*)f_8980},
{"f_8983chicken.scm",(void*)f_8983},
{"f_8986chicken.scm",(void*)f_8986},
{"f_9396chicken.scm",(void*)f_9396},
{"f_9356chicken.scm",(void*)f_9356},
{"f_9388chicken.scm",(void*)f_9388},
{"f_9348chicken.scm",(void*)f_9348},
{"f_9304chicken.scm",(void*)f_9304},
{"f_9015chicken.scm",(void*)f_9015},
{"f_9025chicken.scm",(void*)f_9025},
{"f_9292chicken.scm",(void*)f_9292},
{"f_9028chicken.scm",(void*)f_9028},
{"f_9288chicken.scm",(void*)f_9288},
{"f_9031chicken.scm",(void*)f_9031},
{"f_9078chicken.scm",(void*)f_9078},
{"f_9042chicken.scm",(void*)f_9042},
{"f_9013chicken.scm",(void*)f_9013},
{"f_9009chicken.scm",(void*)f_9009},
{"f_8956chicken.scm",(void*)f_8956},
{"f_1837chicken.scm",(void*)f_1837},
{"f_8815chicken.scm",(void*)f_8815},
{"f_8819chicken.scm",(void*)f_8819},
{"f_8822chicken.scm",(void*)f_8822},
{"f_8825chicken.scm",(void*)f_8825},
{"f_8861chicken.scm",(void*)f_8861},
{"f_8876chicken.scm",(void*)f_8876},
{"f_8930chicken.scm",(void*)f_8930},
{"f_8891chicken.scm",(void*)f_8891},
{"f_8854chicken.scm",(void*)f_8854},
{"f_8813chicken.scm",(void*)f_8813},
{"f_1840chicken.scm",(void*)f_1840},
{"f_8716chicken.scm",(void*)f_8716},
{"f_8720chicken.scm",(void*)f_8720},
{"f_8723chicken.scm",(void*)f_8723},
{"f_8726chicken.scm",(void*)f_8726},
{"f_8805chicken.scm",(void*)f_8805},
{"f_8714chicken.scm",(void*)f_8714},
{"f_1843chicken.scm",(void*)f_1843},
{"f_8698chicken.scm",(void*)f_8698},
{"f_8706chicken.scm",(void*)f_8706},
{"f_8696chicken.scm",(void*)f_8696},
{"f_1846chicken.scm",(void*)f_1846},
{"f_8609chicken.scm",(void*)f_8609},
{"f_8613chicken.scm",(void*)f_8613},
{"f_8616chicken.scm",(void*)f_8616},
{"f_8619chicken.scm",(void*)f_8619},
{"f_8685chicken.scm",(void*)f_8685},
{"f_8622chicken.scm",(void*)f_8622},
{"f_8635chicken.scm",(void*)f_8635},
{"f_8679chicken.scm",(void*)f_8679},
{"f_8646chicken.scm",(void*)f_8646},
{"f_8654chicken.scm",(void*)f_8654},
{"f_8656chicken.scm",(void*)f_8656},
{"f_8673chicken.scm",(void*)f_8673},
{"f_8641chicken.scm",(void*)f_8641},
{"f_8633chicken.scm",(void*)f_8633},
{"f_8629chicken.scm",(void*)f_8629},
{"f_8607chicken.scm",(void*)f_8607},
{"f_1849chicken.scm",(void*)f_1849},
{"f_8498chicken.scm",(void*)f_8498},
{"f_8502chicken.scm",(void*)f_8502},
{"f_8511chicken.scm",(void*)f_8511},
{"f_8514chicken.scm",(void*)f_8514},
{"f_8517chicken.scm",(void*)f_8517},
{"f_8560chicken.scm",(void*)f_8560},
{"f_8496chicken.scm",(void*)f_8496},
{"f_1852chicken.scm",(void*)f_1852},
{"f_8361chicken.scm",(void*)f_8361},
{"f_8365chicken.scm",(void*)f_8365},
{"f_8377chicken.scm",(void*)f_8377},
{"f_8380chicken.scm",(void*)f_8380},
{"f_8383chicken.scm",(void*)f_8383},
{"f_8434chicken.scm",(void*)f_8434},
{"f_8430chicken.scm",(void*)f_8430},
{"f_8359chicken.scm",(void*)f_8359},
{"f_1855chicken.scm",(void*)f_1855},
{"f_8103chicken.scm",(void*)f_8103},
{"f_8107chicken.scm",(void*)f_8107},
{"f_8116chicken.scm",(void*)f_8116},
{"f_8347chicken.scm",(void*)f_8347},
{"f_8355chicken.scm",(void*)f_8355},
{"f_8119chicken.scm",(void*)f_8119},
{"f_8337chicken.scm",(void*)f_8337},
{"f_8345chicken.scm",(void*)f_8345},
{"f_8122chicken.scm",(void*)f_8122},
{"f_8125chicken.scm",(void*)f_8125},
{"f_8128chicken.scm",(void*)f_8128},
{"f_8335chicken.scm",(void*)f_8335},
{"f_8295chicken.scm",(void*)f_8295},
{"f_8313chicken.scm",(void*)f_8313},
{"f_8327chicken.scm",(void*)f_8327},
{"f_8307chicken.scm",(void*)f_8307},
{"f_8303chicken.scm",(void*)f_8303},
{"f_8299chicken.scm",(void*)f_8299},
{"f_8139chicken.scm",(void*)f_8139},
{"f_8279chicken.scm",(void*)f_8279},
{"f_8247chicken.scm",(void*)f_8247},
{"f_8265chicken.scm",(void*)f_8265},
{"f_8255chicken.scm",(void*)f_8255},
{"f_8251chicken.scm",(void*)f_8251},
{"f_8243chicken.scm",(void*)f_8243},
{"f_8235chicken.scm",(void*)f_8235},
{"f_8215chicken.scm",(void*)f_8215},
{"f_8183chicken.scm",(void*)f_8183},
{"f_8201chicken.scm",(void*)f_8201},
{"f_8191chicken.scm",(void*)f_8191},
{"f_8187chicken.scm",(void*)f_8187},
{"f_8179chicken.scm",(void*)f_8179},
{"f_8101chicken.scm",(void*)f_8101},
{"f_1858chicken.scm",(void*)f_1858},
{"f_7982chicken.scm",(void*)f_7982},
{"f_7986chicken.scm",(void*)f_7986},
{"f_7992chicken.scm",(void*)f_7992},
{"f_8093chicken.scm",(void*)f_8093},
{"f_7998chicken.scm",(void*)f_7998},
{"f_8001chicken.scm",(void*)f_8001},
{"f_8004chicken.scm",(void*)f_8004},
{"f_8044chicken.scm",(void*)f_8044},
{"f_8067chicken.scm",(void*)f_8067},
{"f_8074chicken.scm",(void*)f_8074},
{"f_8081chicken.scm",(void*)f_8081},
{"f_8057chicken.scm",(void*)f_8057},
{"f_8007chicken.scm",(void*)f_8007},
{"f_7980chicken.scm",(void*)f_7980},
{"f_1861chicken.scm",(void*)f_1861},
{"f_7780chicken.scm",(void*)f_7780},
{"f_7784chicken.scm",(void*)f_7784},
{"f_7793chicken.scm",(void*)f_7793},
{"f_7796chicken.scm",(void*)f_7796},
{"f_7799chicken.scm",(void*)f_7799},
{"f_7802chicken.scm",(void*)f_7802},
{"f_7805chicken.scm",(void*)f_7805},
{"f_7968chicken.scm",(void*)f_7968},
{"f_7976chicken.scm",(void*)f_7976},
{"f_7808chicken.scm",(void*)f_7808},
{"f_7958chicken.scm",(void*)f_7958},
{"f_7966chicken.scm",(void*)f_7966},
{"f_7811chicken.scm",(void*)f_7811},
{"f_7952chicken.scm",(void*)f_7952},
{"f_7956chicken.scm",(void*)f_7956},
{"f_7822chicken.scm",(void*)f_7822},
{"f_7896chicken.scm",(void*)f_7896},
{"f_7894chicken.scm",(void*)f_7894},
{"f_7890chicken.scm",(void*)f_7890},
{"f_7870chicken.scm",(void*)f_7870},
{"f_7778chicken.scm",(void*)f_7778},
{"f_1864chicken.scm",(void*)f_1864},
{"f_7735chicken.scm",(void*)f_7735},
{"f_7739chicken.scm",(void*)f_7739},
{"f_7746chicken.scm",(void*)f_7746},
{"f_7766chicken.scm",(void*)f_7766},
{"f_7770chicken.scm",(void*)f_7770},
{"f_7733chicken.scm",(void*)f_7733},
{"f_1867chicken.scm",(void*)f_1867},
{"f_7682chicken.scm",(void*)f_7682},
{"f_7686chicken.scm",(void*)f_7686},
{"f_7693chicken.scm",(void*)f_7693},
{"f_7721chicken.scm",(void*)f_7721},
{"f_7725chicken.scm",(void*)f_7725},
{"f_7680chicken.scm",(void*)f_7680},
{"f_1870chicken.scm",(void*)f_1870},
{"f_7537chicken.scm",(void*)f_7537},
{"f_7541chicken.scm",(void*)f_7541},
{"f_7550chicken.scm",(void*)f_7550},
{"f_7619chicken.scm",(void*)f_7619},
{"f_7652chicken.scm",(void*)f_7652},
{"f_7650chicken.scm",(void*)f_7650},
{"f_7646chicken.scm",(void*)f_7646},
{"f_7535chicken.scm",(void*)f_7535},
{"f_1873chicken.scm",(void*)f_1873},
{"f_7495chicken.scm",(void*)f_7495},
{"f_7499chicken.scm",(void*)f_7499},
{"f_7519chicken.scm",(void*)f_7519},
{"f_7527chicken.scm",(void*)f_7527},
{"f_7502chicken.scm",(void*)f_7502},
{"f_7509chicken.scm",(void*)f_7509},
{"f_7513chicken.scm",(void*)f_7513},
{"f_7493chicken.scm",(void*)f_7493},
{"f_1876chicken.scm",(void*)f_1876},
{"f_7107chicken.scm",(void*)f_7107},
{"f_7111chicken.scm",(void*)f_7111},
{"f_7120chicken.scm",(void*)f_7120},
{"f_7123chicken.scm",(void*)f_7123},
{"f_7198chicken.scm",(void*)f_7198},
{"f_7451chicken.scm",(void*)f_7451},
{"f_7464chicken.scm",(void*)f_7464},
{"f_7201chicken.scm",(void*)f_7201},
{"f_7437chicken.scm",(void*)f_7437},
{"f_7449chicken.scm",(void*)f_7449},
{"f_7445chicken.scm",(void*)f_7445},
{"f_7204chicken.scm",(void*)f_7204},
{"f_7391chicken.scm",(void*)f_7391},
{"f_7424chicken.scm",(void*)f_7424},
{"f_7431chicken.scm",(void*)f_7431},
{"f_7407chicken.scm",(void*)f_7407},
{"f_7216chicken.scm",(void*)f_7216},
{"f_7385chicken.scm",(void*)f_7385},
{"f_7223chicken.scm",(void*)f_7223},
{"f_7225chicken.scm",(void*)f_7225},
{"f_7379chicken.scm",(void*)f_7379},
{"f_7263chicken.scm",(void*)f_7263},
{"f_7345chicken.scm",(void*)f_7345},
{"f_7302chicken.scm",(void*)f_7302},
{"f_7282chicken.scm",(void*)f_7282},
{"f_7249chicken.scm",(void*)f_7249},
{"f_7257chicken.scm",(void*)f_7257},
{"f_7243chicken.scm",(void*)f_7243},
{"f_7247chicken.scm",(void*)f_7247},
{"f_7205chicken.scm",(void*)f_7205},
{"f_7156chicken.scm",(void*)f_7156},
{"f_7179chicken.scm",(void*)f_7179},
{"f_7183chicken.scm",(void*)f_7183},
{"f_7125chicken.scm",(void*)f_7125},
{"f_7146chicken.scm",(void*)f_7146},
{"f_7105chicken.scm",(void*)f_7105},
{"f_1879chicken.scm",(void*)f_1879},
{"f_7035chicken.scm",(void*)f_7035},
{"f_7039chicken.scm",(void*)f_7039},
{"f_7048chicken.scm",(void*)f_7048},
{"f_7051chicken.scm",(void*)f_7051},
{"f_7056chicken.scm",(void*)f_7056},
{"f_7093chicken.scm",(void*)f_7093},
{"f_7074chicken.scm",(void*)f_7074},
{"f_7033chicken.scm",(void*)f_7033},
{"f_1882chicken.scm",(void*)f_1882},
{"f_6869chicken.scm",(void*)f_6869},
{"f_6873chicken.scm",(void*)f_6873},
{"f_6882chicken.scm",(void*)f_6882},
{"f_6885chicken.scm",(void*)f_6885},
{"f_7025chicken.scm",(void*)f_7025},
{"f_7023chicken.scm",(void*)f_7023},
{"f_6888chicken.scm",(void*)f_6888},
{"f_7007chicken.scm",(void*)f_7007},
{"f_7019chicken.scm",(void*)f_7019},
{"f_7015chicken.scm",(void*)f_7015},
{"f_6891chicken.scm",(void*)f_6891},
{"f_7001chicken.scm",(void*)f_7001},
{"f_6911chicken.scm",(void*)f_6911},
{"f_6925chicken.scm",(void*)f_6925},
{"f_6953chicken.scm",(void*)f_6953},
{"f_6963chicken.scm",(void*)f_6963},
{"f_6979chicken.scm",(void*)f_6979},
{"f_6961chicken.scm",(void*)f_6961},
{"f_6957chicken.scm",(void*)f_6957},
{"f_6919chicken.scm",(void*)f_6919},
{"f_6923chicken.scm",(void*)f_6923},
{"f_6915chicken.scm",(void*)f_6915},
{"f_6892chicken.scm",(void*)f_6892},
{"f_6867chicken.scm",(void*)f_6867},
{"f_1885chicken.scm",(void*)f_1885},
{"f_6795chicken.scm",(void*)f_6795},
{"f_6799chicken.scm",(void*)f_6799},
{"f_6802chicken.scm",(void*)f_6802},
{"f_6805chicken.scm",(void*)f_6805},
{"f_6808chicken.scm",(void*)f_6808},
{"f_6793chicken.scm",(void*)f_6793},
{"f_1888chicken.scm",(void*)f_1888},
{"f_6694chicken.scm",(void*)f_6694},
{"f_6698chicken.scm",(void*)f_6698},
{"f_6785chicken.scm",(void*)f_6785},
{"f_6781chicken.scm",(void*)f_6781},
{"f_6700chicken.scm",(void*)f_6700},
{"f_6704chicken.scm",(void*)f_6704},
{"f_6761chicken.scm",(void*)f_6761},
{"f_6713chicken.scm",(void*)f_6713},
{"f_6735chicken.scm",(void*)f_6735},
{"f_6725chicken.scm",(void*)f_6725},
{"f_6716chicken.scm",(void*)f_6716},
{"f_6692chicken.scm",(void*)f_6692},
{"f_1891chicken.scm",(void*)f_1891},
{"f_6531chicken.scm",(void*)f_6531},
{"f_6535chicken.scm",(void*)f_6535},
{"f_6544chicken.scm",(void*)f_6544},
{"f_6547chicken.scm",(void*)f_6547},
{"f_6552chicken.scm",(void*)f_6552},
{"f_6597chicken.scm",(void*)f_6597},
{"f_6664chicken.scm",(void*)f_6664},
{"f_6626chicken.scm",(void*)f_6626},
{"f_6566chicken.scm",(void*)f_6566},
{"f_6570chicken.scm",(void*)f_6570},
{"f_6529chicken.scm",(void*)f_6529},
{"f_1894chicken.scm",(void*)f_1894},
{"f_6362chicken.scm",(void*)f_6362},
{"f_6366chicken.scm",(void*)f_6366},
{"f_6375chicken.scm",(void*)f_6375},
{"f_6378chicken.scm",(void*)f_6378},
{"f_6381chicken.scm",(void*)f_6381},
{"f_6384chicken.scm",(void*)f_6384},
{"f_6387chicken.scm",(void*)f_6387},
{"f_6390chicken.scm",(void*)f_6390},
{"f_6397chicken.scm",(void*)f_6397},
{"f_6415chicken.scm",(void*)f_6415},
{"f_6431chicken.scm",(void*)f_6431},
{"f_6437chicken.scm",(void*)f_6437},
{"f_6493chicken.scm",(void*)f_6493},
{"f_6491chicken.scm",(void*)f_6491},
{"f_6487chicken.scm",(void*)f_6487},
{"f_6479chicken.scm",(void*)f_6479},
{"f_6475chicken.scm",(void*)f_6475},
{"f_6444chicken.scm",(void*)f_6444},
{"f_6413chicken.scm",(void*)f_6413},
{"f_6360chicken.scm",(void*)f_6360},
{"f_1897chicken.scm",(void*)f_1897},
{"f_5930chicken.scm",(void*)f_5930},
{"f_5934chicken.scm",(void*)f_5934},
{"f_5946chicken.scm",(void*)f_5946},
{"f_5949chicken.scm",(void*)f_5949},
{"f_5952chicken.scm",(void*)f_5952},
{"f_5955chicken.scm",(void*)f_5955},
{"f_5958chicken.scm",(void*)f_5958},
{"f_5961chicken.scm",(void*)f_5961},
{"f_6249chicken.scm",(void*)f_6249},
{"f_6252chicken.scm",(void*)f_6252},
{"f_6255chicken.scm",(void*)f_6255},
{"f_6348chicken.scm",(void*)f_6348},
{"f_6356chicken.scm",(void*)f_6356},
{"f_6271chicken.scm",(void*)f_6271},
{"f_6274chicken.scm",(void*)f_6274},
{"f_6277chicken.scm",(void*)f_6277},
{"f_6280chicken.scm",(void*)f_6280},
{"f_6338chicken.scm",(void*)f_6338},
{"f_6346chicken.scm",(void*)f_6346},
{"f_6283chicken.scm",(void*)f_6283},
{"f_6286chicken.scm",(void*)f_6286},
{"f_6289chicken.scm",(void*)f_6289},
{"f_6296chicken.scm",(void*)f_6296},
{"f_6256chicken.scm",(void*)f_6256},
{"f_6268chicken.scm",(void*)f_6268},
{"f_6264chicken.scm",(void*)f_6264},
{"f_6060chicken.scm",(void*)f_6060},
{"f_6066chicken.scm",(void*)f_6066},
{"f_6242chicken.scm",(void*)f_6242},
{"f_6186chicken.scm",(void*)f_6186},
{"f_6128chicken.scm",(void*)f_6128},
{"f_5963chicken.scm",(void*)f_5963},
{"f_5971chicken.scm",(void*)f_5971},
{"f_5975chicken.scm",(void*)f_5975},
{"f_5979chicken.scm",(void*)f_5979},
{"f_5981chicken.scm",(void*)f_5981},
{"f_6034chicken.scm",(void*)f_6034},
{"f_6050chicken.scm",(void*)f_6050},
{"f_6046chicken.scm",(void*)f_6046},
{"f_6002chicken.scm",(void*)f_6002},
{"f_5928chicken.scm",(void*)f_5928},
{"f_1900chicken.scm",(void*)f_1900},
{"f_5746chicken.scm",(void*)f_5746},
{"f_5750chicken.scm",(void*)f_5750},
{"f_5753chicken.scm",(void*)f_5753},
{"f_5756chicken.scm",(void*)f_5756},
{"f_5759chicken.scm",(void*)f_5759},
{"f_5766chicken.scm",(void*)f_5766},
{"f_5801chicken.scm",(void*)f_5801},
{"f_5885chicken.scm",(void*)f_5885},
{"f_5861chicken.scm",(void*)f_5861},
{"f_5744chicken.scm",(void*)f_5744},
{"f_1903chicken.scm",(void*)f_1903},
{"f_5444chicken.scm",(void*)f_5444},
{"f_5448chicken.scm",(void*)f_5448},
{"f_5460chicken.scm",(void*)f_5460},
{"f_5463chicken.scm",(void*)f_5463},
{"f_5466chicken.scm",(void*)f_5466},
{"f_5469chicken.scm",(void*)f_5469},
{"f_5472chicken.scm",(void*)f_5472},
{"f_5475chicken.scm",(void*)f_5475},
{"f_5496chicken.scm",(void*)f_5496},
{"f_5724chicken.scm",(void*)f_5724},
{"f_5586chicken.scm",(void*)f_5586},
{"f_5605chicken.scm",(void*)f_5605},
{"f_5562chicken.scm",(void*)f_5562},
{"f_5494chicken.scm",(void*)f_5494},
{"f_5442chicken.scm",(void*)f_5442},
{"f_1906chicken.scm",(void*)f_1906},
{"f_5023chicken.scm",(void*)f_5023},
{"f_5027chicken.scm",(void*)f_5027},
{"f_5064chicken.scm",(void*)f_5064},
{"f_5423chicken.scm",(void*)f_5423},
{"f_5433chicken.scm",(void*)f_5433},
{"f_5421chicken.scm",(void*)f_5421},
{"f_5067chicken.scm",(void*)f_5067},
{"f_5070chicken.scm",(void*)f_5070},
{"f_5073chicken.scm",(void*)f_5073},
{"f_5076chicken.scm",(void*)f_5076},
{"f_5079chicken.scm",(void*)f_5079},
{"f_5082chicken.scm",(void*)f_5082},
{"f_5085chicken.scm",(void*)f_5085},
{"f_5096chicken.scm",(void*)f_5096},
{"f_5122chicken.scm",(void*)f_5122},
{"f_5132chicken.scm",(void*)f_5132},
{"f_5136chicken.scm",(void*)f_5136},
{"f_5385chicken.scm",(void*)f_5385},
{"f_5370chicken.scm",(void*)f_5370},
{"f_5150chicken.scm",(void*)f_5150},
{"f_5174chicken.scm",(void*)f_5174},
{"f_5201chicken.scm",(void*)f_5201},
{"f_5357chicken.scm",(void*)f_5357},
{"f_5269chicken.scm",(void*)f_5269},
{"f_5349chicken.scm",(void*)f_5349},
{"f_5329chicken.scm",(void*)f_5329},
{"f_5288chicken.scm",(void*)f_5288},
{"f_5258chicken.scm",(void*)f_5258},
{"f_5226chicken.scm",(void*)f_5226},
{"f_5178chicken.scm",(void*)f_5178},
{"f_5195chicken.scm",(void*)f_5195},
{"f_5164chicken.scm",(void*)f_5164},
{"f_5172chicken.scm",(void*)f_5172},
{"f_5158chicken.scm",(void*)f_5158},
{"f_5120chicken.scm",(void*)f_5120},
{"f_5029chicken.scm",(void*)f_5029},
{"f_5035chicken.scm",(void*)f_5035},
{"f_5061chicken.scm",(void*)f_5061},
{"f_5049chicken.scm",(void*)f_5049},
{"f_5053chicken.scm",(void*)f_5053},
{"f_5021chicken.scm",(void*)f_5021},
{"f_1909chicken.scm",(void*)f_1909},
{"f_4925chicken.scm",(void*)f_4925},
{"f_4929chicken.scm",(void*)f_4929},
{"f_4994chicken.scm",(void*)f_4994},
{"f_5009chicken.scm",(void*)f_5009},
{"f_4944chicken.scm",(void*)f_4944},
{"f_4967chicken.scm",(void*)f_4967},
{"f_4979chicken.scm",(void*)f_4979},
{"f_4923chicken.scm",(void*)f_4923},
{"f_1912chicken.scm",(void*)f_1912},
{"f_4731chicken.scm",(void*)f_4731},
{"f_4735chicken.scm",(void*)f_4735},
{"f_4738chicken.scm",(void*)f_4738},
{"f_4741chicken.scm",(void*)f_4741},
{"f_4744chicken.scm",(void*)f_4744},
{"f_4755chicken.scm",(void*)f_4755},
{"f_4783chicken.scm",(void*)f_4783},
{"f_4875chicken.scm",(void*)f_4875},
{"f_4729chicken.scm",(void*)f_4729},
{"f_1915chicken.scm",(void*)f_1915},
{"f_4404chicken.scm",(void*)f_4404},
{"f_4408chicken.scm",(void*)f_4408},
{"f_4411chicken.scm",(void*)f_4411},
{"f_4414chicken.scm",(void*)f_4414},
{"f_4417chicken.scm",(void*)f_4417},
{"f_4420chicken.scm",(void*)f_4420},
{"f_4423chicken.scm",(void*)f_4423},
{"f_4426chicken.scm",(void*)f_4426},
{"f_4601chicken.scm",(void*)f_4601},
{"f_4641chicken.scm",(void*)f_4641},
{"f_4649chicken.scm",(void*)f_4649},
{"f_4645chicken.scm",(void*)f_4645},
{"f_4428chicken.scm",(void*)f_4428},
{"f_4552chicken.scm",(void*)f_4552},
{"f_4550chicken.scm",(void*)f_4550},
{"f_4546chicken.scm",(void*)f_4546},
{"f_4538chicken.scm",(void*)f_4538},
{"f_4519chicken.scm",(void*)f_4519},
{"f_4504chicken.scm",(void*)f_4504},
{"f_4489chicken.scm",(void*)f_4489},
{"f_4470chicken.scm",(void*)f_4470},
{"f_4455chicken.scm",(void*)f_4455},
{"f_4402chicken.scm",(void*)f_4402},
{"f_1918chicken.scm",(void*)f_1918},
{"f_4029chicken.scm",(void*)f_4029},
{"f_4033chicken.scm",(void*)f_4033},
{"f_4048chicken.scm",(void*)f_4048},
{"f_4051chicken.scm",(void*)f_4051},
{"f_4054chicken.scm",(void*)f_4054},
{"f_4060chicken.scm",(void*)f_4060},
{"f_4063chicken.scm",(void*)f_4063},
{"f_4066chicken.scm",(void*)f_4066},
{"f_4069chicken.scm",(void*)f_4069},
{"f_4387chicken.scm",(void*)f_4387},
{"f_4385chicken.scm",(void*)f_4385},
{"f_4381chicken.scm",(void*)f_4381},
{"f_4098chicken.scm",(void*)f_4098},
{"f_4124chicken.scm",(void*)f_4124},
{"f_4164chicken.scm",(void*)f_4164},
{"f_4140chicken.scm",(void*)f_4140},
{"f_4136chicken.scm",(void*)f_4136},
{"f_4096chicken.scm",(void*)f_4096},
{"f_4092chicken.scm",(void*)f_4092},
{"f_4027chicken.scm",(void*)f_4027},
{"f_1921chicken.scm",(void*)f_1921},
{"f_3841chicken.scm",(void*)f_3841},
{"f_3845chicken.scm",(void*)f_3845},
{"f_3848chicken.scm",(void*)f_3848},
{"f_3851chicken.scm",(void*)f_3851},
{"f_3854chicken.scm",(void*)f_3854},
{"f_3857chicken.scm",(void*)f_3857},
{"f_3866chicken.scm",(void*)f_3866},
{"f_3969chicken.scm",(void*)f_3969},
{"f_3997chicken.scm",(void*)f_3997},
{"f_3991chicken.scm",(void*)f_3991},
{"f_3972chicken.scm",(void*)f_3972},
{"f_3876chicken.scm",(void*)f_3876},
{"f_3879chicken.scm",(void*)f_3879},
{"f_3951chicken.scm",(void*)f_3951},
{"f_3928chicken.scm",(void*)f_3928},
{"f_3885chicken.scm",(void*)f_3885},
{"f_3896chicken.scm",(void*)f_3896},
{"f_3916chicken.scm",(void*)f_3916},
{"f_3839chicken.scm",(void*)f_3839},
{"f_1924chicken.scm",(void*)f_1924},
{"f_3622chicken.scm",(void*)f_3622},
{"f_3626chicken.scm",(void*)f_3626},
{"f_3629chicken.scm",(void*)f_3629},
{"f_3632chicken.scm",(void*)f_3632},
{"f_3635chicken.scm",(void*)f_3635},
{"f_3638chicken.scm",(void*)f_3638},
{"f_3647chicken.scm",(void*)f_3647},
{"f_3766chicken.scm",(void*)f_3766},
{"f_3794chicken.scm",(void*)f_3794},
{"f_3827chicken.scm",(void*)f_3827},
{"f_3800chicken.scm",(void*)f_3800},
{"f_3788chicken.scm",(void*)f_3788},
{"f_3769chicken.scm",(void*)f_3769},
{"f_3657chicken.scm",(void*)f_3657},
{"f_3660chicken.scm",(void*)f_3660},
{"f_3756chicken.scm",(void*)f_3756},
{"f_3721chicken.scm",(void*)f_3721},
{"f_3666chicken.scm",(void*)f_3666},
{"f_3689chicken.scm",(void*)f_3689},
{"f_3709chicken.scm",(void*)f_3709},
{"f_3620chicken.scm",(void*)f_3620},
{"f_1927chicken.scm",(void*)f_1927},
{"f_3345chicken.scm",(void*)f_3345},
{"f_3349chicken.scm",(void*)f_3349},
{"f_3352chicken.scm",(void*)f_3352},
{"f_3355chicken.scm",(void*)f_3355},
{"f_3358chicken.scm",(void*)f_3358},
{"f_3361chicken.scm",(void*)f_3361},
{"f_3364chicken.scm",(void*)f_3364},
{"f_3373chicken.scm",(void*)f_3373},
{"f_3519chicken.scm",(void*)f_3519},
{"f_3522chicken.scm",(void*)f_3522},
{"f_3531chicken.scm",(void*)f_3531},
{"f_3556chicken.scm",(void*)f_3556},
{"f_3581chicken.scm",(void*)f_3581},
{"f_3603chicken.scm",(void*)f_3603},
{"f_3596chicken.scm",(void*)f_3596},
{"f_3588chicken.scm",(void*)f_3588},
{"f_3575chicken.scm",(void*)f_3575},
{"f_3571chicken.scm",(void*)f_3571},
{"f_3550chicken.scm",(void*)f_3550},
{"f_3546chicken.scm",(void*)f_3546},
{"f_3513chicken.scm",(void*)f_3513},
{"f_3383chicken.scm",(void*)f_3383},
{"f_3390chicken.scm",(void*)f_3390},
{"f_3498chicken.scm",(void*)f_3498},
{"f_3486chicken.scm",(void*)f_3486},
{"f_3482chicken.scm",(void*)f_3482},
{"f_3418chicken.scm",(void*)f_3418},
{"f_3446chicken.scm",(void*)f_3446},
{"f_3458chicken.scm",(void*)f_3458},
{"f_3442chicken.scm",(void*)f_3442},
{"f_3343chicken.scm",(void*)f_3343},
{"f_1930chicken.scm",(void*)f_1930},
{"f_3241chicken.scm",(void*)f_3241},
{"f_3245chicken.scm",(void*)f_3245},
{"f_3251chicken.scm",(void*)f_3251},
{"f_3335chicken.scm",(void*)f_3335},
{"f_3296chicken.scm",(void*)f_3296},
{"f_3308chicken.scm",(void*)f_3308},
{"f_3239chicken.scm",(void*)f_3239},
{"f_1933chicken.scm",(void*)f_1933},
{"f_3133chicken.scm",(void*)f_3133},
{"f_3137chicken.scm",(void*)f_3137},
{"f_3211chicken.scm",(void*)f_3211},
{"f_3223chicken.scm",(void*)f_3223},
{"f_3152chicken.scm",(void*)f_3152},
{"f_3198chicken.scm",(void*)f_3198},
{"f_3155chicken.scm",(void*)f_3155},
{"f_3158chicken.scm",(void*)f_3158},
{"f_3168chicken.scm",(void*)f_3168},
{"f_3131chicken.scm",(void*)f_3131},
{"f_1936chicken.scm",(void*)f_1936},
{"f_3108chicken.scm",(void*)f_3108},
{"f_3112chicken.scm",(void*)f_3112},
{"f_3106chicken.scm",(void*)f_3106},
{"f_1939chicken.scm",(void*)f_1939},
{"f_3098chicken.scm",(void*)f_3098},
{"f_3096chicken.scm",(void*)f_3096},
{"f_1942chicken.scm",(void*)f_1942},
{"f_1945chicken.scm",(void*)f_1945},
{"f_1948chicken.scm",(void*)f_1948},
{"f_1952chicken.scm",(void*)f_1952},
{"f_2796chicken.scm",(void*)f_2796},
{"f_2803chicken.scm",(void*)f_2803},
{"f_2806chicken.scm",(void*)f_2806},
{"f_2809chicken.scm",(void*)f_2809},
{"f_2914chicken.scm",(void*)f_2914},
{"f_2927chicken.scm",(void*)f_2927},
{"f_3025chicken.scm",(void*)f_3025},
{"f_3023chicken.scm",(void*)f_3023},
{"f_2987chicken.scm",(void*)f_2987},
{"f_3011chicken.scm",(void*)f_3011},
{"f_2995chicken.scm",(void*)f_2995},
{"f_2999chicken.scm",(void*)f_2999},
{"f_2815chicken.scm",(void*)f_2815},
{"f_2825chicken.scm",(void*)f_2825},
{"f_2899chicken.scm",(void*)f_2899},
{"f_2879chicken.scm",(void*)f_2879},
{"f_2849chicken.scm",(void*)f_2849},
{"f_2845chicken.scm",(void*)f_2845},
{"f_2794chicken.scm",(void*)f_2794},
{"f_1955chicken.scm",(void*)f_1955},
{"f_2655chicken.scm",(void*)f_2655},
{"f_2659chicken.scm",(void*)f_2659},
{"f_2671chicken.scm",(void*)f_2671},
{"f_2771chicken.scm",(void*)f_2771},
{"f_2674chicken.scm",(void*)f_2674},
{"f_2681chicken.scm",(void*)f_2681},
{"f_2751chicken.scm",(void*)f_2751},
{"f_2767chicken.scm",(void*)f_2767},
{"f_2731chicken.scm",(void*)f_2731},
{"f_2705chicken.scm",(void*)f_2705},
{"f_2701chicken.scm",(void*)f_2701},
{"f_2653chicken.scm",(void*)f_2653},
{"f_1958chicken.scm",(void*)f_1958},
{"f_2505chicken.scm",(void*)f_2505},
{"f_2509chicken.scm",(void*)f_2509},
{"f_2518chicken.scm",(void*)f_2518},
{"f_2641chicken.scm",(void*)f_2641},
{"f_2649chicken.scm",(void*)f_2649},
{"f_2521chicken.scm",(void*)f_2521},
{"f_2617chicken.scm",(void*)f_2617},
{"f_2532chicken.scm",(void*)f_2532},
{"f_2615chicken.scm",(void*)f_2615},
{"f_2542chicken.scm",(void*)f_2542},
{"f_2540chicken.scm",(void*)f_2540},
{"f_2503chicken.scm",(void*)f_2503},
{"f_1961chicken.scm",(void*)f_1961},
{"f_2437chicken.scm",(void*)f_2437},
{"f_2441chicken.scm",(void*)f_2441},
{"f_2444chicken.scm",(void*)f_2444},
{"f_2451chicken.scm",(void*)f_2451},
{"f_2475chicken.scm",(void*)f_2475},
{"f_2495chicken.scm",(void*)f_2495},
{"f_2491chicken.scm",(void*)f_2491},
{"f_2435chicken.scm",(void*)f_2435},
{"f_1964chicken.scm",(void*)f_1964},
{"f_2381chicken.scm",(void*)f_2381},
{"f_2385chicken.scm",(void*)f_2385},
{"f_2388chicken.scm",(void*)f_2388},
{"f_2395chicken.scm",(void*)f_2395},
{"f_2411chicken.scm",(void*)f_2411},
{"f_2379chicken.scm",(void*)f_2379},
{"f_1967chicken.scm",(void*)f_1967},
{"f_2352chicken.scm",(void*)f_2352},
{"f_2356chicken.scm",(void*)f_2356},
{"f_2371chicken.scm",(void*)f_2371},
{"f_2350chicken.scm",(void*)f_2350},
{"f_1970chicken.scm",(void*)f_1970},
{"f_1973chicken.scm",(void*)f_1973},
{"f_2343chicken.scm",(void*)f_2343},
{"f_2339chicken.scm",(void*)f_2339},
{"f_2331chicken.scm",(void*)f_2331},
{"f_2321chicken.scm",(void*)f_2321},
{"f_2329chicken.scm",(void*)f_2329},
{"f_1977chicken.scm",(void*)f_1977},
{"f_2106chicken.scm",(void*)f_2106},
{"f_2118chicken.scm",(void*)f_2118},
{"f_2311chicken.scm",(void*)f_2311},
{"f_2304chicken.scm",(void*)f_2304},
{"f_2267chicken.scm",(void*)f_2267},
{"f_2213chicken.scm",(void*)f_2213},
{"f_2230chicken.scm",(void*)f_2230},
{"f_2216chicken.scm",(void*)f_2216},
{"f_2140chicken.scm",(void*)f_2140},
{"f_2193chicken.scm",(void*)f_2193},
{"f_2183chicken.scm",(void*)f_2183},
{"f_2143chicken.scm",(void*)f_2143},
{"f_2110chicken.scm",(void*)f_2110},
{"f_2113chicken.scm",(void*)f_2113},
{"f_2094chicken.scm",(void*)f_2094},
{"f_2101chicken.scm",(void*)f_2101},
{"f_2086chicken.scm",(void*)f_2086},
{"f_2092chicken.scm",(void*)f_2092},
{"f_2089chicken.scm",(void*)f_2089},
{"f_1979chicken.scm",(void*)f_1979},
{"f_1985chicken.scm",(void*)f_1985},
{"f_2020chicken.scm",(void*)f_2020},
{"f_2046chicken.scm",(void*)f_2046},
{"f_2042chicken.scm",(void*)f_2042},
{"f_1999chicken.scm",(void*)f_1999},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
