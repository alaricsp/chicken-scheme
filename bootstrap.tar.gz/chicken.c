/* Generated from chicken.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-07-09 11:03
   Version 3.3.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook hostpcre ]
   compiled 2008-07-02 on debian (Linux)
   command line: chicken.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -extend private-namespace.scm -output-file chicken.c
   used units: library eval data_structures ports extras srfi_69 srfi_1 match srfi_4 utils support compiler optimizer driver platform backend
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_match_toplevel)
C_externimport void C_ccall C_match_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_4_toplevel)
C_externimport void C_ccall C_srfi_4_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_support_toplevel)
C_externimport void C_ccall C_support_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_compiler_toplevel)
C_externimport void C_ccall C_compiler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_optimizer_toplevel)
C_externimport void C_ccall C_optimizer_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_driver_toplevel)
C_externimport void C_ccall C_driver_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_platform_toplevel)
C_externimport void C_ccall C_platform_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_backend_toplevel)
C_externimport void C_ccall C_backend_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[379];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_689)
static void C_ccall f_689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_692)
static void C_ccall f_692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_695)
static void C_ccall f_695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_698)
static void C_ccall f_698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_701)
static void C_ccall f_701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_704)
static void C_ccall f_704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_707)
static void C_ccall f_707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_710)
static void C_ccall f_710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_713)
static void C_ccall f_713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_716)
static void C_ccall f_716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_719)
static void C_ccall f_719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_722)
static void C_ccall f_722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_725)
static void C_ccall f_725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_728)
static void C_ccall f_728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_731)
static void C_ccall f_731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_734)
static void C_ccall f_734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_740)
static void C_ccall f_740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6918)
static void C_ccall f_6918(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6918)
static void C_ccall f_6918r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6922)
static void C_ccall f_6922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6925)
static void C_ccall f_6925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6928)
static void C_ccall f_6928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6934)
static void C_ccall f_6934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7140)
static void C_ccall f_7140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7120)
static void C_ccall f_7120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7116)
static void C_ccall f_7116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7096)
static void C_ccall f_7096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6959)
static void C_fcall f_6959(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6969)
static void C_ccall f_6969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7088)
static void C_ccall f_7088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6972)
static void C_ccall f_6972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7084)
static void C_ccall f_7084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6975)
static void C_ccall f_6975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7006)
static void C_fcall f_7006(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6986)
static void C_ccall f_6986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6957)
static void C_ccall f_6957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_743)
static void C_ccall f_743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6830)
static void C_ccall f_6830(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6830)
static void C_ccall f_6830r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6847)
static void C_ccall f_6847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6850)
static void C_ccall f_6850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6856)
static void C_fcall f_6856(C_word t0,C_word t1) C_noret;
C_noret_decl(f_746)
static void C_ccall f_746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6789)
static void C_ccall f_6789(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6789)
static void C_ccall f_6789r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6793)
static void C_ccall f_6793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_749)
static void C_ccall f_749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6773)
static void C_ccall f_6773(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6773)
static void C_ccall f_6773r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6783)
static void C_ccall f_6783(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6781)
static void C_ccall f_6781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_752)
static void C_ccall f_752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6696)
static void C_ccall f_6696(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6700)
static void C_ccall f_6700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6768)
static void C_ccall f_6768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6703)
static void C_ccall f_6703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6712)
static void C_ccall f_6712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6759)
static void C_ccall f_6759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6726)
static void C_ccall f_6726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6734)
static void C_ccall f_6734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6736)
static void C_fcall f_6736(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6753)
static void C_ccall f_6753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6718)
static void C_ccall f_6718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6710)
static void C_ccall f_6710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_755)
static void C_ccall f_755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6636)
static void C_ccall f_6636(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6636)
static void C_ccall f_6636r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6640)
static void C_fcall f_6640(C_word t0,C_word t1) C_noret;
C_noret_decl(f_758)
static void C_ccall f_758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6577)
static void C_ccall f_6577(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6577)
static void C_ccall f_6577r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6581)
static void C_ccall f_6581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6608)
static void C_fcall f_6608(C_word t0,C_word t1) C_noret;
C_noret_decl(f_761)
static void C_ccall f_761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6403)
static void C_ccall f_6403(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6403)
static void C_ccall f_6403r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6407)
static void C_ccall f_6407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6410)
static void C_ccall f_6410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6571)
static void C_ccall f_6571(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6413)
static void C_ccall f_6413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6565)
static void C_ccall f_6565(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6416)
static void C_ccall f_6416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6563)
static void C_ccall f_6563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6527)
static void C_ccall f_6527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6541)
static void C_fcall f_6541(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6555)
static void C_ccall f_6555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6535)
static void C_ccall f_6535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6531)
static void C_ccall f_6531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6423)
static void C_ccall f_6423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6519)
static void C_ccall f_6519(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6495)
static void C_ccall f_6495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6513)
static void C_ccall f_6513(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6503)
static void C_ccall f_6503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6499)
static void C_ccall f_6499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6491)
static void C_ccall f_6491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6475)
static void C_ccall f_6475(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6451)
static void C_ccall f_6451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6469)
static void C_ccall f_6469(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6459)
static void C_ccall f_6459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6455)
static void C_ccall f_6455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6447)
static void C_ccall f_6447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_764)
static void C_ccall f_764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6308)
static void C_ccall f_6308(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6308)
static void C_ccall f_6308r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6344)
static void C_fcall f_6344(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6357)
static void C_ccall f_6357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6315)
static void C_ccall f_6315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_767)
static void C_ccall f_767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6198)
static void C_ccall f_6198(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6198)
static void C_ccall f_6198r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6202)
static void C_ccall f_6202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6205)
static void C_ccall f_6205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6208)
static void C_ccall f_6208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6211)
static void C_ccall f_6211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6302)
static void C_ccall f_6302(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6214)
static void C_ccall f_6214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6296)
static void C_ccall f_6296(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6217)
static void C_ccall f_6217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6290)
static void C_ccall f_6290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6294)
static void C_ccall f_6294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6224)
static void C_ccall f_6224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6262)
static void C_ccall f_6262(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6260)
static void C_ccall f_6260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_770)
static void C_ccall f_770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6188)
static void C_ccall f_6188(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6188)
static void C_ccall f_6188r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_773)
static void C_ccall f_773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6174)
static void C_ccall f_6174(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6174)
static void C_ccall f_6174r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_776)
static void C_ccall f_776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_850)
static void C_ccall f_850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_853)
static void C_ccall f_853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5912)
static void C_ccall f_5912(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5916)
static void C_ccall f_5916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5925)
static void C_ccall f_5925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6134)
static void C_fcall f_6134(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6147)
static void C_ccall f_6147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5928)
static void C_ccall f_5928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6124)
static void C_ccall f_6124(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6132)
static void C_ccall f_6132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5931)
static void C_ccall f_5931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6078)
static void C_fcall f_6078(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6111)
static void C_ccall f_6111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6118)
static void C_ccall f_6118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6094)
static void C_fcall f_6094(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5943)
static void C_ccall f_5943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6072)
static void C_ccall f_6072(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5950)
static void C_ccall f_5950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5952)
static void C_fcall f_5952(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6066)
static void C_ccall f_6066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5986)
static void C_fcall f_5986(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6040)
static void C_ccall f_6040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6017)
static void C_ccall f_6017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5997)
static void C_ccall f_5997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5972)
static void C_ccall f_5972(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5980)
static void C_ccall f_5980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5970)
static void C_ccall f_5970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5932)
static void C_ccall f_5932(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5872)
static void C_fcall f_5872(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5895)
static void C_ccall f_5895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5899)
static void C_ccall f_5899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5841)
static void C_fcall f_5841(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5862)
static void C_ccall f_5862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_856)
static void C_ccall f_856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5790)
static void C_ccall f_5790(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5794)
static void C_ccall f_5794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5805)
static void C_fcall f_5805(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5830)
static void C_ccall f_5830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_859)
static void C_ccall f_859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5670)
static void C_ccall f_5670(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5674)
static void C_ccall f_5674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5784)
static void C_ccall f_5784(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5782)
static void C_ccall f_5782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5683)
static void C_ccall f_5683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5770)
static void C_ccall f_5770(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5778)
static void C_ccall f_5778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5686)
static void C_ccall f_5686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5764)
static void C_ccall f_5764(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5706)
static void C_ccall f_5706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5716)
static void C_ccall f_5716(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5736)
static void C_ccall f_5736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5742)
static void C_ccall f_5742(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5750)
static void C_ccall f_5750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5740)
static void C_ccall f_5740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5714)
static void C_ccall f_5714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5710)
static void C_ccall f_5710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5687)
static void C_ccall f_5687(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_862)
static void C_ccall f_862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5649)
static void C_ccall f_5649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5653)
static void C_ccall f_5653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_865)
static void C_ccall f_865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5639)
static void C_ccall f_5639(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_871)
static void C_ccall f_871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_880)
static void C_fcall f_880(C_word t0,C_word t1) C_noret;
C_noret_decl(f_896)
static void C_fcall f_896(C_word t0,C_word t1) C_noret;
C_noret_decl(f_883)
static void C_ccall f_883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_944)
static void C_ccall f_944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5618)
static void C_ccall f_5618(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5622)
static void C_ccall f_5622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_947)
static void C_ccall f_947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5502)
static void C_ccall f_5502(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5506)
static void C_ccall f_5506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5515)
static void C_fcall f_5515(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5529)
static void C_fcall f_5529(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5593)
static void C_ccall f_5593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5575)
static void C_ccall f_5575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5558)
static void C_ccall f_5558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_950)
static void C_ccall f_950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5403)
static void C_ccall f_5403(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5413)
static void C_ccall f_5413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5426)
static void C_fcall f_5426(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5442)
static void C_ccall f_5442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5480)
static void C_ccall f_5480(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5478)
static void C_ccall f_5478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5470)
static void C_ccall f_5470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5424)
static void C_ccall f_5424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_953)
static void C_ccall f_953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5314)
static void C_ccall f_5314(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5324)
static void C_ccall f_5324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5337)
static void C_fcall f_5337(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5353)
static void C_ccall f_5353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5381)
static void C_ccall f_5381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5335)
static void C_ccall f_5335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_956)
static void C_ccall f_956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5028)
static void C_ccall f_5028(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5028)
static void C_ccall f_5028r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5225)
static void C_ccall f_5225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5228)
static void C_ccall f_5228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5231)
static void C_ccall f_5231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5304)
static void C_ccall f_5304(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5312)
static void C_ccall f_5312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5247)
static void C_ccall f_5247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5250)
static void C_ccall f_5250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5253)
static void C_ccall f_5253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5256)
static void C_ccall f_5256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5294)
static void C_ccall f_5294(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5302)
static void C_ccall f_5302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5259)
static void C_ccall f_5259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5039)
static void C_ccall f_5039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5043)
static void C_ccall f_5043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5047)
static void C_ccall f_5047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5049)
static void C_fcall f_5049(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5094)
static void C_ccall f_5094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5106)
static void C_ccall f_5106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5102)
static void C_ccall f_5102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5070)
static void C_ccall f_5070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5262)
static void C_ccall f_5262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5122)
static void C_fcall f_5122(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5222)
static void C_ccall f_5222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5186)
static void C_ccall f_5186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5156)
static void C_ccall f_5156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5265)
static void C_ccall f_5265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5232)
static void C_fcall f_5232(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5244)
static void C_ccall f_5244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5240)
static void C_ccall f_5240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_959)
static void C_ccall f_959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4971)
static void C_ccall f_4971(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4975)
static void C_ccall f_4975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_962)
static void C_ccall f_962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4965)
static void C_ccall f_4965(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_965)
static void C_ccall f_965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4812)
static void C_ccall f_4812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4812)
static void C_ccall f_4812r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4816)
static void C_ccall f_4816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4819)
static void C_ccall f_4819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4822)
static void C_ccall f_4822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4835)
static void C_fcall f_4835(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4885)
static void C_ccall f_4885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4896)
static void C_ccall f_4896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4833)
static void C_ccall f_4833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_968)
static void C_ccall f_968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4536)
static void C_ccall f_4536(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4570)
static void C_ccall f_4570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4573)
static void C_ccall f_4573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4799)
static void C_ccall f_4799(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4809)
static void C_ccall f_4809(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4797)
static void C_ccall f_4797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4576)
static void C_ccall f_4576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4545)
static void C_fcall f_4545(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4559)
static void C_ccall f_4559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4563)
static void C_ccall f_4563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4579)
static void C_ccall f_4579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4582)
static void C_ccall f_4582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4585)
static void C_ccall f_4585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4592)
static void C_ccall f_4592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4606)
static void C_ccall f_4606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4616)
static void C_ccall f_4616(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4620)
static void C_ccall f_4620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4630)
static void C_fcall f_4630(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4646)
static void C_ccall f_4646(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4665)
static void C_fcall f_4665(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4721)
static void C_ccall f_4721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4732)
static void C_ccall f_4732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4650)
static void C_ccall f_4650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4663)
static void C_ccall f_4663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4636)
static void C_ccall f_4636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4644)
static void C_ccall f_4644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4634)
static void C_ccall f_4634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4604)
static void C_ccall f_4604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_971)
static void C_ccall f_971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4479)
static void C_ccall f_4479(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4479)
static void C_ccall f_4479r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4519)
static void C_ccall f_4519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4489)
static void C_ccall f_4489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_974)
static void C_ccall f_974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4403)
static void C_ccall f_4403(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4403)
static void C_ccall f_4403r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4407)
static void C_ccall f_4407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4410)
static void C_ccall f_4410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_977)
static void C_ccall f_977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4219)
static void C_ccall f_4219(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4219)
static void C_ccall f_4219r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4226)
static void C_ccall f_4226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4369)
static void C_ccall f_4369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4365)
static void C_ccall f_4365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4228)
static void C_ccall f_4228(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4316)
static void C_ccall f_4316(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4314)
static void C_ccall f_4314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4284)
static void C_fcall f_4284(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4251)
static void C_fcall f_4251(C_word t0,C_word t1) C_noret;
C_noret_decl(f_980)
static void C_ccall f_980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4029)
static void C_ccall f_4029(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_4029)
static void C_ccall f_4029r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_4036)
static void C_ccall f_4036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4210)
static void C_ccall f_4210(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4208)
static void C_ccall f_4208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4061)
static void C_fcall f_4061(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4087)
static void C_fcall f_4087(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4115)
static void C_fcall f_4115(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4099)
static void C_ccall f_4099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4059)
static void C_ccall f_4059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_983)
static void C_ccall f_983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4020)
static void C_ccall f_4020(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4024)
static void C_ccall f_4024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_986)
static void C_ccall f_986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4001)
static void C_ccall f_4001(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4005)
static void C_ccall f_4005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4014)
static void C_ccall f_4014(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4012)
static void C_ccall f_4012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_989)
static void C_ccall f_989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3982)
static void C_ccall f_3982(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3986)
static void C_ccall f_3986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3995)
static void C_ccall f_3995(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3993)
static void C_ccall f_3993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_992)
static void C_ccall f_992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3854)
static void C_ccall f_3854(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3860)
static void C_fcall f_3860(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3941)
static void C_ccall f_3941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3870)
static void C_ccall f_3870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3873)
static void C_ccall f_3873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3879)
static void C_ccall f_3879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3886)
static void C_ccall f_3886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3902)
static void C_ccall f_3902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_995)
static void C_ccall f_995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3711)
static void C_ccall f_3711(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3717)
static void C_fcall f_3717(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3829)
static void C_ccall f_3829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3802)
static void C_ccall f_3802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3727)
static void C_ccall f_3727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3730)
static void C_ccall f_3730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3736)
static void C_ccall f_3736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3747)
static void C_ccall f_3747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3763)
static void C_ccall f_3763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_998)
static void C_ccall f_998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3652)
static void C_ccall f_3652(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_3652)
static void C_ccall f_3652r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_1001)
static void C_ccall f_1001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3481)
static void C_ccall f_3481(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3481)
static void C_ccall f_3481r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3487)
static void C_fcall f_3487(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3561)
static void C_fcall f_3561(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3564)
static void C_ccall f_3564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3637)
static void C_ccall f_3637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3630)
static void C_ccall f_3630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3622)
static void C_ccall f_3622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3609)
static void C_ccall f_3609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3588)
static void C_ccall f_3588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3497)
static void C_fcall f_3497(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1004)
static void C_ccall f_1004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3430)
static void C_ccall f_3430(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3430)
static void C_ccall f_3430r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1007)
static void C_ccall f_1007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3370)
static void C_ccall f_3370(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3370)
static void C_ccall f_3370r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3380)
static void C_fcall f_3380(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3399)
static void C_ccall f_3399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3383)
static void C_ccall f_3383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1010)
static void C_ccall f_1010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1013)
static void C_ccall f_1013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3333)
static void C_ccall f_3333(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3337)
static void C_ccall f_3337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1016)
static void C_ccall f_1016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3314)
static void C_ccall f_3314(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3318)
static void C_ccall f_3318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3327)
static void C_ccall f_3327(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3325)
static void C_ccall f_3325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1019)
static void C_ccall f_1019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3299)
static void C_ccall f_3299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3308)
static void C_ccall f_3308(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3306)
static void C_ccall f_3306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1022)
static void C_ccall f_1022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3276)
static void C_ccall f_3276(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3280)
static void C_ccall f_3280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3289)
static void C_ccall f_3289(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3287)
static void C_ccall f_3287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1025)
static void C_ccall f_1025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3257)
static void C_ccall f_3257(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3261)
static void C_ccall f_3261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3270)
static void C_ccall f_3270(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3268)
static void C_ccall f_3268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1028)
static void C_ccall f_1028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3238)
static void C_ccall f_3238(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3242)
static void C_ccall f_3242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3251)
static void C_ccall f_3251(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3249)
static void C_ccall f_3249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1031)
static void C_ccall f_1031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3219)
static void C_ccall f_3219(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3223)
static void C_ccall f_3223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3232)
static void C_ccall f_3232(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3230)
static void C_ccall f_3230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1034)
static void C_ccall f_1034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3123)
static void C_ccall f_3123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3178)
static void C_ccall f_3178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3132)
static void C_ccall f_3132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1037)
static void C_ccall f_1037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2899)
static void C_ccall f_2899(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2903)
static void C_fcall f_2903(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2906)
static void C_fcall f_2906(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3054)
static void C_ccall f_3054(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3044)
static void C_ccall f_3044(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3032)
static void C_ccall f_3032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2912)
static void C_ccall f_2912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2938)
static void C_fcall f_2938(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1040)
static void C_ccall f_1040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2824)
static void C_ccall f_2824(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2824)
static void C_ccall f_2824r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2897)
static void C_ccall f_2897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2851)
static void C_fcall f_2851(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1043)
static void C_ccall f_1043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2718)
static void C_ccall f_2718(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2718)
static void C_ccall f_2718r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2818)
static void C_ccall f_2818(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2722)
static void C_ccall f_2722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2794)
static void C_ccall f_2794(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2729)
static void C_ccall f_2729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2735)
static void C_ccall f_2735(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2733)
static void C_ccall f_2733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1046)
static void C_ccall f_1046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2689)
static void C_ccall f_2689(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2693)
static void C_ccall f_2693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2716)
static void C_ccall f_2716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2712)
static void C_ccall f_2712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1049)
static void C_ccall f_1049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2676)
static void C_ccall f_2676(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2680)
static void C_ccall f_2680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1052)
static void C_ccall f_1052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1882)
static void C_ccall f_1882(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1882)
static void C_ccall f_1882r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1886)
static void C_ccall f_1886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1892)
static void C_ccall f_1892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1895)
static void C_ccall f_1895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1898)
static void C_ccall f_1898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1901)
static void C_ccall f_1901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2568)
static void C_fcall f_2568(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2647)
static void C_ccall f_2647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2643)
static void C_ccall f_2643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2578)
static void C_fcall f_2578(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2582)
static void C_ccall f_2582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2623)
static void C_ccall f_2623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2613)
static void C_ccall f_2613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2603)
static void C_ccall f_2603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2599)
static void C_ccall f_2599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2585)
static void C_ccall f_2585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1989)
static void C_ccall f_1989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1992)
static void C_ccall f_1992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2562)
static void C_ccall f_2562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2491)
static void C_ccall f_2491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2497)
static void C_ccall f_2497(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2551)
static void C_ccall f_2551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2543)
static void C_ccall f_2543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2526)
static void C_ccall f_2526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2495)
static void C_ccall f_2495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2479)
static void C_ccall f_2479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2475)
static void C_ccall f_2475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2003)
static void C_fcall f_2003(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2457)
static void C_ccall f_2457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2011)
static void C_fcall f_2011(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2019)
static void C_fcall f_2019(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2025)
static void C_ccall f_2025(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2302)
static void C_ccall f_2302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2414)
static void C_ccall f_2414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2410)
static void C_ccall f_2410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2379)
static void C_ccall f_2379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2402)
static void C_ccall f_2402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2391)
static void C_ccall f_2391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2320)
static void C_fcall f_2320(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2365)
static void C_ccall f_2365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2361)
static void C_ccall f_2361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2337)
static void C_ccall f_2337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2349)
static void C_ccall f_2349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2317)
static void C_fcall f_2317(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2047)
static void C_ccall f_2047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2287)
static void C_ccall f_2287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2283)
static void C_ccall f_2283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2188)
static void C_ccall f_2188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2271)
static void C_ccall f_2271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2260)
static void C_ccall f_2260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2065)
static void C_fcall f_2065(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2174)
static void C_ccall f_2174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2170)
static void C_ccall f_2170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2082)
static void C_ccall f_2082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2154)
static void C_ccall f_2154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2062)
static void C_fcall f_2062(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2023)
static void C_ccall f_2023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2015)
static void C_ccall f_2015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2007)
static void C_ccall f_2007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1999)
static void C_ccall f_1999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1946)
static void C_fcall f_1946(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1962)
static void C_ccall f_1962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1903)
static void C_fcall f_1903(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1055)
static void C_ccall f_1055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1868)
static void C_ccall f_1868(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1058)
static void C_ccall f_1058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1528)
static void C_ccall f_1528(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1528)
static void C_ccall f_1528r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1532)
static void C_fcall f_1532(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1535)
static void C_ccall f_1535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1840)
static void C_ccall f_1840(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1538)
static void C_ccall f_1538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1815)
static void C_ccall f_1815(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1541)
static void C_ccall f_1541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1783)
static void C_ccall f_1783(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1544)
static void C_ccall f_1544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1757)
static void C_ccall f_1757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1547)
static void C_fcall f_1547(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1550)
static void C_ccall f_1550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1745)
static void C_ccall f_1745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1553)
static void C_ccall f_1553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1741)
static void C_ccall f_1741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1556)
static void C_ccall f_1556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1729)
static void C_ccall f_1729(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1737)
static void C_ccall f_1737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1567)
static void C_ccall f_1567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1691)
static void C_ccall f_1691(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1673)
static void C_ccall f_1673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1669)
static void C_ccall f_1669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1609)
static void C_ccall f_1609(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1599)
static void C_ccall f_1599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1595)
static void C_ccall f_1595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1563)
static void C_ccall f_1563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1061)
static void C_ccall f_1061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1494)
static void C_ccall f_1494(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1064)
static void C_ccall f_1064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1432)
static void C_ccall f_1432(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1432)
static void C_ccall f_1432r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1445)
static void C_fcall f_1445(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1471)
static void C_ccall f_1471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1442)
static void C_ccall f_1442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1435)
static void C_fcall f_1435(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1067)
static void C_ccall f_1067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1430)
static void C_ccall f_1430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1423)
static void C_ccall f_1423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1419)
static void C_ccall f_1419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1411)
static void C_ccall f_1411(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1409)
static void C_ccall f_1409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1071)
static void C_ccall f_1071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1200)
static void C_ccall f_1200(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1212)
static void C_fcall f_1212(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1395)
static void C_ccall f_1395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1388)
static void C_ccall f_1388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1351)
static void C_ccall f_1351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1297)
static void C_ccall f_1297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1314)
static void C_ccall f_1314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1300)
static void C_ccall f_1300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1234)
static void C_ccall f_1234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1277)
static void C_ccall f_1277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1257)
static void C_ccall f_1257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1237)
static void C_ccall f_1237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1204)
static void C_ccall f_1204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1207)
static void C_ccall f_1207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1188)
static void C_ccall f_1188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1195)
static void C_ccall f_1195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1180)
static void C_ccall f_1180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1186)
static void C_ccall f_1186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1183)
static void C_ccall f_1183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1073)
static void C_ccall f_1073(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1079)
static void C_fcall f_1079(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1114)
static void C_fcall f_1114(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1140)
static void C_ccall f_1140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1136)
static void C_ccall f_1136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1093)
static void C_ccall f_1093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_777)
static void C_ccall f_777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_781)
static void C_ccall f_781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_818)
static void C_ccall f_818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_839)
static void C_ccall f_839(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_837)
static void C_ccall f_837(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_6959)
static void C_fcall trf_6959(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6959(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6959(t0,t1,t2,t3);}

C_noret_decl(trf_7006)
static void C_fcall trf_7006(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7006(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7006(t0,t1);}

C_noret_decl(trf_6856)
static void C_fcall trf_6856(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6856(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6856(t0,t1);}

C_noret_decl(trf_6736)
static void C_fcall trf_6736(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6736(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6736(t0,t1,t2,t3);}

C_noret_decl(trf_6640)
static void C_fcall trf_6640(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6640(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6640(t0,t1);}

C_noret_decl(trf_6608)
static void C_fcall trf_6608(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6608(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6608(t0,t1);}

C_noret_decl(trf_6541)
static void C_fcall trf_6541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6541(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6541(t0,t1,t2);}

C_noret_decl(trf_6344)
static void C_fcall trf_6344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6344(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6344(t0,t1,t2);}

C_noret_decl(trf_6134)
static void C_fcall trf_6134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6134(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6134(t0,t1,t2,t3);}

C_noret_decl(trf_6078)
static void C_fcall trf_6078(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6078(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6078(t0,t1,t2,t3);}

C_noret_decl(trf_6094)
static void C_fcall trf_6094(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6094(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6094(t0,t1);}

C_noret_decl(trf_5952)
static void C_fcall trf_5952(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5952(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5952(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5986)
static void C_fcall trf_5986(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5986(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5986(t0,t1);}

C_noret_decl(trf_5872)
static void C_fcall trf_5872(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5872(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5872(t0,t1,t2,t3);}

C_noret_decl(trf_5841)
static void C_fcall trf_5841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5841(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5841(t0,t1,t2,t3);}

C_noret_decl(trf_5805)
static void C_fcall trf_5805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5805(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5805(t0,t1,t2);}

C_noret_decl(trf_880)
static void C_fcall trf_880(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_880(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_880(t0,t1);}

C_noret_decl(trf_896)
static void C_fcall trf_896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_896(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_896(t0,t1);}

C_noret_decl(trf_5515)
static void C_fcall trf_5515(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5515(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5515(t0,t1);}

C_noret_decl(trf_5529)
static void C_fcall trf_5529(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5529(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5529(t0,t1,t2);}

C_noret_decl(trf_5426)
static void C_fcall trf_5426(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5426(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5426(t0,t1,t2);}

C_noret_decl(trf_5337)
static void C_fcall trf_5337(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5337(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5337(t0,t1,t2);}

C_noret_decl(trf_5049)
static void C_fcall trf_5049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5049(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5049(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5122)
static void C_fcall trf_5122(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5122(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5122(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5232)
static void C_fcall trf_5232(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5232(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5232(t0,t1,t2);}

C_noret_decl(trf_4835)
static void C_fcall trf_4835(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4835(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4835(t0,t1,t2,t3);}

C_noret_decl(trf_4545)
static void C_fcall trf_4545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4545(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4545(t0,t1,t2);}

C_noret_decl(trf_4630)
static void C_fcall trf_4630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4630(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4630(t0,t1);}

C_noret_decl(trf_4665)
static void C_fcall trf_4665(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4665(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4665(t0,t1,t2,t3);}

C_noret_decl(trf_4284)
static void C_fcall trf_4284(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4284(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4284(t0,t1);}

C_noret_decl(trf_4251)
static void C_fcall trf_4251(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4251(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4251(t0,t1);}

C_noret_decl(trf_4061)
static void C_fcall trf_4061(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4061(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4061(t0,t1,t2,t3);}

C_noret_decl(trf_4087)
static void C_fcall trf_4087(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4087(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4087(t0,t1);}

C_noret_decl(trf_4115)
static void C_fcall trf_4115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4115(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4115(t0,t1);}

C_noret_decl(trf_3860)
static void C_fcall trf_3860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3860(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3860(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3717)
static void C_fcall trf_3717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3717(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3717(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3487)
static void C_fcall trf_3487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3487(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3487(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3561)
static void C_fcall trf_3561(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3561(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3561(t0,t1);}

C_noret_decl(trf_3497)
static void C_fcall trf_3497(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3497(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3497(t0,t1);}

C_noret_decl(trf_3380)
static void C_fcall trf_3380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3380(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3380(t0,t1);}

C_noret_decl(trf_2903)
static void C_fcall trf_2903(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2903(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2903(t0,t1);}

C_noret_decl(trf_2906)
static void C_fcall trf_2906(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2906(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2906(t0,t1);}

C_noret_decl(trf_2938)
static void C_fcall trf_2938(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2938(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2938(t0,t1);}

C_noret_decl(trf_2851)
static void C_fcall trf_2851(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2851(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2851(t0,t1);}

C_noret_decl(trf_2568)
static void C_fcall trf_2568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2568(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2568(t0,t1,t2);}

C_noret_decl(trf_2578)
static void C_fcall trf_2578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2578(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2578(t0,t1);}

C_noret_decl(trf_2003)
static void C_fcall trf_2003(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2003(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2003(t0,t1);}

C_noret_decl(trf_2011)
static void C_fcall trf_2011(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2011(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2011(t0,t1);}

C_noret_decl(trf_2019)
static void C_fcall trf_2019(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2019(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2019(t0,t1);}

C_noret_decl(trf_2320)
static void C_fcall trf_2320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2320(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2320(t0,t1);}

C_noret_decl(trf_2317)
static void C_fcall trf_2317(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2317(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2317(t0,t1);}

C_noret_decl(trf_2065)
static void C_fcall trf_2065(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2065(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2065(t0,t1);}

C_noret_decl(trf_2062)
static void C_fcall trf_2062(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2062(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2062(t0,t1);}

C_noret_decl(trf_1946)
static void C_fcall trf_1946(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1946(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1946(t0,t1,t2);}

C_noret_decl(trf_1903)
static void C_fcall trf_1903(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1903(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1903(t0,t1,t2);}

C_noret_decl(trf_1532)
static void C_fcall trf_1532(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1532(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1532(t0,t1);}

C_noret_decl(trf_1547)
static void C_fcall trf_1547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1547(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1547(t0,t1);}

C_noret_decl(trf_1445)
static void C_fcall trf_1445(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1445(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1445(t0,t1);}

C_noret_decl(trf_1435)
static void C_fcall trf_1435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1435(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1435(t0,t1);}

C_noret_decl(trf_1212)
static void C_fcall trf_1212(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1212(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1212(t0,t1,t2);}

C_noret_decl(trf_1079)
static void C_fcall trf_1079(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1079(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1079(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1114)
static void C_fcall trf_1114(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1114(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1114(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(4053)){
C_save(t1);
C_rereclaim2(4053*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,379);
lf[0]=C_h_intern(&lf[0],19,"\003sysundefined-value");
lf[1]=C_h_intern(&lf[1],3,"map");
lf[2]=C_h_intern(&lf[2],6,"lambda");
lf[3]=C_h_intern(&lf[3],14,"\004coreundefined");
lf[4]=C_h_intern(&lf[4],20,"\003syscall-with-values");
lf[5]=C_h_intern(&lf[5],9,"\004coreset!");
lf[6]=C_h_intern(&lf[6],6,"gensym");
lf[7]=C_h_intern(&lf[7],16,"\003syscheck-syntax");
lf[8]=C_h_intern(&lf[8],25,"set!-values/define-values");
lf[9]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[10]=C_h_intern(&lf[10],27,"\010compilercompiler-arguments");
lf[11]=C_h_intern(&lf[11],29,"\010compilerprocess-command-line");
lf[12]=C_h_intern(&lf[12],7,"reverse");
lf[13]=C_h_intern(&lf[13],14,"string->symbol");
lf[14]=C_h_intern(&lf[14],9,"substring");
lf[15]=C_h_intern(&lf[15],25,"\003sysimplicit-exit-handler");
lf[16]=C_h_intern(&lf[16],17,"user-options-pass");
lf[17]=C_h_intern(&lf[17],4,"exit");
lf[18]=C_h_intern(&lf[18],19,"compile-source-file");
lf[19]=C_h_intern(&lf[19],14,"optimize-level");
lf[20]=C_h_intern(&lf[20],5,"cons*");
lf[21]=C_h_intern(&lf[21],22,"optimize-leaf-routines");
lf[22]=C_h_intern(&lf[22],6,"unsafe");
lf[23]=C_h_intern(&lf[23],25,"\010compilercompiler-warning");
lf[24]=C_h_intern(&lf[24],5,"usage");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\047invalid optimization level ~S - ignored");
lf[26]=C_h_intern(&lf[26],11,"debug-level");
lf[27]=C_h_intern(&lf[27],14,"no-lambda-info");
lf[28]=C_h_intern(&lf[28],8,"no-trace");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000 invalid debug level ~S - ignored");
lf[30]=C_h_intern(&lf[30],14,"benchmark-mode");
lf[31]=C_h_intern(&lf[31],17,"fixnum-arithmetic");
lf[32]=C_h_intern(&lf[32],18,"disable-interrupts");
lf[33]=C_h_intern(&lf[33],5,"block");
lf[34]=C_h_intern(&lf[34],11,"lambda-lift");
lf[35]=C_h_intern(&lf[35],31,"\010compilervalid-compiler-options");
lf[36]=C_h_intern(&lf[36],45,"\010compilervalid-compiler-options-with-argument");
lf[37]=C_h_intern(&lf[37],4,"quit");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~s\047 option");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000&invalid compiler option `~a\047 - ignored");
lf[40]=C_h_intern(&lf[40],4,"conc");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[42]=C_h_intern(&lf[42],6,"append");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[44]=C_h_intern(&lf[44],6,"remove");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[46]=C_h_intern(&lf[46],12,"string-split");
lf[47]=C_h_intern(&lf[47],6,"getenv");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\017CHICKEN_OPTIONS");
lf[49]=C_h_intern(&lf[49],4,"argv");
lf[50]=C_h_intern(&lf[50],12,"syntax-error");
lf[51]=C_h_intern(&lf[51],21,"define-compiler-macro");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000!invalid compiler macro definition");
lf[53]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004void\376\377\016");
lf[54]=C_h_intern(&lf[54],9,"compiling");
lf[55]=C_h_intern(&lf[55],12,"\003sysfeatures");
lf[56]=C_h_intern(&lf[56],7,"warning");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\0004compile macros are not available in interpreted code");
lf[58]=C_h_intern(&lf[58],32,"\010compilerregister-compiler-macro");
lf[59]=C_h_intern(&lf[59],18,"\003sysregister-macro");
lf[60]=C_h_intern(&lf[60],4,"args");
lf[61]=C_h_intern(&lf[61],5,"quote");
lf[62]=C_h_intern(&lf[62],7,"sprintf");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000$`~s\047 is deprecated, use `~s\047 instead");
lf[64]=C_h_intern(&lf[64],4,"cons");
lf[65]=C_h_intern(&lf[65],12,"define-macro");
lf[66]=C_h_intern(&lf[66],23,"define-deprecated-macro");
lf[67]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016");
lf[68]=C_h_intern(&lf[68],5,"begin");
lf[69]=C_h_intern(&lf[69],4,"syms");
lf[70]=C_h_intern(&lf[70],7,"symbol\077");
lf[71]=C_h_intern(&lf[71],4,"list");
lf[72]=C_h_intern(&lf[72],2,"if");
lf[73]=C_h_intern(&lf[73],3,"sum");
lf[74]=C_h_intern(&lf[74],5,"null\077");
lf[75]=C_h_intern(&lf[75],3,"cdr");
lf[76]=C_h_intern(&lf[76],3,"car");
lf[77]=C_h_intern(&lf[77],3,"val");
lf[78]=C_h_intern(&lf[78],4,"case");
lf[79]=C_h_intern(&lf[79],3,"let");
lf[80]=C_h_intern(&lf[80],11,"bitwise-ior");
lf[81]=C_h_intern(&lf[81],4,"loop");
lf[82]=C_h_intern(&lf[82],6,"define");
lf[83]=C_h_intern(&lf[83],4,"cond");
lf[84]=C_h_intern(&lf[84],19,"define-foreign-type");
lf[85]=C_h_intern(&lf[85],10,"\003sysappend");
lf[86]=C_h_intern(&lf[86],4,"else");
lf[87]=C_h_intern(&lf[87],1,"=");
lf[88]=C_h_intern(&lf[88],5,"error");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\024not a member of enum");
lf[90]=C_h_intern(&lf[90],23,"define-foreign-variable");
lf[91]=C_h_intern(&lf[91],8,"->string");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\010number->");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\010->number");
lf[94]=C_h_intern(&lf[94],7,"\003sysmap");
lf[95]=C_h_intern(&lf[95],19,"define-foreign-enum");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid type specification");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid enum specification");
lf[98]=C_h_intern(&lf[98],15,"foreign-declare");
lf[99]=C_h_intern(&lf[99],12,"\004coredeclare");
lf[100]=C_h_intern(&lf[100],20,"\003sysregister-macro-2");
lf[101]=C_h_intern(&lf[101],8,"identity");
lf[102]=C_h_intern(&lf[102],5,"const");
lf[103]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\005union\376\377\016");
lf[104]=C_h_intern(&lf[104],9,"c-pointer");
lf[105]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\005union\376\377\016");
lf[106]=C_h_intern(&lf[106],3,"int");
lf[107]=C_h_intern(&lf[107],15,"foreign-lambda*");
lf[108]=C_h_intern(&lf[108],4,"fx>=");
lf[109]=C_h_intern(&lf[109],3,"fx<");
lf[110]=C_h_intern(&lf[110],3,"and");
lf[111]=C_h_intern(&lf[111],10,"\004corecheck");
lf[112]=C_h_intern(&lf[112],21,"define-foreign-record");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\031array access out of range");
lf[114]=C_h_intern(&lf[114],4,"void");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\031array access out of range");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\020~A->~A[~A] = ~A;");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\012~A-~A-set!");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\025return(~A~A->~A[~A]);");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\005~A-~A");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\014~A->~A = ~A;");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\012~A-~A-set!");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\021return(~A~A->~A);");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\005~A-~A");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\015bad slot spec");
lf[129]=C_h_intern(&lf[129],3,"ptr");
lf[130]=C_h_intern(&lf[130],11,"\004coreinline");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\007C_qfree");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000#return((~a *)C_malloc(sizeof(~a)));");
lf[133]=C_h_intern(&lf[133],7,"declare");
lf[134]=C_h_intern(&lf[134],18,"string-intersperse");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\002};");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\007~A[~A];");
lf[138]=C_h_intern(&lf[138],33,"\010compilerforeign-type-declaration");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\003~A;");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\015bad slot spec");
lf[141]=C_h_intern(&lf[141],13,"string-append");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\007struct ");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\003 { ");
lf[144]=C_h_intern(&lf[144],19,"\003syshash-table-set!");
lf[145]=C_h_intern(&lf[145],27,"\010compilerforeign-type-table");
lf[146]=C_h_intern(&lf[146],7,"\000rename");
lf[147]=C_h_intern(&lf[147],4,"eval");
lf[148]=C_h_intern(&lf[148],5,"cadar");
lf[149]=C_h_intern(&lf[149],12,"\000constructor");
lf[150]=C_h_intern(&lf[150],11,"\000destructor");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000)invalid foreign record-type specification");
lf[152]=C_h_intern(&lf[152],4,"caar");
lf[153]=C_h_intern(&lf[153],8,"keyword\077");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\011struct ~A");
lf[155]=C_h_intern(&lf[155],5,"code_");
lf[156]=C_h_intern(&lf[156],13,"foreign-value");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\0007static C_word ~A() { ~A\012; return C_SCHEME_UNDEFINED; }\012");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[159]=C_h_intern(&lf[159],12,"foreign-code");
lf[160]=C_h_intern(&lf[160],17,"\004corelet-location");
lf[161]=C_h_intern(&lf[161],10,"fold-right");
lf[162]=C_h_intern(&lf[162],10,"append-map");
lf[163]=C_h_intern(&lf[163],12,"let-location");
lf[164]=C_h_intern(&lf[164],28,"\004coredefine-foreign-variable");
lf[165]=C_h_intern(&lf[165],29,"\004coredefine-external-variable");
lf[166]=C_h_intern(&lf[166],14,"symbol->string");
lf[167]=C_h_intern(&lf[167],15,"define-location");
lf[168]=C_h_intern(&lf[168],15,"define-external");
lf[169]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[171]=C_h_intern(&lf[171],29,"\004coreforeign-callback-wrapper");
lf[172]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376"
"\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[173]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376"
"\001\000\000\001_\376\377\001\000\000\000\001");
lf[174]=C_h_intern(&lf[174],20,"foreign-safe-wrapper");
lf[175]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006lambda\376\003\000\000\002"
"\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001\376\377\016");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[177]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006lambda\376\003\000\000\002\376\001\000\000\013lambda-list"
"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001\376\377\016");
lf[178]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[179]=C_h_intern(&lf[179],22,"\004coreforeign-primitive");
lf[180]=C_h_intern(&lf[180],17,"foreign-primitive");
lf[181]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[182]=C_h_intern(&lf[182],29,"\004coreforeign-callback-lambda*");
lf[183]=C_h_intern(&lf[183],20,"foreign-safe-lambda*");
lf[184]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\001");
lf[185]=C_h_intern(&lf[185],28,"\004coreforeign-callback-lambda");
lf[186]=C_h_intern(&lf[186],19,"foreign-safe-lambda");
lf[187]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[188]=C_h_intern(&lf[188],20,"\004coreforeign-lambda*");
lf[189]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\001");
lf[190]=C_h_intern(&lf[190],19,"\004coreforeign-lambda");
lf[191]=C_h_intern(&lf[191],14,"foreign-lambda");
lf[192]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[193]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[194]=C_h_intern(&lf[194],24,"\004coredefine-foreign-type");
lf[195]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\001\376\377\001\000\000\000\003");
lf[196]=C_h_intern(&lf[196],17,"register-feature!");
lf[197]=C_h_intern(&lf[197],6,"srfi-8");
lf[198]=C_h_intern(&lf[198],7,"srfi-16");
lf[199]=C_h_intern(&lf[199],7,"srfi-26");
lf[200]=C_h_intern(&lf[200],7,"srfi-31");
lf[201]=C_h_intern(&lf[201],7,"srfi-15");
lf[202]=C_h_intern(&lf[202],7,"srfi-11");
lf[203]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004void\376\377\016\376\377\016");
lf[204]=C_h_intern(&lf[204],25,"\003sysenable-runtime-macros");
lf[205]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\377\016");
lf[206]=C_h_intern(&lf[206],17,"define-for-syntax");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\022invalid identifier");
lf[208]=C_h_intern(&lf[208],6,"letrec");
lf[209]=C_h_intern(&lf[209],3,"rec");
lf[210]=C_h_intern(&lf[210],22,"chicken-compile-shared");
lf[211]=C_h_intern(&lf[211],3,"not");
lf[212]=C_h_intern(&lf[212],4,"unit");
lf[213]=C_h_intern(&lf[213],7,"provide");
lf[214]=C_h_intern(&lf[214],11,"cond-expand");
lf[215]=C_h_intern(&lf[215],6,"export");
lf[216]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\377\016");
lf[217]=C_h_intern(&lf[217],6,"static");
lf[218]=C_h_intern(&lf[218],4,"cdar");
lf[219]=C_h_intern(&lf[219],7,"dynamic");
lf[220]=C_h_intern(&lf[220],16,"define-extension");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid clause specifier");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid clause syntax");
lf[223]=C_h_intern(&lf[223],22,"string-parse-start+end");
lf[224]=C_h_intern(&lf[224],7,"receive");
lf[225]=C_h_intern(&lf[225],28,"string-parse-final-start+end");
lf[226]=C_h_intern(&lf[226],20,"let-string-start+end");
lf[227]=C_h_intern(&lf[227],5,"apply");
lf[228]=C_h_intern(&lf[228],2,"<>");
lf[229]=C_h_intern(&lf[229],5,"<...>");
lf[230]=C_h_intern(&lf[230],4,"cute");
lf[231]=C_h_intern(&lf[231],3,"cut");
lf[232]=C_h_intern(&lf[232],22,"\004corerequire-extension");
lf[233]=C_h_intern(&lf[233],3,"use");
lf[234]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[235]=C_h_intern(&lf[235],17,"require-extension");
lf[236]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[237]=C_h_intern(&lf[237],23,"\004corerequire-for-syntax");
lf[238]=C_h_intern(&lf[238],18,"require-for-syntax");
lf[239]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[240]=C_h_intern(&lf[240],18,"\003sysmake-structure");
lf[241]=C_h_intern(&lf[241],1,"x");
lf[242]=C_h_intern(&lf[242],14,"\003sysstructure\077");
lf[243]=C_h_intern(&lf[243],15,"\000record-setters");
lf[244]=C_h_intern(&lf[244],19,"\003syscheck-structure");
lf[245]=C_h_intern(&lf[245],13,"\003sysblock-ref");
lf[246]=C_h_intern(&lf[246],18,"getter-with-setter");
lf[247]=C_h_intern(&lf[247],1,"y");
lf[248]=C_h_intern(&lf[248],14,"\003sysblock-set!");
lf[249]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[250]=C_h_intern(&lf[250],18,"define-record-type");
lf[251]=C_h_intern(&lf[251],4,"memv");
lf[252]=C_h_intern(&lf[252],9,"condition");
lf[253]=C_h_intern(&lf[253],8,"\003sysslot");
lf[254]=C_h_intern(&lf[254],17,"handle-exceptions");
lf[255]=C_h_intern(&lf[255],10,"\003syssignal");
lf[256]=C_h_intern(&lf[256],14,"condition-case");
lf[257]=C_h_intern(&lf[257],9,"\003sysapply");
lf[258]=C_h_intern(&lf[258],10,"\003sysvalues");
lf[259]=C_h_intern(&lf[259],22,"with-exception-handler");
lf[260]=C_h_intern(&lf[260],30,"call-with-current-continuation");
lf[261]=C_h_intern(&lf[261],27,"\003sysregister-record-printer");
lf[262]=C_h_intern(&lf[262],21,"define-record-printer");
lf[263]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[264]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[265]=C_h_intern(&lf[265],6,"length");
lf[266]=C_h_intern(&lf[266],9,"split-at!");
lf[267]=C_h_intern(&lf[267],4,"take");
lf[268]=C_h_intern(&lf[268],3,"fx=");
lf[269]=C_h_intern(&lf[269],11,"case-lambda");
lf[270]=C_h_intern(&lf[270],11,"lambda-list");
lf[271]=C_h_intern(&lf[271],25,"\003sysdecompose-lambda-list");
lf[272]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corecheck\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\003syserror\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreimmutable\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376B\000\0000no matching clause in call to \047case-lambda\047 form\376\377\016\376\377\016\376\377\016"
"\376\377\016");
lf[273]=C_h_intern(&lf[273],3,"min");
lf[274]=C_h_intern(&lf[274],7,"require");
lf[275]=C_h_intern(&lf[275],6,"srfi-1");
lf[276]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[278]=C_h_intern(&lf[278],14,"\004coreimmutable");
lf[279]=C_h_intern(&lf[279],9,"\003syserror");
lf[280]=C_h_intern(&lf[280],14,"let-optionals*");
lf[281]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[282]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[283]=C_h_intern(&lf[283],8,"optional");
lf[284]=C_h_intern(&lf[284],9,":optional");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[286]=C_h_intern(&lf[286],4,"let*");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\004def-");
lf[289]=C_h_intern(&lf[289],5,"%rest");
lf[290]=C_h_intern(&lf[290],4,"body");
lf[291]=C_h_intern(&lf[291],4,"cadr");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\001%");
lf[293]=C_h_intern(&lf[293],13,"let-optionals");
lf[294]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[295]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[296]=C_h_intern(&lf[296],4,"eqv\077");
lf[297]=C_h_intern(&lf[297],6,"switch");
lf[298]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[299]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[300]=C_h_intern(&lf[300],2,"or");
lf[301]=C_h_intern(&lf[301],6,"select");
lf[302]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[303]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[304]=C_h_intern(&lf[304],21,"\003syssyntax-error-hook");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\037syntax error in \047and-let*\047 form");
lf[306]=C_h_intern(&lf[306],8,"and-let*");
lf[307]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[308]=C_h_intern(&lf[308],20,"\004coredefine-constant");
lf[309]=C_h_intern(&lf[309],15,"define-constant");
lf[310]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[311]=C_h_intern(&lf[311],18,"\004coredefine-inline");
lf[312]=C_h_intern(&lf[312],13,"define-inline");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000*invalid substitution form - must be lambda");
lf[314]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[315]=C_h_intern(&lf[315],8,"list-ref");
lf[316]=C_h_intern(&lf[316],9,"nth-value");
lf[317]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[318]=C_h_intern(&lf[318],13,"letrec-values");
lf[319]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[320]=C_h_intern(&lf[320],10,"let-values");
lf[321]=C_h_intern(&lf[321],11,"let*-values");
lf[322]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[323]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[324]=C_h_intern(&lf[324],13,"define-values");
lf[325]=C_h_intern(&lf[325],11,"set!-values");
lf[326]=C_h_intern(&lf[326],6,"unless");
lf[327]=C_h_intern(&lf[327],4,"when");
lf[328]=C_h_intern(&lf[328],16,"\003sysdynamic-wind");
lf[329]=C_h_intern(&lf[329],1,"t");
lf[330]=C_h_intern(&lf[330],8,"\003syslist");
lf[331]=C_h_intern(&lf[331],12,"parameterize");
lf[332]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[333]=C_h_intern(&lf[333],10,"\000compiling");
lf[334]=C_h_intern(&lf[334],19,"\004corecompiletimetoo");
lf[335]=C_h_intern(&lf[335],20,"\004corecompiletimeonly");
lf[336]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[337]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[338]=C_h_intern(&lf[338],4,"load");
lf[339]=C_h_intern(&lf[339],8,"run-time");
lf[340]=C_h_intern(&lf[340],7,"compile");
lf[341]=C_h_intern(&lf[341],12,"compile-time");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid situation specifier");
lf[343]=C_h_intern(&lf[343],9,"eval-when");
lf[344]=C_h_intern(&lf[344],8,"\003sysvoid");
lf[345]=C_h_intern(&lf[345],9,"fluid-let");
lf[346]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[347]=C_h_intern(&lf[347],11,"\000type-error");
lf[348]=C_h_intern(&lf[348],15,"\003syssignal-hook");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\033argument has incorrect type");
lf[350]=C_h_intern(&lf[350],6,"ensure");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\020assertion failed");
lf[352]=C_h_intern(&lf[352],6,"assert");
lf[353]=C_h_intern(&lf[353],20,"with-input-from-file");
lf[354]=C_h_intern(&lf[354],4,"read");
lf[355]=C_h_intern(&lf[355],27,"\003syscurrent-source-filename");
lf[356]=C_h_intern(&lf[356],5,"print");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\014; including ");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[359]=C_h_intern(&lf[359],12,"load-verbose");
lf[360]=C_h_intern(&lf[360],28,"\003sysresolve-include-filename");
lf[361]=C_h_intern(&lf[361],7,"include");
lf[362]=C_h_intern(&lf[362],15,"\003sysstart-timer");
lf[363]=C_h_intern(&lf[363],14,"\003sysstop-timer");
lf[364]=C_h_intern(&lf[364],17,"\003sysdisplay-times");
lf[365]=C_h_intern(&lf[365],4,"time");
lf[366]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[367]=C_h_intern(&lf[367],28,"\003sysstring->qualified-symbol");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\005-set!");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\001\077");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\005make-");
lf[373]=C_h_intern(&lf[373],27,"\003sysqualified-symbol-prefix");
lf[374]=C_h_intern(&lf[374],13,"define-record");
lf[375]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[376]=C_h_intern(&lf[376],6,"symbol");
lf[377]=C_h_intern(&lf[377],11,"\003sysprovide");
lf[378]=C_h_intern(&lf[378],19,"chicken-more-macros");
C_register_lf2(lf,379,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_689,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k687 */
static void C_ccall f_689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_692,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k690 in k687 */
static void C_ccall f_692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_692,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_695,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k693 in k690 in k687 */
static void C_ccall f_695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_695,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_698,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k696 in k693 in k690 in k687 */
static void C_ccall f_698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_701,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_701,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_704,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_707,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_710,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_match_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_710,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_713,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_4_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_716,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_719,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_support_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_719,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_722,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_compiler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_722,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_725,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_728,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_driver_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_731,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_platform_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_734,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_backend_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_734,2,t0,t1);}
t2=C_retrieve(lf[0]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_740,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#provide */
t4=C_retrieve(lf[377]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[378]);}

/* k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_740,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_743,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[166]+1);
t4=*((C_word*)lf[13]+1);
t5=*((C_word*)lf[141]+1);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6918,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t7=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[374],t6);}

/* a6917 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6918(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_6918r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6918r(t0,t1,t2,t3);}}

static void C_ccall f_6918r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6922,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t5=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[374],t2,lf[376]);}

/* k6920 in a6917 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[374],((C_word*)t0)[5],lf[375]);}

/* k6923 in k6920 in a6917 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6928,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   symbol->string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k6926 in k6923 in k6920 in a6917 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6928,2,t0,t1);}
t2=(C_word)C_i_memq(lf[243],C_retrieve(lf[55]));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6934,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* chicken.scm: 71   ##sys#qualified-symbol-prefix */
t4=C_retrieve(lf[373]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}

/* k6932 in k6926 in k6923 in k6920 in a6917 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7120,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7140,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   string-append */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[372],((C_word*)t0)[3]);}

/* k7138 in k6932 in k6926 in k6923 in k6920 in a6917 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_7140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[367]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7118 in k6932 in k6926 in k6923 in k6920 in a6917 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_7120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7120,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
t4=(C_word)C_a_i_cons(&a,2,lf[240],t3);
t5=(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_list(&a,3,lf[82],t1,t5);
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7096,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t6,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7116,a[2]=((C_word*)t0)[5],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   string-append */
t9=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,((C_word*)t0)[3],lf[371]);}

/* k7114 in k7118 in k6932 in k6926 in k6923 in k6920 in a6917 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_7116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[367]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7094 in k7118 in k6932 in k6926 in k6923 in k6920 in a6917 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_7096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7096,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[241]);
t3=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[10]);
t4=(C_word)C_a_i_list(&a,3,lf[242],lf[241],t3);
t5=(C_word)C_a_i_list(&a,3,lf[2],t2,t4);
t6=(C_word)C_a_i_list(&a,3,lf[82],t1,t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6957,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6959,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t9,a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp));
t11=((C_word*)t9)[1];
f_6959(t11,t7,((C_word*)t0)[2],C_fix(1));}

/* mapslots in k7094 in k7118 in k6932 in k6926 in k6923 in k6920 in a6917 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_6959(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6959,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6969,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=t1,a[9]=t3,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* chicken.scm: 71   symbol->string */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}}

/* k6967 in mapslots in k7094 in k7118 in k6932 in k6926 in k6923 in k6920 in a6917 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6972,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7088,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   string-append */
t4=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[2],lf[369],t1,lf[370]);}

/* k7086 in k6967 in mapslots in k7094 in k7118 in k6932 in k6926 in k6923 in k6920 in a6917 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_7088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[367]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6970 in k6967 in mapslots in k7094 in k7118 in k6932 in k6926 in k6923 in k6920 in a6917 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6975,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t1,a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7084,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   string-append */
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[3],lf[368],((C_word*)t0)[2]);}

/* k7082 in k6970 in k6967 in mapslots in k7094 in k7118 in k6932 in k6926 in k6923 in k6920 in a6917 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_7084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[367]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6973 in k6970 in k6967 in mapslots in k7094 in k7118 in k6932 in k6926 in k6923 in k6920 in a6917 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[167],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6975,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[241],lf[77]);
t3=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[8]);
t4=(C_word)C_a_i_list(&a,3,lf[244],lf[241],t3);
t5=(C_word)C_a_i_list(&a,2,lf[111],t4);
t6=(C_word)C_a_i_list(&a,4,lf[248],lf[241],((C_word*)t0)[7],lf[77]);
t7=(C_word)C_a_i_list(&a,4,lf[2],t2,t5,t6);
t8=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[6],t7);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7006,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t8,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t10=(C_word)C_a_i_list(&a,1,lf[241]);
t11=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[8]);
t12=(C_word)C_a_i_list(&a,3,lf[244],lf[241],t11);
t13=(C_word)C_a_i_list(&a,2,lf[111],t12);
t14=(C_word)C_a_i_list(&a,3,lf[245],lf[241],((C_word*)t0)[7]);
t15=(C_word)C_a_i_list(&a,4,lf[2],t10,t13,t14);
t16=t9;
f_7006(t16,(C_word)C_a_i_list(&a,3,lf[246],t15,((C_word*)t0)[6]));}
else{
t10=(C_word)C_a_i_list(&a,1,lf[241]);
t11=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[8]);
t12=(C_word)C_a_i_list(&a,3,lf[244],lf[241],t11);
t13=(C_word)C_a_i_list(&a,2,lf[111],t12);
t14=(C_word)C_a_i_list(&a,3,lf[245],lf[241],((C_word*)t0)[7]);
t15=t9;
f_7006(t15,(C_word)C_a_i_list(&a,4,lf[2],t10,t13,t14));}}

/* k7004 in k6973 in k6970 in k6967 in mapslots in k7094 in k7118 in k6932 in k6926 in k6923 in k6920 in a6917 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_7006(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7006,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_list(&a,3,lf[68],((C_word*)t0)[6],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6986,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t6=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* chicken.scm: 71   mapslots */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6959(t7,t4,t5,t6);}

/* k6984 in k7004 in k6973 in k6970 in k6967 in mapslots in k7094 in k7118 in k6932 in k6926 in k6923 in k6920 in a6917 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6986,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6955 in k7094 in k7118 in k6932 in k6926 in k6923 in k6920 in a6917 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6957,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[68],t3));}

/* k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_746,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6830,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[224],t3);}

/* a6829 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6830(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+23)){
C_save_and_reclaim((void*)tr3r,(void*)f_6830r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6830r(t0,t1,t2,t3);}}

static void C_ccall f_6830r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(23);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[4],t4,lf[330]));}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6847,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t5=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[224],t2,lf[270]);}}

/* k6845 in a6829 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6847,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6850,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[224],((C_word*)t0)[3],lf[366]);}

/* k6848 in k6845 in a6829 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6856,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=t2;
f_6856(t4,(C_word)C_i_nullp(t3));}
else{
t3=t2;
f_6856(t3,C_SCHEME_FALSE);}}

/* k6854 in k6848 in k6845 in a6829 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_6856(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6856,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[79],t7));}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[2],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[4],t3,t6));}}

/* k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_746,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_749,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[6]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6789,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t5=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[365],t4);}

/* a6788 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6789(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_6789r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6789r(t0,t1,t2);}}

static void C_ccall f_6789r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6793,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   gensym */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[329]);}

/* k6791 in a6788 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6793,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[362]);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,lf[2],t3);
t5=(C_word)C_a_i_list(&a,1,lf[363]);
t6=(C_word)C_a_i_list(&a,2,lf[364],t5);
t7=(C_word)C_a_i_list(&a,3,lf[257],lf[258],t1);
t8=(C_word)C_a_i_list(&a,4,lf[2],t1,t6,t7);
t9=(C_word)C_a_i_list(&a,3,lf[4],t4,t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,3,lf[68],t2,t9));}

/* k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_749,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_752,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6773,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[133],t3);}

/* a6772 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6773(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_6773r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6773r(t0,t1,t2);}}

static void C_ccall f_6773r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6781,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6783,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a6782 in a6772 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6783(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6783,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k6779 in a6772 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6781,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[99],t1));}

/* k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_752,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_755,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[353]);
t4=*((C_word*)lf[354]+1);
t5=*((C_word*)lf[12]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6696,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t7=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[361],t6);}

/* a6695 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6696(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6696,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6700,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#resolve-include-filename */
t4=C_retrieve(lf[360]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,C_SCHEME_TRUE);}

/* k6698 in a6695 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6700,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6703,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6768,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   load-verbose */
t4=C_retrieve(lf[359]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k6766 in k6698 in a6695 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken.scm: 71   print */
t2=*((C_word*)lf[356]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[357],((C_word*)t0)[2],lf[358]);}
else{
t2=((C_word*)t0)[3];
f_6703(2,t2,C_SCHEME_UNDEFINED);}}

/* k6701 in k6698 in a6695 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6710,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6712,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   with-input-from-file */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[5],t3);}

/* a6711 in k6701 in k6698 in a6695 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6712,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6718,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6726,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6759,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[328]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t1,t6,t7,t8);}

/* a6758 in a6711 in k6701 in k6698 in a6695 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6759,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[355]));
t3=C_mutate((C_word*)lf[355]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[0]));}

/* a6725 in a6711 in k6701 in k6698 in a6695 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6726,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6734,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   read */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6732 in a6725 in a6711 in k6701 in k6698 in a6695 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6734,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6736,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6736(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* do44 in k6732 in a6725 in a6711 in k6701 in k6698 in a6695 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_6736(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6736,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eofp(t2))){
/* chicken.scm: 71   reverse */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6753,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   read */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k6751 in do44 in k6732 in a6725 in a6711 in k6701 in k6698 in a6695 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6753,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_6736(t3,((C_word*)t0)[2],t1,t2);}

/* a6717 in a6711 in k6701 in k6698 in a6695 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6718,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[355]));
t3=C_mutate((C_word*)lf[355]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[0]));}

/* k6708 in k6701 in k6698 in a6695 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6710,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[68],t1));}

/* k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_755,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_758,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6636,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[352],t3);}

/* a6635 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6636(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_6636r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6636r(t0,t1,t2,t3);}}

static void C_ccall f_6636r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6640,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t3);
if(C_truep(t5)){
t6=(C_word)C_a_i_list(&a,2,lf[61],lf[351]);
t7=t4;
f_6640(t7,(C_word)C_a_i_list(&a,2,lf[278],t6));}
else{
t6=t4;
f_6640(t6,(C_word)C_slot(t3,C_fix(0)));}}

/* k6638 in a6635 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_6640(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6640,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[111],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,lf[3]);
t4=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=(C_word)C_fixnum_greaterp(t5,C_fix(1));
t7=(C_truep(t6)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t4,t7);
t9=(C_word)C_a_i_cons(&a,2,t1,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[279],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[72],t2,t3,t10));}

/* k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_758,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_761,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6577,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[350],t3);}

/* a6576 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6577(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_6577r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6577r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6577r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6581,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   gensym */
t6=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k6579 in a6576 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[54],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6581,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t5=(C_word)C_a_i_list(&a,2,lf[111],t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6608,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t7=t6;
f_6608(t7,((C_word*)t0)[2]);}
else{
t7=(C_word)C_a_i_list(&a,2,lf[61],lf[349]);
t8=(C_word)C_a_i_list(&a,2,lf[278],t7);
t9=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t10=t6;
f_6608(t10,(C_word)C_a_i_list(&a,3,t8,t1,t9));}}

/* k6606 in k6579 in a6576 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_6608(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6608,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[347],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[348],t2);
t4=(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[5],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t4));}

/* k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_764,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[6]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6403,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t5=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[345],t4);}

/* a6402 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6403(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_6403r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6403r(t0,t1,t2,t3);}}

static void C_ccall f_6403r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6407,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t5=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[345],t2,lf[346]);}

/* k6405 in a6402 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6410,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[76]+1),((C_word*)t0)[3]);}

/* k6408 in k6405 in a6402 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6413,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6571,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a6570 in k6408 in k6405 in a6402 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6571(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6571,3,t0,t1,t2);}
/* chicken.scm: 71   gensym */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k6411 in k6408 in k6405 in a6402 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6416,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6565,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a6564 in k6411 in k6408 in k6405 in a6402 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6565(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6565,3,t0,t1,t2);}
/* chicken.scm: 71   gensym */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k6414 in k6411 in k6408 in k6405 in a6402 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6423,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6527,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6563,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[291]+1),((C_word*)t0)[2]);}

/* k6561 in k6414 in k6411 in k6408 in k6405 in a6402 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   map */
t2=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[330]+1),((C_word*)t0)[2],t1);}

/* k6525 in k6414 in k6411 in k6408 in k6405 in a6402 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6527,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6531,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6535,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(((C_word*)t0)[2]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6541,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_6541(t8,t3,t4);}

/* loop in k6525 in k6414 in k6411 in k6408 in k6405 in a6402 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_6541(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6541,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6555,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
/* chicken.scm: 71   loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k6553 in loop in k6525 in k6414 in k6411 in k6408 in k6405 in a6402 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6555,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1));}

/* k6533 in k6525 in k6414 in k6411 in k6408 in k6405 in a6402 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   map */
t2=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[330]+1),((C_word*)t0)[2],t1);}

/* k6529 in k6525 in k6414 in k6411 in k6408 in k6405 in a6402 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6421 in k6414 in k6411 in k6408 in k6405 in a6402 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6491,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6495,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6519,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   map */
t5=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* a6518 in k6421 in k6414 in k6411 in k6408 in k6405 in a6402 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6519(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6519,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t2,t3));}

/* k6493 in k6421 in k6414 in k6411 in k6408 in k6405 in a6402 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6495,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6499,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6503,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6513,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   map */
t5=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6512 in k6493 in k6421 in k6414 in k6411 in k6408 in k6405 in a6402 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6513(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6513,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t2,t3));}

/* k6501 in k6493 in k6421 in k6414 in k6411 in k6408 in k6405 in a6402 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6503,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[344]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k6497 in k6493 in k6421 in k6414 in k6411 in k6408 in k6405 in a6402 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6489 in k6421 in k6414 in k6411 in k6408 in k6405 in a6402 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6491,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[2],t2);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,lf[2],t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6447,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6451,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6475,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   map */
t9=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,t8,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a6474 in k6489 in k6421 in k6414 in k6411 in k6408 in k6405 in a6402 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6475(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6475,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t2,t3));}

/* k6449 in k6489 in k6421 in k6414 in k6411 in k6408 in k6405 in a6402 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6455,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6459,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6469,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   map */
t5=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6468 in k6449 in k6489 in k6421 in k6414 in k6411 in k6408 in k6405 in a6402 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6469(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6469,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t2,t3));}

/* k6457 in k6449 in k6489 in k6421 in k6414 in k6411 in k6408 in k6405 in a6402 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6459,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[344]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k6453 in k6449 in k6489 in k6421 in k6414 in k6411 in k6408 in k6405 in a6402 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6445 in k6489 in k6421 in k6414 in k6411 in k6408 in k6405 in a6402 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6447,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[2],t2);
t4=(C_word)C_a_i_list(&a,4,lf[328],((C_word*)t0)[5],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t4));}

/* k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_764,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_767,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6308,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[343],t3);}

/* a6307 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6308(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr3r,(void*)f_6308r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6308r(t0,t1,t2,t3);}}

static void C_ccall f_6308r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(24);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(C_word)C_a_i_cons(&a,2,lf[68],t3);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6315,a[2]=t5,a[3]=t10,a[4]=t1,a[5]=t9,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6344,a[2]=t7,a[3]=t9,a[4]=t5,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_6344(t15,t11,t2);}

/* loop in a6307 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_6344(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6344,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6357,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(t3,lf[147]);
if(C_truep(t5)){
t6=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t7=t4;
f_6357(2,t7,t6);}
else{
t6=(C_word)C_eqp(t3,lf[338]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t3,lf[339]));
if(C_truep(t7)){
t8=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t9=t4;
f_6357(2,t9,t8);}
else{
t8=(C_word)C_eqp(t3,lf[340]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[341]));
if(C_truep(t9)){
t10=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t11=t4;
f_6357(2,t11,t10);}
else{
t10=(C_word)C_slot(t2,C_fix(0));
/* chicken.scm: 71   ##sys#error */
t11=*((C_word*)lf[279]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t4,lf[342],t10);}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6355 in loop in a6307 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* chicken.scm: 71   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6344(t3,((C_word*)t0)[2],t2);}

/* k6313 in a6307 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6315,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[333],C_retrieve(lf[55])))){
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?((C_word*)((C_word*)t0)[5])[1]:C_SCHEME_FALSE);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_a_i_list(&a,2,lf[334],((C_word*)t0)[3]):(C_truep(((C_word*)((C_word*)t0)[6])[1])?(C_word)C_a_i_list(&a,2,lf[335],((C_word*)t0)[3]):(C_truep(((C_word*)((C_word*)t0)[5])[1])?((C_word*)t0)[3]:lf[336]))));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)((C_word*)t0)[2])[1])?((C_word*)t0)[3]:lf[337]));}}

/* k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_767,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_770,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[76]+1);
t4=*((C_word*)lf[291]+1);
t5=*((C_word*)lf[1]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6198,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t7=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[331],t6);}

/* a6197 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6198(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_6198r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6198r(t0,t1,t2,t3);}}

static void C_ccall f_6198r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6202,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t5=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[331],t2,lf[332]);}

/* k6200 in a6197 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6203 in k6200 in a6197 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6208,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   ##sys#map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k6206 in k6203 in k6200 in a6197 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6208,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6211,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   ##sys#map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6209 in k6206 in k6203 in k6200 in a6197 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6211,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6214,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6302,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a6301 in k6209 in k6206 in k6203 in k6200 in a6197 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6302(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6302,3,t0,t1,t2);}
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k6212 in k6209 in k6206 in k6203 in k6200 in a6197 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6217,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6296,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a6295 in k6212 in k6209 in k6206 in k6203 in k6200 in a6197 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6296(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6296,3,t0,t1,t2);}
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k6215 in k6212 in k6209 in k6206 in k6203 in k6200 in a6197 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6224,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6290,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   map */
t4=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[330]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k6288 in k6215 in k6212 in k6209 in k6206 in k6203 in k6200 in a6197 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6294,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   map */
t3=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[330]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6292 in k6288 in k6215 in k6212 in k6209 in k6206 in k6203 in k6200 in a6197 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6222 in k6215 in k6212 in k6209 in k6206 in k6203 in k6200 in a6197 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6260,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6262,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   map */
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6261 in k6222 in k6215 in k6212 in k6209 in k6206 in k6203 in k6200 in a6197 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6262(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[39],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6262,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t2);
t5=(C_word)C_a_i_list(&a,2,lf[329],t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_list(&a,2,t2,t3);
t8=(C_word)C_a_i_list(&a,3,lf[5],t3,lf[329]);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_list(&a,4,lf[79],t6,t7,t8));}

/* k6258 in k6222 in k6215 in k6212 in k6209 in k6206 in k6203 in k6200 in a6197 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6260,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[2],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t7=(C_word)C_a_i_cons(&a,2,lf[2],t6);
t8=(C_word)C_a_i_list(&a,4,lf[328],((C_word*)t0)[5],t7,((C_word*)t0)[5]);
t9=(C_word)C_a_i_list(&a,3,lf[79],t5,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t9));}

/* k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_773,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6188,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[327],t3);}

/* a6187 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6188(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_6188r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6188r(t0,t1,t2,t3);}}

static void C_ccall f_6188r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(12);
t4=(C_word)C_a_i_cons(&a,2,lf[68],t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[72],t2,t4));}

/* k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_776,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6174,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[326],t3);}

/* a6173 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6174(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr3r,(void*)f_6174r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6174r(t0,t1,t2,t3);}}

static void C_ccall f_6174r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(18);
t4=(C_word)C_a_i_list(&a,1,lf[3]);
t5=(C_word)C_a_i_cons(&a,2,lf[68],t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,4,lf[72],t2,t4,t5));}

/* k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_776,2,t0,t1);}
t2=*((C_word*)lf[1]+1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_777,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_850,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t5=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[325],t3);}

/* k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_853,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t3=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[324],((C_word*)t0)[2]);}

/* k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_856,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5841,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5872,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5912,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t10=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t2,lf[320],t9);}

/* a5839 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5912(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5912,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[320],t2,lf[323]);}

/* k5914 in a5839 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5916,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[76]+1),t2);}

/* k5923 in k5914 in a5839 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5928,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6134,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6134(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* loop in k5923 in k5914 in a5839 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_6134(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6134,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6147,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t4))){
/* chicken.scm: 71   append */
t6=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t4))){
/* chicken.scm: 71   append* */
t6=((C_word*)((C_word*)t0)[2])[1];
f_5841(t6,t5,t4,t3);}
else{
t6=t5;
f_6147(2,t6,(C_word)C_a_i_cons(&a,2,t4,t3));}}}}

/* k6145 in loop in k5923 in k5914 in a5839 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 71   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6134(t3,((C_word*)t0)[2],t2,t1);}

/* k5926 in k5923 in k5914 in a5839 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6124,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a6123 in k5926 in k5923 in k5914 in a5839 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6124(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6124,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6132,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   gensym */
t4=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6130 in a6123 in k5926 in k5923 in k5914 in a5839 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6132,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5929 in k5926 in k5923 in k5914 in a5839 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5932,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5943,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6078,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_6078(t7,t3,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}

/* loop in k5929 in k5926 in k5923 in k5914 in a5839 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_6078(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6078,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* chicken.scm: 71   reverse */
t4=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6094,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6118,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   map* */
t7=((C_word*)((C_word*)t0)[3])[1];
f_5872(t7,t6,((C_word*)t0)[2],t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6111,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   lookup */
t7=((C_word*)t0)[2];
f_5932(3,t7,t6,t4);}}}

/* k6109 in loop in k5929 in k5926 in k5923 in k5914 in a5839 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6111,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6094(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k6116 in loop in k5929 in k5926 in k5923 in k5914 in a5839 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6118,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6094(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k6092 in loop in k5929 in k5926 in k5923 in k5914 in a5839 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_6094(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 71   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6078(t3,((C_word*)t0)[2],t2,t1);}

/* k5941 in k5929 in k5926 in k5923 in k5914 in a5839 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5943,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5950,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6072,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a6071 in k5941 in k5929 in k5926 in k5923 in k5914 in a5839 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6072(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6072,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k5948 in k5941 in k5929 in k5926 in k5923 in k5914 in a5839 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5950,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5952,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_5952(t5,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* fold in k5948 in k5941 in k5929 in k5926 in k5923 in k5914 in a5839 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_5952(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5952,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5970,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5972,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* map */
t7=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5986,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(t4);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6066,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   cdar */
t8=*((C_word*)lf[218]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}
else{
t7=t5;
f_5986(t7,C_SCHEME_FALSE);}}}

/* k6064 in fold in k5948 in k5941 in k5929 in k5926 in k5923 in k5914 in a5839 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5986(t2,(C_word)C_i_nullp(t1));}

/* k5984 in fold in k5948 in k5941 in k5929 in k5926 in k5923 in k5914 in a5839 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_5986(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5986,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6017,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   caar */
t3=*((C_word*)lf[152]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6040,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[6]);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken.scm: 71   fold */
t9=((C_word*)((C_word*)t0)[2])[1];
f_5952(t9,t5,t6,t7,t8);}}

/* k6038 in k5984 in fold in k5948 in k5941 in k5929 in k5926 in k5923 in k5914 in a5839 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6040,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[4],((C_word*)t0)[2],t2));}

/* k6015 in k5984 in fold in k5948 in k5941 in k5929 in k5926 in k5923 in k5914 in a5839 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_6017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6017,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5997,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[6]);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken.scm: 71   fold */
t9=((C_word*)((C_word*)t0)[2])[1];
f_5952(t9,t5,t6,t7,t8);}

/* k5995 in k6015 in k5984 in fold in k5948 in k5941 in k5929 in k5926 in k5923 in k5914 in a5839 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5997,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* a5971 in fold in k5948 in k5941 in k5929 in k5926 in k5923 in k5914 in a5839 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5972(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5972,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5980,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   lookup */
t4=((C_word*)t0)[2];
f_5932(3,t4,t3,t2);}

/* k5978 in a5971 in fold in k5948 in k5941 in k5929 in k5926 in k5923 in k5914 in a5839 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5980,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k5968 in fold in k5948 in k5941 in k5929 in k5926 in k5923 in k5914 in a5839 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5970,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[79],t2));}

/* lookup in k5929 in k5926 in k5923 in k5914 in a5839 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5932(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5932,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* map* in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_5872(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5872,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5895,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* chicken.scm: 71   proc */
t6=t2;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
/* chicken.scm: 71   proc */
t4=t2;
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}}}

/* k5893 in map* in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5899,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 71   map* */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5872(t4,t2,((C_word*)t0)[2],t3);}

/* k5897 in k5893 in map* in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5899,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* append* in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_5841(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5841,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5862,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* chicken.scm: 71   append* */
t8=t5;
t9=t6;
t10=t3;
t1=t8;
t2=t9;
t3=t10;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}}

/* k5860 in append* in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5862,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_856,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_859,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5790,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[321],t3);}

/* a5789 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5790(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5790,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5794,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[321],t2,lf[322]);}

/* k5792 in a5789 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5794,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5805,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5805(t7,((C_word*)t0)[2],t2);}

/* fold in k5792 in a5789 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_5805(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5805,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[79],t3));}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5830,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* chicken.scm: 71   fold */
t9=t5;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}

/* k5828 in fold in k5792 in a5789 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5830,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[320],((C_word*)t0)[2],t1));}

/* k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_862,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5670,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[318],t3);}

/* a5669 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5670(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5670,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5674,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[318],t2,lf[319]);}

/* k5672 in a5669 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5674,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5683,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5782,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5784,tmp=(C_word)a,a+=2,tmp);
/* map */
t7=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a5783 in k5672 in a5669 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5784(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5784,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k5780 in k5672 in a5669 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[85]+1),t1);}

/* k5681 in k5672 in a5669 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5683,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5686,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5770,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a5769 in k5681 in k5672 in a5669 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5770(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5770,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5778,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   gensym */
t4=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5776 in a5769 in k5681 in k5672 in a5669 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5778,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5684 in k5681 in k5672 in a5669 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5687,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5706,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5764,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a5763 in k5684 in k5681 in k5672 in a5669 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5764(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5764,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,lf[317]));}

/* k5704 in k5684 in k5681 in k5672 in a5669 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5710,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5714,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5716,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a5715 in k5704 in k5684 in k5681 in k5672 in a5669 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5716(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5716,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5736,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t2);
/* map */
t7=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}

/* k5734 in a5715 in k5704 in k5684 in k5681 in k5672 in a5669 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5740,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5742,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[2]);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a5741 in k5734 in a5715 in k5704 in k5684 in k5681 in k5672 in a5669 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5742(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5742,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5750,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   lookup */
t4=((C_word*)t0)[2];
f_5687(3,t4,t3,t2);}

/* k5748 in a5741 in k5734 in a5715 in k5704 in k5684 in k5681 in k5672 in a5669 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5750,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[5],((C_word*)t0)[2],t1));}

/* k5738 in k5734 in a5715 in k5704 in k5684 in k5681 in k5672 in a5669 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5740,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[2],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[4],((C_word*)t0)[2],t3));}

/* k5712 in k5704 in k5684 in k5681 in k5672 in a5669 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5708 in k5704 in k5684 in k5681 in k5672 in a5669 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5710,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[79],t2));}

/* lookup in k5684 in k5681 in k5672 in a5669 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5687(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5687,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_865,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5649,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[316],t3);}

/* a5648 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5649,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5653,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   gensym */
t5=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k5651 in a5648 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5653,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,3,lf[315],t1,((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,3,lf[2],t1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[4],t2,t4));}

/* k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_944,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5639,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[312],t3);}

/* a5638 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5639(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5639,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_871,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[312],t2,lf[314]);}

/* k869 in a5638 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_871,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_880,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(((C_word*)t0)[3]);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=t5;
f_880(t9,(C_word)C_a_i_cons(&a,2,lf[2],t8));}
else{
t6=t5;
f_880(t6,(C_word)C_i_cadr(((C_word*)t0)[3]));}}

/* k878 in k869 in a5638 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_880(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_880,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_883,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_pairp(t1);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_896,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_896(t6,t4);}
else{
t6=(C_word)C_i_car(t1);
t7=(C_word)C_eqp(lf[2],t6);
t8=t5;
f_896(t8,(C_word)C_i_not(t7));}}

/* k894 in k878 in k869 in a5638 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_896(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken.scm: 71   syntax-error */
t2=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[312],lf[313],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_883(2,t2,C_SCHEME_UNDEFINED);}}

/* k881 in k878 in k869 in a5638 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_883,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[311],t3));}

/* k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_947,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5618,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[309],t3);}

/* a5617 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5618(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5618,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5622,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[309],t2,lf[310]);}

/* k5620 in a5617 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5622,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[308],t3,t4));}

/* k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_950,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5502,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[306],t3);}

/* a5501 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5502(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5502,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5506,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[306],t2,lf[307]);}

/* k5504 in a5501 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5506,2,t0,t1);}
t2=(C_word)C_i_listp(((C_word*)t0)[3]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5515,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_5515(t5,t3);}
else{
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=t4;
f_5515(t6,(C_word)C_fixnum_lessp(t5,C_fix(2)));}}

/* k5513 in k5504 in a5501 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_5515(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5515,NULL,2,t0,t1);}
if(C_truep(t1)){
/* chicken.scm: 71   ##sys#syntax-error-hook */
t2=C_retrieve(lf[304]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[305],((C_word*)t0)[2]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[2],C_fix(0));
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5529,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5529(t7,((C_word*)t0)[3],t2);}}

/* fold in k5513 in k5504 in a5501 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_5529(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(25);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5529,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[68],((C_word*)t0)[3]));}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_not_pair_p(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5558,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   fold */
t15=t5;
t16=t4;
t1=t15;
t2=t16;
goto loop;}
else{
t5=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t5))){
t6=(C_word)C_slot(t3,C_fix(0));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5575,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   fold */
t15=t7;
t16=t4;
t1=t15;
t2=t16;
goto loop;}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_i_cadr(t3);
t8=(C_word)C_a_i_list(&a,2,t6,t7);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5593,a[2]=t9,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   fold */
t15=t10;
t16=t4;
t1=t15;
t2=t16;
goto loop;}}}}

/* k5591 in fold in k5513 in k5504 in a5501 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5593,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[4],t1,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t2));}

/* k5573 in fold in k5513 in k5504 in a5501 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5575,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[2],t1,C_SCHEME_FALSE));}

/* k5556 in fold in k5513 in k5504 in a5501 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5558,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[2],t1,C_SCHEME_FALSE));}

/* k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_953,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[6]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5403,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t5=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[301],t4);}

/* a5402 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5403(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5403,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5413,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   gensym */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k5411 in a5402 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5413,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5424,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5426,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_5426(t8,t4,((C_word*)t0)[2]);}

/* expand in k5411 in a5402 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_5426(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5426,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5442,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[301],t3,lf[302]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[303]);}}

/* k5440 in expand in k5411 in a5402 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5442,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[86],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[68],t4));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5478,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5480,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[6]);
/* map */
t7=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}}

/* a5479 in k5440 in expand in k5411 in a5402 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5480(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5480,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[296],((C_word*)t0)[2],t2));}

/* k5476 in k5440 in expand in k5411 in a5402 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5478,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[300],t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,lf[68],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5470,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   expand */
t6=((C_word*)((C_word*)t0)[3])[1];
f_5426(t6,t5,((C_word*)t0)[2]);}

/* k5468 in k5476 in k5440 in expand in k5411 in a5402 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5470,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k5422 in k5411 in a5402 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5424,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_953,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_956,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[6]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5314,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t5=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[297],t4);}

/* a5313 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5314(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5314,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5324,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   gensym */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k5322 in a5313 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5324,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5335,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5337,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_5337(t8,t4,((C_word*)t0)[2]);}

/* expand in k5322 in a5313 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_5337(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5337,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5353,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[297],t3,lf[298]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[299]);}}

/* k5351 in expand in k5322 in a5313 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5353,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[86],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[68],t4));}
else{
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,3,lf[296],((C_word*)t0)[4],t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_cons(&a,2,lf[68],t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5381,a[2]=t7,a[3]=t5,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   expand */
t9=((C_word*)((C_word*)t0)[3])[1];
f_5337(t9,t8,((C_word*)t0)[2]);}}

/* k5379 in k5351 in expand in k5322 in a5313 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5381,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k5333 in k5322 in a5313 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5335,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_959,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5028,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[293],t3);}

/* a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5028(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_5028r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5028r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5028r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5225,a[2]=t3,a[3]=t1,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[293],t3,lf[295]);}

/* k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5225,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5228,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[293],((C_word*)t0)[4],lf[294]);}

/* k5226 in k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5231,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[76]+1),((C_word*)t0)[2]);}

/* k5229 in k5226 in k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5231,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5232,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5247,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5304,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a5303 in k5229 in k5226 in k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5304(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5304,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5312,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   prefix-sym */
f_5232(t3,lf[292],t2);}

/* k5310 in a5303 in k5229 in k5226 in k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   gensym */
t2=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5245 in k5229 in k5226 in k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5250,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[291]+1),((C_word*)t0)[2]);}

/* k5248 in k5245 in k5229 in k5226 in k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5253,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[290]);}

/* k5251 in k5248 in k5245 in k5229 in k5226 in k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5256,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[289]);}

/* k5254 in k5251 in k5248 in k5245 in k5229 in k5226 in k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5259,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5294,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[8]);}

/* a5293 in k5254 in k5251 in k5248 in k5245 in k5229 in k5226 in k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5294(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5294,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5302,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   prefix-sym */
f_5232(t3,lf[288],t2);}

/* k5300 in a5293 in k5254 in k5251 in k5248 in k5245 in k5229 in k5226 in k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   gensym */
t2=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5257 in k5254 in k5251 in k5248 in k5245 in k5229 in k5226 in k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5259,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5262,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[5];
t5=t1;
t6=((C_word*)t0)[2];
t7=C_retrieve(lf[6]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5039,a[2]=t5,a[3]=t6,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   reverse */
t9=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t3);}

/* k5037 in k5257 in k5254 in k5251 in k5248 in k5245 in k5229 in k5226 in k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5039,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5043,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   reverse */
t3=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5041 in k5037 in k5257 in k5254 in k5251 in k5248 in k5245 in k5229 in k5226 in k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5047,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   reverse */
t3=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5045 in k5041 in k5037 in k5257 in k5254 in k5251 in k5248 in k5245 in k5229 in k5226 in k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5047,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5049,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_5049(t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* recur in k5045 in k5041 in k5037 in k5257 in k5254 in k5251 in k5248 in k5245 in k5229 in k5226 in k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_5049(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5049,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5094,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=t7,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* chicken.scm: 71   reverse */
t9=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t6);}}

/* k5092 in recur in k5045 in k5041 in k5037 in k5257 in k5254 in k5251 in k5248 in k5245 in k5229 in k5226 in k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5102,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5106,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   reverse */
t4=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5104 in k5092 in recur in k5045 in k5041 in k5037 in k5257 in k5254 in k5251 in k5248 in k5245 in k5229 in k5226 in k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5106,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k5100 in k5092 in recur in k5045 in k5041 in k5037 in k5257 in k5254 in k5251 in k5248 in k5245 in k5229 in k5226 in k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5102,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5070,a[2]=t4,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
t8=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 71   recur */
t9=((C_word*)((C_word*)t0)[3])[1];
f_5049(t9,t5,((C_word*)t0)[2],t6,t7,t8);}

/* k5068 in k5100 in k5092 in recur in k5045 in k5041 in k5037 in k5257 in k5254 in k5251 in k5248 in k5245 in k5229 in k5226 in k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5070,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5260 in k5257 in k5254 in k5251 in k5248 in k5245 in k5229 in k5226 in k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5262,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5265,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[9];
t7=C_retrieve(lf[6]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5122,a[2]=t9,a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_5122(t11,t2,t3,t4,C_SCHEME_END_OF_LIST);}

/* recur in k5260 in k5257 in k5254 in k5251 in k5248 in k5245 in k5229 in k5226 in k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_5122(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5122,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(C_word)C_a_i_list(&a,2,lf[74],((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,lf[111],t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5156,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   reverse */
t8=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_list(&a,2,lf[74],((C_word*)t0)[4]);
t7=(C_word)C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5222,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t6,a[7]=t1,a[8]=t5,a[9]=((C_word*)t0)[4],a[10]=t7,tmp=(C_word)a,a+=11,tmp);
/* chicken.scm: 71   reverse */
t9=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t4);}}

/* k5220 in recur in k5260 in k5257 in k5254 in k5251 in k5248 in k5245 in k5229 in k5226 in k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5222,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_list(&a,2,lf[76],((C_word*)t0)[9]);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_list(&a,2,lf[75],((C_word*)t0)[9]);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],t5);
t7=(C_word)C_a_i_list(&a,2,t4,t6);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5186,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[3]);
/* chicken.scm: 71   recur */
t12=((C_word*)((C_word*)t0)[2])[1];
f_5122(t12,t8,t9,t10,t11);}

/* k5184 in k5220 in recur in k5260 in k5257 in k5254 in k5251 in k5248 in k5245 in k5229 in k5226 in k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5186,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k5154 in recur in k5260 in k5257 in k5254 in k5251 in k5248 in k5245 in k5229 in k5226 in k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5156,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,2,lf[61],lf[287]);
t4=(C_word)C_a_i_list(&a,2,lf[278],t3);
t5=(C_word)C_a_i_list(&a,3,lf[279],t4,((C_word*)t0)[4]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[2],t2,t5));}

/* k5263 in k5260 in k5257 in k5254 in k5251 in k5248 in k5245 in k5229 in k5226 in k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5265,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,lf[2],t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,3,lf[286],t7,t1));}

/* prefix-sym in k5229 in k5226 in k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_5232(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5232,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5240,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5244,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   symbol->string */
t6=*((C_word*)lf[166]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}

/* k5242 in prefix-sym in k5229 in k5226 in k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   string-append */
t2=*((C_word*)lf[141]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5238 in prefix-sym in k5229 in k5226 in k5223 in a5027 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_5240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_962,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4971,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[283],t3);}

/* a4970 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4971(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4971,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4975,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   gensym */
t5=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k4973 in a4970 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[93],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4975,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,lf[74],t1);
t5=(C_word)C_a_i_list(&a,2,lf[75],t1);
t6=(C_word)C_a_i_list(&a,2,lf[74],t5);
t7=(C_word)C_a_i_list(&a,2,lf[111],t6);
t8=(C_word)C_a_i_list(&a,2,lf[76],t1);
t9=(C_word)C_a_i_list(&a,2,lf[61],lf[285]);
t10=(C_word)C_a_i_list(&a,2,lf[278],t9);
t11=(C_word)C_a_i_list(&a,3,lf[279],t10,t1);
t12=(C_word)C_a_i_list(&a,4,lf[72],t7,t8,t11);
t13=(C_word)C_a_i_list(&a,4,lf[72],t4,((C_word*)t0)[3],t12);
t14=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,3,lf[79],t3,t13));}

/* k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_965,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4965,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[284],t3);}

/* a4964 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4965(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4965,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[283],t2));}

/* k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_968,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4812,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[280],t3);}

/* a4811 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4812r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4812r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4812r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4816,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[280],t3,lf[282]);}

/* k4814 in a4811 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4816,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4819,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[280],((C_word*)t0)[3],lf[281]);}

/* k4817 in k4814 in a4811 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4819,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4822,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4820 in k4817 in k4814 in a4811 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4822,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4833,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4835,a[2]=t6,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4835(t8,t4,t1,((C_word*)t0)[2]);}

/* loop in k4820 in k4817 in k4814 in a4811 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_4835(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4835,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_a_i_list(&a,2,lf[74],t2);
t5=(C_word)C_a_i_list(&a,2,lf[111],t4);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,lf[79],t6);
t8=(C_word)C_a_i_list(&a,2,lf[61],lf[277]);
t9=(C_word)C_a_i_list(&a,2,lf[278],t8);
t10=(C_word)C_a_i_list(&a,3,lf[279],t9,t2);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[72],t5,t7,t10));}
else{
t4=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4885,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   gensym */
t6=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=(C_word)C_a_i_list(&a,2,t4,t2);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[3]);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[79],t7));}}}

/* k4883 in loop in k4820 in k4817 in k4814 in a4811 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[76],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4885,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,lf[74],((C_word*)t0)[5]);
t4=(C_word)C_i_cadr(((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,2,lf[76],((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,4,lf[72],t3,t4,t5);
t7=(C_word)C_a_i_list(&a,2,t2,t6);
t8=(C_word)C_a_i_list(&a,2,lf[74],((C_word*)t0)[5]);
t9=(C_word)C_a_i_list(&a,2,lf[61],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_list(&a,2,lf[75],((C_word*)t0)[5]);
t11=(C_word)C_a_i_list(&a,4,lf[72],t8,t9,t10);
t12=(C_word)C_a_i_list(&a,2,t1,t11);
t13=(C_word)C_a_i_list(&a,2,t7,t12);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4896,a[2]=t13,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken.scm: 71   loop */
t16=((C_word*)((C_word*)t0)[2])[1];
f_4835(t16,t14,t1,t15);}

/* k4894 in k4883 in loop in k4820 in k4817 in k4814 in a4811 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4896,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k4831 in k4820 in k4817 in k4814 in a4811 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4833,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_971,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4536,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[269],t3);}

/* a4535 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4536(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4536,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4570,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[269],t2,lf[276]);}

/* k4568 in a4535 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4570,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4573,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   require */
t3=C_retrieve(lf[274]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[275]);}

/* k4571 in k4568 in a4535 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4573,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4576,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4797,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4799,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a4798 in k4571 in k4568 in a4535 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4799(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4799,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4809,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#decompose-lambda-list */
t5=C_retrieve(lf[271]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a4808 in a4798 in k4571 in k4568 in a4535 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4809(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4809,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k4795 in k4571 in k4568 in a4535 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[273]+1),t1);}

/* k4574 in k4571 in k4568 in a4535 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4579,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=t1;
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4545,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4545(t7,t2,C_fix(0));}

/* loop in k4574 in k4571 in k4568 in a4535 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_4545(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4545,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4559,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   gensym */
t4=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k4557 in loop in k4574 in k4571 in k4568 in a4535 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4563,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* chicken.scm: 71   loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4545(t4,t2,t3);}

/* k4561 in k4557 in loop in k4574 in k4571 in k4568 in a4535 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4563,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4577 in k4574 in k4571 in k4568 in a4535 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4579,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4582,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4580 in k4577 in k4574 in k4571 in k4568 in a4535 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4585,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4583 in k4580 in k4577 in k4574 in k4571 in k4568 in a4535 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4585,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   append */
t3=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[6]);}

/* k4590 in k4583 in k4580 in k4577 in k4574 in k4571 in k4568 in a4535 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4592,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[265],((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4604,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4606,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   fold-right */
t7=C_retrieve(lf[161]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,t6,lf[272],((C_word*)t0)[2]);}

/* a4605 in k4590 in k4583 in k4580 in k4577 in k4574 in k4571 in k4568 in a4535 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4606,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   ##sys#decompose-lambda-list */
t6=C_retrieve(lf[271]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t4,t5);}

/* a4615 in a4605 in k4590 in k4583 in k4580 in k4577 in k4574 in k4571 in k4568 in a4535 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4616(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4616,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4620,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=((C_word*)t0)[7],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* chicken.scm: 71   ##sys#check-syntax */
t7=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,lf[269],t6,lf[270]);}

/* k4618 in a4615 in a4605 in k4590 in k4583 in k4580 in k4577 in k4574 in k4571 in k4568 in a4535 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4620,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[11],((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4630,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=(C_word)C_eqp(t2,C_fix(0));
t5=t3;
f_4630(t5,(C_truep(t4)?C_SCHEME_TRUE:(C_word)C_a_i_list(&a,3,lf[108],((C_word*)t0)[2],t2)));}
else{
t4=t3;
f_4630(t4,(C_word)C_a_i_list(&a,3,lf[268],((C_word*)t0)[2],t2));}}

/* k4628 in k4618 in a4615 in a4605 in k4590 in k4583 in k4580 in k4577 in k4574 in k4571 in k4568 in a4535 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_4630(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4630,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4634,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4636,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a4645 in k4628 in k4618 in a4615 in a4605 in k4590 in k4583 in k4580 in k4577 in k4574 in k4571 in k4568 in a4535 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4646(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4646,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4650,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4665,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4665(t8,t4,t3,((C_word*)t0)[2]);}

/* build in a4645 in k4628 in k4618 in a4615 in a4605 in k4590 in k4583 in k4580 in k4577 in k4574 in k4571 in k4568 in a4535 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_4665(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4665,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[4])){
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[79],t7));}
else{
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cadr(((C_word*)t0)[3]));}
else{
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[79],t6));}}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4721,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   gensym */
t5=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k4719 in build in a4645 in k4628 in k4618 in a4615 in a4605 in k4590 in k4583 in k4580 in k4577 in k4574 in k4571 in k4568 in a4535 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4721,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,lf[76],((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,2,lf[75],((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,t1,t5);
t7=(C_word)C_a_i_list(&a,2,t4,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4732,a[2]=t7,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken.scm: 71   build */
t11=((C_word*)((C_word*)t0)[2])[1];
f_4665(t11,t8,t10,t1);}
else{
/* chicken.scm: 71   build */
t10=((C_word*)((C_word*)t0)[2])[1];
f_4665(t10,t8,C_SCHEME_END_OF_LIST,t1);}}

/* k4730 in k4719 in build in a4645 in k4628 in k4618 in a4615 in a4605 in k4590 in k4583 in k4580 in k4577 in k4574 in k4571 in k4568 in a4535 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4732,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k4648 in a4645 in k4628 in k4618 in a4615 in a4605 in k4590 in k4583 in k4580 in k4577 in k4574 in k4571 in k4568 in a4535 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4650,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4663,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   map */
t3=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[71]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k4661 in k4648 in a4645 in k4628 in k4618 in a4615 in a4605 in k4590 in k4583 in k4580 in k4577 in k4574 in k4571 in k4568 in a4535 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4663,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],t1,((C_word*)t0)[2]));}

/* a4635 in k4628 in k4618 in a4615 in a4605 in k4590 in k4583 in k4580 in k4577 in k4574 in k4571 in k4568 in a4535 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4636,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4644,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   take */
t3=C_retrieve(lf[267]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4642 in a4635 in k4628 in k4618 in a4615 in a4605 in k4590 in k4583 in k4580 in k4577 in k4574 in k4571 in k4568 in a4535 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   split-at! */
t2=C_retrieve(lf[266]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4632 in k4628 in k4618 in a4615 in a4605 in k4590 in k4583 in k4580 in k4577 in k4574 in k4571 in k4568 in a4535 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4634,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[3],t1,((C_word*)t0)[2]));}

/* k4602 in k4590 in k4583 in k4580 in k4577 in k4574 in k4571 in k4568 in a4535 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4604,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[2],t2));}

/* k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_974,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4479,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[262],t3);}

/* a4478 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4479(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr3r,(void*)f_4479r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4479r(t0,t1,t2,t3);}}

static void C_ccall f_4479r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(16);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4489,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* chicken.scm: 71   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,lf[262],t5,lf[263]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4519,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* chicken.scm: 71   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,lf[262],t5,lf[264]);}}

/* k4517 in a4478 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4519,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[261],t3));}

/* k4487 in a4478 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4489,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(0));
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=(C_word)C_a_i_cons(&a,2,lf[2],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[261],t3,t6));}

/* k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_977,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4403,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[254],t3);}

/* a4402 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4403(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4403r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4403r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4403r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4407,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   gensym */
t6=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k4405 in a4402 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4410,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4408 in k4405 in a4402 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[114],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4410,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_list(&a,3,lf[2],t3,t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t8=(C_word)C_a_i_cons(&a,2,lf[2],t7);
t9=(C_word)C_a_i_list(&a,3,lf[257],lf[258],t1);
t10=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t9);
t11=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t10);
t12=(C_word)C_a_i_list(&a,3,lf[2],t1,t11);
t13=(C_word)C_a_i_list(&a,3,lf[4],t8,t12);
t14=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t13);
t15=(C_word)C_a_i_list(&a,3,lf[259],t6,t14);
t16=(C_word)C_a_i_list(&a,3,lf[2],t2,t15);
t17=(C_word)C_a_i_list(&a,2,lf[260],t16);
t18=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_list(&a,1,t17));}

/* k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_980,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4219,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[256],t3);}

/* a4218 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4219(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4219r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4219r(t0,t1,t2,t3);}}

static void C_ccall f_4219r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4223,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   gensym */
t5=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k4221 in a4218 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4223,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4226,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4224 in k4221 in a4218 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4226,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4228,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,2,lf[61],lf[252]);
t4=(C_word)C_a_i_list(&a,3,lf[242],((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_list(&a,3,lf[253],((C_word*)t0)[5],C_fix(1));
t6=(C_word)C_a_i_list(&a,3,lf[110],t4,t5);
t7=(C_word)C_a_i_list(&a,2,t1,t6);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4365,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4369,a[2]=t9,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t11=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,t2,((C_word*)t0)[2]);}

/* k4367 in k4224 in k4221 in a4218 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4369,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[255],((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[86],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* ##sys#append */
t5=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k4363 in k4224 in k4221 in a4218 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4365,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[83],t1);
t3=(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[5],t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,4,lf[254],((C_word*)t0)[3],t3,((C_word*)t0)[2]));}

/* parse-clause in k4224 in k4221 in a4218 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4228(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[34],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4228,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_symbolp(t3);
t5=(C_truep(t4)?(C_word)C_i_car(t2):C_SCHEME_FALSE);
t6=(C_truep(t5)?(C_word)C_i_cadr(t2):(C_word)C_i_car(t2));
t7=(C_truep(t5)?(C_word)C_i_cddr(t2):(C_word)C_i_cdr(t2));
if(C_truep((C_word)C_i_nullp(t6))){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4251,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t5)){
t9=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[3]);
t10=(C_word)C_a_i_list(&a,1,t9);
t11=(C_word)C_a_i_cons(&a,2,t10,t7);
t12=t8;
f_4251(t12,(C_word)C_a_i_cons(&a,2,lf[79],t11));}
else{
t9=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t7);
t10=t8;
f_4251(t10,(C_word)C_a_i_cons(&a,2,lf[79],t9));}}
else{
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4314,a[2]=t7,a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4316,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t10=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t9,t6);}}

/* a4315 in parse-clause in k4224 in k4221 in a4218 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4316(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4316,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[251],t3,((C_word*)t0)[2]));}

/* k4312 in parse-clause in k4224 in k4221 in a4218 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4314,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[110],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4284,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[2]);
t8=t4;
f_4284(t8,(C_word)C_a_i_cons(&a,2,lf[79],t7));}
else{
t5=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t6=t4;
f_4284(t6,(C_word)C_a_i_cons(&a,2,lf[79],t5));}}

/* k4282 in k4312 in parse-clause in k4224 in k4221 in a4218 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_4284(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4284,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k4249 in parse-clause in k4224 in k4221 in a4218 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_4251(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4251,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[86],t1));}

/* k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_983,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4029,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[250],t3);}

/* a4028 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4029(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_4029r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_4029r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_4029r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t6=(C_word)C_i_cdr(t3);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4036,a[2]=t6,a[3]=t5,a[4]=t1,a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* map */
t8=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,*((C_word*)lf[76]+1),t5);}

/* k4034 in a4028 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4036,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4208,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4210,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a4209 in k4034 in a4028 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4210(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4210,3,t0,t1,t2);}
t3=(C_word)C_i_memq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:lf[249]));}

/* k4206 in k4034 in a4028 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4208,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[240],t2);
t4=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],lf[241]);
t6=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t7=(C_word)C_a_i_list(&a,3,lf[242],lf[241],t6);
t8=(C_word)C_a_i_list(&a,3,lf[82],t5,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4059,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4061,a[2]=t11,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t13=((C_word*)t11)[1];
f_4061(t13,t9,((C_word*)t0)[2],C_fix(1));}

/* loop in k4206 in k4034 in a4028 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_4061(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[112],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4061,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_memq(lf[243],C_retrieve(lf[55]));
t6=(C_word)C_i_cddr(t4);
t7=(C_word)C_i_pairp(t6);
t8=(C_word)C_a_i_list(&a,1,lf[241]);
t9=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[3]);
t10=(C_word)C_a_i_list(&a,3,lf[244],lf[241],t9);
t11=(C_word)C_a_i_list(&a,2,lf[111],t10);
t12=(C_word)C_a_i_list(&a,3,lf[245],lf[241],t3);
t13=(C_word)C_a_i_list(&a,4,lf[2],t8,t11,t12);
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4087,a[2]=t13,a[3]=t5,a[4]=t7,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,a[8]=t1,a[9]=t4,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t7)){
t15=(C_word)C_i_caddr(t4);
t16=(C_word)C_a_i_list(&a,3,t15,lf[241],lf[247]);
t17=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[3]);
t18=(C_word)C_a_i_list(&a,3,lf[244],lf[241],t17);
t19=(C_word)C_a_i_list(&a,2,lf[111],t18);
t20=(C_word)C_a_i_list(&a,4,lf[248],lf[241],t3,lf[247]);
t21=(C_word)C_a_i_list(&a,4,lf[82],t16,t19,t20);
t22=t14;
f_4087(t22,(C_word)C_a_i_list(&a,1,t21));}
else{
t15=t14;
f_4087(t15,C_SCHEME_END_OF_LIST);}}}

/* k4085 in loop in k4206 in k4034 in a4028 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_4087(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4087,NULL,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4115,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[3]:C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[9]);
t6=t3;
f_4115(t6,(C_word)C_a_i_list(&a,3,lf[246],((C_word*)t0)[2],t5));}
else{
t5=t3;
f_4115(t5,((C_word*)t0)[2]);}}

/* k4113 in k4085 in loop in k4206 in k4034 in a4028 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_4115(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4115,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4099,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* chicken.scm: 71   loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_4061(t6,t3,t4,t5);}

/* k4097 in k4113 in k4085 in loop in k4206 in k4034 in a4028 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4099,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* ##sys#append */
t3=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4057 in k4206 in k4034 in a4028 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4059,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[68],t3));}

/* k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_986,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4020,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[238],t3);}

/* a4019 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4020(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4020,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4024,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[238],t2,lf[239]);}

/* k4022 in a4019 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4024,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[237],((C_word*)t0)[2]));}

/* k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_989,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4001,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[235],t3);}

/* a4000 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4001(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4001,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4005,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[235],t2,lf[236]);}

/* k4003 in a4000 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4012,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4014,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4013 in k4003 in a4000 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4014(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4014,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k4010 in k4003 in a4000 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_4012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4012,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[232],t1));}

/* k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_992,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3982,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[233],t3);}

/* a3981 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3982(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3982,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3986,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[233],t2,lf[234]);}

/* k3984 in a3981 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3993,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3995,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3994 in k3984 in a3981 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3995(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3995,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3991 in k3984 in a3981 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3993,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[232],t1));}

/* k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_995,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3854,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[231],t3);}

/* a3853 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3854(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3854,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3860,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3860(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in a3853 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_3860(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(15);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3860,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3870,a[2]=t4,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   reverse */
t7=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t3);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[228]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3941,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   gensym */
t9=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t9))(2,t9,t8);}
else{
t8=(C_word)C_eqp(t6,lf[229]);
if(C_truep(t8)){
/* chicken.scm: 71   loop */
t15=t1;
t16=C_SCHEME_END_OF_LIST;
t17=t3;
t18=t4;
t19=C_SCHEME_TRUE;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
t5=t19;
goto loop;}
else{
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_car(t2);
t11=(C_word)C_a_i_cons(&a,2,t10,t4);
/* chicken.scm: 71   loop */
t15=t1;
t16=t9;
t17=t3;
t18=t11;
t19=C_SCHEME_FALSE;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
t5=t19;
goto loop;}}}}

/* k3939 in loop in a3853 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3941,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* chicken.scm: 71   loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3860(t5,((C_word*)t0)[2],t2,t3,t4,C_SCHEME_FALSE);}

/* k3868 in loop in a3853 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3873,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   reverse */
t3=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3871 in k3868 in loop in a3853 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3873,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_a_i_list(&a,2,lf[68],t2);
t4=(C_word)C_i_cdr(t1);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[2],t5));}}

/* k3877 in k3871 in k3868 in loop in a3853 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3886,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k3884 in k3877 in k3871 in k3868 in loop in a3853 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3886,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3902,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* ##sys#append */
t6=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k3900 in k3884 in k3877 in k3871 in k3868 in loop in a3853 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3902,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[227],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[2],t3));}

/* k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_998,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3711,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[230],t3);}

/* a3710 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3711(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3711,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3717,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3717(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in a3710 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_3717(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(22);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3717,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t2))){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3727,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   reverse */
t8=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_eqp(t7,lf[228]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3802,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   gensym */
t10=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t10))(2,t10,t9);}
else{
t9=(C_word)C_eqp(t7,lf[229]);
if(C_truep(t9)){
/* chicken.scm: 71   loop */
t14=t1;
t15=C_SCHEME_END_OF_LIST;
t16=t3;
t17=t4;
t18=t5;
t19=C_SCHEME_TRUE;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
t5=t18;
t6=t19;
goto loop;}
else{
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3829,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t4,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   gensym */
t11=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t11))(2,t11,t10);}}}}

/* k3827 in loop in a3710 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3829,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
t6=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* chicken.scm: 71   loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_3717(t7,((C_word*)t0)[3],t2,((C_word*)t0)[2],t5,t6,C_SCHEME_FALSE);}

/* k3800 in loop in a3710 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3802,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* chicken.scm: 71   loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3717(t5,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2],t4,C_SCHEME_FALSE);}

/* k3725 in loop in a3710 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3730,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   reverse */
t3=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3728 in k3725 in loop in a3710 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3730,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3736,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[2],t4);
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[3],t5));}}

/* k3734 in k3728 in k3725 in loop in a3710 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3747,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k3745 in k3734 in k3728 in k3725 in loop in a3710 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3747,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3763,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* ##sys#append */
t6=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k3761 in k3745 in k3734 in k3728 in k3725 in loop in a3710 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3763,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[227],t2);
t4=(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t4));}

/* k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_998,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1001,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3652,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[226],t3);}

/* a3651 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3652(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc_2(c,6,t0);
if(!C_demand(c*C_SIZEOF_PAIR+51)){
C_save_and_reclaim((void*)tr6r,(void*)f_3652r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_3652r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_3652r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(51);
t7=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_i_caddr(t2);
t9=(C_word)C_i_car(t2);
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_a_i_list(&a,3,t8,t9,t10);
t12=(C_word)C_a_i_list(&a,4,lf[223],t3,t4,t5);
t13=(C_word)C_a_i_cons(&a,2,t12,t6);
t14=(C_word)C_a_i_cons(&a,2,t11,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[224],t14));}
else{
t8=(C_word)C_a_i_list(&a,4,lf[225],t3,t4,t5);
t9=(C_word)C_a_i_cons(&a,2,t8,t6);
t10=(C_word)C_a_i_cons(&a,2,t2,t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[224],t10));}}

/* k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1004,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3481,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[220],t3);}

/* a3480 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3481(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_3481r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3481r(t0,t1,t2,t3);}}

static void C_ccall f_3481r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3487,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3487(t7,t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t3,C_SCHEME_FALSE);}

/* loop in a3480 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_3487(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3487,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t4))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3497,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=(C_word)C_a_i_cons(&a,2,lf[215],t5);
t8=t6;
f_3497(t8,(C_word)C_a_i_list(&a,2,lf[133],t7));}
else{
t7=t6;
f_3497(t7,lf[216]);}}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3561,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_i_car(t4);
t8=t6;
f_3561(t8,(C_word)C_i_pairp(t7));}
else{
t7=t6;
f_3561(t7,C_SCHEME_FALSE);}}}

/* k3559 in loop in a3480 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_3561(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3561,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3564,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   caar */
t3=*((C_word*)lf[152]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
/* chicken.scm: 71   syntax-error */
t2=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[220],lf[222],((C_word*)t0)[7]);}}

/* k3562 in k3559 in loop in a3480 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3564,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_eqp(lf[217],t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3588,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   cdar */
t5=*((C_word*)lf[218]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(lf[219],t1);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3609,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   cdar */
t6=*((C_word*)lf[218]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(lf[215],t1);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3622,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=((C_word*)t0)[2];
t8=(C_truep(t7)?t7:C_SCHEME_END_OF_LIST);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3630,a[2]=t8,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   cdar */
t10=*((C_word*)lf[218]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[7]);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3637,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   caar */
t7=*((C_word*)lf[152]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[7]);}}}}

/* k3635 in k3562 in k3559 in loop in a3480 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   syntax-error */
t2=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[220],lf[221],t1);}

/* k3628 in k3562 in k3559 in loop in a3480 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   append */
t2=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3620 in k3562 in k3559 in loop in a3480 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   loop */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3487(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3607 in k3562 in k3559 in loop in a3480 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3609,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[68],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* chicken.scm: 71   loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3487(t4,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3586 in k3562 in k3559 in loop in a3480 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3588,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[68],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* chicken.scm: 71   loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3487(t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3495 in loop in a3480 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_3497(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[63],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3497,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,lf[210],t2);
t4=(C_word)C_a_i_list(&a,2,lf[211],lf[54]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,lf[212],((C_word*)t0)[4]);
t7=(C_word)C_a_i_list(&a,2,lf[133],t6);
t8=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t9=(C_word)C_a_i_list(&a,2,lf[213],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)t0)[3]);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,t7,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[86],t12);
t14=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,4,lf[214],t3,t5,t13));}

/* k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1007,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3430,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[209],t3);}

/* a3429 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3430(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+39)){
C_save_and_reclaim((void*)tr3r,(void*)f_3430r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3430r(t0,t1,t2,t3);}}

static void C_ccall f_3430r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(39);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,t5,t3);
t7=(C_word)C_a_i_cons(&a,2,lf[2],t6);
t8=(C_word)C_a_i_list(&a,2,t4,t7);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(C_word)C_i_car(t2);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,3,lf[208],t9,t10));}
else{
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[208],t5,t2));}}

/* k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1010,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3370,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[206],t3);}

/* a3369 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3370(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_3370r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3370r(t0,t1,t2,t3);}}

static void C_ccall f_3370r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[203]:t3);
t6=(C_word)C_i_pairp(t2);
t7=(C_truep(t6)?(C_word)C_i_car(t2):t2);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3380,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,t5);
t11=t8;
f_3380(t11,(C_word)C_a_i_cons(&a,2,lf[2],t10));}
else{
t9=t8;
f_3380(t9,(C_word)C_i_car(t5));}}

/* k3378 in a3369 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_3380(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3380,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3383,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3399,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   eval */
t4=C_retrieve(lf[147]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}
else{
/* chicken.scm: 71   syntax-error */
t3=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[206],lf[207],((C_word*)t0)[2]);}}

/* k3397 in k3378 in a3369 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3383(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* k3381 in k3378 in a3369 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3383,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[204]))?(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[3],((C_word*)t0)[2]):lf[205]));}

/* k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1013,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   register-feature! */
t3=C_retrieve(lf[196]);
((C_proc8)C_retrieve_proc(t3))(8,t3,t2,lf[197],lf[198],lf[199],lf[200],lf[201],lf[202]);}

/* k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1016,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3333,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[84],t3);}

/* a3332 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3333(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3333,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3337,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[84],t2,lf[195]);}

/* k3335 in a3332 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3337,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,2,lf[61],t4);
t6=(C_word)C_i_cddr(((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,t3,t7);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[194],t8));}

/* k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1019,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3314,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[90],t3);}

/* a3313 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3314(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3314,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3318,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[90],t2,lf[193]);}

/* k3316 in a3313 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3325,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3327,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3326 in k3316 in a3313 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3327(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3327,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3323 in k3316 in a3313 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3325,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[164],t1));}

/* k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1022,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3295,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[191],t3);}

/* a3294 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3295(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3295,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3299,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[191],t2,lf[192]);}

/* k3297 in a3294 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3306,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3308,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3307 in k3297 in a3294 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3308(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3308,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3304 in k3297 in a3294 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3306,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[190],t1));}

/* k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1025,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3276,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[107],t3);}

/* a3275 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3276(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3276,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3280,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[107],t2,lf[189]);}

/* k3278 in a3275 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3287,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3289,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3288 in k3278 in a3275 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3289(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3289,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3285 in k3278 in a3275 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3287,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[188],t1));}

/* k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1028,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3257,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[186],t3);}

/* a3256 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3257(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3257,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3261,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[186],t2,lf[187]);}

/* k3259 in a3256 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3268,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3270,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3269 in k3259 in a3256 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3270(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3270,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3266 in k3259 in a3256 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3268,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[185],t1));}

/* k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1031,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3238,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[183],t3);}

/* a3237 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3238(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3238,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3242,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[183],t2,lf[184]);}

/* k3240 in a3237 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3249,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3251,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3250 in k3240 in a3237 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3251(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3251,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3247 in k3240 in a3237 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3249,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[182],t1));}

/* k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1034,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3219,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[180],t3);}

/* a3218 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3219(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3219,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3223,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[180],t2,lf[181]);}

/* k3221 in a3218 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3223,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3230,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3232,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3231 in k3221 in a3218 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3232(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3232,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3228 in k3221 in a3218 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3230,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[179],t1));}

/* k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1037,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3119,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[174],t3);}

/* a3118 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3119(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3119,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3123,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[174],t2,lf[178]);}

/* k3121 in a3118 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3123,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_stringp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3132,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[174],((C_word*)t0)[3],lf[175]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3178,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[174],((C_word*)t0)[3],lf[177]);}}

/* k3176 in k3121 in a3118 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3178,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_a_i_list(&a,2,lf[61],lf[176]);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(C_word)C_a_i_list(&a,2,lf[61],t5);
t7=(C_word)C_i_caddr(((C_word*)t0)[3]);
t8=(C_word)C_a_i_list(&a,2,lf[61],t7);
t9=(C_word)C_i_cadddr(((C_word*)t0)[3]);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,6,lf[171],t3,t4,t6,t8,t9));}

/* k3130 in k3121 in a3118 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3132,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_i_caddr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,2,lf[61],t4);
t6=(C_word)C_i_car(((C_word*)t0)[3]);
t7=(C_word)C_a_i_list(&a,2,lf[61],t6);
t8=(C_word)C_i_cadddr(((C_word*)t0)[3]);
t9=(C_word)C_a_i_list(&a,2,lf[61],t8);
t10=(C_word)C_i_cdr(((C_word*)t0)[3]);
t11=(C_word)C_i_cadddr(t10);
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_list(&a,6,lf[171],t3,t5,t7,t9,t11));}

/* k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1040,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2899,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[168],t3);}

/* a2898 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2899(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2899,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2903,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=t3;
f_2903(t5,(C_word)C_i_stringp(t4));}
else{
t4=t3;
f_2903(t4,C_SCHEME_FALSE);}}

/* k2901 in a2898 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_2903(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2903,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2906,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=t1;
if(C_truep(t3)){
t4=t2;
f_2906(t4,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=t2;
f_2906(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t2;
f_2906(t4,C_SCHEME_FALSE);}}}

/* k2904 in k2901 in a2898 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_2906(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2906,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2912,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[168],((C_word*)t0)[4],lf[169]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2987,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* chicken.scm: 72   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[168],((C_word*)t0)[4],lf[172]);}
else{
/* chicken.scm: 72   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[168],((C_word*)t0)[4],lf[173]);}}}

/* k2985 in k2904 in k2901 in a2898 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2987,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cadr(((C_word*)t0)[3]):(C_word)C_i_car(((C_word*)t0)[3]));
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_list(&a,2,lf[61],t5);
t7=(C_truep(((C_word*)t0)[4])?(C_word)C_i_car(((C_word*)t0)[3]):lf[170]);
t8=(C_word)C_a_i_list(&a,2,lf[61],t7);
t9=(C_truep(((C_word*)t0)[4])?(C_word)C_i_caddr(((C_word*)t0)[3]):(C_word)C_i_cadr(((C_word*)t0)[3]));
t10=(C_word)C_a_i_list(&a,2,lf[61],t9);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3052,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t10,a[6]=t8,a[7]=t6,a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[4],tmp=(C_word)a,a+=10,tmp);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3054,tmp=(C_word)a,a+=2,tmp);
/* map */
t13=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,t12,t3);}

/* a3053 in k2985 in k2904 in k2901 in a2898 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3054(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3054,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k3050 in k2985 in k2904 in k2901 in a2898 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3052,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3032,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3044,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a3043 in k3050 in k2985 in k2904 in k2901 in a2898 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3044(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3044,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k3030 in k3050 in k2985 in k2904 in k2901 in a2898 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_3032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3032,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[9])?(C_word)C_i_cdddr(((C_word*)t0)[8]):(C_word)C_i_cddr(((C_word*)t0)[8]));
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[2],t3);
t5=(C_word)C_a_i_list(&a,6,lf[171],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[2],t5));}

/* k2910 in k2904 in k2901 in a2898 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[68],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2912,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,2,lf[61],t4);
t6=(C_word)C_a_i_list(&a,3,lf[164],t3,t5);
t7=(C_word)C_a_i_list(&a,2,lf[61],t2);
t8=(C_word)C_i_cadr(((C_word*)t0)[3]);
t9=(C_word)C_a_i_list(&a,2,lf[61],t8);
t10=(C_word)C_a_i_list(&a,2,lf[61],C_SCHEME_TRUE);
t11=(C_word)C_a_i_list(&a,4,lf[165],t7,t9,t10);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2938,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
t13=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t13))){
t14=(C_word)C_i_caddr(((C_word*)t0)[3]);
t15=(C_word)C_a_i_list(&a,3,lf[5],t2,t14);
t16=t12;
f_2938(t16,(C_word)C_a_i_list(&a,1,t15));}
else{
t14=t12;
f_2938(t14,C_SCHEME_END_OF_LIST);}}

/* k2936 in k2910 in k2904 in k2901 in a2898 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_2938(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2938,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[68],t3));}

/* k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1043,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2824,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[167],t3);}

/* a2823 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2824(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2824r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2824r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2824r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2828,a[2]=t4,a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 72   gensym */
t6=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k2826 in a2823 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2828,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* chicken.scm: 72   symbol->string */
t5=*((C_word*)lf[166]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}

/* k2895 in k2826 in a2823 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[74],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2897,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],t1);
t3=(C_word)C_a_i_list(&a,4,lf[164],((C_word*)t0)[8],((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,lf[61],C_SCHEME_FALSE);
t7=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t8=(C_word)C_a_i_list(&a,5,lf[165],t4,t5,t6,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2851,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[2]))){
t10=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t11=(C_word)C_a_i_list(&a,3,lf[5],((C_word*)t0)[6],t10);
t12=t9;
f_2851(t12,(C_word)C_a_i_list(&a,1,t11));}
else{
t10=t9;
f_2851(t10,C_SCHEME_END_OF_LIST);}}

/* k2849 in k2895 in k2826 in a2823 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_2851(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2851,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[68],t3));}

/* k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1046,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2718,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[163],t3);}

/* a2717 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2718(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_2718r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2718r(t0,t1,t2,t3);}}

static void C_ccall f_2718r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2722,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2818,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a2817 in a2717 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2818(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2818,3,t0,t1,t2);}
/* chicken.scm: 72   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k2720 in a2717 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2722,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2729,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2794,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   append-map */
t4=C_retrieve(lf[162]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],t1);}

/* a2793 in k2720 in a2717 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2794(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2794,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cddr(t2);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}}

/* k2727 in k2720 in a2717 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2733,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2735,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t5=(C_word)C_a_i_cons(&a,2,lf[79],t4);
/* chicken.scm: 72   fold-right */
t6=C_retrieve(lf[161]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t2,t3,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2734 in k2727 in k2720 in a2717 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2735(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[51],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2735,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t2);
t6=(C_word)C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_a_i_list(&a,2,lf[61],t7);
t9=(C_word)C_i_cadr(t2);
t10=(C_word)C_a_i_list(&a,2,lf[61],t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,5,lf[160],t8,t10,t3,t4));}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_a_i_list(&a,2,lf[61],t7);
t9=(C_word)C_i_cadr(t2);
t10=(C_word)C_a_i_list(&a,2,lf[61],t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[160],t8,t10,t4));}}

/* k2731 in k2727 in k2720 in a2717 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2733,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1049,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2689,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[159],t3);}

/* a2688 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2689(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2689,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2693,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   gensym */
t4=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[155]);}

/* k2691 in a2688 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2693,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2712,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2716,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   string-intersperse */
t4=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[158]);}

/* k2714 in k2691 in a2688 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   sprintf */
t2=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[157],((C_word*)t0)[2],t1);}

/* k2710 in k2691 in a2688 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2712,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[98],t1);
t3=(C_word)C_a_i_list(&a,2,lf[133],t2);
t4=(C_word)C_a_i_list(&a,2,lf[130],((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[68],t3,t4));}

/* k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1052,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2676,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[156],t3);}

/* a2675 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2676(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2676,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2680,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 72   gensym */
t5=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[155]);}

/* k2678 in a2675 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2680,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[90],t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[68],t2,t1));}

/* k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1055,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1882,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[112],t3);}

/* a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1882(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_1882r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1882r(t0,t1,t2,t3);}}

static void C_ccall f_1882r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1886,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cadr(t2);
/* chicken.scm: 72   ->string */
t7=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
/* chicken.scm: 72   sprintf */
t6=C_retrieve(lf[62]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[154],t2);}}

/* k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1886,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[4]):((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1892,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 72   gensym */
t5=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1892,2,t0,t1);}
t2=*((C_word*)lf[101]+1);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=t1,a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
/* chicken.scm: 72   gensym */
t9=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t9))(2,t9,t8);}

/* k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1898,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken.scm: 72   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* chicken.scm: 72   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1901,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1903,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t7=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1946,a[2]=t5,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1989,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=t5,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t1,a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[11],tmp=(C_word)a,a+=16,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2568,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=t10,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_2568(t12,t8,((C_word*)((C_word*)t0)[6])[1]);}

/* do539 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_2568(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2568,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2578,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_2578(t5,t3);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_pairp(t5);
t7=(C_word)C_i_not(t6);
if(C_truep(t7)){
t8=t4;
f_2578(t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2643,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2647,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 72   caar */
t10=*((C_word*)lf[152]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t2);}}}

/* k2645 in do539 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   keyword? */
t2=C_retrieve(lf[153]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2641 in do539 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2578(t2,(C_word)C_i_not(t1));}

/* k2576 in do539 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_2578(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2578,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2582,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 72   caar */
t3=*((C_word*)lf[152]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}}

/* k2580 in k2576 in do539 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2585,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[146]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2599,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2603,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 72   cadar */
t6=*((C_word*)lf[148]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(t1,lf[149]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2613,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   cadar */
t6=*((C_word*)lf[148]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(t1,lf[150]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2623,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   cadar */
t7=*((C_word*)lf[148]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[7]);}
else{
t6=(C_word)C_i_car(((C_word*)t0)[7]);
/* chicken.scm: 72   syntax-error */
t7=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t2,lf[112],lf[151],t6);}}}}

/* k2621 in k2580 in k2576 in do539 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2585(2,t3,t2);}

/* k2611 in k2580 in k2576 in do539 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2585(2,t3,t2);}

/* k2601 in k2580 in k2576 in do539 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   eval */
t2=C_retrieve(lf[147]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2597 in k2580 in k2576 in do539 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2585(2,t3,t2);}

/* k2583 in k2580 in k2576 in do539 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2568(t3,((C_word*)t0)[2],t2);}

/* k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1992,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t3=(C_word)C_a_i_list(&a,2,lf[104],((C_word*)t0)[3]);
/* chicken.scm: 72   ##sys#hash-table-set! */
t4=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[145]),((C_word*)t0)[14],t3);}

/* k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1999,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2003,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=t2,tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=t3;
f_2003(t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2475,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2479,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2491,a[2]=((C_word*)t0)[6],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2562,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 72   ->string */
t8=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[2]);}}

/* k2560 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string-append */
t2=*((C_word*)lf[141]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[142],t1,lf[143]);}

/* k2489 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2495,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2497,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a2496 in k2489 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2497(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2497,3,t0,t1,t2);}
t3=(C_word)C_i_length(t2);
switch(t3){
case C_fix(3):
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2514,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2526,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cadr(t2);
/* chicken.scm: 72   ->string */
t8=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);
case C_fix(2):
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2543,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2551,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cadr(t2);
/* chicken.scm: 72   ->string */
t8=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);
default:
/* chicken.scm: 72   syntax-error */
t4=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[112],lf[140],t2);}}

/* k2549 in a2496 in k2489 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   ##compiler#foreign-type-declaration */
t2=C_retrieve(lf[138]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2541 in a2496 in k2489 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   sprintf */
t2=C_retrieve(lf[62]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[139],t1);}

/* k2524 in a2496 in k2489 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   ##compiler#foreign-type-declaration */
t2=C_retrieve(lf[138]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2512 in a2496 in k2489 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_caddr(((C_word*)t0)[3]);
/* chicken.scm: 72   sprintf */
t3=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[137],t1,t2);}

/* k2493 in k2489 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2495,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_list(&a,1,lf[136]);
/* chicken.scm: 72   append */
t4=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t2,t3);}

/* k2477 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string-intersperse */
t2=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[135]);}

/* k2473 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2475,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[98],t1);
t3=(C_word)C_a_i_list(&a,2,lf[133],t2);
t4=((C_word*)t0)[2];
f_2003(t4,(C_word)C_a_i_list(&a,1,t3));}

/* k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_2003(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2003,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2007,a[2]=t1,a[3]=((C_word*)t0)[14],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2011,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2457,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 72   sprintf */
t6=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[132],((C_word*)t0)[2],((C_word*)t0)[2]);}
else{
t5=t3;
f_2011(t5,C_SCHEME_END_OF_LIST);}}

/* k2455 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2457,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[107],((C_word*)t0)[4],C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)((C_word*)t0)[3])[1],t2);
t4=((C_word*)t0)[2];
f_2011(t4,(C_word)C_a_i_list(&a,1,t3));}

/* k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_2011(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2011,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2015,a[2]=t1,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2019,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
t4=((C_word*)((C_word*)t0)[2])[1];
if(C_truep(t4)){
t5=(C_word)C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],lf[129]);
t6=(C_word)C_a_i_list(&a,3,lf[130],lf[131],lf[129]);
t7=(C_word)C_a_i_list(&a,3,lf[110],lf[129],t6);
t8=(C_word)C_a_i_list(&a,3,lf[82],t5,t7);
t9=t3;
f_2019(t9,(C_word)C_a_i_list(&a,1,t8));}
else{
t5=t3;
f_2019(t5,C_SCHEME_END_OF_LIST);}}

/* k2017 in k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_2019(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2019,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2023,a[2]=t1,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2025,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a2024 in k2017 in k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2025(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2025,3,t0,t1,t2);}
t3=(C_word)C_i_length(t2);
switch(t3){
case C_fix(3):
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_caddr(t2);
t7=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2047,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t1,a[8]=t6,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* chicken.scm: 72   stype */
t8=((C_word*)((C_word*)t0)[2])[1];
f_1903(t8,t7,t4);
case C_fix(2):
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cadr(t2);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2302,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* chicken.scm: 72   stype */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1903(t7,t6,t4);
default:
/* chicken.scm: 72   syntax-error */
t4=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[112],lf[128],t2);}}

/* k2300 in a2024 in k2017 in k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2379,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2410,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2414,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   sprintf */
t5=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[127],((C_word*)t0)[9],((C_word*)t0)[4]);}

/* k2412 in k2300 in a2024 in k2017 in k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   renamer */
t2=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2408 in k2300 in a2024 in k2017 in k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2377 in k2300 in a2024 in k2017 in k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2379,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2391,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=t3,a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2402,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 72   strtype */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1946(t6,t5,((C_word*)t0)[6]);}

/* k2400 in k2377 in k2300 in a2024 in k2017 in k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[124]:lf[125]);
/* chicken.scm: 72   sprintf */
t3=C_retrieve(lf[62]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],lf[126],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2389 in k2377 in k2300 in a2024 in k2017 in k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2391,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[107],((C_word*)t0)[11],((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[9],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2317,a[2]=((C_word*)t0)[8],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2320,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[7],a[9]=t4,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t6=(C_word)C_i_car(((C_word*)t0)[7]);
t7=t5;
f_2320(t7,(C_word)C_eqp(lf[102],t6));}
else{
t6=t5;
f_2320(t6,C_SCHEME_FALSE);}}

/* k2318 in k2389 in k2377 in k2300 in a2024 in k2017 in k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_2320(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2320,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
f_2317(t2,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[8],((C_word*)t0)[7]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2337,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2361,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2365,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   sprintf */
t6=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[123],((C_word*)t0)[6],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[9];
f_2317(t3,C_SCHEME_END_OF_LIST);}}}

/* k2363 in k2318 in k2389 in k2377 in k2300 in a2024 in k2017 in k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   renamer */
t2=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2359 in k2318 in k2389 in k2377 in k2300 in a2024 in k2017 in k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2335 in k2318 in k2389 in k2377 in k2300 in a2024 in k2017 in k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2337,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2349,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 72   sprintf */
t6=C_retrieve(lf[62]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,lf[122],((C_word*)t0)[6],((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k2347 in k2335 in k2318 in k2389 in k2377 in k2300 in a2024 in k2017 in k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2349,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[107],lf[114],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_2317(t4,(C_word)C_a_i_list(&a,1,t3));}

/* k2315 in k2389 in k2377 in k2300 in a2024 in k2017 in k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_2317(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2317,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[68],t2));}

/* k2045 in a2024 in k2017 in k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2188,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2283,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2287,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   sprintf */
t5=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[121],((C_word*)t0)[12],((C_word*)t0)[4]);}

/* k2285 in k2045 in a2024 in k2017 in k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   renamer */
t2=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2281 in k2045 in a2024 in k2017 in k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2186 in k2045 in a2024 in k2017 in k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2188,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[13],((C_word*)t0)[12]);
t3=(C_word)C_a_i_list(&a,2,lf[106],((C_word*)t0)[11]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2260,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[9],a[13]=t4,a[14]=((C_word*)t0)[10],tmp=(C_word)a,a+=15,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2271,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[12],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 72   strtype */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1946(t7,t6,((C_word*)t0)[6]);}

/* k2269 in k2186 in k2045 in a2024 in k2017 in k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[118]:lf[119]);
/* chicken.scm: 72   sprintf */
t3=C_retrieve(lf[62]);
((C_proc7)C_retrieve_proc(t3))(7,t3,((C_word*)t0)[5],lf[120],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2258 in k2186 in k2045 in a2024 in k2017 in k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[161],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2260,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[107],((C_word*)t0)[14],((C_word*)t0)[13],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[12],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[11],((C_word*)t0)[10]);
t6=(C_word)C_a_i_list(&a,3,lf[108],((C_word*)t0)[10],C_fix(0));
t7=(C_word)C_a_i_list(&a,3,lf[109],((C_word*)t0)[10],((C_word*)t0)[9]);
t8=(C_word)C_a_i_list(&a,3,lf[110],t6,t7);
t9=(C_word)C_a_i_list(&a,2,lf[111],t8);
t10=(C_word)C_a_i_list(&a,3,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10]);
t11=(C_word)C_a_i_list(&a,2,lf[61],lf[112]);
t12=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[8]);
t13=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[10]);
t14=(C_word)C_a_i_list(&a,6,lf[50],t11,lf[113],t12,t13,((C_word*)t0)[9]);
t15=(C_word)C_a_i_list(&a,4,lf[72],t9,t10,t14);
t16=(C_word)C_a_i_list(&a,3,lf[2],t5,t15);
t17=(C_word)C_a_i_list(&a,3,lf[79],t4,t16);
t18=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[7],t17);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2062,a[2]=((C_word*)t0)[6],a[3]=t18,tmp=(C_word)a,a+=4,tmp);
t20=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2065,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[5],a[12]=t19,tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t21=(C_word)C_i_car(((C_word*)t0)[5]);
t22=t20;
f_2065(t22,(C_word)C_eqp(lf[102],t21));}
else{
t21=t20;
f_2065(t21,C_SCHEME_FALSE);}}

/* k2063 in k2258 in k2186 in k2045 in a2024 in k2017 in k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_2065(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2065,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[12];
f_2062(t2,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[11],((C_word*)t0)[10]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2082,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2170,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2174,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   sprintf */
t6=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[117],((C_word*)t0)[9],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[12];
f_2062(t3,C_SCHEME_END_OF_LIST);}}}

/* k2172 in k2063 in k2258 in k2186 in k2045 in a2024 in k2017 in k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   renamer */
t2=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2168 in k2063 in k2258 in k2186 in k2045 in a2024 in k2017 in k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2080 in k2063 in k2258 in k2186 in k2045 in a2024 in k2017 in k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2082,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(C_word)C_a_i_list(&a,2,lf[106],((C_word*)t0)[8]);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,3,t2,t3,t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2154,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[5],a[10]=t5,tmp=(C_word)a,a+=11,tmp);
/* chicken.scm: 72   sprintf */
t7=C_retrieve(lf[62]);
((C_proc7)C_retrieve_proc(t7))(7,t7,t6,lf[116],((C_word*)t0)[9],((C_word*)t0)[2],((C_word*)t0)[8],((C_word*)t0)[6]);}

/* k2152 in k2080 in k2063 in k2258 in k2186 in k2045 in a2024 in k2017 in k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[153],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2154,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[107],lf[114],((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_a_i_list(&a,3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t6=(C_word)C_a_i_list(&a,3,lf[108],((C_word*)t0)[7],C_fix(0));
t7=(C_word)C_a_i_list(&a,3,lf[109],((C_word*)t0)[7],((C_word*)t0)[5]);
t8=(C_word)C_a_i_list(&a,3,lf[110],t6,t7);
t9=(C_word)C_a_i_list(&a,2,lf[111],t8);
t10=(C_word)C_a_i_list(&a,4,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t11=(C_word)C_a_i_list(&a,2,lf[61],lf[112]);
t12=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t13=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[7]);
t14=(C_word)C_a_i_list(&a,6,lf[50],t11,lf[115],t12,t13,((C_word*)t0)[5]);
t15=(C_word)C_a_i_list(&a,4,lf[72],t9,t10,t14);
t16=(C_word)C_a_i_list(&a,3,lf[2],t5,t15);
t17=(C_word)C_a_i_list(&a,3,lf[79],t4,t16);
t18=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[3],t17);
t19=((C_word*)t0)[2];
f_2062(t19,(C_word)C_a_i_list(&a,1,t18));}

/* k2060 in k2258 in k2186 in k2045 in a2024 in k2017 in k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_2062(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2062,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[68],t2));}

/* k2021 in k2017 in k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2013 in k2009 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2005 in k2001 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_2007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1997 in k1990 in k1987 in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1999,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[68],t1));}

/* strtype in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_1946(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1946,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1962,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(lf[102],t5);
if(C_truep(t6)){
t7=(C_word)C_i_cadr(t2);
/* chicken.scm: 72   strtype */
t9=t4;
t10=t7;
t1=t9;
t2=t10;
goto loop;}
else{
t7=t4;
f_1962(2,t7,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* k1960 in strtype in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_memq(t2,lf[105]));}}

/* stype in k1899 in k1896 in k1893 in k1890 in k1884 in a1881 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_1903(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1903,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(lf[102],t3);
if(C_truep(t4)){
t5=(C_word)C_i_cadr(t2);
/* chicken.scm: 72   stype */
t9=t1;
t10=t5;
t1=t9;
t2=t10;
goto loop;}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_memq(t5,lf[103]);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?(C_word)C_a_i_list(&a,2,lf[104],t2):t2));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1058,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1868,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[98],t3);}

/* a1867 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1868(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1868,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,lf[98],t2);
t4=(C_word)C_a_i_list(&a,2,lf[61],t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,lf[99],t4));}

/* k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1061,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1528,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[95],t3);}

/* a1527 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1528(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_1528r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1528r(t0,t1,t2,t3);}}

static void C_ccall f_1528r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(7);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1532,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t4)[1]))){
t6=(C_word)C_i_car(((C_word*)t4)[1]);
if(C_truep((C_word)C_booleanp(t6))){
t7=(C_word)C_i_cdr(((C_word*)t4)[1]);
t8=C_set_block_item(t4,0,t7);
t9=t5;
f_1532(t9,t6);}
else{
t7=t5;
f_1532(t7,C_SCHEME_TRUE);}}
else{
t6=t5;
f_1532(t6,C_SCHEME_TRUE);}}

/* k1530 in a1527 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_1532(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1532,NULL,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1535,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 72   ->string */
t5=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}

/* k1533 in k1530 in a1527 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1535,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=lf[67];
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1840,tmp=(C_word)a,a+=2,tmp);
/* map */
t8=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)((C_word*)t0)[2])[1]);}

/* a1839 in k1533 in k1530 in a1527 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1840(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1840,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_car(t2):t2));}

/* k1536 in k1533 in k1530 in a1527 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1541,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1815,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a1814 in k1536 in k1533 in k1530 in a1527 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1815(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1815,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cadr(t2));}
else{
/* chicken.scm: 72   syntax-error */
t4=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[95],lf[97],t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1539 in k1536 in k1533 in k1530 in a1527 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1544,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1783,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a1782 in k1539 in k1536 in k1533 in k1530 in a1527 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1783(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1783,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_caddr(t2));}
else{
t4=(C_word)C_i_car(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,lf[61],t4));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}}

/* k1542 in k1539 in k1536 in k1533 in k1530 in a1527 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1547,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[2]))){
t3=(C_word)C_i_length(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1757,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_and((C_word)C_fixnum_less_or_equal_p(C_fix(2),t3),(C_word)C_fixnum_less_or_equal_p(t3,C_fix(3))))){
t5=t4;
f_1757(2,t5,C_SCHEME_UNDEFINED);}
else{
/* chicken.scm: 72   syntax-error */
t5=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[95],lf[96],((C_word*)t0)[2]);}}
else{
t3=t2;
f_1547(t3,C_SCHEME_UNDEFINED);}}

/* k1755 in k1542 in k1539 in k1536 in k1533 in k1530 in a1527 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[7]);
t5=C_mutate(((C_word *)((C_word*)t0)[5])+1,t4);
t6=(C_word)C_eqp(C_fix(3),((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(C_word)C_i_caddr(((C_word*)t0)[7]);
t8=C_mutate(((C_word *)((C_word*)t0)[3])+1,t7);
t9=((C_word*)t0)[2];
f_1547(t9,t8);}
else{
t7=((C_word*)t0)[2];
f_1547(t7,C_SCHEME_UNDEFINED);}}

/* k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in a1527 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_1547(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1547,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1550,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[2])){
/* map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[6]),((C_word*)t0)[4]);}
else{
t3=t2;
f_1550(2,t3,((C_word*)t0)[4]);}}

/* k1548 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in a1527 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1553,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1745,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 72   conc */
t4=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[7])[1],lf[93]);}

/* k1743 in k1548 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in a1527 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1551 in k1548 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in a1527 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1556,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1741,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 72   conc */
t4=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[92],((C_word*)((C_word*)t0)[8])[1]);}

/* k1739 in k1551 in k1548 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in a1527 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1554 in k1551 in k1548 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in a1527 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1563,a[2]=((C_word*)t0)[10],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1567,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1729,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 72   map */
t5=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* a1728 in k1554 in k1551 in k1548 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in a1527 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1729(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1729,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1737,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 72   ->string */
t5=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k1735 in a1728 in k1554 in k1551 in k1548 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in a1527 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1737,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[90],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1));}

/* k1565 in k1554 in k1551 in k1548 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in a1527 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[97],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1567,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[10],lf[69]);
t3=(C_word)C_a_i_list(&a,2,lf[70],lf[69]);
t4=(C_word)C_a_i_list(&a,2,lf[71],lf[69]);
t5=(C_word)C_a_i_list(&a,4,lf[72],t3,t4,lf[69]);
t6=(C_word)C_a_i_list(&a,2,lf[69],t5);
t7=(C_word)C_a_i_list(&a,2,lf[73],C_fix(0));
t8=(C_word)C_a_i_list(&a,2,t6,t7);
t9=(C_word)C_a_i_list(&a,2,lf[74],lf[69]);
t10=(C_word)C_a_i_list(&a,2,lf[75],lf[69]);
t11=(C_word)C_a_i_list(&a,2,lf[76],lf[69]);
t12=(C_word)C_a_i_list(&a,2,lf[77],t11);
t13=(C_word)C_a_i_list(&a,1,t12);
t14=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1669,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t2,a[12]=t8,a[13]=t9,a[14]=t10,a[15]=t13,tmp=(C_word)a,a+=16,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1673,a[2]=t14,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t16=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1691,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   map */
t17=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t17))(5,t17,t15,t16,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* a1690 in k1565 in k1554 in k1551 in k1548 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in a1527 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1691(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1691,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,t4,t2));}

/* k1671 in k1565 in k1554 in k1551 in k1548 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in a1527 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1673,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)((C_word*)t0)[3])[1]);
t3=(C_word)C_a_i_list(&a,4,lf[88],lf[89],lf[77],t2);
t4=(C_word)C_a_i_list(&a,2,lf[86],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* ##sys#append */
t6=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[2],t1,t5);}

/* k1667 in k1565 in k1554 in k1551 in k1548 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in a1527 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[88],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1669,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[77],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[78],t2);
t4=(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[15],t3);
t5=(C_word)C_a_i_list(&a,3,lf[80],lf[73],t4);
t6=(C_word)C_a_i_list(&a,3,lf[81],((C_word*)t0)[14],t5);
t7=(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[13],lf[73],t6);
t8=(C_word)C_a_i_list(&a,4,lf[79],lf[81],((C_word*)t0)[12],t7);
t9=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[11],t8);
t10=(C_word)C_a_i_list(&a,2,((C_word*)t0)[10],lf[77]);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1595,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t9,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t10,tmp=(C_word)a,a+=10,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1599,a[2]=t11,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1609,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   map */
t14=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t14))(5,t14,t12,t13,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1608 in k1667 in k1565 in k1554 in k1551 in k1548 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in a1527 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1609(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1609,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,3,lf[87],lf[77],t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,t4,t3));}

/* k1597 in k1667 in k1565 in k1554 in k1551 in k1548 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in a1527 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1599,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[86],((C_word*)((C_word*)t0)[3])[1]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k1593 in k1667 in k1565 in k1554 in k1551 in k1548 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in a1527 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1595,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[83],t1);
t3=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_list(&a,5,lf[84],((C_word*)((C_word*)t0)[8])[1],((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],t3,t4);
/* ##sys#append */
t6=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[3],((C_word*)t0)[2],t5);}

/* k1561 in k1554 in k1551 in k1548 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in a1527 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1563,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[68],t1));}

/* k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1064,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1494,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[66],t3);}

/* a1493 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1494(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[60],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1494,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t2,lf[60]);
t5=(C_word)C_a_i_list(&a,2,lf[61],t2);
t6=(C_word)C_a_i_list(&a,2,lf[61],t3);
t7=(C_word)C_a_i_list(&a,4,lf[62],lf[63],t5,t6);
t8=(C_word)C_a_i_list(&a,2,lf[56],t7);
t9=(C_word)C_a_i_list(&a,2,lf[61],t3);
t10=(C_word)C_a_i_list(&a,3,lf[64],t9,lf[60]);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[65],t4,t8,t10));}

/* k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1067,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1432,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[51],t3);}

/* a1431 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1432(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_1432r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1432r(t0,t1,t2,t3);}}

static void C_ccall f_1432r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1435,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1442,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1445,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_i_car(t2);
t8=t6;
f_1445(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_1445(t7,C_SCHEME_FALSE);}}

/* k1443 in a1431 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_1445(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1445,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_memq(lf[54],C_retrieve(lf[55])))){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 72   warning */
t3=C_retrieve(lf[56]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],lf[57],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1471,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken.scm: 72   ##compiler#register-compiler-macro */
t5=C_retrieve(lf[58]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,t3,t4,((C_word*)t0)[2]);}}
else{
/* chicken.scm: 72   bad */
t2=((C_word*)t0)[3];
f_1435(t2,((C_word*)t0)[4]);}}

/* k1469 in k1443 in a1431 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_1442(2,t2,C_SCHEME_UNDEFINED);}
else{
/* chicken.scm: 72   bad */
t2=((C_word*)t0)[2];
f_1435(t2,((C_word*)t0)[3]);}}

/* k1440 in a1431 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[53]);}

/* bad in a1431 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_1435(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1435,NULL,2,t0,t1);}
/* chicken.scm: 72   syntax-error */
t2=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,lf[51],lf[52],((C_word*)t0)[2]);}

/* k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1071,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1430,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 79   argv */
t4=C_retrieve(lf[49]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k1428 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1430,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1409,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1411,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1419,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1423,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 80   getenv */
t7=C_retrieve(lf[47]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[48]);}

/* k1421 in k1428 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[45]);
/* chicken.scm: 80   string-split */
t3=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k1417 in k1428 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 80   remove */
t2=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1410 in k1428 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1411(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1411,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_string_equal_p(t2,lf[43]));}

/* k1407 in k1428 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 78   append */
t2=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1069 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1071,2,t0,t1);}
t2=C_mutate((C_word*)lf[10]+1,t1);
t3=C_mutate((C_word*)lf[11]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1073,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1180,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1188,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1200,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 107  ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}

/* a1199 in k1069 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1200(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1200,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1204,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1212,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_1212(t9,t5,((C_word*)t4)[1]);}

/* loop in a1199 in k1069 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_1212(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(26);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1212,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_eqp(lf[19],t3);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1234,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t4);
/* chicken.scm: 113  string->number */
C_string_to_number(3,0,t6,t7);}
else{
t6=(C_word)C_eqp(lf[26],t3);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1297,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_car(t4);
/* chicken.scm: 127  string->number */
C_string_to_number(3,0,t7,t8);}
else{
t7=(C_word)C_eqp(lf[30],t3);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1351,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 136  cons* */
t9=C_retrieve(lf[20]);
((C_proc11)C_retrieve_proc(t9))(11,t9,t8,lf[31],lf[32],lf[28],lf[22],lf[21],lf[33],lf[34],lf[27],((C_word*)((C_word*)t0)[2])[1]);}
else{
if(C_truep((C_word)C_i_memq(t3,C_retrieve(lf[35])))){
/* chicken.scm: 140  loop */
t17=t1;
t18=t4;
t1=t17;
t2=t18;
goto loop;}
else{
if(C_truep((C_word)C_i_memq(t3,C_retrieve(lf[36])))){
if(C_truep((C_word)C_i_pairp(t4))){
t8=(C_word)C_i_cdr(t4);
/* chicken.scm: 143  loop */
t17=t1;
t18=t8;
t1=t17;
t2=t18;
goto loop;}
else{
/* chicken.scm: 144  quit */
t8=C_retrieve(lf[37]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,lf[38],t3);}}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1388,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1395,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_stringp(t3))){
t10=t9;
f_1395(2,t10,t3);}
else{
/* chicken.scm: 148  conc */
t10=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,lf[41],t3);}}}}}}}}

/* k1393 in loop in a1199 in k1069 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 146  compiler-warning */
t2=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[24],lf[39],t1);}

/* k1386 in loop in a1199 in k1069 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 149  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1212(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1349 in loop in a1199 in k1069 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* chicken.scm: 139  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1212(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1295 in loop in a1199 in k1069 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1300,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
switch(t1){
case C_fix(0):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1314,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 129  cons* */
t4=C_retrieve(lf[20]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[27],lf[28],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,lf[28],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_1300(2,t5,t4);
case C_fix(2):
t3=t2;
f_1300(2,t3,C_SCHEME_FALSE);
default:
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 132  compiler-warning */
t4=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[24],lf[29],t3);}}

/* k1312 in k1295 in loop in a1199 in k1069 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1300(2,t3,t2);}

/* k1298 in k1295 in loop in a1199 in k1069 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 133  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1212(t3,((C_word*)t0)[2],t2);}

/* k1232 in loop in a1199 in k1069 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1234,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1237,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
switch(t1){
case C_fix(0):
t3=t2;
f_1237(2,t3,C_SCHEME_FALSE);
case C_fix(1):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1257,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 117  cons* */
t4=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[21],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(2):
t3=(C_word)C_a_i_cons(&a,2,lf[21],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_1237(2,t5,t4);
case C_fix(3):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1277,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 123  cons* */
t4=C_retrieve(lf[20]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[21],lf[22],((C_word*)((C_word*)t0)[2])[1]);
default:
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 124  compiler-warning */
t4=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[24],lf[25],t3);}}

/* k1275 in k1232 in loop in a1199 in k1069 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1237(2,t3,t2);}

/* k1255 in k1232 in loop in a1199 in k1069 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1237(2,t3,t2);}

/* k1235 in k1232 in loop in a1199 in k1069 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 125  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1212(t3,((C_word*)t0)[2],t2);}

/* k1202 in a1199 in k1069 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1207,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t2,C_retrieve(lf[18]),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k1205 in k1202 in a1199 in k1069 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 151  exit */
t2=C_retrieve(lf[17]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a1187 in k1069 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1195,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 107  user-options-pass */
t3=C_retrieve(lf[16]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1193 in a1187 in k1069 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_retrieve(lf[11]));
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_retrieve(lf[10]));}

/* k1178 in k1069 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1183,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1186,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
t4=C_retrieve(lf[15]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k1184 in k1178 in k1069 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1181 in k1178 in k1069 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##compiler#process-command-line in k1069 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1073(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1073,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1079,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_1079(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in ##compiler#process-command-line in k1069 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_1079(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1079,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1093,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 92   reverse */
t6=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_string_length(t5);
t7=(C_word)C_i_string_ref(t5,C_fix(0));
t8=(C_word)C_eqp(C_make_character(45),t7);
t9=(C_truep(t8)?(C_word)C_fixnum_greaterp(t6,C_fix(1)):C_SCHEME_FALSE);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1114,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t6,C_fix(1)))){
t11=(C_word)C_i_string_ref(t5,C_fix(1));
t12=t10;
f_1114(t12,(C_word)C_eqp(C_make_character(58),t11));}
else{
t11=t10;
f_1114(t11,C_SCHEME_FALSE);}}
else{
if(C_truep(t4)){
t10=(C_word)C_i_cdr(t2);
t11=(C_word)C_a_i_cons(&a,2,t5,t3);
/* chicken.scm: 101  loop */
t17=t1;
t18=t10;
t19=t11;
t20=t4;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}
else{
t10=(C_word)C_i_cdr(t2);
/* chicken.scm: 102  loop */
t17=t1;
t18=t10;
t19=t3;
t20=t5;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}}}}

/* k1112 in loop in ##compiler#process-command-line in k1069 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_fcall f_1114(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1114,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* chicken.scm: 98   loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_1079(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1136,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1140,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 99   substring */
t5=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]);}}

/* k1138 in k1112 in loop in ##compiler#process-command-line in k1069 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 99   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1134 in k1112 in loop in ##compiler#process-command-line in k1069 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1136,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* chicken.scm: 99   loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1079(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1091 in loop in ##compiler#process-command-line in k1069 in k1065 in k1062 in k1059 in k1056 in k1053 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k863 in k860 in k857 in k854 in k851 in k848 in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_1093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 92   values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* assign in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_777,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_781,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t5=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[8],t2,lf[9]);}

/* k779 in assign in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_781,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t2=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,lf[3]);
t4=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[4],t2,t4));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t3,((C_word*)t0)[4]));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_818,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   map */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[6]),((C_word*)t0)[5]);}}}

/* k816 in k779 in assign in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_818,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_837,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_839,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   map */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[2],t1);}

/* a838 in k816 in k779 in assign in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_839(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_839,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t2,t3));}

/* k835 in k816 in k779 in assign in k774 in k771 in k768 in k765 in k762 in k759 in k756 in k753 in k750 in k747 in k744 in k741 in k738 in k732 in k729 in k726 in k723 in k720 in k717 in k714 in k711 in k708 in k705 in k702 in k699 in k696 in k693 in k690 in k687 */
static void C_ccall f_837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_837,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[2],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[4],((C_word*)t0)[2],t3));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[579] = {
{"toplevelchicken.scm",(void*)C_toplevel},
{"f_689chicken.scm",(void*)f_689},
{"f_692chicken.scm",(void*)f_692},
{"f_695chicken.scm",(void*)f_695},
{"f_698chicken.scm",(void*)f_698},
{"f_701chicken.scm",(void*)f_701},
{"f_704chicken.scm",(void*)f_704},
{"f_707chicken.scm",(void*)f_707},
{"f_710chicken.scm",(void*)f_710},
{"f_713chicken.scm",(void*)f_713},
{"f_716chicken.scm",(void*)f_716},
{"f_719chicken.scm",(void*)f_719},
{"f_722chicken.scm",(void*)f_722},
{"f_725chicken.scm",(void*)f_725},
{"f_728chicken.scm",(void*)f_728},
{"f_731chicken.scm",(void*)f_731},
{"f_734chicken.scm",(void*)f_734},
{"f_740chicken.scm",(void*)f_740},
{"f_6918chicken.scm",(void*)f_6918},
{"f_6922chicken.scm",(void*)f_6922},
{"f_6925chicken.scm",(void*)f_6925},
{"f_6928chicken.scm",(void*)f_6928},
{"f_6934chicken.scm",(void*)f_6934},
{"f_7140chicken.scm",(void*)f_7140},
{"f_7120chicken.scm",(void*)f_7120},
{"f_7116chicken.scm",(void*)f_7116},
{"f_7096chicken.scm",(void*)f_7096},
{"f_6959chicken.scm",(void*)f_6959},
{"f_6969chicken.scm",(void*)f_6969},
{"f_7088chicken.scm",(void*)f_7088},
{"f_6972chicken.scm",(void*)f_6972},
{"f_7084chicken.scm",(void*)f_7084},
{"f_6975chicken.scm",(void*)f_6975},
{"f_7006chicken.scm",(void*)f_7006},
{"f_6986chicken.scm",(void*)f_6986},
{"f_6957chicken.scm",(void*)f_6957},
{"f_743chicken.scm",(void*)f_743},
{"f_6830chicken.scm",(void*)f_6830},
{"f_6847chicken.scm",(void*)f_6847},
{"f_6850chicken.scm",(void*)f_6850},
{"f_6856chicken.scm",(void*)f_6856},
{"f_746chicken.scm",(void*)f_746},
{"f_6789chicken.scm",(void*)f_6789},
{"f_6793chicken.scm",(void*)f_6793},
{"f_749chicken.scm",(void*)f_749},
{"f_6773chicken.scm",(void*)f_6773},
{"f_6783chicken.scm",(void*)f_6783},
{"f_6781chicken.scm",(void*)f_6781},
{"f_752chicken.scm",(void*)f_752},
{"f_6696chicken.scm",(void*)f_6696},
{"f_6700chicken.scm",(void*)f_6700},
{"f_6768chicken.scm",(void*)f_6768},
{"f_6703chicken.scm",(void*)f_6703},
{"f_6712chicken.scm",(void*)f_6712},
{"f_6759chicken.scm",(void*)f_6759},
{"f_6726chicken.scm",(void*)f_6726},
{"f_6734chicken.scm",(void*)f_6734},
{"f_6736chicken.scm",(void*)f_6736},
{"f_6753chicken.scm",(void*)f_6753},
{"f_6718chicken.scm",(void*)f_6718},
{"f_6710chicken.scm",(void*)f_6710},
{"f_755chicken.scm",(void*)f_755},
{"f_6636chicken.scm",(void*)f_6636},
{"f_6640chicken.scm",(void*)f_6640},
{"f_758chicken.scm",(void*)f_758},
{"f_6577chicken.scm",(void*)f_6577},
{"f_6581chicken.scm",(void*)f_6581},
{"f_6608chicken.scm",(void*)f_6608},
{"f_761chicken.scm",(void*)f_761},
{"f_6403chicken.scm",(void*)f_6403},
{"f_6407chicken.scm",(void*)f_6407},
{"f_6410chicken.scm",(void*)f_6410},
{"f_6571chicken.scm",(void*)f_6571},
{"f_6413chicken.scm",(void*)f_6413},
{"f_6565chicken.scm",(void*)f_6565},
{"f_6416chicken.scm",(void*)f_6416},
{"f_6563chicken.scm",(void*)f_6563},
{"f_6527chicken.scm",(void*)f_6527},
{"f_6541chicken.scm",(void*)f_6541},
{"f_6555chicken.scm",(void*)f_6555},
{"f_6535chicken.scm",(void*)f_6535},
{"f_6531chicken.scm",(void*)f_6531},
{"f_6423chicken.scm",(void*)f_6423},
{"f_6519chicken.scm",(void*)f_6519},
{"f_6495chicken.scm",(void*)f_6495},
{"f_6513chicken.scm",(void*)f_6513},
{"f_6503chicken.scm",(void*)f_6503},
{"f_6499chicken.scm",(void*)f_6499},
{"f_6491chicken.scm",(void*)f_6491},
{"f_6475chicken.scm",(void*)f_6475},
{"f_6451chicken.scm",(void*)f_6451},
{"f_6469chicken.scm",(void*)f_6469},
{"f_6459chicken.scm",(void*)f_6459},
{"f_6455chicken.scm",(void*)f_6455},
{"f_6447chicken.scm",(void*)f_6447},
{"f_764chicken.scm",(void*)f_764},
{"f_6308chicken.scm",(void*)f_6308},
{"f_6344chicken.scm",(void*)f_6344},
{"f_6357chicken.scm",(void*)f_6357},
{"f_6315chicken.scm",(void*)f_6315},
{"f_767chicken.scm",(void*)f_767},
{"f_6198chicken.scm",(void*)f_6198},
{"f_6202chicken.scm",(void*)f_6202},
{"f_6205chicken.scm",(void*)f_6205},
{"f_6208chicken.scm",(void*)f_6208},
{"f_6211chicken.scm",(void*)f_6211},
{"f_6302chicken.scm",(void*)f_6302},
{"f_6214chicken.scm",(void*)f_6214},
{"f_6296chicken.scm",(void*)f_6296},
{"f_6217chicken.scm",(void*)f_6217},
{"f_6290chicken.scm",(void*)f_6290},
{"f_6294chicken.scm",(void*)f_6294},
{"f_6224chicken.scm",(void*)f_6224},
{"f_6262chicken.scm",(void*)f_6262},
{"f_6260chicken.scm",(void*)f_6260},
{"f_770chicken.scm",(void*)f_770},
{"f_6188chicken.scm",(void*)f_6188},
{"f_773chicken.scm",(void*)f_773},
{"f_6174chicken.scm",(void*)f_6174},
{"f_776chicken.scm",(void*)f_776},
{"f_850chicken.scm",(void*)f_850},
{"f_853chicken.scm",(void*)f_853},
{"f_5912chicken.scm",(void*)f_5912},
{"f_5916chicken.scm",(void*)f_5916},
{"f_5925chicken.scm",(void*)f_5925},
{"f_6134chicken.scm",(void*)f_6134},
{"f_6147chicken.scm",(void*)f_6147},
{"f_5928chicken.scm",(void*)f_5928},
{"f_6124chicken.scm",(void*)f_6124},
{"f_6132chicken.scm",(void*)f_6132},
{"f_5931chicken.scm",(void*)f_5931},
{"f_6078chicken.scm",(void*)f_6078},
{"f_6111chicken.scm",(void*)f_6111},
{"f_6118chicken.scm",(void*)f_6118},
{"f_6094chicken.scm",(void*)f_6094},
{"f_5943chicken.scm",(void*)f_5943},
{"f_6072chicken.scm",(void*)f_6072},
{"f_5950chicken.scm",(void*)f_5950},
{"f_5952chicken.scm",(void*)f_5952},
{"f_6066chicken.scm",(void*)f_6066},
{"f_5986chicken.scm",(void*)f_5986},
{"f_6040chicken.scm",(void*)f_6040},
{"f_6017chicken.scm",(void*)f_6017},
{"f_5997chicken.scm",(void*)f_5997},
{"f_5972chicken.scm",(void*)f_5972},
{"f_5980chicken.scm",(void*)f_5980},
{"f_5970chicken.scm",(void*)f_5970},
{"f_5932chicken.scm",(void*)f_5932},
{"f_5872chicken.scm",(void*)f_5872},
{"f_5895chicken.scm",(void*)f_5895},
{"f_5899chicken.scm",(void*)f_5899},
{"f_5841chicken.scm",(void*)f_5841},
{"f_5862chicken.scm",(void*)f_5862},
{"f_856chicken.scm",(void*)f_856},
{"f_5790chicken.scm",(void*)f_5790},
{"f_5794chicken.scm",(void*)f_5794},
{"f_5805chicken.scm",(void*)f_5805},
{"f_5830chicken.scm",(void*)f_5830},
{"f_859chicken.scm",(void*)f_859},
{"f_5670chicken.scm",(void*)f_5670},
{"f_5674chicken.scm",(void*)f_5674},
{"f_5784chicken.scm",(void*)f_5784},
{"f_5782chicken.scm",(void*)f_5782},
{"f_5683chicken.scm",(void*)f_5683},
{"f_5770chicken.scm",(void*)f_5770},
{"f_5778chicken.scm",(void*)f_5778},
{"f_5686chicken.scm",(void*)f_5686},
{"f_5764chicken.scm",(void*)f_5764},
{"f_5706chicken.scm",(void*)f_5706},
{"f_5716chicken.scm",(void*)f_5716},
{"f_5736chicken.scm",(void*)f_5736},
{"f_5742chicken.scm",(void*)f_5742},
{"f_5750chicken.scm",(void*)f_5750},
{"f_5740chicken.scm",(void*)f_5740},
{"f_5714chicken.scm",(void*)f_5714},
{"f_5710chicken.scm",(void*)f_5710},
{"f_5687chicken.scm",(void*)f_5687},
{"f_862chicken.scm",(void*)f_862},
{"f_5649chicken.scm",(void*)f_5649},
{"f_5653chicken.scm",(void*)f_5653},
{"f_865chicken.scm",(void*)f_865},
{"f_5639chicken.scm",(void*)f_5639},
{"f_871chicken.scm",(void*)f_871},
{"f_880chicken.scm",(void*)f_880},
{"f_896chicken.scm",(void*)f_896},
{"f_883chicken.scm",(void*)f_883},
{"f_944chicken.scm",(void*)f_944},
{"f_5618chicken.scm",(void*)f_5618},
{"f_5622chicken.scm",(void*)f_5622},
{"f_947chicken.scm",(void*)f_947},
{"f_5502chicken.scm",(void*)f_5502},
{"f_5506chicken.scm",(void*)f_5506},
{"f_5515chicken.scm",(void*)f_5515},
{"f_5529chicken.scm",(void*)f_5529},
{"f_5593chicken.scm",(void*)f_5593},
{"f_5575chicken.scm",(void*)f_5575},
{"f_5558chicken.scm",(void*)f_5558},
{"f_950chicken.scm",(void*)f_950},
{"f_5403chicken.scm",(void*)f_5403},
{"f_5413chicken.scm",(void*)f_5413},
{"f_5426chicken.scm",(void*)f_5426},
{"f_5442chicken.scm",(void*)f_5442},
{"f_5480chicken.scm",(void*)f_5480},
{"f_5478chicken.scm",(void*)f_5478},
{"f_5470chicken.scm",(void*)f_5470},
{"f_5424chicken.scm",(void*)f_5424},
{"f_953chicken.scm",(void*)f_953},
{"f_5314chicken.scm",(void*)f_5314},
{"f_5324chicken.scm",(void*)f_5324},
{"f_5337chicken.scm",(void*)f_5337},
{"f_5353chicken.scm",(void*)f_5353},
{"f_5381chicken.scm",(void*)f_5381},
{"f_5335chicken.scm",(void*)f_5335},
{"f_956chicken.scm",(void*)f_956},
{"f_5028chicken.scm",(void*)f_5028},
{"f_5225chicken.scm",(void*)f_5225},
{"f_5228chicken.scm",(void*)f_5228},
{"f_5231chicken.scm",(void*)f_5231},
{"f_5304chicken.scm",(void*)f_5304},
{"f_5312chicken.scm",(void*)f_5312},
{"f_5247chicken.scm",(void*)f_5247},
{"f_5250chicken.scm",(void*)f_5250},
{"f_5253chicken.scm",(void*)f_5253},
{"f_5256chicken.scm",(void*)f_5256},
{"f_5294chicken.scm",(void*)f_5294},
{"f_5302chicken.scm",(void*)f_5302},
{"f_5259chicken.scm",(void*)f_5259},
{"f_5039chicken.scm",(void*)f_5039},
{"f_5043chicken.scm",(void*)f_5043},
{"f_5047chicken.scm",(void*)f_5047},
{"f_5049chicken.scm",(void*)f_5049},
{"f_5094chicken.scm",(void*)f_5094},
{"f_5106chicken.scm",(void*)f_5106},
{"f_5102chicken.scm",(void*)f_5102},
{"f_5070chicken.scm",(void*)f_5070},
{"f_5262chicken.scm",(void*)f_5262},
{"f_5122chicken.scm",(void*)f_5122},
{"f_5222chicken.scm",(void*)f_5222},
{"f_5186chicken.scm",(void*)f_5186},
{"f_5156chicken.scm",(void*)f_5156},
{"f_5265chicken.scm",(void*)f_5265},
{"f_5232chicken.scm",(void*)f_5232},
{"f_5244chicken.scm",(void*)f_5244},
{"f_5240chicken.scm",(void*)f_5240},
{"f_959chicken.scm",(void*)f_959},
{"f_4971chicken.scm",(void*)f_4971},
{"f_4975chicken.scm",(void*)f_4975},
{"f_962chicken.scm",(void*)f_962},
{"f_4965chicken.scm",(void*)f_4965},
{"f_965chicken.scm",(void*)f_965},
{"f_4812chicken.scm",(void*)f_4812},
{"f_4816chicken.scm",(void*)f_4816},
{"f_4819chicken.scm",(void*)f_4819},
{"f_4822chicken.scm",(void*)f_4822},
{"f_4835chicken.scm",(void*)f_4835},
{"f_4885chicken.scm",(void*)f_4885},
{"f_4896chicken.scm",(void*)f_4896},
{"f_4833chicken.scm",(void*)f_4833},
{"f_968chicken.scm",(void*)f_968},
{"f_4536chicken.scm",(void*)f_4536},
{"f_4570chicken.scm",(void*)f_4570},
{"f_4573chicken.scm",(void*)f_4573},
{"f_4799chicken.scm",(void*)f_4799},
{"f_4809chicken.scm",(void*)f_4809},
{"f_4797chicken.scm",(void*)f_4797},
{"f_4576chicken.scm",(void*)f_4576},
{"f_4545chicken.scm",(void*)f_4545},
{"f_4559chicken.scm",(void*)f_4559},
{"f_4563chicken.scm",(void*)f_4563},
{"f_4579chicken.scm",(void*)f_4579},
{"f_4582chicken.scm",(void*)f_4582},
{"f_4585chicken.scm",(void*)f_4585},
{"f_4592chicken.scm",(void*)f_4592},
{"f_4606chicken.scm",(void*)f_4606},
{"f_4616chicken.scm",(void*)f_4616},
{"f_4620chicken.scm",(void*)f_4620},
{"f_4630chicken.scm",(void*)f_4630},
{"f_4646chicken.scm",(void*)f_4646},
{"f_4665chicken.scm",(void*)f_4665},
{"f_4721chicken.scm",(void*)f_4721},
{"f_4732chicken.scm",(void*)f_4732},
{"f_4650chicken.scm",(void*)f_4650},
{"f_4663chicken.scm",(void*)f_4663},
{"f_4636chicken.scm",(void*)f_4636},
{"f_4644chicken.scm",(void*)f_4644},
{"f_4634chicken.scm",(void*)f_4634},
{"f_4604chicken.scm",(void*)f_4604},
{"f_971chicken.scm",(void*)f_971},
{"f_4479chicken.scm",(void*)f_4479},
{"f_4519chicken.scm",(void*)f_4519},
{"f_4489chicken.scm",(void*)f_4489},
{"f_974chicken.scm",(void*)f_974},
{"f_4403chicken.scm",(void*)f_4403},
{"f_4407chicken.scm",(void*)f_4407},
{"f_4410chicken.scm",(void*)f_4410},
{"f_977chicken.scm",(void*)f_977},
{"f_4219chicken.scm",(void*)f_4219},
{"f_4223chicken.scm",(void*)f_4223},
{"f_4226chicken.scm",(void*)f_4226},
{"f_4369chicken.scm",(void*)f_4369},
{"f_4365chicken.scm",(void*)f_4365},
{"f_4228chicken.scm",(void*)f_4228},
{"f_4316chicken.scm",(void*)f_4316},
{"f_4314chicken.scm",(void*)f_4314},
{"f_4284chicken.scm",(void*)f_4284},
{"f_4251chicken.scm",(void*)f_4251},
{"f_980chicken.scm",(void*)f_980},
{"f_4029chicken.scm",(void*)f_4029},
{"f_4036chicken.scm",(void*)f_4036},
{"f_4210chicken.scm",(void*)f_4210},
{"f_4208chicken.scm",(void*)f_4208},
{"f_4061chicken.scm",(void*)f_4061},
{"f_4087chicken.scm",(void*)f_4087},
{"f_4115chicken.scm",(void*)f_4115},
{"f_4099chicken.scm",(void*)f_4099},
{"f_4059chicken.scm",(void*)f_4059},
{"f_983chicken.scm",(void*)f_983},
{"f_4020chicken.scm",(void*)f_4020},
{"f_4024chicken.scm",(void*)f_4024},
{"f_986chicken.scm",(void*)f_986},
{"f_4001chicken.scm",(void*)f_4001},
{"f_4005chicken.scm",(void*)f_4005},
{"f_4014chicken.scm",(void*)f_4014},
{"f_4012chicken.scm",(void*)f_4012},
{"f_989chicken.scm",(void*)f_989},
{"f_3982chicken.scm",(void*)f_3982},
{"f_3986chicken.scm",(void*)f_3986},
{"f_3995chicken.scm",(void*)f_3995},
{"f_3993chicken.scm",(void*)f_3993},
{"f_992chicken.scm",(void*)f_992},
{"f_3854chicken.scm",(void*)f_3854},
{"f_3860chicken.scm",(void*)f_3860},
{"f_3941chicken.scm",(void*)f_3941},
{"f_3870chicken.scm",(void*)f_3870},
{"f_3873chicken.scm",(void*)f_3873},
{"f_3879chicken.scm",(void*)f_3879},
{"f_3886chicken.scm",(void*)f_3886},
{"f_3902chicken.scm",(void*)f_3902},
{"f_995chicken.scm",(void*)f_995},
{"f_3711chicken.scm",(void*)f_3711},
{"f_3717chicken.scm",(void*)f_3717},
{"f_3829chicken.scm",(void*)f_3829},
{"f_3802chicken.scm",(void*)f_3802},
{"f_3727chicken.scm",(void*)f_3727},
{"f_3730chicken.scm",(void*)f_3730},
{"f_3736chicken.scm",(void*)f_3736},
{"f_3747chicken.scm",(void*)f_3747},
{"f_3763chicken.scm",(void*)f_3763},
{"f_998chicken.scm",(void*)f_998},
{"f_3652chicken.scm",(void*)f_3652},
{"f_1001chicken.scm",(void*)f_1001},
{"f_3481chicken.scm",(void*)f_3481},
{"f_3487chicken.scm",(void*)f_3487},
{"f_3561chicken.scm",(void*)f_3561},
{"f_3564chicken.scm",(void*)f_3564},
{"f_3637chicken.scm",(void*)f_3637},
{"f_3630chicken.scm",(void*)f_3630},
{"f_3622chicken.scm",(void*)f_3622},
{"f_3609chicken.scm",(void*)f_3609},
{"f_3588chicken.scm",(void*)f_3588},
{"f_3497chicken.scm",(void*)f_3497},
{"f_1004chicken.scm",(void*)f_1004},
{"f_3430chicken.scm",(void*)f_3430},
{"f_1007chicken.scm",(void*)f_1007},
{"f_3370chicken.scm",(void*)f_3370},
{"f_3380chicken.scm",(void*)f_3380},
{"f_3399chicken.scm",(void*)f_3399},
{"f_3383chicken.scm",(void*)f_3383},
{"f_1010chicken.scm",(void*)f_1010},
{"f_1013chicken.scm",(void*)f_1013},
{"f_3333chicken.scm",(void*)f_3333},
{"f_3337chicken.scm",(void*)f_3337},
{"f_1016chicken.scm",(void*)f_1016},
{"f_3314chicken.scm",(void*)f_3314},
{"f_3318chicken.scm",(void*)f_3318},
{"f_3327chicken.scm",(void*)f_3327},
{"f_3325chicken.scm",(void*)f_3325},
{"f_1019chicken.scm",(void*)f_1019},
{"f_3295chicken.scm",(void*)f_3295},
{"f_3299chicken.scm",(void*)f_3299},
{"f_3308chicken.scm",(void*)f_3308},
{"f_3306chicken.scm",(void*)f_3306},
{"f_1022chicken.scm",(void*)f_1022},
{"f_3276chicken.scm",(void*)f_3276},
{"f_3280chicken.scm",(void*)f_3280},
{"f_3289chicken.scm",(void*)f_3289},
{"f_3287chicken.scm",(void*)f_3287},
{"f_1025chicken.scm",(void*)f_1025},
{"f_3257chicken.scm",(void*)f_3257},
{"f_3261chicken.scm",(void*)f_3261},
{"f_3270chicken.scm",(void*)f_3270},
{"f_3268chicken.scm",(void*)f_3268},
{"f_1028chicken.scm",(void*)f_1028},
{"f_3238chicken.scm",(void*)f_3238},
{"f_3242chicken.scm",(void*)f_3242},
{"f_3251chicken.scm",(void*)f_3251},
{"f_3249chicken.scm",(void*)f_3249},
{"f_1031chicken.scm",(void*)f_1031},
{"f_3219chicken.scm",(void*)f_3219},
{"f_3223chicken.scm",(void*)f_3223},
{"f_3232chicken.scm",(void*)f_3232},
{"f_3230chicken.scm",(void*)f_3230},
{"f_1034chicken.scm",(void*)f_1034},
{"f_3119chicken.scm",(void*)f_3119},
{"f_3123chicken.scm",(void*)f_3123},
{"f_3178chicken.scm",(void*)f_3178},
{"f_3132chicken.scm",(void*)f_3132},
{"f_1037chicken.scm",(void*)f_1037},
{"f_2899chicken.scm",(void*)f_2899},
{"f_2903chicken.scm",(void*)f_2903},
{"f_2906chicken.scm",(void*)f_2906},
{"f_2987chicken.scm",(void*)f_2987},
{"f_3054chicken.scm",(void*)f_3054},
{"f_3052chicken.scm",(void*)f_3052},
{"f_3044chicken.scm",(void*)f_3044},
{"f_3032chicken.scm",(void*)f_3032},
{"f_2912chicken.scm",(void*)f_2912},
{"f_2938chicken.scm",(void*)f_2938},
{"f_1040chicken.scm",(void*)f_1040},
{"f_2824chicken.scm",(void*)f_2824},
{"f_2828chicken.scm",(void*)f_2828},
{"f_2897chicken.scm",(void*)f_2897},
{"f_2851chicken.scm",(void*)f_2851},
{"f_1043chicken.scm",(void*)f_1043},
{"f_2718chicken.scm",(void*)f_2718},
{"f_2818chicken.scm",(void*)f_2818},
{"f_2722chicken.scm",(void*)f_2722},
{"f_2794chicken.scm",(void*)f_2794},
{"f_2729chicken.scm",(void*)f_2729},
{"f_2735chicken.scm",(void*)f_2735},
{"f_2733chicken.scm",(void*)f_2733},
{"f_1046chicken.scm",(void*)f_1046},
{"f_2689chicken.scm",(void*)f_2689},
{"f_2693chicken.scm",(void*)f_2693},
{"f_2716chicken.scm",(void*)f_2716},
{"f_2712chicken.scm",(void*)f_2712},
{"f_1049chicken.scm",(void*)f_1049},
{"f_2676chicken.scm",(void*)f_2676},
{"f_2680chicken.scm",(void*)f_2680},
{"f_1052chicken.scm",(void*)f_1052},
{"f_1882chicken.scm",(void*)f_1882},
{"f_1886chicken.scm",(void*)f_1886},
{"f_1892chicken.scm",(void*)f_1892},
{"f_1895chicken.scm",(void*)f_1895},
{"f_1898chicken.scm",(void*)f_1898},
{"f_1901chicken.scm",(void*)f_1901},
{"f_2568chicken.scm",(void*)f_2568},
{"f_2647chicken.scm",(void*)f_2647},
{"f_2643chicken.scm",(void*)f_2643},
{"f_2578chicken.scm",(void*)f_2578},
{"f_2582chicken.scm",(void*)f_2582},
{"f_2623chicken.scm",(void*)f_2623},
{"f_2613chicken.scm",(void*)f_2613},
{"f_2603chicken.scm",(void*)f_2603},
{"f_2599chicken.scm",(void*)f_2599},
{"f_2585chicken.scm",(void*)f_2585},
{"f_1989chicken.scm",(void*)f_1989},
{"f_1992chicken.scm",(void*)f_1992},
{"f_2562chicken.scm",(void*)f_2562},
{"f_2491chicken.scm",(void*)f_2491},
{"f_2497chicken.scm",(void*)f_2497},
{"f_2551chicken.scm",(void*)f_2551},
{"f_2543chicken.scm",(void*)f_2543},
{"f_2526chicken.scm",(void*)f_2526},
{"f_2514chicken.scm",(void*)f_2514},
{"f_2495chicken.scm",(void*)f_2495},
{"f_2479chicken.scm",(void*)f_2479},
{"f_2475chicken.scm",(void*)f_2475},
{"f_2003chicken.scm",(void*)f_2003},
{"f_2457chicken.scm",(void*)f_2457},
{"f_2011chicken.scm",(void*)f_2011},
{"f_2019chicken.scm",(void*)f_2019},
{"f_2025chicken.scm",(void*)f_2025},
{"f_2302chicken.scm",(void*)f_2302},
{"f_2414chicken.scm",(void*)f_2414},
{"f_2410chicken.scm",(void*)f_2410},
{"f_2379chicken.scm",(void*)f_2379},
{"f_2402chicken.scm",(void*)f_2402},
{"f_2391chicken.scm",(void*)f_2391},
{"f_2320chicken.scm",(void*)f_2320},
{"f_2365chicken.scm",(void*)f_2365},
{"f_2361chicken.scm",(void*)f_2361},
{"f_2337chicken.scm",(void*)f_2337},
{"f_2349chicken.scm",(void*)f_2349},
{"f_2317chicken.scm",(void*)f_2317},
{"f_2047chicken.scm",(void*)f_2047},
{"f_2287chicken.scm",(void*)f_2287},
{"f_2283chicken.scm",(void*)f_2283},
{"f_2188chicken.scm",(void*)f_2188},
{"f_2271chicken.scm",(void*)f_2271},
{"f_2260chicken.scm",(void*)f_2260},
{"f_2065chicken.scm",(void*)f_2065},
{"f_2174chicken.scm",(void*)f_2174},
{"f_2170chicken.scm",(void*)f_2170},
{"f_2082chicken.scm",(void*)f_2082},
{"f_2154chicken.scm",(void*)f_2154},
{"f_2062chicken.scm",(void*)f_2062},
{"f_2023chicken.scm",(void*)f_2023},
{"f_2015chicken.scm",(void*)f_2015},
{"f_2007chicken.scm",(void*)f_2007},
{"f_1999chicken.scm",(void*)f_1999},
{"f_1946chicken.scm",(void*)f_1946},
{"f_1962chicken.scm",(void*)f_1962},
{"f_1903chicken.scm",(void*)f_1903},
{"f_1055chicken.scm",(void*)f_1055},
{"f_1868chicken.scm",(void*)f_1868},
{"f_1058chicken.scm",(void*)f_1058},
{"f_1528chicken.scm",(void*)f_1528},
{"f_1532chicken.scm",(void*)f_1532},
{"f_1535chicken.scm",(void*)f_1535},
{"f_1840chicken.scm",(void*)f_1840},
{"f_1538chicken.scm",(void*)f_1538},
{"f_1815chicken.scm",(void*)f_1815},
{"f_1541chicken.scm",(void*)f_1541},
{"f_1783chicken.scm",(void*)f_1783},
{"f_1544chicken.scm",(void*)f_1544},
{"f_1757chicken.scm",(void*)f_1757},
{"f_1547chicken.scm",(void*)f_1547},
{"f_1550chicken.scm",(void*)f_1550},
{"f_1745chicken.scm",(void*)f_1745},
{"f_1553chicken.scm",(void*)f_1553},
{"f_1741chicken.scm",(void*)f_1741},
{"f_1556chicken.scm",(void*)f_1556},
{"f_1729chicken.scm",(void*)f_1729},
{"f_1737chicken.scm",(void*)f_1737},
{"f_1567chicken.scm",(void*)f_1567},
{"f_1691chicken.scm",(void*)f_1691},
{"f_1673chicken.scm",(void*)f_1673},
{"f_1669chicken.scm",(void*)f_1669},
{"f_1609chicken.scm",(void*)f_1609},
{"f_1599chicken.scm",(void*)f_1599},
{"f_1595chicken.scm",(void*)f_1595},
{"f_1563chicken.scm",(void*)f_1563},
{"f_1061chicken.scm",(void*)f_1061},
{"f_1494chicken.scm",(void*)f_1494},
{"f_1064chicken.scm",(void*)f_1064},
{"f_1432chicken.scm",(void*)f_1432},
{"f_1445chicken.scm",(void*)f_1445},
{"f_1471chicken.scm",(void*)f_1471},
{"f_1442chicken.scm",(void*)f_1442},
{"f_1435chicken.scm",(void*)f_1435},
{"f_1067chicken.scm",(void*)f_1067},
{"f_1430chicken.scm",(void*)f_1430},
{"f_1423chicken.scm",(void*)f_1423},
{"f_1419chicken.scm",(void*)f_1419},
{"f_1411chicken.scm",(void*)f_1411},
{"f_1409chicken.scm",(void*)f_1409},
{"f_1071chicken.scm",(void*)f_1071},
{"f_1200chicken.scm",(void*)f_1200},
{"f_1212chicken.scm",(void*)f_1212},
{"f_1395chicken.scm",(void*)f_1395},
{"f_1388chicken.scm",(void*)f_1388},
{"f_1351chicken.scm",(void*)f_1351},
{"f_1297chicken.scm",(void*)f_1297},
{"f_1314chicken.scm",(void*)f_1314},
{"f_1300chicken.scm",(void*)f_1300},
{"f_1234chicken.scm",(void*)f_1234},
{"f_1277chicken.scm",(void*)f_1277},
{"f_1257chicken.scm",(void*)f_1257},
{"f_1237chicken.scm",(void*)f_1237},
{"f_1204chicken.scm",(void*)f_1204},
{"f_1207chicken.scm",(void*)f_1207},
{"f_1188chicken.scm",(void*)f_1188},
{"f_1195chicken.scm",(void*)f_1195},
{"f_1180chicken.scm",(void*)f_1180},
{"f_1186chicken.scm",(void*)f_1186},
{"f_1183chicken.scm",(void*)f_1183},
{"f_1073chicken.scm",(void*)f_1073},
{"f_1079chicken.scm",(void*)f_1079},
{"f_1114chicken.scm",(void*)f_1114},
{"f_1140chicken.scm",(void*)f_1140},
{"f_1136chicken.scm",(void*)f_1136},
{"f_1093chicken.scm",(void*)f_1093},
{"f_777chicken.scm",(void*)f_777},
{"f_781chicken.scm",(void*)f_781},
{"f_818chicken.scm",(void*)f_818},
{"f_839chicken.scm",(void*)f_839},
{"f_837chicken.scm",(void*)f_837},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
