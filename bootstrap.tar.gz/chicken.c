/* Generated from chicken.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-12-30 14:34
   Version 4.0.0x5 - SVN rev. 12341
   macosx-unix-gnu-ppc [ dload ptables applyhook ]
   compiled 2008-11-03 on apfel (Darwin)
   command line: chicken.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -no-lambda-info -inline -local -extend private-namespace.scm -output-file chicken.c
   used units: library eval data_structures ports extras srfi_69 chicken_syntax srfi_1 srfi_4 utils files support compiler optimizer driver platform backend srfi_69
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_syntax_toplevel)
C_externimport void C_ccall C_chicken_syntax_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_4_toplevel)
C_externimport void C_ccall C_srfi_4_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_support_toplevel)
C_externimport void C_ccall C_support_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_compiler_toplevel)
C_externimport void C_ccall C_compiler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_optimizer_toplevel)
C_externimport void C_ccall C_optimizer_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_driver_toplevel)
C_externimport void C_ccall C_driver_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_platform_toplevel)
C_externimport void C_ccall C_platform_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_backend_toplevel)
C_externimport void C_ccall C_backend_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[89];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_333)
static void C_ccall f_333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_336)
static void C_ccall f_336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_339)
static void C_ccall f_339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_342)
static void C_ccall f_342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_345)
static void C_ccall f_345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_348)
static void C_ccall f_348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_351)
static void C_ccall f_351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_354)
static void C_ccall f_354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_357)
static void C_ccall f_357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_360)
static void C_ccall f_360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_363)
static void C_ccall f_363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_366)
static void C_ccall f_366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_369)
static void C_ccall f_369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_372)
static void C_ccall f_372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_375)
static void C_ccall f_375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_378)
static void C_ccall f_378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_381)
static void C_ccall f_381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_384)
static void C_ccall f_384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_388)
static void C_ccall f_388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1232)
static void C_ccall f_1232(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1239)
static void C_ccall f_1239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1242)
static void C_fcall f_1242(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1245)
static void C_fcall f_1245(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1350)
static void C_ccall f_1350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1363)
static void C_ccall f_1363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1461)
static void C_ccall f_1461(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1459)
static void C_ccall f_1459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1423)
static void C_ccall f_1423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1447)
static void C_ccall f_1447(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1431)
static void C_ccall f_1431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1435)
static void C_ccall f_1435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1251)
static void C_ccall f_1251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1261)
static void C_ccall f_1261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1335)
static void C_ccall f_1335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1315)
static void C_ccall f_1315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1285)
static void C_fcall f_1285(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1281)
static void C_ccall f_1281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1230)
static void C_ccall f_1230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_391)
static void C_ccall f_391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1091)
static void C_ccall f_1091(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1095)
static void C_ccall f_1095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1107)
static void C_ccall f_1107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1207)
static void C_ccall f_1207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1110)
static void C_ccall f_1110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1117)
static void C_ccall f_1117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1187)
static void C_ccall f_1187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1203)
static void C_ccall f_1203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1167)
static void C_ccall f_1167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1141)
static void C_fcall f_1141(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1137)
static void C_ccall f_1137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1089)
static void C_ccall f_1089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_394)
static void C_ccall f_394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_941)
static void C_ccall f_941(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_945)
static void C_ccall f_945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_954)
static void C_ccall f_954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1077)
static void C_ccall f_1077(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1085)
static void C_ccall f_1085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_957)
static void C_ccall f_957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1053)
static void C_ccall f_1053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_968)
static void C_ccall f_968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1051)
static void C_ccall f_1051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_978)
static void C_ccall f_978(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_976)
static void C_ccall f_976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_939)
static void C_ccall f_939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_397)
static void C_ccall f_397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_873)
static void C_ccall f_873(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_877)
static void C_ccall f_877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_880)
static void C_ccall f_880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_887)
static void C_ccall f_887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_911)
static void C_ccall f_911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_931)
static void C_ccall f_931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_927)
static void C_ccall f_927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_871)
static void C_ccall f_871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_400)
static void C_ccall f_400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_817)
static void C_ccall f_817(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_821)
static void C_ccall f_821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_824)
static void C_ccall f_824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_831)
static void C_ccall f_831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_847)
static void C_ccall f_847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_815)
static void C_ccall f_815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_403)
static void C_ccall f_403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_788)
static void C_ccall f_788(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_792)
static void C_ccall f_792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_807)
static void C_ccall f_807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_786)
static void C_ccall f_786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_406)
static void C_ccall f_406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_409)
static void C_ccall f_409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_779)
static void C_ccall f_779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_775)
static void C_ccall f_775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_767)
static void C_ccall f_767(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_757)
static void C_ccall f_757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_765)
static void C_ccall f_765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_413)
static void C_ccall f_413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_542)
static void C_ccall f_542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_554)
static void C_fcall f_554(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_747)
static void C_ccall f_747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_740)
static void C_ccall f_740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_703)
static void C_ccall f_703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_649)
static void C_ccall f_649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_666)
static void C_ccall f_666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_652)
static void C_ccall f_652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_576)
static void C_ccall f_576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_629)
static void C_ccall f_629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_619)
static void C_ccall f_619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_579)
static void C_ccall f_579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_546)
static void C_ccall f_546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_549)
static void C_ccall f_549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_530)
static void C_ccall f_530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_537)
static void C_ccall f_537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_522)
static void C_ccall f_522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_528)
static void C_ccall f_528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_525)
static void C_ccall f_525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_415)
static void C_ccall f_415(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_421)
static void C_fcall f_421(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_456)
static void C_fcall f_456(C_word t0,C_word t1) C_noret;
C_noret_decl(f_482)
static void C_ccall f_482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_478)
static void C_ccall f_478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_435)
static void C_ccall f_435(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1242)
static void C_fcall trf_1242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1242(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1242(t0,t1);}

C_noret_decl(trf_1245)
static void C_fcall trf_1245(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1245(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1245(t0,t1);}

C_noret_decl(trf_1285)
static void C_fcall trf_1285(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1285(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1285(t0,t1);}

C_noret_decl(trf_1141)
static void C_fcall trf_1141(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1141(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1141(t0,t1);}

C_noret_decl(trf_554)
static void C_fcall trf_554(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_554(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_554(t0,t1,t2);}

C_noret_decl(trf_421)
static void C_fcall trf_421(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_421(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_421(t0,t1,t2,t3,t4);}

C_noret_decl(trf_456)
static void C_fcall trf_456(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_456(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_456(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1098)){
C_save(t1);
C_rereclaim2(1098*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,89);
lf[0]=C_h_intern(&lf[0],33,"\003syschicken-ffi-macro-environment");
lf[1]=C_h_intern(&lf[1],27,"\010compilercompiler-arguments");
lf[2]=C_h_intern(&lf[2],29,"\010compilerprocess-command-line");
lf[3]=C_h_intern(&lf[3],7,"reverse");
lf[4]=C_h_intern(&lf[4],14,"string->symbol");
lf[5]=C_h_intern(&lf[5],9,"substring");
lf[6]=C_h_intern(&lf[6],25,"\003sysimplicit-exit-handler");
lf[7]=C_h_intern(&lf[7],17,"user-options-pass");
lf[8]=C_h_intern(&lf[8],4,"exit");
lf[9]=C_h_intern(&lf[9],19,"compile-source-file");
lf[10]=C_h_intern(&lf[10],14,"optimize-level");
lf[11]=C_h_intern(&lf[11],22,"optimize-leaf-routines");
lf[12]=C_h_intern(&lf[12],5,"cons*");
lf[13]=C_h_intern(&lf[13],5,"local");
lf[14]=C_h_intern(&lf[14],6,"inline");
lf[15]=C_h_intern(&lf[15],6,"unsafe");
lf[16]=C_h_intern(&lf[16],25,"\010compilercompiler-warning");
lf[17]=C_h_intern(&lf[17],5,"usage");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\047invalid optimization level ~S - ignored");
lf[19]=C_h_intern(&lf[19],11,"debug-level");
lf[20]=C_h_intern(&lf[20],14,"no-lambda-info");
lf[21]=C_h_intern(&lf[21],8,"no-trace");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000 invalid debug level ~S - ignored");
lf[23]=C_h_intern(&lf[23],14,"benchmark-mode");
lf[24]=C_h_intern(&lf[24],17,"fixnum-arithmetic");
lf[25]=C_h_intern(&lf[25],18,"disable-interrupts");
lf[26]=C_h_intern(&lf[26],5,"block");
lf[27]=C_h_intern(&lf[27],11,"lambda-lift");
lf[28]=C_h_intern(&lf[28],31,"\010compilervalid-compiler-options");
lf[29]=C_h_intern(&lf[29],45,"\010compilervalid-compiler-options-with-argument");
lf[30]=C_h_intern(&lf[30],4,"quit");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~s\047 option");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000&invalid compiler option `~a\047 - ignored");
lf[33]=C_h_intern(&lf[33],4,"conc");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[35]=C_h_intern(&lf[35],6,"append");
lf[36]=C_h_intern(&lf[36],4,"argv");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[38]=C_h_intern(&lf[38],6,"remove");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[40]=C_h_intern(&lf[40],12,"string-split");
lf[41]=C_h_intern(&lf[41],6,"getenv");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\017CHICKEN_OPTIONS");
lf[43]=C_h_intern(&lf[43],16,"\003sysmacro-subset");
lf[44]=C_h_intern(&lf[44],28,"\003sysextend-macro-environment");
lf[45]=C_h_intern(&lf[45],15,"foreign-declare");
lf[46]=C_h_intern(&lf[46],12,"\004coredeclare");
lf[47]=C_h_intern(&lf[47],10,"\003sysappend");
lf[48]=C_h_intern(&lf[48],16,"\003syscheck-syntax");
lf[49]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\000");
lf[50]=C_h_intern(&lf[50],18,"\003syser-transformer");
lf[51]=C_h_intern(&lf[51],13,"foreign-value");
lf[52]=C_h_intern(&lf[52],23,"define-foreign-variable");
lf[53]=C_h_intern(&lf[53],5,"begin");
lf[54]=C_h_intern(&lf[54],6,"gensym");
lf[55]=C_h_intern(&lf[55],5,"code_");
lf[56]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[57]=C_h_intern(&lf[57],12,"foreign-code");
lf[58]=C_h_intern(&lf[58],11,"\004coreinline");
lf[59]=C_h_intern(&lf[59],7,"sprintf");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\0007static C_word ~A() { ~A\012; return C_SCHEME_UNDEFINED; }\012");
lf[61]=C_h_intern(&lf[61],18,"string-intersperse");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[63]=C_h_intern(&lf[63],7,"declare");
lf[64]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\000");
lf[65]=C_h_intern(&lf[65],12,"let-location");
lf[66]=C_h_intern(&lf[66],17,"\004corelet-location");
lf[67]=C_h_intern(&lf[67],10,"fold-right");
lf[68]=C_h_intern(&lf[68],10,"append-map");
lf[69]=C_h_intern(&lf[69],7,"\003sysmap");
lf[70]=C_h_intern(&lf[70],3,"let");
lf[71]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001\376\377\001\000\000"
"\000\000\376\001\000\000\001_");
lf[72]=C_h_intern(&lf[72],15,"define-location");
lf[73]=C_h_intern(&lf[73],9,"\004coreset!");
lf[74]=C_h_intern(&lf[74],24,"define-external-variable");
lf[75]=C_h_intern(&lf[75],14,"symbol->string");
lf[76]=C_h_intern(&lf[76],9,"\003syserror");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[78]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[79]=C_h_intern(&lf[79],15,"define-external");
lf[80]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[81]=C_h_intern(&lf[81],5,"quote");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[83]=C_h_intern(&lf[83],29,"\004coreforeign-callback-wrapper");
lf[84]=C_h_intern(&lf[84],6,"lambda");
lf[85]=C_h_intern(&lf[85],6,"define");
lf[86]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376"
"\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[87]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376"
"\001\000\000\001_\376\377\001\000\000\000\001");
lf[88]=C_h_intern(&lf[88],21,"\003sysmacro-environment");
C_register_lf2(lf,89,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_333,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k331 */
static void C_ccall f_333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_336,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k334 in k331 */
static void C_ccall f_336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_339,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k337 in k334 in k331 */
static void C_ccall f_339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_342,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k340 in k337 in k334 in k331 */
static void C_ccall f_342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_345,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_348,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_351,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_syntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_354,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_357,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_4_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_360,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_363,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_366,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_support_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_369,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_compiler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_372,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_375,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_driver_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_378,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_platform_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_381,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_backend_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_384,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_388,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[88]))(2,*((C_word*)lf[88]+1),t2);}

/* k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_391,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1230,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1232,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t3,t4);}

/* a1231 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1232(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1232,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1239,a[2]=t3,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* r59 */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[81]);}

/* k1237 in a1231 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1242,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=t2;
f_1242(t4,(C_word)C_i_stringp(t3));}
else{
t3=t2;
f_1242(t3,C_SCHEME_FALSE);}}

/* k1240 in k1237 in a1231 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_fcall f_1242(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1242,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1245,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=t1;
if(C_truep(t3)){
t4=t2;
f_1245(t4,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_1245(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t2;
f_1245(t4,C_SCHEME_FALSE);}}}

/* k1243 in k1240 in k1237 in a1231 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_fcall f_1245(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1245,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1251,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t2,lf[79],((C_word*)t0)[5],lf[80]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1350,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t2,lf[79],((C_word*)t0)[5],lf[86]);}
else{
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t2,lf[79],((C_word*)t0)[5],lf[87]);}}}

/* k1348 in k1243 in k1240 in k1237 in a1231 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1350,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_i_cadr(((C_word*)t0)[4]):(C_word)C_i_car(((C_word*)t0)[4]));
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1363,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* r59 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[85]);}

/* k1361 in k1348 in k1243 in k1240 in k1237 in a1231 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1363,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[81],t4);
t6=(C_truep(((C_word*)t0)[6])?(C_word)C_i_car(((C_word*)t0)[5]):lf[82]);
t7=(C_truep(((C_word*)t0)[6])?(C_word)C_i_caddr(((C_word*)t0)[5]):(C_word)C_i_cadr(((C_word*)t0)[5]));
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,lf[81],t8);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1459,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=t2,a[9]=t5,a[10]=t6,a[11]=t9,tmp=(C_word)a,a+=12,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1461,tmp=(C_word)a,a+=2,tmp);
/* map */
t12=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,((C_word*)t0)[3]);}

/* a1460 in k1361 in k1348 in k1243 in k1240 in k1237 in a1231 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1461(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1461,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k1457 in k1361 in k1348 in k1243 in k1240 in k1237 in a1231 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1459,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[81],t2);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1423,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
/* r59 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[84]);}

/* k1421 in k1457 in k1361 in k1348 in k1243 in k1240 in k1237 in a1231 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1431,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1447,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a1446 in k1421 in k1457 in k1361 in k1348 in k1243 in k1240 in k1237 in a1231 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1447(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1447,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k1429 in k1421 in k1457 in k1361 in k1348 in k1243 in k1240 in k1237 in a1231 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1435,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t3=(C_truep(((C_word*)t0)[3])?(C_word)C_i_cdddr(((C_word*)t0)[2]):(C_word)C_i_cddr(((C_word*)t0)[2]));
/* ##sys#append */
t4=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k1433 in k1429 in k1421 in k1457 in k1361 in k1348 in k1243 in k1240 in k1237 in a1231 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1435,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[83],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t10);
t12=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t11));}

/* k1249 in k1243 in k1240 in k1237 in a1231 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1251,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1261,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* r59 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[53]);}

/* k1259 in k1249 in k1243 in k1240 in k1237 in a1231 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1335,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* r59 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[52]);}

/* k1333 in k1259 in k1249 in k1243 in k1240 in k1237 in a1231 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1335,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1315,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* r59 */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[74]);}

/* k1313 in k1333 in k1259 in k1249 in k1243 in k1240 in k1237 in a1231 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1315,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1281,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1285,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cddr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_caddr(((C_word*)t0)[6]);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[73],t12);
t14=t8;
f_1285(t14,(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST));}
else{
t10=t8;
f_1285(t10,C_SCHEME_END_OF_LIST);}}

/* k1283 in k1313 in k1333 in k1259 in k1249 in k1243 in k1240 in k1237 in a1231 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_fcall f_1285(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k1279 in k1313 in k1333 in k1259 in k1249 in k1243 in k1240 in k1237 in a1231 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1281,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k1228 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[79],C_SCHEME_END_OF_LIST,t1);}

/* k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_394,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1089,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1091,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t3,t4);}

/* a1090 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1091(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1091,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1095,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t5,lf[72],t2,lf[78]);}

/* k1093 in a1090 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1095,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1107,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_1107(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_1107(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[77],t4);}}}

/* k1105 in k1093 in a1090 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1107,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1110,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1207,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
((C_proc2)C_retrieve_symbol_proc(lf[54]))(2,*((C_word*)lf[54]+1),t3);}

/* k1205 in k1105 in k1093 in a1090 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r112 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1108 in k1105 in k1093 in a1090 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1110,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* r112 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[53]);}

/* k1115 in k1108 in k1105 in k1093 in a1090 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1117,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1187,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* r112 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[52]);}

/* k1185 in k1115 in k1108 in k1105 in k1093 in a1090 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1203,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[75]+1)))(3,*((C_word*)lf[75]+1),t2,((C_word*)t0)[6]);}

/* k1201 in k1185 in k1115 in k1108 in k1105 in k1093 in a1090 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1203,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1167,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* r112 */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[74]);}

/* k1165 in k1201 in k1185 in k1115 in k1108 in k1105 in k1093 in a1090 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1167,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1137,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1141,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t9=(C_word)C_i_car(((C_word*)t0)[2]);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t10);
t12=(C_word)C_a_i_cons(&a,2,lf[73],t11);
t13=t8;
f_1141(t13,(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST));}
else{
t9=t8;
f_1141(t9,C_SCHEME_END_OF_LIST);}}

/* k1139 in k1165 in k1201 in k1185 in k1115 in k1108 in k1105 in k1093 in a1090 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_fcall f_1141(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k1135 in k1165 in k1201 in k1185 in k1115 in k1108 in k1105 in k1093 in a1090 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1137,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k1087 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[72],C_SCHEME_END_OF_LIST,t1);}

/* k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_397,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_939,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_941,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t3,t4);}

/* a940 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_941(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_941,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_945,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t5,lf[65],t2,lf[71]);}

/* k943 in a940 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_945,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_954,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* r139 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[70]);}

/* k952 in k943 in a940 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_957,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1077,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a1076 in k952 in k943 in a940 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1077(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1077,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1085,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
((C_proc2)C_retrieve_symbol_proc(lf[54]))(2,*((C_word*)lf[54]+1),t3);}

/* k1083 in a1076 in k952 in k943 in a940 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r139 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k955 in k952 in k943 in a940 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_968,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1053,tmp=(C_word)a,a+=2,tmp);
/* append-map */
((C_proc5)C_retrieve_symbol_proc(lf[68]))(5,*((C_word*)lf[68]+1),t2,t3,((C_word*)t0)[3],t1);}

/* a1052 in k955 in k952 in k943 in a940 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1053,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cddr(t2);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}}

/* k966 in k955 in k952 in k943 in a940 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_976,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_978,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1051,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#append */
t5=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1049 in k966 in k955 in k952 in k943 in a940 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_1051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1051,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
/* fold-right */
((C_proc6)C_retrieve_symbol_proc(lf[67]))(6,*((C_word*)lf[67]+1),((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a977 in k966 in k955 in k952 in k943 in a940 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_978(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_978,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t2);
t6=(C_word)C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t3,t9);
t11=(C_word)C_a_i_cons(&a,2,t8,t10);
t12=(C_word)C_a_i_cons(&a,2,t7,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,lf[66],t12));}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t8,t9);
t11=(C_word)C_a_i_cons(&a,2,t7,t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,lf[66],t11));}}

/* k974 in k966 in k955 in k952 in k943 in a940 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_976,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k937 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[65],C_SCHEME_END_OF_LIST,t1);}

/* k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_400,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_871,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_873,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t3,t4);}

/* a872 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_873(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_873,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_877,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t5,lf[57],t2,lf[64]);}

/* k875 in a872 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_880,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* gensym */
((C_proc3)C_retrieve_symbol_proc(lf[54]))(3,*((C_word*)lf[54]+1),t2,lf[55]);}

/* k878 in k875 in a872 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_887,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* r179 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[53]);}

/* k885 in k878 in k875 in a872 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_911,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* r179 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[63]);}

/* k909 in k885 in k878 in k875 in a872 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_927,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_931,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),t3,t4,lf[62]);}

/* k929 in k909 in k885 in k878 in k875 in a872 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[59]))(5,*((C_word*)lf[59]+1),((C_word*)t0)[3],lf[60],((C_word*)t0)[2],t1);}

/* k925 in k909 in k885 in k878 in k875 in a872 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_927,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[45],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[58],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t5,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k869 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[57],C_SCHEME_END_OF_LIST,t1);}

/* k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_403,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_815,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_817,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t3,t4);}

/* a816 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_817(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_817,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_821,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t5,lf[51],t2,lf[56]);}

/* k819 in a816 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* gensym */
((C_proc3)C_retrieve_symbol_proc(lf[54]))(3,*((C_word*)lf[54]+1),t2,lf[55]);}

/* k822 in k819 in a816 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* r190 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[53]);}

/* k829 in k822 in k819 in a816 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_847,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* r190 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[52]);}

/* k845 in k829 in k822 in k819 in a816 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_847,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[5]);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,t1,t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k813 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[51],C_SCHEME_END_OF_LIST,t1);}

/* k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_406,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_786,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_788,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t3,t4);}

/* a787 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_788(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_788,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_792,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t5,lf[45],t2,lf[49]);}

/* k790 in a787 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_807,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k805 in k790 in a787 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_807,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[45],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[46],t3));}

/* k784 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[45],C_SCHEME_END_OF_LIST,t1);}

/* k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_409,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#macro-subset */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t2,((C_word*)t0)[2]);}

/* k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_409,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! chicken-ffi-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_413,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_757,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_767,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_775,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_779,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 80   getenv */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t7,lf[42]);}

/* k777 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[39]);
/* chicken.scm: 80   string-split */
((C_proc3)C_retrieve_symbol_proc(lf[40]))(3,*((C_word*)lf[40]+1),((C_word*)t0)[2],t2);}

/* k773 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 78   remove */
((C_proc4)C_retrieve_symbol_proc(lf[38]))(4,*((C_word*)lf[38]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a766 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_767(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_767,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_string_equal_p(t2,lf[37]));}

/* k755 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_757,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_765,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 81   argv */
((C_proc2)C_retrieve_symbol_proc(lf[36]))(2,*((C_word*)lf[36]+1),t2);}

/* k763 in k755 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(t1);
/* chicken.scm: 77   append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[35]+1)))(4,*((C_word*)lf[35]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k411 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_413,2,t0,t1);}
t2=C_mutate((C_word*)lf[1]+1 /* (set! compiler-arguments ...) */,t1);
t3=C_mutate((C_word*)lf[2]+1 /* (set! process-command-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_415,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_522,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_530,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_542,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}

/* a541 in k411 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_542,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_546,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_554,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_554(t9,t5,((C_word*)t4)[1]);}

/* loop in a541 in k411 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_fcall f_554(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_554,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_eqp(lf[10],t3);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_576,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t4);
/* chicken.scm: 114  string->number */
C_string_to_number(3,0,t6,t7);}
else{
t6=(C_word)C_eqp(lf[19],t3);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_649,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_car(t4);
/* chicken.scm: 130  string->number */
C_string_to_number(3,0,t7,t8);}
else{
t7=(C_word)C_eqp(lf[23],t3);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_703,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 139  cons* */
((C_proc12)C_retrieve_symbol_proc(lf[12]))(12,*((C_word*)lf[12]+1),t8,lf[24],lf[25],lf[21],lf[15],lf[11],lf[26],lf[27],lf[20],lf[14],((C_word*)((C_word*)t0)[2])[1]);}
else{
if(C_truep((C_word)C_i_memq(t3,C_retrieve(lf[28])))){
/* chicken.scm: 144  loop */
t17=t1;
t18=t4;
t1=t17;
t2=t18;
goto loop;}
else{
if(C_truep((C_word)C_i_memq(t3,C_retrieve(lf[29])))){
if(C_truep((C_word)C_i_pairp(t4))){
t8=(C_word)C_i_cdr(t4);
/* chicken.scm: 147  loop */
t17=t1;
t18=t8;
t1=t17;
t2=t18;
goto loop;}
else{
/* chicken.scm: 148  quit */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t1,lf[31],t3);}}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_740,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_747,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_stringp(t3))){
t10=t9;
f_747(2,t10,t3);}
else{
/* chicken.scm: 152  conc */
((C_proc4)C_retrieve_symbol_proc(lf[33]))(4,*((C_word*)lf[33]+1),t9,lf[34],t3);}}}}}}}}

/* k745 in loop in a541 in k411 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 150  compiler-warning */
((C_proc5)C_retrieve_symbol_proc(lf[16]))(5,*((C_word*)lf[16]+1),((C_word*)t0)[2],lf[17],lf[32],t1);}

/* k738 in loop in a541 in k411 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 153  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_554(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k701 in loop in a541 in k411 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* chicken.scm: 143  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_554(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k647 in loop in a541 in k411 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_652,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
switch(t1){
case C_fix(0):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_666,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 132  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[12]))(5,*((C_word*)lf[12]+1),t3,lf[20],lf[21],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,lf[21],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_652(2,t5,t4);
case C_fix(2):
t3=t2;
f_652(2,t3,C_SCHEME_FALSE);
default:
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 135  compiler-warning */
((C_proc5)C_retrieve_symbol_proc(lf[16]))(5,*((C_word*)lf[16]+1),t2,lf[17],lf[22],t3);}}

/* k664 in k647 in loop in a541 in k411 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_652(2,t3,t2);}

/* k650 in k647 in loop in a541 in k411 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 136  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_554(t3,((C_word*)t0)[2],t2);}

/* k574 in loop in a541 in k411 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_579,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
switch(t1){
case C_fix(0):
t3=t2;
f_579(2,t3,C_SCHEME_FALSE);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,lf[11],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_579(2,t5,t4);
case C_fix(2):
t3=(C_word)C_a_i_cons(&a,2,lf[11],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_579(2,t5,t4);
case C_fix(3):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_619,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 123  cons* */
((C_proc6)C_retrieve_symbol_proc(lf[12]))(6,*((C_word*)lf[12]+1),t3,lf[11],lf[13],lf[14],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(4):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_629,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 126  cons* */
((C_proc7)C_retrieve_symbol_proc(lf[12]))(7,*((C_word*)lf[12]+1),t3,lf[11],lf[13],lf[14],lf[15],((C_word*)((C_word*)t0)[2])[1]);
default:
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 127  compiler-warning */
((C_proc5)C_retrieve_symbol_proc(lf[16]))(5,*((C_word*)lf[16]+1),t2,lf[17],lf[18],t3);}}

/* k627 in k574 in loop in a541 in k411 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_579(2,t3,t2);}

/* k617 in k574 in loop in a541 in k411 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_579(2,t3,t2);}

/* k577 in k574 in loop in a541 in k411 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 128  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_554(t3,((C_word*)t0)[2],t2);}

/* k544 in a541 in k411 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_549,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t2,C_retrieve(lf[9]),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k547 in k544 in a541 in k411 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 155  exit */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),((C_word*)t0)[2]);}

/* a529 in k411 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_537,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 108  user-options-pass */
((C_proc2)C_retrieve_symbol_proc(lf[7]))(2,*((C_word*)lf[7]+1),t2);}

/* k535 in a529 in k411 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_retrieve(lf[2]));
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_retrieve(lf[1]));}

/* k520 in k411 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_525,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_528,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[6]))(2,*((C_word*)lf[6]+1),t3);}

/* k526 in k520 in k411 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k523 in k520 in k411 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##compiler#process-command-line in k411 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_415(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_415,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_421,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_421(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in ##compiler#process-command-line in k411 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_fcall f_421(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_421,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_435,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 93   reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[3]+1)))(3,*((C_word*)lf[3]+1),t5,t3);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_string_length(t5);
t7=(C_word)C_i_string_ref(t5,C_fix(0));
t8=(C_word)C_eqp(C_make_character(45),t7);
t9=(C_truep(t8)?(C_word)C_fixnum_greaterp(t6,C_fix(1)):C_SCHEME_FALSE);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_456,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t6,C_fix(1)))){
t11=(C_word)C_i_string_ref(t5,C_fix(1));
t12=t10;
f_456(t12,(C_word)C_eqp(C_make_character(58),t11));}
else{
t11=t10;
f_456(t11,C_SCHEME_FALSE);}}
else{
if(C_truep(t4)){
t10=(C_word)C_i_cdr(t2);
t11=(C_word)C_a_i_cons(&a,2,t5,t3);
/* chicken.scm: 102  loop */
t17=t1;
t18=t10;
t19=t11;
t20=t4;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}
else{
t10=(C_word)C_i_cdr(t2);
/* chicken.scm: 103  loop */
t17=t1;
t18=t10;
t19=t3;
t20=t5;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}}}}

/* k454 in loop in ##compiler#process-command-line in k411 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_fcall f_456(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_456,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* chicken.scm: 99   loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_421(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_478,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_482,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 100  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[5]+1)))(5,*((C_word*)lf[5]+1),t4,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]);}}

/* k480 in k454 in loop in ##compiler#process-command-line in k411 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 100  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[4]+1)))(3,*((C_word*)lf[4]+1),((C_word*)t0)[2],t1);}

/* k476 in k454 in loop in ##compiler#process-command-line in k411 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_478,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* chicken.scm: 100  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_421(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k433 in loop in ##compiler#process-command-line in k411 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 */
static void C_ccall f_435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 93   values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[120] = {
{"toplevel:chicken_scm",(void*)C_toplevel},
{"f_333:chicken_scm",(void*)f_333},
{"f_336:chicken_scm",(void*)f_336},
{"f_339:chicken_scm",(void*)f_339},
{"f_342:chicken_scm",(void*)f_342},
{"f_345:chicken_scm",(void*)f_345},
{"f_348:chicken_scm",(void*)f_348},
{"f_351:chicken_scm",(void*)f_351},
{"f_354:chicken_scm",(void*)f_354},
{"f_357:chicken_scm",(void*)f_357},
{"f_360:chicken_scm",(void*)f_360},
{"f_363:chicken_scm",(void*)f_363},
{"f_366:chicken_scm",(void*)f_366},
{"f_369:chicken_scm",(void*)f_369},
{"f_372:chicken_scm",(void*)f_372},
{"f_375:chicken_scm",(void*)f_375},
{"f_378:chicken_scm",(void*)f_378},
{"f_381:chicken_scm",(void*)f_381},
{"f_384:chicken_scm",(void*)f_384},
{"f_388:chicken_scm",(void*)f_388},
{"f_1232:chicken_scm",(void*)f_1232},
{"f_1239:chicken_scm",(void*)f_1239},
{"f_1242:chicken_scm",(void*)f_1242},
{"f_1245:chicken_scm",(void*)f_1245},
{"f_1350:chicken_scm",(void*)f_1350},
{"f_1363:chicken_scm",(void*)f_1363},
{"f_1461:chicken_scm",(void*)f_1461},
{"f_1459:chicken_scm",(void*)f_1459},
{"f_1423:chicken_scm",(void*)f_1423},
{"f_1447:chicken_scm",(void*)f_1447},
{"f_1431:chicken_scm",(void*)f_1431},
{"f_1435:chicken_scm",(void*)f_1435},
{"f_1251:chicken_scm",(void*)f_1251},
{"f_1261:chicken_scm",(void*)f_1261},
{"f_1335:chicken_scm",(void*)f_1335},
{"f_1315:chicken_scm",(void*)f_1315},
{"f_1285:chicken_scm",(void*)f_1285},
{"f_1281:chicken_scm",(void*)f_1281},
{"f_1230:chicken_scm",(void*)f_1230},
{"f_391:chicken_scm",(void*)f_391},
{"f_1091:chicken_scm",(void*)f_1091},
{"f_1095:chicken_scm",(void*)f_1095},
{"f_1107:chicken_scm",(void*)f_1107},
{"f_1207:chicken_scm",(void*)f_1207},
{"f_1110:chicken_scm",(void*)f_1110},
{"f_1117:chicken_scm",(void*)f_1117},
{"f_1187:chicken_scm",(void*)f_1187},
{"f_1203:chicken_scm",(void*)f_1203},
{"f_1167:chicken_scm",(void*)f_1167},
{"f_1141:chicken_scm",(void*)f_1141},
{"f_1137:chicken_scm",(void*)f_1137},
{"f_1089:chicken_scm",(void*)f_1089},
{"f_394:chicken_scm",(void*)f_394},
{"f_941:chicken_scm",(void*)f_941},
{"f_945:chicken_scm",(void*)f_945},
{"f_954:chicken_scm",(void*)f_954},
{"f_1077:chicken_scm",(void*)f_1077},
{"f_1085:chicken_scm",(void*)f_1085},
{"f_957:chicken_scm",(void*)f_957},
{"f_1053:chicken_scm",(void*)f_1053},
{"f_968:chicken_scm",(void*)f_968},
{"f_1051:chicken_scm",(void*)f_1051},
{"f_978:chicken_scm",(void*)f_978},
{"f_976:chicken_scm",(void*)f_976},
{"f_939:chicken_scm",(void*)f_939},
{"f_397:chicken_scm",(void*)f_397},
{"f_873:chicken_scm",(void*)f_873},
{"f_877:chicken_scm",(void*)f_877},
{"f_880:chicken_scm",(void*)f_880},
{"f_887:chicken_scm",(void*)f_887},
{"f_911:chicken_scm",(void*)f_911},
{"f_931:chicken_scm",(void*)f_931},
{"f_927:chicken_scm",(void*)f_927},
{"f_871:chicken_scm",(void*)f_871},
{"f_400:chicken_scm",(void*)f_400},
{"f_817:chicken_scm",(void*)f_817},
{"f_821:chicken_scm",(void*)f_821},
{"f_824:chicken_scm",(void*)f_824},
{"f_831:chicken_scm",(void*)f_831},
{"f_847:chicken_scm",(void*)f_847},
{"f_815:chicken_scm",(void*)f_815},
{"f_403:chicken_scm",(void*)f_403},
{"f_788:chicken_scm",(void*)f_788},
{"f_792:chicken_scm",(void*)f_792},
{"f_807:chicken_scm",(void*)f_807},
{"f_786:chicken_scm",(void*)f_786},
{"f_406:chicken_scm",(void*)f_406},
{"f_409:chicken_scm",(void*)f_409},
{"f_779:chicken_scm",(void*)f_779},
{"f_775:chicken_scm",(void*)f_775},
{"f_767:chicken_scm",(void*)f_767},
{"f_757:chicken_scm",(void*)f_757},
{"f_765:chicken_scm",(void*)f_765},
{"f_413:chicken_scm",(void*)f_413},
{"f_542:chicken_scm",(void*)f_542},
{"f_554:chicken_scm",(void*)f_554},
{"f_747:chicken_scm",(void*)f_747},
{"f_740:chicken_scm",(void*)f_740},
{"f_703:chicken_scm",(void*)f_703},
{"f_649:chicken_scm",(void*)f_649},
{"f_666:chicken_scm",(void*)f_666},
{"f_652:chicken_scm",(void*)f_652},
{"f_576:chicken_scm",(void*)f_576},
{"f_629:chicken_scm",(void*)f_629},
{"f_619:chicken_scm",(void*)f_619},
{"f_579:chicken_scm",(void*)f_579},
{"f_546:chicken_scm",(void*)f_546},
{"f_549:chicken_scm",(void*)f_549},
{"f_530:chicken_scm",(void*)f_530},
{"f_537:chicken_scm",(void*)f_537},
{"f_522:chicken_scm",(void*)f_522},
{"f_528:chicken_scm",(void*)f_528},
{"f_525:chicken_scm",(void*)f_525},
{"f_415:chicken_scm",(void*)f_415},
{"f_421:chicken_scm",(void*)f_421},
{"f_456:chicken_scm",(void*)f_456},
{"f_482:chicken_scm",(void*)f_482},
{"f_478:chicken_scm",(void*)f_478},
{"f_435:chicken_scm",(void*)f_435},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
