/* Generated from chicken.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-05-02 09:52
   Version 3.2.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook hostpcre ]
   SVN rev. 10674	compiled 2008-04-30 on debian (Linux)
   command line: chicken.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -extend private-namespace.scm -output-file chicken.c
   used units: library eval data_structures extras srfi_69 srfi_1 match srfi_4 utils support compiler optimizer driver platform backend
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_match_toplevel)
C_externimport void C_ccall C_match_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_4_toplevel)
C_externimport void C_ccall C_srfi_4_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_support_toplevel)
C_externimport void C_ccall C_support_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_compiler_toplevel)
C_externimport void C_ccall C_compiler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_optimizer_toplevel)
C_externimport void C_ccall C_optimizer_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_driver_toplevel)
C_externimport void C_ccall C_driver_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_platform_toplevel)
C_externimport void C_ccall C_platform_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_backend_toplevel)
C_externimport void C_ccall C_backend_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[379];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_688)
static void C_ccall f_688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_691)
static void C_ccall f_691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_694)
static void C_ccall f_694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_697)
static void C_ccall f_697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_700)
static void C_ccall f_700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_703)
static void C_ccall f_703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_706)
static void C_ccall f_706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_709)
static void C_ccall f_709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_712)
static void C_ccall f_712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_715)
static void C_ccall f_715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_718)
static void C_ccall f_718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_721)
static void C_ccall f_721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_724)
static void C_ccall f_724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_727)
static void C_ccall f_727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_730)
static void C_ccall f_730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_736)
static void C_ccall f_736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6914)
static void C_ccall f_6914(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6914)
static void C_ccall f_6914r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6918)
static void C_ccall f_6918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6921)
static void C_ccall f_6921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6924)
static void C_ccall f_6924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6930)
static void C_ccall f_6930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7136)
static void C_ccall f_7136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7116)
static void C_ccall f_7116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7112)
static void C_ccall f_7112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7092)
static void C_ccall f_7092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6955)
static void C_fcall f_6955(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6965)
static void C_ccall f_6965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7084)
static void C_ccall f_7084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6968)
static void C_ccall f_6968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7080)
static void C_ccall f_7080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6971)
static void C_ccall f_6971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7002)
static void C_fcall f_7002(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6982)
static void C_ccall f_6982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6953)
static void C_ccall f_6953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_739)
static void C_ccall f_739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6826)
static void C_ccall f_6826(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6826)
static void C_ccall f_6826r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6843)
static void C_ccall f_6843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6846)
static void C_ccall f_6846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6852)
static void C_fcall f_6852(C_word t0,C_word t1) C_noret;
C_noret_decl(f_742)
static void C_ccall f_742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6785)
static void C_ccall f_6785(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6785)
static void C_ccall f_6785r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6789)
static void C_ccall f_6789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_745)
static void C_ccall f_745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6769)
static void C_ccall f_6769(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6769)
static void C_ccall f_6769r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6779)
static void C_ccall f_6779(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6777)
static void C_ccall f_6777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_748)
static void C_ccall f_748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6692)
static void C_ccall f_6692(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6696)
static void C_ccall f_6696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6764)
static void C_ccall f_6764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6699)
static void C_ccall f_6699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6708)
static void C_ccall f_6708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6755)
static void C_ccall f_6755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6722)
static void C_ccall f_6722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6730)
static void C_ccall f_6730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6732)
static void C_fcall f_6732(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6749)
static void C_ccall f_6749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6714)
static void C_ccall f_6714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6706)
static void C_ccall f_6706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_751)
static void C_ccall f_751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6632)
static void C_ccall f_6632(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6632)
static void C_ccall f_6632r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6636)
static void C_fcall f_6636(C_word t0,C_word t1) C_noret;
C_noret_decl(f_754)
static void C_ccall f_754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6573)
static void C_ccall f_6573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6573)
static void C_ccall f_6573r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6577)
static void C_ccall f_6577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6604)
static void C_fcall f_6604(C_word t0,C_word t1) C_noret;
C_noret_decl(f_757)
static void C_ccall f_757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6399)
static void C_ccall f_6399(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6399)
static void C_ccall f_6399r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6403)
static void C_ccall f_6403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6406)
static void C_ccall f_6406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6567)
static void C_ccall f_6567(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6409)
static void C_ccall f_6409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6561)
static void C_ccall f_6561(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6412)
static void C_ccall f_6412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6559)
static void C_ccall f_6559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6523)
static void C_ccall f_6523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6537)
static void C_fcall f_6537(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6551)
static void C_ccall f_6551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6531)
static void C_ccall f_6531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6527)
static void C_ccall f_6527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6419)
static void C_ccall f_6419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6515)
static void C_ccall f_6515(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6491)
static void C_ccall f_6491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6509)
static void C_ccall f_6509(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6499)
static void C_ccall f_6499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6495)
static void C_ccall f_6495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6487)
static void C_ccall f_6487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6471)
static void C_ccall f_6471(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6447)
static void C_ccall f_6447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6465)
static void C_ccall f_6465(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6455)
static void C_ccall f_6455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6451)
static void C_ccall f_6451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6443)
static void C_ccall f_6443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_760)
static void C_ccall f_760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6304)
static void C_ccall f_6304(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6304)
static void C_ccall f_6304r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6340)
static void C_fcall f_6340(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6353)
static void C_ccall f_6353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6311)
static void C_ccall f_6311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_763)
static void C_ccall f_763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6194)
static void C_ccall f_6194(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6194)
static void C_ccall f_6194r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6198)
static void C_ccall f_6198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6201)
static void C_ccall f_6201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6204)
static void C_ccall f_6204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6207)
static void C_ccall f_6207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6298)
static void C_ccall f_6298(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6210)
static void C_ccall f_6210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6292)
static void C_ccall f_6292(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6213)
static void C_ccall f_6213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6286)
static void C_ccall f_6286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6290)
static void C_ccall f_6290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6220)
static void C_ccall f_6220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6258)
static void C_ccall f_6258(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6256)
static void C_ccall f_6256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_766)
static void C_ccall f_766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6184)
static void C_ccall f_6184(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6184)
static void C_ccall f_6184r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_769)
static void C_ccall f_769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6170)
static void C_ccall f_6170(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6170)
static void C_ccall f_6170r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_772)
static void C_ccall f_772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_846)
static void C_ccall f_846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_849)
static void C_ccall f_849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5908)
static void C_ccall f_5908(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5912)
static void C_ccall f_5912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5921)
static void C_ccall f_5921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6130)
static void C_fcall f_6130(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6143)
static void C_ccall f_6143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5924)
static void C_ccall f_5924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6120)
static void C_ccall f_6120(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6128)
static void C_ccall f_6128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5927)
static void C_ccall f_5927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6074)
static void C_fcall f_6074(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6107)
static void C_ccall f_6107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6114)
static void C_ccall f_6114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6090)
static void C_fcall f_6090(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5939)
static void C_ccall f_5939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6068)
static void C_ccall f_6068(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5946)
static void C_ccall f_5946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5948)
static void C_fcall f_5948(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6062)
static void C_ccall f_6062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5982)
static void C_fcall f_5982(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6036)
static void C_ccall f_6036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6013)
static void C_ccall f_6013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5993)
static void C_ccall f_5993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5968)
static void C_ccall f_5968(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5976)
static void C_ccall f_5976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5966)
static void C_ccall f_5966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5928)
static void C_ccall f_5928(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5868)
static void C_fcall f_5868(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5891)
static void C_ccall f_5891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5895)
static void C_ccall f_5895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5837)
static void C_fcall f_5837(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5858)
static void C_ccall f_5858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_852)
static void C_ccall f_852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5786)
static void C_ccall f_5786(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5790)
static void C_ccall f_5790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5801)
static void C_fcall f_5801(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5826)
static void C_ccall f_5826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_855)
static void C_ccall f_855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5666)
static void C_ccall f_5666(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5670)
static void C_ccall f_5670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5780)
static void C_ccall f_5780(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5778)
static void C_ccall f_5778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5679)
static void C_ccall f_5679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5766)
static void C_ccall f_5766(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5774)
static void C_ccall f_5774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5682)
static void C_ccall f_5682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5760)
static void C_ccall f_5760(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5702)
static void C_ccall f_5702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5712)
static void C_ccall f_5712(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5732)
static void C_ccall f_5732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5738)
static void C_ccall f_5738(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5746)
static void C_ccall f_5746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5736)
static void C_ccall f_5736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5710)
static void C_ccall f_5710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5706)
static void C_ccall f_5706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5683)
static void C_ccall f_5683(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_858)
static void C_ccall f_858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5645)
static void C_ccall f_5645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5649)
static void C_ccall f_5649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_861)
static void C_ccall f_861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5635)
static void C_ccall f_5635(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_867)
static void C_ccall f_867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_876)
static void C_fcall f_876(C_word t0,C_word t1) C_noret;
C_noret_decl(f_892)
static void C_fcall f_892(C_word t0,C_word t1) C_noret;
C_noret_decl(f_879)
static void C_ccall f_879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_940)
static void C_ccall f_940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5614)
static void C_ccall f_5614(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5618)
static void C_ccall f_5618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_943)
static void C_ccall f_943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5498)
static void C_ccall f_5498(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5502)
static void C_ccall f_5502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5511)
static void C_fcall f_5511(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5525)
static void C_fcall f_5525(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5589)
static void C_ccall f_5589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5571)
static void C_ccall f_5571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5554)
static void C_ccall f_5554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_946)
static void C_ccall f_946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5399)
static void C_ccall f_5399(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5409)
static void C_ccall f_5409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5422)
static void C_fcall f_5422(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5438)
static void C_ccall f_5438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5476)
static void C_ccall f_5476(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5474)
static void C_ccall f_5474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5466)
static void C_ccall f_5466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5420)
static void C_ccall f_5420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_949)
static void C_ccall f_949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5310)
static void C_ccall f_5310(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5320)
static void C_ccall f_5320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5333)
static void C_fcall f_5333(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5349)
static void C_ccall f_5349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5377)
static void C_ccall f_5377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5331)
static void C_ccall f_5331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_952)
static void C_ccall f_952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5024)
static void C_ccall f_5024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5024)
static void C_ccall f_5024r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5221)
static void C_ccall f_5221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5224)
static void C_ccall f_5224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5227)
static void C_ccall f_5227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5300)
static void C_ccall f_5300(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5308)
static void C_ccall f_5308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5243)
static void C_ccall f_5243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5246)
static void C_ccall f_5246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5249)
static void C_ccall f_5249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5252)
static void C_ccall f_5252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5290)
static void C_ccall f_5290(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5298)
static void C_ccall f_5298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5255)
static void C_ccall f_5255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5035)
static void C_ccall f_5035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5039)
static void C_ccall f_5039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5043)
static void C_ccall f_5043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5045)
static void C_fcall f_5045(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5090)
static void C_ccall f_5090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5102)
static void C_ccall f_5102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5098)
static void C_ccall f_5098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5066)
static void C_ccall f_5066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5258)
static void C_ccall f_5258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5118)
static void C_fcall f_5118(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5218)
static void C_ccall f_5218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5182)
static void C_ccall f_5182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5152)
static void C_ccall f_5152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5261)
static void C_ccall f_5261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5228)
static void C_fcall f_5228(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5240)
static void C_ccall f_5240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5236)
static void C_ccall f_5236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_955)
static void C_ccall f_955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4967)
static void C_ccall f_4967(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4971)
static void C_ccall f_4971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_958)
static void C_ccall f_958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4961)
static void C_ccall f_4961(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_961)
static void C_ccall f_961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4808)
static void C_ccall f_4808(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4808)
static void C_ccall f_4808r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4812)
static void C_ccall f_4812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4815)
static void C_ccall f_4815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4818)
static void C_ccall f_4818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4831)
static void C_fcall f_4831(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4881)
static void C_ccall f_4881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4892)
static void C_ccall f_4892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4829)
static void C_ccall f_4829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_964)
static void C_ccall f_964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4532)
static void C_ccall f_4532(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4566)
static void C_ccall f_4566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4569)
static void C_ccall f_4569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4795)
static void C_ccall f_4795(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4805)
static void C_ccall f_4805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4793)
static void C_ccall f_4793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4572)
static void C_ccall f_4572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4541)
static void C_fcall f_4541(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4555)
static void C_ccall f_4555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4559)
static void C_ccall f_4559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4575)
static void C_ccall f_4575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4578)
static void C_ccall f_4578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4581)
static void C_ccall f_4581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4588)
static void C_ccall f_4588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4602)
static void C_ccall f_4602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4612)
static void C_ccall f_4612(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4616)
static void C_ccall f_4616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4626)
static void C_fcall f_4626(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4642)
static void C_ccall f_4642(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4661)
static void C_fcall f_4661(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4717)
static void C_ccall f_4717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4646)
static void C_ccall f_4646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4659)
static void C_ccall f_4659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4632)
static void C_ccall f_4632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4640)
static void C_ccall f_4640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4630)
static void C_ccall f_4630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4600)
static void C_ccall f_4600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_967)
static void C_ccall f_967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4475)
static void C_ccall f_4475(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4475)
static void C_ccall f_4475r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4515)
static void C_ccall f_4515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4485)
static void C_ccall f_4485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_970)
static void C_ccall f_970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4399)
static void C_ccall f_4399(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4399)
static void C_ccall f_4399r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4403)
static void C_ccall f_4403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4406)
static void C_ccall f_4406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_973)
static void C_ccall f_973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4215)
static void C_ccall f_4215(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4215)
static void C_ccall f_4215r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4219)
static void C_ccall f_4219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4222)
static void C_ccall f_4222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4365)
static void C_ccall f_4365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4361)
static void C_ccall f_4361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4224)
static void C_ccall f_4224(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4312)
static void C_ccall f_4312(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4310)
static void C_ccall f_4310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4280)
static void C_fcall f_4280(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4247)
static void C_fcall f_4247(C_word t0,C_word t1) C_noret;
C_noret_decl(f_976)
static void C_ccall f_976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4025)
static void C_ccall f_4025(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_4025)
static void C_ccall f_4025r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_4032)
static void C_ccall f_4032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4206)
static void C_ccall f_4206(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4204)
static void C_ccall f_4204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4057)
static void C_fcall f_4057(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4083)
static void C_fcall f_4083(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4111)
static void C_fcall f_4111(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4095)
static void C_ccall f_4095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4055)
static void C_ccall f_4055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_979)
static void C_ccall f_979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4016)
static void C_ccall f_4016(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4020)
static void C_ccall f_4020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_982)
static void C_ccall f_982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3997)
static void C_ccall f_3997(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4001)
static void C_ccall f_4001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4010)
static void C_ccall f_4010(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4008)
static void C_ccall f_4008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_985)
static void C_ccall f_985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3978)
static void C_ccall f_3978(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3982)
static void C_ccall f_3982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3991)
static void C_ccall f_3991(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3989)
static void C_ccall f_3989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_988)
static void C_ccall f_988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3850)
static void C_ccall f_3850(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3856)
static void C_fcall f_3856(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3937)
static void C_ccall f_3937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3866)
static void C_ccall f_3866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3869)
static void C_ccall f_3869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3875)
static void C_ccall f_3875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3898)
static void C_ccall f_3898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_991)
static void C_ccall f_991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3707)
static void C_ccall f_3707(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3713)
static void C_fcall f_3713(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3825)
static void C_ccall f_3825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3798)
static void C_ccall f_3798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3723)
static void C_ccall f_3723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3726)
static void C_ccall f_3726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3732)
static void C_ccall f_3732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3743)
static void C_ccall f_3743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3759)
static void C_ccall f_3759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_994)
static void C_ccall f_994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3648)
static void C_ccall f_3648(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_3648)
static void C_ccall f_3648r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_997)
static void C_ccall f_997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3477)
static void C_ccall f_3477(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3477)
static void C_ccall f_3477r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3483)
static void C_fcall f_3483(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3557)
static void C_fcall f_3557(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3560)
static void C_ccall f_3560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3633)
static void C_ccall f_3633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3626)
static void C_ccall f_3626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3618)
static void C_ccall f_3618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3605)
static void C_ccall f_3605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3584)
static void C_ccall f_3584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3493)
static void C_fcall f_3493(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1000)
static void C_ccall f_1000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3426)
static void C_ccall f_3426(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3426)
static void C_ccall f_3426r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1003)
static void C_ccall f_1003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3366)
static void C_ccall f_3366(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3366)
static void C_ccall f_3366r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3376)
static void C_fcall f_3376(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3395)
static void C_ccall f_3395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3379)
static void C_ccall f_3379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1006)
static void C_ccall f_1006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1009)
static void C_ccall f_1009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3333)
static void C_ccall f_3333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1012)
static void C_ccall f_1012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3310)
static void C_ccall f_3310(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3314)
static void C_ccall f_3314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3321)
static void C_ccall f_3321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1015)
static void C_ccall f_1015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3291)
static void C_ccall f_3291(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3302)
static void C_ccall f_3302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1018)
static void C_ccall f_1018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3272)
static void C_ccall f_3272(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3276)
static void C_ccall f_3276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3285)
static void C_ccall f_3285(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3283)
static void C_ccall f_3283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1021)
static void C_ccall f_1021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3253)
static void C_ccall f_3253(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3257)
static void C_ccall f_3257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3266)
static void C_ccall f_3266(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3264)
static void C_ccall f_3264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1024)
static void C_ccall f_1024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3234)
static void C_ccall f_3234(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3238)
static void C_ccall f_3238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3247)
static void C_ccall f_3247(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3245)
static void C_ccall f_3245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1027)
static void C_ccall f_1027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3215)
static void C_ccall f_3215(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3219)
static void C_ccall f_3219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3228)
static void C_ccall f_3228(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3226)
static void C_ccall f_3226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1030)
static void C_ccall f_1030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3115)
static void C_ccall f_3115(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3174)
static void C_ccall f_3174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3128)
static void C_ccall f_3128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1033)
static void C_ccall f_1033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2895)
static void C_ccall f_2895(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2899)
static void C_fcall f_2899(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2902)
static void C_fcall f_2902(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3050)
static void C_ccall f_3050(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3048)
static void C_ccall f_3048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3028)
static void C_ccall f_3028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2908)
static void C_ccall f_2908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2934)
static void C_fcall f_2934(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1036)
static void C_ccall f_1036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2820)
static void C_ccall f_2820(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2820)
static void C_ccall f_2820r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2824)
static void C_ccall f_2824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2847)
static void C_fcall f_2847(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1039)
static void C_ccall f_1039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2714)
static void C_ccall f_2714(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2714)
static void C_ccall f_2714r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2814)
static void C_ccall f_2814(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2718)
static void C_ccall f_2718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2790)
static void C_ccall f_2790(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2725)
static void C_ccall f_2725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2731)
static void C_ccall f_2731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2729)
static void C_ccall f_2729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1042)
static void C_ccall f_1042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2685)
static void C_ccall f_2685(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2689)
static void C_ccall f_2689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2712)
static void C_ccall f_2712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2708)
static void C_ccall f_2708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1045)
static void C_ccall f_1045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2672)
static void C_ccall f_2672(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2676)
static void C_ccall f_2676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1048)
static void C_ccall f_1048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1878)
static void C_ccall f_1878(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1878)
static void C_ccall f_1878r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1882)
static void C_ccall f_1882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1888)
static void C_ccall f_1888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1891)
static void C_ccall f_1891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1897)
static void C_ccall f_1897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2564)
static void C_fcall f_2564(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2643)
static void C_ccall f_2643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2639)
static void C_ccall f_2639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2574)
static void C_fcall f_2574(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2578)
static void C_ccall f_2578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2619)
static void C_ccall f_2619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2609)
static void C_ccall f_2609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2599)
static void C_ccall f_2599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2595)
static void C_ccall f_2595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2581)
static void C_ccall f_2581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1985)
static void C_ccall f_1985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1988)
static void C_ccall f_1988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2558)
static void C_ccall f_2558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2487)
static void C_ccall f_2487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2493)
static void C_ccall f_2493(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2547)
static void C_ccall f_2547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2539)
static void C_ccall f_2539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2522)
static void C_ccall f_2522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2510)
static void C_ccall f_2510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2491)
static void C_ccall f_2491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2475)
static void C_ccall f_2475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2471)
static void C_ccall f_2471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1999)
static void C_fcall f_1999(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2453)
static void C_ccall f_2453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2007)
static void C_fcall f_2007(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2015)
static void C_fcall f_2015(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2021)
static void C_ccall f_2021(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2298)
static void C_ccall f_2298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2410)
static void C_ccall f_2410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2406)
static void C_ccall f_2406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2375)
static void C_ccall f_2375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2398)
static void C_ccall f_2398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2387)
static void C_ccall f_2387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2316)
static void C_fcall f_2316(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2361)
static void C_ccall f_2361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2357)
static void C_ccall f_2357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2333)
static void C_ccall f_2333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2345)
static void C_ccall f_2345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2313)
static void C_fcall f_2313(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2043)
static void C_ccall f_2043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2283)
static void C_ccall f_2283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2279)
static void C_ccall f_2279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2184)
static void C_ccall f_2184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2267)
static void C_ccall f_2267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2256)
static void C_ccall f_2256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2061)
static void C_fcall f_2061(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2170)
static void C_ccall f_2170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2166)
static void C_ccall f_2166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2078)
static void C_ccall f_2078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2150)
static void C_ccall f_2150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2058)
static void C_fcall f_2058(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2011)
static void C_ccall f_2011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2003)
static void C_ccall f_2003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1995)
static void C_ccall f_1995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1942)
static void C_fcall f_1942(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1958)
static void C_ccall f_1958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1899)
static void C_fcall f_1899(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1051)
static void C_ccall f_1051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1864)
static void C_ccall f_1864(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1054)
static void C_ccall f_1054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1524)
static void C_ccall f_1524(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1524)
static void C_ccall f_1524r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1528)
static void C_fcall f_1528(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1531)
static void C_ccall f_1531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1836)
static void C_ccall f_1836(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1534)
static void C_ccall f_1534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1811)
static void C_ccall f_1811(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1537)
static void C_ccall f_1537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1779)
static void C_ccall f_1779(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1540)
static void C_ccall f_1540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1543)
static void C_fcall f_1543(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1546)
static void C_ccall f_1546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1741)
static void C_ccall f_1741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1549)
static void C_ccall f_1549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1737)
static void C_ccall f_1737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1552)
static void C_ccall f_1552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1725)
static void C_ccall f_1725(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1733)
static void C_ccall f_1733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1563)
static void C_ccall f_1563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1687)
static void C_ccall f_1687(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1669)
static void C_ccall f_1669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1665)
static void C_ccall f_1665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1605)
static void C_ccall f_1605(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1595)
static void C_ccall f_1595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1591)
static void C_ccall f_1591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1559)
static void C_ccall f_1559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1057)
static void C_ccall f_1057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1490)
static void C_ccall f_1490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1060)
static void C_ccall f_1060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1428)
static void C_ccall f_1428(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1428)
static void C_ccall f_1428r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1441)
static void C_fcall f_1441(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1467)
static void C_ccall f_1467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1438)
static void C_ccall f_1438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1431)
static void C_fcall f_1431(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1063)
static void C_ccall f_1063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1426)
static void C_ccall f_1426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1419)
static void C_ccall f_1419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1415)
static void C_ccall f_1415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1407)
static void C_ccall f_1407(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1405)
static void C_ccall f_1405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1067)
static void C_ccall f_1067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1196)
static void C_ccall f_1196(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1208)
static void C_fcall f_1208(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1391)
static void C_ccall f_1391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1384)
static void C_ccall f_1384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1347)
static void C_ccall f_1347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1293)
static void C_ccall f_1293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1310)
static void C_ccall f_1310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1296)
static void C_ccall f_1296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1230)
static void C_ccall f_1230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1273)
static void C_ccall f_1273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1253)
static void C_ccall f_1253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1233)
static void C_ccall f_1233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1200)
static void C_ccall f_1200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1203)
static void C_ccall f_1203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1184)
static void C_ccall f_1184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1191)
static void C_ccall f_1191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1176)
static void C_ccall f_1176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1182)
static void C_ccall f_1182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1179)
static void C_ccall f_1179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1069)
static void C_ccall f_1069(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1075)
static void C_fcall f_1075(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1110)
static void C_fcall f_1110(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1136)
static void C_ccall f_1136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1132)
static void C_ccall f_1132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1089)
static void C_ccall f_1089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_773)
static void C_ccall f_773(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_777)
static void C_ccall f_777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_814)
static void C_ccall f_814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_835)
static void C_ccall f_835(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_833)
static void C_ccall f_833(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_6955)
static void C_fcall trf_6955(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6955(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6955(t0,t1,t2,t3);}

C_noret_decl(trf_7002)
static void C_fcall trf_7002(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7002(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7002(t0,t1);}

C_noret_decl(trf_6852)
static void C_fcall trf_6852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6852(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6852(t0,t1);}

C_noret_decl(trf_6732)
static void C_fcall trf_6732(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6732(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6732(t0,t1,t2,t3);}

C_noret_decl(trf_6636)
static void C_fcall trf_6636(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6636(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6636(t0,t1);}

C_noret_decl(trf_6604)
static void C_fcall trf_6604(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6604(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6604(t0,t1);}

C_noret_decl(trf_6537)
static void C_fcall trf_6537(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6537(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6537(t0,t1,t2);}

C_noret_decl(trf_6340)
static void C_fcall trf_6340(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6340(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6340(t0,t1,t2);}

C_noret_decl(trf_6130)
static void C_fcall trf_6130(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6130(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6130(t0,t1,t2,t3);}

C_noret_decl(trf_6074)
static void C_fcall trf_6074(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6074(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6074(t0,t1,t2,t3);}

C_noret_decl(trf_6090)
static void C_fcall trf_6090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6090(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6090(t0,t1);}

C_noret_decl(trf_5948)
static void C_fcall trf_5948(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5948(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5948(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5982)
static void C_fcall trf_5982(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5982(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5982(t0,t1);}

C_noret_decl(trf_5868)
static void C_fcall trf_5868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5868(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5868(t0,t1,t2,t3);}

C_noret_decl(trf_5837)
static void C_fcall trf_5837(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5837(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5837(t0,t1,t2,t3);}

C_noret_decl(trf_5801)
static void C_fcall trf_5801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5801(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5801(t0,t1,t2);}

C_noret_decl(trf_876)
static void C_fcall trf_876(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_876(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_876(t0,t1);}

C_noret_decl(trf_892)
static void C_fcall trf_892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_892(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_892(t0,t1);}

C_noret_decl(trf_5511)
static void C_fcall trf_5511(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5511(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5511(t0,t1);}

C_noret_decl(trf_5525)
static void C_fcall trf_5525(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5525(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5525(t0,t1,t2);}

C_noret_decl(trf_5422)
static void C_fcall trf_5422(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5422(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5422(t0,t1,t2);}

C_noret_decl(trf_5333)
static void C_fcall trf_5333(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5333(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5333(t0,t1,t2);}

C_noret_decl(trf_5045)
static void C_fcall trf_5045(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5045(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5045(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5118)
static void C_fcall trf_5118(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5118(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5118(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5228)
static void C_fcall trf_5228(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5228(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5228(t0,t1,t2);}

C_noret_decl(trf_4831)
static void C_fcall trf_4831(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4831(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4831(t0,t1,t2,t3);}

C_noret_decl(trf_4541)
static void C_fcall trf_4541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4541(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4541(t0,t1,t2);}

C_noret_decl(trf_4626)
static void C_fcall trf_4626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4626(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4626(t0,t1);}

C_noret_decl(trf_4661)
static void C_fcall trf_4661(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4661(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4661(t0,t1,t2,t3);}

C_noret_decl(trf_4280)
static void C_fcall trf_4280(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4280(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4280(t0,t1);}

C_noret_decl(trf_4247)
static void C_fcall trf_4247(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4247(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4247(t0,t1);}

C_noret_decl(trf_4057)
static void C_fcall trf_4057(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4057(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4057(t0,t1,t2,t3);}

C_noret_decl(trf_4083)
static void C_fcall trf_4083(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4083(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4083(t0,t1);}

C_noret_decl(trf_4111)
static void C_fcall trf_4111(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4111(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4111(t0,t1);}

C_noret_decl(trf_3856)
static void C_fcall trf_3856(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3856(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3856(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3713)
static void C_fcall trf_3713(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3713(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3713(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3483)
static void C_fcall trf_3483(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3483(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3483(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3557)
static void C_fcall trf_3557(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3557(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3557(t0,t1);}

C_noret_decl(trf_3493)
static void C_fcall trf_3493(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3493(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3493(t0,t1);}

C_noret_decl(trf_3376)
static void C_fcall trf_3376(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3376(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3376(t0,t1);}

C_noret_decl(trf_2899)
static void C_fcall trf_2899(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2899(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2899(t0,t1);}

C_noret_decl(trf_2902)
static void C_fcall trf_2902(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2902(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2902(t0,t1);}

C_noret_decl(trf_2934)
static void C_fcall trf_2934(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2934(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2934(t0,t1);}

C_noret_decl(trf_2847)
static void C_fcall trf_2847(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2847(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2847(t0,t1);}

C_noret_decl(trf_2564)
static void C_fcall trf_2564(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2564(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2564(t0,t1,t2);}

C_noret_decl(trf_2574)
static void C_fcall trf_2574(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2574(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2574(t0,t1);}

C_noret_decl(trf_1999)
static void C_fcall trf_1999(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1999(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1999(t0,t1);}

C_noret_decl(trf_2007)
static void C_fcall trf_2007(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2007(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2007(t0,t1);}

C_noret_decl(trf_2015)
static void C_fcall trf_2015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2015(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2015(t0,t1);}

C_noret_decl(trf_2316)
static void C_fcall trf_2316(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2316(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2316(t0,t1);}

C_noret_decl(trf_2313)
static void C_fcall trf_2313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2313(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2313(t0,t1);}

C_noret_decl(trf_2061)
static void C_fcall trf_2061(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2061(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2061(t0,t1);}

C_noret_decl(trf_2058)
static void C_fcall trf_2058(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2058(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2058(t0,t1);}

C_noret_decl(trf_1942)
static void C_fcall trf_1942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1942(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1942(t0,t1,t2);}

C_noret_decl(trf_1899)
static void C_fcall trf_1899(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1899(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1899(t0,t1,t2);}

C_noret_decl(trf_1528)
static void C_fcall trf_1528(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1528(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1528(t0,t1);}

C_noret_decl(trf_1543)
static void C_fcall trf_1543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1543(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1543(t0,t1);}

C_noret_decl(trf_1441)
static void C_fcall trf_1441(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1441(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1441(t0,t1);}

C_noret_decl(trf_1431)
static void C_fcall trf_1431(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1431(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1431(t0,t1);}

C_noret_decl(trf_1208)
static void C_fcall trf_1208(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1208(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1208(t0,t1,t2);}

C_noret_decl(trf_1075)
static void C_fcall trf_1075(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1075(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1075(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1110)
static void C_fcall trf_1110(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1110(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1110(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(4053)){
C_save(t1);
C_rereclaim2(4053*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,379);
lf[0]=C_h_intern(&lf[0],19,"\003sysundefined-value");
lf[1]=C_h_intern(&lf[1],3,"map");
lf[2]=C_h_intern(&lf[2],6,"lambda");
lf[3]=C_h_intern(&lf[3],14,"\004coreundefined");
lf[4]=C_h_intern(&lf[4],20,"\003syscall-with-values");
lf[5]=C_h_intern(&lf[5],9,"\004coreset!");
lf[6]=C_h_intern(&lf[6],6,"gensym");
lf[7]=C_h_intern(&lf[7],16,"\003syscheck-syntax");
lf[8]=C_h_intern(&lf[8],25,"set!-values/define-values");
lf[9]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[10]=C_h_intern(&lf[10],27,"\010compilercompiler-arguments");
lf[11]=C_h_intern(&lf[11],29,"\010compilerprocess-command-line");
lf[12]=C_h_intern(&lf[12],7,"reverse");
lf[13]=C_h_intern(&lf[13],14,"string->symbol");
lf[14]=C_h_intern(&lf[14],9,"substring");
lf[15]=C_h_intern(&lf[15],25,"\003sysimplicit-exit-handler");
lf[16]=C_h_intern(&lf[16],17,"user-options-pass");
lf[17]=C_h_intern(&lf[17],4,"exit");
lf[18]=C_h_intern(&lf[18],19,"compile-source-file");
lf[19]=C_h_intern(&lf[19],14,"optimize-level");
lf[20]=C_h_intern(&lf[20],5,"cons*");
lf[21]=C_h_intern(&lf[21],22,"optimize-leaf-routines");
lf[22]=C_h_intern(&lf[22],6,"unsafe");
lf[23]=C_h_intern(&lf[23],25,"\010compilercompiler-warning");
lf[24]=C_h_intern(&lf[24],5,"usage");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\047invalid optimization level ~S - ignored");
lf[26]=C_h_intern(&lf[26],11,"debug-level");
lf[27]=C_h_intern(&lf[27],14,"no-lambda-info");
lf[28]=C_h_intern(&lf[28],8,"no-trace");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000 invalid debug level ~S - ignored");
lf[30]=C_h_intern(&lf[30],14,"benchmark-mode");
lf[31]=C_h_intern(&lf[31],17,"fixnum-arithmetic");
lf[32]=C_h_intern(&lf[32],18,"disable-interrupts");
lf[33]=C_h_intern(&lf[33],5,"block");
lf[34]=C_h_intern(&lf[34],11,"lambda-lift");
lf[35]=C_h_intern(&lf[35],31,"\010compilervalid-compiler-options");
lf[36]=C_h_intern(&lf[36],45,"\010compilervalid-compiler-options-with-argument");
lf[37]=C_h_intern(&lf[37],4,"quit");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~s\047 option");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000&invalid compiler option `~a\047 - ignored");
lf[40]=C_h_intern(&lf[40],4,"conc");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[42]=C_h_intern(&lf[42],6,"append");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[44]=C_h_intern(&lf[44],6,"remove");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[46]=C_h_intern(&lf[46],12,"string-split");
lf[47]=C_h_intern(&lf[47],6,"getenv");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\017CHICKEN_OPTIONS");
lf[49]=C_h_intern(&lf[49],4,"argv");
lf[50]=C_h_intern(&lf[50],12,"syntax-error");
lf[51]=C_h_intern(&lf[51],21,"define-compiler-macro");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000!invalid compiler macro definition");
lf[53]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004void\376\377\016");
lf[54]=C_h_intern(&lf[54],9,"compiling");
lf[55]=C_h_intern(&lf[55],12,"\003sysfeatures");
lf[56]=C_h_intern(&lf[56],7,"warning");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\0004compile macros are not available in interpreted code");
lf[58]=C_h_intern(&lf[58],32,"\010compilerregister-compiler-macro");
lf[59]=C_h_intern(&lf[59],18,"\003sysregister-macro");
lf[60]=C_h_intern(&lf[60],4,"args");
lf[61]=C_h_intern(&lf[61],5,"quote");
lf[62]=C_h_intern(&lf[62],7,"sprintf");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000$`~s\047 is deprecated, use `~s\047 instead");
lf[64]=C_h_intern(&lf[64],4,"cons");
lf[65]=C_h_intern(&lf[65],12,"define-macro");
lf[66]=C_h_intern(&lf[66],23,"define-deprecated-macro");
lf[67]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016");
lf[68]=C_h_intern(&lf[68],5,"begin");
lf[69]=C_h_intern(&lf[69],4,"syms");
lf[70]=C_h_intern(&lf[70],7,"symbol\077");
lf[71]=C_h_intern(&lf[71],4,"list");
lf[72]=C_h_intern(&lf[72],2,"if");
lf[73]=C_h_intern(&lf[73],3,"sum");
lf[74]=C_h_intern(&lf[74],5,"null\077");
lf[75]=C_h_intern(&lf[75],3,"cdr");
lf[76]=C_h_intern(&lf[76],3,"car");
lf[77]=C_h_intern(&lf[77],3,"val");
lf[78]=C_h_intern(&lf[78],4,"case");
lf[79]=C_h_intern(&lf[79],3,"let");
lf[80]=C_h_intern(&lf[80],11,"bitwise-ior");
lf[81]=C_h_intern(&lf[81],4,"loop");
lf[82]=C_h_intern(&lf[82],6,"define");
lf[83]=C_h_intern(&lf[83],4,"cond");
lf[84]=C_h_intern(&lf[84],19,"define-foreign-type");
lf[85]=C_h_intern(&lf[85],10,"\003sysappend");
lf[86]=C_h_intern(&lf[86],4,"else");
lf[87]=C_h_intern(&lf[87],1,"=");
lf[88]=C_h_intern(&lf[88],5,"error");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\024not a member of enum");
lf[90]=C_h_intern(&lf[90],23,"define-foreign-variable");
lf[91]=C_h_intern(&lf[91],8,"->string");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\010number->");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\010->number");
lf[94]=C_h_intern(&lf[94],7,"\003sysmap");
lf[95]=C_h_intern(&lf[95],19,"define-foreign-enum");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid type specification");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid enum specification");
lf[98]=C_h_intern(&lf[98],15,"foreign-declare");
lf[99]=C_h_intern(&lf[99],12,"\004coredeclare");
lf[100]=C_h_intern(&lf[100],20,"\003sysregister-macro-2");
lf[101]=C_h_intern(&lf[101],8,"identity");
lf[102]=C_h_intern(&lf[102],5,"const");
lf[103]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\005union\376\377\016");
lf[104]=C_h_intern(&lf[104],9,"c-pointer");
lf[105]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\005union\376\377\016");
lf[106]=C_h_intern(&lf[106],3,"int");
lf[107]=C_h_intern(&lf[107],15,"foreign-lambda*");
lf[108]=C_h_intern(&lf[108],4,"fx>=");
lf[109]=C_h_intern(&lf[109],3,"fx<");
lf[110]=C_h_intern(&lf[110],3,"and");
lf[111]=C_h_intern(&lf[111],10,"\004corecheck");
lf[112]=C_h_intern(&lf[112],21,"define-foreign-record");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\031array access out of range");
lf[114]=C_h_intern(&lf[114],4,"void");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\031array access out of range");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\020~A->~A[~A] = ~A;");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\012~A-~A-set!");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\025return(~A~A->~A[~A]);");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\005~A-~A");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\014~A->~A = ~A;");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\012~A-~A-set!");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\021return(~A~A->~A);");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\005~A-~A");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\015bad slot spec");
lf[129]=C_h_intern(&lf[129],3,"ptr");
lf[130]=C_h_intern(&lf[130],11,"\004coreinline");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\007C_qfree");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000#return((~a *)C_malloc(sizeof(~a)));");
lf[133]=C_h_intern(&lf[133],7,"declare");
lf[134]=C_h_intern(&lf[134],18,"string-intersperse");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\002};");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\007~A[~A];");
lf[138]=C_h_intern(&lf[138],33,"\010compilerforeign-type-declaration");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\003~A;");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\015bad slot spec");
lf[141]=C_h_intern(&lf[141],13,"string-append");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\007struct ");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\003 { ");
lf[144]=C_h_intern(&lf[144],19,"\003syshash-table-set!");
lf[145]=C_h_intern(&lf[145],27,"\010compilerforeign-type-table");
lf[146]=C_h_intern(&lf[146],7,"\000rename");
lf[147]=C_h_intern(&lf[147],4,"eval");
lf[148]=C_h_intern(&lf[148],5,"cadar");
lf[149]=C_h_intern(&lf[149],12,"\000constructor");
lf[150]=C_h_intern(&lf[150],11,"\000destructor");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000)invalid foreign record-type specification");
lf[152]=C_h_intern(&lf[152],4,"caar");
lf[153]=C_h_intern(&lf[153],8,"keyword\077");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\011struct ~A");
lf[155]=C_h_intern(&lf[155],5,"code_");
lf[156]=C_h_intern(&lf[156],13,"foreign-value");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\0007static C_word ~A() { ~A\012; return C_SCHEME_UNDEFINED; }\012");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[159]=C_h_intern(&lf[159],12,"foreign-code");
lf[160]=C_h_intern(&lf[160],17,"\004corelet-location");
lf[161]=C_h_intern(&lf[161],10,"fold-right");
lf[162]=C_h_intern(&lf[162],10,"append-map");
lf[163]=C_h_intern(&lf[163],12,"let-location");
lf[164]=C_h_intern(&lf[164],28,"\004coredefine-foreign-variable");
lf[165]=C_h_intern(&lf[165],29,"\004coredefine-external-variable");
lf[166]=C_h_intern(&lf[166],14,"symbol->string");
lf[167]=C_h_intern(&lf[167],15,"define-location");
lf[168]=C_h_intern(&lf[168],15,"define-external");
lf[169]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[171]=C_h_intern(&lf[171],29,"\004coreforeign-callback-wrapper");
lf[172]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376"
"\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[173]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376"
"\001\000\000\001_\376\377\001\000\000\000\001");
lf[174]=C_h_intern(&lf[174],20,"foreign-safe-wrapper");
lf[175]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006lambda\376\003\000\000\002"
"\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001\376\377\016");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[177]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006lambda\376\003\000\000\002\376\001\000\000\013lambda-list"
"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001\376\377\016");
lf[178]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[179]=C_h_intern(&lf[179],22,"\004coreforeign-primitive");
lf[180]=C_h_intern(&lf[180],17,"foreign-primitive");
lf[181]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[182]=C_h_intern(&lf[182],29,"\004coreforeign-callback-lambda*");
lf[183]=C_h_intern(&lf[183],20,"foreign-safe-lambda*");
lf[184]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\001");
lf[185]=C_h_intern(&lf[185],28,"\004coreforeign-callback-lambda");
lf[186]=C_h_intern(&lf[186],19,"foreign-safe-lambda");
lf[187]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[188]=C_h_intern(&lf[188],20,"\004coreforeign-lambda*");
lf[189]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\001");
lf[190]=C_h_intern(&lf[190],19,"\004coreforeign-lambda");
lf[191]=C_h_intern(&lf[191],14,"foreign-lambda");
lf[192]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[193]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[194]=C_h_intern(&lf[194],24,"\004coredefine-foreign-type");
lf[195]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\001\376\377\001\000\000\000\003");
lf[196]=C_h_intern(&lf[196],17,"register-feature!");
lf[197]=C_h_intern(&lf[197],6,"srfi-8");
lf[198]=C_h_intern(&lf[198],7,"srfi-16");
lf[199]=C_h_intern(&lf[199],7,"srfi-26");
lf[200]=C_h_intern(&lf[200],7,"srfi-31");
lf[201]=C_h_intern(&lf[201],7,"srfi-15");
lf[202]=C_h_intern(&lf[202],7,"srfi-11");
lf[203]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004void\376\377\016\376\377\016");
lf[204]=C_h_intern(&lf[204],25,"\003sysenable-runtime-macros");
lf[205]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\377\016");
lf[206]=C_h_intern(&lf[206],17,"define-for-syntax");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\022invalid identifier");
lf[208]=C_h_intern(&lf[208],6,"letrec");
lf[209]=C_h_intern(&lf[209],3,"rec");
lf[210]=C_h_intern(&lf[210],22,"chicken-compile-shared");
lf[211]=C_h_intern(&lf[211],3,"not");
lf[212]=C_h_intern(&lf[212],4,"unit");
lf[213]=C_h_intern(&lf[213],7,"provide");
lf[214]=C_h_intern(&lf[214],11,"cond-expand");
lf[215]=C_h_intern(&lf[215],6,"export");
lf[216]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\377\016");
lf[217]=C_h_intern(&lf[217],6,"static");
lf[218]=C_h_intern(&lf[218],4,"cdar");
lf[219]=C_h_intern(&lf[219],7,"dynamic");
lf[220]=C_h_intern(&lf[220],16,"define-extension");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid clause specifier");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid clause syntax");
lf[223]=C_h_intern(&lf[223],22,"string-parse-start+end");
lf[224]=C_h_intern(&lf[224],7,"receive");
lf[225]=C_h_intern(&lf[225],28,"string-parse-final-start+end");
lf[226]=C_h_intern(&lf[226],20,"let-string-start+end");
lf[227]=C_h_intern(&lf[227],5,"apply");
lf[228]=C_h_intern(&lf[228],2,"<>");
lf[229]=C_h_intern(&lf[229],5,"<...>");
lf[230]=C_h_intern(&lf[230],4,"cute");
lf[231]=C_h_intern(&lf[231],3,"cut");
lf[232]=C_h_intern(&lf[232],22,"\004corerequire-extension");
lf[233]=C_h_intern(&lf[233],3,"use");
lf[234]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[235]=C_h_intern(&lf[235],17,"require-extension");
lf[236]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[237]=C_h_intern(&lf[237],23,"\004corerequire-for-syntax");
lf[238]=C_h_intern(&lf[238],18,"require-for-syntax");
lf[239]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[240]=C_h_intern(&lf[240],18,"\003sysmake-structure");
lf[241]=C_h_intern(&lf[241],1,"x");
lf[242]=C_h_intern(&lf[242],14,"\003sysstructure\077");
lf[243]=C_h_intern(&lf[243],15,"\000record-setters");
lf[244]=C_h_intern(&lf[244],19,"\003syscheck-structure");
lf[245]=C_h_intern(&lf[245],13,"\003sysblock-ref");
lf[246]=C_h_intern(&lf[246],18,"getter-with-setter");
lf[247]=C_h_intern(&lf[247],1,"y");
lf[248]=C_h_intern(&lf[248],14,"\003sysblock-set!");
lf[249]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[250]=C_h_intern(&lf[250],18,"define-record-type");
lf[251]=C_h_intern(&lf[251],4,"memv");
lf[252]=C_h_intern(&lf[252],9,"condition");
lf[253]=C_h_intern(&lf[253],8,"\003sysslot");
lf[254]=C_h_intern(&lf[254],17,"handle-exceptions");
lf[255]=C_h_intern(&lf[255],10,"\003syssignal");
lf[256]=C_h_intern(&lf[256],14,"condition-case");
lf[257]=C_h_intern(&lf[257],9,"\003sysapply");
lf[258]=C_h_intern(&lf[258],10,"\003sysvalues");
lf[259]=C_h_intern(&lf[259],22,"with-exception-handler");
lf[260]=C_h_intern(&lf[260],30,"call-with-current-continuation");
lf[261]=C_h_intern(&lf[261],27,"\003sysregister-record-printer");
lf[262]=C_h_intern(&lf[262],21,"define-record-printer");
lf[263]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[264]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[265]=C_h_intern(&lf[265],6,"length");
lf[266]=C_h_intern(&lf[266],9,"split-at!");
lf[267]=C_h_intern(&lf[267],4,"take");
lf[268]=C_h_intern(&lf[268],3,"fx=");
lf[269]=C_h_intern(&lf[269],11,"case-lambda");
lf[270]=C_h_intern(&lf[270],11,"lambda-list");
lf[271]=C_h_intern(&lf[271],25,"\003sysdecompose-lambda-list");
lf[272]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corecheck\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\003syserror\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreimmutable\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376B\000\0000no matching clause in call to \047case-lambda\047 form\376\377\016\376\377\016\376\377\016"
"\376\377\016");
lf[273]=C_h_intern(&lf[273],3,"min");
lf[274]=C_h_intern(&lf[274],7,"require");
lf[275]=C_h_intern(&lf[275],6,"srfi-1");
lf[276]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[278]=C_h_intern(&lf[278],14,"\004coreimmutable");
lf[279]=C_h_intern(&lf[279],9,"\003syserror");
lf[280]=C_h_intern(&lf[280],14,"let-optionals*");
lf[281]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[282]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[283]=C_h_intern(&lf[283],8,"optional");
lf[284]=C_h_intern(&lf[284],9,":optional");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[286]=C_h_intern(&lf[286],4,"let*");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\004def-");
lf[289]=C_h_intern(&lf[289],5,"%rest");
lf[290]=C_h_intern(&lf[290],4,"body");
lf[291]=C_h_intern(&lf[291],4,"cadr");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\001%");
lf[293]=C_h_intern(&lf[293],13,"let-optionals");
lf[294]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[295]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[296]=C_h_intern(&lf[296],4,"eqv\077");
lf[297]=C_h_intern(&lf[297],6,"switch");
lf[298]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[299]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[300]=C_h_intern(&lf[300],2,"or");
lf[301]=C_h_intern(&lf[301],6,"select");
lf[302]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[303]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[304]=C_h_intern(&lf[304],21,"\003syssyntax-error-hook");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\037syntax error in \047and-let*\047 form");
lf[306]=C_h_intern(&lf[306],8,"and-let*");
lf[307]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[308]=C_h_intern(&lf[308],20,"\004coredefine-constant");
lf[309]=C_h_intern(&lf[309],15,"define-constant");
lf[310]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[311]=C_h_intern(&lf[311],18,"\004coredefine-inline");
lf[312]=C_h_intern(&lf[312],13,"define-inline");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000*invalid substitution form - must be lambda");
lf[314]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[315]=C_h_intern(&lf[315],8,"list-ref");
lf[316]=C_h_intern(&lf[316],9,"nth-value");
lf[317]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[318]=C_h_intern(&lf[318],13,"letrec-values");
lf[319]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[320]=C_h_intern(&lf[320],10,"let-values");
lf[321]=C_h_intern(&lf[321],11,"let*-values");
lf[322]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[323]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[324]=C_h_intern(&lf[324],13,"define-values");
lf[325]=C_h_intern(&lf[325],11,"set!-values");
lf[326]=C_h_intern(&lf[326],6,"unless");
lf[327]=C_h_intern(&lf[327],4,"when");
lf[328]=C_h_intern(&lf[328],16,"\003sysdynamic-wind");
lf[329]=C_h_intern(&lf[329],1,"t");
lf[330]=C_h_intern(&lf[330],8,"\003syslist");
lf[331]=C_h_intern(&lf[331],12,"parameterize");
lf[332]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[333]=C_h_intern(&lf[333],10,"\000compiling");
lf[334]=C_h_intern(&lf[334],19,"\004corecompiletimetoo");
lf[335]=C_h_intern(&lf[335],20,"\004corecompiletimeonly");
lf[336]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[337]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[338]=C_h_intern(&lf[338],4,"load");
lf[339]=C_h_intern(&lf[339],8,"run-time");
lf[340]=C_h_intern(&lf[340],7,"compile");
lf[341]=C_h_intern(&lf[341],12,"compile-time");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid situation specifier");
lf[343]=C_h_intern(&lf[343],9,"eval-when");
lf[344]=C_h_intern(&lf[344],8,"\003sysvoid");
lf[345]=C_h_intern(&lf[345],9,"fluid-let");
lf[346]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[347]=C_h_intern(&lf[347],11,"\000type-error");
lf[348]=C_h_intern(&lf[348],15,"\003syssignal-hook");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\033argument has incorrect type");
lf[350]=C_h_intern(&lf[350],6,"ensure");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\020assertion failed");
lf[352]=C_h_intern(&lf[352],6,"assert");
lf[353]=C_h_intern(&lf[353],20,"with-input-from-file");
lf[354]=C_h_intern(&lf[354],4,"read");
lf[355]=C_h_intern(&lf[355],27,"\003syscurrent-source-filename");
lf[356]=C_h_intern(&lf[356],5,"print");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\014; including ");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[359]=C_h_intern(&lf[359],12,"load-verbose");
lf[360]=C_h_intern(&lf[360],28,"\003sysresolve-include-filename");
lf[361]=C_h_intern(&lf[361],7,"include");
lf[362]=C_h_intern(&lf[362],15,"\003sysstart-timer");
lf[363]=C_h_intern(&lf[363],14,"\003sysstop-timer");
lf[364]=C_h_intern(&lf[364],17,"\003sysdisplay-times");
lf[365]=C_h_intern(&lf[365],4,"time");
lf[366]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[367]=C_h_intern(&lf[367],28,"\003sysstring->qualified-symbol");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\005-set!");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\001\077");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\005make-");
lf[373]=C_h_intern(&lf[373],27,"\003sysqualified-symbol-prefix");
lf[374]=C_h_intern(&lf[374],13,"define-record");
lf[375]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[376]=C_h_intern(&lf[376],6,"symbol");
lf[377]=C_h_intern(&lf[377],11,"\003sysprovide");
lf[378]=C_h_intern(&lf[378],19,"chicken-more-macros");
C_register_lf2(lf,379,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_688,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k686 */
static void C_ccall f_688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_691,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k689 in k686 */
static void C_ccall f_691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_691,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_694,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k692 in k689 in k686 */
static void C_ccall f_694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_694,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_697,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k695 in k692 in k689 in k686 */
static void C_ccall f_697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_700,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_700,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_703,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_706,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_match_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_709,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_4_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_712,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_715,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_support_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_718,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_compiler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_721,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_724,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_driver_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_727,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_platform_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_730,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_backend_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_730,2,t0,t1);}
t2=C_retrieve(lf[0]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_736,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#provide */
t4=C_retrieve(lf[377]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[378]);}

/* k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_739,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[166]+1);
t4=*((C_word*)lf[13]+1);
t5=*((C_word*)lf[141]+1);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6914,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t7=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[374],t6);}

/* a6913 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6914(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_6914r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6914r(t0,t1,t2,t3);}}

static void C_ccall f_6914r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6918,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t5=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[374],t2,lf[376]);}

/* k6916 in a6913 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6918,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6921,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[374],((C_word*)t0)[5],lf[375]);}

/* k6919 in k6916 in a6913 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   symbol->string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k6922 in k6919 in k6916 in a6913 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6924,2,t0,t1);}
t2=(C_word)C_i_memq(lf[243],C_retrieve(lf[55]));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6930,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* chicken.scm: 71   ##sys#qualified-symbol-prefix */
t4=C_retrieve(lf[373]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}

/* k6928 in k6922 in k6919 in k6916 in a6913 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7116,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7136,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   string-append */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[372],((C_word*)t0)[3]);}

/* k7134 in k6928 in k6922 in k6919 in k6916 in a6913 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_7136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[367]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7114 in k6928 in k6922 in k6919 in k6916 in a6913 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_7116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7116,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
t4=(C_word)C_a_i_cons(&a,2,lf[240],t3);
t5=(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_list(&a,3,lf[82],t1,t5);
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7092,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t6,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7112,a[2]=((C_word*)t0)[5],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   string-append */
t9=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,((C_word*)t0)[3],lf[371]);}

/* k7110 in k7114 in k6928 in k6922 in k6919 in k6916 in a6913 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_7112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[367]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7090 in k7114 in k6928 in k6922 in k6919 in k6916 in a6913 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_7092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7092,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[241]);
t3=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[10]);
t4=(C_word)C_a_i_list(&a,3,lf[242],lf[241],t3);
t5=(C_word)C_a_i_list(&a,3,lf[2],t2,t4);
t6=(C_word)C_a_i_list(&a,3,lf[82],t1,t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6953,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6955,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t9,a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp));
t11=((C_word*)t9)[1];
f_6955(t11,t7,((C_word*)t0)[2],C_fix(1));}

/* mapslots in k7090 in k7114 in k6928 in k6922 in k6919 in k6916 in a6913 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_6955(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6955,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6965,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=t1,a[9]=t3,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* chicken.scm: 71   symbol->string */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}}

/* k6963 in mapslots in k7090 in k7114 in k6928 in k6922 in k6919 in k6916 in a6913 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6968,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7084,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   string-append */
t4=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[2],lf[369],t1,lf[370]);}

/* k7082 in k6963 in mapslots in k7090 in k7114 in k6928 in k6922 in k6919 in k6916 in a6913 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_7084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[367]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6966 in k6963 in mapslots in k7090 in k7114 in k6928 in k6922 in k6919 in k6916 in a6913 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6971,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t1,a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7080,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   string-append */
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[3],lf[368],((C_word*)t0)[2]);}

/* k7078 in k6966 in k6963 in mapslots in k7090 in k7114 in k6928 in k6922 in k6919 in k6916 in a6913 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_7080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[367]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6969 in k6966 in k6963 in mapslots in k7090 in k7114 in k6928 in k6922 in k6919 in k6916 in a6913 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[167],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6971,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[241],lf[77]);
t3=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[8]);
t4=(C_word)C_a_i_list(&a,3,lf[244],lf[241],t3);
t5=(C_word)C_a_i_list(&a,2,lf[111],t4);
t6=(C_word)C_a_i_list(&a,4,lf[248],lf[241],((C_word*)t0)[7],lf[77]);
t7=(C_word)C_a_i_list(&a,4,lf[2],t2,t5,t6);
t8=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[6],t7);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7002,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t8,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t10=(C_word)C_a_i_list(&a,1,lf[241]);
t11=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[8]);
t12=(C_word)C_a_i_list(&a,3,lf[244],lf[241],t11);
t13=(C_word)C_a_i_list(&a,2,lf[111],t12);
t14=(C_word)C_a_i_list(&a,3,lf[245],lf[241],((C_word*)t0)[7]);
t15=(C_word)C_a_i_list(&a,4,lf[2],t10,t13,t14);
t16=t9;
f_7002(t16,(C_word)C_a_i_list(&a,3,lf[246],t15,((C_word*)t0)[6]));}
else{
t10=(C_word)C_a_i_list(&a,1,lf[241]);
t11=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[8]);
t12=(C_word)C_a_i_list(&a,3,lf[244],lf[241],t11);
t13=(C_word)C_a_i_list(&a,2,lf[111],t12);
t14=(C_word)C_a_i_list(&a,3,lf[245],lf[241],((C_word*)t0)[7]);
t15=t9;
f_7002(t15,(C_word)C_a_i_list(&a,4,lf[2],t10,t13,t14));}}

/* k7000 in k6969 in k6966 in k6963 in mapslots in k7090 in k7114 in k6928 in k6922 in k6919 in k6916 in a6913 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_7002(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7002,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_list(&a,3,lf[68],((C_word*)t0)[6],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6982,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t6=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* chicken.scm: 71   mapslots */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6955(t7,t4,t5,t6);}

/* k6980 in k7000 in k6969 in k6966 in k6963 in mapslots in k7090 in k7114 in k6928 in k6922 in k6919 in k6916 in a6913 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6982,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6951 in k7090 in k7114 in k6928 in k6922 in k6919 in k6916 in a6913 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6953,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[68],t3));}

/* k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_742,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6826,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[224],t3);}

/* a6825 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6826(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+23)){
C_save_and_reclaim((void*)tr3r,(void*)f_6826r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6826r(t0,t1,t2,t3);}}

static void C_ccall f_6826r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(23);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[4],t4,lf[330]));}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6843,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t5=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[224],t2,lf[270]);}}

/* k6841 in a6825 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[224],((C_word*)t0)[3],lf[366]);}

/* k6844 in k6841 in a6825 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=t2;
f_6852(t4,(C_word)C_i_nullp(t3));}
else{
t3=t2;
f_6852(t3,C_SCHEME_FALSE);}}

/* k6850 in k6844 in k6841 in a6825 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_6852(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6852,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[79],t7));}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[2],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[4],t3,t6));}}

/* k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_745,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[6]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6785,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t5=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[365],t4);}

/* a6784 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6785(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_6785r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6785r(t0,t1,t2);}}

static void C_ccall f_6785r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6789,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   gensym */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[329]);}

/* k6787 in a6784 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6789,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[362]);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,lf[2],t3);
t5=(C_word)C_a_i_list(&a,1,lf[363]);
t6=(C_word)C_a_i_list(&a,2,lf[364],t5);
t7=(C_word)C_a_i_list(&a,3,lf[257],lf[258],t1);
t8=(C_word)C_a_i_list(&a,4,lf[2],t1,t6,t7);
t9=(C_word)C_a_i_list(&a,3,lf[4],t4,t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,3,lf[68],t2,t9));}

/* k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_748,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6769,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[133],t3);}

/* a6768 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6769(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_6769r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6769r(t0,t1,t2);}}

static void C_ccall f_6769r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6777,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6779,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a6778 in a6768 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6779(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6779,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k6775 in a6768 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6777,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[99],t1));}

/* k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_748,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_751,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[353]);
t4=*((C_word*)lf[354]+1);
t5=*((C_word*)lf[12]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6692,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t7=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[361],t6);}

/* a6691 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6692(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6692,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#resolve-include-filename */
t4=C_retrieve(lf[360]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,C_SCHEME_TRUE);}

/* k6694 in a6691 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6699,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6764,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   load-verbose */
t4=C_retrieve(lf[359]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k6762 in k6694 in a6691 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken.scm: 71   print */
t2=*((C_word*)lf[356]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[357],((C_word*)t0)[2],lf[358]);}
else{
t2=((C_word*)t0)[3];
f_6699(2,t2,C_SCHEME_UNDEFINED);}}

/* k6697 in k6694 in a6691 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6699,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6706,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6708,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   with-input-from-file */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[5],t3);}

/* a6707 in k6697 in k6694 in a6691 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6708,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6714,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6722,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6755,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[328]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t1,t6,t7,t8);}

/* a6754 in a6707 in k6697 in k6694 in a6691 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6755,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[355]));
t3=C_mutate((C_word*)lf[355]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[0]));}

/* a6721 in a6707 in k6697 in k6694 in a6691 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6722,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6730,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   read */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6728 in a6721 in a6707 in k6697 in k6694 in a6691 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6730,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6732,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6732(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* do44 in k6728 in a6721 in a6707 in k6697 in k6694 in a6691 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_6732(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6732,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eofp(t2))){
/* chicken.scm: 71   reverse */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6749,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   read */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k6747 in do44 in k6728 in a6721 in a6707 in k6697 in k6694 in a6691 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6749,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_6732(t3,((C_word*)t0)[2],t1,t2);}

/* a6713 in a6707 in k6697 in k6694 in a6691 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6714,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[355]));
t3=C_mutate((C_word*)lf[355]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[0]));}

/* k6704 in k6697 in k6694 in a6691 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6706,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[68],t1));}

/* k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_754,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6632,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[352],t3);}

/* a6631 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6632(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_6632r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6632r(t0,t1,t2,t3);}}

static void C_ccall f_6632r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6636,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t3);
if(C_truep(t5)){
t6=(C_word)C_a_i_list(&a,2,lf[61],lf[351]);
t7=t4;
f_6636(t7,(C_word)C_a_i_list(&a,2,lf[278],t6));}
else{
t6=t4;
f_6636(t6,(C_word)C_slot(t3,C_fix(0)));}}

/* k6634 in a6631 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_6636(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6636,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[111],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,lf[3]);
t4=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=(C_word)C_fixnum_greaterp(t5,C_fix(1));
t7=(C_truep(t6)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t4,t7);
t9=(C_word)C_a_i_cons(&a,2,t1,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[279],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[72],t2,t3,t10));}

/* k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_757,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6573,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[350],t3);}

/* a6572 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_6573r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6573r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6573r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6577,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   gensym */
t6=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k6575 in a6572 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[54],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6577,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t5=(C_word)C_a_i_list(&a,2,lf[111],t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6604,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t7=t6;
f_6604(t7,((C_word*)t0)[2]);}
else{
t7=(C_word)C_a_i_list(&a,2,lf[61],lf[349]);
t8=(C_word)C_a_i_list(&a,2,lf[278],t7);
t9=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t10=t6;
f_6604(t10,(C_word)C_a_i_list(&a,3,t8,t1,t9));}}

/* k6602 in k6575 in a6572 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_6604(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6604,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[347],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[348],t2);
t4=(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[5],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t4));}

/* k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_757,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_760,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[6]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6399,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t5=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[345],t4);}

/* a6398 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6399(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_6399r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6399r(t0,t1,t2,t3);}}

static void C_ccall f_6399r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6403,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t5=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[345],t2,lf[346]);}

/* k6401 in a6398 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6406,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[76]+1),((C_word*)t0)[3]);}

/* k6404 in k6401 in a6398 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6409,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6567,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a6566 in k6404 in k6401 in a6398 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6567(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6567,3,t0,t1,t2);}
/* chicken.scm: 71   gensym */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k6407 in k6404 in k6401 in a6398 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6412,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6561,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a6560 in k6407 in k6404 in k6401 in a6398 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6561(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6561,3,t0,t1,t2);}
/* chicken.scm: 71   gensym */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k6410 in k6407 in k6404 in k6401 in a6398 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6419,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6523,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6559,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[291]+1),((C_word*)t0)[2]);}

/* k6557 in k6410 in k6407 in k6404 in k6401 in a6398 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   map */
t2=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[330]+1),((C_word*)t0)[2],t1);}

/* k6521 in k6410 in k6407 in k6404 in k6401 in a6398 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6523,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6527,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6531,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(((C_word*)t0)[2]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6537,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_6537(t8,t3,t4);}

/* loop in k6521 in k6410 in k6407 in k6404 in k6401 in a6398 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_6537(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6537,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6551,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
/* chicken.scm: 71   loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k6549 in loop in k6521 in k6410 in k6407 in k6404 in k6401 in a6398 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6551,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1));}

/* k6529 in k6521 in k6410 in k6407 in k6404 in k6401 in a6398 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   map */
t2=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[330]+1),((C_word*)t0)[2],t1);}

/* k6525 in k6521 in k6410 in k6407 in k6404 in k6401 in a6398 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6417 in k6410 in k6407 in k6404 in k6401 in a6398 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6487,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6491,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6515,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   map */
t5=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* a6514 in k6417 in k6410 in k6407 in k6404 in k6401 in a6398 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6515(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6515,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t2,t3));}

/* k6489 in k6417 in k6410 in k6407 in k6404 in k6401 in a6398 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6495,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6499,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6509,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   map */
t5=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6508 in k6489 in k6417 in k6410 in k6407 in k6404 in k6401 in a6398 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6509(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6509,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t2,t3));}

/* k6497 in k6489 in k6417 in k6410 in k6407 in k6404 in k6401 in a6398 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6499,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[344]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k6493 in k6489 in k6417 in k6410 in k6407 in k6404 in k6401 in a6398 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6485 in k6417 in k6410 in k6407 in k6404 in k6401 in a6398 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6487,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[2],t2);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,lf[2],t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6443,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6447,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6471,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   map */
t9=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,t8,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a6470 in k6485 in k6417 in k6410 in k6407 in k6404 in k6401 in a6398 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6471(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6471,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t2,t3));}

/* k6445 in k6485 in k6417 in k6410 in k6407 in k6404 in k6401 in a6398 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6451,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6455,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6465,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   map */
t5=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6464 in k6445 in k6485 in k6417 in k6410 in k6407 in k6404 in k6401 in a6398 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6465(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6465,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t2,t3));}

/* k6453 in k6445 in k6485 in k6417 in k6410 in k6407 in k6404 in k6401 in a6398 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6455,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[344]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k6449 in k6445 in k6485 in k6417 in k6410 in k6407 in k6404 in k6401 in a6398 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6441 in k6485 in k6417 in k6410 in k6407 in k6404 in k6401 in a6398 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6443,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[2],t2);
t4=(C_word)C_a_i_list(&a,4,lf[328],((C_word*)t0)[5],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t4));}

/* k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_763,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6304,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[343],t3);}

/* a6303 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6304(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr3r,(void*)f_6304r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6304r(t0,t1,t2,t3);}}

static void C_ccall f_6304r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(24);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(C_word)C_a_i_cons(&a,2,lf[68],t3);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6311,a[2]=t5,a[3]=t10,a[4]=t1,a[5]=t9,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6340,a[2]=t7,a[3]=t9,a[4]=t5,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_6340(t15,t11,t2);}

/* loop in a6303 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_6340(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6340,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6353,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(t3,lf[147]);
if(C_truep(t5)){
t6=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t7=t4;
f_6353(2,t7,t6);}
else{
t6=(C_word)C_eqp(t3,lf[338]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t3,lf[339]));
if(C_truep(t7)){
t8=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t9=t4;
f_6353(2,t9,t8);}
else{
t8=(C_word)C_eqp(t3,lf[340]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[341]));
if(C_truep(t9)){
t10=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t11=t4;
f_6353(2,t11,t10);}
else{
t10=(C_word)C_slot(t2,C_fix(0));
/* chicken.scm: 71   ##sys#error */
t11=*((C_word*)lf[279]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t4,lf[342],t10);}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6351 in loop in a6303 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* chicken.scm: 71   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6340(t3,((C_word*)t0)[2],t2);}

/* k6309 in a6303 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6311,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[333],C_retrieve(lf[55])))){
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?((C_word*)((C_word*)t0)[5])[1]:C_SCHEME_FALSE);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_a_i_list(&a,2,lf[334],((C_word*)t0)[3]):(C_truep(((C_word*)((C_word*)t0)[6])[1])?(C_word)C_a_i_list(&a,2,lf[335],((C_word*)t0)[3]):(C_truep(((C_word*)((C_word*)t0)[5])[1])?((C_word*)t0)[3]:lf[336]))));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)((C_word*)t0)[2])[1])?((C_word*)t0)[3]:lf[337]));}}

/* k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_766,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[76]+1);
t4=*((C_word*)lf[291]+1);
t5=*((C_word*)lf[1]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6194,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t7=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[331],t6);}

/* a6193 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6194(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_6194r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6194r(t0,t1,t2,t3);}}

static void C_ccall f_6194r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6198,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t5=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[331],t2,lf[332]);}

/* k6196 in a6193 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6201,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6199 in k6196 in a6193 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6201,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6204,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   ##sys#map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k6202 in k6199 in k6196 in a6193 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6207,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   ##sys#map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6205 in k6202 in k6199 in k6196 in a6193 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6210,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6298,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a6297 in k6205 in k6202 in k6199 in k6196 in a6193 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6298(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6298,3,t0,t1,t2);}
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k6208 in k6205 in k6202 in k6199 in k6196 in a6193 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6213,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6292,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a6291 in k6208 in k6205 in k6202 in k6199 in k6196 in a6193 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6292(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6292,3,t0,t1,t2);}
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k6211 in k6208 in k6205 in k6202 in k6199 in k6196 in a6193 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6220,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6286,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   map */
t4=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[330]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k6284 in k6211 in k6208 in k6205 in k6202 in k6199 in k6196 in a6193 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6286,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6290,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   map */
t3=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[330]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6288 in k6284 in k6211 in k6208 in k6205 in k6202 in k6199 in k6196 in a6193 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6218 in k6211 in k6208 in k6205 in k6202 in k6199 in k6196 in a6193 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6256,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6258,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   map */
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6257 in k6218 in k6211 in k6208 in k6205 in k6202 in k6199 in k6196 in a6193 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6258(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[39],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6258,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t2);
t5=(C_word)C_a_i_list(&a,2,lf[329],t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_list(&a,2,t2,t3);
t8=(C_word)C_a_i_list(&a,3,lf[5],t3,lf[329]);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_list(&a,4,lf[79],t6,t7,t8));}

/* k6254 in k6218 in k6211 in k6208 in k6205 in k6202 in k6199 in k6196 in a6193 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6256,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[2],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t7=(C_word)C_a_i_cons(&a,2,lf[2],t6);
t8=(C_word)C_a_i_list(&a,4,lf[328],((C_word*)t0)[5],t7,((C_word*)t0)[5]);
t9=(C_word)C_a_i_list(&a,3,lf[79],t5,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t9));}

/* k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_769,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6184,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[327],t3);}

/* a6183 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6184(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_6184r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6184r(t0,t1,t2,t3);}}

static void C_ccall f_6184r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(12);
t4=(C_word)C_a_i_cons(&a,2,lf[68],t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[72],t2,t4));}

/* k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_772,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6170,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[326],t3);}

/* a6169 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6170(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr3r,(void*)f_6170r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6170r(t0,t1,t2,t3);}}

static void C_ccall f_6170r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(18);
t4=(C_word)C_a_i_list(&a,1,lf[3]);
t5=(C_word)C_a_i_cons(&a,2,lf[68],t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,4,lf[72],t2,t4,t5));}

/* k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_772,2,t0,t1);}
t2=*((C_word*)lf[1]+1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_773,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_846,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t5=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[325],t3);}

/* k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_849,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t3=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[324],((C_word*)t0)[2]);}

/* k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_852,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5837,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5868,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5908,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t10=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t2,lf[320],t9);}

/* a5835 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5908(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5908,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5912,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[320],t2,lf[323]);}

/* k5910 in a5835 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5912,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5921,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[76]+1),t2);}

/* k5919 in k5910 in a5835 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5924,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6130,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6130(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* loop in k5919 in k5910 in a5835 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_6130(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6130,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6143,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t4))){
/* chicken.scm: 71   append */
t6=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t4))){
/* chicken.scm: 71   append* */
t6=((C_word*)((C_word*)t0)[2])[1];
f_5837(t6,t5,t4,t3);}
else{
t6=t5;
f_6143(2,t6,(C_word)C_a_i_cons(&a,2,t4,t3));}}}}

/* k6141 in loop in k5919 in k5910 in a5835 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 71   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6130(t3,((C_word*)t0)[2],t2,t1);}

/* k5922 in k5919 in k5910 in a5835 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6120,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a6119 in k5922 in k5919 in k5910 in a5835 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6120(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6120,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6128,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   gensym */
t4=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6126 in a6119 in k5922 in k5919 in k5910 in a5835 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6128,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5925 in k5922 in k5919 in k5910 in a5835 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5928,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5939,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6074,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_6074(t7,t3,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}

/* loop in k5925 in k5922 in k5919 in k5910 in a5835 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_6074(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6074,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* chicken.scm: 71   reverse */
t4=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6090,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6114,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   map* */
t7=((C_word*)((C_word*)t0)[3])[1];
f_5868(t7,t6,((C_word*)t0)[2],t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6107,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   lookup */
t7=((C_word*)t0)[2];
f_5928(3,t7,t6,t4);}}}

/* k6105 in loop in k5925 in k5922 in k5919 in k5910 in a5835 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6107,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6090(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k6112 in loop in k5925 in k5922 in k5919 in k5910 in a5835 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6114,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6090(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k6088 in loop in k5925 in k5922 in k5919 in k5910 in a5835 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_6090(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 71   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6074(t3,((C_word*)t0)[2],t2,t1);}

/* k5937 in k5925 in k5922 in k5919 in k5910 in a5835 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5946,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6068,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a6067 in k5937 in k5925 in k5922 in k5919 in k5910 in a5835 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6068(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6068,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k5944 in k5937 in k5925 in k5922 in k5919 in k5910 in a5835 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5946,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5948,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_5948(t5,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* fold in k5944 in k5937 in k5925 in k5922 in k5919 in k5910 in a5835 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_5948(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5948,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5966,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5968,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* map */
t7=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5982,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(t4);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6062,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   cdar */
t8=*((C_word*)lf[218]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}
else{
t7=t5;
f_5982(t7,C_SCHEME_FALSE);}}}

/* k6060 in fold in k5944 in k5937 in k5925 in k5922 in k5919 in k5910 in a5835 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5982(t2,(C_word)C_i_nullp(t1));}

/* k5980 in fold in k5944 in k5937 in k5925 in k5922 in k5919 in k5910 in a5835 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_5982(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5982,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6013,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   caar */
t3=*((C_word*)lf[152]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6036,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[6]);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken.scm: 71   fold */
t9=((C_word*)((C_word*)t0)[2])[1];
f_5948(t9,t5,t6,t7,t8);}}

/* k6034 in k5980 in fold in k5944 in k5937 in k5925 in k5922 in k5919 in k5910 in a5835 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6036,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[4],((C_word*)t0)[2],t2));}

/* k6011 in k5980 in fold in k5944 in k5937 in k5925 in k5922 in k5919 in k5910 in a5835 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_6013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6013,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5993,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[6]);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken.scm: 71   fold */
t9=((C_word*)((C_word*)t0)[2])[1];
f_5948(t9,t5,t6,t7,t8);}

/* k5991 in k6011 in k5980 in fold in k5944 in k5937 in k5925 in k5922 in k5919 in k5910 in a5835 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5993,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* a5967 in fold in k5944 in k5937 in k5925 in k5922 in k5919 in k5910 in a5835 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5968(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5968,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5976,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   lookup */
t4=((C_word*)t0)[2];
f_5928(3,t4,t3,t2);}

/* k5974 in a5967 in fold in k5944 in k5937 in k5925 in k5922 in k5919 in k5910 in a5835 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5976,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k5964 in fold in k5944 in k5937 in k5925 in k5922 in k5919 in k5910 in a5835 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5966,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[79],t2));}

/* lookup in k5925 in k5922 in k5919 in k5910 in a5835 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5928(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5928,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* map* in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_5868(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5868,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5891,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* chicken.scm: 71   proc */
t6=t2;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
/* chicken.scm: 71   proc */
t4=t2;
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}}}

/* k5889 in map* in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5895,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 71   map* */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5868(t4,t2,((C_word*)t0)[2],t3);}

/* k5893 in k5889 in map* in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5895,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* append* in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_5837(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5837,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5858,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* chicken.scm: 71   append* */
t8=t5;
t9=t6;
t10=t3;
t1=t8;
t2=t9;
t3=t10;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}}

/* k5856 in append* in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5858,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_855,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5786,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[321],t3);}

/* a5785 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5786(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5786,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5790,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[321],t2,lf[322]);}

/* k5788 in a5785 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5790,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5801,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5801(t7,((C_word*)t0)[2],t2);}

/* fold in k5788 in a5785 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_5801(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5801,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[79],t3));}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5826,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* chicken.scm: 71   fold */
t9=t5;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}

/* k5824 in fold in k5788 in a5785 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5826,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[320],((C_word*)t0)[2],t1));}

/* k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_858,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5666,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[318],t3);}

/* a5665 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5666(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5666,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5670,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[318],t2,lf[319]);}

/* k5668 in a5665 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5670,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5679,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5778,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5780,tmp=(C_word)a,a+=2,tmp);
/* map */
t7=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a5779 in k5668 in a5665 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5780(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5780,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k5776 in k5668 in a5665 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[85]+1),t1);}

/* k5677 in k5668 in a5665 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5682,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5766,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a5765 in k5677 in k5668 in a5665 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5766(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5766,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5774,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   gensym */
t4=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5772 in a5765 in k5677 in k5668 in a5665 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5774,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5680 in k5677 in k5668 in a5665 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5682,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5683,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5702,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5760,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a5759 in k5680 in k5677 in k5668 in a5665 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5760(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5760,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,lf[317]));}

/* k5700 in k5680 in k5677 in k5668 in a5665 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5702,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5706,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5710,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5712,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a5711 in k5700 in k5680 in k5677 in k5668 in a5665 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5712(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5712,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5732,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t2);
/* map */
t7=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}

/* k5730 in a5711 in k5700 in k5680 in k5677 in k5668 in a5665 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5732,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5736,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5738,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[2]);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a5737 in k5730 in a5711 in k5700 in k5680 in k5677 in k5668 in a5665 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5738(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5738,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5746,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   lookup */
t4=((C_word*)t0)[2];
f_5683(3,t4,t3,t2);}

/* k5744 in a5737 in k5730 in a5711 in k5700 in k5680 in k5677 in k5668 in a5665 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5746,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[5],((C_word*)t0)[2],t1));}

/* k5734 in k5730 in a5711 in k5700 in k5680 in k5677 in k5668 in a5665 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5736,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[2],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[4],((C_word*)t0)[2],t3));}

/* k5708 in k5700 in k5680 in k5677 in k5668 in a5665 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5704 in k5700 in k5680 in k5677 in k5668 in a5665 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5706,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[79],t2));}

/* lookup in k5680 in k5677 in k5668 in a5665 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5683(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5683,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_861,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5645,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[316],t3);}

/* a5644 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5645,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5649,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   gensym */
t5=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k5647 in a5644 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5649,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,3,lf[315],t1,((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,3,lf[2],t1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[4],t2,t4));}

/* k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_940,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5635,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[312],t3);}

/* a5634 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5635(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5635,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_867,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[312],t2,lf[314]);}

/* k865 in a5634 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_867,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_876,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(((C_word*)t0)[3]);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=t5;
f_876(t9,(C_word)C_a_i_cons(&a,2,lf[2],t8));}
else{
t6=t5;
f_876(t6,(C_word)C_i_cadr(((C_word*)t0)[3]));}}

/* k874 in k865 in a5634 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_876(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_876,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_879,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_pairp(t1);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_892,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_892(t6,t4);}
else{
t6=(C_word)C_i_car(t1);
t7=(C_word)C_eqp(lf[2],t6);
t8=t5;
f_892(t8,(C_word)C_i_not(t7));}}

/* k890 in k874 in k865 in a5634 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_892(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken.scm: 71   syntax-error */
t2=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[312],lf[313],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_879(2,t2,C_SCHEME_UNDEFINED);}}

/* k877 in k874 in k865 in a5634 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_879,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[311],t3));}

/* k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_943,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5614,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[309],t3);}

/* a5613 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5614(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5614,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5618,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[309],t2,lf[310]);}

/* k5616 in a5613 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5618,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[308],t3,t4));}

/* k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_943,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_946,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5498,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[306],t3);}

/* a5497 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5498(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5498,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5502,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[306],t2,lf[307]);}

/* k5500 in a5497 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5502,2,t0,t1);}
t2=(C_word)C_i_listp(((C_word*)t0)[3]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5511,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_5511(t5,t3);}
else{
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=t4;
f_5511(t6,(C_word)C_fixnum_lessp(t5,C_fix(2)));}}

/* k5509 in k5500 in a5497 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_5511(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5511,NULL,2,t0,t1);}
if(C_truep(t1)){
/* chicken.scm: 71   ##sys#syntax-error-hook */
t2=C_retrieve(lf[304]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[305],((C_word*)t0)[2]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[2],C_fix(0));
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5525,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5525(t7,((C_word*)t0)[3],t2);}}

/* fold in k5509 in k5500 in a5497 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_5525(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(25);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5525,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[68],((C_word*)t0)[3]));}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_not_pair_p(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5554,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   fold */
t15=t5;
t16=t4;
t1=t15;
t2=t16;
goto loop;}
else{
t5=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t5))){
t6=(C_word)C_slot(t3,C_fix(0));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5571,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   fold */
t15=t7;
t16=t4;
t1=t15;
t2=t16;
goto loop;}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_i_cadr(t3);
t8=(C_word)C_a_i_list(&a,2,t6,t7);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5589,a[2]=t9,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   fold */
t15=t10;
t16=t4;
t1=t15;
t2=t16;
goto loop;}}}}

/* k5587 in fold in k5509 in k5500 in a5497 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5589,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[4],t1,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t2));}

/* k5569 in fold in k5509 in k5500 in a5497 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5571,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[2],t1,C_SCHEME_FALSE));}

/* k5552 in fold in k5509 in k5500 in a5497 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5554,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[2],t1,C_SCHEME_FALSE));}

/* k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_949,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[6]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5399,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t5=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[301],t4);}

/* a5398 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5399(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5399,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5409,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   gensym */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k5407 in a5398 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5409,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5420,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5422,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_5422(t8,t4,((C_word*)t0)[2]);}

/* expand in k5407 in a5398 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_5422(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5422,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5438,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[301],t3,lf[302]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[303]);}}

/* k5436 in expand in k5407 in a5398 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5438,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[86],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[68],t4));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5474,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5476,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[6]);
/* map */
t7=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}}

/* a5475 in k5436 in expand in k5407 in a5398 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5476(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5476,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[296],((C_word*)t0)[2],t2));}

/* k5472 in k5436 in expand in k5407 in a5398 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5474,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[300],t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,lf[68],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5466,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   expand */
t6=((C_word*)((C_word*)t0)[3])[1];
f_5422(t6,t5,((C_word*)t0)[2]);}

/* k5464 in k5472 in k5436 in expand in k5407 in a5398 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5466,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k5418 in k5407 in a5398 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5420,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_952,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[6]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5310,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t5=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[297],t4);}

/* a5309 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5310(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5310,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5320,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   gensym */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k5318 in a5309 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5320,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5331,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5333,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_5333(t8,t4,((C_word*)t0)[2]);}

/* expand in k5318 in a5309 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_5333(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5333,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5349,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[297],t3,lf[298]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[299]);}}

/* k5347 in expand in k5318 in a5309 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5349,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[86],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[68],t4));}
else{
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,3,lf[296],((C_word*)t0)[4],t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_cons(&a,2,lf[68],t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5377,a[2]=t7,a[3]=t5,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   expand */
t9=((C_word*)((C_word*)t0)[3])[1];
f_5333(t9,t8,((C_word*)t0)[2]);}}

/* k5375 in k5347 in expand in k5318 in a5309 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5377,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k5329 in k5318 in a5309 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5331,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_955,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5024,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[293],t3);}

/* a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_5024r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5024r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5024r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5221,a[2]=t3,a[3]=t1,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[293],t3,lf[295]);}

/* k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5224,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[293],((C_word*)t0)[4],lf[294]);}

/* k5222 in k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[76]+1),((C_word*)t0)[2]);}

/* k5225 in k5222 in k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5227,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5228,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5243,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5300,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a5299 in k5225 in k5222 in k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5300(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5300,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5308,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   prefix-sym */
f_5228(t3,lf[292],t2);}

/* k5306 in a5299 in k5225 in k5222 in k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   gensym */
t2=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5241 in k5225 in k5222 in k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5246,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[291]+1),((C_word*)t0)[2]);}

/* k5244 in k5241 in k5225 in k5222 in k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5249,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[290]);}

/* k5247 in k5244 in k5241 in k5225 in k5222 in k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5252,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[289]);}

/* k5250 in k5247 in k5244 in k5241 in k5225 in k5222 in k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5255,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5290,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[8]);}

/* a5289 in k5250 in k5247 in k5244 in k5241 in k5225 in k5222 in k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5290(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5290,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5298,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   prefix-sym */
f_5228(t3,lf[288],t2);}

/* k5296 in a5289 in k5250 in k5247 in k5244 in k5241 in k5225 in k5222 in k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   gensym */
t2=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5253 in k5250 in k5247 in k5244 in k5241 in k5225 in k5222 in k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5258,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[5];
t5=t1;
t6=((C_word*)t0)[2];
t7=C_retrieve(lf[6]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5035,a[2]=t5,a[3]=t6,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   reverse */
t9=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t3);}

/* k5033 in k5253 in k5250 in k5247 in k5244 in k5241 in k5225 in k5222 in k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5039,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   reverse */
t3=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5037 in k5033 in k5253 in k5250 in k5247 in k5244 in k5241 in k5225 in k5222 in k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5039,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5043,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   reverse */
t3=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5041 in k5037 in k5033 in k5253 in k5250 in k5247 in k5244 in k5241 in k5225 in k5222 in k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5043,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5045,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_5045(t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* recur in k5041 in k5037 in k5033 in k5253 in k5250 in k5247 in k5244 in k5241 in k5225 in k5222 in k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_5045(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5045,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5090,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=t7,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* chicken.scm: 71   reverse */
t9=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t6);}}

/* k5088 in recur in k5041 in k5037 in k5033 in k5253 in k5250 in k5247 in k5244 in k5241 in k5225 in k5222 in k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5090,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5098,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5102,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   reverse */
t4=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5100 in k5088 in recur in k5041 in k5037 in k5033 in k5253 in k5250 in k5247 in k5244 in k5241 in k5225 in k5222 in k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5102,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k5096 in k5088 in recur in k5041 in k5037 in k5033 in k5253 in k5250 in k5247 in k5244 in k5241 in k5225 in k5222 in k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5098,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5066,a[2]=t4,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
t8=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 71   recur */
t9=((C_word*)((C_word*)t0)[3])[1];
f_5045(t9,t5,((C_word*)t0)[2],t6,t7,t8);}

/* k5064 in k5096 in k5088 in recur in k5041 in k5037 in k5033 in k5253 in k5250 in k5247 in k5244 in k5241 in k5225 in k5222 in k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5066,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5256 in k5253 in k5250 in k5247 in k5244 in k5241 in k5225 in k5222 in k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5258,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5261,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[9];
t7=C_retrieve(lf[6]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5118,a[2]=t9,a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_5118(t11,t2,t3,t4,C_SCHEME_END_OF_LIST);}

/* recur in k5256 in k5253 in k5250 in k5247 in k5244 in k5241 in k5225 in k5222 in k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_5118(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5118,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(C_word)C_a_i_list(&a,2,lf[74],((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,lf[111],t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5152,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   reverse */
t8=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_list(&a,2,lf[74],((C_word*)t0)[4]);
t7=(C_word)C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5218,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t6,a[7]=t1,a[8]=t5,a[9]=((C_word*)t0)[4],a[10]=t7,tmp=(C_word)a,a+=11,tmp);
/* chicken.scm: 71   reverse */
t9=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t4);}}

/* k5216 in recur in k5256 in k5253 in k5250 in k5247 in k5244 in k5241 in k5225 in k5222 in k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5218,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_list(&a,2,lf[76],((C_word*)t0)[9]);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_list(&a,2,lf[75],((C_word*)t0)[9]);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],t5);
t7=(C_word)C_a_i_list(&a,2,t4,t6);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5182,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[3]);
/* chicken.scm: 71   recur */
t12=((C_word*)((C_word*)t0)[2])[1];
f_5118(t12,t8,t9,t10,t11);}

/* k5180 in k5216 in recur in k5256 in k5253 in k5250 in k5247 in k5244 in k5241 in k5225 in k5222 in k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5182,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k5150 in recur in k5256 in k5253 in k5250 in k5247 in k5244 in k5241 in k5225 in k5222 in k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5152,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,2,lf[61],lf[287]);
t4=(C_word)C_a_i_list(&a,2,lf[278],t3);
t5=(C_word)C_a_i_list(&a,3,lf[279],t4,((C_word*)t0)[4]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[2],t2,t5));}

/* k5259 in k5256 in k5253 in k5250 in k5247 in k5244 in k5241 in k5225 in k5222 in k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5261,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,lf[2],t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,3,lf[286],t7,t1));}

/* prefix-sym in k5225 in k5222 in k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_5228(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5228,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5236,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5240,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   symbol->string */
t6=*((C_word*)lf[166]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}

/* k5238 in prefix-sym in k5225 in k5222 in k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   string-append */
t2=*((C_word*)lf[141]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5234 in prefix-sym in k5225 in k5222 in k5219 in a5023 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_5236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_958,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4967,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[283],t3);}

/* a4966 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4967(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4967,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4971,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   gensym */
t5=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k4969 in a4966 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[93],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4971,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,lf[74],t1);
t5=(C_word)C_a_i_list(&a,2,lf[75],t1);
t6=(C_word)C_a_i_list(&a,2,lf[74],t5);
t7=(C_word)C_a_i_list(&a,2,lf[111],t6);
t8=(C_word)C_a_i_list(&a,2,lf[76],t1);
t9=(C_word)C_a_i_list(&a,2,lf[61],lf[285]);
t10=(C_word)C_a_i_list(&a,2,lf[278],t9);
t11=(C_word)C_a_i_list(&a,3,lf[279],t10,t1);
t12=(C_word)C_a_i_list(&a,4,lf[72],t7,t8,t11);
t13=(C_word)C_a_i_list(&a,4,lf[72],t4,((C_word*)t0)[3],t12);
t14=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,3,lf[79],t3,t13));}

/* k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_961,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4961,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[284],t3);}

/* a4960 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4961(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4961,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[283],t2));}

/* k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_964,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4808,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[280],t3);}

/* a4807 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4808(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4808r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4808r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4808r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4812,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[280],t3,lf[282]);}

/* k4810 in a4807 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4812,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4815,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[280],((C_word*)t0)[3],lf[281]);}

/* k4813 in k4810 in a4807 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4816 in k4813 in k4810 in a4807 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4818,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4829,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4831,a[2]=t6,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4831(t8,t4,t1,((C_word*)t0)[2]);}

/* loop in k4816 in k4813 in k4810 in a4807 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_4831(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4831,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_a_i_list(&a,2,lf[74],t2);
t5=(C_word)C_a_i_list(&a,2,lf[111],t4);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,lf[79],t6);
t8=(C_word)C_a_i_list(&a,2,lf[61],lf[277]);
t9=(C_word)C_a_i_list(&a,2,lf[278],t8);
t10=(C_word)C_a_i_list(&a,3,lf[279],t9,t2);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[72],t5,t7,t10));}
else{
t4=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4881,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   gensym */
t6=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=(C_word)C_a_i_list(&a,2,t4,t2);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[3]);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[79],t7));}}}

/* k4879 in loop in k4816 in k4813 in k4810 in a4807 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[76],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4881,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,lf[74],((C_word*)t0)[5]);
t4=(C_word)C_i_cadr(((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,2,lf[76],((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,4,lf[72],t3,t4,t5);
t7=(C_word)C_a_i_list(&a,2,t2,t6);
t8=(C_word)C_a_i_list(&a,2,lf[74],((C_word*)t0)[5]);
t9=(C_word)C_a_i_list(&a,2,lf[61],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_list(&a,2,lf[75],((C_word*)t0)[5]);
t11=(C_word)C_a_i_list(&a,4,lf[72],t8,t9,t10);
t12=(C_word)C_a_i_list(&a,2,t1,t11);
t13=(C_word)C_a_i_list(&a,2,t7,t12);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4892,a[2]=t13,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken.scm: 71   loop */
t16=((C_word*)((C_word*)t0)[2])[1];
f_4831(t16,t14,t1,t15);}

/* k4890 in k4879 in loop in k4816 in k4813 in k4810 in a4807 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4892,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k4827 in k4816 in k4813 in k4810 in a4807 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4829,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_967,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4532,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[269],t3);}

/* a4531 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4532(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4532,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4566,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[269],t2,lf[276]);}

/* k4564 in a4531 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4569,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   require */
t3=C_retrieve(lf[274]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[275]);}

/* k4567 in k4564 in a4531 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4572,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4793,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4795,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a4794 in k4567 in k4564 in a4531 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4795(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4795,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4805,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#decompose-lambda-list */
t5=C_retrieve(lf[271]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a4804 in a4794 in k4567 in k4564 in a4531 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4805,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k4791 in k4567 in k4564 in a4531 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[273]+1),t1);}

/* k4570 in k4567 in k4564 in a4531 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4572,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4575,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=t1;
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4541,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4541(t7,t2,C_fix(0));}

/* loop in k4570 in k4567 in k4564 in a4531 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_4541(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4541,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4555,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   gensym */
t4=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k4553 in loop in k4570 in k4567 in k4564 in a4531 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4559,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* chicken.scm: 71   loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4541(t4,t2,t3);}

/* k4557 in k4553 in loop in k4570 in k4567 in k4564 in a4531 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4559,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4573 in k4570 in k4567 in k4564 in a4531 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4575,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4578,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4576 in k4573 in k4570 in k4567 in k4564 in a4531 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4578,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4581,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4579 in k4576 in k4573 in k4570 in k4567 in k4564 in a4531 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4581,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4588,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   append */
t3=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[6]);}

/* k4586 in k4579 in k4576 in k4573 in k4570 in k4567 in k4564 in a4531 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4588,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[265],((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4600,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4602,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   fold-right */
t7=C_retrieve(lf[161]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,t6,lf[272],((C_word*)t0)[2]);}

/* a4601 in k4586 in k4579 in k4576 in k4573 in k4570 in k4567 in k4564 in a4531 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4602,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4612,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   ##sys#decompose-lambda-list */
t6=C_retrieve(lf[271]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t4,t5);}

/* a4611 in a4601 in k4586 in k4579 in k4576 in k4573 in k4570 in k4567 in k4564 in a4531 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4612(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4612,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=((C_word*)t0)[7],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* chicken.scm: 71   ##sys#check-syntax */
t7=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,lf[269],t6,lf[270]);}

/* k4614 in a4611 in a4601 in k4586 in k4579 in k4576 in k4573 in k4570 in k4567 in k4564 in a4531 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4616,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[11],((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4626,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=(C_word)C_eqp(t2,C_fix(0));
t5=t3;
f_4626(t5,(C_truep(t4)?C_SCHEME_TRUE:(C_word)C_a_i_list(&a,3,lf[108],((C_word*)t0)[2],t2)));}
else{
t4=t3;
f_4626(t4,(C_word)C_a_i_list(&a,3,lf[268],((C_word*)t0)[2],t2));}}

/* k4624 in k4614 in a4611 in a4601 in k4586 in k4579 in k4576 in k4573 in k4570 in k4567 in k4564 in a4531 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_4626(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4626,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4630,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4632,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4642,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a4641 in k4624 in k4614 in a4611 in a4601 in k4586 in k4579 in k4576 in k4573 in k4570 in k4567 in k4564 in a4531 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4642(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4642,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4646,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4661,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4661(t8,t4,t3,((C_word*)t0)[2]);}

/* build in a4641 in k4624 in k4614 in a4611 in a4601 in k4586 in k4579 in k4576 in k4573 in k4570 in k4567 in k4564 in a4531 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_4661(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4661,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[4])){
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[79],t7));}
else{
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cadr(((C_word*)t0)[3]));}
else{
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[79],t6));}}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4717,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   gensym */
t5=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k4715 in build in a4641 in k4624 in k4614 in a4611 in a4601 in k4586 in k4579 in k4576 in k4573 in k4570 in k4567 in k4564 in a4531 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4717,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,lf[76],((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,2,lf[75],((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,t1,t5);
t7=(C_word)C_a_i_list(&a,2,t4,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4728,a[2]=t7,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken.scm: 71   build */
t11=((C_word*)((C_word*)t0)[2])[1];
f_4661(t11,t8,t10,t1);}
else{
/* chicken.scm: 71   build */
t10=((C_word*)((C_word*)t0)[2])[1];
f_4661(t10,t8,C_SCHEME_END_OF_LIST,t1);}}

/* k4726 in k4715 in build in a4641 in k4624 in k4614 in a4611 in a4601 in k4586 in k4579 in k4576 in k4573 in k4570 in k4567 in k4564 in a4531 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4728,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k4644 in a4641 in k4624 in k4614 in a4611 in a4601 in k4586 in k4579 in k4576 in k4573 in k4570 in k4567 in k4564 in a4531 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4646,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4659,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   map */
t3=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[71]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k4657 in k4644 in a4641 in k4624 in k4614 in a4611 in a4601 in k4586 in k4579 in k4576 in k4573 in k4570 in k4567 in k4564 in a4531 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4659,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],t1,((C_word*)t0)[2]));}

/* a4631 in k4624 in k4614 in a4611 in a4601 in k4586 in k4579 in k4576 in k4573 in k4570 in k4567 in k4564 in a4531 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4640,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   take */
t3=C_retrieve(lf[267]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4638 in a4631 in k4624 in k4614 in a4611 in a4601 in k4586 in k4579 in k4576 in k4573 in k4570 in k4567 in k4564 in a4531 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   split-at! */
t2=C_retrieve(lf[266]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4628 in k4624 in k4614 in a4611 in a4601 in k4586 in k4579 in k4576 in k4573 in k4570 in k4567 in k4564 in a4531 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4630,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[3],t1,((C_word*)t0)[2]));}

/* k4598 in k4586 in k4579 in k4576 in k4573 in k4570 in k4567 in k4564 in a4531 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4600,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[2],t2));}

/* k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_970,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4475,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[262],t3);}

/* a4474 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4475(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr3r,(void*)f_4475r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4475r(t0,t1,t2,t3);}}

static void C_ccall f_4475r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(16);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4485,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* chicken.scm: 71   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,lf[262],t5,lf[263]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4515,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* chicken.scm: 71   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,lf[262],t5,lf[264]);}}

/* k4513 in a4474 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4515,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[261],t3));}

/* k4483 in a4474 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4485,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(0));
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=(C_word)C_a_i_cons(&a,2,lf[2],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[261],t3,t6));}

/* k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_973,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4399,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[254],t3);}

/* a4398 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4399(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4399r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4399r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4399r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4403,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   gensym */
t6=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k4401 in a4398 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4406,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4404 in k4401 in a4398 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[114],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4406,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_list(&a,3,lf[2],t3,t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t8=(C_word)C_a_i_cons(&a,2,lf[2],t7);
t9=(C_word)C_a_i_list(&a,3,lf[257],lf[258],t1);
t10=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t9);
t11=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t10);
t12=(C_word)C_a_i_list(&a,3,lf[2],t1,t11);
t13=(C_word)C_a_i_list(&a,3,lf[4],t8,t12);
t14=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t13);
t15=(C_word)C_a_i_list(&a,3,lf[259],t6,t14);
t16=(C_word)C_a_i_list(&a,3,lf[2],t2,t15);
t17=(C_word)C_a_i_list(&a,2,lf[260],t16);
t18=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_list(&a,1,t17));}

/* k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_976,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4215,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[256],t3);}

/* a4214 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4215(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4215r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4215r(t0,t1,t2,t3);}}

static void C_ccall f_4215r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4219,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   gensym */
t5=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k4217 in a4214 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4219,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4222,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4220 in k4217 in a4214 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4222,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4224,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,2,lf[61],lf[252]);
t4=(C_word)C_a_i_list(&a,3,lf[242],((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_list(&a,3,lf[253],((C_word*)t0)[5],C_fix(1));
t6=(C_word)C_a_i_list(&a,3,lf[110],t4,t5);
t7=(C_word)C_a_i_list(&a,2,t1,t6);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4361,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4365,a[2]=t9,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t11=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,t2,((C_word*)t0)[2]);}

/* k4363 in k4220 in k4217 in a4214 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4365,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[255],((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[86],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* ##sys#append */
t5=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k4359 in k4220 in k4217 in a4214 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4361,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[83],t1);
t3=(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[5],t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,4,lf[254],((C_word*)t0)[3],t3,((C_word*)t0)[2]));}

/* parse-clause in k4220 in k4217 in a4214 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4224(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[34],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4224,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_symbolp(t3);
t5=(C_truep(t4)?(C_word)C_i_car(t2):C_SCHEME_FALSE);
t6=(C_truep(t5)?(C_word)C_i_cadr(t2):(C_word)C_i_car(t2));
t7=(C_truep(t5)?(C_word)C_i_cddr(t2):(C_word)C_i_cdr(t2));
if(C_truep((C_word)C_i_nullp(t6))){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4247,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t5)){
t9=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[3]);
t10=(C_word)C_a_i_list(&a,1,t9);
t11=(C_word)C_a_i_cons(&a,2,t10,t7);
t12=t8;
f_4247(t12,(C_word)C_a_i_cons(&a,2,lf[79],t11));}
else{
t9=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t7);
t10=t8;
f_4247(t10,(C_word)C_a_i_cons(&a,2,lf[79],t9));}}
else{
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4310,a[2]=t7,a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4312,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t10=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t9,t6);}}

/* a4311 in parse-clause in k4220 in k4217 in a4214 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4312(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4312,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[251],t3,((C_word*)t0)[2]));}

/* k4308 in parse-clause in k4220 in k4217 in a4214 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4310,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[110],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4280,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[2]);
t8=t4;
f_4280(t8,(C_word)C_a_i_cons(&a,2,lf[79],t7));}
else{
t5=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t6=t4;
f_4280(t6,(C_word)C_a_i_cons(&a,2,lf[79],t5));}}

/* k4278 in k4308 in parse-clause in k4220 in k4217 in a4214 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_4280(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4280,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k4245 in parse-clause in k4220 in k4217 in a4214 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_4247(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4247,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[86],t1));}

/* k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_979,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4025,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[250],t3);}

/* a4024 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4025(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_4025r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_4025r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_4025r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t6=(C_word)C_i_cdr(t3);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4032,a[2]=t6,a[3]=t5,a[4]=t1,a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* map */
t8=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,*((C_word*)lf[76]+1),t5);}

/* k4030 in a4024 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4032,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4204,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4206,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a4205 in k4030 in a4024 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4206(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4206,3,t0,t1,t2);}
t3=(C_word)C_i_memq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:lf[249]));}

/* k4202 in k4030 in a4024 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4204,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[240],t2);
t4=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],lf[241]);
t6=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t7=(C_word)C_a_i_list(&a,3,lf[242],lf[241],t6);
t8=(C_word)C_a_i_list(&a,3,lf[82],t5,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4055,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4057,a[2]=t11,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t13=((C_word*)t11)[1];
f_4057(t13,t9,((C_word*)t0)[2],C_fix(1));}

/* loop in k4202 in k4030 in a4024 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_4057(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[112],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4057,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_memq(lf[243],C_retrieve(lf[55]));
t6=(C_word)C_i_cddr(t4);
t7=(C_word)C_i_pairp(t6);
t8=(C_word)C_a_i_list(&a,1,lf[241]);
t9=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[3]);
t10=(C_word)C_a_i_list(&a,3,lf[244],lf[241],t9);
t11=(C_word)C_a_i_list(&a,2,lf[111],t10);
t12=(C_word)C_a_i_list(&a,3,lf[245],lf[241],t3);
t13=(C_word)C_a_i_list(&a,4,lf[2],t8,t11,t12);
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4083,a[2]=t13,a[3]=t5,a[4]=t7,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,a[8]=t1,a[9]=t4,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t7)){
t15=(C_word)C_i_caddr(t4);
t16=(C_word)C_a_i_list(&a,3,t15,lf[241],lf[247]);
t17=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[3]);
t18=(C_word)C_a_i_list(&a,3,lf[244],lf[241],t17);
t19=(C_word)C_a_i_list(&a,2,lf[111],t18);
t20=(C_word)C_a_i_list(&a,4,lf[248],lf[241],t3,lf[247]);
t21=(C_word)C_a_i_list(&a,4,lf[82],t16,t19,t20);
t22=t14;
f_4083(t22,(C_word)C_a_i_list(&a,1,t21));}
else{
t15=t14;
f_4083(t15,C_SCHEME_END_OF_LIST);}}}

/* k4081 in loop in k4202 in k4030 in a4024 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_4083(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4083,NULL,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4111,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[3]:C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[9]);
t6=t3;
f_4111(t6,(C_word)C_a_i_list(&a,3,lf[246],((C_word*)t0)[2],t5));}
else{
t5=t3;
f_4111(t5,((C_word*)t0)[2]);}}

/* k4109 in k4081 in loop in k4202 in k4030 in a4024 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_4111(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4111,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4095,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* chicken.scm: 71   loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_4057(t6,t3,t4,t5);}

/* k4093 in k4109 in k4081 in loop in k4202 in k4030 in a4024 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4095,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* ##sys#append */
t3=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4053 in k4202 in k4030 in a4024 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4055,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[68],t3));}

/* k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_982,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4016,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[238],t3);}

/* a4015 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4016(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4016,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4020,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[238],t2,lf[239]);}

/* k4018 in a4015 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4020,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[237],((C_word*)t0)[2]));}

/* k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_985,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3997,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[235],t3);}

/* a3996 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3997(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3997,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4001,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[235],t2,lf[236]);}

/* k3999 in a3996 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4008,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4010,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4009 in k3999 in a3996 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4010(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4010,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k4006 in k3999 in a3996 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_4008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4008,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[232],t1));}

/* k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_988,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3978,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[233],t3);}

/* a3977 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3978(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3978,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3982,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[233],t2,lf[234]);}

/* k3980 in a3977 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3989,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3991,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3990 in k3980 in a3977 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3991(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3991,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3987 in k3980 in a3977 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3989,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[232],t1));}

/* k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_991,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3850,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[231],t3);}

/* a3849 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3850(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3850,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3856,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3856(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in a3849 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_3856(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(15);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3856,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3866,a[2]=t4,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   reverse */
t7=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t3);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[228]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3937,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   gensym */
t9=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t9))(2,t9,t8);}
else{
t8=(C_word)C_eqp(t6,lf[229]);
if(C_truep(t8)){
/* chicken.scm: 71   loop */
t15=t1;
t16=C_SCHEME_END_OF_LIST;
t17=t3;
t18=t4;
t19=C_SCHEME_TRUE;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
t5=t19;
goto loop;}
else{
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_car(t2);
t11=(C_word)C_a_i_cons(&a,2,t10,t4);
/* chicken.scm: 71   loop */
t15=t1;
t16=t9;
t17=t3;
t18=t11;
t19=C_SCHEME_FALSE;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
t5=t19;
goto loop;}}}}

/* k3935 in loop in a3849 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3937,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* chicken.scm: 71   loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3856(t5,((C_word*)t0)[2],t2,t3,t4,C_SCHEME_FALSE);}

/* k3864 in loop in a3849 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3869,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   reverse */
t3=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3867 in k3864 in loop in a3849 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3869,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3875,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_a_i_list(&a,2,lf[68],t2);
t4=(C_word)C_i_cdr(t1);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[2],t5));}}

/* k3873 in k3867 in k3864 in loop in a3849 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3882,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k3880 in k3873 in k3867 in k3864 in loop in a3849 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3882,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3898,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* ##sys#append */
t6=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k3896 in k3880 in k3873 in k3867 in k3864 in loop in a3849 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3898,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[227],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[2],t3));}

/* k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_994,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3707,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[230],t3);}

/* a3706 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3707(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3707,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3713,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3713(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in a3706 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_3713(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(22);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3713,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t2))){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3723,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   reverse */
t8=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_eqp(t7,lf[228]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3798,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   gensym */
t10=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t10))(2,t10,t9);}
else{
t9=(C_word)C_eqp(t7,lf[229]);
if(C_truep(t9)){
/* chicken.scm: 71   loop */
t14=t1;
t15=C_SCHEME_END_OF_LIST;
t16=t3;
t17=t4;
t18=t5;
t19=C_SCHEME_TRUE;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
t5=t18;
t6=t19;
goto loop;}
else{
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3825,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t4,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   gensym */
t11=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t11))(2,t11,t10);}}}}

/* k3823 in loop in a3706 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3825,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
t6=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* chicken.scm: 71   loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_3713(t7,((C_word*)t0)[3],t2,((C_word*)t0)[2],t5,t6,C_SCHEME_FALSE);}

/* k3796 in loop in a3706 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3798,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* chicken.scm: 71   loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3713(t5,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2],t4,C_SCHEME_FALSE);}

/* k3721 in loop in a3706 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3726,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   reverse */
t3=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3724 in k3721 in loop in a3706 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3726,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3732,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[2],t4);
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[3],t5));}}

/* k3730 in k3724 in k3721 in loop in a3706 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3732,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3743,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k3741 in k3730 in k3724 in k3721 in loop in a3706 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3743,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3759,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* ##sys#append */
t6=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k3757 in k3741 in k3730 in k3724 in k3721 in loop in a3706 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3759,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[227],t2);
t4=(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t4));}

/* k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_997,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3648,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[226],t3);}

/* a3647 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3648(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc_2(c,6,t0);
if(!C_demand(c*C_SIZEOF_PAIR+51)){
C_save_and_reclaim((void*)tr6r,(void*)f_3648r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_3648r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_3648r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(51);
t7=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_i_caddr(t2);
t9=(C_word)C_i_car(t2);
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_a_i_list(&a,3,t8,t9,t10);
t12=(C_word)C_a_i_list(&a,4,lf[223],t3,t4,t5);
t13=(C_word)C_a_i_cons(&a,2,t12,t6);
t14=(C_word)C_a_i_cons(&a,2,t11,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[224],t14));}
else{
t8=(C_word)C_a_i_list(&a,4,lf[225],t3,t4,t5);
t9=(C_word)C_a_i_cons(&a,2,t8,t6);
t10=(C_word)C_a_i_cons(&a,2,t2,t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[224],t10));}}

/* k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1000,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3477,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[220],t3);}

/* a3476 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3477(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_3477r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3477r(t0,t1,t2,t3);}}

static void C_ccall f_3477r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3483,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3483(t7,t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t3,C_SCHEME_FALSE);}

/* loop in a3476 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_3483(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3483,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t4))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3493,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=(C_word)C_a_i_cons(&a,2,lf[215],t5);
t8=t6;
f_3493(t8,(C_word)C_a_i_list(&a,2,lf[133],t7));}
else{
t7=t6;
f_3493(t7,lf[216]);}}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3557,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_i_car(t4);
t8=t6;
f_3557(t8,(C_word)C_i_pairp(t7));}
else{
t7=t6;
f_3557(t7,C_SCHEME_FALSE);}}}

/* k3555 in loop in a3476 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_3557(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3557,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3560,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   caar */
t3=*((C_word*)lf[152]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
/* chicken.scm: 71   syntax-error */
t2=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[220],lf[222],((C_word*)t0)[7]);}}

/* k3558 in k3555 in loop in a3476 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3560,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_eqp(lf[217],t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3584,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   cdar */
t5=*((C_word*)lf[218]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(lf[219],t1);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3605,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   cdar */
t6=*((C_word*)lf[218]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(lf[215],t1);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3618,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=((C_word*)t0)[2];
t8=(C_truep(t7)?t7:C_SCHEME_END_OF_LIST);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3626,a[2]=t8,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   cdar */
t10=*((C_word*)lf[218]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[7]);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3633,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   caar */
t7=*((C_word*)lf[152]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[7]);}}}}

/* k3631 in k3558 in k3555 in loop in a3476 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   syntax-error */
t2=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[220],lf[221],t1);}

/* k3624 in k3558 in k3555 in loop in a3476 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   append */
t2=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3616 in k3558 in k3555 in loop in a3476 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   loop */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3483(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3603 in k3558 in k3555 in loop in a3476 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3605,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[68],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* chicken.scm: 71   loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3483(t4,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3582 in k3558 in k3555 in loop in a3476 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3584,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[68],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* chicken.scm: 71   loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3483(t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3491 in loop in a3476 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_3493(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[63],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3493,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,lf[210],t2);
t4=(C_word)C_a_i_list(&a,2,lf[211],lf[54]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,lf[212],((C_word*)t0)[4]);
t7=(C_word)C_a_i_list(&a,2,lf[133],t6);
t8=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t9=(C_word)C_a_i_list(&a,2,lf[213],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)t0)[3]);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,t7,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[86],t12);
t14=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,4,lf[214],t3,t5,t13));}

/* k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1003,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3426,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[209],t3);}

/* a3425 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3426(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+39)){
C_save_and_reclaim((void*)tr3r,(void*)f_3426r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3426r(t0,t1,t2,t3);}}

static void C_ccall f_3426r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(39);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,t5,t3);
t7=(C_word)C_a_i_cons(&a,2,lf[2],t6);
t8=(C_word)C_a_i_list(&a,2,t4,t7);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(C_word)C_i_car(t2);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,3,lf[208],t9,t10));}
else{
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[208],t5,t2));}}

/* k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1006,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3366,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[206],t3);}

/* a3365 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3366(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_3366r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3366r(t0,t1,t2,t3);}}

static void C_ccall f_3366r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[203]:t3);
t6=(C_word)C_i_pairp(t2);
t7=(C_truep(t6)?(C_word)C_i_car(t2):t2);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3376,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,t5);
t11=t8;
f_3376(t11,(C_word)C_a_i_cons(&a,2,lf[2],t10));}
else{
t9=t8;
f_3376(t9,(C_word)C_i_car(t5));}}

/* k3374 in a3365 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_3376(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3376,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3379,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3395,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   eval */
t4=C_retrieve(lf[147]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}
else{
/* chicken.scm: 71   syntax-error */
t3=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[206],lf[207],((C_word*)t0)[2]);}}

/* k3393 in k3374 in a3365 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3379(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* k3377 in k3374 in a3365 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3379,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[204]))?(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[3],((C_word*)t0)[2]):lf[205]));}

/* k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1009,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   register-feature! */
t3=C_retrieve(lf[196]);
((C_proc8)C_retrieve_proc(t3))(8,t3,t2,lf[197],lf[198],lf[199],lf[200],lf[201],lf[202]);}

/* k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1012,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3329,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[84],t3);}

/* a3328 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3329(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3329,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3333,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[84],t2,lf[195]);}

/* k3331 in a3328 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3333,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,2,lf[61],t4);
t6=(C_word)C_i_cddr(((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,t3,t7);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[194],t8));}

/* k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1015,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3310,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[90],t3);}

/* a3309 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3310(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3310,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3314,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[90],t2,lf[193]);}

/* k3312 in a3309 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3321,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3323,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3322 in k3312 in a3309 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3323(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3323,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3319 in k3312 in a3309 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3321,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[164],t1));}

/* k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1018,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3291,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[191],t3);}

/* a3290 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3291(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3291,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3295,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[191],t2,lf[192]);}

/* k3293 in a3290 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3302,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3304,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3303 in k3293 in a3290 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3304(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3304,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3300 in k3293 in a3290 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3302,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[190],t1));}

/* k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1021,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3272,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[107],t3);}

/* a3271 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3272(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3272,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3276,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[107],t2,lf[189]);}

/* k3274 in a3271 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3283,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3285,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3284 in k3274 in a3271 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3285(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3285,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3281 in k3274 in a3271 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3283,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[188],t1));}

/* k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1024,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3253,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[186],t3);}

/* a3252 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3253(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3253,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3257,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[186],t2,lf[187]);}

/* k3255 in a3252 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3264,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3266,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3265 in k3255 in a3252 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3266(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3266,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3262 in k3255 in a3252 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3264,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[185],t1));}

/* k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1027,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3234,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[183],t3);}

/* a3233 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3234(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3234,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3238,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[183],t2,lf[184]);}

/* k3236 in a3233 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3245,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3247,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3246 in k3236 in a3233 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3247(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3247,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3243 in k3236 in a3233 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3245,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[182],t1));}

/* k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1030,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3215,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[180],t3);}

/* a3214 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3215(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3215,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3219,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[180],t2,lf[181]);}

/* k3217 in a3214 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3219,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3226,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3228,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3227 in k3217 in a3214 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3228(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3228,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3224 in k3217 in a3214 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3226,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[179],t1));}

/* k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1033,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3115,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[174],t3);}

/* a3114 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3115(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3115,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3119,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[174],t2,lf[178]);}

/* k3117 in a3114 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3119,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_stringp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[174],((C_word*)t0)[3],lf[175]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3174,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[174],((C_word*)t0)[3],lf[177]);}}

/* k3172 in k3117 in a3114 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3174,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_a_i_list(&a,2,lf[61],lf[176]);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(C_word)C_a_i_list(&a,2,lf[61],t5);
t7=(C_word)C_i_caddr(((C_word*)t0)[3]);
t8=(C_word)C_a_i_list(&a,2,lf[61],t7);
t9=(C_word)C_i_cadddr(((C_word*)t0)[3]);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,6,lf[171],t3,t4,t6,t8,t9));}

/* k3126 in k3117 in a3114 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3128,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_i_caddr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,2,lf[61],t4);
t6=(C_word)C_i_car(((C_word*)t0)[3]);
t7=(C_word)C_a_i_list(&a,2,lf[61],t6);
t8=(C_word)C_i_cadddr(((C_word*)t0)[3]);
t9=(C_word)C_a_i_list(&a,2,lf[61],t8);
t10=(C_word)C_i_cdr(((C_word*)t0)[3]);
t11=(C_word)C_i_cadddr(t10);
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_list(&a,6,lf[171],t3,t5,t7,t9,t11));}

/* k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1036,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2895,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[168],t3);}

/* a2894 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2895(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2895,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2899,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=t3;
f_2899(t5,(C_word)C_i_stringp(t4));}
else{
t4=t3;
f_2899(t4,C_SCHEME_FALSE);}}

/* k2897 in a2894 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_2899(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2899,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2902,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=t1;
if(C_truep(t3)){
t4=t2;
f_2902(t4,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=t2;
f_2902(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t2;
f_2902(t4,C_SCHEME_FALSE);}}}

/* k2900 in k2897 in a2894 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_2902(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2902,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2908,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[168],((C_word*)t0)[4],lf[169]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2983,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* chicken.scm: 72   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[168],((C_word*)t0)[4],lf[172]);}
else{
/* chicken.scm: 72   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[168],((C_word*)t0)[4],lf[173]);}}}

/* k2981 in k2900 in k2897 in a2894 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2983,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cadr(((C_word*)t0)[3]):(C_word)C_i_car(((C_word*)t0)[3]));
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_list(&a,2,lf[61],t5);
t7=(C_truep(((C_word*)t0)[4])?(C_word)C_i_car(((C_word*)t0)[3]):lf[170]);
t8=(C_word)C_a_i_list(&a,2,lf[61],t7);
t9=(C_truep(((C_word*)t0)[4])?(C_word)C_i_caddr(((C_word*)t0)[3]):(C_word)C_i_cadr(((C_word*)t0)[3]));
t10=(C_word)C_a_i_list(&a,2,lf[61],t9);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3048,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t10,a[6]=t8,a[7]=t6,a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[4],tmp=(C_word)a,a+=10,tmp);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3050,tmp=(C_word)a,a+=2,tmp);
/* map */
t13=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,t12,t3);}

/* a3049 in k2981 in k2900 in k2897 in a2894 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3050(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3050,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k3046 in k2981 in k2900 in k2897 in a2894 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3048,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3028,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3040,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a3039 in k3046 in k2981 in k2900 in k2897 in a2894 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3040(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3040,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k3026 in k3046 in k2981 in k2900 in k2897 in a2894 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_3028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3028,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[9])?(C_word)C_i_cdddr(((C_word*)t0)[8]):(C_word)C_i_cddr(((C_word*)t0)[8]));
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[2],t3);
t5=(C_word)C_a_i_list(&a,6,lf[171],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[2],t5));}

/* k2906 in k2900 in k2897 in a2894 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[68],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2908,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,2,lf[61],t4);
t6=(C_word)C_a_i_list(&a,3,lf[164],t3,t5);
t7=(C_word)C_a_i_list(&a,2,lf[61],t2);
t8=(C_word)C_i_cadr(((C_word*)t0)[3]);
t9=(C_word)C_a_i_list(&a,2,lf[61],t8);
t10=(C_word)C_a_i_list(&a,2,lf[61],C_SCHEME_TRUE);
t11=(C_word)C_a_i_list(&a,4,lf[165],t7,t9,t10);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2934,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
t13=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t13))){
t14=(C_word)C_i_caddr(((C_word*)t0)[3]);
t15=(C_word)C_a_i_list(&a,3,lf[5],t2,t14);
t16=t12;
f_2934(t16,(C_word)C_a_i_list(&a,1,t15));}
else{
t14=t12;
f_2934(t14,C_SCHEME_END_OF_LIST);}}

/* k2932 in k2906 in k2900 in k2897 in a2894 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_2934(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2934,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[68],t3));}

/* k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1039,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2820,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[167],t3);}

/* a2819 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2820(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2820r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2820r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2820r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2824,a[2]=t4,a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 72   gensym */
t6=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k2822 in a2819 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2824,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* chicken.scm: 72   symbol->string */
t5=*((C_word*)lf[166]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}

/* k2891 in k2822 in a2819 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[74],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2893,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],t1);
t3=(C_word)C_a_i_list(&a,4,lf[164],((C_word*)t0)[8],((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,lf[61],C_SCHEME_FALSE);
t7=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t8=(C_word)C_a_i_list(&a,5,lf[165],t4,t5,t6,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2847,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[2]))){
t10=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t11=(C_word)C_a_i_list(&a,3,lf[5],((C_word*)t0)[6],t10);
t12=t9;
f_2847(t12,(C_word)C_a_i_list(&a,1,t11));}
else{
t10=t9;
f_2847(t10,C_SCHEME_END_OF_LIST);}}

/* k2845 in k2891 in k2822 in a2819 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_2847(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2847,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[68],t3));}

/* k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1039,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1042,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2714,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[163],t3);}

/* a2713 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2714(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_2714r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2714r(t0,t1,t2,t3);}}

static void C_ccall f_2714r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2718,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2814,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a2813 in a2713 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2814(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2814,3,t0,t1,t2);}
/* chicken.scm: 72   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k2716 in a2713 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2725,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2790,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   append-map */
t4=C_retrieve(lf[162]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],t1);}

/* a2789 in k2716 in a2713 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2790(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2790,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cddr(t2);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}}

/* k2723 in k2716 in a2713 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2729,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2731,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t5=(C_word)C_a_i_cons(&a,2,lf[79],t4);
/* chicken.scm: 72   fold-right */
t6=C_retrieve(lf[161]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t2,t3,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2730 in k2723 in k2716 in a2713 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[51],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2731,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t2);
t6=(C_word)C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_a_i_list(&a,2,lf[61],t7);
t9=(C_word)C_i_cadr(t2);
t10=(C_word)C_a_i_list(&a,2,lf[61],t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,5,lf[160],t8,t10,t3,t4));}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_a_i_list(&a,2,lf[61],t7);
t9=(C_word)C_i_cadr(t2);
t10=(C_word)C_a_i_list(&a,2,lf[61],t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[160],t8,t10,t4));}}

/* k2727 in k2723 in k2716 in a2713 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2729,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1045,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2685,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[159],t3);}

/* a2684 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2685(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2685,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2689,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   gensym */
t4=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[155]);}

/* k2687 in a2684 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2708,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2712,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   string-intersperse */
t4=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[158]);}

/* k2710 in k2687 in a2684 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   sprintf */
t2=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[157],((C_word*)t0)[2],t1);}

/* k2706 in k2687 in a2684 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2708,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[98],t1);
t3=(C_word)C_a_i_list(&a,2,lf[133],t2);
t4=(C_word)C_a_i_list(&a,2,lf[130],((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[68],t3,t4));}

/* k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1048,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2672,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[156],t3);}

/* a2671 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2672(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2672,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2676,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 72   gensym */
t5=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[155]);}

/* k2674 in a2671 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2676,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[90],t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[68],t2,t1));}

/* k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1051,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1878,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[112],t3);}

/* a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1878(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_1878r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1878r(t0,t1,t2,t3);}}

static void C_ccall f_1878r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1882,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cadr(t2);
/* chicken.scm: 72   ->string */
t7=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
/* chicken.scm: 72   sprintf */
t6=C_retrieve(lf[62]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[154],t2);}}

/* k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1882,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[4]):((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1888,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 72   gensym */
t5=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1888,2,t0,t1);}
t2=*((C_word*)lf[101]+1);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=t1,a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
/* chicken.scm: 72   gensym */
t9=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t9))(2,t9,t8);}

/* k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1894,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken.scm: 72   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* chicken.scm: 72   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1897,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1899,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t7=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1942,a[2]=t5,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=t5,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t1,a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[11],tmp=(C_word)a,a+=16,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2564,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=t10,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_2564(t12,t8,((C_word*)((C_word*)t0)[6])[1]);}

/* do539 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_2564(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2564,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_2574(t5,t3);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_pairp(t5);
t7=(C_word)C_i_not(t6);
if(C_truep(t7)){
t8=t4;
f_2574(t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2639,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2643,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 72   caar */
t10=*((C_word*)lf[152]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t2);}}}

/* k2641 in do539 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   keyword? */
t2=C_retrieve(lf[153]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2637 in do539 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2574(t2,(C_word)C_i_not(t1));}

/* k2572 in do539 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_2574(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2574,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2578,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 72   caar */
t3=*((C_word*)lf[152]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}}

/* k2576 in k2572 in do539 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2578,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2581,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[146]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2595,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2599,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 72   cadar */
t6=*((C_word*)lf[148]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(t1,lf[149]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2609,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   cadar */
t6=*((C_word*)lf[148]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(t1,lf[150]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2619,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   cadar */
t7=*((C_word*)lf[148]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[7]);}
else{
t6=(C_word)C_i_car(((C_word*)t0)[7]);
/* chicken.scm: 72   syntax-error */
t7=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t2,lf[112],lf[151],t6);}}}}

/* k2617 in k2576 in k2572 in do539 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2581(2,t3,t2);}

/* k2607 in k2576 in k2572 in do539 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2581(2,t3,t2);}

/* k2597 in k2576 in k2572 in do539 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   eval */
t2=C_retrieve(lf[147]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2593 in k2576 in k2572 in do539 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2581(2,t3,t2);}

/* k2579 in k2576 in k2572 in do539 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2564(t3,((C_word*)t0)[2],t2);}

/* k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1988,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t3=(C_word)C_a_i_list(&a,2,lf[104],((C_word*)t0)[3]);
/* chicken.scm: 72   ##sys#hash-table-set! */
t4=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[145]),((C_word*)t0)[14],t3);}

/* k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1995,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1999,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=t2,tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=t3;
f_1999(t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2471,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2475,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2487,a[2]=((C_word*)t0)[6],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2558,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 72   ->string */
t8=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[2]);}}

/* k2556 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string-append */
t2=*((C_word*)lf[141]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[142],t1,lf[143]);}

/* k2485 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2491,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2493,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a2492 in k2485 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2493(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2493,3,t0,t1,t2);}
t3=(C_word)C_i_length(t2);
switch(t3){
case C_fix(3):
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2510,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2522,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cadr(t2);
/* chicken.scm: 72   ->string */
t8=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);
case C_fix(2):
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2539,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2547,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cadr(t2);
/* chicken.scm: 72   ->string */
t8=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);
default:
/* chicken.scm: 72   syntax-error */
t4=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[112],lf[140],t2);}}

/* k2545 in a2492 in k2485 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   ##compiler#foreign-type-declaration */
t2=C_retrieve(lf[138]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2537 in a2492 in k2485 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   sprintf */
t2=C_retrieve(lf[62]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[139],t1);}

/* k2520 in a2492 in k2485 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   ##compiler#foreign-type-declaration */
t2=C_retrieve(lf[138]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2508 in a2492 in k2485 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_caddr(((C_word*)t0)[3]);
/* chicken.scm: 72   sprintf */
t3=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[137],t1,t2);}

/* k2489 in k2485 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2491,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_list(&a,1,lf[136]);
/* chicken.scm: 72   append */
t4=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t2,t3);}

/* k2473 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string-intersperse */
t2=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[135]);}

/* k2469 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2471,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[98],t1);
t3=(C_word)C_a_i_list(&a,2,lf[133],t2);
t4=((C_word*)t0)[2];
f_1999(t4,(C_word)C_a_i_list(&a,1,t3));}

/* k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_1999(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1999,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2003,a[2]=t1,a[3]=((C_word*)t0)[14],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2007,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2453,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 72   sprintf */
t6=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[132],((C_word*)t0)[2],((C_word*)t0)[2]);}
else{
t5=t3;
f_2007(t5,C_SCHEME_END_OF_LIST);}}

/* k2451 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2453,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[107],((C_word*)t0)[4],C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)((C_word*)t0)[3])[1],t2);
t4=((C_word*)t0)[2];
f_2007(t4,(C_word)C_a_i_list(&a,1,t3));}

/* k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_2007(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2007,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2011,a[2]=t1,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2015,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
t4=((C_word*)((C_word*)t0)[2])[1];
if(C_truep(t4)){
t5=(C_word)C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],lf[129]);
t6=(C_word)C_a_i_list(&a,3,lf[130],lf[131],lf[129]);
t7=(C_word)C_a_i_list(&a,3,lf[110],lf[129],t6);
t8=(C_word)C_a_i_list(&a,3,lf[82],t5,t7);
t9=t3;
f_2015(t9,(C_word)C_a_i_list(&a,1,t8));}
else{
t5=t3;
f_2015(t5,C_SCHEME_END_OF_LIST);}}

/* k2013 in k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_2015(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2015,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2019,a[2]=t1,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2021,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a2020 in k2013 in k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2021(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2021,3,t0,t1,t2);}
t3=(C_word)C_i_length(t2);
switch(t3){
case C_fix(3):
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_caddr(t2);
t7=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2043,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t1,a[8]=t6,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* chicken.scm: 72   stype */
t8=((C_word*)((C_word*)t0)[2])[1];
f_1899(t8,t7,t4);
case C_fix(2):
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cadr(t2);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2298,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* chicken.scm: 72   stype */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1899(t7,t6,t4);
default:
/* chicken.scm: 72   syntax-error */
t4=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[112],lf[128],t2);}}

/* k2296 in a2020 in k2013 in k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2375,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2406,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2410,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   sprintf */
t5=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[127],((C_word*)t0)[9],((C_word*)t0)[4]);}

/* k2408 in k2296 in a2020 in k2013 in k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   renamer */
t2=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2404 in k2296 in a2020 in k2013 in k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2373 in k2296 in a2020 in k2013 in k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2375,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2387,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=t3,a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2398,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 72   strtype */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1942(t6,t5,((C_word*)t0)[6]);}

/* k2396 in k2373 in k2296 in a2020 in k2013 in k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[124]:lf[125]);
/* chicken.scm: 72   sprintf */
t3=C_retrieve(lf[62]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],lf[126],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2385 in k2373 in k2296 in a2020 in k2013 in k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2387,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[107],((C_word*)t0)[11],((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[9],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2313,a[2]=((C_word*)t0)[8],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2316,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[7],a[9]=t4,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t6=(C_word)C_i_car(((C_word*)t0)[7]);
t7=t5;
f_2316(t7,(C_word)C_eqp(lf[102],t6));}
else{
t6=t5;
f_2316(t6,C_SCHEME_FALSE);}}

/* k2314 in k2385 in k2373 in k2296 in a2020 in k2013 in k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_2316(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2316,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
f_2313(t2,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[8],((C_word*)t0)[7]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2333,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2357,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2361,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   sprintf */
t6=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[123],((C_word*)t0)[6],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[9];
f_2313(t3,C_SCHEME_END_OF_LIST);}}}

/* k2359 in k2314 in k2385 in k2373 in k2296 in a2020 in k2013 in k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   renamer */
t2=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2355 in k2314 in k2385 in k2373 in k2296 in a2020 in k2013 in k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2331 in k2314 in k2385 in k2373 in k2296 in a2020 in k2013 in k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2333,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2345,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 72   sprintf */
t6=C_retrieve(lf[62]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,lf[122],((C_word*)t0)[6],((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k2343 in k2331 in k2314 in k2385 in k2373 in k2296 in a2020 in k2013 in k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2345,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[107],lf[114],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_2313(t4,(C_word)C_a_i_list(&a,1,t3));}

/* k2311 in k2385 in k2373 in k2296 in a2020 in k2013 in k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_2313(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2313,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[68],t2));}

/* k2041 in a2020 in k2013 in k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2184,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2279,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2283,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   sprintf */
t5=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[121],((C_word*)t0)[12],((C_word*)t0)[4]);}

/* k2281 in k2041 in a2020 in k2013 in k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   renamer */
t2=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2277 in k2041 in a2020 in k2013 in k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2182 in k2041 in a2020 in k2013 in k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2184,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[13],((C_word*)t0)[12]);
t3=(C_word)C_a_i_list(&a,2,lf[106],((C_word*)t0)[11]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2256,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[9],a[13]=t4,a[14]=((C_word*)t0)[10],tmp=(C_word)a,a+=15,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2267,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[12],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 72   strtype */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1942(t7,t6,((C_word*)t0)[6]);}

/* k2265 in k2182 in k2041 in a2020 in k2013 in k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[118]:lf[119]);
/* chicken.scm: 72   sprintf */
t3=C_retrieve(lf[62]);
((C_proc7)C_retrieve_proc(t3))(7,t3,((C_word*)t0)[5],lf[120],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2254 in k2182 in k2041 in a2020 in k2013 in k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[161],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2256,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[107],((C_word*)t0)[14],((C_word*)t0)[13],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[12],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[11],((C_word*)t0)[10]);
t6=(C_word)C_a_i_list(&a,3,lf[108],((C_word*)t0)[10],C_fix(0));
t7=(C_word)C_a_i_list(&a,3,lf[109],((C_word*)t0)[10],((C_word*)t0)[9]);
t8=(C_word)C_a_i_list(&a,3,lf[110],t6,t7);
t9=(C_word)C_a_i_list(&a,2,lf[111],t8);
t10=(C_word)C_a_i_list(&a,3,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10]);
t11=(C_word)C_a_i_list(&a,2,lf[61],lf[112]);
t12=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[8]);
t13=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[10]);
t14=(C_word)C_a_i_list(&a,6,lf[50],t11,lf[113],t12,t13,((C_word*)t0)[9]);
t15=(C_word)C_a_i_list(&a,4,lf[72],t9,t10,t14);
t16=(C_word)C_a_i_list(&a,3,lf[2],t5,t15);
t17=(C_word)C_a_i_list(&a,3,lf[79],t4,t16);
t18=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[7],t17);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2058,a[2]=((C_word*)t0)[6],a[3]=t18,tmp=(C_word)a,a+=4,tmp);
t20=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2061,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[5],a[12]=t19,tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t21=(C_word)C_i_car(((C_word*)t0)[5]);
t22=t20;
f_2061(t22,(C_word)C_eqp(lf[102],t21));}
else{
t21=t20;
f_2061(t21,C_SCHEME_FALSE);}}

/* k2059 in k2254 in k2182 in k2041 in a2020 in k2013 in k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_2061(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2061,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[12];
f_2058(t2,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[11],((C_word*)t0)[10]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2078,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2166,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2170,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   sprintf */
t6=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[117],((C_word*)t0)[9],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[12];
f_2058(t3,C_SCHEME_END_OF_LIST);}}}

/* k2168 in k2059 in k2254 in k2182 in k2041 in a2020 in k2013 in k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   renamer */
t2=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2164 in k2059 in k2254 in k2182 in k2041 in a2020 in k2013 in k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2076 in k2059 in k2254 in k2182 in k2041 in a2020 in k2013 in k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2078,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(C_word)C_a_i_list(&a,2,lf[106],((C_word*)t0)[8]);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,3,t2,t3,t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2150,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[5],a[10]=t5,tmp=(C_word)a,a+=11,tmp);
/* chicken.scm: 72   sprintf */
t7=C_retrieve(lf[62]);
((C_proc7)C_retrieve_proc(t7))(7,t7,t6,lf[116],((C_word*)t0)[9],((C_word*)t0)[2],((C_word*)t0)[8],((C_word*)t0)[6]);}

/* k2148 in k2076 in k2059 in k2254 in k2182 in k2041 in a2020 in k2013 in k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[153],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2150,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[107],lf[114],((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_a_i_list(&a,3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t6=(C_word)C_a_i_list(&a,3,lf[108],((C_word*)t0)[7],C_fix(0));
t7=(C_word)C_a_i_list(&a,3,lf[109],((C_word*)t0)[7],((C_word*)t0)[5]);
t8=(C_word)C_a_i_list(&a,3,lf[110],t6,t7);
t9=(C_word)C_a_i_list(&a,2,lf[111],t8);
t10=(C_word)C_a_i_list(&a,4,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t11=(C_word)C_a_i_list(&a,2,lf[61],lf[112]);
t12=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t13=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[7]);
t14=(C_word)C_a_i_list(&a,6,lf[50],t11,lf[115],t12,t13,((C_word*)t0)[5]);
t15=(C_word)C_a_i_list(&a,4,lf[72],t9,t10,t14);
t16=(C_word)C_a_i_list(&a,3,lf[2],t5,t15);
t17=(C_word)C_a_i_list(&a,3,lf[79],t4,t16);
t18=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[3],t17);
t19=((C_word*)t0)[2];
f_2058(t19,(C_word)C_a_i_list(&a,1,t18));}

/* k2056 in k2254 in k2182 in k2041 in a2020 in k2013 in k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_2058(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2058,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[68],t2));}

/* k2017 in k2013 in k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2009 in k2005 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2001 in k1997 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_2003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1993 in k1986 in k1983 in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1995,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[68],t1));}

/* strtype in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_1942(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1942,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1958,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(lf[102],t5);
if(C_truep(t6)){
t7=(C_word)C_i_cadr(t2);
/* chicken.scm: 72   strtype */
t9=t4;
t10=t7;
t1=t9;
t2=t10;
goto loop;}
else{
t7=t4;
f_1958(2,t7,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* k1956 in strtype in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_memq(t2,lf[105]));}}

/* stype in k1895 in k1892 in k1889 in k1886 in k1880 in a1877 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_1899(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1899,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(lf[102],t3);
if(C_truep(t4)){
t5=(C_word)C_i_cadr(t2);
/* chicken.scm: 72   stype */
t9=t1;
t10=t5;
t1=t9;
t2=t10;
goto loop;}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_memq(t5,lf[103]);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?(C_word)C_a_i_list(&a,2,lf[104],t2):t2));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1054,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1864,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[98],t3);}

/* a1863 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1864(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1864,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,lf[98],t2);
t4=(C_word)C_a_i_list(&a,2,lf[61],t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,lf[99],t4));}

/* k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1057,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1524,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[95],t3);}

/* a1523 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1524(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_1524r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1524r(t0,t1,t2,t3);}}

static void C_ccall f_1524r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(7);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1528,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t4)[1]))){
t6=(C_word)C_i_car(((C_word*)t4)[1]);
if(C_truep((C_word)C_booleanp(t6))){
t7=(C_word)C_i_cdr(((C_word*)t4)[1]);
t8=C_set_block_item(t4,0,t7);
t9=t5;
f_1528(t9,t6);}
else{
t7=t5;
f_1528(t7,C_SCHEME_TRUE);}}
else{
t6=t5;
f_1528(t6,C_SCHEME_TRUE);}}

/* k1526 in a1523 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_1528(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1528,NULL,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 72   ->string */
t5=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}

/* k1529 in k1526 in a1523 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1531,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=lf[67];
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1534,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1836,tmp=(C_word)a,a+=2,tmp);
/* map */
t8=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)((C_word*)t0)[2])[1]);}

/* a1835 in k1529 in k1526 in a1523 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1836(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1836,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_car(t2):t2));}

/* k1532 in k1529 in k1526 in a1523 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1534,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1537,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1811,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a1810 in k1532 in k1529 in k1526 in a1523 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1811(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1811,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cadr(t2));}
else{
/* chicken.scm: 72   syntax-error */
t4=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[95],lf[97],t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1535 in k1532 in k1529 in k1526 in a1523 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1540,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1779,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a1778 in k1535 in k1532 in k1529 in k1526 in a1523 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1779(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1779,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_caddr(t2));}
else{
t4=(C_word)C_i_car(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,lf[61],t4));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}}

/* k1538 in k1535 in k1532 in k1529 in k1526 in a1523 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1543,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[2]))){
t3=(C_word)C_i_length(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1753,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_and((C_word)C_fixnum_less_or_equal_p(C_fix(2),t3),(C_word)C_fixnum_less_or_equal_p(t3,C_fix(3))))){
t5=t4;
f_1753(2,t5,C_SCHEME_UNDEFINED);}
else{
/* chicken.scm: 72   syntax-error */
t5=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[95],lf[96],((C_word*)t0)[2]);}}
else{
t3=t2;
f_1543(t3,C_SCHEME_UNDEFINED);}}

/* k1751 in k1538 in k1535 in k1532 in k1529 in k1526 in a1523 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[7]);
t5=C_mutate(((C_word *)((C_word*)t0)[5])+1,t4);
t6=(C_word)C_eqp(C_fix(3),((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(C_word)C_i_caddr(((C_word*)t0)[7]);
t8=C_mutate(((C_word *)((C_word*)t0)[3])+1,t7);
t9=((C_word*)t0)[2];
f_1543(t9,t8);}
else{
t7=((C_word*)t0)[2];
f_1543(t7,C_SCHEME_UNDEFINED);}}

/* k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in a1523 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_1543(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1543,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1546,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[2])){
/* map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[6]),((C_word*)t0)[4]);}
else{
t3=t2;
f_1546(2,t3,((C_word*)t0)[4]);}}

/* k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in a1523 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1741,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 72   conc */
t4=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[7])[1],lf[93]);}

/* k1739 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in a1523 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in a1523 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1737,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 72   conc */
t4=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[92],((C_word*)((C_word*)t0)[8])[1]);}

/* k1735 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in a1523 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in a1523 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1559,a[2]=((C_word*)t0)[10],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1563,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1725,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 72   map */
t5=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* a1724 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in a1523 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1725(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1725,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1733,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 72   ->string */
t5=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k1731 in a1724 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in a1523 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1733,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[90],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1));}

/* k1561 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in a1523 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[97],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1563,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[10],lf[69]);
t3=(C_word)C_a_i_list(&a,2,lf[70],lf[69]);
t4=(C_word)C_a_i_list(&a,2,lf[71],lf[69]);
t5=(C_word)C_a_i_list(&a,4,lf[72],t3,t4,lf[69]);
t6=(C_word)C_a_i_list(&a,2,lf[69],t5);
t7=(C_word)C_a_i_list(&a,2,lf[73],C_fix(0));
t8=(C_word)C_a_i_list(&a,2,t6,t7);
t9=(C_word)C_a_i_list(&a,2,lf[74],lf[69]);
t10=(C_word)C_a_i_list(&a,2,lf[75],lf[69]);
t11=(C_word)C_a_i_list(&a,2,lf[76],lf[69]);
t12=(C_word)C_a_i_list(&a,2,lf[77],t11);
t13=(C_word)C_a_i_list(&a,1,t12);
t14=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1665,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t2,a[12]=t8,a[13]=t9,a[14]=t10,a[15]=t13,tmp=(C_word)a,a+=16,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1669,a[2]=t14,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t16=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1687,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   map */
t17=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t17))(5,t17,t15,t16,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* a1686 in k1561 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in a1523 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1687(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1687,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,t4,t2));}

/* k1667 in k1561 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in a1523 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1669,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)((C_word*)t0)[3])[1]);
t3=(C_word)C_a_i_list(&a,4,lf[88],lf[89],lf[77],t2);
t4=(C_word)C_a_i_list(&a,2,lf[86],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* ##sys#append */
t6=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[2],t1,t5);}

/* k1663 in k1561 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in a1523 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[88],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1665,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[77],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[78],t2);
t4=(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[15],t3);
t5=(C_word)C_a_i_list(&a,3,lf[80],lf[73],t4);
t6=(C_word)C_a_i_list(&a,3,lf[81],((C_word*)t0)[14],t5);
t7=(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[13],lf[73],t6);
t8=(C_word)C_a_i_list(&a,4,lf[79],lf[81],((C_word*)t0)[12],t7);
t9=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[11],t8);
t10=(C_word)C_a_i_list(&a,2,((C_word*)t0)[10],lf[77]);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1591,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t9,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t10,tmp=(C_word)a,a+=10,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1595,a[2]=t11,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1605,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   map */
t14=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t14))(5,t14,t12,t13,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1604 in k1663 in k1561 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in a1523 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1605(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1605,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,3,lf[87],lf[77],t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,t4,t3));}

/* k1593 in k1663 in k1561 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in a1523 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1595,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[86],((C_word*)((C_word*)t0)[3])[1]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k1589 in k1663 in k1561 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in a1523 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1591,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[83],t1);
t3=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_list(&a,5,lf[84],((C_word*)((C_word*)t0)[8])[1],((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],t3,t4);
/* ##sys#append */
t6=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[3],((C_word*)t0)[2],t5);}

/* k1557 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in a1523 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1559,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[68],t1));}

/* k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1060,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1490,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[66],t3);}

/* a1489 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[60],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1490,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t2,lf[60]);
t5=(C_word)C_a_i_list(&a,2,lf[61],t2);
t6=(C_word)C_a_i_list(&a,2,lf[61],t3);
t7=(C_word)C_a_i_list(&a,4,lf[62],lf[63],t5,t6);
t8=(C_word)C_a_i_list(&a,2,lf[56],t7);
t9=(C_word)C_a_i_list(&a,2,lf[61],t3);
t10=(C_word)C_a_i_list(&a,3,lf[64],t9,lf[60]);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[65],t4,t8,t10));}

/* k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1063,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1428,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[51],t3);}

/* a1427 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1428(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_1428r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1428r(t0,t1,t2,t3);}}

static void C_ccall f_1428r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1431,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1438,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1441,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_i_car(t2);
t8=t6;
f_1441(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_1441(t7,C_SCHEME_FALSE);}}

/* k1439 in a1427 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_1441(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1441,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_memq(lf[54],C_retrieve(lf[55])))){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 72   warning */
t3=C_retrieve(lf[56]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],lf[57],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1467,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken.scm: 72   ##compiler#register-compiler-macro */
t5=C_retrieve(lf[58]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,t3,t4,((C_word*)t0)[2]);}}
else{
/* chicken.scm: 72   bad */
t2=((C_word*)t0)[3];
f_1431(t2,((C_word*)t0)[4]);}}

/* k1465 in k1439 in a1427 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_1438(2,t2,C_SCHEME_UNDEFINED);}
else{
/* chicken.scm: 72   bad */
t2=((C_word*)t0)[2];
f_1431(t2,((C_word*)t0)[3]);}}

/* k1436 in a1427 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[53]);}

/* bad in a1427 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_1431(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1431,NULL,2,t0,t1);}
/* chicken.scm: 72   syntax-error */
t2=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,lf[51],lf[52],((C_word*)t0)[2]);}

/* k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1067,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1426,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 79   argv */
t4=C_retrieve(lf[49]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k1424 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1426,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1405,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1407,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1415,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1419,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 80   getenv */
t7=C_retrieve(lf[47]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[48]);}

/* k1417 in k1424 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[45]);
/* chicken.scm: 80   string-split */
t3=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k1413 in k1424 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 80   remove */
t2=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1406 in k1424 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1407(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1407,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_string_equal_p(t2,lf[43]));}

/* k1403 in k1424 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 78   append */
t2=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1065 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1067,2,t0,t1);}
t2=C_mutate((C_word*)lf[10]+1,t1);
t3=C_mutate((C_word*)lf[11]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1069,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1176,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1184,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1196,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 107  ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}

/* a1195 in k1065 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1196(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1196,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1200,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1208,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_1208(t9,t5,((C_word*)t4)[1]);}

/* loop in a1195 in k1065 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_1208(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(26);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1208,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_eqp(lf[19],t3);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1230,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t4);
/* chicken.scm: 113  string->number */
C_string_to_number(3,0,t6,t7);}
else{
t6=(C_word)C_eqp(lf[26],t3);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1293,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_car(t4);
/* chicken.scm: 127  string->number */
C_string_to_number(3,0,t7,t8);}
else{
t7=(C_word)C_eqp(lf[30],t3);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1347,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 136  cons* */
t9=C_retrieve(lf[20]);
((C_proc11)C_retrieve_proc(t9))(11,t9,t8,lf[31],lf[32],lf[28],lf[22],lf[21],lf[33],lf[34],lf[27],((C_word*)((C_word*)t0)[2])[1]);}
else{
if(C_truep((C_word)C_i_memq(t3,C_retrieve(lf[35])))){
/* chicken.scm: 140  loop */
t17=t1;
t18=t4;
t1=t17;
t2=t18;
goto loop;}
else{
if(C_truep((C_word)C_i_memq(t3,C_retrieve(lf[36])))){
if(C_truep((C_word)C_i_pairp(t4))){
t8=(C_word)C_i_cdr(t4);
/* chicken.scm: 143  loop */
t17=t1;
t18=t8;
t1=t17;
t2=t18;
goto loop;}
else{
/* chicken.scm: 144  quit */
t8=C_retrieve(lf[37]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,lf[38],t3);}}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1384,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1391,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_stringp(t3))){
t10=t9;
f_1391(2,t10,t3);}
else{
/* chicken.scm: 148  conc */
t10=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,lf[41],t3);}}}}}}}}

/* k1389 in loop in a1195 in k1065 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 146  compiler-warning */
t2=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[24],lf[39],t1);}

/* k1382 in loop in a1195 in k1065 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 149  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1208(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1345 in loop in a1195 in k1065 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* chicken.scm: 139  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1208(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1291 in loop in a1195 in k1065 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1293,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1296,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
switch(t1){
case C_fix(0):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1310,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 129  cons* */
t4=C_retrieve(lf[20]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[27],lf[28],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,lf[28],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_1296(2,t5,t4);
case C_fix(2):
t3=t2;
f_1296(2,t3,C_SCHEME_FALSE);
default:
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 132  compiler-warning */
t4=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[24],lf[29],t3);}}

/* k1308 in k1291 in loop in a1195 in k1065 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1296(2,t3,t2);}

/* k1294 in k1291 in loop in a1195 in k1065 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 133  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1208(t3,((C_word*)t0)[2],t2);}

/* k1228 in loop in a1195 in k1065 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1230,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1233,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
switch(t1){
case C_fix(0):
t3=t2;
f_1233(2,t3,C_SCHEME_FALSE);
case C_fix(1):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1253,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 117  cons* */
t4=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[21],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(2):
t3=(C_word)C_a_i_cons(&a,2,lf[21],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_1233(2,t5,t4);
case C_fix(3):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1273,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 123  cons* */
t4=C_retrieve(lf[20]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[21],lf[22],((C_word*)((C_word*)t0)[2])[1]);
default:
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 124  compiler-warning */
t4=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[24],lf[25],t3);}}

/* k1271 in k1228 in loop in a1195 in k1065 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1233(2,t3,t2);}

/* k1251 in k1228 in loop in a1195 in k1065 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1233(2,t3,t2);}

/* k1231 in k1228 in loop in a1195 in k1065 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 125  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1208(t3,((C_word*)t0)[2],t2);}

/* k1198 in a1195 in k1065 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1203,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t2,C_retrieve(lf[18]),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k1201 in k1198 in a1195 in k1065 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 151  exit */
t2=C_retrieve(lf[17]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a1183 in k1065 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1191,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 107  user-options-pass */
t3=C_retrieve(lf[16]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1189 in a1183 in k1065 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_retrieve(lf[11]));
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_retrieve(lf[10]));}

/* k1174 in k1065 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1179,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1182,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
t4=C_retrieve(lf[15]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k1180 in k1174 in k1065 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1177 in k1174 in k1065 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##compiler#process-command-line in k1065 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1069(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1069,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1075,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_1075(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in ##compiler#process-command-line in k1065 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_1075(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1075,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1089,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 92   reverse */
t6=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_string_length(t5);
t7=(C_word)C_i_string_ref(t5,C_fix(0));
t8=(C_word)C_eqp(C_make_character(45),t7);
t9=(C_truep(t8)?(C_word)C_fixnum_greaterp(t6,C_fix(1)):C_SCHEME_FALSE);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1110,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t6,C_fix(1)))){
t11=(C_word)C_i_string_ref(t5,C_fix(1));
t12=t10;
f_1110(t12,(C_word)C_eqp(C_make_character(58),t11));}
else{
t11=t10;
f_1110(t11,C_SCHEME_FALSE);}}
else{
if(C_truep(t4)){
t10=(C_word)C_i_cdr(t2);
t11=(C_word)C_a_i_cons(&a,2,t5,t3);
/* chicken.scm: 101  loop */
t17=t1;
t18=t10;
t19=t11;
t20=t4;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}
else{
t10=(C_word)C_i_cdr(t2);
/* chicken.scm: 102  loop */
t17=t1;
t18=t10;
t19=t3;
t20=t5;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}}}}

/* k1108 in loop in ##compiler#process-command-line in k1065 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_fcall f_1110(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1110,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* chicken.scm: 98   loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_1075(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1132,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1136,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 99   substring */
t5=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]);}}

/* k1134 in k1108 in loop in ##compiler#process-command-line in k1065 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 99   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1130 in k1108 in loop in ##compiler#process-command-line in k1065 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1132,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* chicken.scm: 99   loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1075(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1087 in loop in ##compiler#process-command-line in k1065 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 in k1010 in k1007 in k1004 in k1001 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 in k971 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k938 in k859 in k856 in k853 in k850 in k847 in k844 in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_1089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 92   values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* assign in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_773(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_773,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_777,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t5=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[8],t2,lf[9]);}

/* k775 in assign in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_777,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t2=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,lf[3]);
t4=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[4],t2,t4));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t3,((C_word*)t0)[4]));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_814,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   map */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[6]),((C_word*)t0)[5]);}}}

/* k812 in k775 in assign in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_814,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_833,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_835,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   map */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[2],t1);}

/* a834 in k812 in k775 in assign in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_835(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_835,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t2,t3));}

/* k831 in k812 in k775 in assign in k770 in k767 in k764 in k761 in k758 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k728 in k725 in k722 in k719 in k716 in k713 in k710 in k707 in k704 in k701 in k698 in k695 in k692 in k689 in k686 */
static void C_ccall f_833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_833,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[2],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[4],((C_word*)t0)[2],t3));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[578] = {
{"toplevelchicken.scm",(void*)C_toplevel},
{"f_688chicken.scm",(void*)f_688},
{"f_691chicken.scm",(void*)f_691},
{"f_694chicken.scm",(void*)f_694},
{"f_697chicken.scm",(void*)f_697},
{"f_700chicken.scm",(void*)f_700},
{"f_703chicken.scm",(void*)f_703},
{"f_706chicken.scm",(void*)f_706},
{"f_709chicken.scm",(void*)f_709},
{"f_712chicken.scm",(void*)f_712},
{"f_715chicken.scm",(void*)f_715},
{"f_718chicken.scm",(void*)f_718},
{"f_721chicken.scm",(void*)f_721},
{"f_724chicken.scm",(void*)f_724},
{"f_727chicken.scm",(void*)f_727},
{"f_730chicken.scm",(void*)f_730},
{"f_736chicken.scm",(void*)f_736},
{"f_6914chicken.scm",(void*)f_6914},
{"f_6918chicken.scm",(void*)f_6918},
{"f_6921chicken.scm",(void*)f_6921},
{"f_6924chicken.scm",(void*)f_6924},
{"f_6930chicken.scm",(void*)f_6930},
{"f_7136chicken.scm",(void*)f_7136},
{"f_7116chicken.scm",(void*)f_7116},
{"f_7112chicken.scm",(void*)f_7112},
{"f_7092chicken.scm",(void*)f_7092},
{"f_6955chicken.scm",(void*)f_6955},
{"f_6965chicken.scm",(void*)f_6965},
{"f_7084chicken.scm",(void*)f_7084},
{"f_6968chicken.scm",(void*)f_6968},
{"f_7080chicken.scm",(void*)f_7080},
{"f_6971chicken.scm",(void*)f_6971},
{"f_7002chicken.scm",(void*)f_7002},
{"f_6982chicken.scm",(void*)f_6982},
{"f_6953chicken.scm",(void*)f_6953},
{"f_739chicken.scm",(void*)f_739},
{"f_6826chicken.scm",(void*)f_6826},
{"f_6843chicken.scm",(void*)f_6843},
{"f_6846chicken.scm",(void*)f_6846},
{"f_6852chicken.scm",(void*)f_6852},
{"f_742chicken.scm",(void*)f_742},
{"f_6785chicken.scm",(void*)f_6785},
{"f_6789chicken.scm",(void*)f_6789},
{"f_745chicken.scm",(void*)f_745},
{"f_6769chicken.scm",(void*)f_6769},
{"f_6779chicken.scm",(void*)f_6779},
{"f_6777chicken.scm",(void*)f_6777},
{"f_748chicken.scm",(void*)f_748},
{"f_6692chicken.scm",(void*)f_6692},
{"f_6696chicken.scm",(void*)f_6696},
{"f_6764chicken.scm",(void*)f_6764},
{"f_6699chicken.scm",(void*)f_6699},
{"f_6708chicken.scm",(void*)f_6708},
{"f_6755chicken.scm",(void*)f_6755},
{"f_6722chicken.scm",(void*)f_6722},
{"f_6730chicken.scm",(void*)f_6730},
{"f_6732chicken.scm",(void*)f_6732},
{"f_6749chicken.scm",(void*)f_6749},
{"f_6714chicken.scm",(void*)f_6714},
{"f_6706chicken.scm",(void*)f_6706},
{"f_751chicken.scm",(void*)f_751},
{"f_6632chicken.scm",(void*)f_6632},
{"f_6636chicken.scm",(void*)f_6636},
{"f_754chicken.scm",(void*)f_754},
{"f_6573chicken.scm",(void*)f_6573},
{"f_6577chicken.scm",(void*)f_6577},
{"f_6604chicken.scm",(void*)f_6604},
{"f_757chicken.scm",(void*)f_757},
{"f_6399chicken.scm",(void*)f_6399},
{"f_6403chicken.scm",(void*)f_6403},
{"f_6406chicken.scm",(void*)f_6406},
{"f_6567chicken.scm",(void*)f_6567},
{"f_6409chicken.scm",(void*)f_6409},
{"f_6561chicken.scm",(void*)f_6561},
{"f_6412chicken.scm",(void*)f_6412},
{"f_6559chicken.scm",(void*)f_6559},
{"f_6523chicken.scm",(void*)f_6523},
{"f_6537chicken.scm",(void*)f_6537},
{"f_6551chicken.scm",(void*)f_6551},
{"f_6531chicken.scm",(void*)f_6531},
{"f_6527chicken.scm",(void*)f_6527},
{"f_6419chicken.scm",(void*)f_6419},
{"f_6515chicken.scm",(void*)f_6515},
{"f_6491chicken.scm",(void*)f_6491},
{"f_6509chicken.scm",(void*)f_6509},
{"f_6499chicken.scm",(void*)f_6499},
{"f_6495chicken.scm",(void*)f_6495},
{"f_6487chicken.scm",(void*)f_6487},
{"f_6471chicken.scm",(void*)f_6471},
{"f_6447chicken.scm",(void*)f_6447},
{"f_6465chicken.scm",(void*)f_6465},
{"f_6455chicken.scm",(void*)f_6455},
{"f_6451chicken.scm",(void*)f_6451},
{"f_6443chicken.scm",(void*)f_6443},
{"f_760chicken.scm",(void*)f_760},
{"f_6304chicken.scm",(void*)f_6304},
{"f_6340chicken.scm",(void*)f_6340},
{"f_6353chicken.scm",(void*)f_6353},
{"f_6311chicken.scm",(void*)f_6311},
{"f_763chicken.scm",(void*)f_763},
{"f_6194chicken.scm",(void*)f_6194},
{"f_6198chicken.scm",(void*)f_6198},
{"f_6201chicken.scm",(void*)f_6201},
{"f_6204chicken.scm",(void*)f_6204},
{"f_6207chicken.scm",(void*)f_6207},
{"f_6298chicken.scm",(void*)f_6298},
{"f_6210chicken.scm",(void*)f_6210},
{"f_6292chicken.scm",(void*)f_6292},
{"f_6213chicken.scm",(void*)f_6213},
{"f_6286chicken.scm",(void*)f_6286},
{"f_6290chicken.scm",(void*)f_6290},
{"f_6220chicken.scm",(void*)f_6220},
{"f_6258chicken.scm",(void*)f_6258},
{"f_6256chicken.scm",(void*)f_6256},
{"f_766chicken.scm",(void*)f_766},
{"f_6184chicken.scm",(void*)f_6184},
{"f_769chicken.scm",(void*)f_769},
{"f_6170chicken.scm",(void*)f_6170},
{"f_772chicken.scm",(void*)f_772},
{"f_846chicken.scm",(void*)f_846},
{"f_849chicken.scm",(void*)f_849},
{"f_5908chicken.scm",(void*)f_5908},
{"f_5912chicken.scm",(void*)f_5912},
{"f_5921chicken.scm",(void*)f_5921},
{"f_6130chicken.scm",(void*)f_6130},
{"f_6143chicken.scm",(void*)f_6143},
{"f_5924chicken.scm",(void*)f_5924},
{"f_6120chicken.scm",(void*)f_6120},
{"f_6128chicken.scm",(void*)f_6128},
{"f_5927chicken.scm",(void*)f_5927},
{"f_6074chicken.scm",(void*)f_6074},
{"f_6107chicken.scm",(void*)f_6107},
{"f_6114chicken.scm",(void*)f_6114},
{"f_6090chicken.scm",(void*)f_6090},
{"f_5939chicken.scm",(void*)f_5939},
{"f_6068chicken.scm",(void*)f_6068},
{"f_5946chicken.scm",(void*)f_5946},
{"f_5948chicken.scm",(void*)f_5948},
{"f_6062chicken.scm",(void*)f_6062},
{"f_5982chicken.scm",(void*)f_5982},
{"f_6036chicken.scm",(void*)f_6036},
{"f_6013chicken.scm",(void*)f_6013},
{"f_5993chicken.scm",(void*)f_5993},
{"f_5968chicken.scm",(void*)f_5968},
{"f_5976chicken.scm",(void*)f_5976},
{"f_5966chicken.scm",(void*)f_5966},
{"f_5928chicken.scm",(void*)f_5928},
{"f_5868chicken.scm",(void*)f_5868},
{"f_5891chicken.scm",(void*)f_5891},
{"f_5895chicken.scm",(void*)f_5895},
{"f_5837chicken.scm",(void*)f_5837},
{"f_5858chicken.scm",(void*)f_5858},
{"f_852chicken.scm",(void*)f_852},
{"f_5786chicken.scm",(void*)f_5786},
{"f_5790chicken.scm",(void*)f_5790},
{"f_5801chicken.scm",(void*)f_5801},
{"f_5826chicken.scm",(void*)f_5826},
{"f_855chicken.scm",(void*)f_855},
{"f_5666chicken.scm",(void*)f_5666},
{"f_5670chicken.scm",(void*)f_5670},
{"f_5780chicken.scm",(void*)f_5780},
{"f_5778chicken.scm",(void*)f_5778},
{"f_5679chicken.scm",(void*)f_5679},
{"f_5766chicken.scm",(void*)f_5766},
{"f_5774chicken.scm",(void*)f_5774},
{"f_5682chicken.scm",(void*)f_5682},
{"f_5760chicken.scm",(void*)f_5760},
{"f_5702chicken.scm",(void*)f_5702},
{"f_5712chicken.scm",(void*)f_5712},
{"f_5732chicken.scm",(void*)f_5732},
{"f_5738chicken.scm",(void*)f_5738},
{"f_5746chicken.scm",(void*)f_5746},
{"f_5736chicken.scm",(void*)f_5736},
{"f_5710chicken.scm",(void*)f_5710},
{"f_5706chicken.scm",(void*)f_5706},
{"f_5683chicken.scm",(void*)f_5683},
{"f_858chicken.scm",(void*)f_858},
{"f_5645chicken.scm",(void*)f_5645},
{"f_5649chicken.scm",(void*)f_5649},
{"f_861chicken.scm",(void*)f_861},
{"f_5635chicken.scm",(void*)f_5635},
{"f_867chicken.scm",(void*)f_867},
{"f_876chicken.scm",(void*)f_876},
{"f_892chicken.scm",(void*)f_892},
{"f_879chicken.scm",(void*)f_879},
{"f_940chicken.scm",(void*)f_940},
{"f_5614chicken.scm",(void*)f_5614},
{"f_5618chicken.scm",(void*)f_5618},
{"f_943chicken.scm",(void*)f_943},
{"f_5498chicken.scm",(void*)f_5498},
{"f_5502chicken.scm",(void*)f_5502},
{"f_5511chicken.scm",(void*)f_5511},
{"f_5525chicken.scm",(void*)f_5525},
{"f_5589chicken.scm",(void*)f_5589},
{"f_5571chicken.scm",(void*)f_5571},
{"f_5554chicken.scm",(void*)f_5554},
{"f_946chicken.scm",(void*)f_946},
{"f_5399chicken.scm",(void*)f_5399},
{"f_5409chicken.scm",(void*)f_5409},
{"f_5422chicken.scm",(void*)f_5422},
{"f_5438chicken.scm",(void*)f_5438},
{"f_5476chicken.scm",(void*)f_5476},
{"f_5474chicken.scm",(void*)f_5474},
{"f_5466chicken.scm",(void*)f_5466},
{"f_5420chicken.scm",(void*)f_5420},
{"f_949chicken.scm",(void*)f_949},
{"f_5310chicken.scm",(void*)f_5310},
{"f_5320chicken.scm",(void*)f_5320},
{"f_5333chicken.scm",(void*)f_5333},
{"f_5349chicken.scm",(void*)f_5349},
{"f_5377chicken.scm",(void*)f_5377},
{"f_5331chicken.scm",(void*)f_5331},
{"f_952chicken.scm",(void*)f_952},
{"f_5024chicken.scm",(void*)f_5024},
{"f_5221chicken.scm",(void*)f_5221},
{"f_5224chicken.scm",(void*)f_5224},
{"f_5227chicken.scm",(void*)f_5227},
{"f_5300chicken.scm",(void*)f_5300},
{"f_5308chicken.scm",(void*)f_5308},
{"f_5243chicken.scm",(void*)f_5243},
{"f_5246chicken.scm",(void*)f_5246},
{"f_5249chicken.scm",(void*)f_5249},
{"f_5252chicken.scm",(void*)f_5252},
{"f_5290chicken.scm",(void*)f_5290},
{"f_5298chicken.scm",(void*)f_5298},
{"f_5255chicken.scm",(void*)f_5255},
{"f_5035chicken.scm",(void*)f_5035},
{"f_5039chicken.scm",(void*)f_5039},
{"f_5043chicken.scm",(void*)f_5043},
{"f_5045chicken.scm",(void*)f_5045},
{"f_5090chicken.scm",(void*)f_5090},
{"f_5102chicken.scm",(void*)f_5102},
{"f_5098chicken.scm",(void*)f_5098},
{"f_5066chicken.scm",(void*)f_5066},
{"f_5258chicken.scm",(void*)f_5258},
{"f_5118chicken.scm",(void*)f_5118},
{"f_5218chicken.scm",(void*)f_5218},
{"f_5182chicken.scm",(void*)f_5182},
{"f_5152chicken.scm",(void*)f_5152},
{"f_5261chicken.scm",(void*)f_5261},
{"f_5228chicken.scm",(void*)f_5228},
{"f_5240chicken.scm",(void*)f_5240},
{"f_5236chicken.scm",(void*)f_5236},
{"f_955chicken.scm",(void*)f_955},
{"f_4967chicken.scm",(void*)f_4967},
{"f_4971chicken.scm",(void*)f_4971},
{"f_958chicken.scm",(void*)f_958},
{"f_4961chicken.scm",(void*)f_4961},
{"f_961chicken.scm",(void*)f_961},
{"f_4808chicken.scm",(void*)f_4808},
{"f_4812chicken.scm",(void*)f_4812},
{"f_4815chicken.scm",(void*)f_4815},
{"f_4818chicken.scm",(void*)f_4818},
{"f_4831chicken.scm",(void*)f_4831},
{"f_4881chicken.scm",(void*)f_4881},
{"f_4892chicken.scm",(void*)f_4892},
{"f_4829chicken.scm",(void*)f_4829},
{"f_964chicken.scm",(void*)f_964},
{"f_4532chicken.scm",(void*)f_4532},
{"f_4566chicken.scm",(void*)f_4566},
{"f_4569chicken.scm",(void*)f_4569},
{"f_4795chicken.scm",(void*)f_4795},
{"f_4805chicken.scm",(void*)f_4805},
{"f_4793chicken.scm",(void*)f_4793},
{"f_4572chicken.scm",(void*)f_4572},
{"f_4541chicken.scm",(void*)f_4541},
{"f_4555chicken.scm",(void*)f_4555},
{"f_4559chicken.scm",(void*)f_4559},
{"f_4575chicken.scm",(void*)f_4575},
{"f_4578chicken.scm",(void*)f_4578},
{"f_4581chicken.scm",(void*)f_4581},
{"f_4588chicken.scm",(void*)f_4588},
{"f_4602chicken.scm",(void*)f_4602},
{"f_4612chicken.scm",(void*)f_4612},
{"f_4616chicken.scm",(void*)f_4616},
{"f_4626chicken.scm",(void*)f_4626},
{"f_4642chicken.scm",(void*)f_4642},
{"f_4661chicken.scm",(void*)f_4661},
{"f_4717chicken.scm",(void*)f_4717},
{"f_4728chicken.scm",(void*)f_4728},
{"f_4646chicken.scm",(void*)f_4646},
{"f_4659chicken.scm",(void*)f_4659},
{"f_4632chicken.scm",(void*)f_4632},
{"f_4640chicken.scm",(void*)f_4640},
{"f_4630chicken.scm",(void*)f_4630},
{"f_4600chicken.scm",(void*)f_4600},
{"f_967chicken.scm",(void*)f_967},
{"f_4475chicken.scm",(void*)f_4475},
{"f_4515chicken.scm",(void*)f_4515},
{"f_4485chicken.scm",(void*)f_4485},
{"f_970chicken.scm",(void*)f_970},
{"f_4399chicken.scm",(void*)f_4399},
{"f_4403chicken.scm",(void*)f_4403},
{"f_4406chicken.scm",(void*)f_4406},
{"f_973chicken.scm",(void*)f_973},
{"f_4215chicken.scm",(void*)f_4215},
{"f_4219chicken.scm",(void*)f_4219},
{"f_4222chicken.scm",(void*)f_4222},
{"f_4365chicken.scm",(void*)f_4365},
{"f_4361chicken.scm",(void*)f_4361},
{"f_4224chicken.scm",(void*)f_4224},
{"f_4312chicken.scm",(void*)f_4312},
{"f_4310chicken.scm",(void*)f_4310},
{"f_4280chicken.scm",(void*)f_4280},
{"f_4247chicken.scm",(void*)f_4247},
{"f_976chicken.scm",(void*)f_976},
{"f_4025chicken.scm",(void*)f_4025},
{"f_4032chicken.scm",(void*)f_4032},
{"f_4206chicken.scm",(void*)f_4206},
{"f_4204chicken.scm",(void*)f_4204},
{"f_4057chicken.scm",(void*)f_4057},
{"f_4083chicken.scm",(void*)f_4083},
{"f_4111chicken.scm",(void*)f_4111},
{"f_4095chicken.scm",(void*)f_4095},
{"f_4055chicken.scm",(void*)f_4055},
{"f_979chicken.scm",(void*)f_979},
{"f_4016chicken.scm",(void*)f_4016},
{"f_4020chicken.scm",(void*)f_4020},
{"f_982chicken.scm",(void*)f_982},
{"f_3997chicken.scm",(void*)f_3997},
{"f_4001chicken.scm",(void*)f_4001},
{"f_4010chicken.scm",(void*)f_4010},
{"f_4008chicken.scm",(void*)f_4008},
{"f_985chicken.scm",(void*)f_985},
{"f_3978chicken.scm",(void*)f_3978},
{"f_3982chicken.scm",(void*)f_3982},
{"f_3991chicken.scm",(void*)f_3991},
{"f_3989chicken.scm",(void*)f_3989},
{"f_988chicken.scm",(void*)f_988},
{"f_3850chicken.scm",(void*)f_3850},
{"f_3856chicken.scm",(void*)f_3856},
{"f_3937chicken.scm",(void*)f_3937},
{"f_3866chicken.scm",(void*)f_3866},
{"f_3869chicken.scm",(void*)f_3869},
{"f_3875chicken.scm",(void*)f_3875},
{"f_3882chicken.scm",(void*)f_3882},
{"f_3898chicken.scm",(void*)f_3898},
{"f_991chicken.scm",(void*)f_991},
{"f_3707chicken.scm",(void*)f_3707},
{"f_3713chicken.scm",(void*)f_3713},
{"f_3825chicken.scm",(void*)f_3825},
{"f_3798chicken.scm",(void*)f_3798},
{"f_3723chicken.scm",(void*)f_3723},
{"f_3726chicken.scm",(void*)f_3726},
{"f_3732chicken.scm",(void*)f_3732},
{"f_3743chicken.scm",(void*)f_3743},
{"f_3759chicken.scm",(void*)f_3759},
{"f_994chicken.scm",(void*)f_994},
{"f_3648chicken.scm",(void*)f_3648},
{"f_997chicken.scm",(void*)f_997},
{"f_3477chicken.scm",(void*)f_3477},
{"f_3483chicken.scm",(void*)f_3483},
{"f_3557chicken.scm",(void*)f_3557},
{"f_3560chicken.scm",(void*)f_3560},
{"f_3633chicken.scm",(void*)f_3633},
{"f_3626chicken.scm",(void*)f_3626},
{"f_3618chicken.scm",(void*)f_3618},
{"f_3605chicken.scm",(void*)f_3605},
{"f_3584chicken.scm",(void*)f_3584},
{"f_3493chicken.scm",(void*)f_3493},
{"f_1000chicken.scm",(void*)f_1000},
{"f_3426chicken.scm",(void*)f_3426},
{"f_1003chicken.scm",(void*)f_1003},
{"f_3366chicken.scm",(void*)f_3366},
{"f_3376chicken.scm",(void*)f_3376},
{"f_3395chicken.scm",(void*)f_3395},
{"f_3379chicken.scm",(void*)f_3379},
{"f_1006chicken.scm",(void*)f_1006},
{"f_1009chicken.scm",(void*)f_1009},
{"f_3329chicken.scm",(void*)f_3329},
{"f_3333chicken.scm",(void*)f_3333},
{"f_1012chicken.scm",(void*)f_1012},
{"f_3310chicken.scm",(void*)f_3310},
{"f_3314chicken.scm",(void*)f_3314},
{"f_3323chicken.scm",(void*)f_3323},
{"f_3321chicken.scm",(void*)f_3321},
{"f_1015chicken.scm",(void*)f_1015},
{"f_3291chicken.scm",(void*)f_3291},
{"f_3295chicken.scm",(void*)f_3295},
{"f_3304chicken.scm",(void*)f_3304},
{"f_3302chicken.scm",(void*)f_3302},
{"f_1018chicken.scm",(void*)f_1018},
{"f_3272chicken.scm",(void*)f_3272},
{"f_3276chicken.scm",(void*)f_3276},
{"f_3285chicken.scm",(void*)f_3285},
{"f_3283chicken.scm",(void*)f_3283},
{"f_1021chicken.scm",(void*)f_1021},
{"f_3253chicken.scm",(void*)f_3253},
{"f_3257chicken.scm",(void*)f_3257},
{"f_3266chicken.scm",(void*)f_3266},
{"f_3264chicken.scm",(void*)f_3264},
{"f_1024chicken.scm",(void*)f_1024},
{"f_3234chicken.scm",(void*)f_3234},
{"f_3238chicken.scm",(void*)f_3238},
{"f_3247chicken.scm",(void*)f_3247},
{"f_3245chicken.scm",(void*)f_3245},
{"f_1027chicken.scm",(void*)f_1027},
{"f_3215chicken.scm",(void*)f_3215},
{"f_3219chicken.scm",(void*)f_3219},
{"f_3228chicken.scm",(void*)f_3228},
{"f_3226chicken.scm",(void*)f_3226},
{"f_1030chicken.scm",(void*)f_1030},
{"f_3115chicken.scm",(void*)f_3115},
{"f_3119chicken.scm",(void*)f_3119},
{"f_3174chicken.scm",(void*)f_3174},
{"f_3128chicken.scm",(void*)f_3128},
{"f_1033chicken.scm",(void*)f_1033},
{"f_2895chicken.scm",(void*)f_2895},
{"f_2899chicken.scm",(void*)f_2899},
{"f_2902chicken.scm",(void*)f_2902},
{"f_2983chicken.scm",(void*)f_2983},
{"f_3050chicken.scm",(void*)f_3050},
{"f_3048chicken.scm",(void*)f_3048},
{"f_3040chicken.scm",(void*)f_3040},
{"f_3028chicken.scm",(void*)f_3028},
{"f_2908chicken.scm",(void*)f_2908},
{"f_2934chicken.scm",(void*)f_2934},
{"f_1036chicken.scm",(void*)f_1036},
{"f_2820chicken.scm",(void*)f_2820},
{"f_2824chicken.scm",(void*)f_2824},
{"f_2893chicken.scm",(void*)f_2893},
{"f_2847chicken.scm",(void*)f_2847},
{"f_1039chicken.scm",(void*)f_1039},
{"f_2714chicken.scm",(void*)f_2714},
{"f_2814chicken.scm",(void*)f_2814},
{"f_2718chicken.scm",(void*)f_2718},
{"f_2790chicken.scm",(void*)f_2790},
{"f_2725chicken.scm",(void*)f_2725},
{"f_2731chicken.scm",(void*)f_2731},
{"f_2729chicken.scm",(void*)f_2729},
{"f_1042chicken.scm",(void*)f_1042},
{"f_2685chicken.scm",(void*)f_2685},
{"f_2689chicken.scm",(void*)f_2689},
{"f_2712chicken.scm",(void*)f_2712},
{"f_2708chicken.scm",(void*)f_2708},
{"f_1045chicken.scm",(void*)f_1045},
{"f_2672chicken.scm",(void*)f_2672},
{"f_2676chicken.scm",(void*)f_2676},
{"f_1048chicken.scm",(void*)f_1048},
{"f_1878chicken.scm",(void*)f_1878},
{"f_1882chicken.scm",(void*)f_1882},
{"f_1888chicken.scm",(void*)f_1888},
{"f_1891chicken.scm",(void*)f_1891},
{"f_1894chicken.scm",(void*)f_1894},
{"f_1897chicken.scm",(void*)f_1897},
{"f_2564chicken.scm",(void*)f_2564},
{"f_2643chicken.scm",(void*)f_2643},
{"f_2639chicken.scm",(void*)f_2639},
{"f_2574chicken.scm",(void*)f_2574},
{"f_2578chicken.scm",(void*)f_2578},
{"f_2619chicken.scm",(void*)f_2619},
{"f_2609chicken.scm",(void*)f_2609},
{"f_2599chicken.scm",(void*)f_2599},
{"f_2595chicken.scm",(void*)f_2595},
{"f_2581chicken.scm",(void*)f_2581},
{"f_1985chicken.scm",(void*)f_1985},
{"f_1988chicken.scm",(void*)f_1988},
{"f_2558chicken.scm",(void*)f_2558},
{"f_2487chicken.scm",(void*)f_2487},
{"f_2493chicken.scm",(void*)f_2493},
{"f_2547chicken.scm",(void*)f_2547},
{"f_2539chicken.scm",(void*)f_2539},
{"f_2522chicken.scm",(void*)f_2522},
{"f_2510chicken.scm",(void*)f_2510},
{"f_2491chicken.scm",(void*)f_2491},
{"f_2475chicken.scm",(void*)f_2475},
{"f_2471chicken.scm",(void*)f_2471},
{"f_1999chicken.scm",(void*)f_1999},
{"f_2453chicken.scm",(void*)f_2453},
{"f_2007chicken.scm",(void*)f_2007},
{"f_2015chicken.scm",(void*)f_2015},
{"f_2021chicken.scm",(void*)f_2021},
{"f_2298chicken.scm",(void*)f_2298},
{"f_2410chicken.scm",(void*)f_2410},
{"f_2406chicken.scm",(void*)f_2406},
{"f_2375chicken.scm",(void*)f_2375},
{"f_2398chicken.scm",(void*)f_2398},
{"f_2387chicken.scm",(void*)f_2387},
{"f_2316chicken.scm",(void*)f_2316},
{"f_2361chicken.scm",(void*)f_2361},
{"f_2357chicken.scm",(void*)f_2357},
{"f_2333chicken.scm",(void*)f_2333},
{"f_2345chicken.scm",(void*)f_2345},
{"f_2313chicken.scm",(void*)f_2313},
{"f_2043chicken.scm",(void*)f_2043},
{"f_2283chicken.scm",(void*)f_2283},
{"f_2279chicken.scm",(void*)f_2279},
{"f_2184chicken.scm",(void*)f_2184},
{"f_2267chicken.scm",(void*)f_2267},
{"f_2256chicken.scm",(void*)f_2256},
{"f_2061chicken.scm",(void*)f_2061},
{"f_2170chicken.scm",(void*)f_2170},
{"f_2166chicken.scm",(void*)f_2166},
{"f_2078chicken.scm",(void*)f_2078},
{"f_2150chicken.scm",(void*)f_2150},
{"f_2058chicken.scm",(void*)f_2058},
{"f_2019chicken.scm",(void*)f_2019},
{"f_2011chicken.scm",(void*)f_2011},
{"f_2003chicken.scm",(void*)f_2003},
{"f_1995chicken.scm",(void*)f_1995},
{"f_1942chicken.scm",(void*)f_1942},
{"f_1958chicken.scm",(void*)f_1958},
{"f_1899chicken.scm",(void*)f_1899},
{"f_1051chicken.scm",(void*)f_1051},
{"f_1864chicken.scm",(void*)f_1864},
{"f_1054chicken.scm",(void*)f_1054},
{"f_1524chicken.scm",(void*)f_1524},
{"f_1528chicken.scm",(void*)f_1528},
{"f_1531chicken.scm",(void*)f_1531},
{"f_1836chicken.scm",(void*)f_1836},
{"f_1534chicken.scm",(void*)f_1534},
{"f_1811chicken.scm",(void*)f_1811},
{"f_1537chicken.scm",(void*)f_1537},
{"f_1779chicken.scm",(void*)f_1779},
{"f_1540chicken.scm",(void*)f_1540},
{"f_1753chicken.scm",(void*)f_1753},
{"f_1543chicken.scm",(void*)f_1543},
{"f_1546chicken.scm",(void*)f_1546},
{"f_1741chicken.scm",(void*)f_1741},
{"f_1549chicken.scm",(void*)f_1549},
{"f_1737chicken.scm",(void*)f_1737},
{"f_1552chicken.scm",(void*)f_1552},
{"f_1725chicken.scm",(void*)f_1725},
{"f_1733chicken.scm",(void*)f_1733},
{"f_1563chicken.scm",(void*)f_1563},
{"f_1687chicken.scm",(void*)f_1687},
{"f_1669chicken.scm",(void*)f_1669},
{"f_1665chicken.scm",(void*)f_1665},
{"f_1605chicken.scm",(void*)f_1605},
{"f_1595chicken.scm",(void*)f_1595},
{"f_1591chicken.scm",(void*)f_1591},
{"f_1559chicken.scm",(void*)f_1559},
{"f_1057chicken.scm",(void*)f_1057},
{"f_1490chicken.scm",(void*)f_1490},
{"f_1060chicken.scm",(void*)f_1060},
{"f_1428chicken.scm",(void*)f_1428},
{"f_1441chicken.scm",(void*)f_1441},
{"f_1467chicken.scm",(void*)f_1467},
{"f_1438chicken.scm",(void*)f_1438},
{"f_1431chicken.scm",(void*)f_1431},
{"f_1063chicken.scm",(void*)f_1063},
{"f_1426chicken.scm",(void*)f_1426},
{"f_1419chicken.scm",(void*)f_1419},
{"f_1415chicken.scm",(void*)f_1415},
{"f_1407chicken.scm",(void*)f_1407},
{"f_1405chicken.scm",(void*)f_1405},
{"f_1067chicken.scm",(void*)f_1067},
{"f_1196chicken.scm",(void*)f_1196},
{"f_1208chicken.scm",(void*)f_1208},
{"f_1391chicken.scm",(void*)f_1391},
{"f_1384chicken.scm",(void*)f_1384},
{"f_1347chicken.scm",(void*)f_1347},
{"f_1293chicken.scm",(void*)f_1293},
{"f_1310chicken.scm",(void*)f_1310},
{"f_1296chicken.scm",(void*)f_1296},
{"f_1230chicken.scm",(void*)f_1230},
{"f_1273chicken.scm",(void*)f_1273},
{"f_1253chicken.scm",(void*)f_1253},
{"f_1233chicken.scm",(void*)f_1233},
{"f_1200chicken.scm",(void*)f_1200},
{"f_1203chicken.scm",(void*)f_1203},
{"f_1184chicken.scm",(void*)f_1184},
{"f_1191chicken.scm",(void*)f_1191},
{"f_1176chicken.scm",(void*)f_1176},
{"f_1182chicken.scm",(void*)f_1182},
{"f_1179chicken.scm",(void*)f_1179},
{"f_1069chicken.scm",(void*)f_1069},
{"f_1075chicken.scm",(void*)f_1075},
{"f_1110chicken.scm",(void*)f_1110},
{"f_1136chicken.scm",(void*)f_1136},
{"f_1132chicken.scm",(void*)f_1132},
{"f_1089chicken.scm",(void*)f_1089},
{"f_773chicken.scm",(void*)f_773},
{"f_777chicken.scm",(void*)f_777},
{"f_814chicken.scm",(void*)f_814},
{"f_835chicken.scm",(void*)f_835},
{"f_833chicken.scm",(void*)f_833},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
