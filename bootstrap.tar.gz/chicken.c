/* Generated from chicken.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-08-14 10:08
   Version 3.3.4 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   compiled 2008-07-29 on pequod (Linux)
   command line: chicken.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path . -no-lambda-info -extend private-namespace.scm -output-file chicken.c
   used units: library eval data_structures ports extras srfi_69 srfi_1 match srfi_4 utils files support compiler optimizer driver platform backend
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_match_toplevel)
C_externimport void C_ccall C_match_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_4_toplevel)
C_externimport void C_ccall C_srfi_4_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_support_toplevel)
C_externimport void C_ccall C_support_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_compiler_toplevel)
C_externimport void C_ccall C_compiler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_optimizer_toplevel)
C_externimport void C_ccall C_optimizer_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_driver_toplevel)
C_externimport void C_ccall C_driver_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_platform_toplevel)
C_externimport void C_ccall C_platform_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_backend_toplevel)
C_externimport void C_ccall C_backend_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[379];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_690)
static void C_ccall f_690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_693)
static void C_ccall f_693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_696)
static void C_ccall f_696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_699)
static void C_ccall f_699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_702)
static void C_ccall f_702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_705)
static void C_ccall f_705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_708)
static void C_ccall f_708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_711)
static void C_ccall f_711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_714)
static void C_ccall f_714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_717)
static void C_ccall f_717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_720)
static void C_ccall f_720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_723)
static void C_ccall f_723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_726)
static void C_ccall f_726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_729)
static void C_ccall f_729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_732)
static void C_ccall f_732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_735)
static void C_ccall f_735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_738)
static void C_ccall f_738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_744)
static void C_ccall f_744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6922)
static void C_ccall f_6922(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6922)
static void C_ccall f_6922r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6926)
static void C_ccall f_6926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6929)
static void C_ccall f_6929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6932)
static void C_ccall f_6932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6938)
static void C_ccall f_6938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7144)
static void C_ccall f_7144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7124)
static void C_ccall f_7124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7120)
static void C_ccall f_7120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7100)
static void C_ccall f_7100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6963)
static void C_fcall f_6963(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6973)
static void C_ccall f_6973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7092)
static void C_ccall f_7092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6976)
static void C_ccall f_6976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7088)
static void C_ccall f_7088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6979)
static void C_ccall f_6979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7010)
static void C_fcall f_7010(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6990)
static void C_ccall f_6990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6961)
static void C_ccall f_6961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_747)
static void C_ccall f_747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6834)
static void C_ccall f_6834(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6834)
static void C_ccall f_6834r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6851)
static void C_ccall f_6851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6854)
static void C_ccall f_6854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6860)
static void C_fcall f_6860(C_word t0,C_word t1) C_noret;
C_noret_decl(f_750)
static void C_ccall f_750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6793)
static void C_ccall f_6793(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6793)
static void C_ccall f_6793r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6797)
static void C_ccall f_6797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_753)
static void C_ccall f_753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6777)
static void C_ccall f_6777(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6777)
static void C_ccall f_6777r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6787)
static void C_ccall f_6787(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6785)
static void C_ccall f_6785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_756)
static void C_ccall f_756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6700)
static void C_ccall f_6700(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6704)
static void C_ccall f_6704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6772)
static void C_ccall f_6772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6707)
static void C_ccall f_6707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6716)
static void C_ccall f_6716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6763)
static void C_ccall f_6763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6730)
static void C_ccall f_6730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6738)
static void C_ccall f_6738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6740)
static void C_fcall f_6740(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6757)
static void C_ccall f_6757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6722)
static void C_ccall f_6722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6714)
static void C_ccall f_6714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_759)
static void C_ccall f_759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6640)
static void C_ccall f_6640(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6640)
static void C_ccall f_6640r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6644)
static void C_fcall f_6644(C_word t0,C_word t1) C_noret;
C_noret_decl(f_762)
static void C_ccall f_762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6581)
static void C_ccall f_6581(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6581)
static void C_ccall f_6581r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6585)
static void C_ccall f_6585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6612)
static void C_fcall f_6612(C_word t0,C_word t1) C_noret;
C_noret_decl(f_765)
static void C_ccall f_765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6407)
static void C_ccall f_6407(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6407)
static void C_ccall f_6407r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6411)
static void C_ccall f_6411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6414)
static void C_ccall f_6414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6575)
static void C_ccall f_6575(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6417)
static void C_ccall f_6417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6569)
static void C_ccall f_6569(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6420)
static void C_ccall f_6420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6567)
static void C_ccall f_6567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6531)
static void C_ccall f_6531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6545)
static void C_fcall f_6545(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6559)
static void C_ccall f_6559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6539)
static void C_ccall f_6539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6535)
static void C_ccall f_6535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6427)
static void C_ccall f_6427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6523)
static void C_ccall f_6523(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6499)
static void C_ccall f_6499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6517)
static void C_ccall f_6517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6507)
static void C_ccall f_6507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6503)
static void C_ccall f_6503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6495)
static void C_ccall f_6495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6479)
static void C_ccall f_6479(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6455)
static void C_ccall f_6455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6473)
static void C_ccall f_6473(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6463)
static void C_ccall f_6463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6459)
static void C_ccall f_6459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6451)
static void C_ccall f_6451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_768)
static void C_ccall f_768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6312)
static void C_ccall f_6312(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6312)
static void C_ccall f_6312r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6348)
static void C_fcall f_6348(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6361)
static void C_ccall f_6361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6319)
static void C_ccall f_6319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_771)
static void C_ccall f_771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6202)
static void C_ccall f_6202(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6202)
static void C_ccall f_6202r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6206)
static void C_ccall f_6206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6209)
static void C_ccall f_6209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6212)
static void C_ccall f_6212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6215)
static void C_ccall f_6215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6306)
static void C_ccall f_6306(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6218)
static void C_ccall f_6218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6300)
static void C_ccall f_6300(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6221)
static void C_ccall f_6221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6294)
static void C_ccall f_6294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6298)
static void C_ccall f_6298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6228)
static void C_ccall f_6228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6266)
static void C_ccall f_6266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6264)
static void C_ccall f_6264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_774)
static void C_ccall f_774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6192)
static void C_ccall f_6192(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6192)
static void C_ccall f_6192r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_777)
static void C_ccall f_777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6178)
static void C_ccall f_6178(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6178)
static void C_ccall f_6178r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_780)
static void C_ccall f_780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_854)
static void C_ccall f_854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_857)
static void C_ccall f_857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5916)
static void C_ccall f_5916(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5920)
static void C_ccall f_5920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5929)
static void C_ccall f_5929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6138)
static void C_fcall f_6138(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6151)
static void C_ccall f_6151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5932)
static void C_ccall f_5932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6128)
static void C_ccall f_6128(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6136)
static void C_ccall f_6136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5935)
static void C_ccall f_5935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6082)
static void C_fcall f_6082(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6115)
static void C_ccall f_6115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6122)
static void C_ccall f_6122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6098)
static void C_fcall f_6098(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5947)
static void C_ccall f_5947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6076)
static void C_ccall f_6076(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5954)
static void C_ccall f_5954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5956)
static void C_fcall f_5956(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6070)
static void C_ccall f_6070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5990)
static void C_fcall f_5990(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6044)
static void C_ccall f_6044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6021)
static void C_ccall f_6021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6001)
static void C_ccall f_6001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5976)
static void C_ccall f_5976(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5984)
static void C_ccall f_5984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5974)
static void C_ccall f_5974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5936)
static void C_ccall f_5936(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5876)
static void C_fcall f_5876(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5899)
static void C_ccall f_5899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5903)
static void C_ccall f_5903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5845)
static void C_fcall f_5845(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5866)
static void C_ccall f_5866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_860)
static void C_ccall f_860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5794)
static void C_ccall f_5794(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5798)
static void C_ccall f_5798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5809)
static void C_fcall f_5809(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5834)
static void C_ccall f_5834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_863)
static void C_ccall f_863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5674)
static void C_ccall f_5674(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5678)
static void C_ccall f_5678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5788)
static void C_ccall f_5788(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5786)
static void C_ccall f_5786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5687)
static void C_ccall f_5687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5774)
static void C_ccall f_5774(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5782)
static void C_ccall f_5782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5690)
static void C_ccall f_5690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5768)
static void C_ccall f_5768(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5710)
static void C_ccall f_5710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5720)
static void C_ccall f_5720(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5740)
static void C_ccall f_5740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5746)
static void C_ccall f_5746(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5754)
static void C_ccall f_5754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5744)
static void C_ccall f_5744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5718)
static void C_ccall f_5718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5714)
static void C_ccall f_5714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5691)
static void C_ccall f_5691(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_866)
static void C_ccall f_866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5653)
static void C_ccall f_5653(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5657)
static void C_ccall f_5657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_869)
static void C_ccall f_869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5643)
static void C_ccall f_5643(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_875)
static void C_ccall f_875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_884)
static void C_fcall f_884(C_word t0,C_word t1) C_noret;
C_noret_decl(f_900)
static void C_fcall f_900(C_word t0,C_word t1) C_noret;
C_noret_decl(f_887)
static void C_ccall f_887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_948)
static void C_ccall f_948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5622)
static void C_ccall f_5622(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5626)
static void C_ccall f_5626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_951)
static void C_ccall f_951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5506)
static void C_ccall f_5506(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5510)
static void C_ccall f_5510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5519)
static void C_fcall f_5519(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5533)
static void C_fcall f_5533(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5597)
static void C_ccall f_5597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5579)
static void C_ccall f_5579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5562)
static void C_ccall f_5562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_954)
static void C_ccall f_954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5407)
static void C_ccall f_5407(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5417)
static void C_ccall f_5417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5430)
static void C_fcall f_5430(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5446)
static void C_ccall f_5446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5484)
static void C_ccall f_5484(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5482)
static void C_ccall f_5482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5474)
static void C_ccall f_5474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5428)
static void C_ccall f_5428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_957)
static void C_ccall f_957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5318)
static void C_ccall f_5318(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5328)
static void C_ccall f_5328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5341)
static void C_fcall f_5341(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5357)
static void C_ccall f_5357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5385)
static void C_ccall f_5385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5339)
static void C_ccall f_5339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_960)
static void C_ccall f_960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5032)
static void C_ccall f_5032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5032)
static void C_ccall f_5032r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5229)
static void C_ccall f_5229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5232)
static void C_ccall f_5232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5235)
static void C_ccall f_5235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5308)
static void C_ccall f_5308(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5316)
static void C_ccall f_5316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5251)
static void C_ccall f_5251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5254)
static void C_ccall f_5254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5257)
static void C_ccall f_5257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5260)
static void C_ccall f_5260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5298)
static void C_ccall f_5298(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5306)
static void C_ccall f_5306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5263)
static void C_ccall f_5263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5043)
static void C_ccall f_5043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5047)
static void C_ccall f_5047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5051)
static void C_ccall f_5051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5053)
static void C_fcall f_5053(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5098)
static void C_ccall f_5098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5110)
static void C_ccall f_5110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5106)
static void C_ccall f_5106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5074)
static void C_ccall f_5074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5266)
static void C_ccall f_5266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5126)
static void C_fcall f_5126(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5226)
static void C_ccall f_5226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5190)
static void C_ccall f_5190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5160)
static void C_ccall f_5160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5269)
static void C_ccall f_5269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5236)
static void C_fcall f_5236(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5248)
static void C_ccall f_5248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5244)
static void C_ccall f_5244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_963)
static void C_ccall f_963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4975)
static void C_ccall f_4975(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4979)
static void C_ccall f_4979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_966)
static void C_ccall f_966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4969)
static void C_ccall f_4969(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_969)
static void C_ccall f_969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4816)
static void C_ccall f_4816(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4816)
static void C_ccall f_4816r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4820)
static void C_ccall f_4820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4823)
static void C_ccall f_4823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4826)
static void C_ccall f_4826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4839)
static void C_fcall f_4839(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4889)
static void C_ccall f_4889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4900)
static void C_ccall f_4900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4837)
static void C_ccall f_4837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_972)
static void C_ccall f_972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4540)
static void C_ccall f_4540(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4574)
static void C_ccall f_4574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4577)
static void C_ccall f_4577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4803)
static void C_ccall f_4803(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4813)
static void C_ccall f_4813(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4801)
static void C_ccall f_4801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4580)
static void C_ccall f_4580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4549)
static void C_fcall f_4549(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4563)
static void C_ccall f_4563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4567)
static void C_ccall f_4567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4583)
static void C_ccall f_4583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4586)
static void C_ccall f_4586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4589)
static void C_ccall f_4589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4596)
static void C_ccall f_4596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4610)
static void C_ccall f_4610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4620)
static void C_ccall f_4620(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4624)
static void C_ccall f_4624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4634)
static void C_fcall f_4634(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4650)
static void C_ccall f_4650(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4669)
static void C_fcall f_4669(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4725)
static void C_ccall f_4725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4736)
static void C_ccall f_4736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4654)
static void C_ccall f_4654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4667)
static void C_ccall f_4667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4640)
static void C_ccall f_4640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4648)
static void C_ccall f_4648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4638)
static void C_ccall f_4638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4608)
static void C_ccall f_4608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_975)
static void C_ccall f_975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4483)
static void C_ccall f_4483(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4483)
static void C_ccall f_4483r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4523)
static void C_ccall f_4523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4493)
static void C_ccall f_4493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_978)
static void C_ccall f_978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4407)
static void C_ccall f_4407(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4407)
static void C_ccall f_4407r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4411)
static void C_ccall f_4411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4414)
static void C_ccall f_4414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_981)
static void C_ccall f_981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4227)
static void C_ccall f_4227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4230)
static void C_ccall f_4230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4373)
static void C_ccall f_4373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4369)
static void C_ccall f_4369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4232)
static void C_ccall f_4232(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4320)
static void C_ccall f_4320(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4318)
static void C_ccall f_4318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4288)
static void C_fcall f_4288(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4255)
static void C_fcall f_4255(C_word t0,C_word t1) C_noret;
C_noret_decl(f_984)
static void C_ccall f_984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4033)
static void C_ccall f_4033(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_4033)
static void C_ccall f_4033r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_4040)
static void C_ccall f_4040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4214)
static void C_ccall f_4214(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4212)
static void C_ccall f_4212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4065)
static void C_fcall f_4065(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4091)
static void C_fcall f_4091(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4119)
static void C_fcall f_4119(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4103)
static void C_ccall f_4103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4063)
static void C_ccall f_4063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_987)
static void C_ccall f_987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4024)
static void C_ccall f_4024(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4028)
static void C_ccall f_4028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_990)
static void C_ccall f_990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4005)
static void C_ccall f_4005(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4018)
static void C_ccall f_4018(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4016)
static void C_ccall f_4016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_993)
static void C_ccall f_993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3986)
static void C_ccall f_3986(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3990)
static void C_ccall f_3990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3999)
static void C_ccall f_3999(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3997)
static void C_ccall f_3997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_996)
static void C_ccall f_996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3858)
static void C_ccall f_3858(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3864)
static void C_fcall f_3864(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3945)
static void C_ccall f_3945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3874)
static void C_ccall f_3874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3877)
static void C_ccall f_3877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3883)
static void C_ccall f_3883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3890)
static void C_ccall f_3890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3906)
static void C_ccall f_3906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_999)
static void C_ccall f_999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3715)
static void C_ccall f_3715(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3721)
static void C_fcall f_3721(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3833)
static void C_ccall f_3833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3806)
static void C_ccall f_3806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3734)
static void C_ccall f_3734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3740)
static void C_ccall f_3740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3751)
static void C_ccall f_3751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3767)
static void C_ccall f_3767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1002)
static void C_ccall f_1002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3656)
static void C_ccall f_3656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_3656)
static void C_ccall f_3656r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_1005)
static void C_ccall f_1005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3485)
static void C_ccall f_3485(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3485)
static void C_ccall f_3485r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3491)
static void C_fcall f_3491(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3565)
static void C_fcall f_3565(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3568)
static void C_ccall f_3568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3641)
static void C_ccall f_3641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3634)
static void C_ccall f_3634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3626)
static void C_ccall f_3626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3613)
static void C_ccall f_3613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3501)
static void C_fcall f_3501(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1008)
static void C_ccall f_1008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3434)
static void C_ccall f_3434(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3434)
static void C_ccall f_3434r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1011)
static void C_ccall f_1011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3374)
static void C_ccall f_3374(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3374)
static void C_ccall f_3374r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3384)
static void C_fcall f_3384(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3403)
static void C_ccall f_3403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3387)
static void C_ccall f_3387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1014)
static void C_ccall f_1014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1017)
static void C_ccall f_1017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3337)
static void C_ccall f_3337(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3341)
static void C_ccall f_3341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1020)
static void C_ccall f_1020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3318)
static void C_ccall f_3318(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3322)
static void C_ccall f_3322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1023)
static void C_ccall f_1023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3299)
static void C_ccall f_3299(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3303)
static void C_ccall f_3303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3312)
static void C_ccall f_3312(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3310)
static void C_ccall f_3310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1026)
static void C_ccall f_1026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3280)
static void C_ccall f_3280(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3284)
static void C_ccall f_3284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3293)
static void C_ccall f_3293(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3291)
static void C_ccall f_3291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1029)
static void C_ccall f_1029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3261)
static void C_ccall f_3261(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3265)
static void C_ccall f_3265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3274)
static void C_ccall f_3274(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3272)
static void C_ccall f_3272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1032)
static void C_ccall f_1032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3242)
static void C_ccall f_3242(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3246)
static void C_ccall f_3246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3255)
static void C_ccall f_3255(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3253)
static void C_ccall f_3253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1035)
static void C_ccall f_1035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3223)
static void C_ccall f_3223(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3227)
static void C_ccall f_3227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3236)
static void C_ccall f_3236(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3234)
static void C_ccall f_3234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1038)
static void C_ccall f_1038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3123)
static void C_ccall f_3123(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3127)
static void C_ccall f_3127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3182)
static void C_ccall f_3182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3136)
static void C_ccall f_3136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1041)
static void C_ccall f_1041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2903)
static void C_ccall f_2903(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2907)
static void C_fcall f_2907(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2910)
static void C_fcall f_2910(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2991)
static void C_ccall f_2991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3058)
static void C_ccall f_3058(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3056)
static void C_ccall f_3056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3048)
static void C_ccall f_3048(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3036)
static void C_ccall f_3036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2916)
static void C_ccall f_2916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2942)
static void C_fcall f_2942(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1044)
static void C_ccall f_1044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2832)
static void C_ccall f_2832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2901)
static void C_ccall f_2901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2855)
static void C_fcall f_2855(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1047)
static void C_ccall f_1047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2722)
static void C_ccall f_2722(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2722)
static void C_ccall f_2722r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2822)
static void C_ccall f_2822(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2726)
static void C_ccall f_2726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2798)
static void C_ccall f_2798(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2733)
static void C_ccall f_2733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2739)
static void C_ccall f_2739(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2737)
static void C_ccall f_2737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1050)
static void C_ccall f_1050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2693)
static void C_ccall f_2693(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2697)
static void C_ccall f_2697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2720)
static void C_ccall f_2720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2716)
static void C_ccall f_2716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1053)
static void C_ccall f_1053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2680)
static void C_ccall f_2680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2684)
static void C_ccall f_2684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1056)
static void C_ccall f_1056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1886)
static void C_ccall f_1886(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1886)
static void C_ccall f_1886r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1890)
static void C_ccall f_1890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1896)
static void C_ccall f_1896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1899)
static void C_ccall f_1899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1902)
static void C_ccall f_1902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1905)
static void C_ccall f_1905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2572)
static void C_fcall f_2572(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2651)
static void C_ccall f_2651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2647)
static void C_ccall f_2647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2582)
static void C_fcall f_2582(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2586)
static void C_ccall f_2586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2627)
static void C_ccall f_2627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2617)
static void C_ccall f_2617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2607)
static void C_ccall f_2607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2603)
static void C_ccall f_2603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2589)
static void C_ccall f_2589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1993)
static void C_ccall f_1993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1996)
static void C_ccall f_1996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2566)
static void C_ccall f_2566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2495)
static void C_ccall f_2495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2501)
static void C_ccall f_2501(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2555)
static void C_ccall f_2555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2547)
static void C_ccall f_2547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2530)
static void C_ccall f_2530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2518)
static void C_ccall f_2518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2499)
static void C_ccall f_2499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2483)
static void C_ccall f_2483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2479)
static void C_ccall f_2479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2007)
static void C_fcall f_2007(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2461)
static void C_ccall f_2461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2015)
static void C_fcall f_2015(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2023)
static void C_fcall f_2023(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2029)
static void C_ccall f_2029(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2306)
static void C_ccall f_2306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2418)
static void C_ccall f_2418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2414)
static void C_ccall f_2414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2383)
static void C_ccall f_2383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2406)
static void C_ccall f_2406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2395)
static void C_ccall f_2395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2324)
static void C_fcall f_2324(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2369)
static void C_ccall f_2369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2365)
static void C_ccall f_2365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2341)
static void C_ccall f_2341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2353)
static void C_ccall f_2353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2321)
static void C_fcall f_2321(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2051)
static void C_ccall f_2051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2287)
static void C_ccall f_2287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2192)
static void C_ccall f_2192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2275)
static void C_ccall f_2275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2264)
static void C_ccall f_2264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2069)
static void C_fcall f_2069(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2178)
static void C_ccall f_2178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2174)
static void C_ccall f_2174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2086)
static void C_ccall f_2086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2158)
static void C_ccall f_2158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2066)
static void C_fcall f_2066(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2027)
static void C_ccall f_2027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2011)
static void C_ccall f_2011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2003)
static void C_ccall f_2003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1950)
static void C_fcall f_1950(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1966)
static void C_ccall f_1966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1907)
static void C_fcall f_1907(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1059)
static void C_ccall f_1059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1872)
static void C_ccall f_1872(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1062)
static void C_ccall f_1062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1532)
static void C_ccall f_1532(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1532)
static void C_ccall f_1532r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1536)
static void C_fcall f_1536(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1539)
static void C_ccall f_1539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1844)
static void C_ccall f_1844(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1542)
static void C_ccall f_1542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1819)
static void C_ccall f_1819(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1545)
static void C_ccall f_1545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1787)
static void C_ccall f_1787(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1548)
static void C_ccall f_1548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1761)
static void C_ccall f_1761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1551)
static void C_fcall f_1551(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1554)
static void C_ccall f_1554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1749)
static void C_ccall f_1749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1557)
static void C_ccall f_1557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1745)
static void C_ccall f_1745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1560)
static void C_ccall f_1560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1733)
static void C_ccall f_1733(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1741)
static void C_ccall f_1741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1571)
static void C_ccall f_1571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1695)
static void C_ccall f_1695(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1677)
static void C_ccall f_1677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1673)
static void C_ccall f_1673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1613)
static void C_ccall f_1613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1603)
static void C_ccall f_1603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1599)
static void C_ccall f_1599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1567)
static void C_ccall f_1567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1065)
static void C_ccall f_1065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1498)
static void C_ccall f_1498(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1068)
static void C_ccall f_1068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1436)
static void C_ccall f_1436(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1436)
static void C_ccall f_1436r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1449)
static void C_fcall f_1449(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1475)
static void C_ccall f_1475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1446)
static void C_ccall f_1446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1439)
static void C_fcall f_1439(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1071)
static void C_ccall f_1071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1434)
static void C_ccall f_1434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1427)
static void C_ccall f_1427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1423)
static void C_ccall f_1423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1415)
static void C_ccall f_1415(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1413)
static void C_ccall f_1413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1075)
static void C_ccall f_1075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1204)
static void C_ccall f_1204(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1216)
static void C_fcall f_1216(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1399)
static void C_ccall f_1399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1392)
static void C_ccall f_1392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1355)
static void C_ccall f_1355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1301)
static void C_ccall f_1301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1318)
static void C_ccall f_1318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1304)
static void C_ccall f_1304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1238)
static void C_ccall f_1238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1281)
static void C_ccall f_1281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1261)
static void C_ccall f_1261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1241)
static void C_ccall f_1241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1208)
static void C_ccall f_1208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1211)
static void C_ccall f_1211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1192)
static void C_ccall f_1192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1199)
static void C_ccall f_1199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1184)
static void C_ccall f_1184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1190)
static void C_ccall f_1190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1187)
static void C_ccall f_1187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1077)
static void C_ccall f_1077(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1083)
static void C_fcall f_1083(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1118)
static void C_fcall f_1118(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1144)
static void C_ccall f_1144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1140)
static void C_ccall f_1140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1097)
static void C_ccall f_1097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_781)
static void C_ccall f_781(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_785)
static void C_ccall f_785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_822)
static void C_ccall f_822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_843)
static void C_ccall f_843(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_841)
static void C_ccall f_841(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_6963)
static void C_fcall trf_6963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6963(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6963(t0,t1,t2,t3);}

C_noret_decl(trf_7010)
static void C_fcall trf_7010(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7010(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7010(t0,t1);}

C_noret_decl(trf_6860)
static void C_fcall trf_6860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6860(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6860(t0,t1);}

C_noret_decl(trf_6740)
static void C_fcall trf_6740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6740(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6740(t0,t1,t2,t3);}

C_noret_decl(trf_6644)
static void C_fcall trf_6644(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6644(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6644(t0,t1);}

C_noret_decl(trf_6612)
static void C_fcall trf_6612(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6612(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6612(t0,t1);}

C_noret_decl(trf_6545)
static void C_fcall trf_6545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6545(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6545(t0,t1,t2);}

C_noret_decl(trf_6348)
static void C_fcall trf_6348(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6348(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6348(t0,t1,t2);}

C_noret_decl(trf_6138)
static void C_fcall trf_6138(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6138(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6138(t0,t1,t2,t3);}

C_noret_decl(trf_6082)
static void C_fcall trf_6082(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6082(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6082(t0,t1,t2,t3);}

C_noret_decl(trf_6098)
static void C_fcall trf_6098(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6098(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6098(t0,t1);}

C_noret_decl(trf_5956)
static void C_fcall trf_5956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5956(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5956(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5990)
static void C_fcall trf_5990(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5990(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5990(t0,t1);}

C_noret_decl(trf_5876)
static void C_fcall trf_5876(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5876(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5876(t0,t1,t2,t3);}

C_noret_decl(trf_5845)
static void C_fcall trf_5845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5845(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5845(t0,t1,t2,t3);}

C_noret_decl(trf_5809)
static void C_fcall trf_5809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5809(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5809(t0,t1,t2);}

C_noret_decl(trf_884)
static void C_fcall trf_884(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_884(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_884(t0,t1);}

C_noret_decl(trf_900)
static void C_fcall trf_900(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_900(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_900(t0,t1);}

C_noret_decl(trf_5519)
static void C_fcall trf_5519(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5519(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5519(t0,t1);}

C_noret_decl(trf_5533)
static void C_fcall trf_5533(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5533(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5533(t0,t1,t2);}

C_noret_decl(trf_5430)
static void C_fcall trf_5430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5430(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5430(t0,t1,t2);}

C_noret_decl(trf_5341)
static void C_fcall trf_5341(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5341(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5341(t0,t1,t2);}

C_noret_decl(trf_5053)
static void C_fcall trf_5053(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5053(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5053(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5126)
static void C_fcall trf_5126(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5126(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5126(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5236)
static void C_fcall trf_5236(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5236(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5236(t0,t1,t2);}

C_noret_decl(trf_4839)
static void C_fcall trf_4839(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4839(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4839(t0,t1,t2,t3);}

C_noret_decl(trf_4549)
static void C_fcall trf_4549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4549(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4549(t0,t1,t2);}

C_noret_decl(trf_4634)
static void C_fcall trf_4634(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4634(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4634(t0,t1);}

C_noret_decl(trf_4669)
static void C_fcall trf_4669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4669(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4669(t0,t1,t2,t3);}

C_noret_decl(trf_4288)
static void C_fcall trf_4288(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4288(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4288(t0,t1);}

C_noret_decl(trf_4255)
static void C_fcall trf_4255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4255(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4255(t0,t1);}

C_noret_decl(trf_4065)
static void C_fcall trf_4065(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4065(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4065(t0,t1,t2,t3);}

C_noret_decl(trf_4091)
static void C_fcall trf_4091(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4091(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4091(t0,t1);}

C_noret_decl(trf_4119)
static void C_fcall trf_4119(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4119(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4119(t0,t1);}

C_noret_decl(trf_3864)
static void C_fcall trf_3864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3864(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3864(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3721)
static void C_fcall trf_3721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3721(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3721(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3491)
static void C_fcall trf_3491(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3491(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3491(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3565)
static void C_fcall trf_3565(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3565(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3565(t0,t1);}

C_noret_decl(trf_3501)
static void C_fcall trf_3501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3501(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3501(t0,t1);}

C_noret_decl(trf_3384)
static void C_fcall trf_3384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3384(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3384(t0,t1);}

C_noret_decl(trf_2907)
static void C_fcall trf_2907(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2907(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2907(t0,t1);}

C_noret_decl(trf_2910)
static void C_fcall trf_2910(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2910(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2910(t0,t1);}

C_noret_decl(trf_2942)
static void C_fcall trf_2942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2942(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2942(t0,t1);}

C_noret_decl(trf_2855)
static void C_fcall trf_2855(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2855(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2855(t0,t1);}

C_noret_decl(trf_2572)
static void C_fcall trf_2572(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2572(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2572(t0,t1,t2);}

C_noret_decl(trf_2582)
static void C_fcall trf_2582(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2582(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2582(t0,t1);}

C_noret_decl(trf_2007)
static void C_fcall trf_2007(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2007(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2007(t0,t1);}

C_noret_decl(trf_2015)
static void C_fcall trf_2015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2015(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2015(t0,t1);}

C_noret_decl(trf_2023)
static void C_fcall trf_2023(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2023(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2023(t0,t1);}

C_noret_decl(trf_2324)
static void C_fcall trf_2324(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2324(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2324(t0,t1);}

C_noret_decl(trf_2321)
static void C_fcall trf_2321(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2321(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2321(t0,t1);}

C_noret_decl(trf_2069)
static void C_fcall trf_2069(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2069(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2069(t0,t1);}

C_noret_decl(trf_2066)
static void C_fcall trf_2066(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2066(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2066(t0,t1);}

C_noret_decl(trf_1950)
static void C_fcall trf_1950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1950(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1950(t0,t1,t2);}

C_noret_decl(trf_1907)
static void C_fcall trf_1907(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1907(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1907(t0,t1,t2);}

C_noret_decl(trf_1536)
static void C_fcall trf_1536(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1536(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1536(t0,t1);}

C_noret_decl(trf_1551)
static void C_fcall trf_1551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1551(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1551(t0,t1);}

C_noret_decl(trf_1449)
static void C_fcall trf_1449(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1449(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1449(t0,t1);}

C_noret_decl(trf_1439)
static void C_fcall trf_1439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1439(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1439(t0,t1);}

C_noret_decl(trf_1216)
static void C_fcall trf_1216(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1216(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1216(t0,t1,t2);}

C_noret_decl(trf_1083)
static void C_fcall trf_1083(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1083(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1083(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1118)
static void C_fcall trf_1118(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1118(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1118(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(4053)){
C_save(t1);
C_rereclaim2(4053*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,379);
lf[0]=C_h_intern(&lf[0],19,"\003sysundefined-value");
lf[1]=C_h_intern(&lf[1],3,"map");
lf[2]=C_h_intern(&lf[2],6,"lambda");
lf[3]=C_h_intern(&lf[3],14,"\004coreundefined");
lf[4]=C_h_intern(&lf[4],20,"\003syscall-with-values");
lf[5]=C_h_intern(&lf[5],9,"\004coreset!");
lf[6]=C_h_intern(&lf[6],6,"gensym");
lf[7]=C_h_intern(&lf[7],16,"\003syscheck-syntax");
lf[8]=C_h_intern(&lf[8],25,"set!-values/define-values");
lf[9]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[10]=C_h_intern(&lf[10],27,"\010compilercompiler-arguments");
lf[11]=C_h_intern(&lf[11],29,"\010compilerprocess-command-line");
lf[12]=C_h_intern(&lf[12],7,"reverse");
lf[13]=C_h_intern(&lf[13],14,"string->symbol");
lf[14]=C_h_intern(&lf[14],9,"substring");
lf[15]=C_h_intern(&lf[15],25,"\003sysimplicit-exit-handler");
lf[16]=C_h_intern(&lf[16],17,"user-options-pass");
lf[17]=C_h_intern(&lf[17],4,"exit");
lf[18]=C_h_intern(&lf[18],19,"compile-source-file");
lf[19]=C_h_intern(&lf[19],14,"optimize-level");
lf[20]=C_h_intern(&lf[20],5,"cons*");
lf[21]=C_h_intern(&lf[21],22,"optimize-leaf-routines");
lf[22]=C_h_intern(&lf[22],6,"unsafe");
lf[23]=C_h_intern(&lf[23],25,"\010compilercompiler-warning");
lf[24]=C_h_intern(&lf[24],5,"usage");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\047invalid optimization level ~S - ignored");
lf[26]=C_h_intern(&lf[26],11,"debug-level");
lf[27]=C_h_intern(&lf[27],14,"no-lambda-info");
lf[28]=C_h_intern(&lf[28],8,"no-trace");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000 invalid debug level ~S - ignored");
lf[30]=C_h_intern(&lf[30],14,"benchmark-mode");
lf[31]=C_h_intern(&lf[31],17,"fixnum-arithmetic");
lf[32]=C_h_intern(&lf[32],18,"disable-interrupts");
lf[33]=C_h_intern(&lf[33],5,"block");
lf[34]=C_h_intern(&lf[34],11,"lambda-lift");
lf[35]=C_h_intern(&lf[35],31,"\010compilervalid-compiler-options");
lf[36]=C_h_intern(&lf[36],45,"\010compilervalid-compiler-options-with-argument");
lf[37]=C_h_intern(&lf[37],4,"quit");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~s\047 option");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000&invalid compiler option `~a\047 - ignored");
lf[40]=C_h_intern(&lf[40],4,"conc");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[42]=C_h_intern(&lf[42],6,"append");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[44]=C_h_intern(&lf[44],6,"remove");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[46]=C_h_intern(&lf[46],12,"string-split");
lf[47]=C_h_intern(&lf[47],6,"getenv");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\017CHICKEN_OPTIONS");
lf[49]=C_h_intern(&lf[49],4,"argv");
lf[50]=C_h_intern(&lf[50],12,"syntax-error");
lf[51]=C_h_intern(&lf[51],21,"define-compiler-macro");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000!invalid compiler macro definition");
lf[53]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004void\376\377\016");
lf[54]=C_h_intern(&lf[54],9,"compiling");
lf[55]=C_h_intern(&lf[55],12,"\003sysfeatures");
lf[56]=C_h_intern(&lf[56],7,"warning");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\0004compile macros are not available in interpreted code");
lf[58]=C_h_intern(&lf[58],32,"\010compilerregister-compiler-macro");
lf[59]=C_h_intern(&lf[59],18,"\003sysregister-macro");
lf[60]=C_h_intern(&lf[60],4,"args");
lf[61]=C_h_intern(&lf[61],5,"quote");
lf[62]=C_h_intern(&lf[62],7,"sprintf");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000$`~s\047 is deprecated, use `~s\047 instead");
lf[64]=C_h_intern(&lf[64],4,"cons");
lf[65]=C_h_intern(&lf[65],12,"define-macro");
lf[66]=C_h_intern(&lf[66],23,"define-deprecated-macro");
lf[67]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016");
lf[68]=C_h_intern(&lf[68],5,"begin");
lf[69]=C_h_intern(&lf[69],4,"syms");
lf[70]=C_h_intern(&lf[70],7,"symbol\077");
lf[71]=C_h_intern(&lf[71],4,"list");
lf[72]=C_h_intern(&lf[72],2,"if");
lf[73]=C_h_intern(&lf[73],3,"sum");
lf[74]=C_h_intern(&lf[74],5,"null\077");
lf[75]=C_h_intern(&lf[75],3,"cdr");
lf[76]=C_h_intern(&lf[76],3,"car");
lf[77]=C_h_intern(&lf[77],3,"val");
lf[78]=C_h_intern(&lf[78],4,"case");
lf[79]=C_h_intern(&lf[79],3,"let");
lf[80]=C_h_intern(&lf[80],11,"bitwise-ior");
lf[81]=C_h_intern(&lf[81],4,"loop");
lf[82]=C_h_intern(&lf[82],6,"define");
lf[83]=C_h_intern(&lf[83],4,"cond");
lf[84]=C_h_intern(&lf[84],19,"define-foreign-type");
lf[85]=C_h_intern(&lf[85],10,"\003sysappend");
lf[86]=C_h_intern(&lf[86],4,"else");
lf[87]=C_h_intern(&lf[87],1,"=");
lf[88]=C_h_intern(&lf[88],5,"error");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\024not a member of enum");
lf[90]=C_h_intern(&lf[90],23,"define-foreign-variable");
lf[91]=C_h_intern(&lf[91],8,"->string");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\010number->");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\010->number");
lf[94]=C_h_intern(&lf[94],7,"\003sysmap");
lf[95]=C_h_intern(&lf[95],19,"define-foreign-enum");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid type specification");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid enum specification");
lf[98]=C_h_intern(&lf[98],15,"foreign-declare");
lf[99]=C_h_intern(&lf[99],12,"\004coredeclare");
lf[100]=C_h_intern(&lf[100],20,"\003sysregister-macro-2");
lf[101]=C_h_intern(&lf[101],8,"identity");
lf[102]=C_h_intern(&lf[102],5,"const");
lf[103]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\005union\376\377\016");
lf[104]=C_h_intern(&lf[104],9,"c-pointer");
lf[105]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\005union\376\377\016");
lf[106]=C_h_intern(&lf[106],3,"int");
lf[107]=C_h_intern(&lf[107],15,"foreign-lambda*");
lf[108]=C_h_intern(&lf[108],4,"fx>=");
lf[109]=C_h_intern(&lf[109],3,"fx<");
lf[110]=C_h_intern(&lf[110],3,"and");
lf[111]=C_h_intern(&lf[111],10,"\004corecheck");
lf[112]=C_h_intern(&lf[112],21,"define-foreign-record");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\031array access out of range");
lf[114]=C_h_intern(&lf[114],4,"void");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\031array access out of range");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\020~A->~A[~A] = ~A;");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\012~A-~A-set!");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\025return(~A~A->~A[~A]);");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\005~A-~A");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\014~A->~A = ~A;");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\012~A-~A-set!");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\021return(~A~A->~A);");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\005~A-~A");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\015bad slot spec");
lf[129]=C_h_intern(&lf[129],3,"ptr");
lf[130]=C_h_intern(&lf[130],11,"\004coreinline");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\007C_qfree");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000#return((~a *)C_malloc(sizeof(~a)));");
lf[133]=C_h_intern(&lf[133],7,"declare");
lf[134]=C_h_intern(&lf[134],18,"string-intersperse");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\002};");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\007~A[~A];");
lf[138]=C_h_intern(&lf[138],33,"\010compilerforeign-type-declaration");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\003~A;");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\015bad slot spec");
lf[141]=C_h_intern(&lf[141],13,"string-append");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\007struct ");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\003 { ");
lf[144]=C_h_intern(&lf[144],19,"\003syshash-table-set!");
lf[145]=C_h_intern(&lf[145],27,"\010compilerforeign-type-table");
lf[146]=C_h_intern(&lf[146],7,"\000rename");
lf[147]=C_h_intern(&lf[147],4,"eval");
lf[148]=C_h_intern(&lf[148],5,"cadar");
lf[149]=C_h_intern(&lf[149],12,"\000constructor");
lf[150]=C_h_intern(&lf[150],11,"\000destructor");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000)invalid foreign record-type specification");
lf[152]=C_h_intern(&lf[152],4,"caar");
lf[153]=C_h_intern(&lf[153],8,"keyword\077");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\011struct ~A");
lf[155]=C_h_intern(&lf[155],5,"code_");
lf[156]=C_h_intern(&lf[156],13,"foreign-value");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\0007static C_word ~A() { ~A\012; return C_SCHEME_UNDEFINED; }\012");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[159]=C_h_intern(&lf[159],12,"foreign-code");
lf[160]=C_h_intern(&lf[160],17,"\004corelet-location");
lf[161]=C_h_intern(&lf[161],10,"fold-right");
lf[162]=C_h_intern(&lf[162],10,"append-map");
lf[163]=C_h_intern(&lf[163],12,"let-location");
lf[164]=C_h_intern(&lf[164],28,"\004coredefine-foreign-variable");
lf[165]=C_h_intern(&lf[165],29,"\004coredefine-external-variable");
lf[166]=C_h_intern(&lf[166],14,"symbol->string");
lf[167]=C_h_intern(&lf[167],15,"define-location");
lf[168]=C_h_intern(&lf[168],15,"define-external");
lf[169]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[171]=C_h_intern(&lf[171],29,"\004coreforeign-callback-wrapper");
lf[172]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376"
"\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[173]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376"
"\001\000\000\001_\376\377\001\000\000\000\001");
lf[174]=C_h_intern(&lf[174],20,"foreign-safe-wrapper");
lf[175]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006lambda\376\003\000\000\002"
"\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001\376\377\016");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[177]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006lambda\376\003\000\000\002\376\001\000\000\013lambda-list"
"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001\376\377\016");
lf[178]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[179]=C_h_intern(&lf[179],22,"\004coreforeign-primitive");
lf[180]=C_h_intern(&lf[180],17,"foreign-primitive");
lf[181]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[182]=C_h_intern(&lf[182],29,"\004coreforeign-callback-lambda*");
lf[183]=C_h_intern(&lf[183],20,"foreign-safe-lambda*");
lf[184]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\001");
lf[185]=C_h_intern(&lf[185],28,"\004coreforeign-callback-lambda");
lf[186]=C_h_intern(&lf[186],19,"foreign-safe-lambda");
lf[187]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[188]=C_h_intern(&lf[188],20,"\004coreforeign-lambda*");
lf[189]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\001");
lf[190]=C_h_intern(&lf[190],19,"\004coreforeign-lambda");
lf[191]=C_h_intern(&lf[191],14,"foreign-lambda");
lf[192]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[193]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[194]=C_h_intern(&lf[194],24,"\004coredefine-foreign-type");
lf[195]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\001\376\377\001\000\000\000\003");
lf[196]=C_h_intern(&lf[196],17,"register-feature!");
lf[197]=C_h_intern(&lf[197],6,"srfi-8");
lf[198]=C_h_intern(&lf[198],7,"srfi-16");
lf[199]=C_h_intern(&lf[199],7,"srfi-26");
lf[200]=C_h_intern(&lf[200],7,"srfi-31");
lf[201]=C_h_intern(&lf[201],7,"srfi-15");
lf[202]=C_h_intern(&lf[202],7,"srfi-11");
lf[203]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004void\376\377\016\376\377\016");
lf[204]=C_h_intern(&lf[204],25,"\003sysenable-runtime-macros");
lf[205]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\377\016");
lf[206]=C_h_intern(&lf[206],17,"define-for-syntax");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\022invalid identifier");
lf[208]=C_h_intern(&lf[208],6,"letrec");
lf[209]=C_h_intern(&lf[209],3,"rec");
lf[210]=C_h_intern(&lf[210],22,"chicken-compile-shared");
lf[211]=C_h_intern(&lf[211],3,"not");
lf[212]=C_h_intern(&lf[212],4,"unit");
lf[213]=C_h_intern(&lf[213],7,"provide");
lf[214]=C_h_intern(&lf[214],11,"cond-expand");
lf[215]=C_h_intern(&lf[215],6,"export");
lf[216]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\377\016");
lf[217]=C_h_intern(&lf[217],6,"static");
lf[218]=C_h_intern(&lf[218],4,"cdar");
lf[219]=C_h_intern(&lf[219],7,"dynamic");
lf[220]=C_h_intern(&lf[220],16,"define-extension");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid clause specifier");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid clause syntax");
lf[223]=C_h_intern(&lf[223],22,"string-parse-start+end");
lf[224]=C_h_intern(&lf[224],7,"receive");
lf[225]=C_h_intern(&lf[225],28,"string-parse-final-start+end");
lf[226]=C_h_intern(&lf[226],20,"let-string-start+end");
lf[227]=C_h_intern(&lf[227],5,"apply");
lf[228]=C_h_intern(&lf[228],2,"<>");
lf[229]=C_h_intern(&lf[229],5,"<...>");
lf[230]=C_h_intern(&lf[230],4,"cute");
lf[231]=C_h_intern(&lf[231],3,"cut");
lf[232]=C_h_intern(&lf[232],22,"\004corerequire-extension");
lf[233]=C_h_intern(&lf[233],3,"use");
lf[234]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[235]=C_h_intern(&lf[235],17,"require-extension");
lf[236]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[237]=C_h_intern(&lf[237],23,"\004corerequire-for-syntax");
lf[238]=C_h_intern(&lf[238],18,"require-for-syntax");
lf[239]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[240]=C_h_intern(&lf[240],18,"\003sysmake-structure");
lf[241]=C_h_intern(&lf[241],1,"x");
lf[242]=C_h_intern(&lf[242],14,"\003sysstructure\077");
lf[243]=C_h_intern(&lf[243],15,"\000record-setters");
lf[244]=C_h_intern(&lf[244],19,"\003syscheck-structure");
lf[245]=C_h_intern(&lf[245],13,"\003sysblock-ref");
lf[246]=C_h_intern(&lf[246],18,"getter-with-setter");
lf[247]=C_h_intern(&lf[247],1,"y");
lf[248]=C_h_intern(&lf[248],14,"\003sysblock-set!");
lf[249]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[250]=C_h_intern(&lf[250],18,"define-record-type");
lf[251]=C_h_intern(&lf[251],4,"memv");
lf[252]=C_h_intern(&lf[252],9,"condition");
lf[253]=C_h_intern(&lf[253],8,"\003sysslot");
lf[254]=C_h_intern(&lf[254],17,"handle-exceptions");
lf[255]=C_h_intern(&lf[255],10,"\003syssignal");
lf[256]=C_h_intern(&lf[256],14,"condition-case");
lf[257]=C_h_intern(&lf[257],9,"\003sysapply");
lf[258]=C_h_intern(&lf[258],10,"\003sysvalues");
lf[259]=C_h_intern(&lf[259],22,"with-exception-handler");
lf[260]=C_h_intern(&lf[260],30,"call-with-current-continuation");
lf[261]=C_h_intern(&lf[261],27,"\003sysregister-record-printer");
lf[262]=C_h_intern(&lf[262],21,"define-record-printer");
lf[263]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[264]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[265]=C_h_intern(&lf[265],6,"length");
lf[266]=C_h_intern(&lf[266],9,"split-at!");
lf[267]=C_h_intern(&lf[267],4,"take");
lf[268]=C_h_intern(&lf[268],3,"fx=");
lf[269]=C_h_intern(&lf[269],11,"case-lambda");
lf[270]=C_h_intern(&lf[270],11,"lambda-list");
lf[271]=C_h_intern(&lf[271],25,"\003sysdecompose-lambda-list");
lf[272]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corecheck\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\003syserror\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreimmutable\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376B\000\0000no matching clause in call to \047case-lambda\047 form\376\377\016\376\377\016\376\377\016"
"\376\377\016");
lf[273]=C_h_intern(&lf[273],3,"min");
lf[274]=C_h_intern(&lf[274],7,"require");
lf[275]=C_h_intern(&lf[275],6,"srfi-1");
lf[276]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[278]=C_h_intern(&lf[278],14,"\004coreimmutable");
lf[279]=C_h_intern(&lf[279],9,"\003syserror");
lf[280]=C_h_intern(&lf[280],14,"let-optionals*");
lf[281]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[282]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[283]=C_h_intern(&lf[283],8,"optional");
lf[284]=C_h_intern(&lf[284],9,":optional");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[286]=C_h_intern(&lf[286],4,"let*");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\004def-");
lf[289]=C_h_intern(&lf[289],5,"%rest");
lf[290]=C_h_intern(&lf[290],4,"body");
lf[291]=C_h_intern(&lf[291],4,"cadr");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\001%");
lf[293]=C_h_intern(&lf[293],13,"let-optionals");
lf[294]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[295]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[296]=C_h_intern(&lf[296],4,"eqv\077");
lf[297]=C_h_intern(&lf[297],6,"switch");
lf[298]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[299]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[300]=C_h_intern(&lf[300],2,"or");
lf[301]=C_h_intern(&lf[301],6,"select");
lf[302]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[303]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[304]=C_h_intern(&lf[304],21,"\003syssyntax-error-hook");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\037syntax error in \047and-let*\047 form");
lf[306]=C_h_intern(&lf[306],8,"and-let*");
lf[307]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[308]=C_h_intern(&lf[308],20,"\004coredefine-constant");
lf[309]=C_h_intern(&lf[309],15,"define-constant");
lf[310]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[311]=C_h_intern(&lf[311],18,"\004coredefine-inline");
lf[312]=C_h_intern(&lf[312],13,"define-inline");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000*invalid substitution form - must be lambda");
lf[314]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[315]=C_h_intern(&lf[315],8,"list-ref");
lf[316]=C_h_intern(&lf[316],9,"nth-value");
lf[317]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[318]=C_h_intern(&lf[318],13,"letrec-values");
lf[319]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[320]=C_h_intern(&lf[320],10,"let-values");
lf[321]=C_h_intern(&lf[321],11,"let*-values");
lf[322]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[323]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[324]=C_h_intern(&lf[324],13,"define-values");
lf[325]=C_h_intern(&lf[325],11,"set!-values");
lf[326]=C_h_intern(&lf[326],6,"unless");
lf[327]=C_h_intern(&lf[327],4,"when");
lf[328]=C_h_intern(&lf[328],16,"\003sysdynamic-wind");
lf[329]=C_h_intern(&lf[329],1,"t");
lf[330]=C_h_intern(&lf[330],8,"\003syslist");
lf[331]=C_h_intern(&lf[331],12,"parameterize");
lf[332]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[333]=C_h_intern(&lf[333],10,"\000compiling");
lf[334]=C_h_intern(&lf[334],19,"\004corecompiletimetoo");
lf[335]=C_h_intern(&lf[335],20,"\004corecompiletimeonly");
lf[336]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[337]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[338]=C_h_intern(&lf[338],4,"load");
lf[339]=C_h_intern(&lf[339],8,"run-time");
lf[340]=C_h_intern(&lf[340],7,"compile");
lf[341]=C_h_intern(&lf[341],12,"compile-time");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid situation specifier");
lf[343]=C_h_intern(&lf[343],9,"eval-when");
lf[344]=C_h_intern(&lf[344],8,"\003sysvoid");
lf[345]=C_h_intern(&lf[345],9,"fluid-let");
lf[346]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[347]=C_h_intern(&lf[347],11,"\000type-error");
lf[348]=C_h_intern(&lf[348],15,"\003syssignal-hook");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\033argument has incorrect type");
lf[350]=C_h_intern(&lf[350],6,"ensure");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\020assertion failed");
lf[352]=C_h_intern(&lf[352],6,"assert");
lf[353]=C_h_intern(&lf[353],20,"with-input-from-file");
lf[354]=C_h_intern(&lf[354],4,"read");
lf[355]=C_h_intern(&lf[355],27,"\003syscurrent-source-filename");
lf[356]=C_h_intern(&lf[356],5,"print");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\014; including ");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[359]=C_h_intern(&lf[359],12,"load-verbose");
lf[360]=C_h_intern(&lf[360],28,"\003sysresolve-include-filename");
lf[361]=C_h_intern(&lf[361],7,"include");
lf[362]=C_h_intern(&lf[362],15,"\003sysstart-timer");
lf[363]=C_h_intern(&lf[363],14,"\003sysstop-timer");
lf[364]=C_h_intern(&lf[364],17,"\003sysdisplay-times");
lf[365]=C_h_intern(&lf[365],4,"time");
lf[366]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[367]=C_h_intern(&lf[367],28,"\003sysstring->qualified-symbol");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\005-set!");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\001\077");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\005make-");
lf[373]=C_h_intern(&lf[373],27,"\003sysqualified-symbol-prefix");
lf[374]=C_h_intern(&lf[374],13,"define-record");
lf[375]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[376]=C_h_intern(&lf[376],6,"symbol");
lf[377]=C_h_intern(&lf[377],11,"\003sysprovide");
lf[378]=C_h_intern(&lf[378],19,"chicken-more-macros");
C_register_lf2(lf,379,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_690,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k688 */
static void C_ccall f_690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_693,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k691 in k688 */
static void C_ccall f_693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_693,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_696,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k694 in k691 in k688 */
static void C_ccall f_696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_699,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k697 in k694 in k691 in k688 */
static void C_ccall f_699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_699,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_702,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_702,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_705,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_705,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_708,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_711,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_match_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_714,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_4_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_717,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_720,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_723,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_support_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_726,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_compiler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_726,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_729,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_732,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_driver_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_732,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_735,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_platform_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_735,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_738,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_backend_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_738,2,t0,t1);}
t2=C_retrieve(lf[0]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_744,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#provide */
t4=C_retrieve(lf[377]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[378]);}

/* k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_747,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[166]+1);
t4=*((C_word*)lf[13]+1);
t5=*((C_word*)lf[141]+1);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6922,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t7=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[374],t6);}

/* a6921 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6922(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_6922r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6922r(t0,t1,t2,t3);}}

static void C_ccall f_6922r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6926,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t5=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[374],t2,lf[376]);}

/* k6924 in a6921 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6929,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[374],((C_word*)t0)[5],lf[375]);}

/* k6927 in k6924 in a6921 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6929,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6932,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   symbol->string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k6930 in k6927 in k6924 in a6921 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6932,2,t0,t1);}
t2=(C_word)C_i_memq(lf[243],C_retrieve(lf[55]));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6938,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* chicken.scm: 71   ##sys#qualified-symbol-prefix */
t4=C_retrieve(lf[373]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}

/* k6936 in k6930 in k6927 in k6924 in a6921 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7124,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7144,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   string-append */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[372],((C_word*)t0)[3]);}

/* k7142 in k6936 in k6930 in k6927 in k6924 in a6921 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_7144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[367]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7122 in k6936 in k6930 in k6927 in k6924 in a6921 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_7124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7124,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
t4=(C_word)C_a_i_cons(&a,2,lf[240],t3);
t5=(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_list(&a,3,lf[82],t1,t5);
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7100,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t6,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7120,a[2]=((C_word*)t0)[5],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   string-append */
t9=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,((C_word*)t0)[3],lf[371]);}

/* k7118 in k7122 in k6936 in k6930 in k6927 in k6924 in a6921 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_7120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[367]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7098 in k7122 in k6936 in k6930 in k6927 in k6924 in a6921 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_7100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7100,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[241]);
t3=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[10]);
t4=(C_word)C_a_i_list(&a,3,lf[242],lf[241],t3);
t5=(C_word)C_a_i_list(&a,3,lf[2],t2,t4);
t6=(C_word)C_a_i_list(&a,3,lf[82],t1,t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6961,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6963,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t9,a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp));
t11=((C_word*)t9)[1];
f_6963(t11,t7,((C_word*)t0)[2],C_fix(1));}

/* mapslots in k7098 in k7122 in k6936 in k6930 in k6927 in k6924 in a6921 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_6963(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6963,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6973,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=t1,a[9]=t3,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* chicken.scm: 71   symbol->string */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}}

/* k6971 in mapslots in k7098 in k7122 in k6936 in k6930 in k6927 in k6924 in a6921 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6976,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7092,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   string-append */
t4=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[2],lf[369],t1,lf[370]);}

/* k7090 in k6971 in mapslots in k7098 in k7122 in k6936 in k6930 in k6927 in k6924 in a6921 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_7092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[367]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6974 in k6971 in mapslots in k7098 in k7122 in k6936 in k6930 in k6927 in k6924 in a6921 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6979,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t1,a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7088,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   string-append */
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[3],lf[368],((C_word*)t0)[2]);}

/* k7086 in k6974 in k6971 in mapslots in k7098 in k7122 in k6936 in k6930 in k6927 in k6924 in a6921 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_7088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[367]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6977 in k6974 in k6971 in mapslots in k7098 in k7122 in k6936 in k6930 in k6927 in k6924 in a6921 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[167],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6979,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[241],lf[77]);
t3=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[8]);
t4=(C_word)C_a_i_list(&a,3,lf[244],lf[241],t3);
t5=(C_word)C_a_i_list(&a,2,lf[111],t4);
t6=(C_word)C_a_i_list(&a,4,lf[248],lf[241],((C_word*)t0)[7],lf[77]);
t7=(C_word)C_a_i_list(&a,4,lf[2],t2,t5,t6);
t8=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[6],t7);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7010,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t8,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t10=(C_word)C_a_i_list(&a,1,lf[241]);
t11=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[8]);
t12=(C_word)C_a_i_list(&a,3,lf[244],lf[241],t11);
t13=(C_word)C_a_i_list(&a,2,lf[111],t12);
t14=(C_word)C_a_i_list(&a,3,lf[245],lf[241],((C_word*)t0)[7]);
t15=(C_word)C_a_i_list(&a,4,lf[2],t10,t13,t14);
t16=t9;
f_7010(t16,(C_word)C_a_i_list(&a,3,lf[246],t15,((C_word*)t0)[6]));}
else{
t10=(C_word)C_a_i_list(&a,1,lf[241]);
t11=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[8]);
t12=(C_word)C_a_i_list(&a,3,lf[244],lf[241],t11);
t13=(C_word)C_a_i_list(&a,2,lf[111],t12);
t14=(C_word)C_a_i_list(&a,3,lf[245],lf[241],((C_word*)t0)[7]);
t15=t9;
f_7010(t15,(C_word)C_a_i_list(&a,4,lf[2],t10,t13,t14));}}

/* k7008 in k6977 in k6974 in k6971 in mapslots in k7098 in k7122 in k6936 in k6930 in k6927 in k6924 in a6921 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_7010(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7010,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_list(&a,3,lf[68],((C_word*)t0)[6],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6990,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t6=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* chicken.scm: 71   mapslots */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6963(t7,t4,t5,t6);}

/* k6988 in k7008 in k6977 in k6974 in k6971 in mapslots in k7098 in k7122 in k6936 in k6930 in k6927 in k6924 in a6921 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6990,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6959 in k7098 in k7122 in k6936 in k6930 in k6927 in k6924 in a6921 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6961,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[68],t3));}

/* k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_747,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_750,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6834,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[224],t3);}

/* a6833 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6834(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+23)){
C_save_and_reclaim((void*)tr3r,(void*)f_6834r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6834r(t0,t1,t2,t3);}}

static void C_ccall f_6834r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(23);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[4],t4,lf[330]));}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6851,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t5=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[224],t2,lf[270]);}}

/* k6849 in a6833 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[224],((C_word*)t0)[3],lf[366]);}

/* k6852 in k6849 in a6833 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6860,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=t2;
f_6860(t4,(C_word)C_i_nullp(t3));}
else{
t3=t2;
f_6860(t3,C_SCHEME_FALSE);}}

/* k6858 in k6852 in k6849 in a6833 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_6860(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6860,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[79],t7));}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[2],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[4],t3,t6));}}

/* k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_753,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[6]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6793,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t5=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[365],t4);}

/* a6792 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6793(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_6793r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6793r(t0,t1,t2);}}

static void C_ccall f_6793r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6797,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   gensym */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[329]);}

/* k6795 in a6792 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6797,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[362]);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,lf[2],t3);
t5=(C_word)C_a_i_list(&a,1,lf[363]);
t6=(C_word)C_a_i_list(&a,2,lf[364],t5);
t7=(C_word)C_a_i_list(&a,3,lf[257],lf[258],t1);
t8=(C_word)C_a_i_list(&a,4,lf[2],t1,t6,t7);
t9=(C_word)C_a_i_list(&a,3,lf[4],t4,t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,3,lf[68],t2,t9));}

/* k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_756,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6777,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[133],t3);}

/* a6776 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6777(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_6777r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6777r(t0,t1,t2);}}

static void C_ccall f_6777r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6785,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6787,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a6786 in a6776 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6787(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6787,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k6783 in a6776 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6785,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[99],t1));}

/* k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_759,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[353]);
t4=*((C_word*)lf[354]+1);
t5=*((C_word*)lf[12]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6700,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t7=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[361],t6);}

/* a6699 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6700(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6700,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6704,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#resolve-include-filename */
t4=C_retrieve(lf[360]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,C_SCHEME_TRUE);}

/* k6702 in a6699 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6707,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6772,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   load-verbose */
t4=C_retrieve(lf[359]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k6770 in k6702 in a6699 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken.scm: 71   print */
t2=*((C_word*)lf[356]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[357],((C_word*)t0)[2],lf[358]);}
else{
t2=((C_word*)t0)[3];
f_6707(2,t2,C_SCHEME_UNDEFINED);}}

/* k6705 in k6702 in a6699 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6714,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6716,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   with-input-from-file */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[5],t3);}

/* a6715 in k6705 in k6702 in a6699 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6716,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6722,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6730,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6763,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[328]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t1,t6,t7,t8);}

/* a6762 in a6715 in k6705 in k6702 in a6699 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6763,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[355]));
t3=C_mutate((C_word*)lf[355]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[0]));}

/* a6729 in a6715 in k6705 in k6702 in a6699 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6738,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   read */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6736 in a6729 in a6715 in k6705 in k6702 in a6699 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6738,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6740,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6740(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* do44 in k6736 in a6729 in a6715 in k6705 in k6702 in a6699 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_6740(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6740,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eofp(t2))){
/* chicken.scm: 71   reverse */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6757,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   read */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k6755 in do44 in k6736 in a6729 in a6715 in k6705 in k6702 in a6699 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6757,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_6740(t3,((C_word*)t0)[2],t1,t2);}

/* a6721 in a6715 in k6705 in k6702 in a6699 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6722,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[355]));
t3=C_mutate((C_word*)lf[355]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[0]));}

/* k6712 in k6705 in k6702 in a6699 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6714,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[68],t1));}

/* k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_759,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_762,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6640,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[352],t3);}

/* a6639 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6640(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_6640r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6640r(t0,t1,t2,t3);}}

static void C_ccall f_6640r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6644,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t3);
if(C_truep(t5)){
t6=(C_word)C_a_i_list(&a,2,lf[61],lf[351]);
t7=t4;
f_6644(t7,(C_word)C_a_i_list(&a,2,lf[278],t6));}
else{
t6=t4;
f_6644(t6,(C_word)C_slot(t3,C_fix(0)));}}

/* k6642 in a6639 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_6644(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6644,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[111],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,lf[3]);
t4=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=(C_word)C_fixnum_greaterp(t5,C_fix(1));
t7=(C_truep(t6)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t4,t7);
t9=(C_word)C_a_i_cons(&a,2,t1,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[279],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[72],t2,t3,t10));}

/* k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_765,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6581,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[350],t3);}

/* a6580 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6581(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_6581r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6581r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6581r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6585,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   gensym */
t6=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k6583 in a6580 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[54],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6585,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t5=(C_word)C_a_i_list(&a,2,lf[111],t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6612,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t7=t6;
f_6612(t7,((C_word*)t0)[2]);}
else{
t7=(C_word)C_a_i_list(&a,2,lf[61],lf[349]);
t8=(C_word)C_a_i_list(&a,2,lf[278],t7);
t9=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t10=t6;
f_6612(t10,(C_word)C_a_i_list(&a,3,t8,t1,t9));}}

/* k6610 in k6583 in a6580 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_6612(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6612,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[347],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[348],t2);
t4=(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[5],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t4));}

/* k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_768,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[6]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6407,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t5=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[345],t4);}

/* a6406 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6407(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_6407r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6407r(t0,t1,t2,t3);}}

static void C_ccall f_6407r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6411,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t5=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[345],t2,lf[346]);}

/* k6409 in a6406 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6414,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[76]+1),((C_word*)t0)[3]);}

/* k6412 in k6409 in a6406 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6417,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6575,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a6574 in k6412 in k6409 in a6406 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6575(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6575,3,t0,t1,t2);}
/* chicken.scm: 71   gensym */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k6415 in k6412 in k6409 in a6406 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6417,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6420,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6569,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a6568 in k6415 in k6412 in k6409 in a6406 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6569(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6569,3,t0,t1,t2);}
/* chicken.scm: 71   gensym */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k6418 in k6415 in k6412 in k6409 in a6406 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6427,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6531,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6567,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[291]+1),((C_word*)t0)[2]);}

/* k6565 in k6418 in k6415 in k6412 in k6409 in a6406 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   map */
t2=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[330]+1),((C_word*)t0)[2],t1);}

/* k6529 in k6418 in k6415 in k6412 in k6409 in a6406 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6535,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6539,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(((C_word*)t0)[2]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6545,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_6545(t8,t3,t4);}

/* loop in k6529 in k6418 in k6415 in k6412 in k6409 in a6406 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_6545(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6545,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6559,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
/* chicken.scm: 71   loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k6557 in loop in k6529 in k6418 in k6415 in k6412 in k6409 in a6406 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6559,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1));}

/* k6537 in k6529 in k6418 in k6415 in k6412 in k6409 in a6406 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   map */
t2=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[330]+1),((C_word*)t0)[2],t1);}

/* k6533 in k6529 in k6418 in k6415 in k6412 in k6409 in a6406 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6425 in k6418 in k6415 in k6412 in k6409 in a6406 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6495,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6499,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6523,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   map */
t5=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* a6522 in k6425 in k6418 in k6415 in k6412 in k6409 in a6406 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6523(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6523,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t2,t3));}

/* k6497 in k6425 in k6418 in k6415 in k6412 in k6409 in a6406 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6503,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6507,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6517,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   map */
t5=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6516 in k6497 in k6425 in k6418 in k6415 in k6412 in k6409 in a6406 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6517,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t2,t3));}

/* k6505 in k6497 in k6425 in k6418 in k6415 in k6412 in k6409 in a6406 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6507,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[344]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k6501 in k6497 in k6425 in k6418 in k6415 in k6412 in k6409 in a6406 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6493 in k6425 in k6418 in k6415 in k6412 in k6409 in a6406 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6495,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[2],t2);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,lf[2],t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6451,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6455,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6479,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   map */
t9=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,t8,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a6478 in k6493 in k6425 in k6418 in k6415 in k6412 in k6409 in a6406 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6479(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6479,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t2,t3));}

/* k6453 in k6493 in k6425 in k6418 in k6415 in k6412 in k6409 in a6406 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6459,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6463,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6473,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   map */
t5=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6472 in k6453 in k6493 in k6425 in k6418 in k6415 in k6412 in k6409 in a6406 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6473(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6473,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t2,t3));}

/* k6461 in k6453 in k6493 in k6425 in k6418 in k6415 in k6412 in k6409 in a6406 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6463,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[344]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k6457 in k6453 in k6493 in k6425 in k6418 in k6415 in k6412 in k6409 in a6406 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6449 in k6493 in k6425 in k6418 in k6415 in k6412 in k6409 in a6406 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6451,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[2],t2);
t4=(C_word)C_a_i_list(&a,4,lf[328],((C_word*)t0)[5],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t4));}

/* k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_768,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_771,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6312,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[343],t3);}

/* a6311 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6312(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr3r,(void*)f_6312r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6312r(t0,t1,t2,t3);}}

static void C_ccall f_6312r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(24);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(C_word)C_a_i_cons(&a,2,lf[68],t3);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6319,a[2]=t5,a[3]=t10,a[4]=t1,a[5]=t9,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6348,a[2]=t7,a[3]=t9,a[4]=t5,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_6348(t15,t11,t2);}

/* loop in a6311 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_6348(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6348,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6361,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(t3,lf[147]);
if(C_truep(t5)){
t6=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t7=t4;
f_6361(2,t7,t6);}
else{
t6=(C_word)C_eqp(t3,lf[338]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t3,lf[339]));
if(C_truep(t7)){
t8=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t9=t4;
f_6361(2,t9,t8);}
else{
t8=(C_word)C_eqp(t3,lf[340]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[341]));
if(C_truep(t9)){
t10=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t11=t4;
f_6361(2,t11,t10);}
else{
t10=(C_word)C_slot(t2,C_fix(0));
/* chicken.scm: 71   ##sys#error */
t11=*((C_word*)lf[279]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t4,lf[342],t10);}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6359 in loop in a6311 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* chicken.scm: 71   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6348(t3,((C_word*)t0)[2],t2);}

/* k6317 in a6311 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6319,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[333],C_retrieve(lf[55])))){
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?((C_word*)((C_word*)t0)[5])[1]:C_SCHEME_FALSE);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_a_i_list(&a,2,lf[334],((C_word*)t0)[3]):(C_truep(((C_word*)((C_word*)t0)[6])[1])?(C_word)C_a_i_list(&a,2,lf[335],((C_word*)t0)[3]):(C_truep(((C_word*)((C_word*)t0)[5])[1])?((C_word*)t0)[3]:lf[336]))));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)((C_word*)t0)[2])[1])?((C_word*)t0)[3]:lf[337]));}}

/* k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_774,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[76]+1);
t4=*((C_word*)lf[291]+1);
t5=*((C_word*)lf[1]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6202,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t7=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[331],t6);}

/* a6201 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6202(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_6202r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6202r(t0,t1,t2,t3);}}

static void C_ccall f_6202r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6206,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t5=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[331],t2,lf[332]);}

/* k6204 in a6201 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6206,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6209,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6207 in k6204 in a6201 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6209,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6212,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   ##sys#map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k6210 in k6207 in k6204 in a6201 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6215,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   ##sys#map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6213 in k6210 in k6207 in k6204 in a6201 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6215,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6218,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6306,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a6305 in k6213 in k6210 in k6207 in k6204 in a6201 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6306(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6306,3,t0,t1,t2);}
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k6216 in k6213 in k6210 in k6207 in k6204 in a6201 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6221,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6300,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a6299 in k6216 in k6213 in k6210 in k6207 in k6204 in a6201 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6300(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6300,3,t0,t1,t2);}
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k6219 in k6216 in k6213 in k6210 in k6207 in k6204 in a6201 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6228,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6294,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   map */
t4=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[330]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k6292 in k6219 in k6216 in k6213 in k6210 in k6207 in k6204 in a6201 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6298,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   map */
t3=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[330]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6296 in k6292 in k6219 in k6216 in k6213 in k6210 in k6207 in k6204 in a6201 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6226 in k6219 in k6216 in k6213 in k6210 in k6207 in k6204 in a6201 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6264,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6266,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   map */
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6265 in k6226 in k6219 in k6216 in k6213 in k6210 in k6207 in k6204 in a6201 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[39],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6266,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t2);
t5=(C_word)C_a_i_list(&a,2,lf[329],t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_list(&a,2,t2,t3);
t8=(C_word)C_a_i_list(&a,3,lf[5],t3,lf[329]);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_list(&a,4,lf[79],t6,t7,t8));}

/* k6262 in k6226 in k6219 in k6216 in k6213 in k6210 in k6207 in k6204 in a6201 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6264,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[2],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t7=(C_word)C_a_i_cons(&a,2,lf[2],t6);
t8=(C_word)C_a_i_list(&a,4,lf[328],((C_word*)t0)[5],t7,((C_word*)t0)[5]);
t9=(C_word)C_a_i_list(&a,3,lf[79],t5,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t9));}

/* k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_777,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6192,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[327],t3);}

/* a6191 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6192(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_6192r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6192r(t0,t1,t2,t3);}}

static void C_ccall f_6192r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(12);
t4=(C_word)C_a_i_cons(&a,2,lf[68],t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[72],t2,t4));}

/* k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_780,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6178,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[326],t3);}

/* a6177 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6178(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr3r,(void*)f_6178r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6178r(t0,t1,t2,t3);}}

static void C_ccall f_6178r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(18);
t4=(C_word)C_a_i_list(&a,1,lf[3]);
t5=(C_word)C_a_i_cons(&a,2,lf[68],t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,4,lf[72],t2,t4,t5));}

/* k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_780,2,t0,t1);}
t2=*((C_word*)lf[1]+1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_781,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_854,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t5=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[325],t3);}

/* k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_857,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t3=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[324],((C_word*)t0)[2]);}

/* k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_860,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5845,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5876,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5916,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t10=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t2,lf[320],t9);}

/* a5843 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5916(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5916,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5920,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[320],t2,lf[323]);}

/* k5918 in a5843 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5920,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5929,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[76]+1),t2);}

/* k5927 in k5918 in a5843 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5929,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5932,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6138,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6138(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* loop in k5927 in k5918 in a5843 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_6138(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6138,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6151,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t4))){
/* chicken.scm: 71   append */
t6=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t4))){
/* chicken.scm: 71   append* */
t6=((C_word*)((C_word*)t0)[2])[1];
f_5845(t6,t5,t4,t3);}
else{
t6=t5;
f_6151(2,t6,(C_word)C_a_i_cons(&a,2,t4,t3));}}}}

/* k6149 in loop in k5927 in k5918 in a5843 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 71   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6138(t3,((C_word*)t0)[2],t2,t1);}

/* k5930 in k5927 in k5918 in a5843 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5932,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6128,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a6127 in k5930 in k5927 in k5918 in a5843 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6128(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6128,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6136,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   gensym */
t4=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6134 in a6127 in k5930 in k5927 in k5918 in a5843 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6136,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5933 in k5930 in k5927 in k5918 in a5843 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5936,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5947,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6082,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_6082(t7,t3,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}

/* loop in k5933 in k5930 in k5927 in k5918 in a5843 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_6082(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6082,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* chicken.scm: 71   reverse */
t4=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6098,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6122,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   map* */
t7=((C_word*)((C_word*)t0)[3])[1];
f_5876(t7,t6,((C_word*)t0)[2],t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6115,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   lookup */
t7=((C_word*)t0)[2];
f_5936(3,t7,t6,t4);}}}

/* k6113 in loop in k5933 in k5930 in k5927 in k5918 in a5843 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6115,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6098(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k6120 in loop in k5933 in k5930 in k5927 in k5918 in a5843 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6122,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6098(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k6096 in loop in k5933 in k5930 in k5927 in k5918 in a5843 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_6098(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 71   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6082(t3,((C_word*)t0)[2],t2,t1);}

/* k5945 in k5933 in k5930 in k5927 in k5918 in a5843 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5954,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6076,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a6075 in k5945 in k5933 in k5930 in k5927 in k5918 in a5843 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6076(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6076,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k5952 in k5945 in k5933 in k5930 in k5927 in k5918 in a5843 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5954,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5956,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_5956(t5,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* fold in k5952 in k5945 in k5933 in k5930 in k5927 in k5918 in a5843 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_5956(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5956,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5974,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5976,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* map */
t7=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5990,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(t4);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6070,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   cdar */
t8=*((C_word*)lf[218]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}
else{
t7=t5;
f_5990(t7,C_SCHEME_FALSE);}}}

/* k6068 in fold in k5952 in k5945 in k5933 in k5930 in k5927 in k5918 in a5843 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5990(t2,(C_word)C_i_nullp(t1));}

/* k5988 in fold in k5952 in k5945 in k5933 in k5930 in k5927 in k5918 in a5843 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_5990(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5990,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   caar */
t3=*((C_word*)lf[152]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6044,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[6]);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken.scm: 71   fold */
t9=((C_word*)((C_word*)t0)[2])[1];
f_5956(t9,t5,t6,t7,t8);}}

/* k6042 in k5988 in fold in k5952 in k5945 in k5933 in k5930 in k5927 in k5918 in a5843 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6044,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[4],((C_word*)t0)[2],t2));}

/* k6019 in k5988 in fold in k5952 in k5945 in k5933 in k5930 in k5927 in k5918 in a5843 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6021,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6001,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[6]);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken.scm: 71   fold */
t9=((C_word*)((C_word*)t0)[2])[1];
f_5956(t9,t5,t6,t7,t8);}

/* k5999 in k6019 in k5988 in fold in k5952 in k5945 in k5933 in k5930 in k5927 in k5918 in a5843 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_6001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6001,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* a5975 in fold in k5952 in k5945 in k5933 in k5930 in k5927 in k5918 in a5843 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5976(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5976,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5984,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   lookup */
t4=((C_word*)t0)[2];
f_5936(3,t4,t3,t2);}

/* k5982 in a5975 in fold in k5952 in k5945 in k5933 in k5930 in k5927 in k5918 in a5843 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5984,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k5972 in fold in k5952 in k5945 in k5933 in k5930 in k5927 in k5918 in a5843 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5974,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[79],t2));}

/* lookup in k5933 in k5930 in k5927 in k5918 in a5843 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5936(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5936,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* map* in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_5876(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5876,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5899,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* chicken.scm: 71   proc */
t6=t2;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
/* chicken.scm: 71   proc */
t4=t2;
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}}}

/* k5897 in map* in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5903,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 71   map* */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5876(t4,t2,((C_word*)t0)[2],t3);}

/* k5901 in k5897 in map* in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5903,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* append* in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_5845(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5845,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5866,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* chicken.scm: 71   append* */
t8=t5;
t9=t6;
t10=t3;
t1=t8;
t2=t9;
t3=t10;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}}

/* k5864 in append* in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5866,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_863,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5794,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[321],t3);}

/* a5793 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5794(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5794,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5798,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[321],t2,lf[322]);}

/* k5796 in a5793 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5798,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5809,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5809(t7,((C_word*)t0)[2],t2);}

/* fold in k5796 in a5793 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_5809(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5809,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[79],t3));}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5834,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* chicken.scm: 71   fold */
t9=t5;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}

/* k5832 in fold in k5796 in a5793 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5834,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[320],((C_word*)t0)[2],t1));}

/* k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_866,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5674,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[318],t3);}

/* a5673 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5674(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5674,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5678,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[318],t2,lf[319]);}

/* k5676 in a5673 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5678,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5687,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5786,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5788,tmp=(C_word)a,a+=2,tmp);
/* map */
t7=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a5787 in k5676 in a5673 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5788(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5788,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k5784 in k5676 in a5673 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[85]+1),t1);}

/* k5685 in k5676 in a5673 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5687,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5690,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5774,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a5773 in k5685 in k5676 in a5673 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5774(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5774,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5782,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   gensym */
t4=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5780 in a5773 in k5685 in k5676 in a5673 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5782,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5688 in k5685 in k5676 in a5673 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5691,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5710,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5768,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a5767 in k5688 in k5685 in k5676 in a5673 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5768(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5768,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,lf[317]));}

/* k5708 in k5688 in k5685 in k5676 in a5673 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5710,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5714,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5718,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5720,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a5719 in k5708 in k5688 in k5685 in k5676 in a5673 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5720(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5720,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5740,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t2);
/* map */
t7=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}

/* k5738 in a5719 in k5708 in k5688 in k5685 in k5676 in a5673 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5740,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5744,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5746,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[2]);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a5745 in k5738 in a5719 in k5708 in k5688 in k5685 in k5676 in a5673 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5746(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5746,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5754,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   lookup */
t4=((C_word*)t0)[2];
f_5691(3,t4,t3,t2);}

/* k5752 in a5745 in k5738 in a5719 in k5708 in k5688 in k5685 in k5676 in a5673 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5754,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[5],((C_word*)t0)[2],t1));}

/* k5742 in k5738 in a5719 in k5708 in k5688 in k5685 in k5676 in a5673 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5744,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[2],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[4],((C_word*)t0)[2],t3));}

/* k5716 in k5708 in k5688 in k5685 in k5676 in a5673 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5712 in k5708 in k5688 in k5685 in k5676 in a5673 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5714,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[79],t2));}

/* lookup in k5688 in k5685 in k5676 in a5673 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5691(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5691,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_869,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5653,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[316],t3);}

/* a5652 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5653(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5653,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5657,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   gensym */
t5=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k5655 in a5652 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5657,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,3,lf[315],t1,((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,3,lf[2],t1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[4],t2,t4));}

/* k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_948,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5643,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[312],t3);}

/* a5642 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5643(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5643,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_875,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[312],t2,lf[314]);}

/* k873 in a5642 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_875,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_884,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(((C_word*)t0)[3]);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=t5;
f_884(t9,(C_word)C_a_i_cons(&a,2,lf[2],t8));}
else{
t6=t5;
f_884(t6,(C_word)C_i_cadr(((C_word*)t0)[3]));}}

/* k882 in k873 in a5642 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_884(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_884,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_887,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_pairp(t1);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_900,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_900(t6,t4);}
else{
t6=(C_word)C_i_car(t1);
t7=(C_word)C_eqp(lf[2],t6);
t8=t5;
f_900(t8,(C_word)C_i_not(t7));}}

/* k898 in k882 in k873 in a5642 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_900(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken.scm: 71   syntax-error */
t2=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[312],lf[313],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_887(2,t2,C_SCHEME_UNDEFINED);}}

/* k885 in k882 in k873 in a5642 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_887,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[311],t3));}

/* k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_951,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5622,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[309],t3);}

/* a5621 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5622(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5622,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5626,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[309],t2,lf[310]);}

/* k5624 in a5621 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5626,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[308],t3,t4));}

/* k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_954,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5506,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[306],t3);}

/* a5505 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5506(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5506,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5510,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[306],t2,lf[307]);}

/* k5508 in a5505 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5510,2,t0,t1);}
t2=(C_word)C_i_listp(((C_word*)t0)[3]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5519,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_5519(t5,t3);}
else{
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=t4;
f_5519(t6,(C_word)C_fixnum_lessp(t5,C_fix(2)));}}

/* k5517 in k5508 in a5505 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_5519(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5519,NULL,2,t0,t1);}
if(C_truep(t1)){
/* chicken.scm: 71   ##sys#syntax-error-hook */
t2=C_retrieve(lf[304]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[305],((C_word*)t0)[2]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[2],C_fix(0));
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5533,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5533(t7,((C_word*)t0)[3],t2);}}

/* fold in k5517 in k5508 in a5505 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_5533(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(25);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5533,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[68],((C_word*)t0)[3]));}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_not_pair_p(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5562,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   fold */
t15=t5;
t16=t4;
t1=t15;
t2=t16;
goto loop;}
else{
t5=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t5))){
t6=(C_word)C_slot(t3,C_fix(0));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5579,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   fold */
t15=t7;
t16=t4;
t1=t15;
t2=t16;
goto loop;}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_i_cadr(t3);
t8=(C_word)C_a_i_list(&a,2,t6,t7);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5597,a[2]=t9,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   fold */
t15=t10;
t16=t4;
t1=t15;
t2=t16;
goto loop;}}}}

/* k5595 in fold in k5517 in k5508 in a5505 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5597,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[4],t1,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t2));}

/* k5577 in fold in k5517 in k5508 in a5505 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5579,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[2],t1,C_SCHEME_FALSE));}

/* k5560 in fold in k5517 in k5508 in a5505 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5562,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[2],t1,C_SCHEME_FALSE));}

/* k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_957,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[6]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5407,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t5=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[301],t4);}

/* a5406 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5407(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5407,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5417,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   gensym */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k5415 in a5406 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5417,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5428,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5430,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_5430(t8,t4,((C_word*)t0)[2]);}

/* expand in k5415 in a5406 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_5430(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5430,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5446,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[301],t3,lf[302]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[303]);}}

/* k5444 in expand in k5415 in a5406 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5446,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[86],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[68],t4));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5482,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5484,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[6]);
/* map */
t7=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}}

/* a5483 in k5444 in expand in k5415 in a5406 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5484(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5484,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[296],((C_word*)t0)[2],t2));}

/* k5480 in k5444 in expand in k5415 in a5406 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5482,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[300],t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,lf[68],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5474,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   expand */
t6=((C_word*)((C_word*)t0)[3])[1];
f_5430(t6,t5,((C_word*)t0)[2]);}

/* k5472 in k5480 in k5444 in expand in k5415 in a5406 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5474,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k5426 in k5415 in a5406 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5428,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_960,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[6]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5318,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t5=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[297],t4);}

/* a5317 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5318(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5318,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5328,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   gensym */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k5326 in a5317 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5328,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5339,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5341,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_5341(t8,t4,((C_word*)t0)[2]);}

/* expand in k5326 in a5317 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_5341(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5341,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5357,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[297],t3,lf[298]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[299]);}}

/* k5355 in expand in k5326 in a5317 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5357,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[86],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[68],t4));}
else{
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,3,lf[296],((C_word*)t0)[4],t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_cons(&a,2,lf[68],t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5385,a[2]=t7,a[3]=t5,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   expand */
t9=((C_word*)((C_word*)t0)[3])[1];
f_5341(t9,t8,((C_word*)t0)[2]);}}

/* k5383 in k5355 in expand in k5326 in a5317 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5385,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k5337 in k5326 in a5317 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5339,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_963,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5032,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[293],t3);}

/* a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_5032r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5032r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5032r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5229,a[2]=t3,a[3]=t1,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[293],t3,lf[295]);}

/* k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5232,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[293],((C_word*)t0)[4],lf[294]);}

/* k5230 in k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5235,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[76]+1),((C_word*)t0)[2]);}

/* k5233 in k5230 in k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5236,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5251,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5308,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a5307 in k5233 in k5230 in k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5308(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5308,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5316,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   prefix-sym */
f_5236(t3,lf[292],t2);}

/* k5314 in a5307 in k5233 in k5230 in k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   gensym */
t2=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5249 in k5233 in k5230 in k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5251,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5254,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[291]+1),((C_word*)t0)[2]);}

/* k5252 in k5249 in k5233 in k5230 in k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5254,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5257,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[290]);}

/* k5255 in k5252 in k5249 in k5233 in k5230 in k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5260,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[289]);}

/* k5258 in k5255 in k5252 in k5249 in k5233 in k5230 in k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5260,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5263,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5298,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[8]);}

/* a5297 in k5258 in k5255 in k5252 in k5249 in k5233 in k5230 in k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5298(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5298,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5306,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   prefix-sym */
f_5236(t3,lf[288],t2);}

/* k5304 in a5297 in k5258 in k5255 in k5252 in k5249 in k5233 in k5230 in k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   gensym */
t2=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5261 in k5258 in k5255 in k5252 in k5249 in k5233 in k5230 in k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5263,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5266,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[5];
t5=t1;
t6=((C_word*)t0)[2];
t7=C_retrieve(lf[6]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5043,a[2]=t5,a[3]=t6,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   reverse */
t9=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t3);}

/* k5041 in k5261 in k5258 in k5255 in k5252 in k5249 in k5233 in k5230 in k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5047,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   reverse */
t3=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5045 in k5041 in k5261 in k5258 in k5255 in k5252 in k5249 in k5233 in k5230 in k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5051,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   reverse */
t3=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5049 in k5045 in k5041 in k5261 in k5258 in k5255 in k5252 in k5249 in k5233 in k5230 in k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5051,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5053,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_5053(t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* recur in k5049 in k5045 in k5041 in k5261 in k5258 in k5255 in k5252 in k5249 in k5233 in k5230 in k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_5053(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5053,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5098,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=t7,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* chicken.scm: 71   reverse */
t9=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t6);}}

/* k5096 in recur in k5049 in k5045 in k5041 in k5261 in k5258 in k5255 in k5252 in k5249 in k5233 in k5230 in k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5106,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5110,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   reverse */
t4=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5108 in k5096 in recur in k5049 in k5045 in k5041 in k5261 in k5258 in k5255 in k5252 in k5249 in k5233 in k5230 in k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5110,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k5104 in k5096 in recur in k5049 in k5045 in k5041 in k5261 in k5258 in k5255 in k5252 in k5249 in k5233 in k5230 in k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5106,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5074,a[2]=t4,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
t8=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 71   recur */
t9=((C_word*)((C_word*)t0)[3])[1];
f_5053(t9,t5,((C_word*)t0)[2],t6,t7,t8);}

/* k5072 in k5104 in k5096 in recur in k5049 in k5045 in k5041 in k5261 in k5258 in k5255 in k5252 in k5249 in k5233 in k5230 in k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5074,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5264 in k5261 in k5258 in k5255 in k5252 in k5249 in k5233 in k5230 in k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5266,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5269,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[9];
t7=C_retrieve(lf[6]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5126,a[2]=t9,a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_5126(t11,t2,t3,t4,C_SCHEME_END_OF_LIST);}

/* recur in k5264 in k5261 in k5258 in k5255 in k5252 in k5249 in k5233 in k5230 in k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_5126(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5126,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(C_word)C_a_i_list(&a,2,lf[74],((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,lf[111],t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5160,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   reverse */
t8=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_list(&a,2,lf[74],((C_word*)t0)[4]);
t7=(C_word)C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5226,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t6,a[7]=t1,a[8]=t5,a[9]=((C_word*)t0)[4],a[10]=t7,tmp=(C_word)a,a+=11,tmp);
/* chicken.scm: 71   reverse */
t9=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t4);}}

/* k5224 in recur in k5264 in k5261 in k5258 in k5255 in k5252 in k5249 in k5233 in k5230 in k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5226,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_list(&a,2,lf[76],((C_word*)t0)[9]);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_list(&a,2,lf[75],((C_word*)t0)[9]);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],t5);
t7=(C_word)C_a_i_list(&a,2,t4,t6);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5190,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[3]);
/* chicken.scm: 71   recur */
t12=((C_word*)((C_word*)t0)[2])[1];
f_5126(t12,t8,t9,t10,t11);}

/* k5188 in k5224 in recur in k5264 in k5261 in k5258 in k5255 in k5252 in k5249 in k5233 in k5230 in k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5190,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k5158 in recur in k5264 in k5261 in k5258 in k5255 in k5252 in k5249 in k5233 in k5230 in k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5160,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,2,lf[61],lf[287]);
t4=(C_word)C_a_i_list(&a,2,lf[278],t3);
t5=(C_word)C_a_i_list(&a,3,lf[279],t4,((C_word*)t0)[4]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[2],t2,t5));}

/* k5267 in k5264 in k5261 in k5258 in k5255 in k5252 in k5249 in k5233 in k5230 in k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5269,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,lf[2],t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,3,lf[286],t7,t1));}

/* prefix-sym in k5233 in k5230 in k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_5236(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5236,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5244,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5248,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   symbol->string */
t6=*((C_word*)lf[166]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}

/* k5246 in prefix-sym in k5233 in k5230 in k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   string-append */
t2=*((C_word*)lf[141]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5242 in prefix-sym in k5233 in k5230 in k5227 in a5031 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_5244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_966,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4975,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[283],t3);}

/* a4974 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4975(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4975,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4979,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   gensym */
t5=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k4977 in a4974 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[93],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4979,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,lf[74],t1);
t5=(C_word)C_a_i_list(&a,2,lf[75],t1);
t6=(C_word)C_a_i_list(&a,2,lf[74],t5);
t7=(C_word)C_a_i_list(&a,2,lf[111],t6);
t8=(C_word)C_a_i_list(&a,2,lf[76],t1);
t9=(C_word)C_a_i_list(&a,2,lf[61],lf[285]);
t10=(C_word)C_a_i_list(&a,2,lf[278],t9);
t11=(C_word)C_a_i_list(&a,3,lf[279],t10,t1);
t12=(C_word)C_a_i_list(&a,4,lf[72],t7,t8,t11);
t13=(C_word)C_a_i_list(&a,4,lf[72],t4,((C_word*)t0)[3],t12);
t14=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,3,lf[79],t3,t13));}

/* k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_969,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4969,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[284],t3);}

/* a4968 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4969(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4969,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[283],t2));}

/* k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_972,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4816,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[280],t3);}

/* a4815 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4816(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4816r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4816r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4816r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4820,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[280],t3,lf[282]);}

/* k4818 in a4815 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4823,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[280],((C_word*)t0)[3],lf[281]);}

/* k4821 in k4818 in a4815 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4823,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4826,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4824 in k4821 in k4818 in a4815 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4826,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4837,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4839,a[2]=t6,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4839(t8,t4,t1,((C_word*)t0)[2]);}

/* loop in k4824 in k4821 in k4818 in a4815 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_4839(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4839,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_a_i_list(&a,2,lf[74],t2);
t5=(C_word)C_a_i_list(&a,2,lf[111],t4);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,lf[79],t6);
t8=(C_word)C_a_i_list(&a,2,lf[61],lf[277]);
t9=(C_word)C_a_i_list(&a,2,lf[278],t8);
t10=(C_word)C_a_i_list(&a,3,lf[279],t9,t2);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[72],t5,t7,t10));}
else{
t4=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4889,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   gensym */
t6=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=(C_word)C_a_i_list(&a,2,t4,t2);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[3]);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[79],t7));}}}

/* k4887 in loop in k4824 in k4821 in k4818 in a4815 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[76],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4889,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,lf[74],((C_word*)t0)[5]);
t4=(C_word)C_i_cadr(((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,2,lf[76],((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,4,lf[72],t3,t4,t5);
t7=(C_word)C_a_i_list(&a,2,t2,t6);
t8=(C_word)C_a_i_list(&a,2,lf[74],((C_word*)t0)[5]);
t9=(C_word)C_a_i_list(&a,2,lf[61],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_list(&a,2,lf[75],((C_word*)t0)[5]);
t11=(C_word)C_a_i_list(&a,4,lf[72],t8,t9,t10);
t12=(C_word)C_a_i_list(&a,2,t1,t11);
t13=(C_word)C_a_i_list(&a,2,t7,t12);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4900,a[2]=t13,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken.scm: 71   loop */
t16=((C_word*)((C_word*)t0)[2])[1];
f_4839(t16,t14,t1,t15);}

/* k4898 in k4887 in loop in k4824 in k4821 in k4818 in a4815 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4900,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k4835 in k4824 in k4821 in k4818 in a4815 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4837,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_975,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4540,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[269],t3);}

/* a4539 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4540(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4540,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4574,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[269],t2,lf[276]);}

/* k4572 in a4539 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4577,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   require */
t3=C_retrieve(lf[274]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[275]);}

/* k4575 in k4572 in a4539 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4577,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4580,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4801,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4803,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a4802 in k4575 in k4572 in a4539 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4803(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4803,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4813,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#decompose-lambda-list */
t5=C_retrieve(lf[271]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a4812 in a4802 in k4575 in k4572 in a4539 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4813(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4813,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k4799 in k4575 in k4572 in a4539 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[273]+1),t1);}

/* k4578 in k4575 in k4572 in a4539 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4583,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=t1;
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4549,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4549(t7,t2,C_fix(0));}

/* loop in k4578 in k4575 in k4572 in a4539 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_4549(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4549,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4563,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   gensym */
t4=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k4561 in loop in k4578 in k4575 in k4572 in a4539 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4567,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* chicken.scm: 71   loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4549(t4,t2,t3);}

/* k4565 in k4561 in loop in k4578 in k4575 in k4572 in a4539 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4567,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4581 in k4578 in k4575 in k4572 in a4539 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4586,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4584 in k4581 in k4578 in k4575 in k4572 in a4539 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4589,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4587 in k4584 in k4581 in k4578 in k4575 in k4572 in a4539 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4596,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   append */
t3=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[6]);}

/* k4594 in k4587 in k4584 in k4581 in k4578 in k4575 in k4572 in a4539 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4596,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[265],((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4608,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4610,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   fold-right */
t7=C_retrieve(lf[161]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,t6,lf[272],((C_word*)t0)[2]);}

/* a4609 in k4594 in k4587 in k4584 in k4581 in k4578 in k4575 in k4572 in a4539 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4610,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4620,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   ##sys#decompose-lambda-list */
t6=C_retrieve(lf[271]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t4,t5);}

/* a4619 in a4609 in k4594 in k4587 in k4584 in k4581 in k4578 in k4575 in k4572 in a4539 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4620(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4620,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=((C_word*)t0)[7],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* chicken.scm: 71   ##sys#check-syntax */
t7=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,lf[269],t6,lf[270]);}

/* k4622 in a4619 in a4609 in k4594 in k4587 in k4584 in k4581 in k4578 in k4575 in k4572 in a4539 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4624,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[11],((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4634,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=(C_word)C_eqp(t2,C_fix(0));
t5=t3;
f_4634(t5,(C_truep(t4)?C_SCHEME_TRUE:(C_word)C_a_i_list(&a,3,lf[108],((C_word*)t0)[2],t2)));}
else{
t4=t3;
f_4634(t4,(C_word)C_a_i_list(&a,3,lf[268],((C_word*)t0)[2],t2));}}

/* k4632 in k4622 in a4619 in a4609 in k4594 in k4587 in k4584 in k4581 in k4578 in k4575 in k4572 in a4539 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_4634(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4634,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4638,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4640,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4650,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a4649 in k4632 in k4622 in a4619 in a4609 in k4594 in k4587 in k4584 in k4581 in k4578 in k4575 in k4572 in a4539 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4650(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4650,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4654,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4669,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4669(t8,t4,t3,((C_word*)t0)[2]);}

/* build in a4649 in k4632 in k4622 in a4619 in a4609 in k4594 in k4587 in k4584 in k4581 in k4578 in k4575 in k4572 in a4539 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_4669(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4669,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[4])){
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[79],t7));}
else{
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cadr(((C_word*)t0)[3]));}
else{
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[79],t6));}}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4725,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   gensym */
t5=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k4723 in build in a4649 in k4632 in k4622 in a4619 in a4609 in k4594 in k4587 in k4584 in k4581 in k4578 in k4575 in k4572 in a4539 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4725,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,lf[76],((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,2,lf[75],((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,t1,t5);
t7=(C_word)C_a_i_list(&a,2,t4,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4736,a[2]=t7,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken.scm: 71   build */
t11=((C_word*)((C_word*)t0)[2])[1];
f_4669(t11,t8,t10,t1);}
else{
/* chicken.scm: 71   build */
t10=((C_word*)((C_word*)t0)[2])[1];
f_4669(t10,t8,C_SCHEME_END_OF_LIST,t1);}}

/* k4734 in k4723 in build in a4649 in k4632 in k4622 in a4619 in a4609 in k4594 in k4587 in k4584 in k4581 in k4578 in k4575 in k4572 in a4539 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4736,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k4652 in a4649 in k4632 in k4622 in a4619 in a4609 in k4594 in k4587 in k4584 in k4581 in k4578 in k4575 in k4572 in a4539 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4654,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4667,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   map */
t3=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[71]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k4665 in k4652 in a4649 in k4632 in k4622 in a4619 in a4609 in k4594 in k4587 in k4584 in k4581 in k4578 in k4575 in k4572 in a4539 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4667,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],t1,((C_word*)t0)[2]));}

/* a4639 in k4632 in k4622 in a4619 in a4609 in k4594 in k4587 in k4584 in k4581 in k4578 in k4575 in k4572 in a4539 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4648,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   take */
t3=C_retrieve(lf[267]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4646 in a4639 in k4632 in k4622 in a4619 in a4609 in k4594 in k4587 in k4584 in k4581 in k4578 in k4575 in k4572 in a4539 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   split-at! */
t2=C_retrieve(lf[266]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4636 in k4632 in k4622 in a4619 in a4609 in k4594 in k4587 in k4584 in k4581 in k4578 in k4575 in k4572 in a4539 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4638,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[3],t1,((C_word*)t0)[2]));}

/* k4606 in k4594 in k4587 in k4584 in k4581 in k4578 in k4575 in k4572 in a4539 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4608,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[2],t2));}

/* k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_978,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4483,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[262],t3);}

/* a4482 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4483(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr3r,(void*)f_4483r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4483r(t0,t1,t2,t3);}}

static void C_ccall f_4483r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(16);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4493,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* chicken.scm: 71   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,lf[262],t5,lf[263]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4523,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* chicken.scm: 71   ##sys#check-syntax */
t6=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,lf[262],t5,lf[264]);}}

/* k4521 in a4482 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4523,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[261],t3));}

/* k4491 in a4482 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4493,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(0));
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=(C_word)C_a_i_cons(&a,2,lf[2],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[261],t3,t6));}

/* k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_981,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4407,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[254],t3);}

/* a4406 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4407(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4407r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4407r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4407r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4411,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   gensym */
t6=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k4409 in a4406 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4414,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4412 in k4409 in a4406 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[114],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4414,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_list(&a,3,lf[2],t3,t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t8=(C_word)C_a_i_cons(&a,2,lf[2],t7);
t9=(C_word)C_a_i_list(&a,3,lf[257],lf[258],t1);
t10=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t9);
t11=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t10);
t12=(C_word)C_a_i_list(&a,3,lf[2],t1,t11);
t13=(C_word)C_a_i_list(&a,3,lf[4],t8,t12);
t14=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t13);
t15=(C_word)C_a_i_list(&a,3,lf[259],t6,t14);
t16=(C_word)C_a_i_list(&a,3,lf[2],t2,t15);
t17=(C_word)C_a_i_list(&a,2,lf[260],t16);
t18=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_list(&a,1,t17));}

/* k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_984,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4223,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[256],t3);}

/* a4222 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4223(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4223r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4223r(t0,t1,t2,t3);}}

static void C_ccall f_4223r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4227,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   gensym */
t5=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k4225 in a4222 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4227,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4230,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4228 in k4225 in a4222 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4230,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4232,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,2,lf[61],lf[252]);
t4=(C_word)C_a_i_list(&a,3,lf[242],((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_list(&a,3,lf[253],((C_word*)t0)[5],C_fix(1));
t6=(C_word)C_a_i_list(&a,3,lf[110],t4,t5);
t7=(C_word)C_a_i_list(&a,2,t1,t6);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4369,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4373,a[2]=t9,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t11=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,t2,((C_word*)t0)[2]);}

/* k4371 in k4228 in k4225 in a4222 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4373,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[255],((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[86],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* ##sys#append */
t5=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k4367 in k4228 in k4225 in a4222 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4369,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[83],t1);
t3=(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[5],t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,4,lf[254],((C_word*)t0)[3],t3,((C_word*)t0)[2]));}

/* parse-clause in k4228 in k4225 in a4222 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4232(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[34],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4232,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_symbolp(t3);
t5=(C_truep(t4)?(C_word)C_i_car(t2):C_SCHEME_FALSE);
t6=(C_truep(t5)?(C_word)C_i_cadr(t2):(C_word)C_i_car(t2));
t7=(C_truep(t5)?(C_word)C_i_cddr(t2):(C_word)C_i_cdr(t2));
if(C_truep((C_word)C_i_nullp(t6))){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4255,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t5)){
t9=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[3]);
t10=(C_word)C_a_i_list(&a,1,t9);
t11=(C_word)C_a_i_cons(&a,2,t10,t7);
t12=t8;
f_4255(t12,(C_word)C_a_i_cons(&a,2,lf[79],t11));}
else{
t9=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t7);
t10=t8;
f_4255(t10,(C_word)C_a_i_cons(&a,2,lf[79],t9));}}
else{
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4318,a[2]=t7,a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4320,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t10=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t9,t6);}}

/* a4319 in parse-clause in k4228 in k4225 in a4222 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4320(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4320,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[251],t3,((C_word*)t0)[2]));}

/* k4316 in parse-clause in k4228 in k4225 in a4222 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4318,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[110],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4288,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[2]);
t8=t4;
f_4288(t8,(C_word)C_a_i_cons(&a,2,lf[79],t7));}
else{
t5=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t6=t4;
f_4288(t6,(C_word)C_a_i_cons(&a,2,lf[79],t5));}}

/* k4286 in k4316 in parse-clause in k4228 in k4225 in a4222 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_4288(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4288,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k4253 in parse-clause in k4228 in k4225 in a4222 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_4255(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4255,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[86],t1));}

/* k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_987,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4033,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[250],t3);}

/* a4032 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4033(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_4033r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_4033r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_4033r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t6=(C_word)C_i_cdr(t3);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4040,a[2]=t6,a[3]=t5,a[4]=t1,a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* map */
t8=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,*((C_word*)lf[76]+1),t5);}

/* k4038 in a4032 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4040,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4212,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4214,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a4213 in k4038 in a4032 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4214(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4214,3,t0,t1,t2);}
t3=(C_word)C_i_memq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:lf[249]));}

/* k4210 in k4038 in a4032 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4212,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[240],t2);
t4=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],lf[241]);
t6=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t7=(C_word)C_a_i_list(&a,3,lf[242],lf[241],t6);
t8=(C_word)C_a_i_list(&a,3,lf[82],t5,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4063,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4065,a[2]=t11,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t13=((C_word*)t11)[1];
f_4065(t13,t9,((C_word*)t0)[2],C_fix(1));}

/* loop in k4210 in k4038 in a4032 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_4065(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[112],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4065,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_memq(lf[243],C_retrieve(lf[55]));
t6=(C_word)C_i_cddr(t4);
t7=(C_word)C_i_pairp(t6);
t8=(C_word)C_a_i_list(&a,1,lf[241]);
t9=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[3]);
t10=(C_word)C_a_i_list(&a,3,lf[244],lf[241],t9);
t11=(C_word)C_a_i_list(&a,2,lf[111],t10);
t12=(C_word)C_a_i_list(&a,3,lf[245],lf[241],t3);
t13=(C_word)C_a_i_list(&a,4,lf[2],t8,t11,t12);
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4091,a[2]=t13,a[3]=t5,a[4]=t7,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,a[8]=t1,a[9]=t4,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t7)){
t15=(C_word)C_i_caddr(t4);
t16=(C_word)C_a_i_list(&a,3,t15,lf[241],lf[247]);
t17=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[3]);
t18=(C_word)C_a_i_list(&a,3,lf[244],lf[241],t17);
t19=(C_word)C_a_i_list(&a,2,lf[111],t18);
t20=(C_word)C_a_i_list(&a,4,lf[248],lf[241],t3,lf[247]);
t21=(C_word)C_a_i_list(&a,4,lf[82],t16,t19,t20);
t22=t14;
f_4091(t22,(C_word)C_a_i_list(&a,1,t21));}
else{
t15=t14;
f_4091(t15,C_SCHEME_END_OF_LIST);}}}

/* k4089 in loop in k4210 in k4038 in a4032 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_4091(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4091,NULL,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4119,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[3]:C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[9]);
t6=t3;
f_4119(t6,(C_word)C_a_i_list(&a,3,lf[246],((C_word*)t0)[2],t5));}
else{
t5=t3;
f_4119(t5,((C_word*)t0)[2]);}}

/* k4117 in k4089 in loop in k4210 in k4038 in a4032 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_4119(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4119,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4103,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* chicken.scm: 71   loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_4065(t6,t3,t4,t5);}

/* k4101 in k4117 in k4089 in loop in k4210 in k4038 in a4032 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4103,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* ##sys#append */
t3=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4061 in k4210 in k4038 in a4032 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4063,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[68],t3));}

/* k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_990,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4024,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[238],t3);}

/* a4023 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4024(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4024,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4028,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[238],t2,lf[239]);}

/* k4026 in a4023 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4028,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[237],((C_word*)t0)[2]));}

/* k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_993,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4005,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[235],t3);}

/* a4004 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4005(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4005,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4009,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[235],t2,lf[236]);}

/* k4007 in a4004 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4016,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4018,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4017 in k4007 in a4004 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4018(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4018,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k4014 in k4007 in a4004 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_4016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4016,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[232],t1));}

/* k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_996,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3986,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[233],t3);}

/* a3985 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3986(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3986,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3990,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[233],t2,lf[234]);}

/* k3988 in a3985 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3997,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3999,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3998 in k3988 in a3985 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3999(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3999,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3995 in k3988 in a3985 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3997,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[232],t1));}

/* k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_999,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3858,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[231],t3);}

/* a3857 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3858(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3858,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3864,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3864(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in a3857 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_3864(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(15);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3864,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3874,a[2]=t4,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   reverse */
t7=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t3);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[228]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3945,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 71   gensym */
t9=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t9))(2,t9,t8);}
else{
t8=(C_word)C_eqp(t6,lf[229]);
if(C_truep(t8)){
/* chicken.scm: 71   loop */
t15=t1;
t16=C_SCHEME_END_OF_LIST;
t17=t3;
t18=t4;
t19=C_SCHEME_TRUE;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
t5=t19;
goto loop;}
else{
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_car(t2);
t11=(C_word)C_a_i_cons(&a,2,t10,t4);
/* chicken.scm: 71   loop */
t15=t1;
t16=t9;
t17=t3;
t18=t11;
t19=C_SCHEME_FALSE;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
t5=t19;
goto loop;}}}}

/* k3943 in loop in a3857 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3945,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* chicken.scm: 71   loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3864(t5,((C_word*)t0)[2],t2,t3,t4,C_SCHEME_FALSE);}

/* k3872 in loop in a3857 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3877,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   reverse */
t3=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3875 in k3872 in loop in a3857 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3877,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_a_i_list(&a,2,lf[68],t2);
t4=(C_word)C_i_cdr(t1);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[2],t5));}}

/* k3881 in k3875 in k3872 in loop in a3857 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3890,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k3888 in k3881 in k3875 in k3872 in loop in a3857 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3890,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3906,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* ##sys#append */
t6=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k3904 in k3888 in k3881 in k3875 in k3872 in loop in a3857 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3906,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[227],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[2],t3));}

/* k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1002,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3715,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[230],t3);}

/* a3714 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3715(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3715,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3721,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3721(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in a3714 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_3721(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(22);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3721,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t2))){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3731,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   reverse */
t8=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_eqp(t7,lf[228]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3806,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   gensym */
t10=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t10))(2,t10,t9);}
else{
t9=(C_word)C_eqp(t7,lf[229]);
if(C_truep(t9)){
/* chicken.scm: 71   loop */
t14=t1;
t15=C_SCHEME_END_OF_LIST;
t16=t3;
t17=t4;
t18=t5;
t19=C_SCHEME_TRUE;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
t5=t18;
t6=t19;
goto loop;}
else{
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3833,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t4,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   gensym */
t11=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t11))(2,t11,t10);}}}}

/* k3831 in loop in a3714 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3833,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
t6=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* chicken.scm: 71   loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_3721(t7,((C_word*)t0)[3],t2,((C_word*)t0)[2],t5,t6,C_SCHEME_FALSE);}

/* k3804 in loop in a3714 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3806,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* chicken.scm: 71   loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3721(t5,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2],t4,C_SCHEME_FALSE);}

/* k3729 in loop in a3714 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3734,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   reverse */
t3=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3732 in k3729 in loop in a3714 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3734,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3740,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[2],t4);
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[3],t5));}}

/* k3738 in k3732 in k3729 in loop in a3714 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3740,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3751,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k3749 in k3738 in k3732 in k3729 in loop in a3714 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3751,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3767,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* ##sys#append */
t6=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k3765 in k3749 in k3738 in k3732 in k3729 in loop in a3714 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3767,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[227],t2);
t4=(C_word)C_a_i_list(&a,3,lf[2],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t4));}

/* k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1002,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1005,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3656,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[226],t3);}

/* a3655 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc_2(c,6,t0);
if(!C_demand(c*C_SIZEOF_PAIR+51)){
C_save_and_reclaim((void*)tr6r,(void*)f_3656r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_3656r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_3656r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(51);
t7=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_i_caddr(t2);
t9=(C_word)C_i_car(t2);
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_a_i_list(&a,3,t8,t9,t10);
t12=(C_word)C_a_i_list(&a,4,lf[223],t3,t4,t5);
t13=(C_word)C_a_i_cons(&a,2,t12,t6);
t14=(C_word)C_a_i_cons(&a,2,t11,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[224],t14));}
else{
t8=(C_word)C_a_i_list(&a,4,lf[225],t3,t4,t5);
t9=(C_word)C_a_i_cons(&a,2,t8,t6);
t10=(C_word)C_a_i_cons(&a,2,t2,t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[224],t10));}}

/* k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1008,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3485,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[220],t3);}

/* a3484 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3485(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_3485r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3485r(t0,t1,t2,t3);}}

static void C_ccall f_3485r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3491,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3491(t7,t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t3,C_SCHEME_FALSE);}

/* loop in a3484 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_3491(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3491,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t4))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3501,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=(C_word)C_a_i_cons(&a,2,lf[215],t5);
t8=t6;
f_3501(t8,(C_word)C_a_i_list(&a,2,lf[133],t7));}
else{
t7=t6;
f_3501(t7,lf[216]);}}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3565,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_i_car(t4);
t8=t6;
f_3565(t8,(C_word)C_i_pairp(t7));}
else{
t7=t6;
f_3565(t7,C_SCHEME_FALSE);}}}

/* k3563 in loop in a3484 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_3565(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3565,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   caar */
t3=*((C_word*)lf[152]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
/* chicken.scm: 71   syntax-error */
t2=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[220],lf[222],((C_word*)t0)[7]);}}

/* k3566 in k3563 in loop in a3484 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3568,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_eqp(lf[217],t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3592,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   cdar */
t5=*((C_word*)lf[218]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(lf[219],t1);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3613,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 71   cdar */
t6=*((C_word*)lf[218]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(lf[215],t1);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3626,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=((C_word*)t0)[2];
t8=(C_truep(t7)?t7:C_SCHEME_END_OF_LIST);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3634,a[2]=t8,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   cdar */
t10=*((C_word*)lf[218]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[7]);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3641,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   caar */
t7=*((C_word*)lf[152]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[7]);}}}}

/* k3639 in k3566 in k3563 in loop in a3484 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   syntax-error */
t2=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[220],lf[221],t1);}

/* k3632 in k3566 in k3563 in loop in a3484 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   append */
t2=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3624 in k3566 in k3563 in loop in a3484 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 71   loop */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3491(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3611 in k3566 in k3563 in loop in a3484 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3613,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[68],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* chicken.scm: 71   loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3491(t4,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3590 in k3566 in k3563 in loop in a3484 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3592,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[68],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* chicken.scm: 71   loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3491(t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3499 in loop in a3484 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_3501(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[63],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3501,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,lf[210],t2);
t4=(C_word)C_a_i_list(&a,2,lf[211],lf[54]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,lf[212],((C_word*)t0)[4]);
t7=(C_word)C_a_i_list(&a,2,lf[133],t6);
t8=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t9=(C_word)C_a_i_list(&a,2,lf[213],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)t0)[3]);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,t7,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[86],t12);
t14=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,4,lf[214],t3,t5,t13));}

/* k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1011,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3434,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[209],t3);}

/* a3433 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3434(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+39)){
C_save_and_reclaim((void*)tr3r,(void*)f_3434r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3434r(t0,t1,t2,t3);}}

static void C_ccall f_3434r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(39);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,t5,t3);
t7=(C_word)C_a_i_cons(&a,2,lf[2],t6);
t8=(C_word)C_a_i_list(&a,2,t4,t7);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(C_word)C_i_car(t2);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,3,lf[208],t9,t10));}
else{
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[208],t5,t2));}}

/* k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1014,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3374,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[206],t3);}

/* a3373 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3374(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_3374r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3374r(t0,t1,t2,t3);}}

static void C_ccall f_3374r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[203]:t3);
t6=(C_word)C_i_pairp(t2);
t7=(C_truep(t6)?(C_word)C_i_car(t2):t2);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3384,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,t5);
t11=t8;
f_3384(t11,(C_word)C_a_i_cons(&a,2,lf[2],t10));}
else{
t9=t8;
f_3384(t9,(C_word)C_i_car(t5));}}

/* k3382 in a3373 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_3384(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3384,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3387,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3403,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 71   eval */
t4=C_retrieve(lf[147]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}
else{
/* chicken.scm: 71   syntax-error */
t3=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[206],lf[207],((C_word*)t0)[2]);}}

/* k3401 in k3382 in a3373 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3387(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* k3385 in k3382 in a3373 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3387,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[204]))?(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[3],((C_word*)t0)[2]):lf[205]));}

/* k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1017,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 71   register-feature! */
t3=C_retrieve(lf[196]);
((C_proc8)C_retrieve_proc(t3))(8,t3,t2,lf[197],lf[198],lf[199],lf[200],lf[201],lf[202]);}

/* k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1020,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3337,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[84],t3);}

/* a3336 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3337(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3337,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3341,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[84],t2,lf[195]);}

/* k3339 in a3336 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3341,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,2,lf[61],t4);
t6=(C_word)C_i_cddr(((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,t3,t7);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[194],t8));}

/* k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1023,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3318,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[90],t3);}

/* a3317 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3318(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3318,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3322,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[90],t2,lf[193]);}

/* k3320 in a3317 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3329,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3331,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3330 in k3320 in a3317 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3331(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3331,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3327 in k3320 in a3317 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3329,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[164],t1));}

/* k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1026,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3299,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[191],t3);}

/* a3298 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3299(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3299,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3303,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[191],t2,lf[192]);}

/* k3301 in a3298 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3310,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3312,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3311 in k3301 in a3298 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3312(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3312,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3308 in k3301 in a3298 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3310,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[190],t1));}

/* k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1026,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1029,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3280,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[107],t3);}

/* a3279 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3280(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3280,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3284,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[107],t2,lf[189]);}

/* k3282 in a3279 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3284,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3291,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3293,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3292 in k3282 in a3279 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3293(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3293,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3289 in k3282 in a3279 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3291,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[188],t1));}

/* k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1032,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3261,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[186],t3);}

/* a3260 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3261(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3261,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3265,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[186],t2,lf[187]);}

/* k3263 in a3260 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3272,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3274,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3273 in k3263 in a3260 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3274(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3274,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3270 in k3263 in a3260 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3272,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[185],t1));}

/* k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1035,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3242,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[183],t3);}

/* a3241 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3242(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3242,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3246,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[183],t2,lf[184]);}

/* k3244 in a3241 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3253,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3255,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3254 in k3244 in a3241 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3255(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3255,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3251 in k3244 in a3241 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3253,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[182],t1));}

/* k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1038,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3223,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[180],t3);}

/* a3222 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3223(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3223,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3227,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[180],t2,lf[181]);}

/* k3225 in a3222 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3227,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3234,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3236,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3235 in k3225 in a3222 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3236(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3236,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}

/* k3232 in k3225 in a3222 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3234,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[179],t1));}

/* k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1041,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3123,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[174],t3);}

/* a3122 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3123(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3123,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3127,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[174],t2,lf[178]);}

/* k3125 in a3122 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3127,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_stringp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3136,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[174],((C_word*)t0)[3],lf[175]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3182,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t4=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[174],((C_word*)t0)[3],lf[177]);}}

/* k3180 in k3125 in a3122 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3182,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_a_i_list(&a,2,lf[61],lf[176]);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(C_word)C_a_i_list(&a,2,lf[61],t5);
t7=(C_word)C_i_caddr(((C_word*)t0)[3]);
t8=(C_word)C_a_i_list(&a,2,lf[61],t7);
t9=(C_word)C_i_cadddr(((C_word*)t0)[3]);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,6,lf[171],t3,t4,t6,t8,t9));}

/* k3134 in k3125 in a3122 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3136,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_i_caddr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,2,lf[61],t4);
t6=(C_word)C_i_car(((C_word*)t0)[3]);
t7=(C_word)C_a_i_list(&a,2,lf[61],t6);
t8=(C_word)C_i_cadddr(((C_word*)t0)[3]);
t9=(C_word)C_a_i_list(&a,2,lf[61],t8);
t10=(C_word)C_i_cdr(((C_word*)t0)[3]);
t11=(C_word)C_i_cadddr(t10);
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_list(&a,6,lf[171],t3,t5,t7,t9,t11));}

/* k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1044,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2903,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[168],t3);}

/* a2902 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2903(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2903,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2907,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=t3;
f_2907(t5,(C_word)C_i_stringp(t4));}
else{
t4=t3;
f_2907(t4,C_SCHEME_FALSE);}}

/* k2905 in a2902 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_2907(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2907,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2910,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=t1;
if(C_truep(t3)){
t4=t2;
f_2910(t4,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=t2;
f_2910(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t2;
f_2910(t4,C_SCHEME_FALSE);}}}

/* k2908 in k2905 in a2902 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_2910(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2910,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2916,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[168],((C_word*)t0)[4],lf[169]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2991,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* chicken.scm: 72   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[168],((C_word*)t0)[4],lf[172]);}
else{
/* chicken.scm: 72   ##sys#check-syntax */
t3=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[168],((C_word*)t0)[4],lf[173]);}}}

/* k2989 in k2908 in k2905 in a2902 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2991,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cadr(((C_word*)t0)[3]):(C_word)C_i_car(((C_word*)t0)[3]));
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_list(&a,2,lf[61],t5);
t7=(C_truep(((C_word*)t0)[4])?(C_word)C_i_car(((C_word*)t0)[3]):lf[170]);
t8=(C_word)C_a_i_list(&a,2,lf[61],t7);
t9=(C_truep(((C_word*)t0)[4])?(C_word)C_i_caddr(((C_word*)t0)[3]):(C_word)C_i_cadr(((C_word*)t0)[3]));
t10=(C_word)C_a_i_list(&a,2,lf[61],t9);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3056,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t10,a[6]=t8,a[7]=t6,a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[4],tmp=(C_word)a,a+=10,tmp);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3058,tmp=(C_word)a,a+=2,tmp);
/* map */
t13=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,t12,t3);}

/* a3057 in k2989 in k2908 in k2905 in a2902 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3058(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3058,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k3054 in k2989 in k2908 in k2905 in a2902 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3056,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3036,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3048,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a3047 in k3054 in k2989 in k2908 in k2905 in a2902 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3048(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3048,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k3034 in k3054 in k2989 in k2908 in k2905 in a2902 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_3036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3036,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[9])?(C_word)C_i_cdddr(((C_word*)t0)[8]):(C_word)C_i_cddr(((C_word*)t0)[8]));
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[2],t3);
t5=(C_word)C_a_i_list(&a,6,lf[171],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[2],t5));}

/* k2914 in k2908 in k2905 in a2902 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[68],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2916,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[61],t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,2,lf[61],t4);
t6=(C_word)C_a_i_list(&a,3,lf[164],t3,t5);
t7=(C_word)C_a_i_list(&a,2,lf[61],t2);
t8=(C_word)C_i_cadr(((C_word*)t0)[3]);
t9=(C_word)C_a_i_list(&a,2,lf[61],t8);
t10=(C_word)C_a_i_list(&a,2,lf[61],C_SCHEME_TRUE);
t11=(C_word)C_a_i_list(&a,4,lf[165],t7,t9,t10);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2942,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
t13=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t13))){
t14=(C_word)C_i_caddr(((C_word*)t0)[3]);
t15=(C_word)C_a_i_list(&a,3,lf[5],t2,t14);
t16=t12;
f_2942(t16,(C_word)C_a_i_list(&a,1,t15));}
else{
t14=t12;
f_2942(t14,C_SCHEME_END_OF_LIST);}}

/* k2940 in k2914 in k2908 in k2905 in a2902 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_2942(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2942,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[68],t3));}

/* k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1047,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2828,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[167],t3);}

/* a2827 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2828(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2828r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2828r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2828r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2832,a[2]=t4,a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 72   gensym */
t6=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k2830 in a2827 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2832,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* chicken.scm: 72   symbol->string */
t5=*((C_word*)lf[166]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}

/* k2899 in k2830 in a2827 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[74],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2901,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],t1);
t3=(C_word)C_a_i_list(&a,4,lf[164],((C_word*)t0)[8],((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,lf[61],C_SCHEME_FALSE);
t7=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t8=(C_word)C_a_i_list(&a,5,lf[165],t4,t5,t6,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2855,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[2]))){
t10=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t11=(C_word)C_a_i_list(&a,3,lf[5],((C_word*)t0)[6],t10);
t12=t9;
f_2855(t12,(C_word)C_a_i_list(&a,1,t11));}
else{
t10=t9;
f_2855(t10,C_SCHEME_END_OF_LIST);}}

/* k2853 in k2899 in k2830 in a2827 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_2855(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2855,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[68],t3));}

/* k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1050,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2722,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[163],t3);}

/* a2721 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2722(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_2722r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2722r(t0,t1,t2,t3);}}

static void C_ccall f_2722r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2726,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2822,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a2821 in a2721 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2822(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2822,3,t0,t1,t2);}
/* chicken.scm: 72   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k2724 in a2721 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2726,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2733,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2798,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   append-map */
t4=C_retrieve(lf[162]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],t1);}

/* a2797 in k2724 in a2721 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2798(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2798,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cddr(t2);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}}

/* k2731 in k2724 in a2721 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2737,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2739,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t5=(C_word)C_a_i_cons(&a,2,lf[79],t4);
/* chicken.scm: 72   fold-right */
t6=C_retrieve(lf[161]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t2,t3,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2738 in k2731 in k2724 in a2721 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2739(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[51],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2739,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t2);
t6=(C_word)C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_a_i_list(&a,2,lf[61],t7);
t9=(C_word)C_i_cadr(t2);
t10=(C_word)C_a_i_list(&a,2,lf[61],t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,5,lf[160],t8,t10,t3,t4));}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_a_i_list(&a,2,lf[61],t7);
t9=(C_word)C_i_cadr(t2);
t10=(C_word)C_a_i_list(&a,2,lf[61],t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[160],t8,t10,t4));}}

/* k2735 in k2731 in k2724 in a2721 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2737,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[2],t1));}

/* k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1050,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1053,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2693,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[159],t3);}

/* a2692 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2693(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2693,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2697,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   gensym */
t4=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[155]);}

/* k2695 in a2692 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2716,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2720,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   string-intersperse */
t4=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[158]);}

/* k2718 in k2695 in a2692 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   sprintf */
t2=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[157],((C_word*)t0)[2],t1);}

/* k2714 in k2695 in a2692 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2716,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[98],t1);
t3=(C_word)C_a_i_list(&a,2,lf[133],t2);
t4=(C_word)C_a_i_list(&a,2,lf[130],((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[68],t3,t4));}

/* k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1053,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1056,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2680,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[156],t3);}

/* a2679 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2680,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2684,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 72   gensym */
t5=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[155]);}

/* k2682 in a2679 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2684,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[90],t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[68],t2,t1));}

/* k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1059,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1886,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[112],t3);}

/* a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1886(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_1886r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1886r(t0,t1,t2,t3);}}

static void C_ccall f_1886r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1890,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cadr(t2);
/* chicken.scm: 72   ->string */
t7=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
/* chicken.scm: 72   sprintf */
t6=C_retrieve(lf[62]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[154],t2);}}

/* k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1890,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[4]):((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1896,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 72   gensym */
t5=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1896,2,t0,t1);}
t2=*((C_word*)lf[101]+1);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=t1,a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
/* chicken.scm: 72   gensym */
t9=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t9))(2,t9,t8);}

/* k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1902,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken.scm: 72   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1905,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* chicken.scm: 72   gensym */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1905,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1907,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t7=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1950,a[2]=t5,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=t5,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t1,a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[11],tmp=(C_word)a,a+=16,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2572,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=t10,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_2572(t12,t8,((C_word*)((C_word*)t0)[6])[1]);}

/* do539 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_2572(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2572,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2582,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_2582(t5,t3);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_pairp(t5);
t7=(C_word)C_i_not(t6);
if(C_truep(t7)){
t8=t4;
f_2582(t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2647,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2651,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 72   caar */
t10=*((C_word*)lf[152]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t2);}}}

/* k2649 in do539 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   keyword? */
t2=C_retrieve(lf[153]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2645 in do539 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2582(t2,(C_word)C_i_not(t1));}

/* k2580 in do539 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_2582(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2582,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2586,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken.scm: 72   caar */
t3=*((C_word*)lf[152]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}}

/* k2584 in k2580 in do539 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2589,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[146]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2603,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2607,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 72   cadar */
t6=*((C_word*)lf[148]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(t1,lf[149]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2617,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   cadar */
t6=*((C_word*)lf[148]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(t1,lf[150]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2627,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   cadar */
t7=*((C_word*)lf[148]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[7]);}
else{
t6=(C_word)C_i_car(((C_word*)t0)[7]);
/* chicken.scm: 72   syntax-error */
t7=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t2,lf[112],lf[151],t6);}}}}

/* k2625 in k2584 in k2580 in do539 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2589(2,t3,t2);}

/* k2615 in k2584 in k2580 in do539 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2589(2,t3,t2);}

/* k2605 in k2584 in k2580 in do539 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   eval */
t2=C_retrieve(lf[147]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2601 in k2584 in k2580 in do539 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2589(2,t3,t2);}

/* k2587 in k2584 in k2580 in do539 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2572(t3,((C_word*)t0)[2],t2);}

/* k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1996,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t3=(C_word)C_a_i_list(&a,2,lf[104],((C_word*)t0)[3]);
/* chicken.scm: 72   ##sys#hash-table-set! */
t4=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[145]),((C_word*)t0)[14],t3);}

/* k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2003,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2007,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=t2,tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=t3;
f_2007(t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2479,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2483,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2495,a[2]=((C_word*)t0)[6],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2566,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 72   ->string */
t8=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[2]);}}

/* k2564 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string-append */
t2=*((C_word*)lf[141]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[142],t1,lf[143]);}

/* k2493 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2495,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2499,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2501,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a2500 in k2493 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2501(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2501,3,t0,t1,t2);}
t3=(C_word)C_i_length(t2);
switch(t3){
case C_fix(3):
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2518,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2530,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cadr(t2);
/* chicken.scm: 72   ->string */
t8=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);
case C_fix(2):
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2547,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2555,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cadr(t2);
/* chicken.scm: 72   ->string */
t8=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);
default:
/* chicken.scm: 72   syntax-error */
t4=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[112],lf[140],t2);}}

/* k2553 in a2500 in k2493 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   ##compiler#foreign-type-declaration */
t2=C_retrieve(lf[138]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2545 in a2500 in k2493 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   sprintf */
t2=C_retrieve(lf[62]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[139],t1);}

/* k2528 in a2500 in k2493 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   ##compiler#foreign-type-declaration */
t2=C_retrieve(lf[138]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2516 in a2500 in k2493 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_caddr(((C_word*)t0)[3]);
/* chicken.scm: 72   sprintf */
t3=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[137],t1,t2);}

/* k2497 in k2493 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2499,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_list(&a,1,lf[136]);
/* chicken.scm: 72   append */
t4=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t2,t3);}

/* k2481 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string-intersperse */
t2=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[135]);}

/* k2477 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2479,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[98],t1);
t3=(C_word)C_a_i_list(&a,2,lf[133],t2);
t4=((C_word*)t0)[2];
f_2007(t4,(C_word)C_a_i_list(&a,1,t3));}

/* k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_2007(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2007,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2011,a[2]=t1,a[3]=((C_word*)t0)[14],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2015,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2461,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 72   sprintf */
t6=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[132],((C_word*)t0)[2],((C_word*)t0)[2]);}
else{
t5=t3;
f_2015(t5,C_SCHEME_END_OF_LIST);}}

/* k2459 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2461,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[107],((C_word*)t0)[4],C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)((C_word*)t0)[3])[1],t2);
t4=((C_word*)t0)[2];
f_2015(t4,(C_word)C_a_i_list(&a,1,t3));}

/* k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_2015(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2015,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2019,a[2]=t1,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2023,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
t4=((C_word*)((C_word*)t0)[2])[1];
if(C_truep(t4)){
t5=(C_word)C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],lf[129]);
t6=(C_word)C_a_i_list(&a,3,lf[130],lf[131],lf[129]);
t7=(C_word)C_a_i_list(&a,3,lf[110],lf[129],t6);
t8=(C_word)C_a_i_list(&a,3,lf[82],t5,t7);
t9=t3;
f_2023(t9,(C_word)C_a_i_list(&a,1,t8));}
else{
t5=t3;
f_2023(t5,C_SCHEME_END_OF_LIST);}}

/* k2021 in k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_2023(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2023,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2027,a[2]=t1,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2029,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a2028 in k2021 in k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2029(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2029,3,t0,t1,t2);}
t3=(C_word)C_i_length(t2);
switch(t3){
case C_fix(3):
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_caddr(t2);
t7=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2051,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t1,a[8]=t6,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* chicken.scm: 72   stype */
t8=((C_word*)((C_word*)t0)[2])[1];
f_1907(t8,t7,t4);
case C_fix(2):
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cadr(t2);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2306,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* chicken.scm: 72   stype */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1907(t7,t6,t4);
default:
/* chicken.scm: 72   syntax-error */
t4=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[112],lf[128],t2);}}

/* k2304 in a2028 in k2021 in k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2383,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2414,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2418,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   sprintf */
t5=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[127],((C_word*)t0)[9],((C_word*)t0)[4]);}

/* k2416 in k2304 in a2028 in k2021 in k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   renamer */
t2=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2412 in k2304 in a2028 in k2021 in k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2381 in k2304 in a2028 in k2021 in k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2383,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2395,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=t3,a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2406,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 72   strtype */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1950(t6,t5,((C_word*)t0)[6]);}

/* k2404 in k2381 in k2304 in a2028 in k2021 in k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[124]:lf[125]);
/* chicken.scm: 72   sprintf */
t3=C_retrieve(lf[62]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],lf[126],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2393 in k2381 in k2304 in a2028 in k2021 in k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2395,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[107],((C_word*)t0)[11],((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[9],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2321,a[2]=((C_word*)t0)[8],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2324,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[7],a[9]=t4,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t6=(C_word)C_i_car(((C_word*)t0)[7]);
t7=t5;
f_2324(t7,(C_word)C_eqp(lf[102],t6));}
else{
t6=t5;
f_2324(t6,C_SCHEME_FALSE);}}

/* k2322 in k2393 in k2381 in k2304 in a2028 in k2021 in k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_2324(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2324,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
f_2321(t2,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[8],((C_word*)t0)[7]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2341,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2365,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2369,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   sprintf */
t6=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[123],((C_word*)t0)[6],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[9];
f_2321(t3,C_SCHEME_END_OF_LIST);}}}

/* k2367 in k2322 in k2393 in k2381 in k2304 in a2028 in k2021 in k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   renamer */
t2=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2363 in k2322 in k2393 in k2381 in k2304 in a2028 in k2021 in k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2339 in k2322 in k2393 in k2381 in k2304 in a2028 in k2021 in k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2341,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2353,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 72   sprintf */
t6=C_retrieve(lf[62]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,lf[122],((C_word*)t0)[6],((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k2351 in k2339 in k2322 in k2393 in k2381 in k2304 in a2028 in k2021 in k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2353,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[107],lf[114],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_2321(t4,(C_word)C_a_i_list(&a,1,t3));}

/* k2319 in k2393 in k2381 in k2304 in a2028 in k2021 in k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_2321(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2321,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[68],t2));}

/* k2049 in a2028 in k2021 in k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2192,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2287,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2291,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   sprintf */
t5=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[121],((C_word*)t0)[12],((C_word*)t0)[4]);}

/* k2289 in k2049 in a2028 in k2021 in k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   renamer */
t2=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2285 in k2049 in a2028 in k2021 in k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2190 in k2049 in a2028 in k2021 in k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2192,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[13],((C_word*)t0)[12]);
t3=(C_word)C_a_i_list(&a,2,lf[106],((C_word*)t0)[11]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2264,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[9],a[13]=t4,a[14]=((C_word*)t0)[10],tmp=(C_word)a,a+=15,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2275,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[12],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 72   strtype */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1950(t7,t6,((C_word*)t0)[6]);}

/* k2273 in k2190 in k2049 in a2028 in k2021 in k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[118]:lf[119]);
/* chicken.scm: 72   sprintf */
t3=C_retrieve(lf[62]);
((C_proc7)C_retrieve_proc(t3))(7,t3,((C_word*)t0)[5],lf[120],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2262 in k2190 in k2049 in a2028 in k2021 in k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[161],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2264,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[107],((C_word*)t0)[14],((C_word*)t0)[13],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[12],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[11],((C_word*)t0)[10]);
t6=(C_word)C_a_i_list(&a,3,lf[108],((C_word*)t0)[10],C_fix(0));
t7=(C_word)C_a_i_list(&a,3,lf[109],((C_word*)t0)[10],((C_word*)t0)[9]);
t8=(C_word)C_a_i_list(&a,3,lf[110],t6,t7);
t9=(C_word)C_a_i_list(&a,2,lf[111],t8);
t10=(C_word)C_a_i_list(&a,3,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10]);
t11=(C_word)C_a_i_list(&a,2,lf[61],lf[112]);
t12=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[8]);
t13=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[10]);
t14=(C_word)C_a_i_list(&a,6,lf[50],t11,lf[113],t12,t13,((C_word*)t0)[9]);
t15=(C_word)C_a_i_list(&a,4,lf[72],t9,t10,t14);
t16=(C_word)C_a_i_list(&a,3,lf[2],t5,t15);
t17=(C_word)C_a_i_list(&a,3,lf[79],t4,t16);
t18=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[7],t17);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2066,a[2]=((C_word*)t0)[6],a[3]=t18,tmp=(C_word)a,a+=4,tmp);
t20=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[5],a[12]=t19,tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t21=(C_word)C_i_car(((C_word*)t0)[5]);
t22=t20;
f_2069(t22,(C_word)C_eqp(lf[102],t21));}
else{
t21=t20;
f_2069(t21,C_SCHEME_FALSE);}}

/* k2067 in k2262 in k2190 in k2049 in a2028 in k2021 in k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_2069(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2069,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[12];
f_2066(t2,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[11],((C_word*)t0)[10]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2086,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2174,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2178,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 72   sprintf */
t6=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[117],((C_word*)t0)[9],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[12];
f_2066(t3,C_SCHEME_END_OF_LIST);}}}

/* k2176 in k2067 in k2262 in k2190 in k2049 in a2028 in k2021 in k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   renamer */
t2=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2172 in k2067 in k2262 in k2190 in k2049 in a2028 in k2021 in k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2084 in k2067 in k2262 in k2190 in k2049 in a2028 in k2021 in k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2086,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(C_word)C_a_i_list(&a,2,lf[106],((C_word*)t0)[8]);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,3,t2,t3,t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2158,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[5],a[10]=t5,tmp=(C_word)a,a+=11,tmp);
/* chicken.scm: 72   sprintf */
t7=C_retrieve(lf[62]);
((C_proc7)C_retrieve_proc(t7))(7,t7,t6,lf[116],((C_word*)t0)[9],((C_word*)t0)[2],((C_word*)t0)[8],((C_word*)t0)[6]);}

/* k2156 in k2084 in k2067 in k2262 in k2190 in k2049 in a2028 in k2021 in k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[153],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2158,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[107],lf[114],((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_a_i_list(&a,3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t6=(C_word)C_a_i_list(&a,3,lf[108],((C_word*)t0)[7],C_fix(0));
t7=(C_word)C_a_i_list(&a,3,lf[109],((C_word*)t0)[7],((C_word*)t0)[5]);
t8=(C_word)C_a_i_list(&a,3,lf[110],t6,t7);
t9=(C_word)C_a_i_list(&a,2,lf[111],t8);
t10=(C_word)C_a_i_list(&a,4,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t11=(C_word)C_a_i_list(&a,2,lf[61],lf[112]);
t12=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[4]);
t13=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)t0)[7]);
t14=(C_word)C_a_i_list(&a,6,lf[50],t11,lf[115],t12,t13,((C_word*)t0)[5]);
t15=(C_word)C_a_i_list(&a,4,lf[72],t9,t10,t14);
t16=(C_word)C_a_i_list(&a,3,lf[2],t5,t15);
t17=(C_word)C_a_i_list(&a,3,lf[79],t4,t16);
t18=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[3],t17);
t19=((C_word*)t0)[2];
f_2066(t19,(C_word)C_a_i_list(&a,1,t18));}

/* k2064 in k2262 in k2190 in k2049 in a2028 in k2021 in k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_2066(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2066,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[68],t2));}

/* k2025 in k2021 in k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2017 in k2013 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2009 in k2005 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2001 in k1994 in k1991 in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_2003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2003,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[68],t1));}

/* strtype in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_1950(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1950,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1966,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(lf[102],t5);
if(C_truep(t6)){
t7=(C_word)C_i_cadr(t2);
/* chicken.scm: 72   strtype */
t9=t4;
t10=t7;
t1=t9;
t2=t10;
goto loop;}
else{
t7=t4;
f_1966(2,t7,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* k1964 in strtype in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_memq(t2,lf[105]));}}

/* stype in k1903 in k1900 in k1897 in k1894 in k1888 in a1885 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_1907(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1907,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(lf[102],t3);
if(C_truep(t4)){
t5=(C_word)C_i_cadr(t2);
/* chicken.scm: 72   stype */
t9=t1;
t10=t5;
t1=t9;
t2=t10;
goto loop;}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_memq(t5,lf[103]);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?(C_word)C_a_i_list(&a,2,lf[104],t2):t2));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1062,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1872,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro-2 */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[98],t3);}

/* a1871 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1872(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1872,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,lf[98],t2);
t4=(C_word)C_a_i_list(&a,2,lf[61],t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,lf[99],t4));}

/* k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1065,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1532,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[95],t3);}

/* a1531 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1532(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_1532r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1532r(t0,t1,t2,t3);}}

static void C_ccall f_1532r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(7);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1536,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t4)[1]))){
t6=(C_word)C_i_car(((C_word*)t4)[1]);
if(C_truep((C_word)C_booleanp(t6))){
t7=(C_word)C_i_cdr(((C_word*)t4)[1]);
t8=C_set_block_item(t4,0,t7);
t9=t5;
f_1536(t9,t6);}
else{
t7=t5;
f_1536(t7,C_SCHEME_TRUE);}}
else{
t6=t5;
f_1536(t6,C_SCHEME_TRUE);}}

/* k1534 in a1531 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_1536(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1536,NULL,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1539,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* chicken.scm: 72   ->string */
t5=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}

/* k1537 in k1534 in a1531 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1539,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=lf[67];
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1542,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1844,tmp=(C_word)a,a+=2,tmp);
/* map */
t8=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)((C_word*)t0)[2])[1]);}

/* a1843 in k1537 in k1534 in a1531 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1844(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1844,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_car(t2):t2));}

/* k1540 in k1537 in k1534 in a1531 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1542,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1545,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1819,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a1818 in k1540 in k1537 in k1534 in a1531 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1819(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1819,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cadr(t2));}
else{
/* chicken.scm: 72   syntax-error */
t4=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[95],lf[97],t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1543 in k1540 in k1537 in k1534 in a1531 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1548,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1787,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a1786 in k1543 in k1540 in k1537 in k1534 in a1531 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1787(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1787,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_caddr(t2));}
else{
t4=(C_word)C_i_car(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,lf[61],t4));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[61],t2));}}

/* k1546 in k1543 in k1540 in k1537 in k1534 in a1531 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1551,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[2]))){
t3=(C_word)C_i_length(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1761,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_and((C_word)C_fixnum_less_or_equal_p(C_fix(2),t3),(C_word)C_fixnum_less_or_equal_p(t3,C_fix(3))))){
t5=t4;
f_1761(2,t5,C_SCHEME_UNDEFINED);}
else{
/* chicken.scm: 72   syntax-error */
t5=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[95],lf[96],((C_word*)t0)[2]);}}
else{
t3=t2;
f_1551(t3,C_SCHEME_UNDEFINED);}}

/* k1759 in k1546 in k1543 in k1540 in k1537 in k1534 in a1531 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[7]);
t5=C_mutate(((C_word *)((C_word*)t0)[5])+1,t4);
t6=(C_word)C_eqp(C_fix(3),((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(C_word)C_i_caddr(((C_word*)t0)[7]);
t8=C_mutate(((C_word *)((C_word*)t0)[3])+1,t7);
t9=((C_word*)t0)[2];
f_1551(t9,t8);}
else{
t7=((C_word*)t0)[2];
f_1551(t7,C_SCHEME_UNDEFINED);}}

/* k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in a1531 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_1551(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1551,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1554,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[2])){
/* map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[6]),((C_word*)t0)[4]);}
else{
t3=t2;
f_1554(2,t3,((C_word*)t0)[4]);}}

/* k1552 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in a1531 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1557,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1749,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 72   conc */
t4=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[7])[1],lf[93]);}

/* k1747 in k1552 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in a1531 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1555 in k1552 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in a1531 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1560,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1745,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 72   conc */
t4=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[92],((C_word*)((C_word*)t0)[8])[1]);}

/* k1743 in k1555 in k1552 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in a1531 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 72   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1558 in k1555 in k1552 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in a1531 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1567,a[2]=((C_word*)t0)[10],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1571,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1733,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 72   map */
t5=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* a1732 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in a1531 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1733(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1733,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1741,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken.scm: 72   ->string */
t5=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k1739 in a1732 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in a1531 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1741,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[90],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1));}

/* k1569 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in a1531 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[97],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1571,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[10],lf[69]);
t3=(C_word)C_a_i_list(&a,2,lf[70],lf[69]);
t4=(C_word)C_a_i_list(&a,2,lf[71],lf[69]);
t5=(C_word)C_a_i_list(&a,4,lf[72],t3,t4,lf[69]);
t6=(C_word)C_a_i_list(&a,2,lf[69],t5);
t7=(C_word)C_a_i_list(&a,2,lf[73],C_fix(0));
t8=(C_word)C_a_i_list(&a,2,t6,t7);
t9=(C_word)C_a_i_list(&a,2,lf[74],lf[69]);
t10=(C_word)C_a_i_list(&a,2,lf[75],lf[69]);
t11=(C_word)C_a_i_list(&a,2,lf[76],lf[69]);
t12=(C_word)C_a_i_list(&a,2,lf[77],t11);
t13=(C_word)C_a_i_list(&a,1,t12);
t14=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1673,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t2,a[12]=t8,a[13]=t9,a[14]=t10,a[15]=t13,tmp=(C_word)a,a+=16,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1677,a[2]=t14,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t16=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1695,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   map */
t17=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t17))(5,t17,t15,t16,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* a1694 in k1569 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in a1531 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1695(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1695,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,t4,t2));}

/* k1675 in k1569 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in a1531 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1677,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[61],((C_word*)((C_word*)t0)[3])[1]);
t3=(C_word)C_a_i_list(&a,4,lf[88],lf[89],lf[77],t2);
t4=(C_word)C_a_i_list(&a,2,lf[86],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* ##sys#append */
t6=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[2],t1,t5);}

/* k1671 in k1569 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in a1531 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[88],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1673,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[77],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[78],t2);
t4=(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[15],t3);
t5=(C_word)C_a_i_list(&a,3,lf[80],lf[73],t4);
t6=(C_word)C_a_i_list(&a,3,lf[81],((C_word*)t0)[14],t5);
t7=(C_word)C_a_i_list(&a,4,lf[72],((C_word*)t0)[13],lf[73],t6);
t8=(C_word)C_a_i_list(&a,4,lf[79],lf[81],((C_word*)t0)[12],t7);
t9=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[11],t8);
t10=(C_word)C_a_i_list(&a,2,((C_word*)t0)[10],lf[77]);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1599,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t9,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t10,tmp=(C_word)a,a+=10,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1603,a[2]=t11,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1613,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   map */
t14=*((C_word*)lf[1]+1);
((C_proc5)C_retrieve_proc(t14))(5,t14,t12,t13,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1612 in k1671 in k1569 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in a1531 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1613,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,3,lf[87],lf[77],t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,t4,t3));}

/* k1601 in k1671 in k1569 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in a1531 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1603,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[86],((C_word*)((C_word*)t0)[3])[1]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k1597 in k1671 in k1569 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in a1531 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1599,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[83],t1);
t3=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_list(&a,5,lf[84],((C_word*)((C_word*)t0)[8])[1],((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],t3,t4);
/* ##sys#append */
t6=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[3],((C_word*)t0)[2],t5);}

/* k1565 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in a1531 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1567,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[68],t1));}

/* k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1068,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1498,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[66],t3);}

/* a1497 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1498(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[60],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1498,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t2,lf[60]);
t5=(C_word)C_a_i_list(&a,2,lf[61],t2);
t6=(C_word)C_a_i_list(&a,2,lf[61],t3);
t7=(C_word)C_a_i_list(&a,4,lf[62],lf[63],t5,t6);
t8=(C_word)C_a_i_list(&a,2,lf[56],t7);
t9=(C_word)C_a_i_list(&a,2,lf[61],t3);
t10=(C_word)C_a_i_list(&a,3,lf[64],t9,lf[60]);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[65],t4,t8,t10));}

/* k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1071,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1436,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 72   ##sys#register-macro */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[51],t3);}

/* a1435 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1436(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_1436r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1436r(t0,t1,t2,t3);}}

static void C_ccall f_1436r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1439,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1446,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1449,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_i_car(t2);
t8=t6;
f_1449(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_1449(t7,C_SCHEME_FALSE);}}

/* k1447 in a1435 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_1449(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1449,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_memq(lf[54],C_retrieve(lf[55])))){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 72   warning */
t3=C_retrieve(lf[56]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],lf[57],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1475,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken.scm: 72   ##compiler#register-compiler-macro */
t5=C_retrieve(lf[58]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,t3,t4,((C_word*)t0)[2]);}}
else{
/* chicken.scm: 72   bad */
t2=((C_word*)t0)[3];
f_1439(t2,((C_word*)t0)[4]);}}

/* k1473 in k1447 in a1435 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_1446(2,t2,C_SCHEME_UNDEFINED);}
else{
/* chicken.scm: 72   bad */
t2=((C_word*)t0)[2];
f_1439(t2,((C_word*)t0)[3]);}}

/* k1444 in a1435 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[53]);}

/* bad in a1435 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_1439(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1439,NULL,2,t0,t1);}
/* chicken.scm: 72   syntax-error */
t2=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,lf[51],lf[52],((C_word*)t0)[2]);}

/* k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1075,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1434,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 79   argv */
t4=C_retrieve(lf[49]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k1432 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1434,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1413,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1415,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1423,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1427,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 80   getenv */
t7=C_retrieve(lf[47]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[48]);}

/* k1425 in k1432 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[45]);
/* chicken.scm: 80   string-split */
t3=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k1421 in k1432 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 80   remove */
t2=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1414 in k1432 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1415(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1415,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_string_equal_p(t2,lf[43]));}

/* k1411 in k1432 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 78   append */
t2=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1073 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1075,2,t0,t1);}
t2=C_mutate((C_word*)lf[10]+1,t1);
t3=C_mutate((C_word*)lf[11]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1077,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1184,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1192,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1204,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 107  ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}

/* a1203 in k1073 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1204(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1204,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1208,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1216,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_1216(t9,t5,((C_word*)t4)[1]);}

/* loop in a1203 in k1073 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_1216(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(26);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1216,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_eqp(lf[19],t3);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1238,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t4);
/* chicken.scm: 113  string->number */
C_string_to_number(3,0,t6,t7);}
else{
t6=(C_word)C_eqp(lf[26],t3);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1301,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_car(t4);
/* chicken.scm: 127  string->number */
C_string_to_number(3,0,t7,t8);}
else{
t7=(C_word)C_eqp(lf[30],t3);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1355,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 136  cons* */
t9=C_retrieve(lf[20]);
((C_proc11)C_retrieve_proc(t9))(11,t9,t8,lf[31],lf[32],lf[28],lf[22],lf[21],lf[33],lf[34],lf[27],((C_word*)((C_word*)t0)[2])[1]);}
else{
if(C_truep((C_word)C_i_memq(t3,C_retrieve(lf[35])))){
/* chicken.scm: 140  loop */
t17=t1;
t18=t4;
t1=t17;
t2=t18;
goto loop;}
else{
if(C_truep((C_word)C_i_memq(t3,C_retrieve(lf[36])))){
if(C_truep((C_word)C_i_pairp(t4))){
t8=(C_word)C_i_cdr(t4);
/* chicken.scm: 143  loop */
t17=t1;
t18=t8;
t1=t17;
t2=t18;
goto loop;}
else{
/* chicken.scm: 144  quit */
t8=C_retrieve(lf[37]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,lf[38],t3);}}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1392,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1399,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_stringp(t3))){
t10=t9;
f_1399(2,t10,t3);}
else{
/* chicken.scm: 148  conc */
t10=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,lf[41],t3);}}}}}}}}

/* k1397 in loop in a1203 in k1073 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 146  compiler-warning */
t2=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[24],lf[39],t1);}

/* k1390 in loop in a1203 in k1073 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 149  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1216(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1353 in loop in a1203 in k1073 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* chicken.scm: 139  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1216(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1299 in loop in a1203 in k1073 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1304,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
switch(t1){
case C_fix(0):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1318,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 129  cons* */
t4=C_retrieve(lf[20]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[27],lf[28],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,lf[28],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_1304(2,t5,t4);
case C_fix(2):
t3=t2;
f_1304(2,t3,C_SCHEME_FALSE);
default:
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 132  compiler-warning */
t4=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[24],lf[29],t3);}}

/* k1316 in k1299 in loop in a1203 in k1073 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1304(2,t3,t2);}

/* k1302 in k1299 in loop in a1203 in k1073 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 133  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1216(t3,((C_word*)t0)[2],t2);}

/* k1236 in loop in a1203 in k1073 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1241,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
switch(t1){
case C_fix(0):
t3=t2;
f_1241(2,t3,C_SCHEME_FALSE);
case C_fix(1):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1261,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 117  cons* */
t4=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[21],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(2):
t3=(C_word)C_a_i_cons(&a,2,lf[21],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_1241(2,t5,t4);
case C_fix(3):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1281,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 123  cons* */
t4=C_retrieve(lf[20]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[21],lf[22],((C_word*)((C_word*)t0)[2])[1]);
default:
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 124  compiler-warning */
t4=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[24],lf[25],t3);}}

/* k1279 in k1236 in loop in a1203 in k1073 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1241(2,t3,t2);}

/* k1259 in k1236 in loop in a1203 in k1073 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1241(2,t3,t2);}

/* k1239 in k1236 in loop in a1203 in k1073 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 125  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1216(t3,((C_word*)t0)[2],t2);}

/* k1206 in a1203 in k1073 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1208,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1211,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t2,C_retrieve(lf[18]),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k1209 in k1206 in a1203 in k1073 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 151  exit */
t2=C_retrieve(lf[17]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a1191 in k1073 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1199,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 107  user-options-pass */
t3=C_retrieve(lf[16]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1197 in a1191 in k1073 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_retrieve(lf[11]));
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_retrieve(lf[10]));}

/* k1182 in k1073 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1187,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1190,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
t4=C_retrieve(lf[15]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k1188 in k1182 in k1073 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1185 in k1182 in k1073 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##compiler#process-command-line in k1073 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1077(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1077,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1083,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_1083(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in ##compiler#process-command-line in k1073 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_1083(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1083,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1097,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 92   reverse */
t6=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_string_length(t5);
t7=(C_word)C_i_string_ref(t5,C_fix(0));
t8=(C_word)C_eqp(C_make_character(45),t7);
t9=(C_truep(t8)?(C_word)C_fixnum_greaterp(t6,C_fix(1)):C_SCHEME_FALSE);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1118,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t6,C_fix(1)))){
t11=(C_word)C_i_string_ref(t5,C_fix(1));
t12=t10;
f_1118(t12,(C_word)C_eqp(C_make_character(58),t11));}
else{
t11=t10;
f_1118(t11,C_SCHEME_FALSE);}}
else{
if(C_truep(t4)){
t10=(C_word)C_i_cdr(t2);
t11=(C_word)C_a_i_cons(&a,2,t5,t3);
/* chicken.scm: 101  loop */
t17=t1;
t18=t10;
t19=t11;
t20=t4;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}
else{
t10=(C_word)C_i_cdr(t2);
/* chicken.scm: 102  loop */
t17=t1;
t18=t10;
t19=t3;
t20=t5;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}}}}

/* k1116 in loop in ##compiler#process-command-line in k1073 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_fcall f_1118(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1118,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* chicken.scm: 98   loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_1083(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1140,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1144,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 99   substring */
t5=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]);}}

/* k1142 in k1116 in loop in ##compiler#process-command-line in k1073 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 99   string->symbol */
t2=*((C_word*)lf[13]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1138 in k1116 in loop in ##compiler#process-command-line in k1073 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1140,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* chicken.scm: 99   loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1083(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1095 in loop in ##compiler#process-command-line in k1073 in k1069 in k1066 in k1063 in k1060 in k1057 in k1054 in k1051 in k1048 in k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k867 in k864 in k861 in k858 in k855 in k852 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_1097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 92   values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* assign in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_781(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_781,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_785,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   ##sys#check-syntax */
t5=C_retrieve(lf[7]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[8],t2,lf[9]);}

/* k783 in assign in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_785,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t2=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,lf[3]);
t4=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[4],t2,t4));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t3,((C_word*)t0)[4]));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_822,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 71   map */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[6]),((C_word*)t0)[5]);}}}

/* k820 in k783 in assign in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_822,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[2],C_SCHEME_END_OF_LIST,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_841,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_843,tmp=(C_word)a,a+=2,tmp);
/* chicken.scm: 71   map */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[2],t1);}

/* a842 in k820 in k783 in assign in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_843(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_843,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],t2,t3));}

/* k839 in k820 in k783 in assign in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 in k754 in k751 in k748 in k745 in k742 in k736 in k733 in k730 in k727 in k724 in k721 in k718 in k715 in k712 in k709 in k706 in k703 in k700 in k697 in k694 in k691 in k688 */
static void C_ccall f_841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_841,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[2],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[4],((C_word*)t0)[2],t3));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[580] = {
{"toplevelchicken.scm",(void*)C_toplevel},
{"f_690chicken.scm",(void*)f_690},
{"f_693chicken.scm",(void*)f_693},
{"f_696chicken.scm",(void*)f_696},
{"f_699chicken.scm",(void*)f_699},
{"f_702chicken.scm",(void*)f_702},
{"f_705chicken.scm",(void*)f_705},
{"f_708chicken.scm",(void*)f_708},
{"f_711chicken.scm",(void*)f_711},
{"f_714chicken.scm",(void*)f_714},
{"f_717chicken.scm",(void*)f_717},
{"f_720chicken.scm",(void*)f_720},
{"f_723chicken.scm",(void*)f_723},
{"f_726chicken.scm",(void*)f_726},
{"f_729chicken.scm",(void*)f_729},
{"f_732chicken.scm",(void*)f_732},
{"f_735chicken.scm",(void*)f_735},
{"f_738chicken.scm",(void*)f_738},
{"f_744chicken.scm",(void*)f_744},
{"f_6922chicken.scm",(void*)f_6922},
{"f_6926chicken.scm",(void*)f_6926},
{"f_6929chicken.scm",(void*)f_6929},
{"f_6932chicken.scm",(void*)f_6932},
{"f_6938chicken.scm",(void*)f_6938},
{"f_7144chicken.scm",(void*)f_7144},
{"f_7124chicken.scm",(void*)f_7124},
{"f_7120chicken.scm",(void*)f_7120},
{"f_7100chicken.scm",(void*)f_7100},
{"f_6963chicken.scm",(void*)f_6963},
{"f_6973chicken.scm",(void*)f_6973},
{"f_7092chicken.scm",(void*)f_7092},
{"f_6976chicken.scm",(void*)f_6976},
{"f_7088chicken.scm",(void*)f_7088},
{"f_6979chicken.scm",(void*)f_6979},
{"f_7010chicken.scm",(void*)f_7010},
{"f_6990chicken.scm",(void*)f_6990},
{"f_6961chicken.scm",(void*)f_6961},
{"f_747chicken.scm",(void*)f_747},
{"f_6834chicken.scm",(void*)f_6834},
{"f_6851chicken.scm",(void*)f_6851},
{"f_6854chicken.scm",(void*)f_6854},
{"f_6860chicken.scm",(void*)f_6860},
{"f_750chicken.scm",(void*)f_750},
{"f_6793chicken.scm",(void*)f_6793},
{"f_6797chicken.scm",(void*)f_6797},
{"f_753chicken.scm",(void*)f_753},
{"f_6777chicken.scm",(void*)f_6777},
{"f_6787chicken.scm",(void*)f_6787},
{"f_6785chicken.scm",(void*)f_6785},
{"f_756chicken.scm",(void*)f_756},
{"f_6700chicken.scm",(void*)f_6700},
{"f_6704chicken.scm",(void*)f_6704},
{"f_6772chicken.scm",(void*)f_6772},
{"f_6707chicken.scm",(void*)f_6707},
{"f_6716chicken.scm",(void*)f_6716},
{"f_6763chicken.scm",(void*)f_6763},
{"f_6730chicken.scm",(void*)f_6730},
{"f_6738chicken.scm",(void*)f_6738},
{"f_6740chicken.scm",(void*)f_6740},
{"f_6757chicken.scm",(void*)f_6757},
{"f_6722chicken.scm",(void*)f_6722},
{"f_6714chicken.scm",(void*)f_6714},
{"f_759chicken.scm",(void*)f_759},
{"f_6640chicken.scm",(void*)f_6640},
{"f_6644chicken.scm",(void*)f_6644},
{"f_762chicken.scm",(void*)f_762},
{"f_6581chicken.scm",(void*)f_6581},
{"f_6585chicken.scm",(void*)f_6585},
{"f_6612chicken.scm",(void*)f_6612},
{"f_765chicken.scm",(void*)f_765},
{"f_6407chicken.scm",(void*)f_6407},
{"f_6411chicken.scm",(void*)f_6411},
{"f_6414chicken.scm",(void*)f_6414},
{"f_6575chicken.scm",(void*)f_6575},
{"f_6417chicken.scm",(void*)f_6417},
{"f_6569chicken.scm",(void*)f_6569},
{"f_6420chicken.scm",(void*)f_6420},
{"f_6567chicken.scm",(void*)f_6567},
{"f_6531chicken.scm",(void*)f_6531},
{"f_6545chicken.scm",(void*)f_6545},
{"f_6559chicken.scm",(void*)f_6559},
{"f_6539chicken.scm",(void*)f_6539},
{"f_6535chicken.scm",(void*)f_6535},
{"f_6427chicken.scm",(void*)f_6427},
{"f_6523chicken.scm",(void*)f_6523},
{"f_6499chicken.scm",(void*)f_6499},
{"f_6517chicken.scm",(void*)f_6517},
{"f_6507chicken.scm",(void*)f_6507},
{"f_6503chicken.scm",(void*)f_6503},
{"f_6495chicken.scm",(void*)f_6495},
{"f_6479chicken.scm",(void*)f_6479},
{"f_6455chicken.scm",(void*)f_6455},
{"f_6473chicken.scm",(void*)f_6473},
{"f_6463chicken.scm",(void*)f_6463},
{"f_6459chicken.scm",(void*)f_6459},
{"f_6451chicken.scm",(void*)f_6451},
{"f_768chicken.scm",(void*)f_768},
{"f_6312chicken.scm",(void*)f_6312},
{"f_6348chicken.scm",(void*)f_6348},
{"f_6361chicken.scm",(void*)f_6361},
{"f_6319chicken.scm",(void*)f_6319},
{"f_771chicken.scm",(void*)f_771},
{"f_6202chicken.scm",(void*)f_6202},
{"f_6206chicken.scm",(void*)f_6206},
{"f_6209chicken.scm",(void*)f_6209},
{"f_6212chicken.scm",(void*)f_6212},
{"f_6215chicken.scm",(void*)f_6215},
{"f_6306chicken.scm",(void*)f_6306},
{"f_6218chicken.scm",(void*)f_6218},
{"f_6300chicken.scm",(void*)f_6300},
{"f_6221chicken.scm",(void*)f_6221},
{"f_6294chicken.scm",(void*)f_6294},
{"f_6298chicken.scm",(void*)f_6298},
{"f_6228chicken.scm",(void*)f_6228},
{"f_6266chicken.scm",(void*)f_6266},
{"f_6264chicken.scm",(void*)f_6264},
{"f_774chicken.scm",(void*)f_774},
{"f_6192chicken.scm",(void*)f_6192},
{"f_777chicken.scm",(void*)f_777},
{"f_6178chicken.scm",(void*)f_6178},
{"f_780chicken.scm",(void*)f_780},
{"f_854chicken.scm",(void*)f_854},
{"f_857chicken.scm",(void*)f_857},
{"f_5916chicken.scm",(void*)f_5916},
{"f_5920chicken.scm",(void*)f_5920},
{"f_5929chicken.scm",(void*)f_5929},
{"f_6138chicken.scm",(void*)f_6138},
{"f_6151chicken.scm",(void*)f_6151},
{"f_5932chicken.scm",(void*)f_5932},
{"f_6128chicken.scm",(void*)f_6128},
{"f_6136chicken.scm",(void*)f_6136},
{"f_5935chicken.scm",(void*)f_5935},
{"f_6082chicken.scm",(void*)f_6082},
{"f_6115chicken.scm",(void*)f_6115},
{"f_6122chicken.scm",(void*)f_6122},
{"f_6098chicken.scm",(void*)f_6098},
{"f_5947chicken.scm",(void*)f_5947},
{"f_6076chicken.scm",(void*)f_6076},
{"f_5954chicken.scm",(void*)f_5954},
{"f_5956chicken.scm",(void*)f_5956},
{"f_6070chicken.scm",(void*)f_6070},
{"f_5990chicken.scm",(void*)f_5990},
{"f_6044chicken.scm",(void*)f_6044},
{"f_6021chicken.scm",(void*)f_6021},
{"f_6001chicken.scm",(void*)f_6001},
{"f_5976chicken.scm",(void*)f_5976},
{"f_5984chicken.scm",(void*)f_5984},
{"f_5974chicken.scm",(void*)f_5974},
{"f_5936chicken.scm",(void*)f_5936},
{"f_5876chicken.scm",(void*)f_5876},
{"f_5899chicken.scm",(void*)f_5899},
{"f_5903chicken.scm",(void*)f_5903},
{"f_5845chicken.scm",(void*)f_5845},
{"f_5866chicken.scm",(void*)f_5866},
{"f_860chicken.scm",(void*)f_860},
{"f_5794chicken.scm",(void*)f_5794},
{"f_5798chicken.scm",(void*)f_5798},
{"f_5809chicken.scm",(void*)f_5809},
{"f_5834chicken.scm",(void*)f_5834},
{"f_863chicken.scm",(void*)f_863},
{"f_5674chicken.scm",(void*)f_5674},
{"f_5678chicken.scm",(void*)f_5678},
{"f_5788chicken.scm",(void*)f_5788},
{"f_5786chicken.scm",(void*)f_5786},
{"f_5687chicken.scm",(void*)f_5687},
{"f_5774chicken.scm",(void*)f_5774},
{"f_5782chicken.scm",(void*)f_5782},
{"f_5690chicken.scm",(void*)f_5690},
{"f_5768chicken.scm",(void*)f_5768},
{"f_5710chicken.scm",(void*)f_5710},
{"f_5720chicken.scm",(void*)f_5720},
{"f_5740chicken.scm",(void*)f_5740},
{"f_5746chicken.scm",(void*)f_5746},
{"f_5754chicken.scm",(void*)f_5754},
{"f_5744chicken.scm",(void*)f_5744},
{"f_5718chicken.scm",(void*)f_5718},
{"f_5714chicken.scm",(void*)f_5714},
{"f_5691chicken.scm",(void*)f_5691},
{"f_866chicken.scm",(void*)f_866},
{"f_5653chicken.scm",(void*)f_5653},
{"f_5657chicken.scm",(void*)f_5657},
{"f_869chicken.scm",(void*)f_869},
{"f_5643chicken.scm",(void*)f_5643},
{"f_875chicken.scm",(void*)f_875},
{"f_884chicken.scm",(void*)f_884},
{"f_900chicken.scm",(void*)f_900},
{"f_887chicken.scm",(void*)f_887},
{"f_948chicken.scm",(void*)f_948},
{"f_5622chicken.scm",(void*)f_5622},
{"f_5626chicken.scm",(void*)f_5626},
{"f_951chicken.scm",(void*)f_951},
{"f_5506chicken.scm",(void*)f_5506},
{"f_5510chicken.scm",(void*)f_5510},
{"f_5519chicken.scm",(void*)f_5519},
{"f_5533chicken.scm",(void*)f_5533},
{"f_5597chicken.scm",(void*)f_5597},
{"f_5579chicken.scm",(void*)f_5579},
{"f_5562chicken.scm",(void*)f_5562},
{"f_954chicken.scm",(void*)f_954},
{"f_5407chicken.scm",(void*)f_5407},
{"f_5417chicken.scm",(void*)f_5417},
{"f_5430chicken.scm",(void*)f_5430},
{"f_5446chicken.scm",(void*)f_5446},
{"f_5484chicken.scm",(void*)f_5484},
{"f_5482chicken.scm",(void*)f_5482},
{"f_5474chicken.scm",(void*)f_5474},
{"f_5428chicken.scm",(void*)f_5428},
{"f_957chicken.scm",(void*)f_957},
{"f_5318chicken.scm",(void*)f_5318},
{"f_5328chicken.scm",(void*)f_5328},
{"f_5341chicken.scm",(void*)f_5341},
{"f_5357chicken.scm",(void*)f_5357},
{"f_5385chicken.scm",(void*)f_5385},
{"f_5339chicken.scm",(void*)f_5339},
{"f_960chicken.scm",(void*)f_960},
{"f_5032chicken.scm",(void*)f_5032},
{"f_5229chicken.scm",(void*)f_5229},
{"f_5232chicken.scm",(void*)f_5232},
{"f_5235chicken.scm",(void*)f_5235},
{"f_5308chicken.scm",(void*)f_5308},
{"f_5316chicken.scm",(void*)f_5316},
{"f_5251chicken.scm",(void*)f_5251},
{"f_5254chicken.scm",(void*)f_5254},
{"f_5257chicken.scm",(void*)f_5257},
{"f_5260chicken.scm",(void*)f_5260},
{"f_5298chicken.scm",(void*)f_5298},
{"f_5306chicken.scm",(void*)f_5306},
{"f_5263chicken.scm",(void*)f_5263},
{"f_5043chicken.scm",(void*)f_5043},
{"f_5047chicken.scm",(void*)f_5047},
{"f_5051chicken.scm",(void*)f_5051},
{"f_5053chicken.scm",(void*)f_5053},
{"f_5098chicken.scm",(void*)f_5098},
{"f_5110chicken.scm",(void*)f_5110},
{"f_5106chicken.scm",(void*)f_5106},
{"f_5074chicken.scm",(void*)f_5074},
{"f_5266chicken.scm",(void*)f_5266},
{"f_5126chicken.scm",(void*)f_5126},
{"f_5226chicken.scm",(void*)f_5226},
{"f_5190chicken.scm",(void*)f_5190},
{"f_5160chicken.scm",(void*)f_5160},
{"f_5269chicken.scm",(void*)f_5269},
{"f_5236chicken.scm",(void*)f_5236},
{"f_5248chicken.scm",(void*)f_5248},
{"f_5244chicken.scm",(void*)f_5244},
{"f_963chicken.scm",(void*)f_963},
{"f_4975chicken.scm",(void*)f_4975},
{"f_4979chicken.scm",(void*)f_4979},
{"f_966chicken.scm",(void*)f_966},
{"f_4969chicken.scm",(void*)f_4969},
{"f_969chicken.scm",(void*)f_969},
{"f_4816chicken.scm",(void*)f_4816},
{"f_4820chicken.scm",(void*)f_4820},
{"f_4823chicken.scm",(void*)f_4823},
{"f_4826chicken.scm",(void*)f_4826},
{"f_4839chicken.scm",(void*)f_4839},
{"f_4889chicken.scm",(void*)f_4889},
{"f_4900chicken.scm",(void*)f_4900},
{"f_4837chicken.scm",(void*)f_4837},
{"f_972chicken.scm",(void*)f_972},
{"f_4540chicken.scm",(void*)f_4540},
{"f_4574chicken.scm",(void*)f_4574},
{"f_4577chicken.scm",(void*)f_4577},
{"f_4803chicken.scm",(void*)f_4803},
{"f_4813chicken.scm",(void*)f_4813},
{"f_4801chicken.scm",(void*)f_4801},
{"f_4580chicken.scm",(void*)f_4580},
{"f_4549chicken.scm",(void*)f_4549},
{"f_4563chicken.scm",(void*)f_4563},
{"f_4567chicken.scm",(void*)f_4567},
{"f_4583chicken.scm",(void*)f_4583},
{"f_4586chicken.scm",(void*)f_4586},
{"f_4589chicken.scm",(void*)f_4589},
{"f_4596chicken.scm",(void*)f_4596},
{"f_4610chicken.scm",(void*)f_4610},
{"f_4620chicken.scm",(void*)f_4620},
{"f_4624chicken.scm",(void*)f_4624},
{"f_4634chicken.scm",(void*)f_4634},
{"f_4650chicken.scm",(void*)f_4650},
{"f_4669chicken.scm",(void*)f_4669},
{"f_4725chicken.scm",(void*)f_4725},
{"f_4736chicken.scm",(void*)f_4736},
{"f_4654chicken.scm",(void*)f_4654},
{"f_4667chicken.scm",(void*)f_4667},
{"f_4640chicken.scm",(void*)f_4640},
{"f_4648chicken.scm",(void*)f_4648},
{"f_4638chicken.scm",(void*)f_4638},
{"f_4608chicken.scm",(void*)f_4608},
{"f_975chicken.scm",(void*)f_975},
{"f_4483chicken.scm",(void*)f_4483},
{"f_4523chicken.scm",(void*)f_4523},
{"f_4493chicken.scm",(void*)f_4493},
{"f_978chicken.scm",(void*)f_978},
{"f_4407chicken.scm",(void*)f_4407},
{"f_4411chicken.scm",(void*)f_4411},
{"f_4414chicken.scm",(void*)f_4414},
{"f_981chicken.scm",(void*)f_981},
{"f_4223chicken.scm",(void*)f_4223},
{"f_4227chicken.scm",(void*)f_4227},
{"f_4230chicken.scm",(void*)f_4230},
{"f_4373chicken.scm",(void*)f_4373},
{"f_4369chicken.scm",(void*)f_4369},
{"f_4232chicken.scm",(void*)f_4232},
{"f_4320chicken.scm",(void*)f_4320},
{"f_4318chicken.scm",(void*)f_4318},
{"f_4288chicken.scm",(void*)f_4288},
{"f_4255chicken.scm",(void*)f_4255},
{"f_984chicken.scm",(void*)f_984},
{"f_4033chicken.scm",(void*)f_4033},
{"f_4040chicken.scm",(void*)f_4040},
{"f_4214chicken.scm",(void*)f_4214},
{"f_4212chicken.scm",(void*)f_4212},
{"f_4065chicken.scm",(void*)f_4065},
{"f_4091chicken.scm",(void*)f_4091},
{"f_4119chicken.scm",(void*)f_4119},
{"f_4103chicken.scm",(void*)f_4103},
{"f_4063chicken.scm",(void*)f_4063},
{"f_987chicken.scm",(void*)f_987},
{"f_4024chicken.scm",(void*)f_4024},
{"f_4028chicken.scm",(void*)f_4028},
{"f_990chicken.scm",(void*)f_990},
{"f_4005chicken.scm",(void*)f_4005},
{"f_4009chicken.scm",(void*)f_4009},
{"f_4018chicken.scm",(void*)f_4018},
{"f_4016chicken.scm",(void*)f_4016},
{"f_993chicken.scm",(void*)f_993},
{"f_3986chicken.scm",(void*)f_3986},
{"f_3990chicken.scm",(void*)f_3990},
{"f_3999chicken.scm",(void*)f_3999},
{"f_3997chicken.scm",(void*)f_3997},
{"f_996chicken.scm",(void*)f_996},
{"f_3858chicken.scm",(void*)f_3858},
{"f_3864chicken.scm",(void*)f_3864},
{"f_3945chicken.scm",(void*)f_3945},
{"f_3874chicken.scm",(void*)f_3874},
{"f_3877chicken.scm",(void*)f_3877},
{"f_3883chicken.scm",(void*)f_3883},
{"f_3890chicken.scm",(void*)f_3890},
{"f_3906chicken.scm",(void*)f_3906},
{"f_999chicken.scm",(void*)f_999},
{"f_3715chicken.scm",(void*)f_3715},
{"f_3721chicken.scm",(void*)f_3721},
{"f_3833chicken.scm",(void*)f_3833},
{"f_3806chicken.scm",(void*)f_3806},
{"f_3731chicken.scm",(void*)f_3731},
{"f_3734chicken.scm",(void*)f_3734},
{"f_3740chicken.scm",(void*)f_3740},
{"f_3751chicken.scm",(void*)f_3751},
{"f_3767chicken.scm",(void*)f_3767},
{"f_1002chicken.scm",(void*)f_1002},
{"f_3656chicken.scm",(void*)f_3656},
{"f_1005chicken.scm",(void*)f_1005},
{"f_3485chicken.scm",(void*)f_3485},
{"f_3491chicken.scm",(void*)f_3491},
{"f_3565chicken.scm",(void*)f_3565},
{"f_3568chicken.scm",(void*)f_3568},
{"f_3641chicken.scm",(void*)f_3641},
{"f_3634chicken.scm",(void*)f_3634},
{"f_3626chicken.scm",(void*)f_3626},
{"f_3613chicken.scm",(void*)f_3613},
{"f_3592chicken.scm",(void*)f_3592},
{"f_3501chicken.scm",(void*)f_3501},
{"f_1008chicken.scm",(void*)f_1008},
{"f_3434chicken.scm",(void*)f_3434},
{"f_1011chicken.scm",(void*)f_1011},
{"f_3374chicken.scm",(void*)f_3374},
{"f_3384chicken.scm",(void*)f_3384},
{"f_3403chicken.scm",(void*)f_3403},
{"f_3387chicken.scm",(void*)f_3387},
{"f_1014chicken.scm",(void*)f_1014},
{"f_1017chicken.scm",(void*)f_1017},
{"f_3337chicken.scm",(void*)f_3337},
{"f_3341chicken.scm",(void*)f_3341},
{"f_1020chicken.scm",(void*)f_1020},
{"f_3318chicken.scm",(void*)f_3318},
{"f_3322chicken.scm",(void*)f_3322},
{"f_3331chicken.scm",(void*)f_3331},
{"f_3329chicken.scm",(void*)f_3329},
{"f_1023chicken.scm",(void*)f_1023},
{"f_3299chicken.scm",(void*)f_3299},
{"f_3303chicken.scm",(void*)f_3303},
{"f_3312chicken.scm",(void*)f_3312},
{"f_3310chicken.scm",(void*)f_3310},
{"f_1026chicken.scm",(void*)f_1026},
{"f_3280chicken.scm",(void*)f_3280},
{"f_3284chicken.scm",(void*)f_3284},
{"f_3293chicken.scm",(void*)f_3293},
{"f_3291chicken.scm",(void*)f_3291},
{"f_1029chicken.scm",(void*)f_1029},
{"f_3261chicken.scm",(void*)f_3261},
{"f_3265chicken.scm",(void*)f_3265},
{"f_3274chicken.scm",(void*)f_3274},
{"f_3272chicken.scm",(void*)f_3272},
{"f_1032chicken.scm",(void*)f_1032},
{"f_3242chicken.scm",(void*)f_3242},
{"f_3246chicken.scm",(void*)f_3246},
{"f_3255chicken.scm",(void*)f_3255},
{"f_3253chicken.scm",(void*)f_3253},
{"f_1035chicken.scm",(void*)f_1035},
{"f_3223chicken.scm",(void*)f_3223},
{"f_3227chicken.scm",(void*)f_3227},
{"f_3236chicken.scm",(void*)f_3236},
{"f_3234chicken.scm",(void*)f_3234},
{"f_1038chicken.scm",(void*)f_1038},
{"f_3123chicken.scm",(void*)f_3123},
{"f_3127chicken.scm",(void*)f_3127},
{"f_3182chicken.scm",(void*)f_3182},
{"f_3136chicken.scm",(void*)f_3136},
{"f_1041chicken.scm",(void*)f_1041},
{"f_2903chicken.scm",(void*)f_2903},
{"f_2907chicken.scm",(void*)f_2907},
{"f_2910chicken.scm",(void*)f_2910},
{"f_2991chicken.scm",(void*)f_2991},
{"f_3058chicken.scm",(void*)f_3058},
{"f_3056chicken.scm",(void*)f_3056},
{"f_3048chicken.scm",(void*)f_3048},
{"f_3036chicken.scm",(void*)f_3036},
{"f_2916chicken.scm",(void*)f_2916},
{"f_2942chicken.scm",(void*)f_2942},
{"f_1044chicken.scm",(void*)f_1044},
{"f_2828chicken.scm",(void*)f_2828},
{"f_2832chicken.scm",(void*)f_2832},
{"f_2901chicken.scm",(void*)f_2901},
{"f_2855chicken.scm",(void*)f_2855},
{"f_1047chicken.scm",(void*)f_1047},
{"f_2722chicken.scm",(void*)f_2722},
{"f_2822chicken.scm",(void*)f_2822},
{"f_2726chicken.scm",(void*)f_2726},
{"f_2798chicken.scm",(void*)f_2798},
{"f_2733chicken.scm",(void*)f_2733},
{"f_2739chicken.scm",(void*)f_2739},
{"f_2737chicken.scm",(void*)f_2737},
{"f_1050chicken.scm",(void*)f_1050},
{"f_2693chicken.scm",(void*)f_2693},
{"f_2697chicken.scm",(void*)f_2697},
{"f_2720chicken.scm",(void*)f_2720},
{"f_2716chicken.scm",(void*)f_2716},
{"f_1053chicken.scm",(void*)f_1053},
{"f_2680chicken.scm",(void*)f_2680},
{"f_2684chicken.scm",(void*)f_2684},
{"f_1056chicken.scm",(void*)f_1056},
{"f_1886chicken.scm",(void*)f_1886},
{"f_1890chicken.scm",(void*)f_1890},
{"f_1896chicken.scm",(void*)f_1896},
{"f_1899chicken.scm",(void*)f_1899},
{"f_1902chicken.scm",(void*)f_1902},
{"f_1905chicken.scm",(void*)f_1905},
{"f_2572chicken.scm",(void*)f_2572},
{"f_2651chicken.scm",(void*)f_2651},
{"f_2647chicken.scm",(void*)f_2647},
{"f_2582chicken.scm",(void*)f_2582},
{"f_2586chicken.scm",(void*)f_2586},
{"f_2627chicken.scm",(void*)f_2627},
{"f_2617chicken.scm",(void*)f_2617},
{"f_2607chicken.scm",(void*)f_2607},
{"f_2603chicken.scm",(void*)f_2603},
{"f_2589chicken.scm",(void*)f_2589},
{"f_1993chicken.scm",(void*)f_1993},
{"f_1996chicken.scm",(void*)f_1996},
{"f_2566chicken.scm",(void*)f_2566},
{"f_2495chicken.scm",(void*)f_2495},
{"f_2501chicken.scm",(void*)f_2501},
{"f_2555chicken.scm",(void*)f_2555},
{"f_2547chicken.scm",(void*)f_2547},
{"f_2530chicken.scm",(void*)f_2530},
{"f_2518chicken.scm",(void*)f_2518},
{"f_2499chicken.scm",(void*)f_2499},
{"f_2483chicken.scm",(void*)f_2483},
{"f_2479chicken.scm",(void*)f_2479},
{"f_2007chicken.scm",(void*)f_2007},
{"f_2461chicken.scm",(void*)f_2461},
{"f_2015chicken.scm",(void*)f_2015},
{"f_2023chicken.scm",(void*)f_2023},
{"f_2029chicken.scm",(void*)f_2029},
{"f_2306chicken.scm",(void*)f_2306},
{"f_2418chicken.scm",(void*)f_2418},
{"f_2414chicken.scm",(void*)f_2414},
{"f_2383chicken.scm",(void*)f_2383},
{"f_2406chicken.scm",(void*)f_2406},
{"f_2395chicken.scm",(void*)f_2395},
{"f_2324chicken.scm",(void*)f_2324},
{"f_2369chicken.scm",(void*)f_2369},
{"f_2365chicken.scm",(void*)f_2365},
{"f_2341chicken.scm",(void*)f_2341},
{"f_2353chicken.scm",(void*)f_2353},
{"f_2321chicken.scm",(void*)f_2321},
{"f_2051chicken.scm",(void*)f_2051},
{"f_2291chicken.scm",(void*)f_2291},
{"f_2287chicken.scm",(void*)f_2287},
{"f_2192chicken.scm",(void*)f_2192},
{"f_2275chicken.scm",(void*)f_2275},
{"f_2264chicken.scm",(void*)f_2264},
{"f_2069chicken.scm",(void*)f_2069},
{"f_2178chicken.scm",(void*)f_2178},
{"f_2174chicken.scm",(void*)f_2174},
{"f_2086chicken.scm",(void*)f_2086},
{"f_2158chicken.scm",(void*)f_2158},
{"f_2066chicken.scm",(void*)f_2066},
{"f_2027chicken.scm",(void*)f_2027},
{"f_2019chicken.scm",(void*)f_2019},
{"f_2011chicken.scm",(void*)f_2011},
{"f_2003chicken.scm",(void*)f_2003},
{"f_1950chicken.scm",(void*)f_1950},
{"f_1966chicken.scm",(void*)f_1966},
{"f_1907chicken.scm",(void*)f_1907},
{"f_1059chicken.scm",(void*)f_1059},
{"f_1872chicken.scm",(void*)f_1872},
{"f_1062chicken.scm",(void*)f_1062},
{"f_1532chicken.scm",(void*)f_1532},
{"f_1536chicken.scm",(void*)f_1536},
{"f_1539chicken.scm",(void*)f_1539},
{"f_1844chicken.scm",(void*)f_1844},
{"f_1542chicken.scm",(void*)f_1542},
{"f_1819chicken.scm",(void*)f_1819},
{"f_1545chicken.scm",(void*)f_1545},
{"f_1787chicken.scm",(void*)f_1787},
{"f_1548chicken.scm",(void*)f_1548},
{"f_1761chicken.scm",(void*)f_1761},
{"f_1551chicken.scm",(void*)f_1551},
{"f_1554chicken.scm",(void*)f_1554},
{"f_1749chicken.scm",(void*)f_1749},
{"f_1557chicken.scm",(void*)f_1557},
{"f_1745chicken.scm",(void*)f_1745},
{"f_1560chicken.scm",(void*)f_1560},
{"f_1733chicken.scm",(void*)f_1733},
{"f_1741chicken.scm",(void*)f_1741},
{"f_1571chicken.scm",(void*)f_1571},
{"f_1695chicken.scm",(void*)f_1695},
{"f_1677chicken.scm",(void*)f_1677},
{"f_1673chicken.scm",(void*)f_1673},
{"f_1613chicken.scm",(void*)f_1613},
{"f_1603chicken.scm",(void*)f_1603},
{"f_1599chicken.scm",(void*)f_1599},
{"f_1567chicken.scm",(void*)f_1567},
{"f_1065chicken.scm",(void*)f_1065},
{"f_1498chicken.scm",(void*)f_1498},
{"f_1068chicken.scm",(void*)f_1068},
{"f_1436chicken.scm",(void*)f_1436},
{"f_1449chicken.scm",(void*)f_1449},
{"f_1475chicken.scm",(void*)f_1475},
{"f_1446chicken.scm",(void*)f_1446},
{"f_1439chicken.scm",(void*)f_1439},
{"f_1071chicken.scm",(void*)f_1071},
{"f_1434chicken.scm",(void*)f_1434},
{"f_1427chicken.scm",(void*)f_1427},
{"f_1423chicken.scm",(void*)f_1423},
{"f_1415chicken.scm",(void*)f_1415},
{"f_1413chicken.scm",(void*)f_1413},
{"f_1075chicken.scm",(void*)f_1075},
{"f_1204chicken.scm",(void*)f_1204},
{"f_1216chicken.scm",(void*)f_1216},
{"f_1399chicken.scm",(void*)f_1399},
{"f_1392chicken.scm",(void*)f_1392},
{"f_1355chicken.scm",(void*)f_1355},
{"f_1301chicken.scm",(void*)f_1301},
{"f_1318chicken.scm",(void*)f_1318},
{"f_1304chicken.scm",(void*)f_1304},
{"f_1238chicken.scm",(void*)f_1238},
{"f_1281chicken.scm",(void*)f_1281},
{"f_1261chicken.scm",(void*)f_1261},
{"f_1241chicken.scm",(void*)f_1241},
{"f_1208chicken.scm",(void*)f_1208},
{"f_1211chicken.scm",(void*)f_1211},
{"f_1192chicken.scm",(void*)f_1192},
{"f_1199chicken.scm",(void*)f_1199},
{"f_1184chicken.scm",(void*)f_1184},
{"f_1190chicken.scm",(void*)f_1190},
{"f_1187chicken.scm",(void*)f_1187},
{"f_1077chicken.scm",(void*)f_1077},
{"f_1083chicken.scm",(void*)f_1083},
{"f_1118chicken.scm",(void*)f_1118},
{"f_1144chicken.scm",(void*)f_1144},
{"f_1140chicken.scm",(void*)f_1140},
{"f_1097chicken.scm",(void*)f_1097},
{"f_781chicken.scm",(void*)f_781},
{"f_785chicken.scm",(void*)f_785},
{"f_822chicken.scm",(void*)f_822},
{"f_843chicken.scm",(void*)f_843},
{"f_841chicken.scm",(void*)f_841},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
