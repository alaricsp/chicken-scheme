/* Generated from eval.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2007-12-23 00:16
   Version 2.737 - macosx-unix-gnu-ppc	[ manyargs dload ptables applyhook ]
(c)2000-2007 Felix L. Winkelmann	compiled 2007-12-09 on o317b.o.pppool.de (Darwin)
   command line: eval.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file eval.c
   unit: eval
*/

#include "chicken.h"


#ifndef C_INSTALL_EGG_HOME
# define C_INSTALL_EGG_HOME    "."
#endif

#ifndef C_INSTALL_SHARE_HOME
# define C_INSTALL_SHARE_HOME NULL
#endif


#define C_store_result(x, ptr)   (*((C_word *)C_block_item(ptr, 0)) = (x), C_SCHEME_TRUE)


#define C_copy_result_string(str, buf, n)  (C_memcpy((char *)C_block_item(buf, 0), C_c_string(str), C_unfix(n)), ((char *)C_block_item(buf, 0))[ C_unfix(n) ] = '\0', C_SCHEME_TRUE)


C_externexport  void  CHICKEN_get_error_message(char *t0,int t1);

C_externexport  int  CHICKEN_load(char * t0);

C_externexport  int  CHICKEN_read(char * t0,C_word *t1);

C_externexport  int  CHICKEN_apply_to_string(C_word t0,C_word t1,char *t2,int t3);

C_externexport  int  CHICKEN_apply(C_word t0,C_word t1,C_word *t2);

C_externexport  int  CHICKEN_eval_string_to_string(char * t0,char *t1,int t2);

C_externexport  int  CHICKEN_eval_to_string(C_word t0,char *t1,int t2);

C_externexport  int  CHICKEN_eval_string(char * t0,C_word *t1);

C_externexport  int  CHICKEN_eval(C_word t0,C_word *t1);

C_externexport  int  CHICKEN_yield();

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[878];


/* from ##sys#clear-trace-buffer in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static C_word C_fcall stub1314(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1314(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_clear_trace_buffer();
return C_r;}

C_noret_decl(C_eval_toplevel)
C_externexport void C_ccall C_eval_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1711)
static void C_ccall f_1711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11074)
static void C_ccall f_11074(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_11074)
static void C_ccall f_11074r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_11078)
static void C_fcall f_11078(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11102)
static void C_ccall f_11102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11096)
static void C_ccall f_11096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11086)
static void C_ccall f_11086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11084)
static void C_ccall f_11084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5927)
static void C_ccall f_5927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6026)
static void C_ccall f_6026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6106)
static void C_ccall f_6106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11068)
static void C_ccall f_11068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11064)
static void C_ccall f_11064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11060)
static void C_ccall f_11060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11056)
static void C_ccall f_11056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11046)
static void C_fcall f_11046(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6642)
static void C_fcall f_6642(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6647)
static void C_ccall f_6647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11024)
static void C_ccall f_11024(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11016)
static void C_ccall f_11016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11018)
static void C_ccall f_11018(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6654)
static void C_ccall f_6654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11006)
static void C_ccall f_11006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11009)
static void C_ccall f_11009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7007)
static void C_ccall f_7007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10952)
static void C_ccall f_10952(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10966)
static void C_fcall f_10966(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11002)
static void C_ccall f_11002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10998)
static void C_ccall f_10998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10986)
static void C_ccall f_10986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10990)
static void C_ccall f_10990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10960)
static void C_ccall f_10960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7733)
static void C_ccall f_7733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10831)
static void C_ccall f_10831(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10868)
static void C_fcall f_10868(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10877)
static void C_ccall f_10877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10896)
static void C_ccall f_10896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10900)
static void C_ccall f_10900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10886)
static void C_ccall f_10886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10883)
static void C_ccall f_10883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10834)
static void C_fcall f_10834(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7736)
static void C_ccall f_7736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7794)
static void C_ccall f_7794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10829)
static void C_ccall f_10829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8129)
static void C_ccall f_8129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8133)
static void C_ccall f_8133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10825)
static void C_ccall f_10825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8136)
static void C_ccall f_8136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8140)
static void C_ccall f_8140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10728)
static void C_ccall f_10728(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10734)
static void C_fcall f_10734(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10750)
static void C_ccall f_10750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10753)
static void C_ccall f_10753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10788)
static void C_ccall f_10788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10791)
static void C_ccall f_10791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10775)
static void C_ccall f_10775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10778)
static void C_ccall f_10778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10785)
static void C_ccall f_10785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8830)
static void C_ccall f_8830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10700)
static void C_ccall f_10700(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8833)
static void C_ccall f_8833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10657)
static void C_ccall f_10657(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10679)
static void C_ccall f_10679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8836)
static void C_ccall f_8836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10460)
static void C_ccall f_10460(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10466)
static void C_fcall f_10466(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10482)
static void C_ccall f_10482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10558)
static void C_fcall f_10558(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10615)
static void C_ccall f_10615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10561)
static void C_ccall f_10561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10588)
static void C_ccall f_10588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10521)
static void C_ccall f_10521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10540)
static void C_ccall f_10540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10512)
static void C_ccall f_10512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8839)
static void C_ccall f_8839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10357)
static void C_ccall f_10357(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10367)
static void C_ccall f_10367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10380)
static void C_fcall f_10380(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10396)
static void C_ccall f_10396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10434)
static void C_ccall f_10434(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10432)
static void C_ccall f_10432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10424)
static void C_ccall f_10424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10378)
static void C_ccall f_10378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8842)
static void C_ccall f_8842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10304)
static void C_ccall f_10304(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10314)
static void C_ccall f_10314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10317)
static void C_ccall f_10317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10322)
static void C_fcall f_10322(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10347)
static void C_ccall f_10347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8845)
static void C_ccall f_8845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10234)
static void C_ccall f_10234(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10244)
static void C_ccall f_10244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10247)
static void C_ccall f_10247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10294)
static void C_ccall f_10294(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10258)
static void C_ccall f_10258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10280)
static void C_ccall f_10280(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10266)
static void C_ccall f_10266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10262)
static void C_ccall f_10262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8848)
static void C_ccall f_8848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10115)
static void C_ccall f_10115(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_10115)
static void C_ccall f_10115r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_10119)
static void C_ccall f_10119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10122)
static void C_ccall f_10122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10125)
static void C_ccall f_10125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10216)
static void C_ccall f_10216(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10132)
static void C_ccall f_10132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10155)
static void C_fcall f_10155(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10169)
static void C_ccall f_10169(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10167)
static void C_ccall f_10167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8851)
static void C_ccall f_8851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9823)
static void C_ccall f_9823(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10033)
static void C_fcall f_10033(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10037)
static void C_ccall f_10037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10058)
static void C_ccall f_10058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10100)
static void C_ccall f_10100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9836)
static void C_fcall f_9836(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10024)
static void C_ccall f_10024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10028)
static void C_ccall f_10028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10007)
static void C_ccall f_10007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10011)
static void C_ccall f_10011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9996)
static void C_ccall f_9996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9988)
static void C_ccall f_9988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9977)
static void C_ccall f_9977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9943)
static void C_ccall f_9943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9924)
static void C_ccall f_9924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9897)
static void C_ccall f_9897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9854)
static void C_ccall f_9854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9850)
static void C_ccall f_9850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9826)
static void C_fcall f_9826(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9834)
static void C_ccall f_9834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8854)
static void C_ccall f_8854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9813)
static void C_ccall f_9813(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8857)
static void C_ccall f_8857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8861)
static void C_ccall f_8861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9810)
static void C_ccall f_9810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8883)
static void C_ccall f_8883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9243)
static void C_ccall f_9243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9668)
static void C_ccall f_9668(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9668)
static void C_ccall f_9668r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9786)
static void C_ccall f_9786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9789)
static void C_ccall f_9789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9776)
static void C_ccall f_9776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9671)
static void C_fcall f_9671(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9675)
static void C_fcall f_9675(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9686)
static void C_fcall f_9686(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9329)
static void C_ccall f_9329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9649)
static void C_ccall f_9649(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9649)
static void C_ccall f_9649r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_9653)
static void C_ccall f_9653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9662)
static void C_ccall f_9662(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9660)
static void C_ccall f_9660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9332)
static void C_ccall f_9332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9643)
static void C_ccall f_9643(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9335)
static void C_ccall f_9335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9637)
static void C_ccall f_9637(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9338)
static void C_ccall f_9338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9628)
static void C_ccall f_9628(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9635)
static void C_ccall f_9635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9618)
static void C_ccall f_9618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9603)
static void C_ccall f_9603(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9607)
static void C_ccall f_9607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9612)
static void C_ccall f_9612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9616)
static void C_ccall f_9616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9581)
static void C_ccall f_9581(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9585)
static void C_ccall f_9585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9590)
static void C_ccall f_9590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9594)
static void C_ccall f_9594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9601)
static void C_ccall f_9601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9555)
static void C_ccall f_9555(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9561)
static void C_ccall f_9561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9565)
static void C_ccall f_9565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9579)
static void C_ccall f_9579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9568)
static void C_ccall f_9568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9575)
static void C_ccall f_9575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9539)
static void C_ccall f_9539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9545)
static void C_ccall f_9545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9553)
static void C_ccall f_9553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9502)
static void C_ccall f_9502(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9506)
static void C_ccall f_9506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9511)
static void C_ccall f_9511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9515)
static void C_ccall f_9515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9537)
static void C_ccall f_9537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9533)
static void C_ccall f_9533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9529)
static void C_ccall f_9529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9518)
static void C_ccall f_9518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9525)
static void C_ccall f_9525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9476)
static void C_ccall f_9476(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9482)
static void C_ccall f_9482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9486)
static void C_ccall f_9486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9500)
static void C_ccall f_9500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9489)
static void C_ccall f_9489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9496)
static void C_ccall f_9496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9463)
static C_word C_fcall f_9463(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_9437)
static void C_ccall f_9437(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9441)
static void C_ccall f_9441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9446)
static void C_ccall f_9446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9450)
static void C_ccall f_9450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9461)
static void C_ccall f_9461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9457)
static void C_ccall f_9457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9421)
static void C_ccall f_9421(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9427)
static void C_ccall f_9427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9435)
static void C_ccall f_9435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9409)
static void C_ccall f_9409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9415)
static void C_ccall f_9415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9419)
static void C_ccall f_9419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9400)
static void C_fcall f_9400(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9404)
static void C_ccall f_9404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9341)
static void C_fcall f_9341(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9351)
static void C_ccall f_9351(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9376)
static void C_ccall f_9376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9388)
static void C_ccall f_9388(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9388)
static void C_ccall f_9388r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_9394)
static void C_ccall f_9394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9382)
static void C_ccall f_9382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9357)
static void C_ccall f_9357(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9363)
static void C_ccall f_9363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9367)
static void C_ccall f_9367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9370)
static void C_ccall f_9370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9374)
static void C_ccall f_9374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9349)
static void C_ccall f_9349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9254)
static void C_ccall f_9254(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9264)
static void C_ccall f_9264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9267)
static void C_ccall f_9267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9281)
static void C_fcall f_9281(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9299)
static void C_ccall f_9299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9268)
static void C_fcall f_9268(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9245)
static void C_ccall f_9245(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8904)
static void C_ccall f_8904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8948)
static void C_ccall f_8948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8951)
static void C_ccall f_8951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9228)
static void C_ccall f_9228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9232)
static void C_ccall f_9232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9236)
static void C_ccall f_9236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9033)
static void C_ccall f_9033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9039)
static void C_fcall f_9039(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9211)
static void C_ccall f_9211(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9217)
static void C_ccall f_9217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9046)
static void C_ccall f_9046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9049)
static void C_ccall f_9049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9052)
static void C_ccall f_9052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9206)
static void C_ccall f_9206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9061)
static void C_ccall f_9061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9064)
static void C_ccall f_9064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9079)
static void C_ccall f_9079(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9079)
static void C_ccall f_9079r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_9097)
static void C_fcall f_9097(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9193)
static void C_ccall f_9193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9189)
static void C_ccall f_9189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9160)
static void C_ccall f_9160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9113)
static void C_ccall f_9113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9118)
static void C_ccall f_9118(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9122)
static void C_ccall f_9122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9125)
static void C_ccall f_9125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9137)
static void C_ccall f_9137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9140)
static void C_ccall f_9140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9128)
static void C_ccall f_9128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9101)
static void C_ccall f_9101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9083)
static void C_ccall f_9083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8929)
static void C_fcall f_8929(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8934)
static void C_ccall f_8934(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9086)
static void C_ccall f_9086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9070)
static void C_ccall f_9070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8968)
static void C_ccall f_8968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8973)
static void C_ccall f_8973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8976)
static void C_ccall f_8976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8981)
static void C_ccall f_8981(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8981)
static void C_ccall f_8981r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8988)
static void C_ccall f_8988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9028)
static void C_ccall f_9028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8991)
static void C_ccall f_8991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9003)
static void C_fcall f_9003(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9012)
static void C_ccall f_9012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9006)
static void C_ccall f_9006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8994)
static void C_ccall f_8994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8997)
static void C_ccall f_8997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8959)
static C_word C_fcall f_8959(C_word t0);
C_noret_decl(f_8953)
static C_word C_fcall f_8953(C_word t0);
C_noret_decl(f_8907)
static void C_fcall f_8907(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8913)
static void C_ccall f_8913(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8901)
static void C_ccall f_8901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8885)
static void C_ccall f_8885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8899)
static void C_ccall f_8899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8896)
static void C_ccall f_8896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8889)
static void C_ccall f_8889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8866)
static void C_ccall f_8866(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8875)
static void C_ccall f_8875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8870)
static void C_ccall f_8870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8438)
static void C_ccall f_8438(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_8438)
static void C_ccall f_8438r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_8575)
static void C_fcall f_8575(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8580)
static void C_fcall f_8580(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8798)
static void C_ccall f_8798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8779)
static void C_ccall f_8779(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8725)
static void C_ccall f_8725(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8596)
static void C_fcall f_8596(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8601)
static void C_fcall f_8601(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8620)
static void C_ccall f_8620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8546)
static void C_ccall f_8546(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8552)
static C_word C_fcall f_8552(C_word t0);
C_noret_decl(f_8484)
static void C_ccall f_8484(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8488)
static void C_ccall f_8488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8496)
static void C_fcall f_8496(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8519)
static void C_ccall f_8519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8441)
static void C_fcall f_8441(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8448)
static void C_ccall f_8448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8453)
static void C_fcall f_8453(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8457)
static void C_ccall f_8457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8482)
static void C_ccall f_8482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8471)
static void C_ccall f_8471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8475)
static void C_ccall f_8475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8464)
static void C_ccall f_8464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8402)
static void C_ccall f_8402(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8424)
static void C_ccall f_8424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8394)
static void C_ccall f_8394(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8394)
static void C_ccall f_8394r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8340)
static void C_ccall f_8340(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8344)
static void C_ccall f_8344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8347)
static void C_ccall f_8347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8350)
static void C_ccall f_8350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8353)
static void C_ccall f_8353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8356)
static void C_ccall f_8356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8359)
static void C_ccall f_8359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8362)
static void C_ccall f_8362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8365)
static void C_ccall f_8365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8368)
static void C_ccall f_8368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8319)
static void C_fcall f_8319(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8323)
static void C_ccall f_8323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8326)
static void C_ccall f_8326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8295)
static void C_fcall f_8295(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8301)
static void C_fcall f_8301(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8311)
static void C_ccall f_8311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8165)
static void C_ccall f_8165(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_8165)
static void C_ccall f_8165r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_8169)
static void C_ccall f_8169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8223)
static void C_ccall f_8223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8274)
static void C_ccall f_8274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8233)
static void C_ccall f_8233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8235)
static void C_fcall f_8235(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8259)
static void C_ccall f_8259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8245)
static void C_ccall f_8245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8206)
static void C_fcall f_8206(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8171)
static void C_fcall f_8171(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8187)
static void C_ccall f_8187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8193)
static void C_ccall f_8193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8184)
static void C_ccall f_8184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8146)
static void C_fcall f_8146(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8150)
static void C_ccall f_8150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8113)
static void C_fcall f_8113(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8115)
static void C_ccall f_8115(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8119)
static void C_ccall f_8119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8075)
static void C_ccall f_8075(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8075)
static void C_ccall f_8075r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8082)
static void C_ccall f_8082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8089)
static void C_ccall f_8089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8031)
static void C_ccall f_8031(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8031)
static void C_ccall f_8031r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8064)
static void C_ccall f_8064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8051)
static void C_ccall f_8051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8028)
static void C_ccall f_8028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7909)
static void C_ccall f_7909(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7909)
static void C_ccall f_7909r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8003)
static void C_ccall f_8003(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8013)
static void C_ccall f_8013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8001)
static void C_ccall f_8001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7930)
static void C_fcall f_7930(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7954)
static void C_fcall f_7954(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7973)
static void C_ccall f_7973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7948)
static void C_ccall f_7948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7801)
static void C_ccall f_7801(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_7801)
static void C_ccall f_7801r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_7811)
static void C_ccall f_7811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7816)
static void C_fcall f_7816(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7843)
static void C_fcall f_7843(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7876)
static void C_ccall f_7876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7837)
static void C_ccall f_7837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7738)
static void C_ccall f_7738(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7742)
static void C_ccall f_7742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7750)
static void C_fcall f_7750(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7770)
static void C_fcall f_7770(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7694)
static void C_ccall f_7694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7726)
static void C_ccall f_7726(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7712)
static void C_ccall f_7712(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7295)
static void C_ccall f_7295(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7570)
static void C_fcall f_7570(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7579)
static void C_ccall f_7579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7605)
static void C_ccall f_7605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7607)
static void C_fcall f_7607(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7640)
static void C_ccall f_7640(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7630)
static void C_ccall f_7630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7625)
static void C_ccall f_7625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7319)
static void C_fcall f_7319(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7329)
static void C_ccall f_7329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7463)
static void C_ccall f_7463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7544)
static void C_ccall f_7544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7475)
static void C_ccall f_7475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7490)
static void C_fcall f_7490(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7510)
static void C_ccall f_7510(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7508)
static void C_ccall f_7508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7494)
static void C_fcall f_7494(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7486)
static void C_ccall f_7486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7405)
static void C_ccall f_7405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7423)
static void C_fcall f_7423(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7431)
static void C_fcall f_7431(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7419)
static void C_ccall f_7419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7378)
static void C_fcall f_7378(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7341)
static void C_ccall f_7341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7365)
static void C_ccall f_7365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7361)
static void C_ccall f_7361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7353)
static void C_ccall f_7353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7344)
static void C_fcall f_7344(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7298)
static void C_fcall f_7298(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7313)
static void C_ccall f_7313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7307)
static void C_ccall f_7307(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7246)
static void C_ccall f_7246(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7252)
static void C_fcall f_7252(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7266)
static void C_ccall f_7266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7269)
static void C_fcall f_7269(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7276)
static void C_ccall f_7276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7240)
static void C_ccall f_7240(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7209)
static void C_ccall f_7209(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7213)
static void C_ccall f_7213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7238)
static void C_ccall f_7238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7216)
static void C_ccall f_7216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7234)
static void C_ccall f_7234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7219)
static void C_ccall f_7219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7226)
static void C_ccall f_7226(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7196)
static void C_ccall f_7196(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7196)
static void C_ccall f_7196r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7202)
static void C_ccall f_7202(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7182)
static void C_ccall f_7182(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7193)
static void C_ccall f_7193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7162)
static void C_ccall f_7162(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7162)
static void C_ccall f_7162r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7168)
static void C_ccall f_7168(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7175)
static void C_ccall f_7175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7087)
static void C_ccall f_7087(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7087)
static void C_ccall f_7087r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7157)
static void C_ccall f_7157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7091)
static void C_fcall f_7091(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7094)
static void C_ccall f_7094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7112)
static void C_ccall f_7112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7128)
static void C_ccall f_7128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7118)
static void C_ccall f_7118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7010)
static void C_ccall f_7010(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7084)
static void C_ccall f_7084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7077)
static void C_ccall f_7077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7044)
static void C_ccall f_7044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7046)
static void C_fcall f_7046(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7059)
static void C_ccall f_7059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7013)
static void C_fcall f_7013(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7017)
static void C_ccall f_7017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7037)
static void C_ccall f_7037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7023)
static void C_ccall f_7023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7033)
static void C_ccall f_7033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7026)
static void C_ccall f_7026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6847)
static void C_ccall f_6847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6952)
static void C_fcall f_6952(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6969)
static void C_ccall f_6969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6977)
static void C_ccall f_6977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6869)
static void C_ccall f_6869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6874)
static void C_fcall f_6874(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6913)
static void C_ccall f_6913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6900)
static void C_ccall f_6900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6856)
static C_word C_fcall f_6856(C_word t0);
C_noret_decl(f_6850)
static void C_fcall f_6850(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6791)
static void C_ccall f_6791(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6800)
static void C_fcall f_6800(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6838)
static void C_ccall f_6838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6818)
static void C_ccall f_6818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6762)
static void C_ccall f_6762(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6762)
static void C_ccall f_6762r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6769)
static void C_ccall f_6769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6779)
static void C_ccall f_6779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6656)
static void C_ccall f_6656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6660)
static void C_ccall f_6660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6752)
static void C_ccall f_6752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6756)
static void C_ccall f_6756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6669)
static void C_fcall f_6669(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6738)
static void C_ccall f_6738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6734)
static void C_ccall f_6734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6672)
static void C_ccall f_6672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6721)
static void C_ccall f_6721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6724)
static void C_ccall f_6724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6727)
static void C_ccall f_6727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6675)
static void C_ccall f_6675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6680)
static void C_fcall f_6680(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6714)
static void C_ccall f_6714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6693)
static void C_ccall f_6693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6696)
static void C_fcall f_6696(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6616)
static void C_ccall f_6616(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6616)
static void C_ccall f_6616r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6637)
static void C_ccall f_6637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6620)
static void C_ccall f_6620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6634)
static void C_ccall f_6634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6623)
static void C_ccall f_6623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6631)
static void C_ccall f_6631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6626)
static void C_ccall f_6626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6573)
static void C_ccall f_6573(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6573)
static void C_ccall f_6573r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6581)
static void C_ccall f_6581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6585)
static void C_ccall f_6585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6544)
static void C_ccall f_6544(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6544)
static void C_ccall f_6544r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6552)
static void C_ccall f_6552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6154)
static void C_ccall f_6154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6154)
static void C_ccall f_6154r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6496)
static void C_fcall f_6496(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6491)
static void C_fcall f_6491(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6156)
static void C_fcall f_6156(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6490)
static void C_ccall f_6490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6160)
static void C_fcall f_6160(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6424)
static void C_ccall f_6424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6439)
static void C_ccall f_6439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6442)
static void C_fcall f_6442(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6445)
static void C_ccall f_6445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6451)
static void C_ccall f_6451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6454)
static void C_ccall f_6454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6460)
static void C_ccall f_6460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6163)
static void C_ccall f_6163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6415)
static void C_ccall f_6415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6406)
static void C_ccall f_6406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6409)
static void C_ccall f_6409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6169)
static void C_ccall f_6169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6391)
static void C_ccall f_6391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6363)
static void C_ccall f_6363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6387)
static void C_ccall f_6387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6383)
static void C_ccall f_6383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6379)
static void C_ccall f_6379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6172)
static void C_ccall f_6172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6180)
static void C_ccall f_6180(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6350)
static void C_ccall f_6350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6184)
static void C_ccall f_6184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6335)
static void C_ccall f_6335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6208)
static void C_ccall f_6208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6212)
static void C_ccall f_6212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6326)
static void C_ccall f_6326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6220)
static void C_ccall f_6220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6224)
static void C_ccall f_6224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6320)
static void C_ccall f_6320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6227)
static void C_ccall f_6227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6230)
static void C_ccall f_6230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6235)
static void C_fcall f_6235(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6245)
static void C_ccall f_6245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6291)
static void C_ccall f_6291(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6291)
static void C_ccall f_6291r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6300)
static void C_ccall f_6300(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6304)
static void C_ccall f_6304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6257)
static void C_ccall f_6257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6264)
static void C_ccall f_6264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6275)
static void C_ccall f_6275(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6275)
static void C_ccall f_6275r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6286)
static void C_ccall f_6286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6279)
static void C_ccall f_6279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6269)
static void C_ccall f_6269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6248)
static void C_ccall f_6248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6255)
static void C_ccall f_6255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6217)
static void C_ccall f_6217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6194)
static void C_ccall f_6194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6185)
static void C_ccall f_6185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6175)
static void C_ccall f_6175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6108)
static void C_fcall f_6108(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6118)
static C_word C_fcall f_6118(C_word t0,C_word t1);
C_noret_decl(f_6033)
static void C_ccall f_6033(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6045)
static void C_fcall f_6045(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6058)
static void C_ccall f_6058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6040)
static void C_ccall f_6040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6028)
static void C_ccall f_6028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5944)
static void C_ccall f_5944(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5957)
static void C_fcall f_5957(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5990)
static void C_ccall f_5990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5971)
static void C_ccall f_5971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5947)
static void C_fcall f_5947(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5930)
static void C_ccall f_5930(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5930)
static void C_ccall f_5930r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5938)
static void C_ccall f_5938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5942)
static void C_ccall f_5942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3684)
static void C_ccall f_3684(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3684)
static void C_ccall f_3684r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5904)
static void C_ccall f_5904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5668)
static void C_fcall f_5668(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5672)
static void C_ccall f_5672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5885)
static void C_ccall f_5885(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5861)
static void C_ccall f_5861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5862)
static void C_ccall f_5862(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5873)
static void C_ccall f_5873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5879)
static void C_ccall f_5879(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5877)
static void C_ccall f_5877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5818)
static void C_ccall f_5818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5821)
static void C_ccall f_5821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5824)
static void C_ccall f_5824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5827)
static void C_ccall f_5827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5828)
static void C_ccall f_5828(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5839)
static void C_ccall f_5839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5843)
static void C_ccall f_5843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5847)
static void C_ccall f_5847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5851)
static void C_ccall f_5851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5854)
static void C_ccall f_5854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5776)
static void C_ccall f_5776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5779)
static void C_ccall f_5779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5782)
static void C_ccall f_5782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5783)
static void C_ccall f_5783(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5794)
static void C_ccall f_5794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5798)
static void C_ccall f_5798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5802)
static void C_ccall f_5802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5805)
static void C_ccall f_5805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5741)
static void C_ccall f_5741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5744)
static void C_ccall f_5744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5745)
static void C_ccall f_5745(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5756)
static void C_ccall f_5756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5760)
static void C_ccall f_5760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5763)
static void C_ccall f_5763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5713)
static void C_ccall f_5713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5714)
static void C_ccall f_5714(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5725)
static void C_ccall f_5725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5728)
static void C_ccall f_5728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5694)
static void C_ccall f_5694(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5704)
static void C_ccall f_5704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5642)
static C_word C_fcall f_5642(C_word t0,C_word t1);
C_noret_decl(f_3912)
static void C_fcall f_3912(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4015)
static void C_ccall f_4015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4071)
static void C_fcall f_4071(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4100)
static void C_ccall f_4100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4106)
static void C_ccall f_4106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5475)
static void C_fcall f_5475(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5462)
static void C_ccall f_5462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5423)
static void C_ccall f_5423(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5412)
static void C_ccall f_5412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5374)
static void C_ccall f_5374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5368)
static void C_ccall f_5368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5322)
static void C_fcall f_5322(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5344)
static void C_ccall f_5344(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5352)
static void C_ccall f_5352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5334)
static void C_ccall f_5334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5342)
static void C_ccall f_5342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5316)
static void C_ccall f_5316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5292)
static void C_ccall f_5292(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5299)
static void C_ccall f_5299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5261)
static void C_ccall f_5261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5264)
static void C_ccall f_5264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5267)
static void C_ccall f_5267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5286)
static void C_ccall f_5286(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5284)
static void C_ccall f_5284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5274)
static void C_fcall f_5274(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4859)
static void C_ccall f_4859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5196)
static void C_ccall f_5196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5207)
static void C_ccall f_5207(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5201)
static void C_ccall f_5201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4871)
static void C_ccall f_4871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4876)
static void C_ccall f_4876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5185)
static void C_ccall f_5185(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5179)
static void C_ccall f_5179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4883)
static void C_ccall f_4883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5141)
static void C_ccall f_5141(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5147)
static void C_ccall f_5147(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5147)
static void C_ccall f_5147r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5171)
static void C_ccall f_5171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5118)
static void C_ccall f_5118(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5124)
static void C_ccall f_5124(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5124)
static void C_ccall f_5124r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5609)
static void C_fcall f_5609(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5140)
static void C_ccall f_5140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5136)
static void C_ccall f_5136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5096)
static void C_ccall f_5096(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5102)
static void C_ccall f_5102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5114)
static void C_ccall f_5114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5077)
static void C_ccall f_5077(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5083)
static void C_ccall f_5083(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_5083)
static void C_ccall f_5083r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_5049)
static void C_ccall f_5049(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5055)
static void C_ccall f_5055(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5036)
static void C_ccall f_5036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5036)
static void C_ccall f_5036r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5002)
static void C_ccall f_5002(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5008)
static void C_ccall f_5008(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4983)
static void C_ccall f_4983(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4989)
static void C_ccall f_4989(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4989)
static void C_ccall f_4989r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4955)
static void C_ccall f_4955(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4961)
static void C_ccall f_4961(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4936)
static void C_ccall f_4936(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4942)
static void C_ccall f_4942(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4942)
static void C_ccall f_4942r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4912)
static void C_ccall f_4912(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4918)
static void C_ccall f_4918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4893)
static void C_ccall f_4893(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4899)
static void C_ccall f_4899(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4899)
static void C_ccall f_4899r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4521)
static void C_ccall f_4521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4846)
static void C_ccall f_4846(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4530)
static void C_ccall f_4530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4840)
static void C_ccall f_4840(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4834)
static void C_ccall f_4834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4536)
static void C_ccall f_4536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4818)
static void C_ccall f_4818(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4771)
static void C_ccall f_4771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4772)
static void C_ccall f_4772(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4776)
static void C_ccall f_4776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4788)
static void C_fcall f_4788(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4813)
static void C_ccall f_4813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4779)
static void C_ccall f_4779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4764)
static void C_ccall f_4764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4695)
static void C_ccall f_4695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4756)
static void C_ccall f_4756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4698)
static void C_ccall f_4698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4748)
static void C_ccall f_4748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4704)
static void C_ccall f_4704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4740)
static void C_ccall f_4740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4707)
static void C_ccall f_4707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4708)
static void C_ccall f_4708(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4724)
static void C_ccall f_4724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4732)
static void C_ccall f_4732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4736)
static void C_ccall f_4736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4682)
static void C_ccall f_4682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4628)
static void C_ccall f_4628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4674)
static void C_ccall f_4674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4631)
static void C_ccall f_4631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4666)
static void C_ccall f_4666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4637)
static void C_ccall f_4637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4638)
static void C_ccall f_4638(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4654)
static void C_ccall f_4654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4658)
static void C_ccall f_4658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4662)
static void C_ccall f_4662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4615)
static void C_ccall f_4615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4579)
static void C_ccall f_4579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4607)
static void C_ccall f_4607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4582)
static void C_ccall f_4582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4583)
static void C_ccall f_4583(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4599)
static void C_ccall f_4599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4603)
static void C_ccall f_4603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4566)
static void C_ccall f_4566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4545)
static void C_ccall f_4545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4546)
static void C_ccall f_4546(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4562)
static void C_ccall f_4562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4412)
static void C_ccall f_4412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4426)
static void C_ccall f_4426(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4430)
static void C_ccall f_4430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4439)
static void C_ccall f_4439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4472)
static void C_ccall f_4472(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4480)
static void C_ccall f_4480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4445)
static void C_ccall f_4445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4448)
static void C_ccall f_4448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4464)
static void C_ccall f_4464(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4455)
static void C_ccall f_4455(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4463)
static void C_ccall f_4463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4500)
static void C_ccall f_4500(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4508)
static void C_ccall f_4508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4487)
static void C_ccall f_4487(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4499)
static void C_ccall f_4499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4420)
static void C_ccall f_4420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4304)
static void C_ccall f_4304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4363)
static void C_ccall f_4363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4366)
static void C_ccall f_4366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4369)
static void C_ccall f_4369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4370)
static void C_ccall f_4370(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4374)
static void C_ccall f_4374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4377)
static void C_ccall f_4377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4341)
static void C_ccall f_4341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4344)
static void C_ccall f_4344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4345)
static void C_ccall f_4345(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4349)
static void C_ccall f_4349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4247)
static void C_ccall f_4247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4250)
static void C_ccall f_4250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4253)
static void C_ccall f_4253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4256)
static void C_ccall f_4256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4257)
static void C_ccall f_4257(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4264)
static void C_ccall f_4264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4237)
static void C_ccall f_4237(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4203)
static void C_ccall f_4203(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4197)
static void C_ccall f_4197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4121)
static void C_ccall f_4121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4181)
static void C_ccall f_4181(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4179)
static void C_ccall f_4179(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4171)
static void C_ccall f_4171(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4163)
static void C_ccall f_4163(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4155)
static void C_ccall f_4155(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4147)
static void C_ccall f_4147(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4139)
static void C_ccall f_4139(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4131)
static void C_ccall f_4131(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4072)
static void C_ccall f_4072(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4061)
static void C_ccall f_4061(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4059)
static void C_ccall f_4059(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4048)
static void C_ccall f_4048(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4046)
static void C_ccall f_4046(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4038)
static void C_ccall f_4038(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4030)
static void C_ccall f_4030(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4022)
static void C_ccall f_4022(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3930)
static void C_ccall f_3930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3940)
static void C_ccall f_3940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3989)
static void C_ccall f_3989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3974)
static void C_fcall f_3974(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3969)
static void C_fcall f_3969(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3970)
static void C_ccall f_3970(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3946)
static void C_ccall f_3946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3949)
static void C_ccall f_3949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3950)
static void C_ccall f_3950(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4005)
static void C_ccall f_4005(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3996)
static void C_ccall f_3996(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3924)
static void C_ccall f_3924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3906)
static void C_fcall f_3906(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3900)
static C_word C_fcall f_3900(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3894)
static C_word C_fcall f_3894(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3841)
static void C_fcall f_3841(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3845)
static void C_ccall f_3845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3892)
static void C_ccall f_3892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3860)
static void C_fcall f_3860(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3869)
static void C_fcall f_3869(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3729)
static void C_fcall f_3729(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3741)
static void C_ccall f_3741(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3735)
static void C_ccall f_3735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3687)
static void C_fcall f_3687(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3693)
static void C_fcall f_3693(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3811)
static C_word C_fcall f_3811(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3678)
static void C_ccall f_3678(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3637)
static void C_ccall f_3637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3656)
static void C_ccall f_3656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3668)
static void C_ccall f_3668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3671)
static void C_ccall f_3671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3674)
static void C_ccall f_3674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3664)
static void C_ccall f_3664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3643)
static void C_ccall f_3643(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3577)
static void C_ccall f_3577(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3581)
static void C_ccall f_3581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3589)
static void C_fcall f_3589(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3531)
static void C_ccall f_3531(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3537)
static void C_fcall f_3537(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3556)
static void C_ccall f_3556(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3547)
static void C_ccall f_3547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3476)
static void C_ccall f_3476(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3480)
static void C_ccall f_3480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3488)
static void C_fcall f_3488(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3431)
static void C_ccall f_3431(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3435)
static void C_ccall f_3435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3444)
static C_word C_fcall f_3444(C_word t0,C_word t1);
C_noret_decl(f_3416)
static void C_ccall f_3416(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3356)
static void C_ccall f_3356(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3411)
static void C_ccall f_3411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3359)
static void C_fcall f_3359(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3265)
static void C_ccall f_3265(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3354)
static void C_ccall f_3354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3268)
static void C_fcall f_3268(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2779)
static void C_ccall f_2779(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2779)
static void C_ccall f_2779r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3217)
static void C_fcall f_3217(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3212)
static void C_fcall f_3212(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2781)
static void C_fcall f_2781(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2964)
static void C_fcall f_2964(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2970)
static void C_fcall f_2970(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3004)
static void C_ccall f_3004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3176)
static void C_ccall f_3176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3162)
static void C_ccall f_3162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3169)
static void C_ccall f_3169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3134)
static void C_ccall f_3134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3016)
static void C_ccall f_3016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3021)
static void C_fcall f_3021(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3034)
static void C_ccall f_3034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3086)
static void C_ccall f_3086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3068)
static void C_ccall f_3068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3079)
static void C_ccall f_3079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2784)
static void C_fcall f_2784(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2866)
static void C_ccall f_2866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2956)
static void C_ccall f_2956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2944)
static void C_ccall f_2944(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2877)
static void C_ccall f_2877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2942)
static void C_ccall f_2942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2934)
static void C_ccall f_2934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2885)
static void C_ccall f_2885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2928)
static void C_ccall f_2928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2932)
static void C_ccall f_2932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2895)
static void C_ccall f_2895(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2899)
static void C_ccall f_2899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2920)
static void C_ccall f_2920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2918)
static void C_ccall f_2918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2889)
static void C_ccall f_2889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2881)
static void C_ccall f_2881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2796)
static void C_fcall f_2796(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2815)
static void C_fcall f_2815(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2826)
static void C_ccall f_2826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2834)
static void C_ccall f_2834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2822)
static void C_ccall f_2822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2260)
static void C_ccall f_2260(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2282)
static void C_fcall f_2282(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2722)
static void C_fcall f_2722(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2660)
static void C_ccall f_2660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2641)
static void C_fcall f_2641(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2595)
static void C_fcall f_2595(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2598)
static void C_fcall f_2598(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2577)
static void C_ccall f_2577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2558)
static void C_fcall f_2558(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2526)
static void C_fcall f_2526(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2296)
static void C_ccall f_2296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2498)
static void C_ccall f_2498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2441)
static void C_ccall f_2441(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2494)
static void C_ccall f_2494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2468)
static void C_fcall f_2468(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2300)
static void C_fcall f_2300(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2312)
static void C_fcall f_2312(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2391)
static void C_ccall f_2391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2387)
static void C_ccall f_2387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2335)
static void C_ccall f_2335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2343)
static void C_ccall f_2343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2303)
static void C_fcall f_2303(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2263)
static void C_fcall f_2263(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2217)
static void C_ccall f_2217(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2223)
static void C_fcall f_2223(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2242)
static void C_fcall f_2242(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2201)
static void C_ccall f_2201(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2201)
static void C_ccall f_2201r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2165)
static void C_ccall f_2165(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2165)
static void C_ccall f_2165r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2174)
static void C_fcall f_2174(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2186)
static void C_ccall f_2186(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2180)
static void C_ccall f_2180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2158)
static void C_ccall f_2158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2155)
static void C_ccall f_2155(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2152)
static void C_ccall f_2152(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1782)
static void C_ccall f_1782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2092)
static void C_fcall f_2092(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2098)
static void C_ccall f_2098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2105)
static void C_ccall f_2105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2031)
static void C_ccall f_2031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2079)
static void C_ccall f_2079(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2073)
static void C_ccall f_2073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2053)
static void C_ccall f_2053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1931)
static void C_fcall f_1931(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1951)
static void C_ccall f_1951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1959)
static void C_fcall f_1959(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1785)
static void C_fcall f_1785(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1794)
static void C_ccall f_1794(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1907)
static void C_ccall f_1907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1919)
static void C_ccall f_1919(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1919)
static void C_ccall f_1919r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1925)
static void C_ccall f_1925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1913)
static void C_ccall f_1913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1800)
static void C_ccall f_1800(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1806)
static void C_ccall f_1806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1817)
static void C_fcall f_1817(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1834)
static void C_fcall f_1834(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1853)
static void C_fcall f_1853(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1864)
static void C_ccall f_1864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1828)
static void C_ccall f_1828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1814)
static void C_fcall f_1814(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1792)
static void C_ccall f_1792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1773)
static void C_ccall f_1773(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1755)
static void C_ccall f_1755(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1765)
static void C_ccall f_1765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1745)
static void C_ccall f_1745(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1729)
static void C_ccall f_1729(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1735)
static void C_ccall f_1735(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1713)
static void C_ccall f_1713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1719)
static void C_ccall f_1719(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1672)
static void C_ccall f_1672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1676)
static void C_ccall f_1676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1679)
static void C_ccall f_1679(C_word c,C_word t0,C_word t1) C_noret;

/* from CHICKEN_get_error_message */
 void  CHICKEN_get_error_message(char *t0,int t1){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer_or_false(&a,(void*)t0);
C_save(x);
x=C_fix((C_word)t1);
C_save(x);C_callback_wrapper((void *)f_9618,2);}

/* from CHICKEN_load */
 int  CHICKEN_load(char * t0){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0))),*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9603,1));}

/* from CHICKEN_read */
 int  CHICKEN_read(char * t0,C_word *t1){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9581,2));}

/* from CHICKEN_apply_to_string */
 int  CHICKEN_apply_to_string(C_word t0,C_word t1,char *t2,int t3){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=((C_word)t1);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t2);
C_save(x);
x=C_fix((C_word)t3);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9555,4));}

/* from CHICKEN_apply */
 int  CHICKEN_apply(C_word t0,C_word t1,C_word *t2){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=((C_word)t1);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9539,3));}

/* from CHICKEN_eval_string_to_string */
 int  CHICKEN_eval_string_to_string(char * t0,char *t1,int t2){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
x=C_fix((C_word)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9502,3));}

/* from CHICKEN_eval_to_string */
 int  CHICKEN_eval_to_string(C_word t0,char *t1,int t2){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
x=C_fix((C_word)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9476,3));}

/* from CHICKEN_eval_string */
 int  CHICKEN_eval_string(char * t0,C_word *t1){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9437,2));}

/* from CHICKEN_eval */
 int  CHICKEN_eval(C_word t0,C_word *t1){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9421,2));}

/* from CHICKEN_yield */
 int  CHICKEN_yield(){
C_word x,s=0,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
return C_truep(C_callback_wrapper((void *)f_9409,0));}

C_noret_decl(trf_11078)
static void C_fcall trf_11078(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11078(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11078(t0,t1);}

C_noret_decl(trf_11046)
static void C_fcall trf_11046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11046(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11046(t0,t1);}

C_noret_decl(trf_6642)
static void C_fcall trf_6642(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6642(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6642(t0,t1);}

C_noret_decl(trf_10966)
static void C_fcall trf_10966(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10966(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10966(t0,t1,t2);}

C_noret_decl(trf_10868)
static void C_fcall trf_10868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10868(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10868(t0,t1);}

C_noret_decl(trf_10834)
static void C_fcall trf_10834(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10834(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10834(t0,t1);}

C_noret_decl(trf_10734)
static void C_fcall trf_10734(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10734(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10734(t0,t1,t2);}

C_noret_decl(trf_10466)
static void C_fcall trf_10466(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10466(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10466(t0,t1,t2);}

C_noret_decl(trf_10558)
static void C_fcall trf_10558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10558(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10558(t0,t1);}

C_noret_decl(trf_10380)
static void C_fcall trf_10380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10380(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10380(t0,t1,t2);}

C_noret_decl(trf_10322)
static void C_fcall trf_10322(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10322(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10322(t0,t1,t2);}

C_noret_decl(trf_10155)
static void C_fcall trf_10155(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10155(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10155(t0,t1);}

C_noret_decl(trf_10033)
static void C_fcall trf_10033(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10033(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10033(t0,t1,t2);}

C_noret_decl(trf_9836)
static void C_fcall trf_9836(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9836(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9836(t0,t1,t2,t3);}

C_noret_decl(trf_9826)
static void C_fcall trf_9826(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9826(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9826(t0,t1,t2,t3);}

C_noret_decl(trf_9671)
static void C_fcall trf_9671(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9671(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9671(t0,t1,t2);}

C_noret_decl(trf_9675)
static void C_fcall trf_9675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9675(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9675(t0,t1);}

C_noret_decl(trf_9686)
static void C_fcall trf_9686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9686(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9686(t0,t1);}

C_noret_decl(trf_9400)
static void C_fcall trf_9400(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9400(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9400(t0,t1,t2);}

C_noret_decl(trf_9341)
static void C_fcall trf_9341(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9341(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9341(t0,t1);}

C_noret_decl(trf_9281)
static void C_fcall trf_9281(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9281(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9281(t0,t1);}

C_noret_decl(trf_9268)
static void C_fcall trf_9268(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9268(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9268(t0,t1);}

C_noret_decl(trf_9039)
static void C_fcall trf_9039(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9039(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9039(t0,t1);}

C_noret_decl(trf_9097)
static void C_fcall trf_9097(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9097(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9097(t0,t1,t2,t3);}

C_noret_decl(trf_8929)
static void C_fcall trf_8929(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8929(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8929(t0,t1);}

C_noret_decl(trf_9003)
static void C_fcall trf_9003(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9003(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9003(t0,t1);}

C_noret_decl(trf_8907)
static void C_fcall trf_8907(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8907(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8907(t0,t1);}

C_noret_decl(trf_8575)
static void C_fcall trf_8575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8575(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8575(t0,t1);}

C_noret_decl(trf_8580)
static void C_fcall trf_8580(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8580(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8580(t0,t1,t2,t3);}

C_noret_decl(trf_8596)
static void C_fcall trf_8596(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8596(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8596(t0,t1);}

C_noret_decl(trf_8601)
static void C_fcall trf_8601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8601(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8601(t0,t1,t2,t3);}

C_noret_decl(trf_8496)
static void C_fcall trf_8496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8496(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8496(t0,t1,t2);}

C_noret_decl(trf_8441)
static void C_fcall trf_8441(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8441(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8441(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8453)
static void C_fcall trf_8453(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8453(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8453(t0,t1,t2);}

C_noret_decl(trf_8319)
static void C_fcall trf_8319(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8319(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8319(t0,t1,t2,t3);}

C_noret_decl(trf_8295)
static void C_fcall trf_8295(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8295(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8295(t0,t1,t2);}

C_noret_decl(trf_8301)
static void C_fcall trf_8301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8301(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8301(t0,t1,t2);}

C_noret_decl(trf_8235)
static void C_fcall trf_8235(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8235(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8235(t0,t1,t2);}

C_noret_decl(trf_8206)
static void C_fcall trf_8206(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8206(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8206(t0,t1,t2);}

C_noret_decl(trf_8171)
static void C_fcall trf_8171(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8171(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8171(t0,t1,t2,t3);}

C_noret_decl(trf_8146)
static void C_fcall trf_8146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8146(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8146(t0,t1);}

C_noret_decl(trf_8113)
static void C_fcall trf_8113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8113(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8113(t0,t1);}

C_noret_decl(trf_7930)
static void C_fcall trf_7930(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7930(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7930(t0,t1,t2,t3);}

C_noret_decl(trf_7954)
static void C_fcall trf_7954(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7954(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7954(t0,t1,t2,t3);}

C_noret_decl(trf_7816)
static void C_fcall trf_7816(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7816(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7816(t0,t1,t2);}

C_noret_decl(trf_7843)
static void C_fcall trf_7843(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7843(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7843(t0,t1,t2);}

C_noret_decl(trf_7750)
static void C_fcall trf_7750(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7750(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7750(t0,t1,t2);}

C_noret_decl(trf_7770)
static void C_fcall trf_7770(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7770(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7770(t0,t1);}

C_noret_decl(trf_7570)
static void C_fcall trf_7570(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7570(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7570(t0,t1);}

C_noret_decl(trf_7607)
static void C_fcall trf_7607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7607(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7607(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7319)
static void C_fcall trf_7319(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7319(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7319(t0,t1,t2);}

C_noret_decl(trf_7490)
static void C_fcall trf_7490(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7490(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7490(t0,t1);}

C_noret_decl(trf_7494)
static void C_fcall trf_7494(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7494(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7494(t0,t1);}

C_noret_decl(trf_7423)
static void C_fcall trf_7423(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7423(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7423(t0,t1);}

C_noret_decl(trf_7431)
static void C_fcall trf_7431(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7431(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7431(t0,t1);}

C_noret_decl(trf_7378)
static void C_fcall trf_7378(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7378(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7378(t0,t1);}

C_noret_decl(trf_7344)
static void C_fcall trf_7344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7344(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7344(t0,t1);}

C_noret_decl(trf_7298)
static void C_fcall trf_7298(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7298(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7298(t0,t1,t2);}

C_noret_decl(trf_7252)
static void C_fcall trf_7252(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7252(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7252(t0,t1,t2);}

C_noret_decl(trf_7269)
static void C_fcall trf_7269(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7269(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7269(t0,t1);}

C_noret_decl(trf_7091)
static void C_fcall trf_7091(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7091(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7091(t0,t1);}

C_noret_decl(trf_7046)
static void C_fcall trf_7046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7046(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7046(t0,t1,t2);}

C_noret_decl(trf_7013)
static void C_fcall trf_7013(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7013(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7013(t0,t1,t2);}

C_noret_decl(trf_6952)
static void C_fcall trf_6952(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6952(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6952(t0,t1,t2);}

C_noret_decl(trf_6874)
static void C_fcall trf_6874(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6874(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6874(t0,t1,t2);}

C_noret_decl(trf_6850)
static void C_fcall trf_6850(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6850(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6850(t0,t1);}

C_noret_decl(trf_6800)
static void C_fcall trf_6800(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6800(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6800(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6669)
static void C_fcall trf_6669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6669(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6669(t0,t1);}

C_noret_decl(trf_6680)
static void C_fcall trf_6680(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6680(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6680(t0,t1,t2);}

C_noret_decl(trf_6696)
static void C_fcall trf_6696(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6696(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6696(t0,t1);}

C_noret_decl(trf_6496)
static void C_fcall trf_6496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6496(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6496(t0,t1);}

C_noret_decl(trf_6491)
static void C_fcall trf_6491(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6491(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6491(t0,t1,t2);}

C_noret_decl(trf_6156)
static void C_fcall trf_6156(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6156(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6156(t0,t1,t2,t3);}

C_noret_decl(trf_6160)
static void C_fcall trf_6160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6160(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6160(t0,t1);}

C_noret_decl(trf_6442)
static void C_fcall trf_6442(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6442(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6442(t0,t1);}

C_noret_decl(trf_6235)
static void C_fcall trf_6235(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6235(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6235(t0,t1,t2);}

C_noret_decl(trf_6108)
static void C_fcall trf_6108(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6108(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6108(t0,t1);}

C_noret_decl(trf_6045)
static void C_fcall trf_6045(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6045(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6045(t0,t1,t2);}

C_noret_decl(trf_5957)
static void C_fcall trf_5957(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5957(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5957(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5947)
static void C_fcall trf_5947(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5947(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5947(t0,t1);}

C_noret_decl(trf_5668)
static void C_fcall trf_5668(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5668(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5668(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3912)
static void C_fcall trf_3912(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3912(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3912(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_4071)
static void C_fcall trf_4071(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4071(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4071(t0,t1);}

C_noret_decl(trf_5475)
static void C_fcall trf_5475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5475(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5475(t0,t1);}

C_noret_decl(trf_5322)
static void C_fcall trf_5322(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5322(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5322(t0,t1,t2);}

C_noret_decl(trf_5274)
static void C_fcall trf_5274(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5274(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5274(t0,t1);}

C_noret_decl(trf_5609)
static void C_fcall trf_5609(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5609(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5609(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4788)
static void C_fcall trf_4788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4788(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4788(t0,t1,t2,t3);}

C_noret_decl(trf_3974)
static void C_fcall trf_3974(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3974(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3974(t0,t1);}

C_noret_decl(trf_3969)
static void C_fcall trf_3969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3969(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3969(t0,t1);}

C_noret_decl(trf_3906)
static void C_fcall trf_3906(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3906(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3906(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3841)
static void C_fcall trf_3841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3841(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3841(t0,t1,t2,t3);}

C_noret_decl(trf_3860)
static void C_fcall trf_3860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3860(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3860(t0,t1);}

C_noret_decl(trf_3869)
static void C_fcall trf_3869(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3869(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3869(t0,t1);}

C_noret_decl(trf_3729)
static void C_fcall trf_3729(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3729(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3729(t0,t1,t2,t3);}

C_noret_decl(trf_3687)
static void C_fcall trf_3687(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3687(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3687(t0,t1,t2);}

C_noret_decl(trf_3693)
static void C_fcall trf_3693(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3693(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3693(t0,t1,t2,t3);}

C_noret_decl(trf_3589)
static void C_fcall trf_3589(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3589(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3589(t0,t1,t2);}

C_noret_decl(trf_3537)
static void C_fcall trf_3537(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3537(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3537(t0,t1,t2);}

C_noret_decl(trf_3488)
static void C_fcall trf_3488(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3488(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3488(t0,t1,t2);}

C_noret_decl(trf_3359)
static void C_fcall trf_3359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3359(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3359(t0,t1,t2,t3);}

C_noret_decl(trf_3268)
static void C_fcall trf_3268(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3268(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3268(t0,t1,t2,t3);}

C_noret_decl(trf_3217)
static void C_fcall trf_3217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3217(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3217(t0,t1);}

C_noret_decl(trf_3212)
static void C_fcall trf_3212(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3212(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3212(t0,t1,t2);}

C_noret_decl(trf_2781)
static void C_fcall trf_2781(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2781(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2781(t0,t1,t2);}

C_noret_decl(trf_2964)
static void C_fcall trf_2964(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2964(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2964(t0,t1,t2);}

C_noret_decl(trf_2970)
static void C_fcall trf_2970(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2970(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2970(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3021)
static void C_fcall trf_3021(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3021(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3021(t0,t1,t2);}

C_noret_decl(trf_2784)
static void C_fcall trf_2784(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2784(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2784(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2796)
static void C_fcall trf_2796(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2796(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2796(t0,t1,t2,t3);}

C_noret_decl(trf_2815)
static void C_fcall trf_2815(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2815(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2815(t0,t1);}

C_noret_decl(trf_2282)
static void C_fcall trf_2282(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2282(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2282(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2722)
static void C_fcall trf_2722(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2722(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2722(t0,t1);}

C_noret_decl(trf_2641)
static void C_fcall trf_2641(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2641(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2641(t0,t1);}

C_noret_decl(trf_2595)
static void C_fcall trf_2595(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2595(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2595(t0,t1);}

C_noret_decl(trf_2598)
static void C_fcall trf_2598(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2598(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2598(t0,t1);}

C_noret_decl(trf_2558)
static void C_fcall trf_2558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2558(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2558(t0,t1);}

C_noret_decl(trf_2526)
static void C_fcall trf_2526(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2526(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2526(t0,t1);}

C_noret_decl(trf_2468)
static void C_fcall trf_2468(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2468(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2468(t0,t1);}

C_noret_decl(trf_2300)
static void C_fcall trf_2300(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2300(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2300(t0,t1);}

C_noret_decl(trf_2312)
static void C_fcall trf_2312(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2312(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2312(t0,t1);}

C_noret_decl(trf_2303)
static void C_fcall trf_2303(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2303(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2303(t0,t1);}

C_noret_decl(trf_2263)
static void C_fcall trf_2263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2263(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2263(t0,t1,t2);}

C_noret_decl(trf_2223)
static void C_fcall trf_2223(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2223(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2223(t0,t1,t2);}

C_noret_decl(trf_2242)
static void C_fcall trf_2242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2242(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2242(t0,t1);}

C_noret_decl(trf_2174)
static void C_fcall trf_2174(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2174(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2174(t0,t1,t2);}

C_noret_decl(trf_2092)
static void C_fcall trf_2092(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2092(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2092(t0,t1);}

C_noret_decl(trf_1931)
static void C_fcall trf_1931(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1931(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1931(t0,t1,t2,t3);}

C_noret_decl(trf_1959)
static void C_fcall trf_1959(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1959(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1959(t0,t1,t2);}

C_noret_decl(trf_1785)
static void C_fcall trf_1785(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1785(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1785(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1817)
static void C_fcall trf_1817(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1817(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1817(t0,t1);}

C_noret_decl(trf_1834)
static void C_fcall trf_1834(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1834(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1834(t0,t1,t2);}

C_noret_decl(trf_1853)
static void C_fcall trf_1853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1853(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1853(t0,t1);}

C_noret_decl(trf_1814)
static void C_fcall trf_1814(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1814(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1814(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr5rv)
static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_eval_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_eval_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("eval_toplevel"));
C_check_nursery_minimum(7);
if(!C_demand(7)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(7613)){
C_save(t1);
C_rereclaim2(7613*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(7);
C_initialize_lf(lf,878);
lf[1]=C_static_string(C_heaptop,27,"too many optional arguments");
lf[2]=C_h_intern(&lf[2],24,"\003syscore-library-modules");
tmp=C_intern(C_heaptop,6,"extras");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"lolevel");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"utils");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"tcp");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"regex");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"regex-extras");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"posix");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"match");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-1");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-4");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-13");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-14");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-18");
C_save(tmp);
lf[3]=C_h_list(13,C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(13);
lf[4]=C_h_intern(&lf[4],28,"\003sysexplicit-library-modules");
tmp=C_static_string(C_heaptop,10,"libchicken");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[6]=C_h_pair(C_restore,tmp);
tmp=C_static_string(C_heaptop,12,"cygchicken-0");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[8]=C_h_pair(C_restore,tmp);
lf[10]=C_static_string(C_heaptop,6,".dylib");
lf[12]=C_static_string(C_heaptop,4,".dll");
lf[14]=C_static_string(C_heaptop,3,".sl");
lf[16]=C_static_string(C_heaptop,3,".so");
lf[18]=C_static_string(C_heaptop,4,".scm");
lf[20]=C_static_string(C_heaptop,10,"setup-info");
lf[22]=C_static_string(C_heaptop,18,"CHICKEN_REPOSITORY");
tmp=C_intern(C_heaptop,18,"chicken-ffi-macros");
C_save(tmp);
tmp=C_intern(C_heaptop,19,"chicken-more-macros");
C_save(tmp);
lf[24]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,7,"chicken");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-2");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-6");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-10");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-12");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-23");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-28");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-30");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-31");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-39");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-69");
C_save(tmp);
lf[26]=C_h_list(11,C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(11);
tmp=C_intern(C_heaptop,6,"srfi-6");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-8");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-9");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-11");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-15");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-16");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-17");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-26");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-55");
C_save(tmp);
lf[28]=C_h_list(9,C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(9);
lf[29]=C_h_intern(&lf[29],6,"getenv");
lf[30]=C_h_intern(&lf[30],12,"chicken-home");
lf[31]=C_h_intern(&lf[31],17,"\003syspeek-c-string");
tmp=C_make_character(92);
C_save(tmp);
tmp=C_make_character(47);
C_save(tmp);
lf[32]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[33]=C_static_string(C_heaptop,5,"share");
lf[34]=C_static_string(C_heaptop,6,"/share");
lf[35]=C_h_intern(&lf[35],17,"\003sysstring-append");
lf[36]=C_static_string(C_heaptop,14,"CHICKEN_PREFIX");
lf[37]=C_static_lambda_info(C_heaptop,14,"(chicken-home)");
lf[38]=C_h_intern(&lf[38],21,"\003sysmacro-environment");
lf[39]=C_h_intern(&lf[39],20,"\003sysregister-macro-2");
lf[40]=C_static_lambda_info(C_heaptop,14,"(a1718 form18)");
lf[41]=C_h_intern(&lf[41],19,"\003syshash-table-set!");
lf[42]=C_static_lambda_info(C_heaptop,41,"(##sys#register-macro-2 name16 handler17)");
lf[43]=C_h_intern(&lf[43],18,"\003sysregister-macro");
lf[44]=C_static_lambda_info(C_heaptop,14,"(a1734 form21)");
lf[45]=C_static_lambda_info(C_heaptop,39,"(##sys#register-macro name19 handler20)");
lf[46]=C_h_intern(&lf[46],14,"\003syscopy-macro");
lf[47]=C_h_intern(&lf[47],18,"\003syshash-table-ref");
lf[48]=C_static_lambda_info(C_heaptop,30,"(##sys#copy-macro old22 new23)");
lf[49]=C_h_intern(&lf[49],6,"macro\077");
lf[50]=C_static_lambda_info(C_heaptop,14,"(macro\077 sym24)");
lf[51]=C_h_intern(&lf[51],15,"undefine-macro!");
lf[52]=C_static_lambda_info(C_heaptop,24,"(undefine-macro! name27)");
lf[53]=C_h_intern(&lf[53],13,"string-append");
lf[54]=C_h_intern(&lf[54],17,"\003sysmacroexpand-0");
lf[55]=C_h_intern(&lf[55],9,"\003sysabort");
lf[56]=C_h_intern(&lf[56],9,"condition");
tmp=C_intern(C_heaptop,3,"exn");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"message");
lf[57]=C_h_pair(C_restore,tmp);
lf[58]=C_static_string(C_heaptop,21,"during expansion of (");
lf[59]=C_static_string(C_heaptop,8," ...) - ");
tmp=C_intern(C_heaptop,3,"exn");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"message");
lf[60]=C_h_pair(C_restore,tmp);
lf[61]=C_static_lambda_info(C_heaptop,11,"(copy ps42)");
lf[62]=C_h_intern(&lf[62],3,"exn");
lf[63]=C_static_lambda_info(C_heaptop,7,"(a1805)");
lf[64]=C_static_lambda_info(C_heaptop,12,"(a1799 ex40)");
lf[65]=C_static_lambda_info(C_heaptop,7,"(a1912)");
lf[66]=C_static_lambda_info(C_heaptop,7,"(a1924)");
lf[67]=C_static_lambda_info(C_heaptop,15,"(a1918 . g3846)");
lf[68]=C_static_lambda_info(C_heaptop,7,"(a1906)");
lf[69]=C_h_intern(&lf[69],22,"with-exception-handler");
lf[70]=C_static_lambda_info(C_heaptop,13,"(a1793 g3739)");
lf[71]=C_h_intern(&lf[71],30,"call-with-current-continuation");
lf[72]=C_static_lambda_info(C_heaptop,37,"(call-handler name34 handler35 exp36)");
lf[73]=C_h_intern(&lf[73],21,"\003syssyntax-error-hook");
lf[74]=C_static_string(C_heaptop,28,"invalid syntax in macro form");
lf[75]=C_static_lambda_info(C_heaptop,10,"(scan x56)");
lf[76]=C_static_lambda_info(C_heaptop,21,"(expand exp47 head48)");
lf[77]=C_h_intern(&lf[77],3,"let");
lf[78]=C_h_intern(&lf[78],16,"\004coreloop-lambda");
lf[79]=C_h_intern(&lf[79],6,"letrec");
lf[80]=C_h_intern(&lf[80],8,"\004coreapp");
lf[81]=C_h_intern(&lf[81],7,"\003sysmap");
lf[82]=C_h_intern(&lf[82],4,"cadr");
lf[83]=C_static_lambda_info(C_heaptop,11,"(a2078 b62)");
lf[84]=C_h_intern(&lf[84],16,"\003syscheck-syntax");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"variable");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_h_pair(C_restore,tmp);
lf[85]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
lf[86]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
lf[87]=C_h_intern(&lf[87],10,"\003syssetter");
lf[88]=C_h_intern(&lf[88],6,"append");
lf[89]=C_h_intern(&lf[89],4,"set!");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
lf[90]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[91]=C_h_intern(&lf[91],9,"\004coreset!");
lf[92]=C_static_lambda_info(C_heaptop,32,"(##sys#macroexpand-0 exp30 me31)");
lf[93]=C_h_intern(&lf[93],38,"\003syscompiler-toplevel-macroexpand-hook");
lf[94]=C_static_lambda_info(C_heaptop,48,"(##sys#compiler-toplevel-macroexpand-hook exp69)");
lf[95]=C_h_intern(&lf[95],41,"\003sysinterpreter-toplevel-macroexpand-hook");
lf[96]=C_static_lambda_info(C_heaptop,51,"(##sys#interpreter-toplevel-macroexpand-hook exp70)");
lf[97]=C_h_intern(&lf[97],23,"\003sysmacroexpand-1-local");
lf[98]=C_static_lambda_info(C_heaptop,38,"(##sys#macroexpand-1-local exp71 me72)");
lf[99]=C_h_intern(&lf[99],25,"\003sysenable-runtime-macros");
lf[100]=C_h_intern(&lf[100],11,"macroexpand");
lf[101]=C_static_lambda_info(C_heaptop,7,"(a2179)");
lf[102]=C_static_lambda_info(C_heaptop,22,"(a2185 exp27880 m7981)");
lf[103]=C_static_lambda_info(C_heaptop,12,"(loop exp77)");
lf[104]=C_static_lambda_info(C_heaptop,26,"(macroexpand exp73 . me74)");
lf[105]=C_h_intern(&lf[105],13,"macroexpand-1");
lf[106]=C_static_lambda_info(C_heaptop,28,"(macroexpand-1 exp85 . me86)");
lf[107]=C_h_intern(&lf[107],25,"\003sysextended-lambda-list\077");
lf[108]=C_h_intern(&lf[108],6,"#!rest");
lf[109]=C_h_intern(&lf[109],10,"#!optional");
lf[110]=C_h_intern(&lf[110],5,"#!key");
lf[111]=C_static_lambda_info(C_heaptop,14,"(loop llist89)");
lf[112]=C_static_lambda_info(C_heaptop,37,"(##sys#extended-lambda-list\077 llist87)");
lf[113]=C_h_intern(&lf[113],7,"reverse");
lf[114]=C_h_intern(&lf[114],6,"gensym");
lf[115]=C_h_intern(&lf[115],31,"\003sysexpand-extended-lambda-list");
lf[116]=C_static_lambda_info(C_heaptop,12,"(err msg104)");
lf[117]=C_h_intern(&lf[117],9,":optional");
lf[118]=C_h_intern(&lf[118],5,"cadar");
lf[119]=C_h_intern(&lf[119],4,"caar");
lf[120]=C_h_intern(&lf[120],13,"let-optionals");
lf[121]=C_h_intern(&lf[121],14,"let-optionals*");
lf[122]=C_h_intern(&lf[122],10,"\003sysappend");
lf[123]=C_h_intern(&lf[123],4,"let*");
lf[124]=C_h_intern(&lf[124],5,"quote");
lf[125]=C_h_intern(&lf[125],15,"\003sysget-keyword");
lf[126]=C_h_intern(&lf[126],6,"lambda");
lf[127]=C_h_intern(&lf[127],15,"string->keyword");
lf[128]=C_static_lambda_info(C_heaptop,12,"(a2440 k115)");
lf[129]=C_static_string(C_heaptop,43,"rest argument list specified more than once");
lf[130]=C_static_string(C_heaptop,45,"`#!optional\047 argument marker in wrong context");
lf[131]=C_static_string(C_heaptop,35,"invalid syntax of `#!rest\047 argument");
lf[132]=C_static_string(C_heaptop,41,"`#!rest\047 argument marker in wrong context");
lf[133]=C_static_string(C_heaptop,40,"`#!key\047 argument marker in wrong context");
lf[134]=C_static_string(C_heaptop,48,"invalid lambda list syntax after `#!rest\047 marker");
lf[135]=C_static_string(C_heaptop,32,"invalid required argument syntax");
lf[136]=C_static_string(C_heaptop,48,"invalid lambda list syntax after `#!rest\047 marker");
lf[137]=C_static_string(C_heaptop,26,"invalid lambda list syntax");
lf[138]=C_static_string(C_heaptop,26,"invalid lambda list syntax");
lf[139]=C_static_lambda_info(C_heaptop,44,"(loop mode109 req110 opt111 key112 llist113)");
lf[140]=C_static_lambda_info(C_heaptop,60,"(##sys#expand-extended-lambda-list llist099 body100 errh101)");
lf[141]=C_h_intern(&lf[141],3,"map");
lf[142]=C_h_intern(&lf[142],21,"\003syscanonicalize-body");
lf[143]=C_h_intern(&lf[143],5,"begin");
lf[144]=C_h_intern(&lf[144],6,"define");
lf[145]=C_h_intern(&lf[145],13,"define-values");
lf[146]=C_static_lambda_info(C_heaptop,23,"(loop body2160 exps161)");
lf[147]=C_h_intern(&lf[147],20,"\003syscall-with-values");
lf[148]=C_static_lambda_info(C_heaptop,17,"(a2919 v171 t172)");
lf[149]=C_static_lambda_info(C_heaptop,18,"(a2894 vs168 x169)");
lf[150]=C_static_lambda_info(C_heaptop,17,"(a2933 v166 x167)");
lf[151]=C_h_intern(&lf[151],14,"\004coreundefined");
lf[152]=C_static_lambda_info(C_heaptop,12,"(a2943 v165)");
lf[153]=C_static_lambda_info(C_heaptop,48,"(fini vars154 vals155 mvars156 mvals157 body158)");
lf[154]=C_h_intern(&lf[154],25,"\003sysexpand-curried-define");
tmp=C_intern(C_heaptop,6,"define");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"lambda-list");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_h_pair(C_restore,tmp);
lf[155]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,6,"define");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"variable");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"lambda-list");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_h_pair(C_restore,tmp);
lf[156]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,8,"\003sysvoid");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[157]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,6,"define");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"variable");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_h_pair(C_restore,tmp);
lf[158]=C_h_pair(C_restore,tmp);
lf[159]=C_static_lambda_info(C_heaptop,12,"(loop2 x184)");
tmp=C_intern(C_heaptop,6,"define");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_h_pair(C_restore,tmp);
lf[160]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,13,"define-values");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
lf[161]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
tmp=C_intern(C_heaptop,5,"begin");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
lf[162]=C_h_pair(C_restore,tmp);
lf[163]=C_static_lambda_info(C_heaptop,48,"(loop body175 vars176 vals177 mvars178 mvals179)");
lf[164]=C_static_lambda_info(C_heaptop,16,"(expand body173)");
lf[165]=C_static_lambda_info(C_heaptop,15,"(body144 me150)");
lf[166]=C_static_lambda_info(C_heaptop,28,"(def-container147 %me142198)");
lf[167]=C_static_lambda_info(C_heaptop,11,"(def-me146)");
lf[168]=C_h_intern(&lf[168],9,"\003syserror");
lf[169]=C_static_lambda_info(C_heaptop,53,"(##sys#canonicalize-body body139 lookup140 . g138141)");
lf[170]=C_h_intern(&lf[170],20,"\003sysmatch-expression");
lf[171]=C_static_lambda_info(C_heaptop,17,"(mwalk x210 p211)");
lf[172]=C_static_lambda_info(C_heaptop,46,"(##sys#match-expression exp205 pat206 vars207)");
lf[173]=C_static_lambda_info(C_heaptop,22,"(loop head225 body226)");
lf[174]=C_static_lambda_info(C_heaptop,45,"(##sys#expand-curried-define head221 body222)");
lf[175]=C_h_intern(&lf[175],15,"\003syshash-symbol");
lf[176]=C_static_lambda_info(C_heaptop,29,"(##sys#hash-symbol s232 n233)");
lf[177]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[178]=C_static_lambda_info(C_heaptop,35,"(##sys#hash-table-ref ht237 key238)");
lf[179]=C_static_lambda_info(C_heaptop,16,"(loop bucket250)");
lf[180]=C_static_lambda_info(C_heaptop,43,"(##sys#hash-table-set! ht244 key245 val246)");
lf[181]=C_h_intern(&lf[181],23,"\003syshash-table-for-each");
lf[182]=C_static_lambda_info(C_heaptop,17,"(a3555 bucket259)");
lf[183]=C_h_intern(&lf[183],12,"\003sysfor-each");
lf[184]=C_static_lambda_info(C_heaptop,12,"(do256 i258)");
lf[185]=C_static_lambda_info(C_heaptop,38,"(##sys#hash-table-for-each p253 ht254)");
lf[186]=C_h_intern(&lf[186],28,"\003sysarbitrary-unbound-symbol");
lf[187]=C_h_intern(&lf[187],23,"\003syshash-table-location");
lf[188]=C_static_lambda_info(C_heaptop,16,"(loop bucket269)");
lf[189]=C_static_lambda_info(C_heaptop,48,"(##sys#hash-table-location ht263 key264 addp265)");
lf[190]=C_h_intern(&lf[190],20,"\003syseval-environment");
lf[191]=C_h_intern(&lf[191],26,"\003sysenvironment-is-mutable");
lf[192]=C_h_intern(&lf[192],18,"\003syseval-decorator");
lf[193]=C_static_lambda_info(C_heaptop,12,"(a3642 x278)");
lf[194]=C_h_intern(&lf[194],20,"\003sysmake-lambda-info");
lf[195]=C_h_intern(&lf[195],17,"get-output-string");
lf[196]=C_h_intern(&lf[196],5,"write");
lf[197]=C_h_intern(&lf[197],18,"open-output-string");
lf[198]=C_static_lambda_info(C_heaptop,17,"(a3655 p279 i280)");
lf[199]=C_h_intern(&lf[199],19,"\003sysdecorate-lambda");
lf[200]=C_static_lambda_info(C_heaptop,46,"(##sys#eval-decorator p274 ll275 h276 cntr277)");
lf[201]=C_h_intern(&lf[201],19,"\003sysunbound-in-eval");
lf[202]=C_h_intern(&lf[202],20,"\003syseval-debug-level");
lf[203]=C_h_intern(&lf[203],21,"\003sysalias-global-hook");
lf[204]=C_static_lambda_info(C_heaptop,30,"(##sys#alias-global-hook s284)");
lf[205]=C_h_intern(&lf[205],6,"cadadr");
lf[206]=C_h_intern(&lf[206],20,"with-input-from-file");
lf[207]=C_h_intern(&lf[207],7,"display");
lf[208]=C_h_intern(&lf[208],22,"\003syscompile-to-closure");
lf[209]=C_static_lambda_info(C_heaptop,11,"(loop i338)");
lf[210]=C_static_lambda_info(C_heaptop,20,"(loop envs313 ei314)");
lf[211]=C_static_lambda_info(C_heaptop,20,"(lookup var310 e311)");
lf[212]=C_static_lambda_info(C_heaptop,7,"(a3734)");
lf[213]=C_static_lambda_info(C_heaptop,17,"(a3740 i321 j322)");
lf[214]=C_static_lambda_info(C_heaptop,22,"(defined\077 var319 e320)");
lf[215]=C_static_lambda_info(C_heaptop,33,"(macroexpand-1-checked x340 e341)");
lf[216]=C_h_intern(&lf[216],18,"\003syscurrent-thread");
lf[217]=C_static_lambda_info(C_heaptop,33,"(emit-trace-info info346 cntr347)");
lf[218]=C_static_lambda_info(C_heaptop,40,"(emit-syntax-trace-info info349 cntr350)");
lf[219]=C_static_lambda_info(C_heaptop,34,"(decorate p351 ll352 h353 cntr354)");
lf[220]=C_static_lambda_info(C_heaptop,7,"(a3923)");
lf[221]=C_static_lambda_info(C_heaptop,13,"(f_3996 v369)");
lf[222]=C_static_lambda_info(C_heaptop,13,"(f_4005 v370)");
lf[223]=C_static_string(C_heaptop,16,"unbound variable");
lf[224]=C_static_lambda_info(C_heaptop,15,"(f_3950 . v364)");
lf[225]=C_static_string(C_heaptop,33,"reference to undefined identifier");
lf[226]=C_static_lambda_info(C_heaptop,15,"(f_3970 . v367)");
lf[227]=C_h_intern(&lf[227],32,"\003syssymbol-has-toplevel-binding\077");
lf[228]=C_static_lambda_info(C_heaptop,17,"(a3929 i360 j361)");
lf[229]=C_static_lambda_info(C_heaptop,15,"(f_4022 . v373)");
lf[230]=C_static_lambda_info(C_heaptop,15,"(f_4030 . v374)");
lf[231]=C_static_lambda_info(C_heaptop,15,"(f_4038 . v375)");
lf[232]=C_static_lambda_info(C_heaptop,15,"(f_4046 . v376)");
lf[233]=C_static_lambda_info(C_heaptop,15,"(f_4048 . v377)");
lf[234]=C_static_lambda_info(C_heaptop,15,"(f_4059 . v378)");
lf[235]=C_static_lambda_info(C_heaptop,15,"(f_4061 . v379)");
lf[236]=C_static_lambda_info(C_heaptop,15,"(f_4072 . v384)");
lf[237]=C_static_lambda_info(C_heaptop,15,"(f_4131 . v392)");
lf[238]=C_static_lambda_info(C_heaptop,15,"(f_4139 . v393)");
lf[239]=C_static_lambda_info(C_heaptop,15,"(f_4147 . v394)");
lf[240]=C_static_lambda_info(C_heaptop,15,"(f_4155 . v395)");
lf[241]=C_static_lambda_info(C_heaptop,15,"(f_4163 . v396)");
lf[242]=C_static_lambda_info(C_heaptop,15,"(f_4171 . v397)");
lf[243]=C_static_lambda_info(C_heaptop,15,"(f_4179 . v398)");
lf[244]=C_static_lambda_info(C_heaptop,15,"(f_4181 . v399)");
tmp=C_intern(C_heaptop,5,"quote");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
lf[245]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[246]=C_h_intern(&lf[246],15,"\004coreglobal-ref");
lf[247]=C_static_lambda_info(C_heaptop,15,"(f_4198 . v403)");
lf[248]=C_static_lambda_info(C_heaptop,15,"(f_4203 . v404)");
lf[249]=C_h_intern(&lf[249],10,"\004corecheck");
lf[250]=C_h_intern(&lf[250],14,"\004coreimmutable");
lf[251]=C_static_lambda_info(C_heaptop,13,"(f_4237 v405)");
lf[252]=C_h_intern(&lf[252],2,"if");
lf[253]=C_static_lambda_info(C_heaptop,13,"(f_4257 v409)");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[254]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,2,"if");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_h_vector(1,C_pick(0));
C_drop(1);
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
lf[255]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[256]=C_h_pair(C_restore,tmp);
lf[257]=C_static_lambda_info(C_heaptop,13,"(f_4345 v417)");
lf[258]=C_static_lambda_info(C_heaptop,13,"(f_4370 v422)");
tmp=C_intern(C_heaptop,5,"begin");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
lf[259]=C_h_pair(C_restore,tmp);
lf[260]=C_static_lambda_info(C_heaptop,7,"(a4419)");
lf[261]=C_static_lambda_info(C_heaptop,13,"(f_4487 v438)");
lf[262]=C_static_lambda_info(C_heaptop,13,"(f_4500 v439)");
lf[263]=C_static_lambda_info(C_heaptop,13,"(f_4455 v434)");
lf[264]=C_static_string(C_heaptop,32,"assignment to immutable variable");
lf[265]=C_static_lambda_info(C_heaptop,15,"(f_4464 . v435)");
lf[266]=C_static_string(C_heaptop,34,"assignment of undefined identifier");
lf[267]=C_static_lambda_info(C_heaptop,13,"(f_4472 v437)");
lf[268]=C_static_lambda_info(C_heaptop,17,"(a4425 i429 j430)");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"variable");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
lf[269]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
lf[270]=C_static_lambda_info(C_heaptop,13,"(f_4546 v452)");
lf[271]=C_static_lambda_info(C_heaptop,13,"(f_4583 v455)");
lf[272]=C_static_lambda_info(C_heaptop,13,"(f_4638 v460)");
lf[273]=C_static_lambda_info(C_heaptop,13,"(f_4708 v466)");
lf[274]=C_static_lambda_info(C_heaptop,21,"(do471 i473 vlist474)");
lf[275]=C_h_intern(&lf[275],15,"\003sysmake-vector");
lf[276]=C_static_lambda_info(C_heaptop,13,"(f_4772 v469)");
lf[277]=C_static_lambda_info(C_heaptop,12,"(a4817 x468)");
lf[278]=C_static_lambda_info(C_heaptop,15,"(a4839 g447448)");
lf[279]=C_static_lambda_info(C_heaptop,12,"(a4845 x444)");
tmp=C_intern(C_heaptop,3,"let");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"variable");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_h_pair(C_restore,tmp);
lf[280]=C_h_pair(C_restore,tmp);
lf[281]=C_h_intern(&lf[281],1,"\077");
lf[282]=C_static_lambda_info(C_heaptop,14,"(a4898 . r503)");
lf[283]=C_static_lambda_info(C_heaptop,13,"(f_4893 v502)");
lf[284]=C_static_lambda_info(C_heaptop,7,"(a4917)");
lf[285]=C_static_lambda_info(C_heaptop,13,"(f_4912 v504)");
lf[286]=C_static_lambda_info(C_heaptop,20,"(a4941 a1506 . r507)");
lf[287]=C_static_lambda_info(C_heaptop,13,"(f_4936 v505)");
lf[288]=C_static_lambda_info(C_heaptop,13,"(a4960 a1509)");
lf[289]=C_static_lambda_info(C_heaptop,13,"(f_4955 v508)");
lf[290]=C_static_lambda_info(C_heaptop,26,"(a4988 a1511 a2512 . r513)");
lf[291]=C_static_lambda_info(C_heaptop,13,"(f_4983 v510)");
lf[292]=C_static_lambda_info(C_heaptop,19,"(a5007 a1515 a2516)");
lf[293]=C_static_lambda_info(C_heaptop,13,"(f_5002 v514)");
lf[294]=C_static_lambda_info(C_heaptop,32,"(a5035 a1518 a2519 a3520 . r521)");
lf[295]=C_static_lambda_info(C_heaptop,13,"(f_5030 v517)");
lf[296]=C_static_lambda_info(C_heaptop,25,"(a5054 a1523 a2524 a3525)");
lf[297]=C_static_lambda_info(C_heaptop,13,"(f_5049 v522)");
lf[298]=C_static_lambda_info(C_heaptop,38,"(a5082 a1527 a2528 a3529 a4530 . r531)");
lf[299]=C_static_lambda_info(C_heaptop,13,"(f_5077 v526)");
lf[300]=C_h_intern(&lf[300],10,"\003sysvector");
lf[301]=C_static_lambda_info(C_heaptop,31,"(a5101 a1533 a2534 a3535 a4536)");
lf[302]=C_static_lambda_info(C_heaptop,13,"(f_5096 v532)");
lf[303]=C_static_lambda_info(C_heaptop,28,"(do589 n591 args592 last593)");
lf[304]=C_static_lambda_info(C_heaptop,15,"(a5123 . as538)");
lf[305]=C_static_lambda_info(C_heaptop,13,"(f_5118 v537)");
lf[306]=C_static_string(C_heaptop,18,"bad argument count");
lf[307]=C_static_lambda_info(C_heaptop,15,"(a5146 . as540)");
lf[308]=C_static_lambda_info(C_heaptop,13,"(f_5141 v539)");
lf[309]=C_static_lambda_info(C_heaptop,15,"(a5184 g494495)");
lf[310]=C_static_lambda_info(C_heaptop,31,"(a4875 vars489 argc490 rest491)");
lf[311]=C_h_intern(&lf[311],25,"\003sysdecompose-lambda-list");
lf[312]=C_static_lambda_info(C_heaptop,7,"(a5200)");
lf[313]=C_static_lambda_info(C_heaptop,30,"(a5206 llist484486 body485487)");
tmp=C_intern(C_heaptop,6,"lambda");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"lambda-list");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_h_pair(C_restore,tmp);
lf[314]=C_h_pair(C_restore,tmp);
lf[315]=C_h_intern(&lf[315],17,"\004corenamed-lambda");
lf[316]=C_h_intern(&lf[316],23,"\004corerequire-for-syntax");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[317]=C_h_pair(C_restore,tmp);
lf[318]=C_h_intern(&lf[318],11,"\003sysrequire");
lf[319]=C_static_lambda_info(C_heaptop,12,"(a5285 x547)");
lf[320]=C_h_intern(&lf[320],31,"\003syslookup-runtime-requirements");
lf[321]=C_static_lambda_info(C_heaptop,12,"(a5291 x545)");
lf[322]=C_h_intern(&lf[322],22,"\004corerequire-extension");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[323]=C_h_pair(C_restore,tmp);
lf[324]=C_h_intern(&lf[324],22,"\003sysdo-the-right-thing");
lf[325]=C_static_lambda_info(C_heaptop,7,"(a5333)");
lf[326]=C_static_lambda_info(C_heaptop,25,"(a5343 exp551553 _552554)");
lf[327]=C_static_lambda_info(C_heaptop,13,"(loop ids550)");
lf[328]=C_h_intern(&lf[328],24,"\004coreelaborationtimeonly");
lf[329]=C_h_intern(&lf[329],23,"\004coreelaborationtimetoo");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[330]=C_h_pair(C_restore,tmp);
lf[331]=C_h_intern(&lf[331],19,"\004corecompiletimetoo");
lf[332]=C_h_intern(&lf[332],20,"\004corecompiletimeonly");
lf[333]=C_h_intern(&lf[333],13,"\004corecallunit");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[334]=C_h_pair(C_restore,tmp);
lf[335]=C_h_intern(&lf[335],12,"\004coredeclare");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[336]=C_h_pair(C_restore,tmp);
lf[337]=C_h_intern(&lf[337],10,"\000compiling");
lf[338]=C_h_intern(&lf[338],12,"\003sysfeatures");
lf[339]=C_h_intern(&lf[339],28,"\010compilerprocess-declaration");
lf[340]=C_static_lambda_info(C_heaptop,12,"(a5422 d563)");
lf[341]=C_h_intern(&lf[341],8,"\003syswarn");
lf[342]=C_static_string(C_heaptop,44,"declarations are ignored in interpreted code");
lf[343]=C_h_intern(&lf[343],18,"\004coredefine-inline");
lf[344]=C_h_intern(&lf[344],20,"\004coredefine-constant");
lf[345]=C_h_intern(&lf[345],14,"\004coreprimitive");
lf[346]=C_static_string(C_heaptop,38,"can not evaluate compiler-special-form");
lf[347]=C_h_intern(&lf[347],8,"location");
lf[348]=C_static_string(C_heaptop,38,"can not evaluate compiler-special-form");
lf[349]=C_h_intern(&lf[349],11,"\004coreinline");
lf[350]=C_h_intern(&lf[350],20,"\004coreinline_allocate");
lf[351]=C_h_intern(&lf[351],19,"\004coreforeign-lambda");
lf[352]=C_h_intern(&lf[352],28,"\004coredefine-foreign-variable");
lf[353]=C_h_intern(&lf[353],29,"\004coredefine-external-variable");
lf[354]=C_h_intern(&lf[354],17,"\004corelet-location");
lf[355]=C_h_intern(&lf[355],22,"\004coreforeign-primitive");
lf[356]=C_h_intern(&lf[356],20,"\004coreforeign-lambda*");
lf[357]=C_h_intern(&lf[357],24,"\004coredefine-foreign-type");
lf[358]=C_static_string(C_heaptop,25,"illegal non-atomic object");
lf[359]=C_h_intern(&lf[359],11,"\003sysnumber\077");
lf[360]=C_static_lambda_info(C_heaptop,38,"(compile x355 e356 h357 tf358 cntr359)");
lf[361]=C_static_lambda_info(C_heaptop,11,"(loop n599)");
lf[362]=C_static_string(C_heaptop,20,"malformed expression");
lf[363]=C_static_lambda_info(C_heaptop,13,"(f_5694 v611)");
lf[364]=C_static_lambda_info(C_heaptop,13,"(f_5714 v614)");
lf[365]=C_static_lambda_info(C_heaptop,13,"(f_5745 v618)");
lf[366]=C_static_lambda_info(C_heaptop,13,"(f_5783 v623)");
lf[367]=C_static_lambda_info(C_heaptop,13,"(f_5828 v629)");
lf[368]=C_static_lambda_info(C_heaptop,12,"(a5878 a634)");
lf[369]=C_static_lambda_info(C_heaptop,13,"(f_5862 v633)");
lf[370]=C_static_lambda_info(C_heaptop,12,"(a5884 a632)");
lf[371]=C_static_lambda_info(C_heaptop,38,"(compile-call x601 e602 tf603 cntr604)");
lf[372]=C_static_lambda_info(C_heaptop,56,"(##sys#compile-to-closure exp294 env295 me296 . cntr297)");
lf[373]=C_h_intern(&lf[373],16,"\003syseval-handler");
lf[374]=C_h_intern(&lf[374],12,"eval-handler");
lf[375]=C_h_intern(&lf[375],4,"eval");
lf[376]=C_static_lambda_info(C_heaptop,20,"(eval x674 . env675)");
lf[377]=C_h_intern(&lf[377],24,"\003syssyntax-error-culprit");
lf[378]=C_static_string(C_heaptop,26,"illegal lambda-list syntax");
lf[379]=C_static_lambda_info(C_heaptop,5,"(err)");
lf[380]=C_static_lambda_info(C_heaptop,31,"(loop llist682 vars683 argc684)");
lf[381]=C_static_lambda_info(C_heaptop,44,"(##sys#decompose-lambda-list llist0677 k678)");
lf[382]=C_h_intern(&lf[382],12,"load-verbose");
lf[383]=C_h_intern(&lf[383],14,"\003sysabort-load");
lf[384]=C_static_lambda_info(C_heaptop,8,"(f_6028)");
lf[385]=C_h_intern(&lf[385],27,"\003syscurrent-source-filename");
lf[386]=C_h_intern(&lf[386],21,"\003syscurrent-load-path");
lf[387]=C_static_string(C_heaptop,0,"");
lf[388]=C_h_intern(&lf[388],22,"set-dynamic-load-mode!");
lf[389]=C_h_intern(&lf[389],21,"\003sysset-dlopen-flags!");
lf[390]=C_h_intern(&lf[390],6,"global");
lf[391]=C_h_intern(&lf[391],5,"local");
lf[392]=C_h_intern(&lf[392],4,"lazy");
lf[393]=C_h_intern(&lf[393],3,"now");
lf[394]=C_h_intern(&lf[394],15,"\003syssignal-hook");
lf[395]=C_static_string(C_heaptop,25,"invalid dynamic-load mode");
lf[396]=C_static_lambda_info(C_heaptop,14,"(loop mode692)");
lf[397]=C_static_lambda_info(C_heaptop,32,"(set-dynamic-load-mode! mode687)");
lf[398]=C_h_intern(&lf[398],4,"read");
lf[399]=C_h_intern(&lf[399],7,"newline");
lf[400]=C_h_intern(&lf[400],15,"open-input-file");
lf[401]=C_h_intern(&lf[401],16,"close-input-port");
lf[402]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[403]=C_static_lambda_info(C_heaptop,17,"(has-sep\077 str710)");
lf[404]=C_h_intern(&lf[404],8,"\003sysload");
lf[405]=C_static_lambda_info(C_heaptop,8,"(f_6185)");
lf[406]=C_h_intern(&lf[406],31,"\003sysread-error-with-line-number");
lf[407]=C_h_intern(&lf[407],19,"\003sysundefined-value");
lf[408]=C_static_lambda_info(C_heaptop,7,"(a6193)");
lf[409]=C_static_lambda_info(C_heaptop,7,"(a6216)");
lf[410]=C_static_lambda_info(C_heaptop,7,"(a6268)");
lf[411]=C_h_intern(&lf[411],17,"\003sysdisplay-times");
lf[412]=C_h_intern(&lf[412],14,"\003sysstop-timer");
lf[413]=C_static_lambda_info(C_heaptop,17,"(a6274 . t778779)");
lf[414]=C_h_intern(&lf[414],15,"\003sysstart-timer");
lf[415]=C_static_lambda_info(C_heaptop,7,"(a6256)");
lf[416]=C_static_lambda_info(C_heaptop,12,"(a6299 r783)");
lf[417]=C_static_lambda_info(C_heaptop,20,"(a6290 . results782)");
lf[418]=C_static_lambda_info(C_heaptop,12,"(do775 x777)");
lf[419]=C_h_intern(&lf[419],4,"load");
lf[420]=C_static_string(C_heaptop,30,"unable to load compiled module");
lf[421]=C_h_intern(&lf[421],9,"peek-char");
lf[422]=C_static_lambda_info(C_heaptop,7,"(a6219)");
lf[423]=C_static_lambda_info(C_heaptop,7,"(a6325)");
lf[424]=C_h_intern(&lf[424],16,"\003sysdynamic-wind");
lf[425]=C_static_lambda_info(C_heaptop,7,"(a6207)");
lf[426]=C_static_lambda_info(C_heaptop,7,"(a6334)");
lf[427]=C_h_intern(&lf[427],13,"\003syssubstring");
lf[428]=C_static_string(C_heaptop,0,"");
lf[429]=C_static_lambda_info(C_heaptop,15,"(a6179 abrt746)");
lf[430]=C_h_intern(&lf[430],9,"\003sysdload");
lf[431]=C_h_intern(&lf[431],17,"\003sysmake-c-string");
lf[432]=C_static_string(C_heaptop,2,"./");
lf[433]=C_h_intern(&lf[433],11,"\000file-error");
lf[434]=C_static_string(C_heaptop,17,"can not open file");
lf[435]=C_static_string(C_heaptop,5," ...\012");
lf[436]=C_static_string(C_heaptop,10,"; loading ");
lf[437]=C_h_intern(&lf[437],13,"\003sysfile-info");
lf[438]=C_h_intern(&lf[438],26,"\003sysload-dynamic-extension");
lf[439]=C_h_intern(&lf[439],11,"\000type-error");
lf[440]=C_static_string(C_heaptop,40,"bad argument type - not a port or string");
lf[441]=C_h_intern(&lf[441],5,"port\077");
lf[442]=C_h_intern(&lf[442],20,"\003sysexpand-home-path");
lf[443]=C_static_lambda_info(C_heaptop,29,"(body722 timer728 printer729)");
lf[444]=C_static_lambda_info(C_heaptop,29,"(def-printer725 %timer720801)");
lf[445]=C_static_lambda_info(C_heaptop,14,"(def-timer724)");
lf[446]=C_static_lambda_info(C_heaptop,50,"(##sys#load input716 evaluator717 pf718 . g715719)");
lf[447]=C_static_lambda_info(C_heaptop,33,"(load filename807 . evaluator808)");
lf[448]=C_h_intern(&lf[448],13,"load-relative");
lf[449]=C_static_lambda_info(C_heaptop,42,"(load-relative filename811 . evaluator812)");
lf[450]=C_h_intern(&lf[450],12,"load-noisily");
lf[451]=C_static_lambda_info(C_heaptop,7,"(a6630)");
lf[452]=C_h_intern(&lf[452],8,"\000printer");
lf[453]=C_static_lambda_info(C_heaptop,7,"(a6633)");
lf[454]=C_h_intern(&lf[454],5,"\000time");
lf[455]=C_static_lambda_info(C_heaptop,7,"(a6636)");
lf[456]=C_h_intern(&lf[456],10,"\000evaluator");
lf[457]=C_static_lambda_info(C_heaptop,36,"(load-noisily filename816 . g815817)");
lf[458]=C_h_intern(&lf[458],26,"\003sysload-library-extension");
lf[459]=C_h_intern(&lf[459],6,"cygwin");
lf[460]=C_h_intern(&lf[460],34,"\003sysdefault-dynamic-load-libraries");
lf[461]=C_h_intern(&lf[461],22,"dynamic-load-libraries");
lf[462]=C_h_intern(&lf[462],16,"\003sysload-library");
lf[463]=C_static_lambda_info(C_heaptop,14,"(loop libs846)");
lf[464]=C_static_string(C_heaptop,5," ...\012");
lf[465]=C_static_string(C_heaptop,18,"; loading library ");
lf[466]=C_static_string(C_heaptop,2,"C_");
lf[467]=C_static_string(C_heaptop,9,"_toplevel");
lf[468]=C_h_intern(&lf[468],24,"\003sysstring->c-identifier");
lf[469]=C_h_intern(&lf[469],16,"\003sys->feature-id");
lf[470]=C_static_lambda_info(C_heaptop,36,"(##sys#load-library uname836 lib837)");
lf[471]=C_h_intern(&lf[471],12,"load-library");
lf[472]=C_static_string(C_heaptop,22,"unable to load library");
lf[473]=C_static_lambda_info(C_heaptop,32,"(load-library uname850 . lib851)");
lf[475]=C_static_lambda_info(C_heaptop,25,"(loop items860 i861 j862)");
lf[476]=C_static_lambda_info(C_heaptop,40,"(##sys#split-at-separator str856 sep857)");
lf[477]=C_h_intern(&lf[477],31,"\003syscanonicalize-extension-path");
lf[478]=C_static_string(C_heaptop,22,"invalid extension path");
lf[479]=C_static_lambda_info(C_heaptop,5,"(err)");
lf[480]=C_static_lambda_info(C_heaptop,6,"(sep\077)");
lf[481]=C_static_lambda_info(C_heaptop,12,"(check p879)");
lf[482]=C_h_intern(&lf[482],18,"\003syssymbol->string");
lf[483]=C_static_string(C_heaptop,0,"");
lf[484]=C_static_string(C_heaptop,0,"");
lf[485]=C_static_string(C_heaptop,1,"/");
lf[486]=C_static_lambda_info(C_heaptop,12,"(loop id875)");
lf[487]=C_static_lambda_info(C_heaptop,48,"(##sys#canonicalize-extension-path id866 loc867)");
lf[488]=C_h_intern(&lf[488],19,"\003sysrepository-path");
lf[489]=C_h_intern(&lf[489],15,"repository-path");
lf[490]=C_h_intern(&lf[490],12,"file-exists\077");
lf[491]=C_h_intern(&lf[491],18,"\003sysfind-extension");
lf[492]=C_static_string(C_heaptop,1,"/");
lf[493]=C_static_lambda_info(C_heaptop,15,"(check path891)");
lf[494]=C_static_lambda_info(C_heaptop,15,"(loop paths896)");
lf[495]=C_h_intern(&lf[495],21,"\003sysinclude-pathnames");
tmp=C_static_string(C_heaptop,1,".");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[496]=C_h_pair(C_restore,tmp);
lf[497]=C_static_lambda_info(C_heaptop,35,"(##sys#find-extension p888 inc\077889)");
lf[498]=C_h_intern(&lf[498],21,"\003sysloaded-extensions");
lf[499]=C_h_intern(&lf[499],14,"string->symbol");
lf[500]=C_h_intern(&lf[500],18,"\003sysload-extension");
lf[501]=C_static_string(C_heaptop,22,"can not load extension");
lf[502]=C_static_lambda_info(C_heaptop,45,"(##sys#load-extension id903 loc904 . err\077905)");
lf[503]=C_h_intern(&lf[503],11,"\003sysprovide");
lf[504]=C_h_intern(&lf[504],7,"provide");
lf[505]=C_static_lambda_info(C_heaptop,13,"(a7167 id916)");
lf[506]=C_static_lambda_info(C_heaptop,24,"(##sys#provide . ids915)");
lf[507]=C_h_intern(&lf[507],13,"\003sysprovided\077");
lf[508]=C_h_intern(&lf[508],9,"provided\077");
lf[509]=C_static_lambda_info(C_heaptop,23,"(##sys#provided\077 id919)");
lf[510]=C_h_intern(&lf[510],7,"require");
lf[511]=C_static_lambda_info(C_heaptop,15,"(a7201 g921922)");
lf[512]=C_static_lambda_info(C_heaptop,24,"(##sys#require . ids920)");
lf[513]=C_h_intern(&lf[513],25,"\003sysextension-information");
lf[514]=C_static_lambda_info(C_heaptop,16,"(f_7226 g933934)");
lf[515]=C_static_string(C_heaptop,1,"/");
lf[516]=C_static_string(C_heaptop,1,".");
lf[517]=C_static_lambda_info(C_heaptop,42,"(##sys#extension-information id927 loc928)");
lf[518]=C_h_intern(&lf[518],21,"extension-information");
lf[519]=C_static_lambda_info(C_heaptop,30,"(extension-information ext935)");
lf[520]=C_h_intern(&lf[520],18,"require-at-runtime");
lf[521]=C_static_lambda_info(C_heaptop,14,"(loop1 ids940)");
lf[522]=C_static_lambda_info(C_heaptop,42,"(##sys#lookup-runtime-requirements ids938)");
lf[523]=C_h_intern(&lf[523],12,"vector->list");
lf[524]=C_h_intern(&lf[524],11,"lset-adjoin");
lf[525]=C_h_intern(&lf[525],3,"eq\077");
lf[526]=C_static_lambda_info(C_heaptop,15,"(a7306 g952953)");
lf[527]=C_static_lambda_info(C_heaptop,7,"(a7312)");
lf[528]=C_h_intern(&lf[528],18,"hash-table-update!");
lf[529]=C_h_intern(&lf[529],26,"\010compilerfile-requirements");
lf[530]=C_h_intern(&lf[530],19,"syntax-requirements");
lf[531]=C_static_lambda_info(C_heaptop,15,"(add-req id951)");
tmp=C_intern(C_heaptop,8,"\003sysvoid");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[532]=C_h_pair(C_restore,tmp);
lf[533]=C_h_intern(&lf[533],18,"chicken-ffi-macros");
lf[534]=C_h_intern(&lf[534],19,"chicken-more-macros");
tmp=C_intern(C_heaptop,8,"\003sysvoid");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[535]=C_h_pair(C_restore,tmp);
lf[536]=C_h_intern(&lf[536],28,"\003sysresolve-include-filename");
lf[537]=C_h_intern(&lf[537],4,"uses");
lf[538]=C_h_intern(&lf[538],6,"syntax");
lf[539]=C_h_intern(&lf[539],17,"require-extension");
lf[540]=C_static_lambda_info(C_heaptop,13,"(a7509 id965)");
lf[541]=C_h_intern(&lf[541],12,"\003sysfeature\077");
lf[542]=C_static_lambda_info(C_heaptop,12,"(doit id954)");
lf[543]=C_h_intern(&lf[543],24,"\003sysextension-specifiers");
lf[544]=C_static_lambda_info(C_heaptop,7,"(a7629)");
lf[545]=C_static_lambda_info(C_heaptop,26,"(a7639 exp974976 fi975977)");
lf[546]=C_static_lambda_info(C_heaptop,28,"(loop specs971 exps972 f973)");
lf[547]=C_static_string(C_heaptop,29,"undefined extension specifier");
lf[548]=C_static_string(C_heaptop,27,"invalid extension specifier");
lf[549]=C_static_lambda_info(C_heaptop,41,"(##sys#do-the-right-thing id947 comp\077948)");
lf[550]=C_h_intern(&lf[550],24,"set-extension-specifier!");
lf[551]=C_static_lambda_info(C_heaptop,15,"(a7711 spec989)");
lf[552]=C_static_lambda_info(C_heaptop,15,"(a7725 spec990)");
lf[553]=C_static_lambda_info(C_heaptop,42,"(set-extension-specifier! name985 proc986)");
lf[554]=C_h_intern(&lf[554],11,"string-copy");
lf[555]=C_static_lambda_info(C_heaptop,14,"(do1018 i1020)");
lf[556]=C_static_lambda_info(C_heaptop,36,"(##sys#string->c-identifier str1015)");
lf[559]=C_h_intern(&lf[559],11,"environment");
lf[561]=C_h_intern(&lf[561],18,"\003syscopy-env-table");
lf[562]=C_static_lambda_info(C_heaptop,12,"(copy b1037)");
lf[563]=C_static_lambda_info(C_heaptop,14,"(do1033 i1035)");
lf[564]=C_static_lambda_info(C_heaptop,54,"(##sys#copy-env-table e1026 mff1027 mf1028 . args1029)");
lf[565]=C_h_intern(&lf[565],23,"\003sysenvironment-symbols");
lf[566]=C_static_lambda_info(C_heaptop,26,"(loop bucket1055 syms1056)");
lf[567]=C_static_lambda_info(C_heaptop,23,"(do1050 i1052 syms1053)");
lf[568]=C_static_lambda_info(C_heaptop,15,"(a8002 sym1063)");
lf[569]=C_h_intern(&lf[569],18,"\003syswalk-namespace");
lf[570]=C_static_lambda_info(C_heaptop,46,"(##sys#environment-symbols env1045 . args1046)");
lf[571]=C_h_intern(&lf[571],23,"interaction-environment");
lf[572]=C_static_lambda_info(C_heaptop,25,"(interaction-environment)");
lf[573]=C_h_intern(&lf[573],25,"scheme-report-environment");
lf[574]=C_static_string(C_heaptop,22,"no support for version");
lf[575]=C_static_lambda_info(C_heaptop,47,"(scheme-report-environment n1068 . mutable1069)");
lf[576]=C_h_intern(&lf[576],11,"make-vector");
lf[577]=C_h_intern(&lf[577],16,"null-environment");
lf[578]=C_static_string(C_heaptop,22,"no support for version");
lf[579]=C_static_lambda_info(C_heaptop,38,"(null-environment n1075 . mutable1076)");
lf[580]=C_static_lambda_info(C_heaptop,14,"(f_8115 b1083)");
lf[581]=C_static_lambda_info(C_heaptop,14,"(initb ht1082)");
lf[582]=C_static_lambda_info(C_heaptop,19,"(exists\077 fname1091)");
lf[583]=C_static_lambda_info(C_heaptop,25,"(test2 fname1103 lst1104)");
lf[584]=C_static_lambda_info(C_heaptop,16,"(test fname1106)");
lf[585]=C_static_string(C_heaptop,1,"/");
lf[586]=C_static_lambda_info(C_heaptop,16,"(loop paths1109)");
lf[587]=C_static_lambda_info(C_heaptop,72,"(##sys#resolve-include-filename fname1094 prefer-source1095 . g10931096)");
lf[588]=C_static_lambda_info(C_heaptop,14,"(do1119 i1121)");
lf[589]=C_static_lambda_info(C_heaptop,14,"(spaces n1118)");
lf[590]=C_static_string(C_heaptop,1,"0");
lf[591]=C_static_lambda_info(C_heaptop,24,"(display-rj x1125 w1126)");
lf[592]=C_static_string(C_heaptop,11," major GCs\012");
lf[593]=C_static_string(C_heaptop,11," minor GCs\012");
lf[594]=C_static_string(C_heaptop,11," mutations\012");
lf[595]=C_static_string(C_heaptop,23," seconds in (major) GC\012");
lf[596]=C_static_string(C_heaptop,17," seconds elapsed\012");
lf[597]=C_static_lambda_info(C_heaptop,30,"(##sys#display-times info1130)");
lf[598]=C_h_intern(&lf[598],24,"\003sysline-number-database");
lf[599]=C_h_intern(&lf[599],13,"\000syntax-error");
lf[600]=C_static_lambda_info(C_heaptop,36,"(##sys#syntax-error-hook . args1140)");
lf[601]=C_h_intern(&lf[601],12,"syntax-error");
lf[602]=C_h_intern(&lf[602],15,"get-line-number");
lf[603]=C_static_lambda_info(C_heaptop,26,"(get-line-number sexp1141)");
lf[604]=C_h_intern(&lf[604],8,"keyword\077");
lf[605]=C_h_intern(&lf[605],14,"symbol->string");
lf[606]=C_static_string(C_heaptop,1,"(");
lf[607]=C_static_string(C_heaptop,10,") in line ");
lf[608]=C_static_string(C_heaptop,3," - ");
lf[609]=C_static_string(C_heaptop,1,"(");
lf[610]=C_static_string(C_heaptop,2,") ");
lf[611]=C_static_lambda_info(C_heaptop,13,"(err msg1162)");
lf[612]=C_static_lambda_info(C_heaptop,29,"(test x1159 pred1160 msg1161)");
lf[613]=C_static_lambda_info(C_heaptop,12,"(loop x1169)");
lf[614]=C_static_lambda_info(C_heaptop,20,"(lambda-list\077 x1165)");
lf[615]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[616]=C_static_lambda_info(C_heaptop,20,"(proper-list\077 x1176)");
lf[617]=C_static_string(C_heaptop,20,"not enough arguments");
lf[618]=C_static_string(C_heaptop,18,"too many arguments");
lf[619]=C_static_string(C_heaptop,17,"not a proper list");
lf[620]=C_static_lambda_info(C_heaptop,20,"(do1189 x1191 n1192)");
lf[621]=C_h_intern(&lf[621],1,"_");
lf[622]=C_h_intern(&lf[622],4,"pair");
lf[623]=C_h_intern(&lf[623],5,"pair\077");
lf[624]=C_static_string(C_heaptop,13,"pair expected");
lf[625]=C_h_intern(&lf[625],8,"variable");
lf[626]=C_static_lambda_info(C_heaptop,13,"(a8724 x1199)");
lf[627]=C_static_string(C_heaptop,19,"identifier expected");
lf[628]=C_h_intern(&lf[628],6,"symbol");
lf[629]=C_h_intern(&lf[629],7,"symbol\077");
lf[630]=C_static_string(C_heaptop,15,"symbol expected");
lf[631]=C_h_intern(&lf[631],4,"list");
lf[632]=C_static_string(C_heaptop,20,"proper list expected");
lf[633]=C_h_intern(&lf[633],6,"number");
lf[634]=C_h_intern(&lf[634],7,"number\077");
lf[635]=C_static_string(C_heaptop,15,"number expected");
lf[636]=C_h_intern(&lf[636],6,"string");
lf[637]=C_h_intern(&lf[637],7,"string\077");
lf[638]=C_static_string(C_heaptop,15,"string expected");
lf[639]=C_h_intern(&lf[639],11,"lambda-list");
lf[640]=C_static_string(C_heaptop,20,"lambda-list expected");
lf[641]=C_static_lambda_info(C_heaptop,13,"(a8778 y1200)");
lf[642]=C_static_string(C_heaptop,15,"missing keyword");
lf[643]=C_static_string(C_heaptop,15,"incomplete form");
lf[644]=C_static_string(C_heaptop,17,"unexpected object");
lf[645]=C_static_lambda_info(C_heaptop,18,"(walk x1183 p1184)");
lf[646]=C_static_lambda_info(C_heaptop,57,"(##sys#check-syntax id1151 exp1152 pat1153 . culprit1154)");
lf[647]=C_h_intern(&lf[647],18,"\003sysrepl-eval-hook");
lf[648]=C_h_intern(&lf[648],27,"\003sysrepl-print-length-limit");
lf[649]=C_h_intern(&lf[649],18,"\003sysrepl-read-hook");
lf[650]=C_h_intern(&lf[650],19,"\003sysrepl-print-hook");
lf[651]=C_h_intern(&lf[651],16,"\003syswrite-char-0");
lf[652]=C_h_intern(&lf[652],9,"\003sysprint");
lf[653]=C_static_lambda_info(C_heaptop,7,"(a8874)");
lf[654]=C_h_intern(&lf[654],27,"\003syswith-print-length-limit");
lf[655]=C_static_lambda_info(C_heaptop,38,"(##sys#repl-print-hook x1309 port1310)");
lf[656]=C_h_intern(&lf[656],11,"repl-prompt");
lf[657]=C_h_intern(&lf[657],20,"\003sysread-prompt-hook");
lf[658]=C_h_intern(&lf[658],16,"\003sysflush-output");
lf[659]=C_h_intern(&lf[659],19,"\003sysstandard-output");
lf[660]=C_static_lambda_info(C_heaptop,24,"(##sys#read-prompt-hook)");
lf[661]=C_h_intern(&lf[661],22,"\003sysclear-trace-buffer");
lf[662]=C_static_lambda_info(C_heaptop,26,"(##sys#clear-trace-buffer)");
lf[663]=C_h_intern(&lf[663],16,"print-call-chain");
lf[664]=C_h_intern(&lf[664],12,"flush-output");
lf[665]=C_h_intern(&lf[665],5,"reset");
lf[666]=C_h_intern(&lf[666],4,"repl");
lf[667]=C_h_intern(&lf[667],18,"\003sysstandard-error");
lf[668]=C_static_lambda_info(C_heaptop,17,"(a8912 g13261327)");
lf[669]=C_static_lambda_info(C_heaptop,18,"(write-err xs1325)");
lf[670]=C_h_intern(&lf[670],18,"\003sysstandard-input");
lf[671]=C_static_string(C_heaptop,2,": ");
lf[672]=C_static_string(C_heaptop,2,": ");
lf[673]=C_static_string(C_heaptop,5,"Error");
lf[674]=C_static_lambda_info(C_heaptop,26,"(a8980 msg1346 . args1347)");
lf[675]=C_h_intern(&lf[675],17,"\003syserror-handler");
lf[676]=C_static_lambda_info(C_heaptop,7,"(a8967)");
lf[677]=C_static_lambda_info(C_heaptop,7,"(a9069)");
lf[678]=C_static_lambda_info(C_heaptop,17,"(a8933 g13311332)");
lf[679]=C_h_intern(&lf[679],20,"\003syswarnings-enabled");
lf[680]=C_static_string(C_heaptop,5," (in ");
lf[681]=C_static_string(C_heaptop,2,"  ");
lf[682]=C_static_lambda_info(C_heaptop,13,"(a9117 v1372)");
lf[683]=C_static_string(C_heaptop,70,"Warning: the following toplevel variables are referenced but unbound:\012");
lf[684]=C_static_lambda_info(C_heaptop,21,"(loop vars1370 u1371)");
lf[685]=C_static_lambda_info(C_heaptop,20,"(a9078 . result1368)");
lf[686]=C_h_intern(&lf[686],15,"\003sysread-char-0");
lf[687]=C_h_intern(&lf[687],15,"\003syspeek-char-0");
lf[688]=C_h_intern(&lf[688],21,"\003sysenable-qualifiers");
lf[689]=C_static_lambda_info(C_heaptop,7,"(a9216)");
lf[690]=C_h_intern(&lf[690],17,"\003sysreset-handler");
lf[691]=C_static_lambda_info(C_heaptop,13,"(a9210 c1359)");
lf[692]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[693]=C_static_lambda_info(C_heaptop,7,"(a9032)");
lf[694]=C_static_lambda_info(C_heaptop,7,"(a9227)");
lf[695]=C_static_lambda_info(C_heaptop,6,"(repl)");
lf[696]=C_h_intern(&lf[696],28,"\003syssharp-comma-reader-ctors");
lf[697]=C_h_intern(&lf[697],18,"define-reader-ctor");
lf[698]=C_static_lambda_info(C_heaptop,38,"(define-reader-ctor spec1399 proc1400)");
lf[699]=C_h_intern(&lf[699],18,"\003sysuser-read-hook");
lf[700]=C_h_intern(&lf[700],9,"read-char");
lf[701]=C_h_intern(&lf[701],14,"\003sysread-error");
lf[702]=C_static_string(C_heaptop,33,"invalid sharp-comma external form");
lf[703]=C_static_lambda_info(C_heaptop,5,"(err)");
lf[704]=C_static_string(C_heaptop,33,"undefined sharp-comma constructor");
lf[705]=C_static_lambda_info(C_heaptop,40,"(##sys#user-read-hook char1405 port1406)");
lf[708]=C_h_intern(&lf[708],19,"print-error-message");
lf[709]=C_static_lambda_info(C_heaptop,7,"(a9362)");
lf[710]=C_static_lambda_info(C_heaptop,14,"(a9356 ex1433)");
lf[711]=C_static_lambda_info(C_heaptop,7,"(a9381)");
lf[712]=C_static_lambda_info(C_heaptop,7,"(a9393)");
lf[713]=C_static_lambda_info(C_heaptop,19,"(a9387 . g14311437)");
lf[714]=C_static_lambda_info(C_heaptop,7,"(a9375)");
lf[715]=C_static_lambda_info(C_heaptop,17,"(a9350 g14301432)");
lf[716]=C_static_lambda_info(C_heaptop,20,"(run-safe thunk1429)");
lf[718]=C_h_intern(&lf[718],6,"\003sysgc");
lf[719]=C_static_lambda_info(C_heaptop,31,"(store-result x1439 result1440)");
lf[721]=C_h_intern(&lf[721],13,"thread-yield!");
lf[722]=C_static_lambda_info(C_heaptop,7,"(a9414)");
lf[723]=C_static_lambda_info(C_heaptop,15,"(CHICKEN_yield)");
lf[725]=C_static_lambda_info(C_heaptop,7,"(a9426)");
lf[726]=C_static_lambda_info(C_heaptop,33,"(CHICKEN_eval exp1444 result1445)");
lf[728]=C_h_intern(&lf[728],17,"open-input-string");
lf[729]=C_static_lambda_info(C_heaptop,7,"(a9445)");
lf[730]=C_static_lambda_info(C_heaptop,40,"(CHICKEN_eval_string str1448 result1449)");
lf[732]=C_static_string(C_heaptop,40,"Error: not enough room for result string");
lf[733]=C_static_lambda_info(C_heaptop,34,"(store-string bufsize1454 buf1455)");
lf[735]=C_static_lambda_info(C_heaptop,7,"(a9481)");
lf[736]=C_static_lambda_info(C_heaptop,52,"(CHICKEN_eval_to_string exp1458 buf1459 bufsize1460)");
lf[738]=C_static_lambda_info(C_heaptop,7,"(a9510)");
lf[739]=C_static_lambda_info(C_heaptop,59,"(CHICKEN_eval_string_to_string str1466 buf1467 bufsize1468)");
lf[741]=C_static_lambda_info(C_heaptop,7,"(a9544)");
lf[742]=C_static_lambda_info(C_heaptop,44,"(CHICKEN_apply func1474 args1475 result1476)");
lf[744]=C_static_lambda_info(C_heaptop,7,"(a9560)");
lf[745]=C_static_lambda_info(C_heaptop,63,"(CHICKEN_apply_to_string func1480 args1481 buf1482 bufsize1483)");
lf[747]=C_static_lambda_info(C_heaptop,7,"(a9589)");
lf[748]=C_static_lambda_info(C_heaptop,33,"(CHICKEN_read str1490 result1491)");
lf[750]=C_static_lambda_info(C_heaptop,7,"(a9611)");
lf[751]=C_static_lambda_info(C_heaptop,22,"(CHICKEN_load str1495)");
lf[753]=C_static_string(C_heaptop,8,"No error");
lf[754]=C_static_lambda_info(C_heaptop,47,"(CHICKEN_get_error_message buf1498 bufsize1499)");
lf[755]=C_h_intern(&lf[755],15,"\003sysmake-string");
lf[756]=C_static_lambda_info(C_heaptop,32,"(##sys#make-lambda-info str1504)");
lf[757]=C_h_intern(&lf[757],6,"module");
lf[758]=C_static_string(C_heaptop,25,"modules are not supported");
lf[759]=C_static_lambda_info(C_heaptop,16,"(a9636 form1428)");
lf[760]=C_h_intern(&lf[760],13,"define-syntax");
lf[761]=C_static_string(C_heaptop,34,"highlevel macros are not supported");
lf[762]=C_static_lambda_info(C_heaptop,16,"(a9642 form1427)");
lf[763]=C_static_lambda_info(C_heaptop,13,"(a9661 x1425)");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
lf[764]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
lf[765]=C_static_lambda_info(C_heaptop,17,"(a9648 . ids1424)");
lf[766]=C_static_lambda_info(C_heaptop,25,"(expand name1417 val1418)");
lf[767]=C_h_intern(&lf[767],12,"define-macro");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[768]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
lf[769]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,6,"symbol");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"lambda-list");
lf[770]=C_h_pair(C_restore,tmp);
lf[771]=C_static_lambda_info(C_heaptop,27,"(a9667 head1414 . body1415)");
lf[772]=C_static_string(C_heaptop,4,"#;> ");
lf[773]=C_static_lambda_info(C_heaptop,7,"(a9809)");
lf[774]=C_h_intern(&lf[774],14,"make-parameter");
tmp=C_intern(C_heaptop,7,"\000srfi-8");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"\000srfi-6");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"\000srfi-2");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"\000srfi-0");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"\000srfi-10");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"\000srfi-9");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"\000srfi-55");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"\000srfi-61");
C_save(tmp);
lf[775]=C_h_list(8,C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(8);
lf[776]=C_h_intern(&lf[776],16,"\003sysmake-promise");
lf[777]=C_static_lambda_info(C_heaptop,13,"(a9812 x1308)");
lf[778]=C_h_intern(&lf[778],5,"delay");
lf[779]=C_static_lambda_info(C_heaptop,18,"(walk x1282 n1283)");
lf[780]=C_h_intern(&lf[780],16,"\003syslist->vector");
lf[781]=C_h_intern(&lf[781],7,"unquote");
lf[782]=C_h_intern(&lf[782],8,"\003syslist");
tmp=C_intern(C_heaptop,5,"quote");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"unquote");
C_save(tmp);
lf[783]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,5,"quote");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"unquote");
C_save(tmp);
lf[784]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[785]=C_h_intern(&lf[785],10,"quasiquote");
lf[786]=C_h_intern(&lf[786],8,"\003syscons");
lf[787]=C_h_intern(&lf[787],16,"unquote-splicing");
lf[788]=C_static_lambda_info(C_heaptop,19,"(walk1 x1284 n1285)");
lf[789]=C_h_intern(&lf[789],1,"a");
lf[790]=C_h_intern(&lf[790],1,"b");
tmp=C_intern(C_heaptop,10,"\003sysappend");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"quote");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
lf[791]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[792]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,8,"\003syscons");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"\003syslist");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"b");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
lf[793]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"b");
C_save(tmp);
lf[794]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,8,"\003syscons");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"quote");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
lf[795]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[796]=C_h_pair(C_restore,tmp);
lf[797]=C_static_lambda_info(C_heaptop,16,"(simplify x1294)");
lf[798]=C_static_lambda_info(C_heaptop,16,"(a9822 form1278)");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[799]=C_h_pair(C_restore,tmp);
lf[800]=C_static_lambda_info(C_heaptop,14,"(a10168 b1274)");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[801]=C_h_pair(C_restore,tmp);
lf[802]=C_static_lambda_info(C_heaptop,14,"(a10215 b1272)");
lf[803]=C_static_string(C_heaptop,2,"do");
lf[804]=C_h_intern(&lf[804],2,"do");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
lf[805]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,6,"symbol");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_h_vector(1,C_pick(0));
C_drop(1);
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
lf[806]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
lf[807]=C_static_lambda_info(C_heaptop,41,"(a10114 bindings1268 test1269 . body1270)");
lf[808]=C_static_lambda_info(C_heaptop,14,"(a10279 b1264)");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[809]=C_h_pair(C_restore,tmp);
lf[810]=C_static_lambda_info(C_heaptop,14,"(a10293 b1263)");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
lf[811]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,6,"symbol");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
lf[812]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
lf[813]=C_static_lambda_info(C_heaptop,17,"(a10233 form1260)");
lf[814]=C_static_lambda_info(C_heaptop,15,"(expand bs1256)");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
lf[815]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,6,"symbol");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
lf[816]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
lf[817]=C_static_lambda_info(C_heaptop,17,"(a10303 form1252)");
lf[818]=C_h_intern(&lf[818],4,"else");
lf[819]=C_h_intern(&lf[819],2,"or");
lf[820]=C_h_intern(&lf[820],4,"eqv\077");
lf[821]=C_static_lambda_info(C_heaptop,14,"(a10433 x1249)");
lf[822]=C_h_intern(&lf[822],4,"case");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
lf[823]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[824]=C_h_pair(C_restore,tmp);
lf[825]=C_static_lambda_info(C_heaptop,20,"(expand clauses1246)");
lf[826]=C_static_lambda_info(C_heaptop,17,"(a10356 form1241)");
lf[827]=C_h_intern(&lf[827],2,"=>");
lf[828]=C_h_intern(&lf[828],9,"\003sysapply");
lf[829]=C_h_intern(&lf[829],4,"cond");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
lf[830]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[831]=C_h_pair(C_restore,tmp);
lf[832]=C_static_lambda_info(C_heaptop,20,"(expand clauses1233)");
lf[833]=C_static_lambda_info(C_heaptop,17,"(a10459 body1231)");
lf[834]=C_static_lambda_info(C_heaptop,17,"(a10656 body1226)");
lf[835]=C_h_intern(&lf[835],3,"and");
lf[836]=C_static_lambda_info(C_heaptop,17,"(a10699 body1222)");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
lf[837]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"lambda-list");
lf[838]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
lf[839]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,6,"symbol");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"lambda-list");
lf[840]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,8,"\003sysvoid");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[841]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
lf[842]=C_h_vector(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
lf[843]=C_static_lambda_info(C_heaptop,15,"(loop form1212)");
lf[844]=C_static_lambda_info(C_heaptop,17,"(a10727 form1210)");
tmp=C_intern(C_heaptop,12,"dynamic-wind");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"values");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"call-with-values");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"eval");
C_save(tmp);
tmp=C_intern(C_heaptop,25,"scheme-report-environment");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"null-environment");
C_save(tmp);
tmp=C_intern(C_heaptop,23,"interaction-environment");
C_save(tmp);
lf[845]=C_h_list(7,C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(7);
tmp=C_intern(C_heaptop,3,"not");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"boolean\077");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"eq\077");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"eqv\077");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"equal\077");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"pair\077");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cons");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"caar");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cadr");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cdar");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cddr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caaar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caadr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cadar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caddr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdaar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdadr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cddar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdddr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caaaar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caaadr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caadar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caaddr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cadaar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cadadr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cadddr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdaaar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdaadr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdadar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdaddr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cddaar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cddadr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdddar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cddddr");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"set-car!");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"set-cdr!");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"null\077");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"list\077");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"list");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"length");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"list-tail");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"list-ref");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"append");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"reverse");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"memq");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"memv");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"member");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"assq");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"assv");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"assoc");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"symbol\077");
C_save(tmp);
tmp=C_intern(C_heaptop,14,"symbol->string");
C_save(tmp);
tmp=C_intern(C_heaptop,14,"string->symbol");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"number\077");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"integer\077");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"exact\077");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"real\077");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"complex\077");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"inexact\077");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"rational\077");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"zero\077");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"odd\077");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"even\077");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"positive\077");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"negative\077");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"max");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"min");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"+");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"-");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"*");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"/");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"=");
C_save(tmp);
tmp=C_intern(C_heaptop,1,">");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"<");
C_save(tmp);
tmp=C_intern(C_heaptop,2,">=");
C_save(tmp);
tmp=C_intern(C_heaptop,2,"<=");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"quotient");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"remainder");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"modulo");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"gcd");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"lcm");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"abs");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"floor");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"ceiling");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"truncate");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"round");
C_save(tmp);
tmp=C_intern(C_heaptop,14,"exact->inexact");
C_save(tmp);
tmp=C_intern(C_heaptop,14,"inexact->exact");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"exp");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"log");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"expt");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"sqrt");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"sin");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cos");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"tan");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"asin");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"acos");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"atan");
C_save(tmp);
tmp=C_intern(C_heaptop,14,"number->string");
C_save(tmp);
tmp=C_intern(C_heaptop,14,"string->number");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"char\077");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"char=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"char>\077");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"char<\077");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"char>=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"char<=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"char-ci=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"char-ci<\077");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"char-ci>\077");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"char-ci>=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"char-ci<=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"char-alphabetic\077");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"char-whitespace\077");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"char-numeric\077");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"char-upper-case\077");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"char-lower-case\077");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"char-upcase");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"char-downcase");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"char->integer");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"integer->char");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"string\077");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"string=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"string>\077");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"string<\077");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"string>=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"string<=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"string-ci=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"string-ci<\077");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"string-ci>\077");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"string-ci>=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"string-ci<=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"make-string");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"string-length");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"string-ref");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"string-set!");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"string-append");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"string-copy");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"string->list");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"list->string");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"substring");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"string-fill!");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"vector\077");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"make-vector");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"vector-ref");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"vector-set!");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"string");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"vector");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"vector-length");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"vector->list");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"list->vector");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"vector-fill!");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"procedure\077");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"map");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"for-each");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"apply");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"force");
C_save(tmp);
tmp=C_intern(C_heaptop,30,"call-with-current-continuation");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"input-port\077");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"output-port\077");
C_save(tmp);
tmp=C_intern(C_heaptop,18,"current-input-port");
C_save(tmp);
tmp=C_intern(C_heaptop,19,"current-output-port");
C_save(tmp);
tmp=C_intern(C_heaptop,20,"call-with-input-file");
C_save(tmp);
tmp=C_intern(C_heaptop,21,"call-with-output-file");
C_save(tmp);
tmp=C_intern(C_heaptop,15,"open-input-file");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"open-output-file");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"close-input-port");
C_save(tmp);
tmp=C_intern(C_heaptop,17,"close-output-port");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"load");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"read");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"eof-object\077");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"read-char");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"peek-char");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"write");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"display");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"write-char");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"newline");
C_save(tmp);
tmp=C_intern(C_heaptop,20,"with-input-from-file");
C_save(tmp);
tmp=C_intern(C_heaptop,19,"with-output-to-file");
C_save(tmp);
tmp=C_intern(C_heaptop,20,"\003syscall-with-values");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"\003sysvalues");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"\003sysdynamic-wind");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"\003sysvoid");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"\003syslist->vector");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"\003syslist");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"\003sysappend");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"\003syscons");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"\003sysmake-promise");
C_save(tmp);
lf[846]=C_h_list(189,C_pick(188),C_pick(187),C_pick(186),C_pick(185),C_pick(184),C_pick(183),C_pick(182),C_pick(181),C_pick(180),C_pick(179),C_pick(178),C_pick(177),C_pick(176),C_pick(175),C_pick(174),C_pick(173),C_pick(172),C_pick(171),C_pick(170),C_pick(169),C_pick(168),C_pick(167),C_pick(166),C_pick(165),C_pick(164),C_pick(163),C_pick(162),C_pick(161),C_pick(160),C_pick(159),C_pick(158),C_pick(157),C_pick(156),C_pick(155),C_pick(154),C_pick(153),C_pick(152),C_pick(151),C_pick(150),C_pick(149),C_pick(148),C_pick(147),C_pick(146),C_pick(145),C_pick(144),C_pick(143),C_pick(142),C_pick(141),C_pick(140),C_pick(139),C_pick(138),C_pick(137),C_pick(136),C_pick(135),C_pick(134),C_pick(133),C_pick(132),C_pick(131),C_pick(130),C_pick(129),C_pick(128),C_pick(127),C_pick(126),C_pick(125),C_pick(124),C_pick(123),C_pick(122),C_pick(121),C_pick(120),C_pick(119),C_pick(118),C_pick(117),C_pick(116),C_pick(115),C_pick(114),C_pick(113),C_pick(112),C_pick(111),C_pick(110),C_pick(109),C_pick(108),C_pick(107),C_pick(106),C_pick(105),C_pick(104),C_pick(103),C_pick(102),C_pick(101),C_pick(100),C_pick(99),C_pick(98),C_pick(97),C_pick(96),C_pick(95),C_pick(94),C_pick(93),C_pick(92),C_pick(91),C_pick(90),C_pick(89),C_pick(88),C_pick(87),C_pick(86),C_pick(85),C_pick(84),C_pick(83),C_pick(82),C_pick(81),C_pick(80),C_pick(79),C_pick(78),C_pick(77),C_pick(76),C_pick(75),C_pick(74),C_pick(73),C_pick(72),C_pick(71),C_pick(70),C_pick(69),C_pick(68),C_pick(67),C_pick(66),C_pick(65),C_pick(64),C_pick(63),C_pick(62),C_pick(61),C_pick(60),C_pick(59),C_pick(58),C_pick(57),C_pick(56),C_pick(55),C_pick(54),C_pick(53),C_pick(52),C_pick(51),C_pick(50),C_pick(49),C_pick(48),C_pick(47),C_pick(46),C_pick(45),C_pick(44),C_pick(43),C_pick(42),C_pick(41),C_pick(40),C_pick(39),C_pick(38),C_pick(37),C_pick(36),C_pick(35),C_pick(34),C_pick(33),C_pick(32),C_pick(31),C_pick(30),C_pick(29),C_pick(28),C_pick(27),C_pick(26),C_pick(25),C_pick(24),C_pick(23),C_pick(22),C_pick(21),C_pick(20),C_pick(19),C_pick(18),C_pick(17),C_pick(16),C_pick(15),C_pick(14),C_pick(13),C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(189);
lf[847]=C_h_intern(&lf[847],18,"\003sysnumber->string");
lf[848]=C_h_intern(&lf[848],5,"error");
lf[849]=C_static_string(C_heaptop,25,"invalid extension version");
lf[850]=C_static_lambda_info(C_heaptop,16,"(->string x1007)");
lf[851]=C_h_intern(&lf[851],7,"version");
lf[852]=C_static_string(C_heaptop,51,"installed extension does not match required version");
lf[853]=C_h_intern(&lf[853],9,"string>=\077");
lf[854]=C_static_string(C_heaptop,29,"invalid version specification");
lf[855]=C_static_lambda_info(C_heaptop,23,"(a10830 spec1000 _1001)");
lf[856]=C_h_intern(&lf[856],12,"list->vector");
lf[857]=C_h_intern(&lf[857],18,"\003sysstring->symbol");
lf[858]=C_static_string(C_heaptop,5,"srfi-");
lf[859]=C_static_lambda_info(C_heaptop,13,"(loop ids996)");
lf[860]=C_static_lambda_info(C_heaptop,23,"(a10951 spec993 old994)");
lf[861]=C_h_intern(&lf[861],4,"srfi");
lf[862]=C_static_lambda_info(C_heaptop,13,"(a11017 x830)");
lf[863]=C_static_lambda_info(C_heaptop,16,"(a11023 g828829)");
lf[864]=C_h_intern(&lf[864],14,"build-platform");
lf[865]=C_h_intern(&lf[865],7,"windows");
lf[866]=C_h_intern(&lf[866],6,"macosx");
lf[867]=C_h_intern(&lf[867],4,"hpux");
lf[868]=C_h_intern(&lf[868],4,"hppa");
lf[869]=C_h_intern(&lf[869],12,"machine-type");
lf[870]=C_h_intern(&lf[870],16,"software-version");
lf[871]=C_h_intern(&lf[871],13,"software-type");
lf[872]=C_static_string(C_heaptop,10,"C_toplevel");
lf[873]=C_static_lambda_info(C_heaptop,8,"(a11085)");
lf[874]=C_static_lambda_info(C_heaptop,8,"(a11095)");
lf[875]=C_static_lambda_info(C_heaptop,8,"(a11101)");
lf[876]=C_static_lambda_info(C_heaptop,22,"(a11073 x650 . env651)");
lf[877]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf2(lf,878,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=C_mutate((C_word*)lf[2]+1,lf[3]);
t4=C_set_block_item(lf[4],0,C_SCHEME_END_OF_LIST);
t5=C_mutate(&lf[5],lf[6]);
t6=C_mutate(&lf[7],lf[8]);
t7=C_mutate(&lf[9],lf[10]);
t8=C_mutate(&lf[11],lf[12]);
t9=C_mutate(&lf[13],lf[14]);
t10=C_mutate(&lf[15],lf[16]);
t11=C_mutate(&lf[17],lf[18]);
t12=C_mutate(&lf[19],lf[20]);
t13=C_mutate(&lf[21],lf[22]);
t14=C_mutate(&lf[23],lf[24]);
t15=C_mutate(&lf[25],lf[26]);
t16=C_mutate(&lf[27],lf[28]);
t17=*((C_word*)lf[29]+1);
t18=C_mutate((C_word*)lf[30]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1672,a[2]=t17,a[3]=lf[37],tmp=(C_word)a,a+=4,tmp));
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1711,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 157  make-vector */
t20=*((C_word*)lf[576]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t19,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k1709 */
static void C_ccall f_1711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word ab[92],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1711,2,t0,t1);}
t2=C_mutate((C_word*)lf[38]+1,t1);
t3=C_mutate((C_word*)lf[39]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1713,a[2]=lf[42],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[43]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1729,a[2]=lf[45],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[46]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1745,a[2]=lf[48],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[49]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1755,a[2]=lf[50],tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[51]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1773,a[2]=lf[52],tmp=(C_word)a,a+=3,tmp));
t8=*((C_word*)lf[53]+1);
t9=C_mutate((C_word*)lf[54]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1782,a[2]=t8,a[3]=lf[92],tmp=(C_word)a,a+=4,tmp));
t10=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2152,a[2]=lf[94],tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[95]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2155,a[2]=lf[96],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[97]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2158,a[2]=lf[98],tmp=(C_word)a,a+=3,tmp));
t13=C_set_block_item(lf[99],0,C_SCHEME_FALSE);
t14=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2165,a[2]=lf[104],tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[105]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2201,a[2]=lf[106],tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[107]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2217,a[2]=lf[112],tmp=(C_word)a,a+=3,tmp));
t17=*((C_word*)lf[113]+1);
t18=*((C_word*)lf[114]+1);
t19=C_mutate((C_word*)lf[115]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2260,a[2]=t18,a[3]=t17,a[4]=lf[140],tmp=(C_word)a,a+=5,tmp));
t20=*((C_word*)lf[113]+1);
t21=*((C_word*)lf[141]+1);
t22=C_mutate((C_word*)lf[142]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2779,a[2]=t21,a[3]=t20,a[4]=lf[169],tmp=(C_word)a,a+=5,tmp));
t23=C_mutate((C_word*)lf[170]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3265,a[2]=lf[172],tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[154]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3356,a[2]=lf[174],tmp=(C_word)a,a+=3,tmp));
t25=C_SCHEME_FALSE;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_FALSE;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_mutate((C_word*)lf[175]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3416,a[2]=t28,a[3]=t26,a[4]=lf[176],tmp=(C_word)a,a+=5,tmp));
t30=C_mutate((C_word*)lf[47]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3431,a[2]=lf[178],tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[41]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3476,a[2]=lf[180],tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[181]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3531,a[2]=lf[185],tmp=(C_word)a,a+=3,tmp));
t33=(C_word)C_slot(lf[186],C_fix(0));
t34=C_mutate((C_word*)lf[187]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3577,a[2]=t33,a[3]=lf[189],tmp=(C_word)a,a+=4,tmp));
t35=C_set_block_item(lf[190],0,C_SCHEME_FALSE);
t36=C_set_block_item(lf[191],0,C_SCHEME_FALSE);
t37=C_mutate((C_word*)lf[192]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3637,a[2]=lf[200],tmp=(C_word)a,a+=3,tmp));
t38=C_set_block_item(lf[201],0,C_SCHEME_FALSE);
t39=C_set_block_item(lf[202],0,C_fix(1));
t40=C_mutate((C_word*)lf[203]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3678,a[2]=lf[204],tmp=(C_word)a,a+=3,tmp));
t41=*((C_word*)lf[49]+1);
t42=*((C_word*)lf[196]+1);
t43=*((C_word*)lf[205]+1);
t44=*((C_word*)lf[113]+1);
t45=*((C_word*)lf[197]+1);
t46=*((C_word*)lf[195]+1);
t47=*((C_word*)lf[206]+1);
t48=(C_word)C_slot(lf[186],C_fix(0));
t49=*((C_word*)lf[207]+1);
t50=C_mutate((C_word*)lf[208]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3684,a[2]=t43,a[3]=t48,a[4]=lf[372],tmp=(C_word)a,a+=5,tmp));
t51=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5927,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11074,a[2]=lf[876],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1038 make-parameter */
t53=*((C_word*)lf[774]+1);
((C_proc3)(void*)(*((C_word*)t53+1)))(3,t53,t51,t52);}

/* a11073 in k1709 */
static void C_ccall f_11074(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3rv,(void*)f_11074r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_11074r(t0,t1,t2,t3);}}

static void C_ccall f_11074r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(10);
t4=*((C_word*)lf[191]+1);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11078,a[2]=t2,a[3]=t1,a[4]=t7,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t9=(C_word)C_i_vector_ref(t3,C_fix(0));
if(C_truep(t9)){
t10=(C_word)C_i_check_structure(t9,lf[559]);
t11=(C_word)C_slot(t9,C_fix(1));
t12=C_set_block_item(t7,0,t11);
t13=(C_word)C_slot(t9,C_fix(2));
t14=C_set_block_item(t5,0,t13);
t15=t8;
f_11078(t15,t14);}
else{
t10=t8;
f_11078(t10,C_SCHEME_UNDEFINED);}}
else{
t9=t8;
f_11078(t9,C_SCHEME_UNDEFINED);}}

/* k11076 in a11073 in k1709 */
static void C_fcall f_11078(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[29],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11078,NULL,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11084,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11086,a[2]=t5,a[3]=t3,a[4]=t9,a[5]=t7,a[6]=lf[873],tmp=(C_word)a,a+=7,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11096,a[2]=((C_word*)t0)[2],a[3]=lf[874],tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11102,a[2]=t9,a[3]=t7,a[4]=t5,a[5]=t3,a[6]=lf[875],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1048 ##sys#dynamic-wind */
t14=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t10,t11,t12,t13);}

/* a11101 in k11076 in a11073 in k1709 */
static void C_ccall f_11102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11102,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[191]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[190]+1));
t4=C_mutate((C_word*)lf[191]+1,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate((C_word*)lf[190]+1,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,*((C_word*)lf[407]+1));}

/* a11095 in k11076 in a11073 in k1709 */
static void C_ccall f_11096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11096,2,t0,t1);}
/* eval.scm: 1050 ##sys#compile-to-closure */
t2=*((C_word*)lf[208]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* a11085 in k11076 in a11073 in k1709 */
static void C_ccall f_11086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11086,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[191]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[190]+1));
t4=C_mutate((C_word*)lf[191]+1,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate((C_word*)lf[190]+1,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,*((C_word*)lf[407]+1));}

/* k11082 in k11076 in a11073 in k1709 */
static void C_ccall f_11084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5925 in k1709 */
static void C_ccall f_5927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5927,2,t0,t1);}
t2=C_mutate((C_word*)lf[373]+1,t1);
t3=C_mutate((C_word*)lf[374]+1,*((C_word*)lf[373]+1));
t4=C_mutate((C_word*)lf[375]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5930,a[2]=lf[376],tmp=(C_word)a,a+=3,tmp));
t5=*((C_word*)lf[113]+1);
t6=C_mutate((C_word*)lf[311]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5944,a[2]=t5,a[3]=lf[381],tmp=(C_word)a,a+=4,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6026,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fudge(C_fix(13));
/* eval.scm: 1082 make-parameter */
t9=*((C_word*)lf[774]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* k6024 in k5925 in k1709 */
static void C_ccall f_6026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6026,2,t0,t1);}
t2=C_mutate((C_word*)lf[382]+1,t1);
t3=C_mutate((C_word*)lf[383]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6028,a[2]=lf[384],tmp=(C_word)a,a+=3,tmp));
t4=C_set_block_item(lf[385],0,C_SCHEME_FALSE);
t5=C_mutate((C_word*)lf[386]+1,lf[387]);
t6=C_mutate((C_word*)lf[388]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6033,a[2]=lf[397],tmp=(C_word)a,a+=3,tmp));
t7=*((C_word*)lf[398]+1);
t8=*((C_word*)lf[196]+1);
t9=*((C_word*)lf[207]+1);
t10=*((C_word*)lf[399]+1);
t11=*((C_word*)lf[375]+1);
t12=*((C_word*)lf[400]+1);
t13=*((C_word*)lf[401]+1);
t14=*((C_word*)lf[53]+1);
t15=*((C_word*)lf[382]+1);
t16=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6106,a[2]=((C_word*)t0)[2],a[3]=t15,a[4]=t9,a[5]=t12,a[6]=t13,a[7]=t8,a[8]=t10,a[9]=t7,a[10]=t11,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 1114 ##sys#make-c-string */
t17=*((C_word*)lf[431]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t16,lf[872]);}

/* k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6106,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6108,a[2]=lf[403],tmp=(C_word)a,a+=3,tmp);
t3=C_mutate((C_word*)lf[404]+1,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6154,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=lf[446],tmp=(C_word)a,a+=13,tmp));
t4=C_mutate((C_word*)lf[419]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6544,a[2]=lf[447],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[448]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6573,a[2]=lf[449],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[450]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6616,a[2]=lf[457],tmp=(C_word)a,a+=3,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6642,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11068,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1204 software-type */
t9=*((C_word*)lf[871]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}

/* k11066 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_11068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11068,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[865]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_6642(t3,lf[12]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11064,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1205 software-version */
t4=*((C_word*)lf[870]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11062 in k11066 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_11064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11064,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[866]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_6642(t3,lf[10]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11046,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11060,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1206 software-version */
t5=*((C_word*)lf[870]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k11058 in k11062 in k11066 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_11060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11060,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[867]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11056,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1207 machine-type */
t4=*((C_word*)lf[869]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[2];
f_11046(t3,C_SCHEME_FALSE);}}

/* k11054 in k11058 in k11062 in k11066 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_11056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_11046(t2,(C_word)C_eqp(t1,lf[868]));}

/* k11044 in k11062 in k11066 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_11046(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6642(t2,(C_truep(t1)?lf[14]:lf[15]));}

/* k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_6642(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6642,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[458]+1,t1);
t3=C_mutate((C_word*)lf[438]+1,lf[15]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6647,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1213 build-platform */
t5=*((C_word*)lf[864]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6647,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[459]);
t3=(C_truep(t2)?lf[8]:lf[6]);
t4=C_mutate((C_word*)lf[460]+1,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6654,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11016,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11024,a[2]=lf[863],tmp=(C_word)a,a+=3,tmp);
/* map */
t8=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,*((C_word*)lf[460]+1));}

/* a11023 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_11024(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11024,3,t0,t1,t2);}
/* ##sys#string-append */
t3=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[458]+1));}

/* k11014 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_11016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11018,a[2]=lf[862],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1218 make-parameter */
t3=*((C_word*)lf[774]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a11017 in k11014 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_11018(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11018,3,t0,t1,t2);}
t3=(C_word)C_i_check_list(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6654,2,t0,t1);}
t2=C_mutate((C_word*)lf[461]+1,t1);
t3=*((C_word*)lf[382]+1);
t4=*((C_word*)lf[53]+1);
t5=*((C_word*)lf[461]+1);
t6=*((C_word*)lf[207]+1);
t7=C_mutate((C_word*)lf[462]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6656,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t6,a[6]=lf[470],tmp=(C_word)a,a+=7,tmp));
t8=C_mutate((C_word*)lf[471]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6762,a[2]=lf[473],tmp=(C_word)a,a+=3,tmp));
t9=*((C_word*)lf[113]+1);
t10=C_mutate(&lf[474],(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6791,a[2]=t9,a[3]=lf[476],tmp=(C_word)a,a+=4,tmp));
t11=*((C_word*)lf[53]+1);
t12=C_mutate((C_word*)lf[477]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6847,a[2]=t11,a[3]=lf[487],tmp=(C_word)a,a+=4,tmp));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7007,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11006,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1306 getenv */
t15=*((C_word*)lf[29]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t14,lf[22]);}

/* k11004 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_11006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11009,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_11009(2,t3,t1);}
else{
/* ##sys#peek-c-string */
t3=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_EGG_HOME),C_fix(0));}}

/* k11007 in k11004 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_11009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1305 make-parameter */
t2=*((C_word*)lf[774]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[45],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7007,2,t0,t1);}
t2=C_mutate((C_word*)lf[488]+1,t1);
t3=C_mutate((C_word*)lf[489]+1,*((C_word*)lf[488]+1));
t4=*((C_word*)lf[490]+1);
t5=*((C_word*)lf[53]+1);
t6=C_mutate((C_word*)lf[491]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7010,a[2]=t5,a[3]=t4,a[4]=lf[497],tmp=(C_word)a,a+=5,tmp));
t7=C_set_block_item(lf[498],0,C_SCHEME_END_OF_LIST);
t8=*((C_word*)lf[499]+1);
t9=C_mutate((C_word*)lf[500]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7087,a[2]=t8,a[3]=lf[502],tmp=(C_word)a,a+=4,tmp));
t10=C_mutate((C_word*)lf[503]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7162,a[2]=lf[506],tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[504]+1,*((C_word*)lf[503]+1));
t12=C_mutate((C_word*)lf[507]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7182,a[2]=lf[509],tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[508]+1,*((C_word*)lf[507]+1));
t14=C_mutate((C_word*)lf[318]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7196,a[2]=lf[512],tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[510]+1,*((C_word*)lf[318]+1));
t16=*((C_word*)lf[206]+1);
t17=*((C_word*)lf[490]+1);
t18=*((C_word*)lf[53]+1);
t19=*((C_word*)lf[398]+1);
t20=C_mutate((C_word*)lf[513]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7209,a[2]=t18,a[3]=t17,a[4]=t19,a[5]=t16,a[6]=lf[517],tmp=(C_word)a,a+=7,tmp));
t21=C_mutate((C_word*)lf[518]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7240,a[2]=lf[519],tmp=(C_word)a,a+=3,tmp));
t22=*((C_word*)lf[206]+1);
t23=*((C_word*)lf[398]+1);
t24=C_mutate((C_word*)lf[320]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7246,a[2]=lf[522],tmp=(C_word)a,a+=3,tmp));
t25=*((C_word*)lf[523]+1);
t26=C_mutate((C_word*)lf[324]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7295,a[2]=t25,a[3]=lf[549],tmp=(C_word)a,a+=4,tmp));
t27=C_set_block_item(lf[543],0,C_SCHEME_END_OF_LIST);
t28=C_mutate((C_word*)lf[550]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7694,a[2]=lf[553],tmp=(C_word)a,a+=3,tmp));
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7733,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t30=*((C_word*)lf[856]+1);
t31=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10952,a[2]=t30,a[3]=lf[860],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1493 set-extension-specifier! */
t32=*((C_word*)lf[550]+1);
((C_proc4)C_retrieve_proc(t32))(4,t32,t29,lf[861],t31);}

/* a10951 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10952(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10952,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10960,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10966,a[2]=t7,a[3]=lf[859],tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_10966(t9,t4,t5);}

/* loop in a10951 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_10966(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10966,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_check_exact_2(t3,lf[539]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10986,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10998,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11002,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1503 number->string */
C_number_to_string(3,0,t7,t3);}}

/* k11000 in loop in a10951 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_11002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1503 ##sys#string-append */
t2=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[858],t1);}

/* k10996 in loop in a10951 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1503 ##sys#string->symbol */
t2=*((C_word*)lf[857]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k10984 in loop in a10951 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10990,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* eval.scm: 1504 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_10966(t4,t2,t3);}

/* k10988 in k10984 in loop in a10951 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10990,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10958 in a10951 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1497 list->vector */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7736,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10831,a[2]=lf[855],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1509 set-extension-specifier! */
t4=*((C_word*)lf[550]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[851],t3);}

/* a10830 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10831(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10831,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10834,a[2]=lf[850],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10868,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[851]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_cdddr(t2);
t11=t5;
f_10868(t11,(C_word)C_i_nullp(t10));}
else{
t10=t5;
f_10868(t10,C_SCHEME_FALSE);}}
else{
t9=t5;
f_10868(t9,C_SCHEME_FALSE);}}
else{
t8=t5;
f_10868(t8,C_SCHEME_FALSE);}}
else{
t6=t5;
f_10868(t6,C_SCHEME_FALSE);}}

/* k10866 in a10830 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_10868(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10868,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10877,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1519 extension-information */
t5=*((C_word*)lf[518]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
/* syntax-error */
t2=*((C_word*)lf[601]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[539],lf[854],((C_word*)t0)[4]);}}

/* k10875 in k10866 in a10830 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10877,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_assq(lf[851],t1):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10883,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10886,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10896,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_car(t2);
/* eval.scm: 1521 ->string */
f_10834(t5,t6);}
else{
t5=t4;
f_10886(2,t5,C_SCHEME_FALSE);}}

/* k10894 in k10875 in k10866 in a10830 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10900,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1521 ->string */
f_10834(t2,((C_word*)t0)[2]);}

/* k10898 in k10894 in k10875 in k10866 in a10830 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1521 string>=? */
t2=*((C_word*)lf[853]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10884 in k10875 in k10866 in a10830 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_10883(2,t2,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 1522 error */
t2=*((C_word*)lf[848]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],lf[852],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k10881 in k10875 in k10866 in a10830 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ->string in a10830 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_10834(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10834,NULL,2,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
/* eval.scm: 1515 ##sys#number->string */
t3=*((C_word*)lf[847]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
/* eval.scm: 1516 error */
t3=*((C_word*)lf[848]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[849],t2);}}}}

/* k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7736,2,t0,t1);}
t2=*((C_word*)lf[554]+1);
t3=C_mutate((C_word*)lf[468]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7738,a[2]=t2,a[3]=lf[556],tmp=(C_word)a,a+=4,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7794,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1543 make-vector */
t5=*((C_word*)lf[576]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7794,2,t0,t1);}
t2=C_mutate(&lf[557],t1);
t3=lf[558]=C_SCHEME_FALSE;;
t4=(C_word)C_a_i_record(&a,3,lf[559],C_SCHEME_FALSE,C_SCHEME_TRUE);
t5=C_mutate(&lf[560],t4);
t6=C_mutate((C_word*)lf[561]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7801,a[2]=lf[564],tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[565]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7909,a[2]=lf[570],tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[571]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8028,a[2]=lf[572],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[573]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8031,a[2]=lf[575],tmp=(C_word)a,a+=3,tmp));
t10=*((C_word*)lf[576]+1);
t11=C_mutate((C_word*)lf[577]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8075,a[2]=t10,a[3]=lf[579],tmp=(C_word)a,a+=4,tmp));
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8113,a[2]=lf[581],tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8129,a[2]=t12,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10829,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1624 initb */
f_8113(t14,lf[557]);}

/* k10827 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[183]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[846]);}

/* k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8129,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8133,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1645 ##sys#copy-env-table */
t3=*((C_word*)lf[561]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[557],C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8133,2,t0,t1);}
t2=C_mutate(&lf[558],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8136,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10825,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1647 initb */
f_8113(t4,lf[558]);}

/* k10823 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[183]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[845]);}

/* k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8136,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8140,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1654 chicken-home */
t3=*((C_word*)lf[30]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[44],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8140,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_a_i_list(&a,1,t1):C_SCHEME_END_OF_LIST);
t3=C_mutate((C_word*)lf[495]+1,t2);
t4=*((C_word*)lf[53]+1);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8146,a[2]=lf[582],tmp=(C_word)a,a+=3,tmp);
t6=C_mutate((C_word*)lf[536]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8165,a[2]=t4,a[3]=t5,a[4]=lf[587],tmp=(C_word)a,a+=5,tmp));
t7=*((C_word*)lf[207]+1);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8295,a[2]=t7,a[3]=lf[589],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8319,a[2]=t8,a[3]=t7,a[4]=lf[591],tmp=(C_word)a,a+=5,tmp);
t10=C_mutate((C_word*)lf[411]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8340,a[2]=t9,a[3]=t7,a[4]=lf[597],tmp=(C_word)a,a+=5,tmp));
t11=C_set_block_item(lf[598],0,C_SCHEME_FALSE);
t12=C_mutate((C_word*)lf[73]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8394,a[2]=lf[600],tmp=(C_word)a,a+=3,tmp));
t13=C_set_block_item(lf[377],0,C_SCHEME_FALSE);
t14=C_mutate((C_word*)lf[601]+1,*((C_word*)lf[73]+1));
t15=C_mutate((C_word*)lf[602]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8402,a[2]=lf[603],tmp=(C_word)a,a+=3,tmp));
t16=*((C_word*)lf[53]+1);
t17=*((C_word*)lf[604]+1);
t18=*((C_word*)lf[602]+1);
t19=*((C_word*)lf[605]+1);
t20=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8438,a[2]=t17,a[3]=t18,a[4]=t19,a[5]=t16,a[6]=lf[646],tmp=(C_word)a,a+=7,tmp));
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8830,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10728,a[2]=lf[844],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1815 ##sys#register-macro-2 */
t23=*((C_word*)lf[39]+1);
((C_proc4)(void*)(*((C_word*)t23+1)))(4,t23,t21,lf[144],t22);}

/* a10727 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10728(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10728,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10734,a[2]=t4,a[3]=lf[843],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_10734(t6,t1,t2);}

/* loop in a10727 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_10734(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10734,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10775,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1826 ##sys#check-syntax */
t7=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[144],t3,lf[838]);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10788,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1830 ##sys#check-syntax */
t7=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[144],t3,lf[840]);}}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10750,a[2]=t3,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1822 ##sys#check-syntax */
t6=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[144],t3,lf[628]);}}

/* k10748 in loop in a10727 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10753,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1823 ##sys#check-syntax */
t3=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[144],((C_word*)t0)[4],lf[842]);}

/* k10751 in k10748 in loop in a10727 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10753,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[4]):lf[841]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[91],((C_word*)t0)[2],t3));}

/* k10786 in loop in a10727 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10791,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1831 ##sys#check-syntax */
t3=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[144],((C_word*)t0)[3],lf[839]);}

/* k10789 in k10786 in loop in a10727 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10791,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=(C_word)C_a_i_cons(&a,2,lf[126],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[91],t2,t5));}

/* k10773 in loop in a10727 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10778,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1827 ##sys#check-syntax */
t3=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[144],((C_word*)t0)[2],lf[837]);}

/* k10776 in k10773 in loop in a10727 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10785,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1828 ##sys#expand-curried-define */
t3=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10783 in k10776 in k10773 in loop in a10727 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1828 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_10734(t2,((C_word*)t0)[2],t1);}

/* k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8830,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8833,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10700,a[2]=lf[836],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1834 ##sys#register-macro-2 */
t4=*((C_word*)lf[39]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[835],t3);}

/* a10699 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10700(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10700,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t5);}
else{
t7=(C_word)C_a_i_cons(&a,2,lf[835],t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,4,lf[252],t5,t7,C_SCHEME_FALSE));}}}

/* k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8833,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8836,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[114]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10657,a[2]=t3,a[3]=lf[834],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1845 ##sys#register-macro-2 */
t5=*((C_word*)lf[39]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[819],t4);}

/* a10656 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10657(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10657,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10679,a[2]=t1,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1855 gensym */
t8=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}}}

/* k10677 in a10656 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[33],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10679,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[819],((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,4,lf[252],t1,t1,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[77],t3,t5));}

/* k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8839,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[114]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10460,a[2]=t3,a[3]=lf[833],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1859 ##sys#register-macro-2 */
t5=*((C_word*)lf[39]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[829],t4);}

/* a10459 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10460(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10460,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10466,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=lf[832],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_10466(t6,t1,t2);}

/* expand in a10459 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_10466(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10466,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10482,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1868 ##sys#check-syntax */
t6=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[829],t3,lf[830]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[831]);}}

/* k10480 in expand in a10459 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10482,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[818],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[143],t4));}
else{
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[6]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10512,a[2]=t6,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1870 expand */
t8=((C_word*)((C_word*)t0)[4])[1];
f_10466(t8,t7,((C_word*)t0)[3]);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[6]);
t7=(C_word)C_eqp(lf[827],t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10521,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1872 gensym */
t9=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t9))(2,t9,t8);}
else{
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[6]))){
t9=(C_word)C_i_length(((C_word*)t0)[6]);
t10=(C_word)C_eqp(t9,C_fix(4));
if(C_truep(t10)){
t11=(C_word)C_i_caddr(((C_word*)t0)[6]);
t12=t8;
f_10558(t12,(C_word)C_eqp(lf[827],t11));}
else{
t11=t8;
f_10558(t11,C_SCHEME_FALSE);}}
else{
t9=t8;
f_10558(t9,C_SCHEME_FALSE);}}}}}

/* k10556 in k10480 in expand in a10459 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_10558(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10558,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10561,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1878 gensym */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,lf[143],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10615,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1887 expand */
t6=((C_word*)((C_word*)t0)[4])[1];
f_10466(t6,t5,((C_word*)t0)[3]);}}

/* k10613 in k10556 in k10480 in expand in a10459 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10615,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[252],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10559 in k10556 in k10480 in expand in a10459 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10561,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,3,lf[126],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,3,lf[828],t4,t1);
t6=(C_word)C_i_cadddr(((C_word*)t0)[5]);
t7=(C_word)C_a_i_list(&a,3,lf[828],t6,t1);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10588,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t7,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1884 expand */
t9=((C_word*)((C_word*)t0)[3])[1];
f_10466(t9,t8,((C_word*)t0)[2]);}

/* k10586 in k10559 in k10556 in k10480 in expand in a10459 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10588,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[252],((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,3,lf[126],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[147],((C_word*)t0)[2],t3));}

/* k10519 in k10480 in expand in a10459 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10521,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_i_caddr(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,t5,t1);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10540,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1876 expand */
t8=((C_word*)((C_word*)t0)[3])[1];
f_10466(t8,t7,((C_word*)t0)[2]);}

/* k10538 in k10519 in k10480 in expand in a10459 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10540,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[252],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[77],((C_word*)t0)[2],t2));}

/* k10510 in k10480 in expand in a10459 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10512,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[819],((C_word*)t0)[2],t1));}

/* k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8842,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[114]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10357,a[2]=t3,a[3]=lf[826],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1889 ##sys#register-macro-2 */
t5=*((C_word*)lf[39]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[822],t4);}

/* a10356 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10357(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10357,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10367,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1895 gensym */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k10365 in a10356 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10367,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10378,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10380,a[2]=t1,a[3]=t6,a[4]=lf[825],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_10380(t8,t4,((C_word*)t0)[2]);}

/* expand in k10365 in a10356 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_10380(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10380,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10396,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1902 ##sys#check-syntax */
t6=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[822],t3,lf[823]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[824]);}}

/* k10394 in expand in k10365 in a10356 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10396,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[818],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[143],t4));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10432,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10434,a[2]=((C_word*)t0)[2],a[3]=lf[821],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[6]);
/* eval.scm: 1905 ##sys#map */
t7=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}}

/* a10433 in k10394 in expand in k10365 in a10356 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10434(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10434,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[124],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[820],((C_word*)t0)[2],t3));}

/* k10430 in k10394 in expand in k10365 in a10356 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10432,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[819],t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,lf[143],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10424,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1907 expand */
t6=((C_word*)((C_word*)t0)[3])[1];
f_10380(t6,t5,((C_word*)t0)[2]);}

/* k10422 in k10430 in k10394 in expand in k10365 in a10356 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10424,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[252],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10376 in k10365 in a10356 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10378,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[77],((C_word*)t0)[2],t1));}

/* k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8845,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10304,a[2]=lf[817],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1909 ##sys#register-macro-2 */
t4=*((C_word*)lf[39]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[123],t3);}

/* a10303 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10304(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10304,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10314,a[2]=t3,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1914 ##sys#check-syntax */
t6=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[123],t3,lf[816]);}

/* k10312 in a10303 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10317,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1915 ##sys#check-syntax */
t3=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[123],((C_word*)t0)[4],lf[815]);}

/* k10315 in k10312 in a10303 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10317,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10322,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=lf[814],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_10322(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k10315 in k10312 in a10303 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_10322(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(13);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10322,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[77],t4));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10347,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(t2);
/* eval.scm: 1919 expand */
t10=t6;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}

/* k10345 in expand in k10315 in k10312 in a10303 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10347,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[77],((C_word*)t0)[2],t1));}

/* k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8848,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10234,a[2]=lf[813],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1921 ##sys#register-macro-2 */
t4=*((C_word*)lf[39]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[79],t3);}

/* a10233 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10234(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10234,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10244,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1926 ##sys#check-syntax */
t6=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[79],t3,lf[812]);}

/* k10242 in a10233 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10247,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1927 ##sys#check-syntax */
t3=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[79],((C_word*)t0)[3],lf[811]);}

/* k10245 in k10242 in a10233 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10258,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10294,a[2]=lf[810],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1928 ##sys#map */
t4=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10293 in k10245 in k10242 in a10233 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10294(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10294,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t3,lf[809]));}

/* k10256 in k10245 in k10242 in a10233 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10258,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10262,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10266,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10280,a[2]=lf[808],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1929 ##sys#map */
t5=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a10279 in k10256 in k10245 in k10242 in a10233 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10280(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10280,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[91],t3,t4));}

/* k10264 in k10256 in k10245 in k10242 in a10233 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10266,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,lf[77],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* ##sys#append */
t5=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k10260 in k10256 in k10245 in k10242 in a10233 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10262,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[77],t2));}

/* k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8851,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[114]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10115,a[2]=t3,a[3]=lf[807],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1932 ##sys#register-macro */
t5=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[804],t4);}

/* a10114 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10115(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_10115r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_10115r(t0,t1,t2,t3,t4);}}

static void C_ccall f_10115r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10119,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1936 ##sys#check-syntax */
t6=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[804],t2,lf[806]);}

/* k10117 in a10114 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10122,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1937 ##sys#check-syntax */
t3=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[804],((C_word*)t0)[6],lf[805]);}

/* k10120 in k10117 in a10114 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10125,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1938 gensym */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[803]);}

/* k10123 in k10120 in k10117 in a10114 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10132,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10216,a[2]=lf[802],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1939 ##sys#map */
t4=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a10215 in k10123 in k10120 in k10117 in a10114 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10216(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10216,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_car(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,2,t3,t5));}

/* k10130 in k10123 in k10120 in k10117 in a10114 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10132,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
t5=(C_truep(t4)?lf[799]:(C_word)C_a_i_cons(&a,2,lf[143],t3));
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10155,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
if(C_truep(t7)){
t8=t6;
f_10155(t8,lf[801]);}
else{
t8=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t9=t6;
f_10155(t9,(C_word)C_a_i_cons(&a,2,lf[77],t8));}}

/* k10153 in k10130 in k10123 in k10120 in k10117 in a10114 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_10155(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10155,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10167,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10169,a[2]=lf[800],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1950 ##sys#map */
t4=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10168 in k10153 in k10130 in k10123 in k10120 in k10117 in a10114 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10169(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10169,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_cdr(t3);
t5=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_car(t2));}
else{
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_car(t7));}}

/* k10165 in k10153 in k10130 in k10123 in k10120 in k10117 in a10114 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[39],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10167,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[80],t2);
t4=(C_word)C_a_i_list(&a,3,lf[143],((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_list(&a,4,lf[252],((C_word*)t0)[5],((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,4,lf[77],((C_word*)t0)[7],((C_word*)t0)[2],t5));}

/* k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8854,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[523]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9823,a[2]=t3,a[3]=lf[798],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1956 ##sys#register-macro */
t5=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[785],t4);}

/* a9822 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9823(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[20],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9823,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9826,a[2]=t6,a[3]=t8,a[4]=lf[779],tmp=(C_word)a,a+=5,tmp));
t10=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9836,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=lf[788],tmp=(C_word)a,a+=5,tmp));
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10033,a[2]=t8,a[3]=lf[797],tmp=(C_word)a,a+=4,tmp));
/* eval.scm: 2017 walk */
t12=((C_word*)t4)[1];
f_9826(t12,t1,t2,C_fix(0));}

/* simplify in a9822 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_10033(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10033,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10037,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2004 ##sys#match-expression */
t4=*((C_word*)lf[170]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,lf[795],lf[796]);}

/* k10035 in simplify in a9822 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10037,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[789],t1);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_list(&a,2,lf[782],t3);
/* eval.scm: 2005 simplify */
t5=((C_word*)((C_word*)t0)[4])[1];
f_10033(t5,((C_word*)t0)[3],t4);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10058,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2006 ##sys#match-expression */
t3=*((C_word*)lf[170]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],lf[793],lf[794]);}}

/* k10056 in k10035 in simplify in a9822 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10058,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[790],t1);
t3=(C_word)C_i_length(t2);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(32)))){
t4=(C_word)C_i_assq(lf[789],t1);
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,lf[782],t7);
/* eval.scm: 2010 simplify */
t9=((C_word*)((C_word*)t0)[4])[1];
f_10033(t9,((C_word*)t0)[3],t8);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10100,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2013 ##sys#match-expression */
t3=*((C_word*)lf[170]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],lf[791],lf[792]);}}

/* k10098 in k10056 in k10035 in simplify in a9822 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[789],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* walk1 in a9822 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_9836(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[72],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9836,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9850,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9854,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1966 vector->list */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
if(C_truep((C_word)C_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_eqp(t4,lf[781]);
if(C_truep(t6)){
t7=(C_truep((C_word)C_blockp(t5))?(C_word)C_pairp(t5):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_slot(t5,C_fix(0));
t9=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t8);}
else{
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9897,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_fixnum_difference(t3,C_fix(1));
/* eval.scm: 1978 walk */
t12=((C_word*)((C_word*)t0)[3])[1];
f_9826(t12,t10,t8,t11);}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[784]);}}
else{
t7=(C_word)C_eqp(t4,lf[785]);
if(C_truep(t7)){
t8=(C_truep((C_word)C_blockp(t5))?(C_word)C_pairp(t5):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=(C_word)C_a_i_list(&a,2,lf[124],lf[785]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9924,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_slot(t5,C_fix(0));
t12=(C_word)C_fixnum_plus(t3,C_fix(1));
/* eval.scm: 1983 walk */
t13=((C_word*)((C_word*)t0)[3])[1];
f_9826(t13,t10,t11,t12);}
else{
t9=(C_word)C_a_i_list(&a,2,lf[124],lf[785]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9943,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1984 walk */
t11=((C_word*)((C_word*)t0)[3])[1];
f_9826(t11,t10,t5,t3);}}
else{
t8=(C_truep((C_word)C_blockp(t4))?(C_word)C_pairp(t4):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=(C_word)C_slot(t4,C_fix(0));
t10=(C_word)C_slot(t4,C_fix(1));
t11=(C_word)C_eqp(t9,lf[787]);
t12=(C_truep(t11)?(C_truep((C_word)C_blockp(t10))?(C_word)C_pairp(t10):C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t12)){
t13=(C_word)C_slot(t10,C_fix(0));
t14=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9977,a[2]=t13,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1995 walk */
t16=((C_word*)((C_word*)t0)[3])[1];
f_9826(t16,t15,t5,t3);}
else{
t15=(C_word)C_a_i_list(&a,2,lf[124],lf[787]);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9996,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t15,tmp=(C_word)a,a+=7,tmp);
t17=(C_word)C_fixnum_difference(t3,C_fix(1));
/* eval.scm: 1997 walk */
t18=((C_word*)((C_word*)t0)[3])[1];
f_9826(t18,t16,t13,t17);}}
else{
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10007,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1999 walk */
t14=((C_word*)((C_word*)t0)[3])[1];
f_9826(t14,t13,t4,t3);}}
else{
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10024,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2000 walk */
t10=((C_word*)((C_word*)t0)[3])[1];
f_9826(t10,t9,t4,t3);}}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[124],t2));}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[124],t2));}}

/* k10022 in walk1 in a9822 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10028,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2000 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9826(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10026 in k10022 in walk1 in a9822 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10028,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[786],((C_word*)t0)[2],t1));}

/* k10005 in walk1 in a9822 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10011,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1999 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9826(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10009 in k10005 in walk1 in a9822 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_10011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10011,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[786],((C_word*)t0)[2],t1));}

/* k9994 in walk1 in a9822 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9996,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[782],((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9988,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1998 walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_9826(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9986 in k9994 in walk1 in a9822 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9988,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[786],((C_word*)t0)[2],t1));}

/* k9975 in walk1 in a9822 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9977,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[122],((C_word*)t0)[2],t1));}

/* k9941 in walk1 in a9822 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9943,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[786],((C_word*)t0)[2],t1));}

/* k9922 in walk1 in a9822 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9924,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[782],((C_word*)t0)[2],t1));}

/* k9895 in walk1 in a9822 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9897,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[782],lf[783],t1));}

/* k9852 in walk1 in a9822 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1966 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9826(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9848 in walk1 in a9822 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9850,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[780],t1));}

/* walk in a9822 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_9826(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9826,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9834,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1961 walk1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_9836(t5,t4,t2,t3);}

/* k9832 in walk in a9822 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1961 simplify */
t2=((C_word*)((C_word*)t0)[3])[1];
f_10033(t2,((C_word*)t0)[2],t1);}

/* k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8857,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9813,a[2]=lf[777],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2019 ##sys#register-macro */
t4=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[778],t3);}

/* a9812 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9813(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9813,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,3,lf[126],C_SCHEME_END_OF_LIST,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[776],t3));}

/* k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8861,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2027 append */
t3=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[775],*((C_word*)lf[338]+1));}

/* k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8861,2,t0,t1);}
t2=C_mutate((C_word*)lf[338]+1,t1);
t3=C_set_block_item(lf[647],0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[648],0,C_SCHEME_FALSE);
t5=C_set_block_item(lf[649],0,C_SCHEME_FALSE);
t6=C_mutate((C_word*)lf[650]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8866,a[2]=lf[655],tmp=(C_word)a,a+=3,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8883,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9810,a[2]=lf[773],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2041 make-parameter */
t9=*((C_word*)lf[774]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* a9809 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9810,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[772]);}

/* k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8883,2,t0,t1);}
t2=C_mutate((C_word*)lf[656]+1,t1);
t3=*((C_word*)lf[656]+1);
t4=C_mutate((C_word*)lf[657]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8885,a[2]=t3,a[3]=lf[660],tmp=(C_word)a,a+=4,tmp));
t5=C_mutate((C_word*)lf[661]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8901,a[2]=lf[662],tmp=(C_word)a,a+=3,tmp));
t6=*((C_word*)lf[375]+1);
t7=*((C_word*)lf[398]+1);
t8=*((C_word*)lf[71]+1);
t9=*((C_word*)lf[663]+1);
t10=*((C_word*)lf[664]+1);
t11=*((C_word*)lf[382]+1);
t12=*((C_word*)lf[665]+1);
t13=C_mutate((C_word*)lf[666]+1,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8904,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t11,a[6]=t9,a[7]=t10,a[8]=lf[695],tmp=(C_word)a,a+=9,tmp));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9243,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2157 make-vector */
t15=*((C_word*)lf[576]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9243,2,t0,t1);}
t2=C_mutate((C_word*)lf[696]+1,t1);
t3=C_mutate((C_word*)lf[697]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9245,a[2]=lf[698],tmp=(C_word)a,a+=3,tmp));
t4=*((C_word*)lf[699]+1);
t5=*((C_word*)lf[700]+1);
t6=*((C_word*)lf[398]+1);
t7=C_mutate((C_word*)lf[699]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9254,a[2]=t4,a[3]=t5,a[4]=t6,a[5]=lf[705],tmp=(C_word)a,a+=6,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9329,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9668,a[2]=lf[771],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2186 ##sys#register-macro */
t10=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,lf[767],t9);}

/* a9667 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9668(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_9668r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_9668r(t0,t1,t2,t3);}}

static void C_ccall f_9668r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9671,a[2]=lf[766],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9776,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2197 ##sys#check-syntax */
t6=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[767],t3,lf[768]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9786,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2200 ##sys#check-syntax */
t6=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[767],t2,lf[770]);}}

/* k9784 in a9667 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9789,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2201 ##sys#check-syntax */
t3=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[767],((C_word*)t0)[4],lf[769]);}

/* k9787 in k9784 in a9667 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9789,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[4]);
t5=(C_word)C_a_i_cons(&a,2,lf[126],t4);
/* eval.scm: 2202 expand */
f_9671(((C_word*)t0)[2],t2,t5);}

/* k9774 in a9667 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* eval.scm: 2198 expand */
f_9671(((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* expand in a9667 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_9671(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9671,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9675,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
t6=(C_word)C_eqp(lf[126],t5);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_i_cadr(t3);
t9=t4;
f_9675(t9,(C_word)C_i_symbolp(t8));}
else{
t8=t4;
f_9675(t8,C_SCHEME_FALSE);}}
else{
t7=t4;
f_9675(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_9675(t5,C_SCHEME_FALSE);}}

/* k9673 in expand in a9667 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_9675(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[64],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9675,NULL,2,t0,t1);}
t2=(C_truep(*((C_word*)lf[99]+1))?lf[329]:lf[328]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9686,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t4=(C_word)C_a_i_list(&a,2,lf[124],((C_word*)t0)[3]);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_i_cddr(((C_word*)t0)[2]);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[126],t8);
t10=t3;
f_9686(t10,(C_word)C_a_i_list(&a,3,lf[39],t4,t9));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t4=(C_word)C_a_i_list(&a,2,lf[124],((C_word*)t0)[2]);
t5=(C_word)C_a_i_list(&a,2,lf[124],((C_word*)t0)[3]);
t6=t3;
f_9686(t6,(C_word)C_a_i_list(&a,3,lf[46],t4,t5));}
else{
t4=(C_word)C_a_i_list(&a,2,lf[124],((C_word*)t0)[3]);
t5=t3;
f_9686(t5,(C_word)C_a_i_list(&a,3,lf[43],t4,((C_word*)t0)[2]));}}}

/* k9684 in k9673 in expand in a9667 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_9686(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9686,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9332,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9649,a[2]=lf[765],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2204 ##sys#register-macro */
t4=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[539],t3);}

/* a9648 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9649(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_9649r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_9649r(t0,t1,t2);}}

static void C_ccall f_9649r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9653,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2207 ##sys#check-syntax */
t4=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[539],t2,lf[764]);}

/* k9651 in a9648 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9660,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9662,a[2]=lf[763],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a9661 in k9651 in a9648 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9662(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9662,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[124],t2));}

/* k9658 in k9651 in a9648 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9660,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[322],t1));}

/* k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9335,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9643,a[2]=lf[762],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2213 ##sys#register-macro-2 */
t4=*((C_word*)lf[39]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[760],t3);}

/* a9642 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9643(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9643,3,t0,t1,t2);}
/* eval.scm: 2216 ##sys#syntax-error-hook */
t3=*((C_word*)lf[73]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[760],lf[761]);}

/* k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9338,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9637,a[2]=lf[759],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2218 ##sys#register-macro-2 */
t4=*((C_word*)lf[39]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[757],t3);}

/* a9636 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9637(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9637,3,t0,t1,t2);}
/* eval.scm: 2221 ##sys#syntax-error-hook */
t3=*((C_word*)lf[73]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[757],lf[758]);}

/* k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[42],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9338,2,t0,t1);}
t2=lf[706]=C_SCHEME_FALSE;;
t3=C_mutate(&lf[707],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9341,a[2]=lf[716],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[717],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9400,a[2]=lf[719],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[720],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9409,a[2]=lf[723],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[724],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9421,a[2]=lf[726],tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[727],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9437,a[2]=lf[730],tmp=(C_word)a,a+=3,tmp));
t8=C_mutate(&lf[731],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9463,a[2]=lf[733],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[734],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9476,a[2]=lf[736],tmp=(C_word)a,a+=3,tmp));
t10=C_mutate(&lf[737],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9502,a[2]=lf[739],tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[740],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9539,a[2]=lf[742],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate(&lf[743],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9555,a[2]=lf[745],tmp=(C_word)a,a+=3,tmp));
t13=C_mutate(&lf[746],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9581,a[2]=lf[748],tmp=(C_word)a,a+=3,tmp));
t14=C_mutate(&lf[749],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9603,a[2]=lf[751],tmp=(C_word)a,a+=3,tmp));
t15=C_mutate(&lf[752],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9618,a[2]=lf[754],tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[194]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9628,a[2]=lf[756],tmp=(C_word)a,a+=3,tmp));
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}

/* ##sys#make-lambda-info in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9628(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9628,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9635,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2328 ##sys#make-string */
t5=*((C_word*)lf[755]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k9633 in ##sys#make-lambda-info in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_copy_memory(t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_string_to_lambdainfo(t1);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* CHICKEN_get_error_message in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9618,4,t0,t1,t2,t3);}
t4=lf[706];
t5=(C_truep(t4)?t4:lf[753]);
/* eval.scm: 2321 store-string */
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_9463(t5,t3,t2));}

/* CHICKEN_load in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9603(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9603,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9607,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_fix(0));}

/* k9605 in CHICKEN_load in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9612,a[2]=t1,a[3]=lf[750],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2318 run-safe */
f_9341(((C_word*)t0)[2],t2);}

/* a9611 in k9605 in CHICKEN_load in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9616,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2318 load */
t3=*((C_word*)lf[419]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k9614 in a9611 in k9605 in CHICKEN_load in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* CHICKEN_read in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9581(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9581,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9585,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_fix(0));}

/* k9583 in CHICKEN_read in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9585,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9590,a[2]=t1,a[3]=t2,a[4]=lf[747],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2312 run-safe */
f_9341(((C_word*)t0)[2],t3);}

/* a9589 in k9583 in CHICKEN_read in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9594,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2314 open-input-string */
t3=*((C_word*)lf[728]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9592 in a9589 in k9583 in CHICKEN_read in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9594,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2315 read */
t3=*((C_word*)lf[398]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k9599 in k9592 in a9589 in k9583 in CHICKEN_read in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2315 store-result */
f_9400(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_apply_to_string in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9555(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9555,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9561,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,a[6]=lf[744],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 2305 run-safe */
f_9341(t1,t6);}

/* a9560 in CHICKEN_apply_to_string in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9565,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 2307 open-output-string */
t3=*((C_word*)lf[197]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9563 in a9560 in CHICKEN_apply_to_string in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9568,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9579,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9577 in k9563 in a9560 in CHICKEN_apply_to_string in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2308 write */
t2=*((C_word*)lf[196]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9566 in k9563 in a9560 in CHICKEN_apply_to_string in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9575,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2309 get-output-string */
t3=*((C_word*)lf[195]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9573 in k9566 in k9563 in a9560 in CHICKEN_apply_to_string in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2309 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9463(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* CHICKEN_apply in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9539,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9545,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=lf[741],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2300 run-safe */
f_9341(t1,t5);}

/* a9544 in CHICKEN_apply in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9553,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9551 in a9544 in CHICKEN_apply in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2300 store-result */
f_9400(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_eval_string_to_string in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9502(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9502,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9506,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,C_fix(0));}

/* k9504 in CHICKEN_eval_string_to_string in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9506,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9511,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=lf[738],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2291 run-safe */
f_9341(((C_word*)t0)[2],t4);}

/* a9510 in k9504 in CHICKEN_eval_string_to_string in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2293 open-output-string */
t3=*((C_word*)lf[197]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9513 in a9510 in k9504 in CHICKEN_eval_string_to_string in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9518,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9529,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9533,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9537,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2294 open-input-string */
t6=*((C_word*)lf[728]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k9535 in k9513 in a9510 in k9504 in CHICKEN_eval_string_to_string in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2294 read */
t2=*((C_word*)lf[398]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9531 in k9513 in a9510 in k9504 in CHICKEN_eval_string_to_string in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2294 eval */
t2=*((C_word*)lf[375]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9527 in k9513 in a9510 in k9504 in CHICKEN_eval_string_to_string in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2294 write */
t2=*((C_word*)lf[196]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9516 in k9513 in a9510 in k9504 in CHICKEN_eval_string_to_string in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9525,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2295 get-output-string */
t3=*((C_word*)lf[195]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9523 in k9516 in k9513 in a9510 in k9504 in CHICKEN_eval_string_to_string in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2295 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9463(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* CHICKEN_eval_to_string in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9476(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9476,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9482,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=lf[735],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2282 run-safe */
f_9341(t1,t5);}

/* a9481 in CHICKEN_eval_to_string in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9482,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2284 open-output-string */
t3=*((C_word*)lf[197]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9484 in a9481 in CHICKEN_eval_to_string in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9489,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9500,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2285 eval */
t4=*((C_word*)lf[375]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9498 in k9484 in a9481 in CHICKEN_eval_to_string in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2285 write */
t2=*((C_word*)lf[196]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9487 in k9484 in a9481 in CHICKEN_eval_to_string in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9496,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2286 get-output-string */
t3=*((C_word*)lf[195]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9494 in k9487 in k9484 in a9481 in CHICKEN_eval_to_string in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2286 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9463(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* store-string in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static C_word C_fcall f_9463(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_stack_check;
t4=(C_word)C_block_size(t1);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t2))){
t5=C_mutate(&lf[706],lf[732]);
return(C_SCHEME_FALSE);}
else{
return((C_word)C_copy_result_string(t1,t3,t4));}}

/* CHICKEN_eval_string in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9437(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9437,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9441,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_fix(0));}

/* k9439 in CHICKEN_eval_string in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9441,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9446,a[2]=t1,a[3]=t2,a[4]=lf[729],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2263 run-safe */
f_9341(((C_word*)t0)[2],t3);}

/* a9445 in k9439 in CHICKEN_eval_string in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9450,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2265 open-input-string */
t3=*((C_word*)lf[728]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9448 in a9445 in k9439 in CHICKEN_eval_string in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9457,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9461,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2266 read */
t4=*((C_word*)lf[398]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k9459 in k9448 in a9445 in k9439 in CHICKEN_eval_string in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2266 eval */
t2=*((C_word*)lf[375]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9455 in k9448 in a9445 in k9439 in CHICKEN_eval_string in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2266 store-result */
f_9400(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_eval in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9421(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9421,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9427,a[2]=t2,a[3]=t3,a[4]=lf[725],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2258 run-safe */
f_9341(t1,t4);}

/* a9426 in CHICKEN_eval in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9435,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2260 eval */
t3=*((C_word*)lf[375]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9433 in a9426 in CHICKEN_eval in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2260 store-result */
f_9400(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_yield in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9415,a[2]=lf[722],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2255 run-safe */
f_9341(t1,t2);}

/* a9414 in CHICKEN_yield in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9415,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9419,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2255 thread-yield! */
t3=*((C_word*)lf[721]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k9417 in a9414 in CHICKEN_yield in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* store-result in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_9400(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9400,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9404,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2249 ##sys#gc */
t5=*((C_word*)lf[718]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,C_SCHEME_FALSE);}

/* k9402 in store-result in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_store_result(((C_word*)t0)[3],((C_word*)t0)[4]):C_SCHEME_UNDEFINED);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* run-safe in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_9341(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9341,NULL,2,t1,t2);}
t3=lf[706]=C_SCHEME_FALSE;;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9349,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9351,a[2]=t2,a[3]=lf[715],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2237 call-with-current-continuation */
t6=*((C_word*)lf[71]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a9350 in run-safe in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9351(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9351,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9357,a[2]=t2,a[3]=lf[710],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9376,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=lf[714],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2237 with-exception-handler */
t5=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a9375 in a9350 in run-safe in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9382,a[2]=((C_word*)t0)[3],a[3]=lf[711],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9388,a[2]=((C_word*)t0)[2],a[3]=lf[713],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2237 ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a9387 in a9375 in a9350 in run-safe in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9388(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_9388r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_9388r(t0,t1,t2);}}

static void C_ccall f_9388r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9394,a[2]=t2,a[3]=lf[712],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2237 g1430 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a9393 in a9387 in a9375 in a9350 in run-safe in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9394,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a9381 in a9375 in a9350 in run-safe in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9382,2,t0,t1);}
/* eval.scm: 2242 thunk */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* a9356 in a9350 in run-safe in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9357(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9357,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9363,a[2]=t2,a[3]=lf[709],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2237 g1430 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a9362 in a9356 in a9350 in run-safe in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9367,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2238 open-output-string */
t3=*((C_word*)lf[197]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9365 in a9362 in a9356 in a9350 in run-safe in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9370,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2239 print-error-message */
t3=*((C_word*)lf[708]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k9368 in k9365 in a9362 in a9356 in a9350 in run-safe in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9374,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2240 get-output-string */
t3=*((C_word*)lf[195]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9372 in k9368 in k9365 in a9362 in a9356 in a9350 in run-safe in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[706],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* k9347 in run-safe in k9336 in k9333 in k9330 in k9327 in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9254(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9254,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_make_character(44));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9264,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2169 read-char */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}
else{
/* eval.scm: 2181 old */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k9262 in ##sys#user-read-hook in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9267,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2170 read */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}

/* k9265 in k9262 in ##sys#user-read-hook in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9268,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=lf[703],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_nullp(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9281,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_9281(t5,t3);}
else{
t5=(C_word)C_i_listp(t1);
t6=t4;
f_9281(t6,(C_word)C_i_not(t5));}}

/* k9279 in k9265 in k9262 in ##sys#user-read-hook in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_9281(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9281,NULL,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 2173 err */
t2=((C_word*)t0)[5];
f_9268(t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9299,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2177 ##sys#hash-table-ref */
t4=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[696]+1),t2);}
else{
/* eval.scm: 2176 err */
t3=((C_word*)t0)[5];
f_9268(t3,((C_word*)t0)[4]);}}}

/* k9297 in k9279 in k9265 in k9262 in ##sys#user-read-hook in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_apply(4,0,((C_word*)t0)[4],t1,t2);}
else{
/* eval.scm: 2180 ##sys#read-error */
t2=*((C_word*)lf[701]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[704],((C_word*)t0)[2]);}}

/* err in k9265 in k9262 in ##sys#user-read-hook in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_9268(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9268,NULL,2,t0,t1);}
/* eval.scm: 2171 ##sys#read-error */
t2=*((C_word*)lf[701]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],lf[702],((C_word*)t0)[2]);}

/* define-reader-ctor in k9241 in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9245(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9245,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[697]);
/* eval.scm: 2161 ##sys#hash-table-set! */
t5=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[696]+1),t2,t3);}

/* repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8907,a[2]=lf[669],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[670]+1);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=*((C_word*)lf[659]+1);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=*((C_word*)lf[667]+1);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8948,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t8,a[11]=t6,a[12]=t4,tmp=(C_word)a,a+=13,tmp);
/* eval.scm: 2071 ##sys#error-handler */
t10=*((C_word*)lf[675]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}

/* k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8951,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 2072 ##sys#reset-handler */
t3=*((C_word*)lf[690]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[37],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8951,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=*((C_word*)lf[201]+1);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8953,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8959,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8968,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t6,a[7]=t3,a[8]=lf[676],tmp=(C_word)a,a+=9,tmp);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9033,a[2]=((C_word*)t0)[4],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,a[7]=lf[693],tmp=(C_word)a,a+=8,tmp);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9228,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t4,a[7]=lf[694],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 2086 ##sys#dynamic-wind */
t10=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,((C_word*)t0)[2],t7,t8,t9);}

/* a9227 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9232,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2149 load-verbose */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k9230 in a9227 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9232,2,t0,t1);}
t2=C_mutate((C_word*)lf[201]+1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9236,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2151 ##sys#error-handler */
t4=*((C_word*)lf[675]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9234 in k9230 in a9227 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2152 ##sys#reset-handler */
t2=*((C_word*)lf[690]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a9032 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9033,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9039,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=lf[692],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_9039(t5,t1);}

/* loop in a9032 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_9039(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9039,NULL,2,t0,t1);}
t2=f_8953(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9046,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9211,a[2]=((C_word*)t0)[3],a[3]=lf[691],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2109 call-with-current-continuation */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a9210 in loop in a9032 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9211(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9211,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9217,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=lf[689],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2111 ##sys#reset-handler */
t4=*((C_word*)lf[690]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a9216 in a9210 in loop in a9032 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9217,2,t0,t1);}
t2=C_set_block_item(lf[406],0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[688],0,C_SCHEME_TRUE);
t4=f_8959(((C_word*)t0)[3]);
/* eval.scm: 2116 c */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t1,C_SCHEME_FALSE);}

/* k9044 in loop in a9032 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2117 ##sys#read-prompt-hook */
t3=*((C_word*)lf[657]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9047 in k9044 in loop in a9032 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9052,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[649]+1);
t4=(C_truep(t3)?t3:((C_word*)t0)[2]);
t5=t4;
((C_proc2)C_retrieve_proc(t5))(2,t5,t2);}

/* k9050 in k9047 in k9044 in loop in a9032 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9052,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9061,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9206,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2120 ##sys#peek-char-0 */
t4=*((C_word*)lf[687]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[670]+1));}}

/* k9204 in k9050 in k9047 in k9044 in loop in a9032 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(10),t1);
if(C_truep(t2)){
/* eval.scm: 2121 ##sys#read-char-0 */
t3=*((C_word*)lf[686]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],*((C_word*)lf[670]+1));}
else{
t3=((C_word*)t0)[2];
f_9061(2,t3,C_SCHEME_UNDEFINED);}}

/* k9059 in k9050 in k9047 in k9044 in loop in a9032 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9064,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2122 ##sys#clear-trace-buffer */
t3=*((C_word*)lf[661]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9062 in k9059 in k9050 in k9047 in k9044 in loop in a9032 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9064,2,t0,t1);}
t2=C_set_block_item(lf[201],0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9070,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=lf[677],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9079,a[2]=((C_word*)t0)[3],a[3]=lf[685],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2124 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a9078 in k9062 in k9059 in k9050 in k9047 in k9044 in loop in a9032 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9079(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr2r,(void*)f_9079r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_9079r(t0,t1,t2);}}

static void C_ccall f_9079r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(11);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9083,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(*((C_word*)lf[679]+1))?(C_word)C_i_pairp(*((C_word*)lf[201]+1)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9097,a[2]=t6,a[3]=lf[684],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_9097(t8,t3,*((C_word*)lf[201]+1),C_SCHEME_END_OF_LIST);}
else{
t5=t3;
f_9083(2,t5,C_SCHEME_UNDEFINED);}}

/* loop in a9078 in k9062 in k9059 in k9050 in k9047 in k9044 in loop in a9032 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_9097(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9097,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9101,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_pairp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9113,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2129 ##sys#print */
t6=*((C_word*)lf[652]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[683],C_SCHEME_FALSE,*((C_word*)lf[667]+1));}
else{
t5=t4;
f_9101(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9193,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2142 caar */
t6=*((C_word*)lf[119]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}}

/* k9191 in loop in a9078 in k9062 in k9059 in k9050 in k9047 in k9044 in loop in a9032 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9193,2,t0,t1);}
t2=(C_word)C_i_memq(t1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9160,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9160(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9189,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2143 caar */
t5=*((C_word*)lf[119]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}}

/* k9187 in k9191 in loop in a9078 in k9062 in k9059 in k9050 in k9047 in k9044 in loop in a9032 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2143 ##sys#symbol-has-toplevel-binding? */
t2=*((C_word*)lf[227]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9158 in k9191 in loop in a9078 in k9062 in k9059 in k9050 in k9047 in k9044 in loop in a9032 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9160,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* eval.scm: 2144 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9097(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* eval.scm: 2145 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_9097(t5,((C_word*)t0)[3],t2,t4);}}

/* k9111 in loop in a9078 in k9062 in k9059 in k9050 in k9047 in k9044 in loop in a9032 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9118,a[2]=lf[682],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[183]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a9117 in k9111 in loop in a9078 in k9062 in k9059 in k9050 in k9047 in k9044 in loop in a9032 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9118(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9118,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9122,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2134 ##sys#print */
t4=*((C_word*)lf[652]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[681],C_SCHEME_FALSE,*((C_word*)lf[667]+1));}

/* k9120 in a9117 in k9111 in loop in a9078 in k9062 in k9059 in k9050 in k9047 in k9044 in loop in a9032 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9125,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* eval.scm: 2135 ##sys#print */
t4=*((C_word*)lf[652]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_TRUE,*((C_word*)lf[667]+1));}

/* k9123 in k9120 in a9117 in k9111 in loop in a9078 in k9062 in k9059 in k9050 in k9047 in k9044 in loop in a9032 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9128,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_cdr(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9137,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2137 ##sys#print */
t4=*((C_word*)lf[652]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[680],C_SCHEME_FALSE,*((C_word*)lf[667]+1));}
else{
t3=t2;
f_9128(2,t3,C_SCHEME_UNDEFINED);}}

/* k9135 in k9123 in k9120 in a9117 in k9111 in loop in a9078 in k9062 in k9059 in k9050 in k9047 in k9044 in loop in a9032 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9137,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9140,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* eval.scm: 2138 ##sys#print */
t4=*((C_word*)lf[652]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_TRUE,*((C_word*)lf[667]+1));}

/* k9138 in k9135 in k9123 in k9120 in a9117 in k9111 in loop in a9078 in k9062 in k9059 in k9050 in k9047 in k9044 in loop in a9032 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2139 ##sys#write-char-0 */
t2=*((C_word*)lf[651]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(41),*((C_word*)lf[667]+1));}

/* k9126 in k9123 in k9120 in a9117 in k9111 in loop in a9078 in k9062 in k9059 in k9050 in k9047 in k9044 in loop in a9032 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2140 ##sys#write-char-0 */
t2=*((C_word*)lf[651]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[667]+1));}

/* k9099 in loop in a9078 in k9062 in k9059 in k9050 in k9047 in k9044 in loop in a9032 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(9));}

/* k9081 in a9078 in k9062 in k9059 in k9050 in k9047 in k9044 in loop in a9032 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9083,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9086,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_i_nullp(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8929,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_8929(t6,t4);}
else{
t6=(C_word)C_i_car(t3);
t7=t5;
f_8929(t7,(C_word)C_eqp(C_SCHEME_UNDEFINED,t6));}}

/* k8927 in k9081 in a9078 in k9062 in k9059 in k9050 in k9047 in k9044 in loop in a9032 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_8929(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8929,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_9086(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8934,a[2]=lf[678],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[183]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}}

/* a8933 in k8927 in k9081 in a9078 in k9062 in k9059 in k9050 in k9047 in k9044 in loop in a9032 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8934(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8934,3,t0,t1,t2);}
/* ##sys#repl-print-hook */
t3=*((C_word*)lf[650]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,*((C_word*)lf[659]+1));}

/* k9084 in k9081 in a9078 in k9062 in k9059 in k9050 in k9047 in k9044 in loop in a9032 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2147 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_9039(t2,((C_word*)t0)[2]);}

/* a9069 in k9062 in k9059 in k9050 in k9047 in k9044 in loop in a9032 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9070,2,t0,t1);}
t2=*((C_word*)lf[647]+1);
t3=(C_truep(t2)?t2:((C_word*)t0)[3]);
t4=t3;
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,((C_word*)t0)[2]);}

/* a8967 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8973,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 2088 load-verbose */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8971 in a8967 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8973,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8976,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 2089 load-verbose */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}

/* k8974 in k8971 in a8967 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8981,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=lf[674],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 2090 ##sys#error-handler */
t3=*((C_word*)lf[675]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* a8980 in k8974 in k8971 in a8967 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8981(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_8981r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8981r(t0,t1,t2,t3);}}

static void C_ccall f_8981r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=f_8959(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8988,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 2093 ##sys#print */
t6=*((C_word*)lf[652]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[673],C_SCHEME_FALSE,*((C_word*)lf[667]+1));}

/* k8986 in a8980 in k8974 in k8971 in a8967 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8991,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9028,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2095 ##sys#print */
t4=*((C_word*)lf[652]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[672],C_SCHEME_FALSE,*((C_word*)lf[667]+1));}
else{
t3=t2;
f_8991(2,t3,C_SCHEME_UNDEFINED);}}

/* k9026 in k8986 in a8980 in k8974 in k8971 in a8967 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2096 ##sys#print */
t2=*((C_word*)lf[652]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,*((C_word*)lf[667]+1));}

/* k8989 in k8986 in a8980 in k8974 in k8971 in a8967 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8994,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9003,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
t5=t3;
f_9003(t5,(C_word)C_i_nullp(t4));}
else{
t4=t3;
f_9003(t4,C_SCHEME_FALSE);}}

/* k9001 in k8989 in k8986 in a8980 in k8974 in k8971 in a8967 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_9003(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9003,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9006,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2099 ##sys#print */
t3=*((C_word*)lf[652]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[671],C_SCHEME_FALSE,*((C_word*)lf[667]+1));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2102 ##sys#write-char-0 */
t3=*((C_word*)lf[651]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),*((C_word*)lf[667]+1));}}

/* k9010 in k9001 in k8989 in k8986 in a8980 in k8974 in k8971 in a8967 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2103 write-err */
f_8907(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9004 in k9001 in k8989 in k8986 in a8980 in k8974 in k8971 in a8967 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_9006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2100 write-err */
f_8907(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8992 in k8989 in k8986 in a8980 in k8974 in k8971 in a8967 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8997,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2104 print-call-chain */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,*((C_word*)lf[667]+1));}

/* k8995 in k8992 in k8989 in k8986 in a8980 in k8974 in k8971 in a8967 in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2105 flush-output */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],*((C_word*)lf[667]+1));}

/* resetports in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static C_word C_fcall f_8959(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t1=C_mutate((C_word*)lf[670]+1,((C_word*)((C_word*)t0)[4])[1]);
t2=C_mutate((C_word*)lf[659]+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate((C_word*)lf[667]+1,((C_word*)((C_word*)t0)[2])[1]);
return(t3);}

/* saveports in k8949 in k8946 in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static C_word C_fcall f_8953(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t1=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[670]+1));
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[659]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[667]+1));
return(t3);}

/* write-err in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_8907(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8907,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8913,a[2]=lf[668],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[183]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a8912 in write-err in repl in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8913(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8913,3,t0,t1,t2);}
/* ##sys#repl-print-hook */
t3=*((C_word*)lf[650]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,*((C_word*)lf[667]+1));}

/* ##sys#clear-trace-buffer in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8901,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1314(C_SCHEME_UNDEFINED));}

/* ##sys#read-prompt-hook in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8889,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8896,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8899,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2046 repl-prompt */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k8897 in ##sys#read-prompt-hook in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k8894 in ##sys#read-prompt-hook in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2046 ##sys#print */
t2=*((C_word*)lf[652]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,*((C_word*)lf[659]+1));}

/* k8887 in ##sys#read-prompt-hook in k8881 in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2047 ##sys#flush-output */
t2=*((C_word*)lf[658]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[659]+1));}

/* ##sys#repl-print-hook in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8866(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8866,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8870,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8875,a[2]=t3,a[3]=t2,a[4]=lf[653],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2038 ##sys#with-print-length-limit */
t6=*((C_word*)lf[654]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[648]+1),t5);}

/* a8874 in ##sys#repl-print-hook in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8875,2,t0,t1);}
/* ##sys#print */
t2=*((C_word*)lf[652]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* k8868 in ##sys#repl-print-hook in k8859 in k8855 in k8852 in k8849 in k8846 in k8843 in k8840 in k8837 in k8834 in k8831 in k8828 in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2039 ##sys#write-char-0 */
t2=*((C_word*)lf[651]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* ##sys#check-syntax in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8438(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+28)){
C_save_and_reclaim((void*)tr5rv,(void*)f_8438r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_8438r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_8438r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(28);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8453,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=lf[611],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8441,a[2]=t6,a[3]=lf[612],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8484,a[2]=((C_word*)t0)[2],a[3]=lf[614],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8546,a[2]=lf[616],tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8575,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=t8,a[6]=t9,a[7]=t7,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_notvemptyp(t5))){
t11=(C_word)C_i_vector_ref(t5,C_fix(0));
t12=C_mutate((C_word*)lf[377]+1,t11);
t13=t10;
f_8575(t13,t12);}
else{
t11=t10;
f_8575(t11,C_SCHEME_UNDEFINED);}}

/* k8573 in ##sys#check-syntax in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_8575(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8575,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8580,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t3,a[6]=((C_word*)t0)[8],a[7]=lf[645],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_8580(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in k8573 in ##sys#check-syntax in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_8580(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word *a;
loop:
a=C_alloc(21);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8580,NULL,4,t0,t1,t2,t3);}
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_vectorp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_block_size(t3);
t7=(C_word)C_fixnum_greaterp(t6,C_fix(1));
t8=(C_truep(t7)?(C_word)C_slot(t3,C_fix(1)):C_fix(0));
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8596,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t8,tmp=(C_word)a,a+=8,tmp);
t10=(C_word)C_eqp(t6,C_fix(1));
if(C_truep(t10)){
t11=t9;
f_8596(t11,C_fix(1));}
else{
t11=(C_word)C_fixnum_greaterp(t6,C_fix(2));
t12=t9;
f_8596(t12,(C_truep(t11)?(C_word)C_slot(t3,C_fix(2)):C_fix(99999)));}}
else{
if(C_truep((C_word)C_blockp(t3))){
if(C_truep((C_word)C_symbolp(t3))){
t5=t3;
t6=(C_word)C_eqp(t5,lf[621]);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_TRUE);}
else{
t7=(C_word)C_eqp(t5,lf[622]);
if(C_truep(t7)){
/* eval.scm: 1798 test */
t8=((C_word*)t0)[4];
f_8441(t8,t1,t2,*((C_word*)lf[623]+1),lf[624]);}
else{
t8=(C_word)C_eqp(t5,lf[625]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8725,a[2]=lf[626],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1799 test */
t10=((C_word*)t0)[4];
f_8441(t10,t1,t2,t9,lf[627]);}
else{
t9=(C_word)C_eqp(t5,lf[628]);
if(C_truep(t9)){
/* eval.scm: 1800 test */
t10=((C_word*)t0)[4];
f_8441(t10,t1,t2,*((C_word*)lf[629]+1),lf[630]);}
else{
t10=(C_word)C_eqp(t5,lf[631]);
if(C_truep(t10)){
/* eval.scm: 1801 test */
t11=((C_word*)t0)[4];
f_8441(t11,t1,t2,((C_word*)t0)[3],lf[632]);}
else{
t11=(C_word)C_eqp(t5,lf[633]);
if(C_truep(t11)){
/* eval.scm: 1802 test */
t12=((C_word*)t0)[4];
f_8441(t12,t1,t2,*((C_word*)lf[634]+1),lf[635]);}
else{
t12=(C_word)C_eqp(t5,lf[636]);
if(C_truep(t12)){
/* eval.scm: 1803 test */
t13=((C_word*)t0)[4];
f_8441(t13,t1,t2,*((C_word*)lf[637]+1),lf[638]);}
else{
t13=(C_word)C_eqp(t5,lf[639]);
if(C_truep(t13)){
/* eval.scm: 1804 test */
t14=((C_word*)t0)[4];
f_8441(t14,t1,t2,((C_word*)t0)[2],lf[640]);}
else{
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8779,a[2]=t3,a[3]=lf[641],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1805 test */
t15=((C_word*)t0)[4];
f_8441(t15,t1,t2,t14,lf[642]);}}}}}}}}}
else{
t5=(C_word)C_i_not((C_word)C_blockp(t2));
t6=(C_truep(t5)?t5:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t6)){
/* eval.scm: 1807 err */
t7=((C_word*)t0)[6];
f_8453(t7,t1,lf[643]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8798,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_slot(t2,C_fix(0));
t9=(C_word)C_slot(t3,C_fix(0));
/* eval.scm: 1809 walk */
t30=t7;
t31=t8;
t32=t9;
t1=t30;
t2=t31;
t3=t32;
goto loop;}}}
else{
t5=(C_word)C_eqp(t3,t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 1794 err */
t6=((C_word*)t0)[6];
f_8453(t6,t1,lf[644]);}}}}

/* k8796 in walk in k8573 in ##sys#check-syntax in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1810 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8580(t4,((C_word*)t0)[2],t2,t3);}

/* a8778 in walk in k8573 in ##sys#check-syntax in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8779(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8779,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(t2,((C_word*)t0)[2]));}

/* a8724 in walk in k8573 in ##sys#check-syntax in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8725(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8725,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_symbolp(t2));}

/* k8594 in walk in k8573 in ##sys#check-syntax in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_8596(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8596,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8601,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=lf[620],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_8601(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* do1189 in k8594 in walk in k8573 in ##sys#check-syntax in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_8601(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8601,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[7]))){
/* eval.scm: 1787 err */
t5=((C_word*)t0)[6];
f_8453(t5,t1,lf[617]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8620,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
/* eval.scm: 1789 err */
t6=((C_word*)t0)[6];
f_8453(t6,t5,lf[618]);}
else{
t6=(C_word)C_i_not((C_word)C_blockp(t2));
t7=(C_truep(t6)?t6:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t7)){
/* eval.scm: 1791 err */
t8=((C_word*)t0)[6];
f_8453(t8,t5,lf[619]);}
else{
t8=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1792 walk */
t9=((C_word*)((C_word*)t0)[3])[1];
f_8580(t9,t5,t8,((C_word*)t0)[2]);}}}}

/* k8618 in do1189 in k8594 in walk in k8573 in ##sys#check-syntax in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_8601(t4,((C_word*)t0)[2],t2,t3);}

/* proper-list? in ##sys#check-syntax in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8546(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8546,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8552,a[2]=lf[615],tmp=(C_word)a,a+=3,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_8552(t2));}

/* loop in proper-list? in ##sys#check-syntax in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static C_word C_fcall f_8552(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_pairp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(C_word)C_slot(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* lambda-list? in ##sys#check-syntax in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8484(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8484,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8488,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1754 ##sys#extended-lambda-list? */
t4=*((C_word*)lf[107]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k8486 in lambda-list? in ##sys#check-syntax in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8488,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8496,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=lf[613],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_8496(t5,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* loop in k8486 in lambda-list? in ##sys#check-syntax in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_8496(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8496,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_symbolp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8519,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1758 keyword? */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
if(C_truep((C_word)C_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_not((C_word)C_blockp(t4));
t6=(C_truep(t5)?t5:(C_word)C_i_not((C_word)C_symbolp(t4)));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1763 loop */
t10=t1;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* k8517 in loop in k8486 in lambda-list? in ##sys#check-syntax in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* test in ##sys#check-syntax in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_8441(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8441,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8448,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1742 pred */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k8446 in test in ##sys#check-syntax in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 1742 err */
t2=((C_word*)t0)[3];
f_8453(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in ##sys#check-syntax in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_8453(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8453,NULL,3,t0,t1,t2);}
t3=*((C_word*)lf[377]+1);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8457,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1746 get-line-number */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k8455 in err in ##sys#check-syntax in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8464,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8471,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1749 symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8482,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1750 symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}

/* k8480 in k8455 in err in ##sys#check-syntax in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1750 string-append */
t2=((C_word*)t0)[4];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[609],t1,lf[610],((C_word*)t0)[2]);}

/* k8469 in k8455 in err in ##sys#check-syntax in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8475,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1749 number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}

/* k8473 in k8469 in k8455 in err in ##sys#check-syntax in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1749 string-append */
t2=((C_word*)t0)[5];
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[4],lf[606],((C_word*)t0)[3],lf[607],t1,lf[608],((C_word*)t0)[2]);}

/* k8462 in k8455 in err in ##sys#check-syntax in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1747 ##sys#syntax-error-hook */
t2=*((C_word*)lf[73]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* get-line-number in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8402(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8402,3,t0,t1,t2);}
if(C_truep(*((C_word*)lf[598]+1))){
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8424,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1728 ##sys#hash-table-ref */
t5=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[598]+1),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k8422 in get-line-number in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#syntax-error-hook in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8394(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_8394r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8394r(t0,t1,t2);}}

static void C_ccall f_8394r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[394]+1),lf[599],t2);}

/* ##sys#display-times in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8340(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8340,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8344,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1703 display-rj */
t5=((C_word*)t0)[2];
f_8319(t5,t3,t4,C_fix(8));}

/* k8342 in ##sys#display-times in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8347,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1704 display */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[596]);}

/* k8345 in k8342 in ##sys#display-times in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8350,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1705 display-rj */
t4=((C_word*)t0)[2];
f_8319(t4,t2,t3,C_fix(8));}

/* k8348 in k8345 in k8342 in ##sys#display-times in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8353,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1706 display */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[595]);}

/* k8351 in k8348 in k8345 in k8342 in ##sys#display-times in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8356,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
/* eval.scm: 1707 display-rj */
t4=((C_word*)t0)[2];
f_8319(t4,t2,t3,C_fix(8));}

/* k8354 in k8351 in k8348 in k8345 in k8342 in ##sys#display-times in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8359,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1708 display */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[594]);}

/* k8357 in k8354 in k8351 in k8348 in k8345 in k8342 in ##sys#display-times in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8362,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
/* eval.scm: 1709 display-rj */
t4=((C_word*)t0)[2];
f_8319(t4,t2,t3,C_fix(8));}

/* k8360 in k8357 in k8354 in k8351 in k8348 in k8345 in k8342 in ##sys#display-times in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8365,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1710 display */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[593]);}

/* k8363 in k8360 in k8357 in k8354 in k8351 in k8348 in k8345 in k8342 in ##sys#display-times in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8368,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
/* eval.scm: 1711 display-rj */
t4=((C_word*)t0)[2];
f_8319(t4,t2,t3,C_fix(8));}

/* k8366 in k8363 in k8360 in k8357 in k8354 in k8351 in k8348 in k8345 in k8342 in ##sys#display-times in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1712 display */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[592]);}

/* display-rj in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_8319(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8319,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8323,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_zerop(t2))){
t5=t4;
f_8323(2,t5,lf[590]);}
else{
/* eval.scm: 1698 number->string */
C_number_to_string(3,0,t4,t2);}}

/* k8321 in display-rj in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8323,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8326,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_fixnum_difference(((C_word*)t0)[3],t2);
/* eval.scm: 1700 spaces */
t5=((C_word*)t0)[2];
f_8295(t5,t3,t4);}

/* k8324 in k8321 in display-rj in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1701 display */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* spaces in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_8295(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8295,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8301,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=lf[588],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_8301(t6,t1,t2);}

/* do1119 in spaces in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_8301(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8301,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8311,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1695 display */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_make_character(32));}}

/* k8309 in do1119 in spaces in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8301(t3,((C_word*)t0)[2],t2);}

/* ##sys#resolve-include-filename in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8165(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_8165r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_8165r(t0,t1,t2,t3,t4);}}

static void C_ccall f_8165r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8169,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_8169(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_8169(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k8167 in ##sys#resolve-include-filename in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8169,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8171,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=lf[583],tmp=(C_word)a,a+=5,tmp));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8206,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=lf[584],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8223,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1676 test */
t7=t5;
f_8206(t7,t6,((C_word*)t0)[3]);}

/* k8221 in k8167 in ##sys#resolve-include-filename in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8223,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8233,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8274,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1678 ##sys#repository-path */
t4=*((C_word*)lf[488]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_8233(2,t3,*((C_word*)lf[495]+1));}}}

/* k8272 in k8221 in k8167 in ##sys#resolve-include-filename in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8274,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* eval.scm: 1678 ##sys#append */
t3=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],*((C_word*)lf[495]+1),t2);}

/* k8231 in k8221 in k8167 in ##sys#resolve-include-filename in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8233,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8235,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=lf[586],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_8235(t5,((C_word*)t0)[2],t1);}

/* loop in k8231 in k8221 in k8167 in ##sys#resolve-include-filename in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_8235(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8235,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8245,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8259,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1681 string-append */
t7=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,t6,lf[585],((C_word*)t0)[5]);}}

/* k8257 in loop in k8231 in k8221 in k8167 in ##sys#resolve-include-filename in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1681 test */
t2=((C_word*)t0)[3];
f_8206(t2,((C_word*)t0)[2],t1);}

/* k8243 in loop in k8231 in k8221 in k8167 in ##sys#resolve-include-filename in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1684 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_8235(t3,((C_word*)t0)[4],t2);}}

/* test in k8167 in ##sys#resolve-include-filename in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_8206(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8206,NULL,3,t0,t1,t2);}
t3=(C_truep(((C_word*)t0)[3])?(C_word)C_a_i_list(&a,2,lf[17],*((C_word*)lf[438]+1)):(C_word)C_a_i_list(&a,2,*((C_word*)lf[438]+1),lf[17]));
/* eval.scm: 1671 test2 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8171(t4,t1,t2,t3);}

/* test2 in k8167 in ##sys#resolve-include-filename in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_8171(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8171,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8184,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1665 exists? */
f_8146(t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8187,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(t3);
/* eval.scm: 1666 ##sys#string-append */
t6=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t2,t5);}}

/* k8185 in test2 in k8167 in ##sys#resolve-include-filename in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8193,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1667 exists? */
f_8146(t2,t1);}

/* k8191 in k8185 in test2 in k8167 in ##sys#resolve-include-filename in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* eval.scm: 1669 test2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8171(t3,((C_word*)t0)[6],((C_word*)t0)[2],t2);}}

/* k8182 in test2 in k8167 in ##sys#resolve-include-filename in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* exists? in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_8146(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8146,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8150,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1660 ##sys#file-info */
t4=*((C_word*)lf[437]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k8148 in exists? in k8138 in k8134 in k8131 in k8127 in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=(C_word)C_eqp(C_fix(1),t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_not(t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* initb in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_8113(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8113,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8115,a[2]=t2,a[3]=lf[580],tmp=(C_word)a,a+=4,tmp));}

/* f_8115 in initb in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8115(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8115,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8119,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1621 ##sys#hash-table-location */
t4=*((C_word*)lf[187]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k8117 */
static void C_ccall f_8119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t1,C_fix(1),t2));}

/* null-environment in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8075(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8075r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8075r(t0,t1,t2,t3);}}

static void C_ccall f_8075r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[577]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8082,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_lessp(t2,C_fix(4));
t7=(C_truep(t6)?t6:(C_word)C_fixnum_greaterp(t2,C_fix(5)));
if(C_truep(t7)){
/* eval.scm: 1612 ##sys#error */
t8=*((C_word*)lf[168]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t5,lf[577],lf[578],t2);}
else{
t8=t5;
f_8082(2,t8,C_SCHEME_UNDEFINED);}}

/* k8080 in null-environment in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8089,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1615 make-vector */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k8087 in k8080 in null-environment in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8089,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[3]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(0)):C_SCHEME_FALSE);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,3,lf[559],t1,t3));}

/* scheme-report-environment in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8031(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8031r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8031r(t0,t1,t2,t3);}}

static void C_ccall f_8031r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t4=(C_word)C_i_check_exact_2(t2,lf[573]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
t7=t2;
switch(t7){
case C_fix(4):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8051,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1603 ##sys#copy-env-table */
t9=*((C_word*)lf[561]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[557],C_SCHEME_TRUE,t6);
case C_fix(5):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8064,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1604 ##sys#copy-env-table */
t9=*((C_word*)lf[561]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[558],C_SCHEME_TRUE,t6);
default:
/* eval.scm: 1605 ##sys#error */
t8=*((C_word*)lf[168]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,lf[573],lf[574],t2);}}

/* k8062 in scheme-report-environment in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8064,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[559],t1,((C_word*)t0)[2]));}

/* k8049 in scheme-report-environment in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8051,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[559],t1,((C_word*)t0)[2]));}

/* interaction-environment in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8028,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[560]);}

/* ##sys#environment-symbols in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7909(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+20)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7909r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7909r(t0,t1,t2,t3);}}

static void C_ccall f_7909r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(20);
t4=(C_word)C_i_check_structure(t2,lf[559]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep(t7)){
t8=(C_word)C_i_vector_length(t7);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7930,a[2]=t6,a[3]=t7,a[4]=t10,a[5]=t8,a[6]=lf[567],tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_7930(t12,t1,C_fix(0),C_SCHEME_END_OF_LIST);}
else{
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8001,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8003,a[2]=t9,a[3]=t6,a[4]=lf[568],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1590 ##sys#walk-namespace */
t12=*((C_word*)lf[569]+1);
((C_proc3)C_retrieve_proc(t12))(3,t12,t10,t11);}}

/* a8002 in ##sys#environment-symbols in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8003(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8003,3,t0,t1,t2);}
t3=(C_word)C_i_not(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8013,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_8013(2,t5,t3);}
else{
/* eval.scm: 1592 pred */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k8011 in a8002 in ##sys#environment-symbols in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8013,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7999 in ##sys#environment-symbols in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_8001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* do1050 in ##sys#environment-symbols in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_7930(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7930,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7948,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_vector_ref(((C_word*)t0)[3],t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7954,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=lf[566],tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_7954(t10,t5,t6,t3);}}

/* loop in do1050 in ##sys#environment-symbols in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_7954(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7954,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_vector_ref(t4,C_fix(0));
t6=(C_word)C_i_not(((C_word*)t0)[3]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7973,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t5,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_7973(2,t8,t6);}
else{
/* eval.scm: 1584 pred */
t8=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t5);}}}

/* k7971 in loop in do1050 in ##sys#environment-symbols in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7973,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* eval.scm: 1585 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7954(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* eval.scm: 1586 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7954(t3,((C_word*)t0)[2],t2,((C_word*)t0)[4]);}}

/* k7946 in do1050 in ##sys#environment-symbols in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_7930(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#copy-env-table in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7801(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5rv,(void*)f_7801r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_7801r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_7801r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t6=(C_word)C_notvemptyp(t5);
t7=(C_truep(t6)?(C_word)C_i_vector_ref(t5,C_fix(0)):C_SCHEME_FALSE);
t8=(C_word)C_block_size(t2);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7811,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=t2,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1551 ##sys#make-vector */
t10=*((C_word*)lf[275]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t8,C_SCHEME_END_OF_LIST);}

/* k7809 in ##sys#copy-env-table in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7811,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7816,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=lf[563],tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_7816(t5,((C_word*)t0)[2],C_fix(0));}

/* do1033 in k7809 in ##sys#copy-env-table in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_7816(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7816,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[7]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7837,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7843,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=lf[562],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_7843(t8,t3,t4);}}

/* copy in do1033 in k7809 in ##sys#copy-env-table in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_7843(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7843,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_i_not(((C_word*)t0)[5]);
t6=(C_truep(t5)?t5:(C_word)C_i_memq(t4,((C_word*)t0)[5]));
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(1));
t8=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[3]:(C_word)C_slot(t3,C_fix(2)));
t9=(C_word)C_a_i_vector(&a,3,t4,t7,t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7876,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1566 copy */
t14=t10;
t15=t11;
t1=t14;
t2=t15;
goto loop;}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1567 copy */
t14=t1;
t15=t7;
t1=t14;
t2=t15;
goto loop;}}}

/* k7874 in copy in do1033 in k7809 in ##sys#copy-env-table in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7876,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7835 in do1033 in k7809 in ##sys#copy-env-table in k7792 in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_7816(t4,((C_word*)t0)[2],t3);}

/* ##sys#string->c-identifier in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7738(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7738,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7742,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1532 string-copy */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k7740 in ##sys#string->c-identifier in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7742,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7750,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=lf[555],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_7750(t6,((C_word*)t0)[2],C_fix(0));}

/* do1018 in k7740 in ##sys#string->c-identifier in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_7750(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7750,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7770,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_u_i_char_alphabeticp(t3))){
t5=t4;
f_7770(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_u_i_char_numericp(t3);
t6=(C_word)C_i_not(t5);
t7=t4;
f_7770(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,C_fix(0))));}}}

/* k7768 in do1018 in k7740 in ##sys#string->c-identifier in k7734 in k7731 in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_7770(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(t1)?(C_word)C_setsubchar(((C_word*)t0)[5],((C_word*)t0)[4],C_make_character(95)):C_SCHEME_UNDEFINED);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_7750(t4,((C_word*)t0)[2],t3);}

/* set-extension-specifier! in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7694,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[550]);
t5=(C_word)C_i_assq(t2,*((C_word*)lf[543]+1));
if(C_truep(t5)){
t6=(C_word)C_slot(t5,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7712,a[2]=t6,a[3]=t3,a[4]=lf[551],tmp=(C_word)a,a+=5,tmp);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_setslot(t5,C_fix(1),t7));}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7726,a[2]=t3,a[3]=lf[552],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,*((C_word*)lf[543]+1));
t9=C_mutate((C_word*)lf[543]+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}

/* a7725 in set-extension-specifier! in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7726(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7726,3,t0,t1,t2);}
/* eval.scm: 1487 proc */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_SCHEME_FALSE);}

/* a7711 in set-extension-specifier! in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7712(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7712,3,t0,t1,t2);}
/* eval.scm: 1485 proc */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7295(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7295,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7298,a[2]=t3,a[3]=lf[531],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7319,a[2]=t4,a[3]=t3,a[4]=lf[542],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7570,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_i_car(t2);
t8=t6;
f_7570(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_7570(t7,C_SCHEME_FALSE);}}

/* k7568 in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_7570(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7570,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(0));
t3=(C_word)C_i_assq(t2,*((C_word*)lf[543]+1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7579,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=t5;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,((C_word*)t0)[6]);}
else{
/* eval.scm: 1473 ##sys#error */
t4=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[5],lf[547],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[6]))){
/* eval.scm: 1475 doit */
t2=((C_word*)t0)[2];
f_7319(t2,((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
/* eval.scm: 1476 ##sys#error */
t2=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],lf[548],((C_word*)t0)[6]);}}}

/* k7577 in k7568 in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7579,2,t0,t1);}
if(C_truep((C_word)C_i_stringp(t1))){
t2=(C_word)C_a_i_list(&a,2,lf[419],t1);
/* eval.scm: 1461 values */
C_values(4,0,((C_word*)t0)[4],t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7605,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1463 vector->list */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}
else{
/* eval.scm: 1472 ##sys#do-the-right-thing */
t2=*((C_word*)lf[324]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3]);}}}

/* k7603 in k7577 in k7568 in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7605,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7607,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=lf[546],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_7607(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k7603 in k7577 in k7568 in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_7607(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7607,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7625,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1467 reverse */
t6=*((C_word*)lf[113]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7630,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=lf[544],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7640,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t2,a[6]=lf[545],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1468 ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}}

/* a7639 in loop in k7603 in k7577 in k7568 in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7640(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7640,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t6=(C_truep(t3)?t3:((C_word*)t0)[3]);
/* eval.scm: 1469 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_7607(t7,t1,t4,t5,t6);}

/* a7629 in loop in k7603 in k7577 in k7568 in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7630,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
/* eval.scm: 1468 ##sys#do-the-right-thing */
t3=*((C_word*)lf[324]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k7623 in loop in k7603 in k7577 in k7568 in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7625,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[143],t1);
/* eval.scm: 1467 values */
C_values(4,0,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* doit in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_7319(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7319,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_memq(t2,lf[26]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7329,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_7329(2,t5,t3);}
else{
if(C_truep(((C_word*)t0)[3])){
t5=t4;
f_7329(2,t5,(C_word)C_i_memq(t2,lf[28]));}
else{
/* eval.scm: 1414 ##sys#feature? */
t5=*((C_word*)lf[541]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}}

/* k7327 in doit in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[47],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7329,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 1415 values */
C_values(4,0,((C_word*)t0)[5],lf[532],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[4];
if(C_truep((C_truep((C_word)C_eqp(t2,lf[533]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,lf[534]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7341,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1417 ##sys#->feature-id */
t4=*((C_word*)lf[469]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],*((C_word*)lf[2]+1)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7378,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_a_i_list(&a,2,lf[537],((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,2,lf[124],t4);
t6=t3;
f_7378(t6,(C_word)C_a_i_list(&a,2,lf[335],t5));}
else{
t4=(C_word)C_a_i_list(&a,2,lf[124],((C_word*)t0)[4]);
t5=t3;
f_7378(t5,(C_word)C_a_i_list(&a,2,lf[471],t4));}}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],*((C_word*)lf[4]+1)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7405,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1429 ##sys#extension-information */
t4=*((C_word*)lf[513]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],lf[539]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1439 ##sys#extension-information */
t4=*((C_word*)lf[513]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],lf[539]);}}}}}

/* k7461 in k7327 in doit in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7463,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[538],t1);
t3=(C_word)C_i_assq(lf[520],t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7475,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
/* eval.scm: 1443 add-req */
t5=((C_word*)t0)[2];
f_7298(t5,t4,((C_word*)t0)[3]);}
else{
t5=t4;
f_7475(2,t5,C_SCHEME_UNDEFINED);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7544,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1455 add-req */
t3=((C_word*)t0)[2];
f_7298(t3,t2,((C_word*)t0)[3]);}}

/* k7542 in k7461 in k7327 in doit in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7544,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[124],((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[318],t2);
/* eval.scm: 1456 values */
C_values(4,0,((C_word*)t0)[2],t3,C_SCHEME_FALSE);}

/* k7473 in k7461 in k7327 in doit in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7486,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7490,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_a_i_list(&a,2,lf[124],((C_word*)t0)[2]);
t5=(C_word)C_a_i_list(&a,2,lf[316],t4);
t6=t3;
f_7490(t6,(C_word)C_a_i_list(&a,1,t5));}
else{
t4=t3;
f_7490(t4,C_SCHEME_END_OF_LIST);}}

/* k7488 in k7473 in k7461 in k7327 in doit in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_7490(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7490,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7494,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep(((C_word*)t0)[4])?C_SCHEME_FALSE:((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t2;
f_7494(t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7508,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7510,a[2]=lf[540],tmp=(C_word)a,a+=3,tmp);
t6=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cdr(((C_word*)t0)[4]):(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));
/* map */
t7=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}}

/* a7509 in k7488 in k7473 in k7461 in k7327 in doit in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7510(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7510,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[124],t2));}

/* k7506 in k7488 in k7473 in k7461 in k7327 in doit in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7508,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[318],t1);
t3=((C_word*)t0)[2];
f_7494(t3,(C_word)C_a_i_list(&a,1,t2));}

/* k7492 in k7488 in k7473 in k7461 in k7327 in doit in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_7494(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1400 ##sys#append */
t2=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7484 in k7473 in k7461 in k7327 in doit in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7486,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[143],t1);
/* eval.scm: 1444 values */
C_values(4,0,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k7403 in k7327 in doit in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7405,2,t0,t1);}
t2=(C_word)C_i_assq(lf[538],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7419,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7423,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t5=(C_word)C_a_i_list(&a,2,lf[124],((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,2,lf[316],t5);
t7=t4;
f_7423(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t5=t4;
f_7423(t5,C_SCHEME_END_OF_LIST);}}

/* k7421 in k7403 in k7327 in doit in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_7423(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7423,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7431,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_a_i_list(&a,2,lf[537],((C_word*)t0)[2]);
t4=(C_word)C_a_i_list(&a,2,lf[124],t3);
t5=t2;
f_7431(t5,(C_word)C_a_i_list(&a,2,lf[335],t4));}
else{
t3=(C_word)C_a_i_list(&a,2,lf[124],((C_word*)t0)[2]);
t4=t2;
f_7431(t4,(C_word)C_a_i_list(&a,2,lf[471],t3));}}

/* k7429 in k7421 in k7403 in k7327 in doit in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_7431(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7431,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* eval.scm: 1400 ##sys#append */
t3=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k7417 in k7403 in k7327 in doit in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7419,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[143],t1);
/* eval.scm: 1431 values */
C_values(4,0,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k7376 in k7327 in doit in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_7378(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1423 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k7339 in k7327 in doit in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7344,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_memq(t1,*((C_word*)lf[338]+1)))){
t3=t2;
f_7344(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7353,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7361,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7365,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1419 ##sys#symbol->string */
t6=*((C_word*)lf[482]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}}

/* k7363 in k7339 in k7327 in doit in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1419 ##sys#resolve-include-filename */
t2=*((C_word*)lf[536]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k7359 in k7339 in k7327 in doit in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1419 ##sys#load */
t2=*((C_word*)lf[404]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k7351 in k7339 in k7327 in doit in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7353,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],*((C_word*)lf[338]+1));
t3=C_mutate((C_word*)lf[338]+1,t2);
t4=((C_word*)t0)[2];
f_7344(t4,t3);}

/* k7342 in k7339 in k7327 in doit in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_7344(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1421 values */
C_values(4,0,((C_word*)t0)[2],lf[535],C_SCHEME_TRUE);}

/* add-req in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_7298(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7298,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7307,a[2]=t2,a[3]=lf[526],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7313,a[2]=t2,a[3]=lf[527],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1405 hash-table-update! */
t5=*((C_word*)lf[528]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t1,*((C_word*)lf[529]+1),lf[530],t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a7312 in add-req in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7313,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* a7306 in add-req in ##sys#do-the-right-thing in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7307(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7307,3,t0,t1,t2);}
/* lset-adjoin */
t3=*((C_word*)lf[524]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,*((C_word*)lf[525]+1),t2,((C_word*)t0)[2]);}

/* ##sys#lookup-runtime-requirements in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7246(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7246,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7252,a[2]=t4,a[3]=lf[521],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_7252(t6,t1,t2);}

/* loop1 in ##sys#lookup-runtime-requirements in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_7252(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7252,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7266,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* eval.scm: 1394 ##sys#extension-information */
t5=*((C_word*)lf[513]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_FALSE);}}

/* k7264 in loop1 in ##sys#lookup-runtime-requirements in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7266,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7269,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_assq(lf[520],t1);
t4=t2;
f_7269(t4,(C_truep(t3)?(C_word)C_i_cdr(t3):C_SCHEME_FALSE));}
else{
t3=t2;
f_7269(t3,C_SCHEME_FALSE);}}

/* k7267 in k7264 in loop1 in ##sys#lookup-runtime-requirements in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_7269(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7269,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7276,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* eval.scm: 1398 loop1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7252(t5,t3,t4);}

/* k7274 in k7267 in k7264 in loop1 in ##sys#lookup-runtime-requirements in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1393 append */
t2=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* extension-information in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7240(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7240,3,t0,t1,t2);}
/* eval.scm: 1384 ##sys#extension-information */
t3=*((C_word*)lf[513]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[518]);}

/* ##sys#extension-information in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7209(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7209,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7213,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1377 ##sys#canonicalize-extension-path */
t5=*((C_word*)lf[477]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* k7211 in ##sys#extension-information in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7216,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7238,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1378 ##sys#repository-path */
t4=*((C_word*)lf[488]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k7236 in k7211 in ##sys#extension-information in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1378 string-append */
t2=((C_word*)t0)[4];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],t1,lf[515],((C_word*)t0)[2],lf[516]);}

/* k7214 in k7211 in ##sys#extension-information in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7216,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7219,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7234,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1379 string-append */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t1,lf[20]);}

/* k7232 in k7214 in k7211 in ##sys#extension-information in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1379 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7217 in k7214 in k7211 in ##sys#extension-information in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7219,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7226,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[514],tmp=(C_word)a,a+=5,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_7226 in k7217 in k7214 in k7211 in ##sys#extension-information in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7226(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7226,3,t0,t1,t2);}
/* with-input-from-file923 */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#require in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7196(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_7196r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7196r(t0,t1,t2);}}

static void C_ccall f_7196r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7202,a[2]=lf[511],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[183]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a7201 in ##sys#require in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7202(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7202,3,t0,t1,t2);}
/* ##sys#load-extension */
t3=*((C_word*)lf[500]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[510]);}

/* ##sys#provided? in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7182(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7182,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7193,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1358 ##sys#canonicalize-extension-path */
t4=*((C_word*)lf[477]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[508]);}

/* k7191 in ##sys#provided? in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_member(t1,*((C_word*)lf[498]+1));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* ##sys#provide in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7162(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_7162r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7162r(t0,t1,t2);}}

static void C_ccall f_7162r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7168,a[2]=lf[505],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[183]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a7167 in ##sys#provide in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7168(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7168,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[504]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7175,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1351 ##sys#canonicalize-extension-path */
t5=*((C_word*)lf[477]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[504]);}

/* k7173 in a7167 in ##sys#provide in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7175,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,*((C_word*)lf[498]+1));
t3=C_mutate((C_word*)lf[498]+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##sys#load-extension in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7087(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_7087r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7087r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7087r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7091,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)t5)[1]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7157,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1332 string->symbol */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t5)[1]);}
else{
t7=t6;
f_7091(t7,(C_word)C_i_check_symbol_2(((C_word*)t5)[1],t3));}}

/* k7155 in ##sys#load-extension in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_7091(t3,t2);}

/* k7089 in ##sys#load-extension in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_7091(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7091,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7094,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1334 ##sys#canonicalize-extension-path */
t3=*((C_word*)lf[477]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[2]);}

/* k7092 in k7089 in ##sys#load-extension in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7094,2,t0,t1);}
t2=(C_word)C_i_member(t1,*((C_word*)lf[498]+1));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_memq(((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[2]+1)))){
/* eval.scm: 1337 ##sys#load-library */
t3=*((C_word*)lf[462]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7112,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1339 ##sys#find-extension */
t4=*((C_word*)lf[491]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_SCHEME_TRUE);}}}

/* k7110 in k7092 in k7089 in ##sys#load-extension in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7112,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7118,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1341 ##sys#load */
t3=*((C_word*)lf[404]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[4];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_7128(2,t4,C_SCHEME_TRUE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_7128(2,t5,(C_word)C_i_car(t2));}
else{
/* eval.scm: 1344 ##sys#error */
t5=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}}

/* k7126 in k7110 in k7092 in k7089 in ##sys#load-extension in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 1344 ##sys#error */
t2=*((C_word*)lf[168]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[501],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7116 in k7110 in k7092 in k7089 in ##sys#load-extension in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7118,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],*((C_word*)lf[498]+1));
t3=C_mutate((C_word*)lf[498]+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}

/* ##sys#find-extension in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7010(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7010,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7013,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=lf[493],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7044,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7084,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1320 ##sys#repository-path */
t7=*((C_word*)lf[488]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k7082 in ##sys#find-extension in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7084,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7077,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* eval.scm: 1321 ##sys#append */
t4=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[495]+1),lf[496]);}
else{
t4=t3;
f_7077(2,t4,C_SCHEME_END_OF_LIST);}}

/* k7075 in k7082 in ##sys#find-extension in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1320 ##sys#append */
t2=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7042 in ##sys#find-extension in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7044,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7046,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=lf[494],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_7046(t5,((C_word*)t0)[2],t1);}

/* loop in k7042 in ##sys#find-extension in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_7046(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7046,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7059,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1324 check */
t5=((C_word*)t0)[2];
f_7013(t5,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7057 in loop in k7042 in ##sys#find-extension in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1325 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7046(t3,((C_word*)t0)[4],t2);}}

/* check in ##sys#find-extension in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_7013(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7013,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7017,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1316 string-append */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,t2,lf[492],((C_word*)t0)[2]);}

/* k7015 in check in ##sys#find-extension in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7023,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7037,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1317 ##sys#string-append */
t4=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,*((C_word*)lf[438]+1));}

/* k7035 in k7015 in check in ##sys#find-extension in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1317 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7021 in k7015 in check in ##sys#find-extension in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7026,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_7026(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7033,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1318 ##sys#string-append */
t4=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],lf[17]);}}

/* k7031 in k7021 in k7015 in check in ##sys#find-extension in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1318 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7024 in k7021 in k7015 in check in ##sys#find-extension in k7005 in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_7026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* ##sys#canonicalize-extension-path in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6847,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6850,a[2]=t2,a[3]=t3,a[4]=lf[479],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6856,a[2]=lf[480],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6869,a[2]=t1,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t7=t6;
f_6869(2,t7,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* eval.scm: 1281 ##sys#symbol->string */
t7=*((C_word*)lf[482]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}
else{
if(C_truep((C_word)C_i_listp(t2))){
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6952,a[2]=t4,a[3]=t8,a[4]=((C_word*)t0)[2],a[5]=lf[486],tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_6952(t10,t6,t2);}
else{
t7=t6;
f_6869(2,t7,C_SCHEME_UNDEFINED);}}}}

/* loop in ##sys#canonicalize-extension-path in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_6952(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6952,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[483]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6969,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
/* eval.scm: 1288 ##sys#symbol->string */
t5=*((C_word*)lf[482]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_stringp(t3))){
t5=t4;
f_6969(2,t5,t3);}
else{
/* eval.scm: 1290 err */
t5=((C_word*)t0)[2];
f_6850(t5,t4);}}}}

/* k6967 in loop in ##sys#canonicalize-extension-path in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6969,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?lf[484]:lf[485]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6977,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* eval.scm: 1294 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6952(t7,t5,t6);}

/* k6975 in k6967 in loop in ##sys#canonicalize-extension-path in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1286 string-append */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6867 in ##sys#canonicalize-extension-path in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6869,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6874,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[481],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_6874(t5,((C_word*)t0)[2],t1);}

/* check in k6867 in ##sys#canonicalize-extension-path in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_6874(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6874,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(C_word)C_eqp(C_fix(0),t3);
if(C_truep(t4)){
/* eval.scm: 1297 err */
t5=((C_word*)t0)[4];
f_6850(t5,t1);}
else{
t5=(C_word)C_i_string_ref(t2,C_fix(0));
t6=f_6856(t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6900,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1299 ##sys#substring */
t8=*((C_word*)lf[427]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,t2,C_fix(1),t3);}
else{
t7=(C_word)C_fixnum_difference(t3,C_fix(1));
t8=(C_word)C_i_string_ref(t2,t7);
t9=f_6856(t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6913,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_fixnum_difference(t3,C_fix(1));
/* eval.scm: 1301 ##sys#substring */
t12=*((C_word*)lf[427]+1);
((C_proc5)(void*)(*((C_word*)t12+1)))(5,t12,t10,t2,C_fix(0),t11);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t2);}}}}

/* k6911 in check in k6867 in ##sys#canonicalize-extension-path in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1301 check */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6874(t2,((C_word*)t0)[2],t1);}

/* k6898 in check in k6867 in ##sys#canonicalize-extension-path in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1299 check */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6874(t2,((C_word*)t0)[2],t1);}

/* sep? in ##sys#canonicalize-extension-path in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static C_word C_fcall f_6856(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_eqp(C_make_character(92),t1);
return((C_truep(t2)?t2:(C_word)C_eqp(C_make_character(47),t1)));}

/* err in ##sys#canonicalize-extension-path in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_6850(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6850,NULL,2,t0,t1);}
/* eval.scm: 1278 ##sys#error */
t2=*((C_word*)lf[168]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],lf[478],((C_word*)t0)[2]);}

/* ##sys#split-at-separator in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6791(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6791,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6800,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t4,a[7]=lf[475],tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_6800(t8,t1,C_SCHEME_END_OF_LIST,C_fix(0),C_fix(0));}

/* loop in ##sys#split-at-separator in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_6800(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(11);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6800,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[6]))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6818,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1266 ##sys#substring */
t6=*((C_word*)lf[427]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[4],t4,((C_word*)t0)[6]);}
else{
t5=(C_word)C_eqp((C_word)C_subchar(((C_word*)t0)[4],t3),((C_word*)t0)[3]);
if(C_truep(t5)){
t6=(C_word)C_fixnum_plus(t3,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6838,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1269 ##sys#substring */
t8=*((C_word*)lf[427]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,((C_word*)t0)[4],t4,t3);}
else{
t6=(C_word)C_fixnum_plus(t3,C_fix(1));
/* eval.scm: 1270 loop */
t11=t1;
t12=t2;
t13=t6;
t14=t4;
t1=t11;
t2=t12;
t3=t13;
t4=t14;
goto loop;}}}

/* k6836 in loop in ##sys#split-at-separator in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6838,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* eval.scm: 1269 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6800(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2],((C_word*)t0)[2]);}

/* k6816 in loop in ##sys#split-at-separator in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6818,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* eval.scm: 1266 reverse */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* load-library in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6762(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6762r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6762r(t0,t1,t2,t3);}}

static void C_ccall f_6762r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_symbol_2(t2,lf[471]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6769,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_notvemptyp(t3);
t7=(C_truep(t6)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
/* eval.scm: 1257 ##sys#load-library */
t8=*((C_word*)lf[462]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,t2,t7);}

/* k6767 in load-library in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6769,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6779,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_dlerror),C_fix(0));}}

/* k6777 in k6767 in load-library in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1258 ##sys#error */
t2=*((C_word*)lf[168]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[471],lf[472],((C_word*)t0)[2],t1);}

/* ##sys#load-library in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6656,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6660,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1230 ##sys#->feature-id */
t5=*((C_word*)lf[469]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6658 in ##sys#load-library in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6660,2,t0,t1);}
t2=(C_word)C_i_memq(t1,*((C_word*)lf[338]+1));
if(C_truep(t2)){
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6669,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=t3;
f_6669(t4,(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6752,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* eval.scm: 1235 ##sys#string-append */
t6=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,*((C_word*)lf[458]+1));}}}

/* k6750 in k6658 in ##sys#load-library in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6752,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6756,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1236 dynamic-load-libraries */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6754 in k6750 in k6658 in ##sys#load-library in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6756,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6669(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6667 in k6658 in ##sys#load-library in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_6669(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6669,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6672,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6734,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6738,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1241 ##sys#string->c-identifier */
t6=*((C_word*)lf[468]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k6736 in k6667 in k6658 in ##sys#load-library in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1239 string-append */
t2=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[466],t1,lf[467]);}

/* k6732 in k6667 in k6658 in ##sys#load-library in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1238 ##sys#make-c-string */
t2=*((C_word*)lf[431]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6670 in k6667 in k6658 in ##sys#load-library in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6675,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6721,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1243 load-verbose */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k6719 in k6670 in k6667 in k6658 in ##sys#load-library in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6721,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6724,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1244 display */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[465]);}
else{
t2=((C_word*)t0)[3];
f_6675(2,t2,C_SCHEME_UNDEFINED);}}

/* k6722 in k6719 in k6670 in k6667 in k6658 in ##sys#load-library in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6727,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1245 display */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6725 in k6722 in k6719 in k6670 in k6667 in k6658 in ##sys#load-library in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1246 display */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[464]);}

/* k6673 in k6670 in k6667 in k6658 in ##sys#load-library in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6675,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6680,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=lf[463],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_6680(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k6673 in k6670 in k6667 in k6658 in ##sys#load-library in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_6680(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6680,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6693,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6714,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1249 ##sys#make-c-string */
t6=*((C_word*)lf[431]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* k6712 in loop in k6673 in k6670 in k6667 in k6658 in ##sys#load-library in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1249 ##sys#dload */
t2=*((C_word*)lf[430]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k6691 in loop in k6673 in k6670 in k6667 in k6658 in ##sys#load-library in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6693,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6696,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],*((C_word*)lf[338]+1)))){
t3=t2;
f_6696(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],*((C_word*)lf[338]+1));
t4=C_mutate((C_word*)lf[338]+1,t3);
t5=t2;
f_6696(t5,t4);}}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1252 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6680(t3,((C_word*)t0)[5],t2);}}

/* k6694 in k6691 in loop in k6673 in k6670 in k6667 in k6658 in ##sys#load-library in k6652 in k6645 in k6640 in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_6696(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* load-noisily in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6616(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_6616r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6616r(t0,t1,t2,t3);}}

static void C_ccall f_6616r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6620,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6637,a[2]=lf[455],tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
t6=*((C_word*)lf[125]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[456],t3,t5);}

/* a6636 in load-noisily in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6637,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k6618 in load-noisily in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6623,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6634,a[2]=lf[453],tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
t4=*((C_word*)lf[125]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[454],((C_word*)t0)[2],t3);}

/* a6633 in k6618 in load-noisily in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6634,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k6621 in k6618 in load-noisily in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6626,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6631,a[2]=lf[451],tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
t4=*((C_word*)lf[125]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[452],((C_word*)t0)[2],t3);}

/* a6630 in k6621 in k6618 in load-noisily in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6631,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k6624 in k6621 in k6618 in load-noisily in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1201 ##sys#load */
t2=*((C_word*)lf[404]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],t1);}

/* load-relative in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6573(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_6573r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6573r(t0,t1,t2,t3);}}

static void C_ccall f_6573r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6581,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_string_ref(t2,C_fix(0));
if(C_truep((C_truep((C_word)C_eqp(t5,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t5,C_make_character(47)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t6=t4;
f_6581(2,t6,t2);}
else{
/* eval.scm: 1197 ##sys#string-append */
t6=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[386]+1),t2);}}

/* k6579 in load-relative in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6581,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6585,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_6585(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_6585(2,t5,(C_word)C_i_car(t2));}
else{
/* eval.scm: 1198 ##sys#error */
t5=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k6583 in k6579 in load-relative in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1194 ##sys#load */
t2=*((C_word*)lf[404]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6544(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_6544r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6544r(t0,t1,t2,t3);}}

static void C_ccall f_6544r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6552,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_6552(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_6552(2,t6,(C_word)C_i_car(t3));}
else{
/* eval.scm: 1191 ##sys#error */
t6=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k6550 in load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1191 ##sys#load */
t2=*((C_word*)lf[404]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+26)){
C_save_and_reclaim((void*)tr5r,(void*)f_6154r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6154r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6154r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(26);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6156,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t6,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t4,a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=t3,a[15]=lf[443],tmp=(C_word)a,a+=16,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6491,a[2]=t7,a[3]=lf[444],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6496,a[2]=t8,a[3]=lf[445],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-timer724802 */
t10=t9;
f_6496(t10,t1);}
else{
t10=(C_word)C_i_car(t5);
t11=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-printer725800 */
t12=t8;
f_6491(t12,t1,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body722727 */
t14=t7;
f_6156(t14,t1,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}

/* def-timer724 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_6496(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6496,NULL,2,t0,t1);}
/* def-printer725800 */
t2=((C_word*)t0)[2];
f_6491(t2,t1,C_SCHEME_FALSE);}

/* def-printer725 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_6491(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6491,NULL,3,t0,t1,t2);}
/* body722727 */
t3=((C_word*)t0)[2];
f_6156(t3,t1,t2,C_SCHEME_FALSE);}

/* body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_6156(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6156,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_6160,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=t2,a[14]=((C_word*)t0)[12],a[15]=t1,a[16]=((C_word*)t0)[13],a[17]=((C_word*)t0)[14],tmp=(C_word)a,a+=18,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[6])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6490,a[2]=t4,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1126 ##sys#expand-home-path */
t6=*((C_word*)lf[442]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)((C_word*)t0)[6])[1]);}
else{
t5=t4;
f_6160(t5,C_SCHEME_UNDEFINED);}}

/* k6488 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6160(t3,t2);}

/* k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_6160(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6160,NULL,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_6163,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6424,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1129 port? */
t6=*((C_word*)lf[441]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)((C_word*)t0)[6])[1]);}

/* k6422 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6424,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6163(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[3])[1]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1131 ##sys#file-info */
t3=*((C_word*)lf[437]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
/* eval.scm: 1122 ##sys#signal-hook */
t3=*((C_word*)lf[394]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],lf[439],lf[419],lf[440],t2);}}}

/* k6437 in k6422 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_slot(t1,C_fix(4));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix(1),t3);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t2;
f_6442(t6,(C_word)C_i_not(t3));}
else{
t4=t2;
f_6442(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_6442(t3,C_SCHEME_FALSE);}}

/* k6440 in k6437 in k6422 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_6442(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6442,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6163(2,t2,((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6445,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1137 ##sys#string-append */
t3=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],*((C_word*)lf[438]+1));}}

/* k6443 in k6440 in k6437 in k6422 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6451,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1138 ##sys#file-info */
t3=*((C_word*)lf[437]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k6449 in k6443 in k6440 in k6437 in k6422 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6451,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6163(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6454,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1140 ##sys#string-append */
t3=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],lf[17]);}}

/* k6452 in k6449 in k6443 in k6440 in k6437 in k6422 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1141 ##sys#file-info */
t3=*((C_word*)lf[437]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k6458 in k6452 in k6449 in k6443 in k6440 in k6437 in k6422 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6163(2,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[5];
f_6163(2,t3,(C_truep(t2)?C_SCHEME_FALSE:((C_word*)((C_word*)t0)[2])[1]));}}

/* k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6163,2,t0,t1);}
t2=((C_word*)t0)[17];
t3=(C_truep(t2)?t2:((C_word*)t0)[16]);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6169,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t3,a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=t1,a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t5=(C_word)C_i_stringp(((C_word*)((C_word*)t0)[6])[1]);
t6=(C_truep(t5)?(C_word)C_i_not(t1):C_SCHEME_FALSE);
if(C_truep(t6)){
/* eval.scm: 1146 ##sys#signal-hook */
t7=*((C_word*)lf[394]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,lf[433],lf[419],lf[434],((C_word*)((C_word*)t0)[6])[1]);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6415,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1147 load-verbose */
t8=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}}

/* k6413 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6415,2,t0,t1);}
t2=(C_truep(t1)?((C_word*)t0)[4]:C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6406,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1148 display */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[436]);}
else{
t3=((C_word*)t0)[2];
f_6169(2,t3,C_SCHEME_UNDEFINED);}}

/* k6404 in k6413 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6409,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1149 display */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6407 in k6404 in k6413 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1150 display */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[435]);}

/* k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6172,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)t0)[14])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6363,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6391,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1152 ##sys#make-c-string */
t5=*((C_word*)lf[431]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[14]);}
else{
t3=t2;
f_6172(2,t3,C_SCHEME_FALSE);}}

/* k6389 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1152 ##sys#dload */
t2=*((C_word*)lf[430]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k6361 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6363,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6172(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6387,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1153 has-sep? */
f_6108(t2,((C_word*)t0)[3]);}}

/* k6385 in k6361 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6387,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6172(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6379,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6383,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1154 ##sys#string-append */
t4=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[432],((C_word*)t0)[2]);}}

/* k6381 in k6385 in k6361 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1154 ##sys#make-c-string */
t2=*((C_word*)lf[431]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6377 in k6385 in k6361 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1154 ##sys#dload */
t2=*((C_word*)lf[430]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6172,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6175,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_6175(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6180,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=lf[429],tmp=(C_word)a,a+=15,tmp);
/* eval.scm: 1155 call-with-current-continuation */
t4=*((C_word*)lf[71]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}}

/* a6179 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6180(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6180,3,t0,t1,t2);}
t3=C_SCHEME_TRUE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t0)[13];
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_6184,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t6,a[15]=t4,a[16]=t2,tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[13])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6350,a[2]=((C_word*)t0)[13],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1161 has-sep? */
f_6108(t8,((C_word*)t0)[13]);}
else{
t8=t7;
f_6184(2,t8,C_SCHEME_FALSE);}}

/* k6348 in a6179 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(t1,C_fix(1));
/* eval.scm: 1162 ##sys#substring */
t3=*((C_word*)lf[427]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2);}
else{
t2=((C_word*)t0)[3];
f_6184(2,t2,lf[428]);}}

/* k6182 in a6179 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[52],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6184,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6185,a[2]=((C_word*)t0)[16],a[3]=lf[405],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6194,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=t13,a[7]=t11,a[8]=t9,a[9]=t7,a[10]=lf[408],tmp=(C_word)a,a+=11,tmp);
t15=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6208,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=lf[425],tmp=(C_word)a,a+=14,tmp);
t16=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6335,a[2]=t13,a[3]=t11,a[4]=t9,a[5]=t7,a[6]=t5,a[7]=t3,a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],a[10]=lf[426],tmp=(C_word)a,a+=11,tmp);
/* ##sys#dynamic-wind */
t17=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t17+1)))(5,t17,((C_word*)t0)[2],t14,t15,t16);}

/* a6334 in k6182 in a6179 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6335,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,*((C_word*)lf[406]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,*((C_word*)lf[385]+1));
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,*((C_word*)lf[386]+1));
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,*((C_word*)lf[383]+1));
t6=C_mutate((C_word*)lf[406]+1,((C_word*)((C_word*)t0)[5])[1]);
t7=C_mutate((C_word*)lf[385]+1,((C_word*)((C_word*)t0)[4])[1]);
t8=C_mutate((C_word*)lf[386]+1,((C_word*)((C_word*)t0)[3])[1]);
t9=C_mutate((C_word*)lf[383]+1,((C_word*)((C_word*)t0)[2])[1]);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,*((C_word*)lf[407]+1));}

/* a6207 in k6182 in a6179 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6208,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6212,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[5])){
/* eval.scm: 1164 open-input-file */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_6212(2,t3,((C_word*)((C_word*)t0)[2])[1]);}}

/* k6210 in a6207 in k6182 in a6179 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6217,a[2]=lf[409],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6220,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[11],a[11]=lf[422],tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6326,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=lf[423],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1165 ##sys#dynamic-wind */
t5=*((C_word*)lf[424]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[2],t2,t3,t4);}

/* a6325 in k6210 in a6207 in k6182 in a6179 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6326,2,t0,t1);}
/* eval.scm: 1187 close-input-port */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* a6219 in k6210 in a6207 in k6182 in a6179 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6224,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 1168 peek-char */
t3=*((C_word*)lf[421]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[9]);}

/* k6222 in a6219 in k6210 in a6207 in k6182 in a6179 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6227,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(t1,C_make_character(127));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6320,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_dlerror),C_fix(0));}
else{
t4=t2;
f_6227(2,t4,C_SCHEME_UNDEFINED);}}

/* k6318 in k6222 in a6219 in k6210 in a6207 in k6182 in a6179 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1170 ##sys#error */
t2=*((C_word*)lf[168]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[419],lf[420],((C_word*)t0)[2],t1);}

/* k6225 in k6222 in a6219 in k6210 in a6207 in k6182 in a6179 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6227,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6230,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 1171 read */
t3=((C_word*)t0)[10];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[9]);}

/* k6228 in k6225 in k6222 in a6219 in k6210 in a6207 in k6182 in a6179 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6230,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6235,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t3,a[11]=lf[418],tmp=(C_word)a,a+=12,tmp));
t5=((C_word*)t3)[1];
f_6235(t5,((C_word*)t0)[2],t1);}

/* do775 in k6228 in k6225 in k6222 in a6219 in k6210 in a6207 in k6182 in a6179 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_6235(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6235,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6245,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[2])){
/* eval.scm: 1174 printer */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t4=t3;
f_6245(2,t4,C_SCHEME_UNDEFINED);}}}

/* k6243 in do775 in k6228 in k6225 in k6222 in a6219 in k6210 in a6207 in k6182 in a6179 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6248,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6257,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=lf[415],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6291,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[417],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1175 ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a6290 in k6243 in do775 in k6228 in k6225 in k6222 in a6219 in k6210 in a6207 in k6182 in a6179 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6291(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_6291r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6291r(t0,t1,t2);}}

static void C_ccall f_6291r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6300,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=lf[416],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t4=*((C_word*)lf[183]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a6299 in a6290 in k6243 in do775 in k6228 in k6225 in k6222 in a6219 in k6210 in a6207 in k6182 in a6179 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6300(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6300,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6304,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1184 write */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6302 in a6299 in a6290 in k6243 in do775 in k6228 in k6225 in k6222 in a6219 in k6210 in a6207 in k6182 in a6179 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1185 newline */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a6256 in k6243 in do775 in k6228 in k6225 in k6222 in a6219 in k6210 in a6207 in k6182 in a6179 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6257,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6264,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1178 ##sys#start-timer */
t3=*((C_word*)lf[414]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* eval.scm: 1179 evproc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}}

/* k6262 in a6256 in k6243 in do775 in k6228 in k6225 in k6222 in a6219 in k6210 in a6207 in k6182 in a6179 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6269,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[410],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6275,a[2]=lf[413],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1178 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a6274 in k6262 in a6256 in k6243 in do775 in k6228 in k6225 in k6222 in a6219 in k6210 in a6207 in k6182 in a6179 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6275(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_6275r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6275r(t0,t1,t2);}}

static void C_ccall f_6275r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6279,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6286,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1178 ##sys#stop-timer */
t5=*((C_word*)lf[412]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6284 in a6274 in k6262 in a6256 in k6243 in do775 in k6228 in k6225 in k6222 in a6219 in k6210 in a6207 in k6182 in a6179 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1178 ##sys#display-times */
t2=*((C_word*)lf[411]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6277 in a6274 in k6262 in a6256 in k6243 in do775 in k6228 in k6225 in k6222 in a6219 in k6210 in a6207 in k6182 in a6179 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6268 in k6262 in a6256 in k6243 in do775 in k6228 in k6225 in k6222 in a6219 in k6210 in a6207 in k6182 in a6179 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6269,2,t0,t1);}
/* eval.scm: 1178 evproc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k6246 in k6243 in do775 in k6228 in k6225 in k6222 in a6219 in k6210 in a6207 in k6182 in a6179 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6248,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6255,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1172 read */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6253 in k6246 in k6243 in do775 in k6228 in k6225 in k6222 in a6219 in k6210 in a6207 in k6182 in a6179 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_6235(t2,((C_word*)t0)[2],t1);}

/* a6216 in k6210 in a6207 in k6182 in a6179 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6217,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* a6193 in k6182 in a6179 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6194,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,*((C_word*)lf[406]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,*((C_word*)lf[385]+1));
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,*((C_word*)lf[386]+1));
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,*((C_word*)lf[383]+1));
t6=C_mutate((C_word*)lf[406]+1,((C_word*)((C_word*)t0)[5])[1]);
t7=C_mutate((C_word*)lf[385]+1,((C_word*)((C_word*)t0)[4])[1]);
t8=C_mutate((C_word*)lf[386]+1,((C_word*)((C_word*)t0)[3])[1]);
t9=C_mutate((C_word*)lf[383]+1,((C_word*)((C_word*)t0)[2])[1]);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,*((C_word*)lf[407]+1));}

/* f_6185 in k6182 in a6179 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6185,2,t0,t1);}
/* eval.scm: 1163 abrt */
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_FALSE);}

/* k6173 in k6170 in k6167 in k6161 in k6158 in body722 in ##sys#load in k6104 in k6024 in k5925 in k1709 */
static void C_ccall f_6175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* has-sep? in k6104 in k6024 in k5925 in k1709 */
static void C_fcall f_6108(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6108,NULL,2,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6118,a[2]=t2,a[3]=lf[402],tmp=(C_word)a,a+=4,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_6118(t5,t4));}

/* loop in has-sep? in k6104 in k6024 in k5925 in k1709 */
static C_word C_fcall f_6118(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
if(C_truep((C_word)C_i_zerop(t1))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_subchar(((C_word*)t0)[2],t1);
if(C_truep((C_truep((C_word)C_eqp(t2,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,C_make_character(47)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
return(t1);}
else{
t3=(C_word)C_fixnum_difference(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}}

/* set-dynamic-load-mode! in k6024 in k5925 in k1709 */
static void C_ccall f_6033(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[20],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6033,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?t2:(C_word)C_a_i_list(&a,1,t2));
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_TRUE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6040,a[2]=t8,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6045,a[2]=t6,a[3]=t8,a[4]=t11,a[5]=lf[396],tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_6045(t13,t9,t4);}

/* loop in set-dynamic-load-mode! in k6024 in k5925 in k1709 */
static void C_fcall f_6045(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6045,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6058,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(t3,lf[390]);
if(C_truep(t5)){
t6=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t7=t4;
f_6058(2,t7,t6);}
else{
t6=(C_word)C_eqp(t3,lf[391]);
if(C_truep(t6)){
t7=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
t8=t4;
f_6058(2,t8,t7);}
else{
t7=(C_word)C_eqp(t3,lf[392]);
if(C_truep(t7)){
t8=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t9=t4;
f_6058(2,t9,t8);}
else{
t8=(C_word)C_eqp(t3,lf[393]);
if(C_truep(t8)){
t9=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t10=t4;
f_6058(2,t10,t9);}
else{
t9=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1101 ##sys#signal-hook */
t10=*((C_word*)lf[394]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t4,lf[388],lf[395],t9);}}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6056 in loop in set-dynamic-load-mode! in k6024 in k5925 in k1709 */
static void C_ccall f_6058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1102 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6045(t3,((C_word*)t0)[2],t2);}

/* k6038 in set-dynamic-load-mode! in k6024 in k5925 in k1709 */
static void C_ccall f_6040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1103 ##sys#set-dlopen-flags! */
t2=*((C_word*)lf[389]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* f_6028 in k6024 in k5925 in k1709 */
static void C_ccall f_6028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6028,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* ##sys#decompose-lambda-list in k5925 in k1709 */
static void C_ccall f_5944(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5944,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5947,a[2]=t2,a[3]=lf[379],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5957,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=lf[380],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_5957(t8,t1,t2,C_SCHEME_END_OF_LIST,C_fix(0));}

/* loop in ##sys#decompose-lambda-list in k5925 in k1709 */
static void C_fcall f_5957(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(17);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5957,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5971,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1071 reverse */
t7=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t3);}
else{
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_symbolp(t2))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5990,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_a_i_cons(&a,2,t2,t3);
/* eval.scm: 1073 reverse */
t8=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
if(C_truep((C_word)C_pairp(t2))){
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t2,C_fix(0));
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
t9=(C_word)C_fixnum_plus(t4,C_fix(1));
/* eval.scm: 1075 loop */
t14=t1;
t15=t6;
t16=t8;
t17=t9;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
goto loop;}
else{
/* eval.scm: 1074 err */
t6=((C_word*)t0)[2];
f_5947(t6,t1);}}}
else{
/* eval.scm: 1072 err */
t6=((C_word*)t0)[2];
f_5947(t6,t1);}}}

/* k5988 in loop in ##sys#decompose-lambda-list in k5925 in k1709 */
static void C_ccall f_5990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1073 k */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5969 in loop in ##sys#decompose-lambda-list in k5925 in k1709 */
static void C_ccall f_5971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1071 k */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* err in ##sys#decompose-lambda-list in k5925 in k1709 */
static void C_fcall f_5947(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5947,NULL,2,t0,t1);}
t2=C_set_block_item(lf[377],0,C_SCHEME_FALSE);
/* eval.scm: 1068 ##sys#syntax-error-hook */
t3=*((C_word*)lf[73]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[378],((C_word*)t0)[2]);}

/* eval in k5925 in k1709 */
static void C_ccall f_5930(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5930r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5930r(t0,t1,t2,t3);}}

static void C_ccall f_5930r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5938,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1056 ##sys#eval-handler */
t5=*((C_word*)lf[373]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k5936 in eval in k5925 in k1709 */
static void C_ccall f_5938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5942,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1057 ##sys#interpreter-toplevel-macroexpand-hook */
t3=*((C_word*)lf[95]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5940 in k5936 in eval in k5925 in k1709 */
static void C_ccall f_5942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##sys#compile-to-closure in k1709 */
static void C_ccall f_3684(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+52)){
C_save_and_reclaim((void*)tr5r,(void*)f_3684r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3684r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3684r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a=C_alloc(52);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3687,a[2]=lf[211],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3729,a[2]=t6,a[3]=lf[214],tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3841,a[2]=t7,a[3]=t9,a[4]=lf[215],tmp=(C_word)a,a+=5,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3894,a[2]=lf[217],tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3900,a[2]=lf[218],tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3906,a[2]=lf[219],tmp=(C_word)a,a+=3,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3912,a[2]=t9,a[3]=t13,a[4]=t7,a[5]=t4,a[6]=((C_word*)t0)[2],a[7]=t15,a[8]=t17,a[9]=t12,a[10]=((C_word*)t0)[3],a[11]=t6,a[12]=lf[360],tmp=(C_word)a,a+=13,tmp));
t19=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5668,a[2]=t15,a[3]=t11,a[4]=lf[371],tmp=(C_word)a,a+=5,tmp));
t20=(C_word)C_fixnum_greaterp(*((C_word*)lf[202]+1),C_fix(0));
t21=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5904,a[2]=t20,a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t15,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
t22=t21;
f_5904(2,t22,C_SCHEME_FALSE);}
else{
t22=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t22))){
t23=t21;
f_5904(2,t23,(C_word)C_i_car(t5));}
else{
/* eval.scm: 1035 ##sys#error */
t23=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t23+1)))(4,t23,t21,lf[0],t5);}}}

/* k5902 in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1035 compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3912(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2],t1);}

/* compile-call in ##sys#compile-to-closure in k1709 */
static void C_fcall f_5668(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5668,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5672,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t1,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 999  compile */
t8=((C_word*)((C_word*)t0)[2])[1];
f_3912(t8,t6,t7,t3,C_SCHEME_FALSE,t4,t5);}

/* k5670 in compile-call in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[67],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5672,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5642,a[2]=lf[361],tmp=(C_word)a,a+=3,tmp);
t4=f_5642(t2,C_fix(0));
t5=((C_word*)t0)[8];
switch(t4){
case C_SCHEME_FALSE:
/* eval.scm: 1004 ##sys#syntax-error-hook */
t6=*((C_word*)lf[73]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[7],lf[362],((C_word*)t0)[8]);
case C_fix(0):
t6=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5694,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=lf[363],tmp=(C_word)a,a+=8,tmp));
case C_fix(1):
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5713,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1008 compile */
t8=((C_word*)((C_word*)t0)[3])[1];
f_3912(t8,t6,t7,((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
case C_fix(2):
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5741,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1012 compile */
t8=((C_word*)((C_word*)t0)[3])[1];
f_3912(t8,t6,t7,((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
case C_fix(3):
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5776,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1017 compile */
t8=((C_word*)((C_word*)t0)[3])[1];
f_3912(t8,t6,t7,((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
case C_fix(4):
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5818,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1023 compile */
t8=((C_word*)((C_word*)t0)[3])[1];
f_3912(t8,t6,t7,((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
default:
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5861,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5885,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=lf[370],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1030 ##sys#map */
t8=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,t2);}}

/* a5884 in k5670 in compile-call in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5885(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5885,3,t0,t1,t2);}
/* eval.scm: 1030 compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3912(t3,t1,t2,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5859 in k5670 in compile-call in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5861,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5862,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=lf[369],tmp=(C_word)a,a+=9,tmp));}

/* f_5862 in k5859 in k5670 in compile-call in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5862(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5862,3,t0,t1,t2);}
t3=f_3894(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5873,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5871 */
static void C_ccall f_5873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5877,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5879,a[2]=((C_word*)t0)[3],a[3]=lf[368],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1033 ##sys#map */
t4=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a5878 in k5871 */
static void C_ccall f_5879(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5879,3,t0,t1,t2);}
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,((C_word*)t0)[2]);}

/* k5875 in k5871 */
static void C_ccall f_5877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5816 in k5670 in compile-call in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5821,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 1024 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3912(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(1)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[8],((C_word*)t0)[6]);}

/* k5819 in k5816 in k5670 in compile-call in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* eval.scm: 1025 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3912(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(2)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[7]);}

/* k5822 in k5819 in k5816 in k5670 in compile-call in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5827,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 1026 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3912(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(3)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[10],((C_word*)t0)[8]);}

/* k5825 in k5822 in k5819 in k5816 in k5670 in compile-call in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5827,2,t0,t1);}
t2=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5828,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=lf[367],tmp=(C_word)a,a+=12,tmp));}

/* f_5828 in k5825 in k5822 in k5819 in k5816 in k5670 in compile-call in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5828(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5828,3,t0,t1,t2);}
t3=f_3894(((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5839,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5837 */
static void C_ccall f_5839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5843,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k5841 in k5837 */
static void C_ccall f_5843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5847,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k5845 in k5841 in k5837 */
static void C_ccall f_5847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5847,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5851,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k5849 in k5845 in k5841 in k5837 */
static void C_ccall f_5851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5854,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5852 in k5849 in k5845 in k5841 in k5837 */
static void C_ccall f_5854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5774 in k5670 in compile-call in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5779,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 1018 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3912(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(1)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[8],((C_word*)t0)[6]);}

/* k5777 in k5774 in k5670 in compile-call in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5782,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 1019 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3912(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(2)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[7]);}

/* k5780 in k5777 in k5774 in k5670 in compile-call in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5782,2,t0,t1);}
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5783,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=lf[366],tmp=(C_word)a,a+=11,tmp));}

/* f_5783 in k5780 in k5777 in k5774 in k5670 in compile-call in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5783(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5783,3,t0,t1,t2);}
t3=f_3894(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5794,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5792 */
static void C_ccall f_5794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5798,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k5796 in k5792 */
static void C_ccall f_5798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5802,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k5800 in k5796 in k5792 */
static void C_ccall f_5802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5805,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5803 in k5800 in k5796 in k5792 */
static void C_ccall f_5805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5739 in k5670 in compile-call in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5744,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1013 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3912(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(1)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[8],((C_word*)t0)[6]);}

/* k5742 in k5739 in k5670 in compile-call in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5744,2,t0,t1);}
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5745,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=lf[365],tmp=(C_word)a,a+=10,tmp));}

/* f_5745 in k5742 in k5739 in k5670 in compile-call in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5745(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5745,3,t0,t1,t2);}
t3=f_3894(((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5756,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5754 */
static void C_ccall f_5756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5760,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k5758 in k5754 */
static void C_ccall f_5760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5763,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5761 in k5758 in k5754 */
static void C_ccall f_5763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5711 in k5670 in compile-call in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5713,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5714,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=lf[364],tmp=(C_word)a,a+=9,tmp));}

/* f_5714 in k5711 in k5670 in compile-call in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5714(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5714,3,t0,t1,t2);}
t3=f_3894(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5725,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5723 */
static void C_ccall f_5725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5728,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5726 in k5723 */
static void C_ccall f_5728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_5694 in k5670 in compile-call in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5694(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5694,3,t0,t1,t2);}
t3=f_3894(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5704,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1007 fn */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k5702 */
static void C_ccall f_5704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* loop in k5670 in compile-call in ##sys#compile-to-closure in k1709 */
static C_word C_fcall f_5642(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(t2);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* compile in ##sys#compile-to-closure in k1709 */
static void C_fcall f_3912(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[29],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3912,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_symbolp(t2))){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3924,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[11],a[5]=lf[220],tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3930,a[2]=t2,a[3]=t6,a[4]=((C_word*)t0)[10],a[5]=lf[228],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 648  ##sys#call-with-values */
C_call_with_values(4,0,t1,t7,t8);}
else{
t7=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4015,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[11],a[8]=t4,a[9]=((C_word*)t0)[7],a[10]=t3,a[11]=((C_word*)t0)[8],a[12]=t6,a[13]=t5,a[14]=((C_word*)t0)[9],a[15]=t1,a[16]=t2,tmp=(C_word)a,a+=17,tmp);
/* eval.scm: 670  ##sys#number? */
t8=*((C_word*)lf[359]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}}

/* k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[39],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4015,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[16];
switch(t2){
case C_fix(-1):
t3=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4022,a[2]=lf[229],tmp=(C_word)a,a+=3,tmp));
case C_fix(0):
t3=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4030,a[2]=lf[230],tmp=(C_word)a,a+=3,tmp));
case C_fix(1):
t3=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4038,a[2]=lf[231],tmp=(C_word)a,a+=3,tmp));
default:
t3=(C_word)C_eqp(t2,C_fix(2));
t4=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4046,a[2]=lf[232],tmp=(C_word)a,a+=3,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4048,a[2]=((C_word*)t0)[16],a[3]=lf[233],tmp=(C_word)a,a+=4,tmp)));}}
else{
if(C_truep((C_word)C_booleanp(((C_word*)t0)[16]))){
t2=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)t0)[16])?(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4059,a[2]=lf[234],tmp=(C_word)a,a+=3,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4061,a[2]=lf[235],tmp=(C_word)a,a+=3,tmp)));}
else{
t2=(C_word)C_charp(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t2)){
t4=t3;
f_4071(t4,t2);}
else{
t4=(C_word)C_eofp(((C_word*)t0)[16]);
t5=t3;
f_4071(t5,(C_truep(t4)?t4:(C_word)C_i_stringp(((C_word*)t0)[16])));}}}}

/* k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_fcall f_4071(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4071,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[16];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4072,a[2]=((C_word*)t0)[15],a[3]=lf[236],tmp=(C_word)a,a+=4,tmp));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[15]))){
t2=(C_word)C_slot(((C_word*)t0)[15],C_fix(0));
if(C_truep((C_word)C_i_symbolp(t2))){
t3=f_3900(((C_word*)t0)[13],((C_word*)t0)[15],((C_word*)t0)[12]);
t4=(C_word)C_slot(((C_word*)t0)[15],C_fix(0));
t5=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4100,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t4,a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[11],tmp=(C_word)a,a+=17,tmp);
/* eval.scm: 689  defined? */
t6=((C_word*)t0)[4];
f_3729(t6,t5,t4,((C_word*)t0)[10]);}
else{
t3=f_3900(((C_word*)t0)[13],((C_word*)t0)[15],((C_word*)t0)[12]);
/* eval.scm: 980  compile-call */
t4=((C_word*)((C_word*)t0)[11])[1];
f_5668(t4,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[10],((C_word*)t0)[13],((C_word*)t0)[12]);}}
else{
/* eval.scm: 685  ##sys#syntax-error-hook */
t2=*((C_word*)lf[73]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[16],lf[358],((C_word*)t0)[15]);}}}

/* k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4100,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 690  compile-call */
t2=((C_word*)((C_word*)t0)[16])[1];
f_5668(t2,((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[11]);}
else{
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4106,a[2]=((C_word*)t0)[16],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* eval.scm: 691  macroexpand-1-checked */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3841(t3,t2,((C_word*)t0)[14],((C_word*)t0)[13]);}}

/* k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word ab[126],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4106,2,t0,t1);}
t2=(C_word)C_eqp(t1,((C_word*)t0)[15]);
if(C_truep(t2)){
t3=(C_word)C_eqp(((C_word*)t0)[14],lf[124]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4121,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 696  ##sys#check-syntax */
t5=*((C_word*)lf[84]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[124],((C_word*)t0)[15],lf[245],C_SCHEME_FALSE);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[14],lf[246]);
if(C_truep(t4)){
t5=(C_word)C_i_cadr(((C_word*)t0)[15]);
if(C_truep(*((C_word*)lf[190]+1))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4197,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 711  ##sys#hash-table-location */
t7=*((C_word*)lf[187]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,*((C_word*)lf[190]+1),t5,C_SCHEME_TRUE);}
else{
t6=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4203,a[2]=t5,a[3]=lf[248],tmp=(C_word)a,a+=4,tmp));}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[14],lf[249]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 716  compile */
t7=((C_word*)((C_word*)t0)[12])[1];
f_3912(t7,((C_word*)t0)[13],t6,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[14],lf[250]);
if(C_truep(t6)){
t7=(C_word)C_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 719  compile */
t8=((C_word*)((C_word*)t0)[12])[1];
f_3912(t8,((C_word*)t0)[13],t7,((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[14],lf[151]);
if(C_truep(t7)){
t8=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4237,a[2]=lf[251],tmp=(C_word)a,a+=3,tmp));}
else{
t8=(C_word)C_eqp(((C_word*)t0)[14],lf[252]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4247,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 724  ##sys#check-syntax */
t10=*((C_word*)lf[84]+1);
((C_proc6)(void*)(*((C_word*)t10+1)))(6,t10,t9,lf[252],((C_word*)t0)[15],lf[255],C_SCHEME_FALSE);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[14],lf[143]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4304,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[15],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 733  ##sys#check-syntax */
t11=*((C_word*)lf[84]+1);
((C_proc6)(void*)(*((C_word*)t11+1)))(6,t11,t10,lf[143],((C_word*)t0)[15],lf[259],C_SCHEME_FALSE);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[14],lf[89]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[14],lf[91]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4412,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[15],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 749  ##sys#check-syntax */
t13=*((C_word*)lf[84]+1);
((C_proc6)(void*)(*((C_word*)t13+1)))(6,t13,t12,lf[89],((C_word*)t0)[15],lf[269],C_SCHEME_FALSE);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[14],lf[77]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4521,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[15],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 773  ##sys#check-syntax */
t14=*((C_word*)lf[84]+1);
((C_proc6)(void*)(*((C_word*)t14+1)))(6,t14,t13,lf[77],((C_word*)t0)[15],lf[280],C_SCHEME_FALSE);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[14],lf[126]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4859,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[15],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 823  ##sys#check-syntax */
t15=*((C_word*)lf[84]+1);
((C_proc6)(void*)(*((C_word*)t15+1)))(6,t15,t14,lf[126],((C_word*)t0)[15],lf[314],C_SCHEME_FALSE);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[14],lf[78]);
if(C_truep(t14)){
t15=(C_word)C_i_cdr(((C_word*)t0)[15]);
t16=(C_word)C_a_i_cons(&a,2,lf[126],t15);
/* eval.scm: 917  compile */
t17=((C_word*)((C_word*)t0)[12])[1];
f_3912(t17,((C_word*)t0)[13],t16,((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[14],lf[315]);
if(C_truep(t15)){
t16=(C_word)C_i_cddr(((C_word*)t0)[15]);
t17=(C_word)C_a_i_cons(&a,2,lf[126],t16);
t18=(C_word)C_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 920  compile */
t19=((C_word*)((C_word*)t0)[12])[1];
f_3912(t19,((C_word*)t0)[13],t17,((C_word*)t0)[11],t18,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[14],lf[316]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5261,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5292,a[2]=lf[321],tmp=(C_word)a,a+=3,tmp);
t19=(C_word)C_i_cdr(((C_word*)t0)[15]);
/* map */
t20=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t17,t18,t19);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[14],lf[322]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5316,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t19=(C_word)C_i_cdr(((C_word*)t0)[15]);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5322,a[2]=t21,a[3]=lf[327],tmp=(C_word)a,a+=4,tmp));
t23=((C_word*)t21)[1];
f_5322(t23,t18,t19);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[14],lf[328]);
t19=(C_truep(t18)?t18:(C_word)C_eqp(((C_word*)t0)[14],lf[329]));
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5368,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5374,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 942  ##sys#compile-to-closure */
t23=*((C_word*)lf[208]+1);
((C_proc6)(void*)(*((C_word*)t23+1)))(6,t23,t21,t22,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[14],lf[331]);
if(C_truep(t20)){
t21=(C_word)C_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 946  compile */
t22=((C_word*)((C_word*)t0)[12])[1];
f_3912(t22,((C_word*)t0)[13],t21,((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[14],lf[332]);
t22=(C_truep(t21)?t21:(C_word)C_eqp(((C_word*)t0)[14],lf[333]));
if(C_truep(t22)){
/* eval.scm: 949  compile */
t23=((C_word*)((C_word*)t0)[12])[1];
f_3912(t23,((C_word*)t0)[13],lf[334],((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[14],lf[335]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5412,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_memq(lf[337],*((C_word*)lf[338]+1)))){
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5423,a[2]=lf[340],tmp=(C_word)a,a+=3,tmp);
t26=(C_word)C_i_cdr(((C_word*)t0)[15]);
/* for-each */
t27=*((C_word*)lf[183]+1);
((C_proc4)(void*)(*((C_word*)t27+1)))(4,t27,t24,t25,t26);}
else{
/* eval.scm: 954  ##sys#warn */
t25=*((C_word*)lf[341]+1);
((C_proc4)(void*)(*((C_word*)t25+1)))(4,t25,t24,lf[342],((C_word*)t0)[15]);}}
else{
t24=(C_word)C_eqp(((C_word*)t0)[14],lf[343]);
t25=(C_truep(t24)?t24:(C_word)C_eqp(((C_word*)t0)[14],lf[344]));
if(C_truep(t25)){
t26=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5462,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[15],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 958  cadadr */
t27=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t27))(3,t27,t26,((C_word*)t0)[15]);}
else{
t26=(C_word)C_eqp(((C_word*)t0)[14],lf[345]);
t27=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5475,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[13],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t26)){
t28=t27;
f_5475(t28,t26);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[14],lf[349]);
if(C_truep(t28)){
t29=t27;
f_5475(t29,t28);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[14],lf[350]);
if(C_truep(t29)){
t30=t27;
f_5475(t30,t29);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[14],lf[351]);
if(C_truep(t30)){
t31=t27;
f_5475(t31,t30);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[14],lf[352]);
if(C_truep(t31)){
t32=t27;
f_5475(t32,t31);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[14],lf[353]);
if(C_truep(t32)){
t33=t27;
f_5475(t33,t32);}
else{
t33=(C_word)C_eqp(((C_word*)t0)[14],lf[354]);
if(C_truep(t33)){
t34=t27;
f_5475(t34,t33);}
else{
t34=(C_word)C_eqp(((C_word*)t0)[14],lf[355]);
if(C_truep(t34)){
t35=t27;
f_5475(t35,t34);}
else{
t35=(C_word)C_eqp(((C_word*)t0)[14],lf[356]);
t36=t27;
f_5475(t36,(C_truep(t35)?t35:(C_word)C_eqp(((C_word*)t0)[14],lf[357])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}
else{
/* eval.scm: 976  compile */
t3=((C_word*)((C_word*)t0)[12])[1];
f_3912(t3,((C_word*)t0)[13],t1,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}}

/* k5473 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_fcall f_5475(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 965  ##sys#syntax-error-hook */
t2=*((C_word*)lf[73]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[8],lf[346],((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[80]);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* eval.scm: 968  compile-call */
t4=((C_word*)((C_word*)t0)[5])[1];
f_5668(t4,((C_word*)t0)[8],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[347]);
if(C_truep(t3)){
/* eval.scm: 972  ##sys#syntax-error-hook */
t4=*((C_word*)lf[73]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[8],lf[348],((C_word*)t0)[7]);}
else{
/* eval.scm: 974  compile-call */
t4=((C_word*)((C_word*)t0)[5])[1];
f_5668(t4,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}}}

/* k5460 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5462,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[89],t3);
/* eval.scm: 958  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3912(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5422 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5423(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5423,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
/* eval.scm: 953  ##compiler#process-declaration */
t4=*((C_word*)lf[339]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k5410 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 955  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3912(t2,((C_word*)t0)[5],lf[336],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5372 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5366 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 943  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3912(t2,((C_word*)t0)[5],lf[330],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_fcall f_5322(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5322,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[323]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5334,a[2]=t2,a[3]=lf[325],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5344,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=lf[326],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 937  ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}}

/* a5343 in loop in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5344(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5344,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5352,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* eval.scm: 938  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_5322(t6,t4,t5);}

/* k5350 in a5343 in loop in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5352,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[143],((C_word*)t0)[2],t1));}

/* a5333 in loop in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5342,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 937  cadar */
t3=*((C_word*)lf[118]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5340 in a5333 in loop in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 937  ##sys#do-the-right-thing */
t2=*((C_word*)lf[324]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k5314 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 933  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3912(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5291 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5292(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5292,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5299,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 923  ##sys#compile-to-closure */
t4=*((C_word*)lf[208]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k5297 in a5291 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* k5259 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5264,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_apply(4,0,t2,*((C_word*)lf[318]+1),t1);}

/* k5262 in k5259 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5267,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 925  ##sys#lookup-runtime-requirements */
t3=*((C_word*)lf[320]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5265 in k5262 in k5259 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5274,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_nullp(t1))){
t3=t2;
f_5274(t3,lf[317]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5284,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5286,a[2]=lf[319],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}}

/* a5285 in k5265 in k5262 in k5259 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5286(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5286,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[124],t2));}

/* k5282 in k5265 in k5262 in k5259 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5284,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5274(t2,(C_word)C_a_i_cons(&a,2,lf[318],t1));}

/* k5272 in k5265 in k5262 in k5259 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_fcall f_5274(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 926  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3912(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4857 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4859,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[9]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t0)[8];
t9=(C_truep(t8)?t8:lf[281]);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)t4)[1]);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4871,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t7,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[8],a[9]=t10,a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5196,a[2]=t11,a[3]=t7,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 827  ##sys#extended-lambda-list? */
t13=*((C_word*)lf[107]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,((C_word*)t4)[1]);}

/* k5194 in k4857 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5196,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5201,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[312],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5207,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[313],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 828  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_4871(2,t2,C_SCHEME_UNDEFINED);}}

/* a5206 in k5194 in k4857 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5207(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5207,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a5200 in k5194 in k4857 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5201,2,t0,t1);}
/* eval.scm: 830  ##sys#expand-extended-lambda-list */
t2=*((C_word*)lf[115]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[73]+1));}

/* k4869 in k4857 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4876,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=lf[310],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 833  ##sys#decompose-lambda-list */
t3=*((C_word*)lf[311]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* a4875 in k4869 in k4857 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[24],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4876,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4883,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t4,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5179,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t6,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5185,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=lf[309],tmp=(C_word)a,a+=5,tmp);
t9=((C_word*)t0)[6];
t10=(C_truep(t9)?t9:((C_word*)t0)[5]);
/* eval.scm: 839  ##sys#canonicalize-body */
t11=*((C_word*)lf[142]+1);
((C_proc6)(void*)(*((C_word*)t11+1)))(6,t11,t7,((C_word*)((C_word*)t0)[2])[1],t8,((C_word*)t0)[4],t10);}

/* a5184 in a4875 in k4869 in k4857 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5185(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5185,3,t0,t1,t2);}
/* defined?299 */
t3=((C_word*)t0)[3];
f_3729(t3,t1,t2,((C_word*)t0)[2]);}

/* k5177 in a4875 in k4869 in k4857 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[6];
t3=(C_truep(t2)?t2:((C_word*)t0)[5]);
/* eval.scm: 838  ##sys#compile-to-closure */
t4=*((C_word*)lf[208]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k4881 in a4875 in k4869 in k4857 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[98],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4883,2,t0,t1);}
t2=((C_word*)t0)[8];
switch(t2){
case C_fix(0):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=lf[283],tmp=(C_word)a,a+=8,tmp):(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4912,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=lf[285],tmp=(C_word)a,a+=8,tmp)));
case C_fix(1):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4936,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=lf[287],tmp=(C_word)a,a+=8,tmp):(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4955,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=lf[289],tmp=(C_word)a,a+=8,tmp)));
case C_fix(2):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=lf[291],tmp=(C_word)a,a+=8,tmp):(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5002,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=lf[293],tmp=(C_word)a,a+=8,tmp)));
case C_fix(3):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5030,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=lf[295],tmp=(C_word)a,a+=8,tmp):(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=lf[297],tmp=(C_word)a,a+=8,tmp)));
default:
t3=(C_word)C_eqp(t2,C_fix(4));
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5077,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=lf[299],tmp=(C_word)a,a+=8,tmp):(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5096,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=lf[302],tmp=(C_word)a,a+=8,tmp)):(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5118,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=lf[305],tmp=(C_word)a,a+=9,tmp):(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5141,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[8],a[8]=lf[308],tmp=(C_word)a,a+=9,tmp))));}}

/* f_5141 in k4881 in a4875 in k4869 in k4857 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5141(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5141,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5147,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],a[5]=lf[307],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 908  decorate */
f_3906(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5146 */
static void C_ccall f_5147(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5147r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5147r(t0,t1,t2);}}

static void C_ccall f_5147r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(t3,((C_word*)t0)[4]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5171,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t5,*((C_word*)lf[300]+1),t2);}
else{
/* eval.scm: 912  ##sys#error */
t5=*((C_word*)lf[168]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[306],((C_word*)t0)[4],t3);}}

/* k5169 in a5146 */
static void C_ccall f_5171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5171,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5118 in k4881 in a4875 in k4869 in k4857 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5118(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5118,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5124,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=lf[304],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 901  decorate */
f_3906(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5123 */
static void C_ccall f_5124(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr2r,(void*)f_5124r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5124r(t0,t1,t2);}}

static void C_ccall f_5124r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(18);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5136,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5140,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t2))){
t6=t4;
f_5140(2,t6,(C_word)C_a_i_list(&a,1,t2));}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5609,a[2]=t7,a[3]=t2,a[4]=lf[303],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_5609(t9,t4,t5,t2,C_SCHEME_FALSE);}}

/* do589 in a5123 */
static void C_fcall f_5609(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5609,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=(C_word)C_a_i_list(&a,1,t3);
t7=(C_word)C_i_setslot(t4,C_fix(1),t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,((C_word*)t0)[3]);}
else{
t6=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_slot(t3,C_fix(1));
t11=t1;
t12=t6;
t13=t7;
t14=t3;
t1=t11;
t2=t12;
t3=t13;
t4=t14;
goto loop;}}

/* k5138 in a5123 */
static void C_ccall f_5140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[300]+1),t1);}

/* k5134 in a5123 */
static void C_ccall f_5136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5136,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5096 in k4881 in a4875 in k4869 in k4857 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5096(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5096,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5102,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=lf[301],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 894  decorate */
f_3906(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5101 */
static void C_ccall f_5102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5102,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5114,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 896  ##sys#vector */
t7=*((C_word*)lf[300]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k5112 in a5101 */
static void C_ccall f_5114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5114,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5077 in k4881 in a4875 in k4869 in k4857 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5077(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5077,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5083,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=lf[298],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 889  decorate */
f_3906(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5082 */
static void C_ccall f_5083(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr6r,(void*)f_5083r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_5083r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_5083r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(9);
t7=(C_word)C_a_i_vector(&a,5,t2,t3,t4,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t1,t8);}

/* f_5049 in k4881 in a4875 in k4869 in k4857 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5049(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5049,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5055,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=lf[296],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 883  decorate */
f_3906(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5054 */
static void C_ccall f_5055(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5055,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_vector(&a,3,t2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}

/* f_5030 in k4881 in a4875 in k4869 in k4857 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5030(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5030,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5036,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=lf[294],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 878  decorate */
f_3906(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5035 */
static void C_ccall f_5036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_5036r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5036r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5036r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t6=(C_word)C_a_i_vector(&a,4,t2,t3,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[3]);
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t1,t7);}

/* f_5002 in k4881 in a4875 in k4869 in k4857 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_5002(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5002,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5008,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=lf[292],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 872  decorate */
f_3906(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5007 */
static void C_ccall f_5008(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5008,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_vector(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t5);}

/* f_4983 in k4881 in a4875 in k4869 in k4857 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4983(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4983,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4989,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=lf[290],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 867  decorate */
f_3906(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4988 */
static void C_ccall f_4989(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_4989r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4989r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4989r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t5=(C_word)C_a_i_vector(&a,3,t2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}

/* f_4955 in k4881 in a4875 in k4869 in k4857 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4955(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4955,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4961,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=lf[288],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 861  decorate */
f_3906(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4960 */
static void C_ccall f_4961(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4961,3,t0,t1,t2);}
t3=(C_word)C_a_i_vector(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* f_4936 in k4881 in a4875 in k4869 in k4857 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4936(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4936,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4942,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=lf[286],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 856  decorate */
f_3906(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4941 */
static void C_ccall f_4942(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_4942r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4942r(t0,t1,t2,t3);}}

static void C_ccall f_4942r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t4=(C_word)C_a_i_vector(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t5);}

/* f_4912 in k4881 in a4875 in k4869 in k4857 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4912(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4912,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4918,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=lf[284],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 851  decorate */
f_3906(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4917 */
static void C_ccall f_4918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4918,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* f_4893 in k4881 in a4875 in k4869 in k4857 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4893(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4893,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4899,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=lf[282],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 846  decorate */
f_3906(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4898 */
static void C_ccall f_4899(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_4899r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4899r(t0,t1,t2);}}

static void C_ccall f_4899r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(C_word)C_a_i_vector(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4521,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[10]);
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4530,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t3,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4846,a[2]=lf[279],tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a4845 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4846(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4846,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4530,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4536,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[9],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4834,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4840,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=lf[278],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 779  ##sys#canonicalize-body */
t7=*((C_word*)lf[142]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,t5,t6,((C_word*)t0)[4],((C_word*)t0)[7]);}

/* a4839 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4840(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4840,3,t0,t1,t2);}
/* defined?299 */
t3=((C_word*)t0)[3];
f_3729(t3,t1,t2,((C_word*)t0)[2]);}

/* k4832 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 778  ##sys#compile-to-closure */
t2=*((C_word*)lf[208]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4534 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[81],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4536,2,t0,t1);}
switch(((C_word*)t0)[10]){
case C_fix(1):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4545,a[2]=t1,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4566,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 784  cadar */
t4=*((C_word*)lf[118]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);
case C_fix(2):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4579,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4615,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 787  cadar */
t4=*((C_word*)lf[118]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);
case C_fix(3):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4628,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4682,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 791  cadar */
t4=*((C_word*)lf[118]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);
case C_fix(4):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4695,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4764,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 799  cadar */
t4=*((C_word*)lf[118]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);
default:
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4771,a[2]=((C_word*)t0)[10],a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4818,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=lf[277],tmp=(C_word)a,a+=7,tmp);
/* map */
t4=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}}

/* a4817 in k4534 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4818(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4818,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_car(t2);
/* eval.scm: 813  compile */
t5=((C_word*)((C_word*)t0)[5])[1];
f_3912(t5,t1,t3,((C_word*)t0)[4],t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4769 in k4534 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4771,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4772,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=lf[276],tmp=(C_word)a,a+=6,tmp));}

/* f_4772 in k4769 in k4534 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4772(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4772,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4776,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 815  ##sys#make-vector */
t4=*((C_word*)lf[275]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k4774 */
static void C_ccall f_4776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4779,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4788,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=lf[274],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_4788(t6,t2,C_fix(0),((C_word*)t0)[2]);}

/* do471 in k4774 */
static void C_fcall f_4788(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4788,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4813,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}}

/* k4811 in do471 in k4774 */
static void C_ccall f_4813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_4788(t5,((C_word*)t0)[2],t3,t4);}

/* k4777 in k4774 */
static void C_ccall f_4779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4779,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k4762 in k4534 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[7]);
/* eval.scm: 799  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3912(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4693 in k4534 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4695,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4698,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4756,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 800  cadadr */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[10]);}

/* k4754 in k4693 in k4534 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 800  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3912(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4696 in k4693 in k4534 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4698,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4704,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4748,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 802  cadar */
t5=*((C_word*)lf[118]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4746 in k4696 in k4693 in k4534 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_caddr(((C_word*)t0)[7]);
/* eval.scm: 802  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3912(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4702 in k4696 in k4693 in k4534 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4707,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t1,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4740,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 803  cadadr */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4738 in k4702 in k4696 in k4693 in k4534 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadddr(((C_word*)t0)[7]);
/* eval.scm: 803  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3912(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4705 in k4702 in k4696 in k4693 in k4534 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4707,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4708,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=lf[273],tmp=(C_word)a,a+=8,tmp));}

/* f_4708 in k4705 in k4702 in k4696 in k4693 in k4534 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4708(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4708,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4724,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4722 */
static void C_ccall f_4724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4728,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}

/* k4726 in k4722 */
static void C_ccall f_4728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4732,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k4730 in k4726 in k4722 */
static void C_ccall f_4732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4732,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4736,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4734 in k4730 in k4726 in k4722 */
static void C_ccall f_4736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4736,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4680 in k4534 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[7]);
/* eval.scm: 791  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3912(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4626 in k4534 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4631,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4674,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 792  cadadr */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[10]);}

/* k4672 in k4626 in k4534 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 792  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3912(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4629 in k4626 in k4534 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4631,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4637,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4666,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 794  cadar */
t5=*((C_word*)lf[118]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4664 in k4629 in k4626 in k4534 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_caddr(((C_word*)t0)[7]);
/* eval.scm: 794  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3912(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4635 in k4629 in k4626 in k4534 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4637,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4638,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=lf[272],tmp=(C_word)a,a+=7,tmp));}

/* f_4638 in k4635 in k4629 in k4626 in k4534 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4638(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4638,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4654,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4652 */
static void C_ccall f_4654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4658,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k4656 in k4652 */
static void C_ccall f_4658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4662,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4660 in k4656 in k4652 */
static void C_ccall f_4662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4662,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4613 in k4534 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[7]);
/* eval.scm: 787  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3912(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4577 in k4534 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4579,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4582,a[2]=t1,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4607,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 788  cadadr */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4605 in k4577 in k4534 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 788  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3912(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4580 in k4577 in k4534 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4582,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4583,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=lf[271],tmp=(C_word)a,a+=6,tmp));}

/* f_4583 in k4580 in k4577 in k4534 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4583(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4583,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4599,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4597 */
static void C_ccall f_4599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4599,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4603,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4601 in k4597 */
static void C_ccall f_4603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4603,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4564 in k4534 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[7]);
/* eval.scm: 784  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3912(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4543 in k4534 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4545,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4546,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=lf[270],tmp=(C_word)a,a+=5,tmp));}

/* f_4546 in k4543 in k4534 in k4528 in k4519 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4546(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4546,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4562,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4560 */
static void C_ccall f_4562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4562,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,1,t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4410 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4412,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4420,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],a[5]=lf[260],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4426,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=t2,a[8]=lf[268],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a4425 in k4410 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4426(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4426,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4430,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_caddr(((C_word*)t0)[6]);
/* eval.scm: 752  compile */
t6=((C_word*)((C_word*)t0)[5])[1];
f_3912(t6,t4,t5,((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4428 in a4425 in k4410 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4430,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_i_zerop(((C_word*)t0)[5]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4487,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=lf[261],tmp=(C_word)a,a+=5,tmp):(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4500,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=lf[262],tmp=(C_word)a,a+=6,tmp)));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4439,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 754  ##sys#alias-global-hook */
t4=*((C_word*)lf[203]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}}

/* k4437 in k4428 in a4425 in k4410 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4439,2,t0,t1);}
if(C_truep(*((C_word*)lf[190]+1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4445,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 756  ##sys#hash-table-location */
t3=*((C_word*)lf[187]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[190]+1),t1,*((C_word*)lf[191]+1));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4472,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=lf[267],tmp=(C_word)a,a+=5,tmp));}}

/* f_4472 in k4437 in k4428 in a4425 in k4410 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4472(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4472,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4480,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4478 */
static void C_ccall f_4480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* k4443 in k4437 in k4428 in a4425 in k4410 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4448(2,t3,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 760  ##sys#error */
t3=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[266],((C_word*)t0)[2]);}}

/* k4446 in k4443 in k4437 in k4428 in a4425 in k4410 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4448,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4455,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=lf[263],tmp=(C_word)a,a+=5,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4464,a[2]=((C_word*)t0)[2],a[3]=lf[265],tmp=(C_word)a,a+=4,tmp)));}

/* f_4464 in k4446 in k4443 in k4437 in k4428 in a4425 in k4410 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4464(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4464,2,t0,t1);}
/* eval.scm: 763  ##sys#error */
t2=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[264],((C_word*)t0)[2]);}

/* f_4455 in k4446 in k4443 in k4437 in k4428 in a4425 in k4410 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4455(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4455,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4463,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4461 */
static void C_ccall f_4463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* f_4500 in k4428 in a4425 in k4410 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4500(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4500,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4508,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4506 */
static void C_ccall f_4508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot((C_word)C_u_i_list_ref(((C_word*)t0)[4],((C_word*)t0)[3]),((C_word*)t0)[2],t1));}

/* f_4487 in k4428 in a4425 in k4410 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4487(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4487,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4499,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4497 */
static void C_ccall f_4499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* a4419 in k4410 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4420,2,t0,t1);}
/* eval.scm: 751  lookup */
f_3687(t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4302 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4304,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_i_length(t2);
switch(t3){
case C_fix(0):
/* eval.scm: 737  compile */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3912(t4,((C_word*)t0)[5],lf[256],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(1):
t4=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 738  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3912(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(2):
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4341,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 739  compile */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3912(t6,t4,t5,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);
default:
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4363,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 743  compile */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3912(t6,t4,t5,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4361 in k4302 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
/* eval.scm: 744  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3912(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4364 in k4361 in k4302 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4369,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,lf[143],t4);
/* eval.scm: 745  compile */
t6=((C_word*)((C_word*)t0)[5])[1];
f_3912(t6,t2,t5,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4367 in k4364 in k4361 in k4302 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4369,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4370,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=lf[258],tmp=(C_word)a,a+=6,tmp));}

/* f_4370 in k4367 in k4364 in k4361 in k4302 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4370(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4370,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4374,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4372 */
static void C_ccall f_4374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4377,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k4375 in k4372 */
static void C_ccall f_4377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4339 in k4302 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4344,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
/* eval.scm: 740  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3912(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4342 in k4339 in k4302 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4344,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4345,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=lf[257],tmp=(C_word)a,a+=5,tmp));}

/* f_4345 in k4342 in k4339 in k4302 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4345(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4345,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4349,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4347 */
static void C_ccall f_4349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4245 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4250,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
/* eval.scm: 725  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3912(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4248 in k4245 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4253,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[6]);
/* eval.scm: 726  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3912(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4251 in k4248 in k4245 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4256,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdddr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadddr(((C_word*)t0)[6]);
/* eval.scm: 728  compile */
t5=((C_word*)((C_word*)t0)[5])[1];
f_3912(t5,t2,t4,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* eval.scm: 729  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3912(t4,t2,lf[254],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4254 in k4251 in k4248 in k4245 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4256,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4257,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=lf[253],tmp=(C_word)a,a+=6,tmp));}

/* f_4257 in k4254 in k4251 in k4248 in k4245 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4257(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4257,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4264,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4262 */
static void C_ccall f_4264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* f_4237 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4237(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4237,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* f_4203 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4203(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4203,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* k4195 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4197,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4198,a[2]=t1,a[3]=lf[247],tmp=(C_word)a,a+=4,tmp));}

/* f_4198 in k4195 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4198(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4198,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(1)));}

/* k4119 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4121,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
switch(t2){
case C_fix(-1):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4131,a[2]=lf[237],tmp=(C_word)a,a+=3,tmp));
case C_fix(0):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4139,a[2]=lf[238],tmp=(C_word)a,a+=3,tmp));
case C_fix(1):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4147,a[2]=lf[239],tmp=(C_word)a,a+=3,tmp));
case C_fix(2):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4155,a[2]=lf[240],tmp=(C_word)a,a+=3,tmp));
case C_SCHEME_TRUE:
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4163,a[2]=lf[241],tmp=(C_word)a,a+=3,tmp));
case C_SCHEME_FALSE:
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4171,a[2]=lf[242],tmp=(C_word)a,a+=3,tmp));
default:
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4179,a[2]=lf[243],tmp=(C_word)a,a+=3,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4181,a[2]=t2,a[3]=lf[244],tmp=(C_word)a,a+=4,tmp)));}}

/* f_4181 in k4119 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4181(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4181,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_4179 in k4119 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4179(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4179,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}

/* f_4171 in k4119 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4171(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4171,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_4163 in k4119 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4163(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4163,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_4155 in k4119 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4155(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4155,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(2));}

/* f_4147 in k4119 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4147(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4147,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(1));}

/* f_4139 in k4119 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4139(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4139,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* f_4131 in k4119 in k4104 in k4098 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4131(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4131,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(-1));}

/* f_4072 in k4069 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4072(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4072,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_4061 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4061(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4061,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_4059 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4059(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4059,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_4048 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4048(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4048,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_4046 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4046(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4046,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(2));}

/* f_4038 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4038(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4038,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(1));}

/* f_4030 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4030(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4030,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* f_4022 in k4013 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4022(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4022,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(-1));}

/* a3929 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_3930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3930,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep(t4)){
t5=(C_word)C_i_zerop(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3996,a[2]=t3,a[3]=lf[221],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4005,a[2]=t3,a[3]=t2,a[4]=lf[222],tmp=(C_word)a,a+=5,tmp)));}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3940,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 650  ##sys#alias-global-hook */
t6=*((C_word*)lf[203]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}}

/* k3938 in a3929 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_3940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3940,2,t0,t1);}
if(C_truep(*((C_word*)lf[190]+1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3946,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 652  ##sys#hash-table-location */
t3=*((C_word*)lf[187]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[190]+1),t1,C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3969,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3974,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[201]+1))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3989,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 665  ##sys#symbol-has-toplevel-binding? */
t5=*((C_word*)lf[227]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}
else{
t4=t3;
f_3974(t4,C_SCHEME_FALSE);}}}

/* k3987 in k3938 in a3929 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_3989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3974(t2,(C_word)C_i_not(t1));}

/* k3972 in k3938 in a3929 in compile in ##sys#compile-to-closure in k1709 */
static void C_fcall f_3974(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3974,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,*((C_word*)lf[201]+1));
t4=C_mutate((C_word*)lf[201]+1,t3);
t5=((C_word*)t0)[2];
f_3969(t5,t4);}
else{
t2=((C_word*)t0)[2];
f_3969(t2,C_SCHEME_UNDEFINED);}}

/* k3967 in k3938 in a3929 in compile in ##sys#compile-to-closure in k1709 */
static void C_fcall f_3969(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3969,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3970,a[2]=((C_word*)t0)[2],a[3]=lf[226],tmp=(C_word)a,a+=4,tmp));}

/* f_3970 in k3967 in k3938 in a3929 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_3970(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3970,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_retrieve(((C_word*)t0)[2]));}

/* k3944 in k3938 in a3929 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_3946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_3949(2,t3,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 653  ##sys#syntax-error-hook */
t3=*((C_word*)lf[73]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[225],((C_word*)t0)[2]);}}

/* k3947 in k3944 in k3938 in a3929 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_3949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3949,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3950,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[224],tmp=(C_word)a,a+=6,tmp));}

/* f_3950 in k3947 in k3944 in k3938 in a3929 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_3950(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3950,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_eqp(((C_word*)t0)[3],t2);
if(C_truep(t3)){
/* eval.scm: 660  ##sys#error */
t4=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[223],((C_word*)t0)[2]);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* f_4005 in a3929 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_4005(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4005,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot((C_word)C_u_i_list_ref(t2,((C_word*)t0)[3]),((C_word*)t0)[2]));}

/* f_3996 in a3929 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_3996(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3996,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t3,((C_word*)t0)[2]));}

/* a3923 in compile in ##sys#compile-to-closure in k1709 */
static void C_ccall f_3924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3924,2,t0,t1);}
/* eval.scm: 648  lookup */
f_3687(t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* decorate in ##sys#compile-to-closure in k1709 */
static void C_fcall f_3906(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3906,NULL,5,t1,t2,t3,t4,t5);}
/* eval.scm: 644  ##sys#eval-decorator */
t6=*((C_word*)lf[192]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t2,t3,t4,t5);}

/* emit-syntax-trace-info in ##sys#compile-to-closure in k1709 */
static C_word C_fcall f_3900(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_stack_check;
return((C_truep(t1)?(C_word)C_emit_syntax_trace_info(t2,t3,*((C_word*)lf[216]+1)):C_SCHEME_UNDEFINED));}

/* emit-trace-info in ##sys#compile-to-closure in k1709 */
static C_word C_fcall f_3894(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_stack_check;
return((C_truep(t1)?(C_word)C_emit_eval_trace_info(t2,t3,*((C_word*)lf[216]+1)):C_SCHEME_UNDEFINED));}

/* macroexpand-1-checked in ##sys#compile-to-closure in k1709 */
static void C_fcall f_3841(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3841,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3845,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 624  ##sys#macroexpand-1-local */
t5=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_SCHEME_END_OF_LIST);}

/* k3843 in macroexpand-1-checked in ##sys#compile-to-closure in k1709 */
static void C_ccall f_3845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3845,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3860,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,lf[77]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3892,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 627  defined? */
t6=((C_word*)t0)[2];
f_3729(t6,t5,lf[77],((C_word*)t0)[3]);}
else{
t5=t3;
f_3860(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* k3890 in k3843 in macroexpand-1-checked in ##sys#compile-to-closure in k1709 */
static void C_ccall f_3892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3860(t2,(C_word)C_i_not(t1));}

/* k3858 in k3843 in macroexpand-1-checked in ##sys#compile-to-closure in k1709 */
static void C_fcall f_3860(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3860,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3869,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t3;
f_3869(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t3;
f_3869(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* k3867 in k3858 in k3843 in macroexpand-1-checked in ##sys#compile-to-closure in k1709 */
static void C_fcall f_3869(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 630  macroexpand-1-checked */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3841(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* defined? in ##sys#compile-to-closure in k1709 */
static void C_fcall f_3729(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3729,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3735,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=lf[212],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3741,a[2]=lf[213],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a3740 in defined? in ##sys#compile-to-closure in k1709 */
static void C_ccall f_3741(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3741,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* a3734 in defined? in ##sys#compile-to-closure in k1709 */
static void C_ccall f_3735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3735,2,t0,t1);}
/* eval.scm: 599  lookup */
f_3687(t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lookup in ##sys#compile-to-closure in k1709 */
static void C_fcall f_3687(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3687,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3693,a[2]=t5,a[3]=t2,a[4]=lf[210],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3693(t7,t1,t3,C_fix(0));}

/* loop in lookup in ##sys#compile-to-closure in k1709 */
static void C_fcall f_3693(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3693,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* eval.scm: 594  values */
C_values(4,0,t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=((C_word*)t0)[3];
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3811,a[2]=t5,a[3]=lf[209],tmp=(C_word)a,a+=4,tmp);
t7=f_3811(t6,t4,C_fix(0));
if(C_truep(t7)){
/* eval.scm: 595  values */
C_values(4,0,t1,t3,t7);}
else{
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_fixnum_plus(t3,C_fix(1));
/* eval.scm: 596  loop */
t11=t1;
t12=t8;
t13=t9;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}}

/* loop in loop in lookup in ##sys#compile-to-closure in k1709 */
static C_word C_fcall f_3811(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=(C_word)C_slot(t1,C_fix(1));
t6=(C_word)C_fixnum_plus(t2,C_fix(1));
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##sys#alias-global-hook in k1709 */
static void C_ccall f_3678(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3678,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##sys#eval-decorator in k1709 */
static void C_ccall f_3637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3637,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3643,a[2]=lf[193],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3656,a[2]=t3,a[3]=lf[198],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 564  ##sys#decorate-lambda */
t8=*((C_word*)lf[199]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,t2,t6,t7);}

/* a3655 in ##sys#eval-decorator in k1709 */
static void C_ccall f_3656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3656,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3664,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3668,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 571  open-output-string */
t6=*((C_word*)lf[197]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k3666 in a3655 in ##sys#eval-decorator in k1709 */
static void C_ccall f_3668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3671,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 572  write */
t3=*((C_word*)lf[196]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k3669 in k3666 in a3655 in ##sys#eval-decorator in k1709 */
static void C_ccall f_3671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3674,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 573  get-output-string */
t3=*((C_word*)lf[195]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3672 in k3669 in k3666 in a3655 in ##sys#eval-decorator in k1709 */
static void C_ccall f_3674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 570  ##sys#make-lambda-info */
t2=*((C_word*)lf[194]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3662 in a3655 in ##sys#eval-decorator in k1709 */
static void C_ccall f_3664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}

/* a3642 in ##sys#eval-decorator in k1709 */
static void C_ccall f_3643(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3643,3,t0,t1,t2);}
t3=(C_word)C_immp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_lambdainfop(t2)));}

/* ##sys#hash-table-location in k1709 */
static void C_ccall f_3577(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3577,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3581,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_block_size(t2);
/* eval.scm: 544  ##sys#hash-symbol */
t7=*((C_word*)lf[175]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t3,t6);}

/* k3579 in ##sys#hash-table-location in k1709 */
static void C_ccall f_3581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3581,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3589,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=lf[188],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_3589(t6,((C_word*)t0)[2],t2);}

/* loop in k3579 in ##sys#hash-table-location in k1709 */
static void C_fcall f_3589(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3589,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[8])){
t3=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[7],((C_word*)t0)[6],C_SCHEME_TRUE);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
t5=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[7],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 555  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* ##sys#hash-table-for-each in k1709 */
static void C_ccall f_3531(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3531,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3537,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t4,a[6]=lf[184],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_3537(t8,t1,C_fix(0));}

/* do256 in ##sys#hash-table-for-each in k1709 */
static void C_fcall f_3537(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3537,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3547,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3556,a[2]=((C_word*)t0)[3],a[3]=lf[182],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],t2);
/* eval.scm: 536  ##sys#for-each */
t6=*((C_word*)lf[183]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a3555 in do256 in ##sys#hash-table-for-each in k1709 */
static void C_ccall f_3556(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3556,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 537  p */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* k3545 in do256 in ##sys#hash-table-for-each in k1709 */
static void C_ccall f_3547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3537(t3,((C_word*)t0)[2],t2);}

/* ##sys#hash-table-set! in k1709 */
static void C_ccall f_3476(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3476,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3480,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 522  ##sys#hash-symbol */
t6=*((C_word*)lf[175]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,(C_word)C_block_size(t2));}

/* k3478 in ##sys#hash-table-set! in k1709 */
static void C_ccall f_3480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3480,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3488,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=lf[179],tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_3488(t6,((C_word*)t0)[2],t2);}

/* loop in k3478 in ##sys#hash-table-set! in k1709 */
static void C_fcall f_3488(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3488,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t5));}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[7],t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t4,C_fix(1),((C_word*)t0)[6]));}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 530  loop */
t11=t1;
t12=t7;
t1=t11;
t2=t12;
goto loop;}}}

/* ##sys#hash-table-ref in k1709 */
static void C_ccall f_3431(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3431,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3435,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 511  ##sys#hash-symbol */
t5=*((C_word*)lf[175]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,(C_word)C_block_size(t2));}

/* k3433 in ##sys#hash-table-ref in k1709 */
static void C_ccall f_3435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3435,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3444,a[2]=((C_word*)t0)[3],a[3]=lf[177],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_3444(t3,t2));}

/* loop in k3433 in ##sys#hash-table-ref in k1709 */
static C_word C_fcall f_3444(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
return((C_word)C_slot(t3,C_fix(1)));}
else{
t6=(C_word)C_slot(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}}

/* ##sys#hash-symbol in k1709 */
static void C_ccall f_3416(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3416,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(((C_word*)((C_word*)t0)[2])[1],t3));}
else{
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_hash_string(t5);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t8=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_fixnum_modulo(t6,t3));}}

/* ##sys#expand-curried-define in k1709 */
static void C_ccall f_3356(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3356,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3359,a[2]=t7,a[3]=t5,a[4]=lf[173],tmp=(C_word)a,a+=5,tmp));
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3411,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 493  loop */
t10=((C_word*)t7)[1];
f_3359(t10,t9,t2,t3);}

/* k3409 in ##sys#expand-curried-define in k1709 */
static void C_ccall f_3411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3411,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],t1));}

/* loop in ##sys#expand-curried-define in k1709 */
static void C_fcall f_3359(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(15);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3359,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_slot(t2,C_fix(0));
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[126],t8));}
else{
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
t8=(C_word)C_a_i_cons(&a,2,lf[126],t7);
t9=(C_word)C_a_i_list(&a,1,t8);
/* eval.scm: 492  loop */
t15=t1;
t16=t5;
t17=t9;
t1=t15;
t2=t16;
t3=t17;
goto loop;}}

/* ##sys#match-expression in k1709 */
static void C_ccall f_3265(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3265,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3268,a[2]=t8,a[3]=t4,a[4]=t6,a[5]=lf[171],tmp=(C_word)a,a+=6,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3354,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 480  mwalk */
t11=((C_word*)t8)[1];
f_3268(t11,t10,t2,t3);}

/* k3352 in ##sys#match-expression in k1709 */
static void C_ccall f_3354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));}

/* mwalk in ##sys#match-expression in k1709 */
static void C_fcall f_3268(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3268,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_not((C_word)C_blockp(t3));
t5=(C_truep(t4)?t4:(C_word)C_i_not((C_word)C_pairp(t3)));
if(C_truep(t5)){
t6=(C_word)C_i_assq(t3,((C_word*)((C_word*)t0)[4])[1]);
if(C_truep(t6)){
t7=(C_word)C_slot(t6,C_fix(1));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_equalp(t2,t7));}
else{
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[3]))){
t7=(C_word)C_a_i_cons(&a,2,t3,t2);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)((C_word*)t0)[4])[1]);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_TRUE);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_eqp(t2,t3));}}}
else{
t6=(C_word)C_i_not((C_word)C_blockp(t2));
t7=(C_truep(t6)?t6:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3323,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_slot(t2,C_fix(0));
t10=(C_word)C_slot(t3,C_fix(0));
/* eval.scm: 477  mwalk */
t17=t8;
t18=t9;
t19=t10;
t1=t17;
t2=t18;
t3=t19;
goto loop;}}}

/* k3321 in mwalk in ##sys#match-expression in k1709 */
static void C_ccall f_3323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 478  mwalk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3268(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#canonicalize-body in k1709 */
static void C_ccall f_2779(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr4r,(void*)f_2779r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2779r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2779r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(15);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2781,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=lf[165],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3212,a[2]=t5,a[3]=lf[166],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3217,a[2]=t6,a[3]=lf[167],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-me146199 */
t8=t7;
f_3217(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-container147197 */
t10=t6;
f_3212(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body144149 */
t12=t5;
f_2781(t12,t1,t8);}
else{
/* ##sys#error */
t12=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-me146 in ##sys#canonicalize-body in k1709 */
static void C_fcall f_3217(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3217,NULL,2,t0,t1);}
/* def-container147197 */
t2=((C_word*)t0)[2];
f_3212(t2,t1,C_SCHEME_FALSE);}

/* def-container147 in ##sys#canonicalize-body in k1709 */
static void C_fcall f_3212(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3212,NULL,3,t0,t1,t2);}
/* body144149 */
t3=((C_word*)t0)[2];
f_2781(t3,t1,t2);}

/* body144 in ##sys#canonicalize-body in k1709 */
static void C_fcall f_2781(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2781,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2784,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t6,a[5]=lf[153],tmp=(C_word)a,a+=6,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2964,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,a[5]=lf[164],tmp=(C_word)a,a+=6,tmp));
/* eval.scm: 461  expand */
t9=((C_word*)t6)[1];
f_2964(t9,t1,((C_word*)t0)[2]);}

/* expand in body144 in ##sys#canonicalize-body in k1709 */
static void C_fcall f_2964(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2964,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=lf[163],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2970(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in expand in body144 in ##sys#canonicalize-body in k1709 */
static void C_fcall f_2970(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2970,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_slot(t2,C_fix(0));
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_i_pairp(t7);
t10=(C_truep(t9)?(C_word)C_slot(t7,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3004,a[2]=((C_word*)t0)[3],a[3]=t7,a[4]=t8,a[5]=((C_word*)t0)[4],a[6]=t10,a[7]=t2,a[8]=t6,a[9]=t5,a[10]=t4,a[11]=t3,a[12]=t1,a[13]=((C_word*)t0)[5],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_symbolp(t10))){
/* eval.scm: 427  lookup */
t12=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,t10);}
else{
t12=t11;
f_3004(2,t12,C_SCHEME_FALSE);}}
else{
/* eval.scm: 426  fini */
t11=((C_word*)((C_word*)t0)[5])[1];
f_2784(t11,t1,t3,t4,t5,t6,t2);}}
else{
/* eval.scm: 422  fini */
t7=((C_word*)((C_word*)t0)[5])[1];
f_2784(t7,t1,t3,t4,t5,t6,t2);}}

/* k3002 in loop in expand in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_3004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[42],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3004,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 428  fini */
t2=((C_word*)((C_word*)t0)[13])[1];
f_2784(t2,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(lf[144],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3016,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 430  ##sys#check-syntax */
t4=*((C_word*)lf[84]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[144],((C_word*)t0)[3],lf[160],C_SCHEME_FALSE);}
else{
t3=(C_word)C_eqp(lf[145],((C_word*)t0)[6]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3134,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 451  ##sys#check-syntax */
t5=*((C_word*)lf[84]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[145],((C_word*)t0)[3],lf[161],C_SCHEME_FALSE);}
else{
t4=(C_word)C_eqp(lf[143],((C_word*)t0)[6]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3162,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 454  ##sys#check-syntax */
t6=*((C_word*)lf[84]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,lf[143],((C_word*)t0)[3],lf[162],C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3176,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[3],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 457  ##sys#macroexpand-0 */
t6=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}}}}}

/* k3174 in k3002 in loop in expand in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_3176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3176,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[11],t1);
if(C_truep(t2)){
/* eval.scm: 459  fini */
t3=((C_word*)((C_word*)t0)[10])[1];
f_2784(t3,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
/* eval.scm: 460  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2970(t4,((C_word*)t0)[9],t3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* k3160 in k3002 in loop in expand in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_3162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3169,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 455  ##sys#append */
t4=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* k3167 in k3160 in k3002 in loop in expand in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_3169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 455  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2970(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3132 in k3002 in loop in expand in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_3134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3134,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
t4=(C_word)C_i_caddr(((C_word*)t0)[9]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[7]);
/* eval.scm: 452  loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2970(t6,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3,t5);}

/* k3014 in k3002 in loop in expand in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_3016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3016,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3021,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t3,a[9]=lf[159],tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_3021(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2 in k3014 in k3002 in loop in expand in body144 in ##sys#canonicalize-body in k1709 */
static void C_fcall f_3021(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3021,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3068,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 442  ##sys#check-syntax */
t6=*((C_word*)lf[84]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,lf[144],t2,lf[155],C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3086,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 445  ##sys#check-syntax */
t6=*((C_word*)lf[84]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,lf[144],t2,lf[156],C_SCHEME_FALSE);}}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 434  ##sys#check-syntax */
t5=*((C_word*)lf[84]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[144],t2,lf[158],C_SCHEME_FALSE);}}

/* k3032 in loop2 in k3014 in k3002 in loop in expand in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_3034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3034,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(C_word)C_i_cddr(((C_word*)t0)[8]);
t4=(C_word)C_i_pairp(t3);
t5=(C_truep(t4)?(C_word)C_i_caddr(((C_word*)t0)[8]):lf[157]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[7]);
/* eval.scm: 435  loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_2970(t7,((C_word*)t0)[5],((C_word*)t0)[4],t2,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3084 in loop2 in k3014 in k3002 in loop in expand in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_3086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3086,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[10],C_fix(0));
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(C_word)C_slot(((C_word*)t0)[10],C_fix(1));
t5=(C_word)C_i_cddr(((C_word*)t0)[8]);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,lf[126],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)t0)[7]);
/* eval.scm: 446  loop */
t9=((C_word*)((C_word*)t0)[6])[1];
f_2970(t9,((C_word*)t0)[5],((C_word*)t0)[4],t3,t8,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3066 in loop2 in k3014 in k3002 in loop in expand in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_3068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3079,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* eval.scm: 443  ##sys#expand-curried-define */
t4=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k3077 in k3066 in loop2 in k3014 in k3002 in loop in expand in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_3079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3079,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[144],t1);
/* eval.scm: 443  loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3021(t3,((C_word*)t0)[2],t2);}

/* fini in body144 in ##sys#canonicalize-body in k1709 */
static void C_fcall f_2784(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2784,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_nullp(t2);
t8=(C_truep(t7)?(C_word)C_i_nullp(t4):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2796,a[2]=t6,a[3]=t10,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=lf[146],tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_2796(t12,t1,t6,C_SCHEME_END_OF_LIST);}
else{
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2866,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],a[7]=t6,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 406  reverse */
t10=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t2);}}

/* k2864 in fini in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_2866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2877,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2944,a[2]=lf[152],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2956,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,*((C_word*)lf[122]+1),t1,((C_word*)t0)[3]);}

/* k2954 in k2864 in fini in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_2956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 407  ##sys#map */
t2=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2943 in k2864 in fini in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_2944(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2944,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,lf[151]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}

/* k2875 in k2864 in fini in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_2877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2881,a[2]=((C_word*)t0)[9],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2885,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2934,a[2]=lf[150],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2942,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 409  reverse */
t6=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k2940 in k2875 in k2864 in fini in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_2942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 409  map */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2933 in k2875 in k2864 in fini in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_2934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2934,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[91],t2,t3));}

/* k2883 in k2875 in k2864 in fini in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_2885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2889,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2893,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2895,a[2]=((C_word*)t0)[5],a[3]=lf[149],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2928,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 416  reverse */
t6=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k2926 in k2883 in k2875 in k2864 in fini in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_2928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2932,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 417  reverse */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2930 in k2926 in k2883 in k2875 in k2864 in fini in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_2932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 410  map */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2894 in k2883 in k2875 in k2864 in fini in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_2895(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2895,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2899,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 411  ##sys#map */
t5=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[114]+1),t2);}

/* k2897 in a2894 in k2883 in k2875 in k2864 in fini in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_2899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2899,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[126],C_SCHEME_END_OF_LIST,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2918,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2920,a[2]=lf[148],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 415  map */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[2],t1);}

/* a2919 in k2897 in a2894 in k2883 in k2875 in k2864 in fini in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_2920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2920,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[91],t2,t3));}

/* k2916 in k2897 in a2894 in k2883 in k2875 in k2864 in fini in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_2918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2918,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[126],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[147],((C_word*)t0)[2],t3));}

/* k2891 in k2883 in k2875 in k2864 in fini in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_2893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2887 in k2883 in k2875 in k2864 in fini in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_2889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2879 in k2875 in k2864 in fini in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_2881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2881,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[77],t2));}

/* loop in fini in body144 in ##sys#canonicalize-body in k1709 */
static void C_fcall f_2796(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2796,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2815,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_slot(t4,C_fix(0));
t7=(C_word)C_a_i_list(&a,2,lf[144],lf[145]);
t8=t5;
f_2815(t8,(C_word)C_i_memq(t6,t7));}
else{
t6=t5;
f_2815(t6,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[143],((C_word*)t0)[2]));}}

/* k2813 in loop in fini in body144 in ##sys#canonicalize-body in k1709 */
static void C_fcall f_2815(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2815,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2822,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2826,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 404  reverse */
t4=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
/* eval.scm: 405  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2796(t4,((C_word*)t0)[8],t2,t3);}}

/* k2824 in k2813 in loop in fini in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_2826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2834,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 404  expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2964(t3,t2,((C_word*)t0)[2]);}

/* k2832 in k2824 in k2813 in loop in fini in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_2834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2834,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* eval.scm: 404  ##sys#append */
t3=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2820 in k2813 in loop in fini in body144 in ##sys#canonicalize-body in k1709 */
static void C_ccall f_2822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2822,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[143],t1));}

/* ##sys#expand-extended-lambda-list in k1709 */
static void C_ccall f_2260(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[21],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2260,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2263,a[2]=t2,a[3]=t4,a[4]=lf[116],tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2282,a[2]=((C_word*)t0)[2],a[3]=t11,a[4]=t5,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t9,a[8]=t7,a[9]=lf[139],tmp=(C_word)a,a+=10,tmp));
t13=((C_word*)t11)[1];
f_2282(t13,t1,C_fix(0),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t2);}

/* loop in ##sys#expand-extended-lambda-list in k1709 */
static void C_fcall f_2282(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word *a;
loop:
a=C_alloc(85);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2282,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t6))){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2296,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t4,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2505,a[2]=((C_word*)t0)[8],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 322  reverse */
t9=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t3);}
else{
/* eval.scm: 322  reverse */
t8=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}
else{
if(C_truep((C_word)C_i_symbolp(t6))){
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(2)))){
/* eval.scm: 345  err */
t7=((C_word*)t0)[4];
f_2263(t7,t1,lf[129]);}
else{
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2526,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t8=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t8)){
t9=t7;
f_2526(t9,C_SCHEME_UNDEFINED);}
else{
t9=C_mutate(((C_word *)((C_word*)t0)[8])+1,t6);
t10=t7;
f_2526(t10,t9);}}}
else{
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_slot(t6,C_fix(0));
t8=(C_word)C_slot(t6,C_fix(1));
t9=(C_word)C_eqp(t7,lf[109]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2558,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t11=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t11)){
t12=t10;
f_2558(t12,C_SCHEME_UNDEFINED);}
else{
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2577,a[2]=t10,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 357  gensym */
t13=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}}
else{
t10=(C_word)C_eqp(t7,lf[108]);
if(C_truep(t10)){
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(1)))){
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2595,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[7],a[9]=t8,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(t8))){
t12=(C_word)C_slot(t8,C_fix(0));
t13=t11;
f_2595(t13,(C_word)C_i_symbolp(t12));}
else{
t12=t11;
f_2595(t12,C_SCHEME_FALSE);}}
else{
/* eval.scm: 369  err */
t11=((C_word*)t0)[4];
f_2263(t11,t1,lf[132]);}}
else{
t11=(C_word)C_eqp(t7,lf[110]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2641,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t13=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t13)){
t14=t12;
f_2641(t14,C_SCHEME_UNDEFINED);}
else{
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2660,a[2]=t12,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 371  gensym */
t15=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t15))(2,t15,t14);}}
else{
if(C_truep((C_word)C_i_symbolp(t7))){
t12=t2;
switch(t12){
case C_fix(0):
t13=(C_word)C_a_i_cons(&a,2,t7,t3);
/* eval.scm: 378  loop */
t34=t1;
t35=C_fix(0);
t36=t13;
t37=C_SCHEME_END_OF_LIST;
t38=C_SCHEME_END_OF_LIST;
t39=t8;
t1=t34;
t2=t35;
t3=t36;
t4=t37;
t5=t38;
t6=t39;
goto loop;
case C_fix(1):
t13=(C_word)C_a_i_list(&a,2,t7,C_SCHEME_FALSE);
t14=(C_word)C_a_i_cons(&a,2,t13,t4);
/* eval.scm: 379  loop */
t34=t1;
t35=C_fix(1);
t36=t3;
t37=t14;
t38=C_SCHEME_END_OF_LIST;
t39=t8;
t1=t34;
t2=t35;
t3=t36;
t4=t37;
t5=t38;
t6=t39;
goto loop;
case C_fix(2):
/* eval.scm: 380  err */
t13=((C_word*)t0)[4];
f_2263(t13,t1,lf[134]);
default:
t13=(C_word)C_a_i_list(&a,1,t7);
t14=(C_word)C_a_i_cons(&a,2,t13,t5);
/* eval.scm: 381  loop */
t34=t1;
t35=C_fix(3);
t36=t3;
t37=t4;
t38=t14;
t39=t8;
t1=t34;
t2=t35;
t3=t36;
t4=t37;
t5=t38;
t6=t39;
goto loop;}}
else{
t12=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2722,a[2]=t5,a[3]=t8,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=t7,a[8]=t1,a[9]=((C_word*)t0)[4],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t7))){
t13=(C_word)C_i_length(t7);
t14=t12;
f_2722(t14,(C_word)C_eqp(C_fix(2),t13));}
else{
t13=t12;
f_2722(t13,C_SCHEME_FALSE);}}}}}}
else{
/* eval.scm: 351  err */
t7=((C_word*)t0)[4];
f_2263(t7,t1,lf[138]);}}}}

/* k2720 in loop in ##sys#expand-extended-lambda-list in k1709 */
static void C_fcall f_2722(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2722,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
switch(t2){
case C_fix(0):
/* eval.scm: 384  err */
t3=((C_word*)t0)[9];
f_2263(t3,((C_word*)t0)[8],lf[135]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
/* eval.scm: 385  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2282(t4,((C_word*)t0)[8],C_fix(1),((C_word*)t0)[4],t3,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
case C_fix(2):
/* eval.scm: 386  err */
t3=((C_word*)t0)[9];
f_2263(t3,((C_word*)t0)[8],lf[136]);
default:
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[2]);
/* eval.scm: 387  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2282(t4,((C_word*)t0)[8],C_fix(3),((C_word*)t0)[4],((C_word*)t0)[6],t3,((C_word*)t0)[3]);}}
else{
/* eval.scm: 388  err */
t2=((C_word*)t0)[9];
f_2263(t2,((C_word*)t0)[8],lf[137]);}}

/* k2658 in loop in ##sys#expand-extended-lambda-list in k1709 */
static void C_ccall f_2660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2641(t3,t2);}

/* k2639 in loop in ##sys#expand-extended-lambda-list in k1709 */
static void C_fcall f_2641(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[8],C_fix(3)))){
/* eval.scm: 373  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2282(t2,((C_word*)t0)[6],C_fix(3),((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* eval.scm: 374  err */
t2=((C_word*)t0)[2];
f_2263(t2,((C_word*)t0)[6],lf[133]);}}

/* k2593 in loop in ##sys#expand-extended-lambda-list in k1709 */
static void C_fcall f_2595(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2595,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2598,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t3)){
t4=t2;
f_2598(t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_slot(((C_word*)t0)[9],C_fix(0));
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=t2;
f_2598(t6,t5);}}
else{
/* eval.scm: 368  err */
t2=((C_word*)t0)[2];
f_2263(t2,((C_word*)t0)[6],lf[131]);}}

/* k2596 in k2593 in loop in ##sys#expand-extended-lambda-list in k1709 */
static void C_fcall f_2598(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(0));
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* eval.scm: 367  loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_2282(t5,((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t4);}

/* k2575 in loop in ##sys#expand-extended-lambda-list in k1709 */
static void C_ccall f_2577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2558(t3,t2);}

/* k2556 in loop in ##sys#expand-extended-lambda-list in k1709 */
static void C_fcall f_2558(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[7],C_fix(0));
if(C_truep(t2)){
/* eval.scm: 359  loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2282(t3,((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* eval.scm: 360  err */
t3=((C_word*)t0)[2];
f_2263(t3,((C_word*)t0)[5],lf[130]);}}

/* k2524 in loop in ##sys#expand-extended-lambda-list in k1709 */
static void C_fcall f_2526(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
/* eval.scm: 349  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2282(t3,((C_word*)t0)[4],C_fix(4),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k2503 in loop in ##sys#expand-extended-lambda-list in k1709 */
static void C_ccall f_2505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 322  ##sys#append */
t2=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k2294 in loop in ##sys#expand-extended-lambda-list in k1709 */
static void C_ccall f_2296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2300,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t3=t2;
f_2300(t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2439,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2441,a[2]=((C_word*)t0)[6],a[3]=lf[128],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2498,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 333  reverse */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[4]);}}

/* k2496 in k2294 in loop in ##sys#expand-extended-lambda-list in k1709 */
static void C_ccall f_2498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2440 in k2294 in loop in ##sys#expand-extended-lambda-list in k1709 */
static void C_ccall f_2441(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2441,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2494,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
/* eval.scm: 312  string->keyword */
t6=*((C_word*)lf[127]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k2492 in a2440 in k2294 in loop in ##sys#expand-extended-lambda-list in k1709 */
static void C_ccall f_2494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2494,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[124],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2468,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cdr(((C_word*)t0)[2]);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5);
t7=(C_word)C_a_i_cons(&a,2,lf[126],t6);
t8=t3;
f_2468(t8,(C_word)C_a_i_list(&a,1,t7));}
else{
t5=t3;
f_2468(t5,C_SCHEME_END_OF_LIST);}}

/* k2466 in k2492 in a2440 in k2294 in loop in ##sys#expand-extended-lambda-list in k1709 */
static void C_fcall f_2468(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2468,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[125],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t4));}

/* k2437 in k2294 in loop in ##sys#expand-extended-lambda-list in k1709 */
static void C_ccall f_2439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2439,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,lf[123],t2);
t4=((C_word*)t0)[2];
f_2300(t4,(C_word)C_a_i_list(&a,1,t3));}

/* k2298 in k2294 in loop in ##sys#expand-extended-lambda-list in k1709 */
static void C_fcall f_2300(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2300,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2303,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[6]))){
t3=t2;
f_2303(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2312,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t4)){
t5=t3;
f_2312(t5,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[3]))){
t5=(C_word)C_i_cdr(((C_word*)t0)[6]);
t6=t3;
f_2312(t6,(C_word)C_i_nullp(t5));}
else{
t5=t3;
f_2312(t5,C_SCHEME_FALSE);}}}}

/* k2310 in k2298 in k2294 in loop in ##sys#expand-extended-lambda-list in k1709 */
static void C_fcall f_2312(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2312,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2335,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 337  caar */
t3=*((C_word*)lf[119]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_nullp(((C_word*)t0)[3]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2368,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 339  reverse */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2387,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2391,a[2]=t4,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 341  reverse */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[5]);}}}

/* k2389 in k2310 in k2298 in k2294 in loop in ##sys#expand-extended-lambda-list in k1709 */
static void C_ccall f_2391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2391,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_truep(t2)?t2:((C_word*)((C_word*)t0)[3])[1]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* eval.scm: 341  ##sys#append */
t5=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k2385 in k2310 in k2298 in k2294 in loop in ##sys#expand-extended-lambda-list in k1709 */
static void C_ccall f_2387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2387,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[121],t3);
t5=((C_word*)t0)[2];
f_2303(t5,(C_word)C_a_i_list(&a,1,t4));}

/* k2366 in k2310 in k2298 in k2294 in loop in ##sys#expand-extended-lambda-list in k1709 */
static void C_ccall f_2368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2368,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[120],t3);
t5=((C_word*)t0)[2];
f_2303(t5,(C_word)C_a_i_list(&a,1,t4));}

/* k2333 in k2310 in k2298 in k2294 in loop in ##sys#expand-extended-lambda-list in k1709 */
static void C_ccall f_2335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2343,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 337  cadar */
t3=*((C_word*)lf[118]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2341 in k2333 in k2310 in k2298 in k2294 in loop in ##sys#expand-extended-lambda-list in k1709 */
static void C_ccall f_2343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2343,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[117],((C_word*)((C_word*)t0)[5])[1],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=(C_word)C_a_i_cons(&a,2,lf[77],t5);
t7=((C_word*)t0)[2];
f_2303(t7,(C_word)C_a_i_list(&a,1,t6));}

/* k2301 in k2298 in k2294 in loop in ##sys#expand-extended-lambda-list in k1709 */
static void C_fcall f_2303(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 321  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* err in ##sys#expand-extended-lambda-list in k1709 */
static void C_fcall f_2263(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2263,NULL,3,t0,t1,t2);}
/* eval.scm: 311  errh */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#extended-lambda-list? in k1709 */
static void C_ccall f_2217(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2217,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2223,a[2]=t4,a[3]=lf[111],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_2223(t6,t1,t2);}

/* loop in ##sys#extended-lambda-list? in k1709 */
static void C_fcall f_2223(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2223,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(t3,lf[108]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2242,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_2242(t6,t4);}
else{
t6=(C_word)C_eqp(t3,lf[109]);
t7=t5;
f_2242(t7,(C_truep(t6)?t6:(C_word)C_eqp(t3,lf[110])));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2240 in loop in ##sys#extended-lambda-list? in k1709 */
static void C_fcall f_2242(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 305  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2223(t3,((C_word*)t0)[4],t2);}}

/* macroexpand-1 in k1709 */
static void C_ccall f_2201(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2201r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2201r(t0,t1,t2,t3);}}

static void C_ccall f_2201r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_END_OF_LIST);
/* eval.scm: 285  ##sys#macroexpand-0 */
t6=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t2,t5);}

/* macroexpand in k1709 */
static void C_ccall f_2165(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2165r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2165r(t0,t1,t2,t3);}}

static void C_ccall f_2165r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(7);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_END_OF_LIST);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2174,a[2]=t7,a[3]=t5,a[4]=lf[103],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_2174(t9,t1,t2);}

/* loop in macroexpand in k1709 */
static void C_fcall f_2174(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2174,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2180,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=lf[101],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2186,a[2]=((C_word*)t0)[2],a[3]=lf[102],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a2185 in loop in macroexpand in k1709 */
static void C_ccall f_2186(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2186,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* eval.scm: 281  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2174(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* a2179 in loop in macroexpand in k1709 */
static void C_ccall f_2180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2180,2,t0,t1);}
/* eval.scm: 279  ##sys#macroexpand-0 */
t2=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#macroexpand-1-local in k1709 */
static void C_ccall f_2158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2158,4,t0,t1,t2,t3);}
/* eval.scm: 266  ##sys#macroexpand-0 */
t4=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,t3);}

/* ##sys#interpreter-toplevel-macroexpand-hook in k1709 */
static void C_ccall f_2155(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2155,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##sys#compiler-toplevel-macroexpand-hook in k1709 */
static void C_ccall f_2152(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2152,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##sys#macroexpand-0 in k1709 */
static void C_ccall f_1782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1782,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1785,a[2]=((C_word*)t0)[2],a[3]=lf[72],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1931,a[2]=t4,a[3]=t3,a[4]=lf[76],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_slot(t2,C_fix(0));
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_symbolp(t6))){
t8=(C_word)C_eqp(t6,lf[77]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2019,a[2]=t2,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 235  ##sys#check-syntax */
t10=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,lf[77],t7,lf[86]);}
else{
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2092,a[2]=t6,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_truep((C_word)C_eqp(t6,lf[89]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t6,lf[91]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
if(C_truep((C_word)C_i_pairp(t7))){
t10=(C_word)C_slot(t7,C_fix(0));
t11=t9;
f_2092(t11,(C_word)C_i_pairp(t10));}
else{
t10=t9;
f_2092(t10,C_SCHEME_FALSE);}}
else{
t10=t9;
f_2092(t10,C_SCHEME_FALSE);}}}
else{
/* eval.scm: 258  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}
else{
/* eval.scm: 259  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}

/* k2090 in ##sys#macroexpand-0 in k1709 */
static void C_fcall f_2092(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2092,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2098,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 251  ##sys#check-syntax */
t4=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[89],((C_word*)t0)[6],lf[90]);}
else{
/* eval.scm: 257  expand */
t2=((C_word*)t0)[4];
f_1931(t2,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2096 in k2090 in ##sys#macroexpand-0 in k1709 */
static void C_ccall f_2098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2105,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t4=(C_word)C_a_i_list(&a,2,lf[87],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t7=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* eval.scm: 253  append */
t8=*((C_word*)lf[88]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t2,t5,t6,t7);}

/* k2103 in k2096 in k2090 in ##sys#macroexpand-0 in k1709 */
static void C_ccall f_2105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 252  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k2017 in ##sys#macroexpand-0 in k1709 */
static void C_ccall f_2019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2019,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2031,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 238  ##sys#check-syntax */
t4=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[77],((C_word*)t0)[4],lf[85]);}
else{
/* eval.scm: 246  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k2029 in k2017 in ##sys#macroexpand-0 in k1709 */
static void C_ccall f_2031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2031,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2073,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2079,a[2]=lf[83],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a2078 in k2029 in k2017 in ##sys#macroexpand-0 in k1709 */
static void C_ccall f_2079(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2079,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k2071 in k2029 in k2017 in ##sys#macroexpand-0 in k1709 */
static void C_ccall f_2073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2073,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[78],t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_list(&a,3,lf[79],t6,((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2053,a[2]=((C_word*)t0)[3],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 244  ##sys#map */
t9=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,*((C_word*)lf[82]+1),((C_word*)t0)[2]);}

/* k2051 in k2071 in k2029 in k2017 in ##sys#macroexpand-0 in k1709 */
static void C_ccall f_2053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2053,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[80],t2);
/* eval.scm: 240  values */
C_values(4,0,((C_word*)t0)[2],t3,C_SCHEME_TRUE);}

/* expand in ##sys#macroexpand-0 in k1709 */
static void C_fcall f_1931(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1931,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t3,((C_word*)t0)[3]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1945,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_slot(t4,C_fix(1));
t7=t6;
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1951,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 219  ##sys#hash-table-ref */
t6=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[38]+1),t3);}}

/* k1949 in expand in ##sys#macroexpand-0 in k1709 */
static void C_ccall f_1951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1951,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1959,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=lf[75],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_1959(t5,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
/* eval.scm: 228  values */
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[3],C_SCHEME_FALSE);}}

/* scan in k1949 in expand in ##sys#macroexpand-0 in k1709 */
static void C_fcall f_1959(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1959,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1973,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 225  call-handler */
t4=((C_word*)t0)[6];
f_1785(t4,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 226  scan */
t6=t1;
t7=t3;
t1=t6;
t2=t7;
goto loop;}
else{
/* eval.scm: 227  ##sys#syntax-error-hook */
t3=*((C_word*)lf[73]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[74],((C_word*)t0)[3]);}}}

/* k1971 in scan in k1949 in expand in ##sys#macroexpand-0 in k1709 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 225  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k1943 in expand in ##sys#macroexpand-0 in k1709 */
static void C_ccall f_1945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 218  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* call-handler in ##sys#macroexpand-0 in k1709 */
static void C_fcall f_1785(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1785,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1792,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1794,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=lf[70],tmp=(C_word)a,a+=7,tmp);
/* call-with-current-continuation */
t7=*((C_word*)lf[71]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* a1793 in call-handler in ##sys#macroexpand-0 in k1709 */
static void C_ccall f_1794(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1794,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1800,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=lf[64],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1907,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=lf[68],tmp=(C_word)a,a+=6,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a1906 in a1793 in call-handler in ##sys#macroexpand-0 in k1709 */
static void C_ccall f_1907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1913,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[65],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1919,a[2]=((C_word*)t0)[2],a[3]=lf[67],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1918 in a1906 in a1793 in call-handler in ##sys#macroexpand-0 in k1709 */
static void C_ccall f_1919(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1919r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1919r(t0,t1,t2);}}

static void C_ccall f_1919r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1925,a[2]=t2,a[3]=lf[66],tmp=(C_word)a,a+=4,tmp);
/* g3739 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1924 in a1918 in a1906 in a1793 in call-handler in ##sys#macroexpand-0 in k1709 */
static void C_ccall f_1925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1925,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1912 in a1906 in a1793 in call-handler in ##sys#macroexpand-0 in k1709 */
static void C_ccall f_1913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1913,2,t0,t1);}
/* eval.scm: 215  handler */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* a1799 in a1793 in call-handler in ##sys#macroexpand-0 in k1709 */
static void C_ccall f_1800(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1800,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1806,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=lf[63],tmp=(C_word)a,a+=6,tmp);
/* g3739 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1805 in a1799 in a1793 in call-handler in ##sys#macroexpand-0 in k1709 */
static void C_ccall f_1806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1814,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1817,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[4],lf[56]))){
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=t3;
f_1817(t5,(C_word)C_i_memv(lf[62],t4));}
else{
t4=t3;
f_1817(t4,C_SCHEME_FALSE);}}

/* k1815 in a1805 in a1799 in a1793 in call-handler in ##sys#macroexpand-0 in k1709 */
static void C_fcall f_1817(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1817,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1828,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1834,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=lf[61],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_1834(t8,t3,t4);}
else{
t2=((C_word*)t0)[4];
f_1814(t2,((C_word*)t0)[5]);}}

/* copy in k1815 in a1805 in a1799 in a1793 in call-handler in ##sys#macroexpand-0 in k1709 */
static void C_fcall f_1834(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1834,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_equalp(lf[60],t3))){
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_i_car(t4);
t7=t5;
f_1853(t7,(C_word)C_i_stringp(t6));}
else{
t6=t5;
f_1853(t6,C_SCHEME_FALSE);}}
else{
t6=t5;
f_1853(t6,C_SCHEME_FALSE);}}}

/* k1851 in copy in k1815 in a1805 in a1799 in a1793 in call-handler in ##sys#macroexpand-0 in k1709 */
static void C_fcall f_1853(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1853,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1864,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_i_car(((C_word*)t0)[6]);
/* eval.scm: 209  string-append */
t5=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,lf[58],t3,lf[59],t4);}
else{
/* eval.scm: 213  copy */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1834(t2,((C_word*)t0)[5],((C_word*)t0)[6]);}}

/* k1862 in k1851 in copy in k1815 in a1805 in a1799 in a1793 in call-handler in ##sys#macroexpand-0 in k1709 */
static void C_ccall f_1864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1864,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[57],t3));}

/* k1826 in k1815 in a1805 in a1799 in a1793 in call-handler in ##sys#macroexpand-0 in k1709 */
static void C_ccall f_1828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1828,2,t0,t1);}
t2=((C_word*)t0)[3];
f_1814(t2,(C_word)C_a_i_record(&a,3,lf[56],((C_word*)t0)[2],t1));}

/* k1812 in a1805 in a1799 in a1793 in call-handler in ##sys#macroexpand-0 in k1709 */
static void C_fcall f_1814(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 193  ##sys#abort */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1790 in call-handler in ##sys#macroexpand-0 in k1709 */
static void C_ccall f_1792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* undefine-macro! in k1709 */
static void C_ccall f_1773(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1773,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[51]);
t4=t2;
/* eval.scm: 178  ##sys#hash-table-set! */
t5=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[38]+1),t4,C_SCHEME_FALSE);}

/* macro? in k1709 */
static void C_ccall f_1755(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1755,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[49]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1765,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 175  ##sys#hash-table-ref */
t5=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[38]+1),t2);}

/* k1763 in macro? in k1709 */
static void C_ccall f_1765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* ##sys#copy-macro in k1709 */
static void C_ccall f_1745(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1745,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1753,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 171  ##sys#hash-table-ref */
t5=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[38]+1),t2);}

/* k1751 in ##sys#copy-macro in k1709 */
static void C_ccall f_1753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 171  ##sys#hash-table-set! */
t2=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[38]+1),((C_word*)t0)[2],t1);}

/* ##sys#register-macro in k1709 */
static void C_ccall f_1729(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1729,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1735,a[2]=t3,a[3]=lf[44],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 166  ##sys#hash-table-set! */
t5=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[38]+1),t2,t4);}

/* a1734 in ##sys#register-macro in k1709 */
static void C_ccall f_1735(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1735,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
C_apply(4,0,t1,((C_word*)t0)[2],t3);}

/* ##sys#register-macro-2 in k1709 */
static void C_ccall f_1713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1713,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1719,a[2]=t3,a[3]=lf[40],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 160  ##sys#hash-table-set! */
t5=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[38]+1),t2,t4);}

/* a1718 in ##sys#register-macro-2 in k1709 */
static void C_ccall f_1719(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1719,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 162  handler */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* chicken-home */
static void C_ccall f_1672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1676,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 146  getenv */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[36]);}

/* k1674 in chicken-home */
static void C_ccall f_1676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1679,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=(C_word)C_block_size(t1);
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(C_word)C_i_string_ref(t1,t4);
t6=(C_word)C_i_memq(t5,lf[32]);
t7=(C_truep(t6)?lf[33]:lf[34]);
/* eval.scm: 147  ##sys#string-append */
t8=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t2,t1,t7);}
else{
t3=t2;
f_1679(2,t3,C_SCHEME_FALSE);}}

/* k1677 in k1674 in chicken-home */
static void C_ccall f_1679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1679,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* ##sys#peek-c-string */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[930] = {
{"topleveleval.scm",(void*)C_eval_toplevel},
{"f_1711eval.scm",(void*)f_1711},
{"f_11074eval.scm",(void*)f_11074},
{"f_11078eval.scm",(void*)f_11078},
{"f_11102eval.scm",(void*)f_11102},
{"f_11096eval.scm",(void*)f_11096},
{"f_11086eval.scm",(void*)f_11086},
{"f_11084eval.scm",(void*)f_11084},
{"f_5927eval.scm",(void*)f_5927},
{"f_6026eval.scm",(void*)f_6026},
{"f_6106eval.scm",(void*)f_6106},
{"f_11068eval.scm",(void*)f_11068},
{"f_11064eval.scm",(void*)f_11064},
{"f_11060eval.scm",(void*)f_11060},
{"f_11056eval.scm",(void*)f_11056},
{"f_11046eval.scm",(void*)f_11046},
{"f_6642eval.scm",(void*)f_6642},
{"f_6647eval.scm",(void*)f_6647},
{"f_11024eval.scm",(void*)f_11024},
{"f_11016eval.scm",(void*)f_11016},
{"f_11018eval.scm",(void*)f_11018},
{"f_6654eval.scm",(void*)f_6654},
{"f_11006eval.scm",(void*)f_11006},
{"f_11009eval.scm",(void*)f_11009},
{"f_7007eval.scm",(void*)f_7007},
{"f_10952eval.scm",(void*)f_10952},
{"f_10966eval.scm",(void*)f_10966},
{"f_11002eval.scm",(void*)f_11002},
{"f_10998eval.scm",(void*)f_10998},
{"f_10986eval.scm",(void*)f_10986},
{"f_10990eval.scm",(void*)f_10990},
{"f_10960eval.scm",(void*)f_10960},
{"f_7733eval.scm",(void*)f_7733},
{"f_10831eval.scm",(void*)f_10831},
{"f_10868eval.scm",(void*)f_10868},
{"f_10877eval.scm",(void*)f_10877},
{"f_10896eval.scm",(void*)f_10896},
{"f_10900eval.scm",(void*)f_10900},
{"f_10886eval.scm",(void*)f_10886},
{"f_10883eval.scm",(void*)f_10883},
{"f_10834eval.scm",(void*)f_10834},
{"f_7736eval.scm",(void*)f_7736},
{"f_7794eval.scm",(void*)f_7794},
{"f_10829eval.scm",(void*)f_10829},
{"f_8129eval.scm",(void*)f_8129},
{"f_8133eval.scm",(void*)f_8133},
{"f_10825eval.scm",(void*)f_10825},
{"f_8136eval.scm",(void*)f_8136},
{"f_8140eval.scm",(void*)f_8140},
{"f_10728eval.scm",(void*)f_10728},
{"f_10734eval.scm",(void*)f_10734},
{"f_10750eval.scm",(void*)f_10750},
{"f_10753eval.scm",(void*)f_10753},
{"f_10788eval.scm",(void*)f_10788},
{"f_10791eval.scm",(void*)f_10791},
{"f_10775eval.scm",(void*)f_10775},
{"f_10778eval.scm",(void*)f_10778},
{"f_10785eval.scm",(void*)f_10785},
{"f_8830eval.scm",(void*)f_8830},
{"f_10700eval.scm",(void*)f_10700},
{"f_8833eval.scm",(void*)f_8833},
{"f_10657eval.scm",(void*)f_10657},
{"f_10679eval.scm",(void*)f_10679},
{"f_8836eval.scm",(void*)f_8836},
{"f_10460eval.scm",(void*)f_10460},
{"f_10466eval.scm",(void*)f_10466},
{"f_10482eval.scm",(void*)f_10482},
{"f_10558eval.scm",(void*)f_10558},
{"f_10615eval.scm",(void*)f_10615},
{"f_10561eval.scm",(void*)f_10561},
{"f_10588eval.scm",(void*)f_10588},
{"f_10521eval.scm",(void*)f_10521},
{"f_10540eval.scm",(void*)f_10540},
{"f_10512eval.scm",(void*)f_10512},
{"f_8839eval.scm",(void*)f_8839},
{"f_10357eval.scm",(void*)f_10357},
{"f_10367eval.scm",(void*)f_10367},
{"f_10380eval.scm",(void*)f_10380},
{"f_10396eval.scm",(void*)f_10396},
{"f_10434eval.scm",(void*)f_10434},
{"f_10432eval.scm",(void*)f_10432},
{"f_10424eval.scm",(void*)f_10424},
{"f_10378eval.scm",(void*)f_10378},
{"f_8842eval.scm",(void*)f_8842},
{"f_10304eval.scm",(void*)f_10304},
{"f_10314eval.scm",(void*)f_10314},
{"f_10317eval.scm",(void*)f_10317},
{"f_10322eval.scm",(void*)f_10322},
{"f_10347eval.scm",(void*)f_10347},
{"f_8845eval.scm",(void*)f_8845},
{"f_10234eval.scm",(void*)f_10234},
{"f_10244eval.scm",(void*)f_10244},
{"f_10247eval.scm",(void*)f_10247},
{"f_10294eval.scm",(void*)f_10294},
{"f_10258eval.scm",(void*)f_10258},
{"f_10280eval.scm",(void*)f_10280},
{"f_10266eval.scm",(void*)f_10266},
{"f_10262eval.scm",(void*)f_10262},
{"f_8848eval.scm",(void*)f_8848},
{"f_10115eval.scm",(void*)f_10115},
{"f_10119eval.scm",(void*)f_10119},
{"f_10122eval.scm",(void*)f_10122},
{"f_10125eval.scm",(void*)f_10125},
{"f_10216eval.scm",(void*)f_10216},
{"f_10132eval.scm",(void*)f_10132},
{"f_10155eval.scm",(void*)f_10155},
{"f_10169eval.scm",(void*)f_10169},
{"f_10167eval.scm",(void*)f_10167},
{"f_8851eval.scm",(void*)f_8851},
{"f_9823eval.scm",(void*)f_9823},
{"f_10033eval.scm",(void*)f_10033},
{"f_10037eval.scm",(void*)f_10037},
{"f_10058eval.scm",(void*)f_10058},
{"f_10100eval.scm",(void*)f_10100},
{"f_9836eval.scm",(void*)f_9836},
{"f_10024eval.scm",(void*)f_10024},
{"f_10028eval.scm",(void*)f_10028},
{"f_10007eval.scm",(void*)f_10007},
{"f_10011eval.scm",(void*)f_10011},
{"f_9996eval.scm",(void*)f_9996},
{"f_9988eval.scm",(void*)f_9988},
{"f_9977eval.scm",(void*)f_9977},
{"f_9943eval.scm",(void*)f_9943},
{"f_9924eval.scm",(void*)f_9924},
{"f_9897eval.scm",(void*)f_9897},
{"f_9854eval.scm",(void*)f_9854},
{"f_9850eval.scm",(void*)f_9850},
{"f_9826eval.scm",(void*)f_9826},
{"f_9834eval.scm",(void*)f_9834},
{"f_8854eval.scm",(void*)f_8854},
{"f_9813eval.scm",(void*)f_9813},
{"f_8857eval.scm",(void*)f_8857},
{"f_8861eval.scm",(void*)f_8861},
{"f_9810eval.scm",(void*)f_9810},
{"f_8883eval.scm",(void*)f_8883},
{"f_9243eval.scm",(void*)f_9243},
{"f_9668eval.scm",(void*)f_9668},
{"f_9786eval.scm",(void*)f_9786},
{"f_9789eval.scm",(void*)f_9789},
{"f_9776eval.scm",(void*)f_9776},
{"f_9671eval.scm",(void*)f_9671},
{"f_9675eval.scm",(void*)f_9675},
{"f_9686eval.scm",(void*)f_9686},
{"f_9329eval.scm",(void*)f_9329},
{"f_9649eval.scm",(void*)f_9649},
{"f_9653eval.scm",(void*)f_9653},
{"f_9662eval.scm",(void*)f_9662},
{"f_9660eval.scm",(void*)f_9660},
{"f_9332eval.scm",(void*)f_9332},
{"f_9643eval.scm",(void*)f_9643},
{"f_9335eval.scm",(void*)f_9335},
{"f_9637eval.scm",(void*)f_9637},
{"f_9338eval.scm",(void*)f_9338},
{"f_9628eval.scm",(void*)f_9628},
{"f_9635eval.scm",(void*)f_9635},
{"f_9618eval.scm",(void*)f_9618},
{"f_9603eval.scm",(void*)f_9603},
{"f_9607eval.scm",(void*)f_9607},
{"f_9612eval.scm",(void*)f_9612},
{"f_9616eval.scm",(void*)f_9616},
{"f_9581eval.scm",(void*)f_9581},
{"f_9585eval.scm",(void*)f_9585},
{"f_9590eval.scm",(void*)f_9590},
{"f_9594eval.scm",(void*)f_9594},
{"f_9601eval.scm",(void*)f_9601},
{"f_9555eval.scm",(void*)f_9555},
{"f_9561eval.scm",(void*)f_9561},
{"f_9565eval.scm",(void*)f_9565},
{"f_9579eval.scm",(void*)f_9579},
{"f_9568eval.scm",(void*)f_9568},
{"f_9575eval.scm",(void*)f_9575},
{"f_9539eval.scm",(void*)f_9539},
{"f_9545eval.scm",(void*)f_9545},
{"f_9553eval.scm",(void*)f_9553},
{"f_9502eval.scm",(void*)f_9502},
{"f_9506eval.scm",(void*)f_9506},
{"f_9511eval.scm",(void*)f_9511},
{"f_9515eval.scm",(void*)f_9515},
{"f_9537eval.scm",(void*)f_9537},
{"f_9533eval.scm",(void*)f_9533},
{"f_9529eval.scm",(void*)f_9529},
{"f_9518eval.scm",(void*)f_9518},
{"f_9525eval.scm",(void*)f_9525},
{"f_9476eval.scm",(void*)f_9476},
{"f_9482eval.scm",(void*)f_9482},
{"f_9486eval.scm",(void*)f_9486},
{"f_9500eval.scm",(void*)f_9500},
{"f_9489eval.scm",(void*)f_9489},
{"f_9496eval.scm",(void*)f_9496},
{"f_9463eval.scm",(void*)f_9463},
{"f_9437eval.scm",(void*)f_9437},
{"f_9441eval.scm",(void*)f_9441},
{"f_9446eval.scm",(void*)f_9446},
{"f_9450eval.scm",(void*)f_9450},
{"f_9461eval.scm",(void*)f_9461},
{"f_9457eval.scm",(void*)f_9457},
{"f_9421eval.scm",(void*)f_9421},
{"f_9427eval.scm",(void*)f_9427},
{"f_9435eval.scm",(void*)f_9435},
{"f_9409eval.scm",(void*)f_9409},
{"f_9415eval.scm",(void*)f_9415},
{"f_9419eval.scm",(void*)f_9419},
{"f_9400eval.scm",(void*)f_9400},
{"f_9404eval.scm",(void*)f_9404},
{"f_9341eval.scm",(void*)f_9341},
{"f_9351eval.scm",(void*)f_9351},
{"f_9376eval.scm",(void*)f_9376},
{"f_9388eval.scm",(void*)f_9388},
{"f_9394eval.scm",(void*)f_9394},
{"f_9382eval.scm",(void*)f_9382},
{"f_9357eval.scm",(void*)f_9357},
{"f_9363eval.scm",(void*)f_9363},
{"f_9367eval.scm",(void*)f_9367},
{"f_9370eval.scm",(void*)f_9370},
{"f_9374eval.scm",(void*)f_9374},
{"f_9349eval.scm",(void*)f_9349},
{"f_9254eval.scm",(void*)f_9254},
{"f_9264eval.scm",(void*)f_9264},
{"f_9267eval.scm",(void*)f_9267},
{"f_9281eval.scm",(void*)f_9281},
{"f_9299eval.scm",(void*)f_9299},
{"f_9268eval.scm",(void*)f_9268},
{"f_9245eval.scm",(void*)f_9245},
{"f_8904eval.scm",(void*)f_8904},
{"f_8948eval.scm",(void*)f_8948},
{"f_8951eval.scm",(void*)f_8951},
{"f_9228eval.scm",(void*)f_9228},
{"f_9232eval.scm",(void*)f_9232},
{"f_9236eval.scm",(void*)f_9236},
{"f_9033eval.scm",(void*)f_9033},
{"f_9039eval.scm",(void*)f_9039},
{"f_9211eval.scm",(void*)f_9211},
{"f_9217eval.scm",(void*)f_9217},
{"f_9046eval.scm",(void*)f_9046},
{"f_9049eval.scm",(void*)f_9049},
{"f_9052eval.scm",(void*)f_9052},
{"f_9206eval.scm",(void*)f_9206},
{"f_9061eval.scm",(void*)f_9061},
{"f_9064eval.scm",(void*)f_9064},
{"f_9079eval.scm",(void*)f_9079},
{"f_9097eval.scm",(void*)f_9097},
{"f_9193eval.scm",(void*)f_9193},
{"f_9189eval.scm",(void*)f_9189},
{"f_9160eval.scm",(void*)f_9160},
{"f_9113eval.scm",(void*)f_9113},
{"f_9118eval.scm",(void*)f_9118},
{"f_9122eval.scm",(void*)f_9122},
{"f_9125eval.scm",(void*)f_9125},
{"f_9137eval.scm",(void*)f_9137},
{"f_9140eval.scm",(void*)f_9140},
{"f_9128eval.scm",(void*)f_9128},
{"f_9101eval.scm",(void*)f_9101},
{"f_9083eval.scm",(void*)f_9083},
{"f_8929eval.scm",(void*)f_8929},
{"f_8934eval.scm",(void*)f_8934},
{"f_9086eval.scm",(void*)f_9086},
{"f_9070eval.scm",(void*)f_9070},
{"f_8968eval.scm",(void*)f_8968},
{"f_8973eval.scm",(void*)f_8973},
{"f_8976eval.scm",(void*)f_8976},
{"f_8981eval.scm",(void*)f_8981},
{"f_8988eval.scm",(void*)f_8988},
{"f_9028eval.scm",(void*)f_9028},
{"f_8991eval.scm",(void*)f_8991},
{"f_9003eval.scm",(void*)f_9003},
{"f_9012eval.scm",(void*)f_9012},
{"f_9006eval.scm",(void*)f_9006},
{"f_8994eval.scm",(void*)f_8994},
{"f_8997eval.scm",(void*)f_8997},
{"f_8959eval.scm",(void*)f_8959},
{"f_8953eval.scm",(void*)f_8953},
{"f_8907eval.scm",(void*)f_8907},
{"f_8913eval.scm",(void*)f_8913},
{"f_8901eval.scm",(void*)f_8901},
{"f_8885eval.scm",(void*)f_8885},
{"f_8899eval.scm",(void*)f_8899},
{"f_8896eval.scm",(void*)f_8896},
{"f_8889eval.scm",(void*)f_8889},
{"f_8866eval.scm",(void*)f_8866},
{"f_8875eval.scm",(void*)f_8875},
{"f_8870eval.scm",(void*)f_8870},
{"f_8438eval.scm",(void*)f_8438},
{"f_8575eval.scm",(void*)f_8575},
{"f_8580eval.scm",(void*)f_8580},
{"f_8798eval.scm",(void*)f_8798},
{"f_8779eval.scm",(void*)f_8779},
{"f_8725eval.scm",(void*)f_8725},
{"f_8596eval.scm",(void*)f_8596},
{"f_8601eval.scm",(void*)f_8601},
{"f_8620eval.scm",(void*)f_8620},
{"f_8546eval.scm",(void*)f_8546},
{"f_8552eval.scm",(void*)f_8552},
{"f_8484eval.scm",(void*)f_8484},
{"f_8488eval.scm",(void*)f_8488},
{"f_8496eval.scm",(void*)f_8496},
{"f_8519eval.scm",(void*)f_8519},
{"f_8441eval.scm",(void*)f_8441},
{"f_8448eval.scm",(void*)f_8448},
{"f_8453eval.scm",(void*)f_8453},
{"f_8457eval.scm",(void*)f_8457},
{"f_8482eval.scm",(void*)f_8482},
{"f_8471eval.scm",(void*)f_8471},
{"f_8475eval.scm",(void*)f_8475},
{"f_8464eval.scm",(void*)f_8464},
{"f_8402eval.scm",(void*)f_8402},
{"f_8424eval.scm",(void*)f_8424},
{"f_8394eval.scm",(void*)f_8394},
{"f_8340eval.scm",(void*)f_8340},
{"f_8344eval.scm",(void*)f_8344},
{"f_8347eval.scm",(void*)f_8347},
{"f_8350eval.scm",(void*)f_8350},
{"f_8353eval.scm",(void*)f_8353},
{"f_8356eval.scm",(void*)f_8356},
{"f_8359eval.scm",(void*)f_8359},
{"f_8362eval.scm",(void*)f_8362},
{"f_8365eval.scm",(void*)f_8365},
{"f_8368eval.scm",(void*)f_8368},
{"f_8319eval.scm",(void*)f_8319},
{"f_8323eval.scm",(void*)f_8323},
{"f_8326eval.scm",(void*)f_8326},
{"f_8295eval.scm",(void*)f_8295},
{"f_8301eval.scm",(void*)f_8301},
{"f_8311eval.scm",(void*)f_8311},
{"f_8165eval.scm",(void*)f_8165},
{"f_8169eval.scm",(void*)f_8169},
{"f_8223eval.scm",(void*)f_8223},
{"f_8274eval.scm",(void*)f_8274},
{"f_8233eval.scm",(void*)f_8233},
{"f_8235eval.scm",(void*)f_8235},
{"f_8259eval.scm",(void*)f_8259},
{"f_8245eval.scm",(void*)f_8245},
{"f_8206eval.scm",(void*)f_8206},
{"f_8171eval.scm",(void*)f_8171},
{"f_8187eval.scm",(void*)f_8187},
{"f_8193eval.scm",(void*)f_8193},
{"f_8184eval.scm",(void*)f_8184},
{"f_8146eval.scm",(void*)f_8146},
{"f_8150eval.scm",(void*)f_8150},
{"f_8113eval.scm",(void*)f_8113},
{"f_8115eval.scm",(void*)f_8115},
{"f_8119eval.scm",(void*)f_8119},
{"f_8075eval.scm",(void*)f_8075},
{"f_8082eval.scm",(void*)f_8082},
{"f_8089eval.scm",(void*)f_8089},
{"f_8031eval.scm",(void*)f_8031},
{"f_8064eval.scm",(void*)f_8064},
{"f_8051eval.scm",(void*)f_8051},
{"f_8028eval.scm",(void*)f_8028},
{"f_7909eval.scm",(void*)f_7909},
{"f_8003eval.scm",(void*)f_8003},
{"f_8013eval.scm",(void*)f_8013},
{"f_8001eval.scm",(void*)f_8001},
{"f_7930eval.scm",(void*)f_7930},
{"f_7954eval.scm",(void*)f_7954},
{"f_7973eval.scm",(void*)f_7973},
{"f_7948eval.scm",(void*)f_7948},
{"f_7801eval.scm",(void*)f_7801},
{"f_7811eval.scm",(void*)f_7811},
{"f_7816eval.scm",(void*)f_7816},
{"f_7843eval.scm",(void*)f_7843},
{"f_7876eval.scm",(void*)f_7876},
{"f_7837eval.scm",(void*)f_7837},
{"f_7738eval.scm",(void*)f_7738},
{"f_7742eval.scm",(void*)f_7742},
{"f_7750eval.scm",(void*)f_7750},
{"f_7770eval.scm",(void*)f_7770},
{"f_7694eval.scm",(void*)f_7694},
{"f_7726eval.scm",(void*)f_7726},
{"f_7712eval.scm",(void*)f_7712},
{"f_7295eval.scm",(void*)f_7295},
{"f_7570eval.scm",(void*)f_7570},
{"f_7579eval.scm",(void*)f_7579},
{"f_7605eval.scm",(void*)f_7605},
{"f_7607eval.scm",(void*)f_7607},
{"f_7640eval.scm",(void*)f_7640},
{"f_7630eval.scm",(void*)f_7630},
{"f_7625eval.scm",(void*)f_7625},
{"f_7319eval.scm",(void*)f_7319},
{"f_7329eval.scm",(void*)f_7329},
{"f_7463eval.scm",(void*)f_7463},
{"f_7544eval.scm",(void*)f_7544},
{"f_7475eval.scm",(void*)f_7475},
{"f_7490eval.scm",(void*)f_7490},
{"f_7510eval.scm",(void*)f_7510},
{"f_7508eval.scm",(void*)f_7508},
{"f_7494eval.scm",(void*)f_7494},
{"f_7486eval.scm",(void*)f_7486},
{"f_7405eval.scm",(void*)f_7405},
{"f_7423eval.scm",(void*)f_7423},
{"f_7431eval.scm",(void*)f_7431},
{"f_7419eval.scm",(void*)f_7419},
{"f_7378eval.scm",(void*)f_7378},
{"f_7341eval.scm",(void*)f_7341},
{"f_7365eval.scm",(void*)f_7365},
{"f_7361eval.scm",(void*)f_7361},
{"f_7353eval.scm",(void*)f_7353},
{"f_7344eval.scm",(void*)f_7344},
{"f_7298eval.scm",(void*)f_7298},
{"f_7313eval.scm",(void*)f_7313},
{"f_7307eval.scm",(void*)f_7307},
{"f_7246eval.scm",(void*)f_7246},
{"f_7252eval.scm",(void*)f_7252},
{"f_7266eval.scm",(void*)f_7266},
{"f_7269eval.scm",(void*)f_7269},
{"f_7276eval.scm",(void*)f_7276},
{"f_7240eval.scm",(void*)f_7240},
{"f_7209eval.scm",(void*)f_7209},
{"f_7213eval.scm",(void*)f_7213},
{"f_7238eval.scm",(void*)f_7238},
{"f_7216eval.scm",(void*)f_7216},
{"f_7234eval.scm",(void*)f_7234},
{"f_7219eval.scm",(void*)f_7219},
{"f_7226eval.scm",(void*)f_7226},
{"f_7196eval.scm",(void*)f_7196},
{"f_7202eval.scm",(void*)f_7202},
{"f_7182eval.scm",(void*)f_7182},
{"f_7193eval.scm",(void*)f_7193},
{"f_7162eval.scm",(void*)f_7162},
{"f_7168eval.scm",(void*)f_7168},
{"f_7175eval.scm",(void*)f_7175},
{"f_7087eval.scm",(void*)f_7087},
{"f_7157eval.scm",(void*)f_7157},
{"f_7091eval.scm",(void*)f_7091},
{"f_7094eval.scm",(void*)f_7094},
{"f_7112eval.scm",(void*)f_7112},
{"f_7128eval.scm",(void*)f_7128},
{"f_7118eval.scm",(void*)f_7118},
{"f_7010eval.scm",(void*)f_7010},
{"f_7084eval.scm",(void*)f_7084},
{"f_7077eval.scm",(void*)f_7077},
{"f_7044eval.scm",(void*)f_7044},
{"f_7046eval.scm",(void*)f_7046},
{"f_7059eval.scm",(void*)f_7059},
{"f_7013eval.scm",(void*)f_7013},
{"f_7017eval.scm",(void*)f_7017},
{"f_7037eval.scm",(void*)f_7037},
{"f_7023eval.scm",(void*)f_7023},
{"f_7033eval.scm",(void*)f_7033},
{"f_7026eval.scm",(void*)f_7026},
{"f_6847eval.scm",(void*)f_6847},
{"f_6952eval.scm",(void*)f_6952},
{"f_6969eval.scm",(void*)f_6969},
{"f_6977eval.scm",(void*)f_6977},
{"f_6869eval.scm",(void*)f_6869},
{"f_6874eval.scm",(void*)f_6874},
{"f_6913eval.scm",(void*)f_6913},
{"f_6900eval.scm",(void*)f_6900},
{"f_6856eval.scm",(void*)f_6856},
{"f_6850eval.scm",(void*)f_6850},
{"f_6791eval.scm",(void*)f_6791},
{"f_6800eval.scm",(void*)f_6800},
{"f_6838eval.scm",(void*)f_6838},
{"f_6818eval.scm",(void*)f_6818},
{"f_6762eval.scm",(void*)f_6762},
{"f_6769eval.scm",(void*)f_6769},
{"f_6779eval.scm",(void*)f_6779},
{"f_6656eval.scm",(void*)f_6656},
{"f_6660eval.scm",(void*)f_6660},
{"f_6752eval.scm",(void*)f_6752},
{"f_6756eval.scm",(void*)f_6756},
{"f_6669eval.scm",(void*)f_6669},
{"f_6738eval.scm",(void*)f_6738},
{"f_6734eval.scm",(void*)f_6734},
{"f_6672eval.scm",(void*)f_6672},
{"f_6721eval.scm",(void*)f_6721},
{"f_6724eval.scm",(void*)f_6724},
{"f_6727eval.scm",(void*)f_6727},
{"f_6675eval.scm",(void*)f_6675},
{"f_6680eval.scm",(void*)f_6680},
{"f_6714eval.scm",(void*)f_6714},
{"f_6693eval.scm",(void*)f_6693},
{"f_6696eval.scm",(void*)f_6696},
{"f_6616eval.scm",(void*)f_6616},
{"f_6637eval.scm",(void*)f_6637},
{"f_6620eval.scm",(void*)f_6620},
{"f_6634eval.scm",(void*)f_6634},
{"f_6623eval.scm",(void*)f_6623},
{"f_6631eval.scm",(void*)f_6631},
{"f_6626eval.scm",(void*)f_6626},
{"f_6573eval.scm",(void*)f_6573},
{"f_6581eval.scm",(void*)f_6581},
{"f_6585eval.scm",(void*)f_6585},
{"f_6544eval.scm",(void*)f_6544},
{"f_6552eval.scm",(void*)f_6552},
{"f_6154eval.scm",(void*)f_6154},
{"f_6496eval.scm",(void*)f_6496},
{"f_6491eval.scm",(void*)f_6491},
{"f_6156eval.scm",(void*)f_6156},
{"f_6490eval.scm",(void*)f_6490},
{"f_6160eval.scm",(void*)f_6160},
{"f_6424eval.scm",(void*)f_6424},
{"f_6439eval.scm",(void*)f_6439},
{"f_6442eval.scm",(void*)f_6442},
{"f_6445eval.scm",(void*)f_6445},
{"f_6451eval.scm",(void*)f_6451},
{"f_6454eval.scm",(void*)f_6454},
{"f_6460eval.scm",(void*)f_6460},
{"f_6163eval.scm",(void*)f_6163},
{"f_6415eval.scm",(void*)f_6415},
{"f_6406eval.scm",(void*)f_6406},
{"f_6409eval.scm",(void*)f_6409},
{"f_6169eval.scm",(void*)f_6169},
{"f_6391eval.scm",(void*)f_6391},
{"f_6363eval.scm",(void*)f_6363},
{"f_6387eval.scm",(void*)f_6387},
{"f_6383eval.scm",(void*)f_6383},
{"f_6379eval.scm",(void*)f_6379},
{"f_6172eval.scm",(void*)f_6172},
{"f_6180eval.scm",(void*)f_6180},
{"f_6350eval.scm",(void*)f_6350},
{"f_6184eval.scm",(void*)f_6184},
{"f_6335eval.scm",(void*)f_6335},
{"f_6208eval.scm",(void*)f_6208},
{"f_6212eval.scm",(void*)f_6212},
{"f_6326eval.scm",(void*)f_6326},
{"f_6220eval.scm",(void*)f_6220},
{"f_6224eval.scm",(void*)f_6224},
{"f_6320eval.scm",(void*)f_6320},
{"f_6227eval.scm",(void*)f_6227},
{"f_6230eval.scm",(void*)f_6230},
{"f_6235eval.scm",(void*)f_6235},
{"f_6245eval.scm",(void*)f_6245},
{"f_6291eval.scm",(void*)f_6291},
{"f_6300eval.scm",(void*)f_6300},
{"f_6304eval.scm",(void*)f_6304},
{"f_6257eval.scm",(void*)f_6257},
{"f_6264eval.scm",(void*)f_6264},
{"f_6275eval.scm",(void*)f_6275},
{"f_6286eval.scm",(void*)f_6286},
{"f_6279eval.scm",(void*)f_6279},
{"f_6269eval.scm",(void*)f_6269},
{"f_6248eval.scm",(void*)f_6248},
{"f_6255eval.scm",(void*)f_6255},
{"f_6217eval.scm",(void*)f_6217},
{"f_6194eval.scm",(void*)f_6194},
{"f_6185eval.scm",(void*)f_6185},
{"f_6175eval.scm",(void*)f_6175},
{"f_6108eval.scm",(void*)f_6108},
{"f_6118eval.scm",(void*)f_6118},
{"f_6033eval.scm",(void*)f_6033},
{"f_6045eval.scm",(void*)f_6045},
{"f_6058eval.scm",(void*)f_6058},
{"f_6040eval.scm",(void*)f_6040},
{"f_6028eval.scm",(void*)f_6028},
{"f_5944eval.scm",(void*)f_5944},
{"f_5957eval.scm",(void*)f_5957},
{"f_5990eval.scm",(void*)f_5990},
{"f_5971eval.scm",(void*)f_5971},
{"f_5947eval.scm",(void*)f_5947},
{"f_5930eval.scm",(void*)f_5930},
{"f_5938eval.scm",(void*)f_5938},
{"f_5942eval.scm",(void*)f_5942},
{"f_3684eval.scm",(void*)f_3684},
{"f_5904eval.scm",(void*)f_5904},
{"f_5668eval.scm",(void*)f_5668},
{"f_5672eval.scm",(void*)f_5672},
{"f_5885eval.scm",(void*)f_5885},
{"f_5861eval.scm",(void*)f_5861},
{"f_5862eval.scm",(void*)f_5862},
{"f_5873eval.scm",(void*)f_5873},
{"f_5879eval.scm",(void*)f_5879},
{"f_5877eval.scm",(void*)f_5877},
{"f_5818eval.scm",(void*)f_5818},
{"f_5821eval.scm",(void*)f_5821},
{"f_5824eval.scm",(void*)f_5824},
{"f_5827eval.scm",(void*)f_5827},
{"f_5828eval.scm",(void*)f_5828},
{"f_5839eval.scm",(void*)f_5839},
{"f_5843eval.scm",(void*)f_5843},
{"f_5847eval.scm",(void*)f_5847},
{"f_5851eval.scm",(void*)f_5851},
{"f_5854eval.scm",(void*)f_5854},
{"f_5776eval.scm",(void*)f_5776},
{"f_5779eval.scm",(void*)f_5779},
{"f_5782eval.scm",(void*)f_5782},
{"f_5783eval.scm",(void*)f_5783},
{"f_5794eval.scm",(void*)f_5794},
{"f_5798eval.scm",(void*)f_5798},
{"f_5802eval.scm",(void*)f_5802},
{"f_5805eval.scm",(void*)f_5805},
{"f_5741eval.scm",(void*)f_5741},
{"f_5744eval.scm",(void*)f_5744},
{"f_5745eval.scm",(void*)f_5745},
{"f_5756eval.scm",(void*)f_5756},
{"f_5760eval.scm",(void*)f_5760},
{"f_5763eval.scm",(void*)f_5763},
{"f_5713eval.scm",(void*)f_5713},
{"f_5714eval.scm",(void*)f_5714},
{"f_5725eval.scm",(void*)f_5725},
{"f_5728eval.scm",(void*)f_5728},
{"f_5694eval.scm",(void*)f_5694},
{"f_5704eval.scm",(void*)f_5704},
{"f_5642eval.scm",(void*)f_5642},
{"f_3912eval.scm",(void*)f_3912},
{"f_4015eval.scm",(void*)f_4015},
{"f_4071eval.scm",(void*)f_4071},
{"f_4100eval.scm",(void*)f_4100},
{"f_4106eval.scm",(void*)f_4106},
{"f_5475eval.scm",(void*)f_5475},
{"f_5462eval.scm",(void*)f_5462},
{"f_5423eval.scm",(void*)f_5423},
{"f_5412eval.scm",(void*)f_5412},
{"f_5374eval.scm",(void*)f_5374},
{"f_5368eval.scm",(void*)f_5368},
{"f_5322eval.scm",(void*)f_5322},
{"f_5344eval.scm",(void*)f_5344},
{"f_5352eval.scm",(void*)f_5352},
{"f_5334eval.scm",(void*)f_5334},
{"f_5342eval.scm",(void*)f_5342},
{"f_5316eval.scm",(void*)f_5316},
{"f_5292eval.scm",(void*)f_5292},
{"f_5299eval.scm",(void*)f_5299},
{"f_5261eval.scm",(void*)f_5261},
{"f_5264eval.scm",(void*)f_5264},
{"f_5267eval.scm",(void*)f_5267},
{"f_5286eval.scm",(void*)f_5286},
{"f_5284eval.scm",(void*)f_5284},
{"f_5274eval.scm",(void*)f_5274},
{"f_4859eval.scm",(void*)f_4859},
{"f_5196eval.scm",(void*)f_5196},
{"f_5207eval.scm",(void*)f_5207},
{"f_5201eval.scm",(void*)f_5201},
{"f_4871eval.scm",(void*)f_4871},
{"f_4876eval.scm",(void*)f_4876},
{"f_5185eval.scm",(void*)f_5185},
{"f_5179eval.scm",(void*)f_5179},
{"f_4883eval.scm",(void*)f_4883},
{"f_5141eval.scm",(void*)f_5141},
{"f_5147eval.scm",(void*)f_5147},
{"f_5171eval.scm",(void*)f_5171},
{"f_5118eval.scm",(void*)f_5118},
{"f_5124eval.scm",(void*)f_5124},
{"f_5609eval.scm",(void*)f_5609},
{"f_5140eval.scm",(void*)f_5140},
{"f_5136eval.scm",(void*)f_5136},
{"f_5096eval.scm",(void*)f_5096},
{"f_5102eval.scm",(void*)f_5102},
{"f_5114eval.scm",(void*)f_5114},
{"f_5077eval.scm",(void*)f_5077},
{"f_5083eval.scm",(void*)f_5083},
{"f_5049eval.scm",(void*)f_5049},
{"f_5055eval.scm",(void*)f_5055},
{"f_5030eval.scm",(void*)f_5030},
{"f_5036eval.scm",(void*)f_5036},
{"f_5002eval.scm",(void*)f_5002},
{"f_5008eval.scm",(void*)f_5008},
{"f_4983eval.scm",(void*)f_4983},
{"f_4989eval.scm",(void*)f_4989},
{"f_4955eval.scm",(void*)f_4955},
{"f_4961eval.scm",(void*)f_4961},
{"f_4936eval.scm",(void*)f_4936},
{"f_4942eval.scm",(void*)f_4942},
{"f_4912eval.scm",(void*)f_4912},
{"f_4918eval.scm",(void*)f_4918},
{"f_4893eval.scm",(void*)f_4893},
{"f_4899eval.scm",(void*)f_4899},
{"f_4521eval.scm",(void*)f_4521},
{"f_4846eval.scm",(void*)f_4846},
{"f_4530eval.scm",(void*)f_4530},
{"f_4840eval.scm",(void*)f_4840},
{"f_4834eval.scm",(void*)f_4834},
{"f_4536eval.scm",(void*)f_4536},
{"f_4818eval.scm",(void*)f_4818},
{"f_4771eval.scm",(void*)f_4771},
{"f_4772eval.scm",(void*)f_4772},
{"f_4776eval.scm",(void*)f_4776},
{"f_4788eval.scm",(void*)f_4788},
{"f_4813eval.scm",(void*)f_4813},
{"f_4779eval.scm",(void*)f_4779},
{"f_4764eval.scm",(void*)f_4764},
{"f_4695eval.scm",(void*)f_4695},
{"f_4756eval.scm",(void*)f_4756},
{"f_4698eval.scm",(void*)f_4698},
{"f_4748eval.scm",(void*)f_4748},
{"f_4704eval.scm",(void*)f_4704},
{"f_4740eval.scm",(void*)f_4740},
{"f_4707eval.scm",(void*)f_4707},
{"f_4708eval.scm",(void*)f_4708},
{"f_4724eval.scm",(void*)f_4724},
{"f_4728eval.scm",(void*)f_4728},
{"f_4732eval.scm",(void*)f_4732},
{"f_4736eval.scm",(void*)f_4736},
{"f_4682eval.scm",(void*)f_4682},
{"f_4628eval.scm",(void*)f_4628},
{"f_4674eval.scm",(void*)f_4674},
{"f_4631eval.scm",(void*)f_4631},
{"f_4666eval.scm",(void*)f_4666},
{"f_4637eval.scm",(void*)f_4637},
{"f_4638eval.scm",(void*)f_4638},
{"f_4654eval.scm",(void*)f_4654},
{"f_4658eval.scm",(void*)f_4658},
{"f_4662eval.scm",(void*)f_4662},
{"f_4615eval.scm",(void*)f_4615},
{"f_4579eval.scm",(void*)f_4579},
{"f_4607eval.scm",(void*)f_4607},
{"f_4582eval.scm",(void*)f_4582},
{"f_4583eval.scm",(void*)f_4583},
{"f_4599eval.scm",(void*)f_4599},
{"f_4603eval.scm",(void*)f_4603},
{"f_4566eval.scm",(void*)f_4566},
{"f_4545eval.scm",(void*)f_4545},
{"f_4546eval.scm",(void*)f_4546},
{"f_4562eval.scm",(void*)f_4562},
{"f_4412eval.scm",(void*)f_4412},
{"f_4426eval.scm",(void*)f_4426},
{"f_4430eval.scm",(void*)f_4430},
{"f_4439eval.scm",(void*)f_4439},
{"f_4472eval.scm",(void*)f_4472},
{"f_4480eval.scm",(void*)f_4480},
{"f_4445eval.scm",(void*)f_4445},
{"f_4448eval.scm",(void*)f_4448},
{"f_4464eval.scm",(void*)f_4464},
{"f_4455eval.scm",(void*)f_4455},
{"f_4463eval.scm",(void*)f_4463},
{"f_4500eval.scm",(void*)f_4500},
{"f_4508eval.scm",(void*)f_4508},
{"f_4487eval.scm",(void*)f_4487},
{"f_4499eval.scm",(void*)f_4499},
{"f_4420eval.scm",(void*)f_4420},
{"f_4304eval.scm",(void*)f_4304},
{"f_4363eval.scm",(void*)f_4363},
{"f_4366eval.scm",(void*)f_4366},
{"f_4369eval.scm",(void*)f_4369},
{"f_4370eval.scm",(void*)f_4370},
{"f_4374eval.scm",(void*)f_4374},
{"f_4377eval.scm",(void*)f_4377},
{"f_4341eval.scm",(void*)f_4341},
{"f_4344eval.scm",(void*)f_4344},
{"f_4345eval.scm",(void*)f_4345},
{"f_4349eval.scm",(void*)f_4349},
{"f_4247eval.scm",(void*)f_4247},
{"f_4250eval.scm",(void*)f_4250},
{"f_4253eval.scm",(void*)f_4253},
{"f_4256eval.scm",(void*)f_4256},
{"f_4257eval.scm",(void*)f_4257},
{"f_4264eval.scm",(void*)f_4264},
{"f_4237eval.scm",(void*)f_4237},
{"f_4203eval.scm",(void*)f_4203},
{"f_4197eval.scm",(void*)f_4197},
{"f_4198eval.scm",(void*)f_4198},
{"f_4121eval.scm",(void*)f_4121},
{"f_4181eval.scm",(void*)f_4181},
{"f_4179eval.scm",(void*)f_4179},
{"f_4171eval.scm",(void*)f_4171},
{"f_4163eval.scm",(void*)f_4163},
{"f_4155eval.scm",(void*)f_4155},
{"f_4147eval.scm",(void*)f_4147},
{"f_4139eval.scm",(void*)f_4139},
{"f_4131eval.scm",(void*)f_4131},
{"f_4072eval.scm",(void*)f_4072},
{"f_4061eval.scm",(void*)f_4061},
{"f_4059eval.scm",(void*)f_4059},
{"f_4048eval.scm",(void*)f_4048},
{"f_4046eval.scm",(void*)f_4046},
{"f_4038eval.scm",(void*)f_4038},
{"f_4030eval.scm",(void*)f_4030},
{"f_4022eval.scm",(void*)f_4022},
{"f_3930eval.scm",(void*)f_3930},
{"f_3940eval.scm",(void*)f_3940},
{"f_3989eval.scm",(void*)f_3989},
{"f_3974eval.scm",(void*)f_3974},
{"f_3969eval.scm",(void*)f_3969},
{"f_3970eval.scm",(void*)f_3970},
{"f_3946eval.scm",(void*)f_3946},
{"f_3949eval.scm",(void*)f_3949},
{"f_3950eval.scm",(void*)f_3950},
{"f_4005eval.scm",(void*)f_4005},
{"f_3996eval.scm",(void*)f_3996},
{"f_3924eval.scm",(void*)f_3924},
{"f_3906eval.scm",(void*)f_3906},
{"f_3900eval.scm",(void*)f_3900},
{"f_3894eval.scm",(void*)f_3894},
{"f_3841eval.scm",(void*)f_3841},
{"f_3845eval.scm",(void*)f_3845},
{"f_3892eval.scm",(void*)f_3892},
{"f_3860eval.scm",(void*)f_3860},
{"f_3869eval.scm",(void*)f_3869},
{"f_3729eval.scm",(void*)f_3729},
{"f_3741eval.scm",(void*)f_3741},
{"f_3735eval.scm",(void*)f_3735},
{"f_3687eval.scm",(void*)f_3687},
{"f_3693eval.scm",(void*)f_3693},
{"f_3811eval.scm",(void*)f_3811},
{"f_3678eval.scm",(void*)f_3678},
{"f_3637eval.scm",(void*)f_3637},
{"f_3656eval.scm",(void*)f_3656},
{"f_3668eval.scm",(void*)f_3668},
{"f_3671eval.scm",(void*)f_3671},
{"f_3674eval.scm",(void*)f_3674},
{"f_3664eval.scm",(void*)f_3664},
{"f_3643eval.scm",(void*)f_3643},
{"f_3577eval.scm",(void*)f_3577},
{"f_3581eval.scm",(void*)f_3581},
{"f_3589eval.scm",(void*)f_3589},
{"f_3531eval.scm",(void*)f_3531},
{"f_3537eval.scm",(void*)f_3537},
{"f_3556eval.scm",(void*)f_3556},
{"f_3547eval.scm",(void*)f_3547},
{"f_3476eval.scm",(void*)f_3476},
{"f_3480eval.scm",(void*)f_3480},
{"f_3488eval.scm",(void*)f_3488},
{"f_3431eval.scm",(void*)f_3431},
{"f_3435eval.scm",(void*)f_3435},
{"f_3444eval.scm",(void*)f_3444},
{"f_3416eval.scm",(void*)f_3416},
{"f_3356eval.scm",(void*)f_3356},
{"f_3411eval.scm",(void*)f_3411},
{"f_3359eval.scm",(void*)f_3359},
{"f_3265eval.scm",(void*)f_3265},
{"f_3354eval.scm",(void*)f_3354},
{"f_3268eval.scm",(void*)f_3268},
{"f_3323eval.scm",(void*)f_3323},
{"f_2779eval.scm",(void*)f_2779},
{"f_3217eval.scm",(void*)f_3217},
{"f_3212eval.scm",(void*)f_3212},
{"f_2781eval.scm",(void*)f_2781},
{"f_2964eval.scm",(void*)f_2964},
{"f_2970eval.scm",(void*)f_2970},
{"f_3004eval.scm",(void*)f_3004},
{"f_3176eval.scm",(void*)f_3176},
{"f_3162eval.scm",(void*)f_3162},
{"f_3169eval.scm",(void*)f_3169},
{"f_3134eval.scm",(void*)f_3134},
{"f_3016eval.scm",(void*)f_3016},
{"f_3021eval.scm",(void*)f_3021},
{"f_3034eval.scm",(void*)f_3034},
{"f_3086eval.scm",(void*)f_3086},
{"f_3068eval.scm",(void*)f_3068},
{"f_3079eval.scm",(void*)f_3079},
{"f_2784eval.scm",(void*)f_2784},
{"f_2866eval.scm",(void*)f_2866},
{"f_2956eval.scm",(void*)f_2956},
{"f_2944eval.scm",(void*)f_2944},
{"f_2877eval.scm",(void*)f_2877},
{"f_2942eval.scm",(void*)f_2942},
{"f_2934eval.scm",(void*)f_2934},
{"f_2885eval.scm",(void*)f_2885},
{"f_2928eval.scm",(void*)f_2928},
{"f_2932eval.scm",(void*)f_2932},
{"f_2895eval.scm",(void*)f_2895},
{"f_2899eval.scm",(void*)f_2899},
{"f_2920eval.scm",(void*)f_2920},
{"f_2918eval.scm",(void*)f_2918},
{"f_2893eval.scm",(void*)f_2893},
{"f_2889eval.scm",(void*)f_2889},
{"f_2881eval.scm",(void*)f_2881},
{"f_2796eval.scm",(void*)f_2796},
{"f_2815eval.scm",(void*)f_2815},
{"f_2826eval.scm",(void*)f_2826},
{"f_2834eval.scm",(void*)f_2834},
{"f_2822eval.scm",(void*)f_2822},
{"f_2260eval.scm",(void*)f_2260},
{"f_2282eval.scm",(void*)f_2282},
{"f_2722eval.scm",(void*)f_2722},
{"f_2660eval.scm",(void*)f_2660},
{"f_2641eval.scm",(void*)f_2641},
{"f_2595eval.scm",(void*)f_2595},
{"f_2598eval.scm",(void*)f_2598},
{"f_2577eval.scm",(void*)f_2577},
{"f_2558eval.scm",(void*)f_2558},
{"f_2526eval.scm",(void*)f_2526},
{"f_2505eval.scm",(void*)f_2505},
{"f_2296eval.scm",(void*)f_2296},
{"f_2498eval.scm",(void*)f_2498},
{"f_2441eval.scm",(void*)f_2441},
{"f_2494eval.scm",(void*)f_2494},
{"f_2468eval.scm",(void*)f_2468},
{"f_2439eval.scm",(void*)f_2439},
{"f_2300eval.scm",(void*)f_2300},
{"f_2312eval.scm",(void*)f_2312},
{"f_2391eval.scm",(void*)f_2391},
{"f_2387eval.scm",(void*)f_2387},
{"f_2368eval.scm",(void*)f_2368},
{"f_2335eval.scm",(void*)f_2335},
{"f_2343eval.scm",(void*)f_2343},
{"f_2303eval.scm",(void*)f_2303},
{"f_2263eval.scm",(void*)f_2263},
{"f_2217eval.scm",(void*)f_2217},
{"f_2223eval.scm",(void*)f_2223},
{"f_2242eval.scm",(void*)f_2242},
{"f_2201eval.scm",(void*)f_2201},
{"f_2165eval.scm",(void*)f_2165},
{"f_2174eval.scm",(void*)f_2174},
{"f_2186eval.scm",(void*)f_2186},
{"f_2180eval.scm",(void*)f_2180},
{"f_2158eval.scm",(void*)f_2158},
{"f_2155eval.scm",(void*)f_2155},
{"f_2152eval.scm",(void*)f_2152},
{"f_1782eval.scm",(void*)f_1782},
{"f_2092eval.scm",(void*)f_2092},
{"f_2098eval.scm",(void*)f_2098},
{"f_2105eval.scm",(void*)f_2105},
{"f_2019eval.scm",(void*)f_2019},
{"f_2031eval.scm",(void*)f_2031},
{"f_2079eval.scm",(void*)f_2079},
{"f_2073eval.scm",(void*)f_2073},
{"f_2053eval.scm",(void*)f_2053},
{"f_1931eval.scm",(void*)f_1931},
{"f_1951eval.scm",(void*)f_1951},
{"f_1959eval.scm",(void*)f_1959},
{"f_1973eval.scm",(void*)f_1973},
{"f_1945eval.scm",(void*)f_1945},
{"f_1785eval.scm",(void*)f_1785},
{"f_1794eval.scm",(void*)f_1794},
{"f_1907eval.scm",(void*)f_1907},
{"f_1919eval.scm",(void*)f_1919},
{"f_1925eval.scm",(void*)f_1925},
{"f_1913eval.scm",(void*)f_1913},
{"f_1800eval.scm",(void*)f_1800},
{"f_1806eval.scm",(void*)f_1806},
{"f_1817eval.scm",(void*)f_1817},
{"f_1834eval.scm",(void*)f_1834},
{"f_1853eval.scm",(void*)f_1853},
{"f_1864eval.scm",(void*)f_1864},
{"f_1828eval.scm",(void*)f_1828},
{"f_1814eval.scm",(void*)f_1814},
{"f_1792eval.scm",(void*)f_1792},
{"f_1773eval.scm",(void*)f_1773},
{"f_1755eval.scm",(void*)f_1755},
{"f_1765eval.scm",(void*)f_1765},
{"f_1745eval.scm",(void*)f_1745},
{"f_1753eval.scm",(void*)f_1753},
{"f_1729eval.scm",(void*)f_1729},
{"f_1735eval.scm",(void*)f_1735},
{"f_1713eval.scm",(void*)f_1713},
{"f_1719eval.scm",(void*)f_1719},
{"f_1672eval.scm",(void*)f_1672},
{"f_1676eval.scm",(void*)f_1676},
{"f_1679eval.scm",(void*)f_1679},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
