/* Generated from srfi-14.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-06-19 09:24
   Version 4.0.7 - SVN rev. 14630
   windows-mingw32-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-05-14 on lenovo-1 (MINGW32_NT-6.0)
   command line: srfi-14.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -explicit-use -output-file srfi-14.c
   unit: srfi_14
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[108];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,19),40,37,108,97,116,105,110,49,45,62,99,104,97,114,32,110,50,49,41,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,15),40,37,99,104,97,114,45,62,108,97,116,105,110,49,41,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,19),40,109,97,107,101,45,99,104,97,114,45,115,101,116,32,115,50,57,41,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,17),40,99,104,97,114,45,115,101,116,58,115,32,99,115,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,15),40,99,104,97,114,45,115,101,116,63,32,120,51,55,41,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,18),40,37,115,116,114,105,110,103,45,99,111,112,121,32,115,52,49,41,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,35),40,37,100,101,102,97,117,108,116,45,98,97,115,101,32,109,97,121,98,101,45,98,97,115,101,52,53,32,112,114,111,99,52,54,41,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,9),40,108,112,32,99,115,53,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,31),40,37,99,104,97,114,45,115,101,116,58,115,47,99,104,101,99,107,32,99,115,53,51,32,112,114,111,99,53,52,41,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,20),40,99,104,97,114,45,115,101,116,45,99,111,112,121,32,99,115,56,56,41,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,12),40,108,112,32,114,101,115,116,49,48,57,41,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,20),40,99,104,97,114,45,115,101,116,61,32,46,32,114,101,115,116,57,49,41,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,10),40,108,112,50,32,105,49,52,57,41,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,18),40,108,112,32,115,49,49,51,53,32,114,101,115,116,49,51,54,41,0,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,22),40,99,104,97,114,45,115,101,116,60,61,32,46,32,114,101,115,116,49,50,50,41,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,4),40,108,112,41,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,16),40,108,112,32,105,49,57,53,32,97,110,115,49,57,54,41};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,38),40,99,104,97,114,45,115,101,116,45,104,97,115,104,32,99,115,49,54,55,32,46,32,109,97,121,98,101,45,98,111,117,110,100,49,54,56,41,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,34),40,99,104,97,114,45,115,101,116,45,99,111,110,116,97,105,110,115,63,32,99,115,50,48,56,32,99,104,97,114,50,48,57,41,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,12),40,108,112,32,115,105,122,101,50,50,57,41,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,21),40,99,104,97,114,45,115,101,116,45,115,105,122,101,32,99,115,50,50,50,41,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,18),40,108,112,32,105,50,52,54,32,99,111,117,110,116,50,52,55,41,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,32),40,99,104,97,114,45,115,101,116,45,99,111,117,110,116,32,112,114,101,100,50,51,57,32,99,115,101,116,50,52,48,41};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,12),40,97,49,55,52,49,32,99,50,55,48,41,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,45),40,37,115,101,116,45,99,104,97,114,45,115,101,116,32,115,101,116,50,54,51,32,112,114,111,99,50,54,52,32,99,115,50,54,53,32,99,104,97,114,115,50,54,54,41,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,12),40,97,49,55,54,52,32,99,50,56,50,41,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,46),40,37,115,101,116,45,99,104,97,114,45,115,101,116,33,32,115,101,116,50,55,53,32,112,114,111,99,50,55,54,32,99,115,50,55,55,32,99,104,97,114,115,50,55,56,41,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,17),40,97,49,55,56,48,32,115,50,57,48,32,105,50,57,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,34),40,99,104,97,114,45,115,101,116,45,97,100,106,111,105,110,32,99,115,50,56,55,32,46,32,99,104,97,114,115,50,56,56,41,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,17),40,97,49,55,57,50,32,115,50,57,56,32,105,50,57,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,35),40,99,104,97,114,45,115,101,116,45,97,100,106,111,105,110,33,32,99,115,50,57,53,32,46,32,99,104,97,114,115,50,57,54,41,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,17),40,97,49,56,48,52,32,115,51,48,54,32,105,51,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,34),40,99,104,97,114,45,115,101,116,45,100,101,108,101,116,101,32,99,115,51,48,51,32,46,32,99,104,97,114,115,51,48,52,41,0,0,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,17),40,97,49,56,49,54,32,115,51,49,52,32,105,51,49,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,35),40,99,104,97,114,45,115,101,116,45,100,101,108,101,116,101,33,32,99,115,51,49,49,32,46,32,99,104,97,114,115,51,49,50,41,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,25),40,99,104,97,114,45,115,101,116,45,99,117,114,115,111,114,32,99,115,101,116,51,49,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,28),40,101,110,100,45,111,102,45,99,104,97,114,45,115,101,116,63,32,99,117,114,115,111,114,51,50,51,41,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,32),40,99,104,97,114,45,115,101,116,45,114,101,102,32,99,115,101,116,51,50,55,32,99,117,114,115,111,114,51,50,56,41};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,40),40,99,104,97,114,45,115,101,116,45,99,117,114,115,111,114,45,110,101,120,116,32,99,115,101,116,51,51,50,32,99,117,114,115,111,114,51,51,51,41};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,11),40,108,112,32,99,117,114,51,52,54,41,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,49),40,37,99,104,97,114,45,115,101,116,45,99,117,114,115,111,114,45,110,101,120,116,32,99,115,101,116,51,51,56,32,99,117,114,115,111,114,51,51,57,32,112,114,111,99,51,52,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,51,55,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,33),40,99,104,97,114,45,115,101,116,45,102,111,114,45,101,97,99,104,32,112,114,111,99,51,54,56,32,99,115,51,54,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,52,48,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,28),40,99,104,97,114,45,115,101,116,45,109,97,112,32,112,114,111,99,51,57,55,32,99,115,51,57,56,41,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,16),40,108,112,32,105,52,52,48,32,97,110,115,52,52,49,41};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,37),40,99,104,97,114,45,115,101,116,45,102,111,108,100,32,107,111,110,115,52,51,50,32,107,110,105,108,52,51,51,32,99,115,52,51,52,41,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,52,53,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,30),40,99,104,97,114,45,115,101,116,45,101,118,101,114,121,32,112,114,101,100,52,53,49,32,99,115,52,53,50,41,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,52,56,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,28),40,99,104,97,114,45,115,101,116,45,97,110,121,32,112,114,101,100,52,56,50,32,99,115,52,56,51,41,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,12),40,108,112,32,115,101,101,100,53,50,50,41,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,47),40,37,99,104,97,114,45,115,101,116,45,117,110,102,111,108,100,33,32,112,53,49,52,32,102,53,49,53,32,103,53,49,54,32,115,53,49,55,32,115,101,101,100,53,49,56,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,56),40,99,104,97,114,45,115,101,116,45,117,110,102,111,108,100,32,112,53,52,48,32,102,53,52,49,32,103,53,52,50,32,115,101,101,100,53,52,51,32,46,32,109,97,121,98,101,45,98,97,115,101,53,52,52,41};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,54),40,99,104,97,114,45,115,101,116,45,117,110,102,111,108,100,33,32,112,53,53,49,32,102,53,53,50,32,103,53,53,51,32,115,101,101,100,53,53,52,32,98,97,115,101,45,99,115,101,116,53,53,53,41,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,15),40,97,50,50,49,55,32,99,104,97,114,53,54,51,41,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,32),40,37,108,105,115,116,45,62,99,104,97,114,45,115,101,116,33,32,99,104,97,114,115,53,54,48,32,115,53,54,49,41};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,21),40,99,104,97,114,45,115,101,116,32,46,32,99,104,97,114,115,53,55,49,41,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,41),40,108,105,115,116,45,62,99,104,97,114,45,115,101,116,32,99,104,97,114,115,53,55,56,32,46,32,109,97,121,98,101,45,98,97,115,101,53,55,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,37),40,108,105,115,116,45,62,99,104,97,114,45,115,101,116,33,32,99,104,97,114,115,53,56,54,32,98,97,115,101,45,99,115,53,56,55,41,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,16),40,108,112,32,105,53,57,56,32,97,110,115,53,57,57,41};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,22),40,99,104,97,114,45,115,101,116,45,62,108,105,115,116,32,99,115,53,57,50,41,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,54,49,51,41,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,41),40,37,115,116,114,105,110,103,45,62,99,104,97,114,45,115,101,116,33,32,115,116,114,54,48,57,32,98,115,54,49,48,32,112,114,111,99,54,49,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,41),40,115,116,114,105,110,103,45,62,99,104,97,114,45,115,101,116,32,115,116,114,54,51,50,32,46,32,109,97,121,98,101,45,98,97,115,101,54,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,37),40,115,116,114,105,110,103,45,62,99,104,97,114,45,115,101,116,33,32,115,116,114,54,52,48,32,98,97,115,101,45,99,115,54,52,49,41,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,14),40,108,112,32,105,54,53,54,32,106,54,53,55,41,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,24),40,99,104,97,114,45,115,101,116,45,62,115,116,114,105,110,103,32,99,115,54,52,54,41};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,4),40,108,112,41,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,65),40,37,117,99,115,45,114,97,110,103,101,45,62,99,104,97,114,45,115,101,116,33,32,108,111,119,101,114,54,55,48,32,117,112,112,101,114,54,55,49,32,101,114,114,111,114,63,54,55,50,32,98,115,54,55,51,32,112,114,111,99,54,55,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,49),40,117,99,115,45,114,97,110,103,101,45,62,99,104,97,114,45,115,101,116,32,108,111,119,101,114,55,48,51,32,117,112,112,101,114,55,48,52,32,46,32,114,101,115,116,55,48,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,61),40,117,99,115,45,114,97,110,103,101,45,62,99,104,97,114,45,115,101,116,33,32,108,111,119,101,114,55,50,54,32,117,112,112,101,114,55,50,55,32,101,114,114,111,114,63,55,50,56,32,98,97,115,101,45,99,115,55,50,57,41,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,55,52,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,39),40,37,99,104,97,114,45,115,101,116,45,102,105,108,116,101,114,33,32,112,114,101,100,55,51,52,32,100,115,55,51,53,32,98,115,55,51,54,41,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,56),40,99,104,97,114,45,115,101,116,45,102,105,108,116,101,114,32,112,114,101,100,105,99,97,116,101,55,54,57,32,100,111,109,97,105,110,55,55,48,32,46,32,109,97,121,98,101,45,98,97,115,101,55,55,49,41};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,52),40,99,104,97,114,45,115,101,116,45,102,105,108,116,101,114,33,32,112,114,101,100,105,99,97,116,101,55,55,56,32,100,111,109,97,105,110,55,55,57,32,98,97,115,101,45,99,115,55,56,48,41,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,17),40,45,62,99,104,97,114,45,115,101,116,32,120,55,56,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,56,48,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,24),40,37,115,116,114,105,110,103,45,105,116,101,114,32,112,55,57,54,32,115,55,57,55,41};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,56,50,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,15),40,97,50,54,56,53,32,99,115,101,116,56,50,48,41,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,47),40,37,99,104,97,114,45,115,101,116,45,97,108,103,101,98,114,97,32,115,56,49,53,32,99,115,101,116,115,56,49,54,32,111,112,56,49,55,32,112,114,111,99,56,49,56,41,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,17),40,97,50,55,51,54,32,105,56,52,57,32,118,56,53,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,27),40,99,104,97,114,45,115,101,116,45,99,111,109,112,108,101,109,101,110,116,32,99,115,56,52,52,41,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,17),40,97,50,55,53,56,32,105,56,54,57,32,118,56,55,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,30),40,99,104,97,114,45,115,101,116,45,99,111,109,112,108,101,109,101,110,116,33,32,99,115,101,116,56,54,53,41,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,22),40,97,50,55,56,49,32,115,56,56,56,32,105,56,56,57,32,118,56,57,48,41,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,37),40,99,104,97,114,45,115,101,116,45,117,110,105,111,110,33,32,99,115,101,116,49,56,56,53,32,46,32,99,115,101,116,115,56,56,54,41,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,22),40,97,50,56,49,57,32,115,57,48,51,32,105,57,48,52,32,118,57,48,53,41,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,27),40,99,104,97,114,45,115,101,116,45,117,110,105,111,110,32,46,32,99,115,101,116,115,56,57,57,41,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,22),40,97,50,56,53,54,32,115,57,49,55,32,105,57,49,56,32,118,57,49,57,41,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,44),40,99,104,97,114,45,115,101,116,45,105,110,116,101,114,115,101,99,116,105,111,110,33,32,99,115,101,116,49,57,49,52,32,46,32,99,115,101,116,115,57,49,53,41,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,22),40,97,50,56,57,48,32,115,57,51,50,32,105,57,51,51,32,118,57,51,52,41,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,34),40,99,104,97,114,45,115,101,116,45,105,110,116,101,114,115,101,99,116,105,111,110,32,46,32,99,115,101,116,115,57,50,56,41,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,22),40,97,50,57,50,51,32,115,57,52,54,32,105,57,52,55,32,118,57,52,56,41,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,42),40,99,104,97,114,45,115,101,116,45,100,105,102,102,101,114,101,110,99,101,33,32,99,115,101,116,49,57,52,51,32,46,32,99,115,101,116,115,57,52,52,41,0,0,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,22),40,97,50,57,53,55,32,115,57,54,50,32,105,57,54,51,32,118,57,54,52,41,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,39),40,99,104,97,114,45,115,101,116,45,100,105,102,102,101,114,101,110,99,101,32,99,115,49,57,53,55,32,46,32,99,115,101,116,115,57,53,56,41,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,22),40,97,50,57,57,48,32,115,57,55,54,32,105,57,55,55,32,118,57,55,56,41,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,35),40,99,104,97,114,45,115,101,116,45,120,111,114,33,32,99,115,101,116,49,57,55,51,32,46,32,99,115,101,116,115,57,55,52,41,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,22),40,97,51,48,52,51,32,115,57,57,54,32,105,57,57,55,32,118,57,57,56,41,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,25),40,99,104,97,114,45,115,101,116,45,120,111,114,32,46,32,99,115,101,116,115,57,57,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,19),40,97,51,48,57,55,32,105,49,48,49,57,32,118,49,48,50,48,41,0,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,14),40,97,51,48,57,49,32,99,115,49,48,49,55,41,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,66),40,37,99,104,97,114,45,115,101,116,45,100,105,102,102,43,105,110,116,101,114,115,101,99,116,105,111,110,33,32,100,105,102,102,49,48,49,50,32,105,110,116,49,48,49,51,32,99,115,101,116,115,49,48,49,52,32,112,114,111,99,49,48,49,53,41,0,0,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,19),40,97,51,49,53,54,32,105,49,48,53,53,32,118,49,48,53,54,41,0,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,57),40,99,104,97,114,45,115,101,116,45,100,105,102,102,43,105,110,116,101,114,115,101,99,116,105,111,110,33,32,99,115,49,49,48,52,56,32,99,115,50,49,48,52,57,32,46,32,99,115,101,116,115,49,48,53,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,48),40,99,104,97,114,45,115,101,116,45,100,105,102,102,43,105,110,116,101,114,115,101,99,116,105,111,110,32,99,115,49,49,48,55,56,32,46,32,99,115,101,116,115,49,48,55,57,41};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_srfi_14_toplevel)
C_externexport void C_ccall C_srfi_14_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1212)
static void C_ccall f_1212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1328)
static void C_ccall f_1328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1332)
static void C_ccall f_1332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3219)
static void C_ccall f_3219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3223)
static void C_ccall f_3223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3227)
static void C_ccall f_3227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3230)
static void C_ccall f_3230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3233)
static void C_ccall f_3233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3335)
static void C_ccall f_3335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3236)
static void C_ccall f_3236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3240)
static void C_ccall f_3240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3248)
static void C_ccall f_3248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3327)
static void C_ccall f_3327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3251)
static void C_ccall f_3251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3255)
static void C_ccall f_3255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3259)
static void C_ccall f_3259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3263)
static void C_ccall f_3263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3267)
static void C_ccall f_3267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3270)
static void C_ccall f_3270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3273)
static void C_ccall f_3273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3277)
static void C_ccall f_3277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3280)
static void C_ccall f_3280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3283)
static void C_ccall f_3283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3287)
static void C_ccall f_3287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3319)
static void C_ccall f_3319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3291)
static void C_ccall f_3291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3315)
static void C_ccall f_3315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3299)
static void C_ccall f_3299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3311)
static void C_ccall f_3311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3303)
static void C_ccall f_3303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3307)
static void C_ccall f_3307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3190)
static void C_ccall f_3190(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3190)
static void C_ccall f_3190r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3215)
static void C_ccall f_3215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3194)
static void C_ccall f_3194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3197)
static void C_ccall f_3197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3200)
static void C_ccall f_3200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3207)
static void C_ccall f_3207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3211)
static void C_ccall f_3211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3139)
static void C_ccall f_3139(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3139)
static void C_ccall f_3139r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3143)
static void C_ccall f_3143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3146)
static void C_ccall f_3146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3157)
static void C_ccall f_3157(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3149)
static void C_ccall f_3149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3152)
static void C_ccall f_3152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3086)
static void C_fcall f_3086(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3092)
static void C_ccall f_3092(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3137)
static void C_ccall f_3137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3098)
static void C_ccall f_3098(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3022)
static void C_ccall f_3022(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3022)
static void C_ccall f_3022r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3077)
static void C_ccall f_3077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3032)
static void C_ccall f_3032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3044)
static void C_ccall f_3044(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3061)
static void C_ccall f_3061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3035)
static void C_ccall f_3035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2981)
static void C_ccall f_2981(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2981)
static void C_ccall f_2981r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2989)
static void C_ccall f_2989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2991)
static void C_ccall f_2991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3008)
static void C_ccall f_3008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2985)
static void C_ccall f_2985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2940)
static void C_ccall f_2940(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2940)
static void C_ccall f_2940r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2976)
static void C_ccall f_2976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2950)
static void C_ccall f_2950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2958)
static void C_ccall f_2958(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2953)
static void C_ccall f_2953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2914)
static void C_ccall f_2914(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2914)
static void C_ccall f_2914r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2922)
static void C_ccall f_2922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2924)
static void C_ccall f_2924(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2918)
static void C_ccall f_2918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2869)
static void C_ccall f_2869(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2869)
static void C_ccall f_2869r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2905)
static void C_ccall f_2905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2879)
static void C_ccall f_2879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2891)
static void C_ccall f_2891(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2882)
static void C_ccall f_2882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2847)
static void C_ccall f_2847(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2847)
static void C_ccall f_2847r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2855)
static void C_ccall f_2855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2857)
static void C_ccall f_2857(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2851)
static void C_ccall f_2851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2798)
static void C_ccall f_2798(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2798)
static void C_ccall f_2798r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2808)
static void C_ccall f_2808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2820)
static void C_ccall f_2820(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2811)
static void C_ccall f_2811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2772)
static void C_ccall f_2772(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2772)
static void C_ccall f_2772r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2780)
static void C_ccall f_2780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2782)
static void C_ccall f_2782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2776)
static void C_ccall f_2776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2750)
static void C_ccall f_2750(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2754)
static void C_ccall f_2754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2759)
static void C_ccall f_2759(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2770)
static void C_ccall f_2770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2757)
static void C_ccall f_2757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2722)
static void C_ccall f_2722(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2726)
static void C_ccall f_2726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2729)
static void C_ccall f_2729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2737)
static void C_ccall f_2737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2748)
static void C_ccall f_2748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2732)
static void C_ccall f_2732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2680)
static void C_fcall f_2680(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2686)
static void C_ccall f_2686(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2690)
static void C_ccall f_2690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2695)
static void C_fcall f_2695(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2705)
static void C_ccall f_2705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2639)
static void C_fcall f_2639(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2649)
static void C_fcall f_2649(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2659)
static void C_ccall f_2659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2609)
static void C_ccall f_2609(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2616)
static void C_ccall f_2616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2595)
static void C_ccall f_2595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2603)
static void C_ccall f_2603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2607)
static void C_ccall f_2607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2599)
static void C_ccall f_2599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2579)
static void C_ccall f_2579(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2579)
static void C_ccall f_2579r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2583)
static void C_ccall f_2583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2593)
static void C_ccall f_2593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2586)
static void C_ccall f_2586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2526)
static void C_fcall f_2526(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2532)
static void C_fcall f_2532(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2565)
static void C_ccall f_2565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2552)
static void C_ccall f_2552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2542)
static void C_fcall f_2542(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2516)
static void C_ccall f_2516(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2524)
static void C_ccall f_2524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2520)
static void C_ccall f_2520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2486)
static void C_ccall f_2486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2486)
static void C_ccall f_2486r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2496)
static void C_ccall f_2496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2499)
static void C_ccall f_2499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2429)
static void C_fcall f_2429(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2472)
static void C_fcall f_2472(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2469)
static void C_ccall f_2469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2448)
static C_word C_fcall f_2448(C_word t0,C_word t1);
C_noret_decl(f_2373)
static void C_ccall f_2373(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2377)
static void C_ccall f_2377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2427)
static void C_ccall f_2427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2380)
static void C_ccall f_2380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2385)
static void C_fcall f_2385(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2415)
static void C_ccall f_2415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2395)
static void C_fcall f_2395(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2363)
static void C_ccall f_2363(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2371)
static void C_ccall f_2371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2367)
static void C_ccall f_2367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2351)
static void C_ccall f_2351(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2351)
static void C_ccall f_2351r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2355)
static void C_ccall f_2355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2358)
static void C_ccall f_2358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2308)
static void C_fcall f_2308(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2321)
static C_word C_fcall f_2321(C_word t0,C_word t1);
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2265)
static void C_ccall f_2265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2270)
static void C_fcall f_2270(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2298)
static void C_ccall f_2298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2288)
static void C_fcall f_2288(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2251)
static void C_ccall f_2251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2259)
static void C_ccall f_2259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2255)
static void C_ccall f_2255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2243)
static void C_ccall f_2243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2227)
static void C_ccall f_2227(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2227)
static void C_ccall f_2227r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2231)
static void C_ccall f_2231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2234)
static void C_ccall f_2234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2212)
static void C_fcall f_2212(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2218)
static void C_ccall f_2218(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2202)
static void C_ccall f_2202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2210)
static void C_ccall f_2210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2206)
static void C_ccall f_2206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2190)
static void C_ccall f_2190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_2190)
static void C_ccall f_2190r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_2194)
static void C_ccall f_2194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2197)
static void C_ccall f_2197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2154)
static void C_fcall f_2154(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2160)
static void C_fcall f_2160(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2188)
static void C_ccall f_2188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2184)
static void C_ccall f_2184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2180)
static void C_ccall f_2180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2101)
static void C_ccall f_2101(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2105)
static void C_ccall f_2105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2110)
static void C_fcall f_2110(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2140)
static void C_ccall f_2140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2120)
static void C_ccall f_2120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2052)
static void C_ccall f_2052(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2056)
static void C_ccall f_2056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2061)
static void C_fcall f_2061(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2091)
static void C_ccall f_2091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2077)
static void C_ccall f_2077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2005)
static void C_ccall f_2005(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2009)
static void C_ccall f_2009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2014)
static void C_fcall f_2014(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2042)
static void C_ccall f_2042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2032)
static void C_ccall f_2032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1946)
static void C_ccall f_1946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1949)
static void C_ccall f_1949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1957)
static void C_fcall f_1957(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1991)
static void C_ccall f_1991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1987)
static void C_ccall f_1987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1967)
static void C_fcall f_1967(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1952)
static void C_ccall f_1952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1892)
static void C_ccall f_1892(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1896)
static void C_ccall f_1896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1901)
static void C_fcall f_1901(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1850)
static void C_fcall f_1850(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1854)
static void C_ccall f_1854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1859)
static void C_fcall f_1859(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1872)
static void C_fcall f_1872(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1841)
static void C_ccall f_1841(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1835)
static void C_ccall f_1835(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1829)
static void C_ccall f_1829(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1823)
static void C_ccall f_1823(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1811)
static void C_ccall f_1811(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1811)
static void C_ccall f_1811r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1817)
static void C_ccall f_1817(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1799)
static void C_ccall f_1799(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1799)
static void C_ccall f_1799r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1805)
static void C_ccall f_1805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1787)
static void C_ccall f_1787(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1787)
static void C_ccall f_1787r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1793)
static void C_ccall f_1793(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1775)
static void C_ccall f_1775(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1775)
static void C_ccall f_1775r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1781)
static void C_ccall f_1781(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1756)
static void C_fcall f_1756(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1760)
static void C_ccall f_1760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1765)
static void C_ccall f_1765(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1763)
static void C_ccall f_1763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1730)
static void C_fcall f_1730(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1754)
static void C_ccall f_1754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1734)
static void C_ccall f_1734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1742)
static void C_ccall f_1742(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1737)
static void C_ccall f_1737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1673)
static void C_ccall f_1673(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1677)
static void C_ccall f_1677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1682)
static void C_fcall f_1682(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1716)
static void C_ccall f_1716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1703)
static void C_ccall f_1703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1636)
static void C_ccall f_1636(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1640)
static void C_ccall f_1640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1645)
static C_word C_fcall f_1645(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_1609)
static void C_ccall f_1609(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1616)
static void C_ccall f_1616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1501)
static void C_ccall f_1501(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1501)
static void C_ccall f_1501r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1505)
static void C_ccall f_1505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1508)
static void C_fcall f_1508(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1514)
static void C_ccall f_1514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1522)
static void C_fcall f_1522(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1543)
static void C_fcall f_1543(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1567)
static C_word C_fcall f_1567(C_word t0,C_word t1);
C_noret_decl(f_1403)
static void C_ccall f_1403(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1403)
static void C_ccall f_1403r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1423)
static void C_ccall f_1423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1425)
static void C_fcall f_1425(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1435)
static void C_ccall f_1435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1452)
static void C_fcall f_1452(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1348)
static void C_ccall f_1348(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1348)
static void C_ccall f_1348r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1364)
static void C_ccall f_1364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1369)
static void C_fcall f_1369(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1393)
static void C_ccall f_1393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1334)
static void C_ccall f_1334(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1346)
static void C_ccall f_1346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1342)
static void C_ccall f_1342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1301)
static void C_fcall f_1301(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1307)
static void C_fcall f_1307(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1314)
static void C_ccall f_1314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1324)
static void C_ccall f_1324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1254)
static void C_fcall f_1254(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1299)
static void C_ccall f_1299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1279)
static void C_ccall f_1279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1286)
static void C_ccall f_1286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1244)
static void C_fcall f_1244(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1238)
static void C_ccall f_1238(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1232)
static void C_ccall f_1232(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1226)
static void C_ccall f_1226(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1220)
static C_word C_fcall f_1220(C_word t0);
C_noret_decl(f_1214)
static void C_ccall f_1214(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_3086)
static void C_fcall trf_3086(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3086(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3086(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2680)
static void C_fcall trf_2680(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2680(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2680(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2695)
static void C_fcall trf_2695(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2695(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2695(t0,t1,t2);}

C_noret_decl(trf_2639)
static void C_fcall trf_2639(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2639(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2639(t0,t1,t2);}

C_noret_decl(trf_2649)
static void C_fcall trf_2649(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2649(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2649(t0,t1,t2);}

C_noret_decl(trf_2526)
static void C_fcall trf_2526(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2526(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2526(t0,t1,t2,t3);}

C_noret_decl(trf_2532)
static void C_fcall trf_2532(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2532(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2532(t0,t1,t2);}

C_noret_decl(trf_2542)
static void C_fcall trf_2542(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2542(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2542(t0,t1);}

C_noret_decl(trf_2429)
static void C_fcall trf_2429(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2429(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2429(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2472)
static void C_fcall trf_2472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2472(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2472(t0,t1);}

C_noret_decl(trf_2385)
static void C_fcall trf_2385(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2385(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2385(t0,t1,t2,t3);}

C_noret_decl(trf_2395)
static void C_fcall trf_2395(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2395(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2395(t0,t1);}

C_noret_decl(trf_2308)
static void C_fcall trf_2308(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2308(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2308(t0,t1,t2,t3);}

C_noret_decl(trf_2270)
static void C_fcall trf_2270(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2270(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2270(t0,t1,t2,t3);}

C_noret_decl(trf_2288)
static void C_fcall trf_2288(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2288(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2288(t0,t1);}

C_noret_decl(trf_2212)
static void C_fcall trf_2212(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2212(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2212(t0,t1,t2);}

C_noret_decl(trf_2154)
static void C_fcall trf_2154(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2154(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2154(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2160)
static void C_fcall trf_2160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2160(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2160(t0,t1,t2);}

C_noret_decl(trf_2110)
static void C_fcall trf_2110(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2110(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2110(t0,t1,t2);}

C_noret_decl(trf_2061)
static void C_fcall trf_2061(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2061(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2061(t0,t1,t2);}

C_noret_decl(trf_2014)
static void C_fcall trf_2014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2014(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2014(t0,t1,t2,t3);}

C_noret_decl(trf_1957)
static void C_fcall trf_1957(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1957(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1957(t0,t1,t2);}

C_noret_decl(trf_1967)
static void C_fcall trf_1967(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1967(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1967(t0,t1);}

C_noret_decl(trf_1901)
static void C_fcall trf_1901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1901(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1901(t0,t1,t2);}

C_noret_decl(trf_1850)
static void C_fcall trf_1850(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1850(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1850(t0,t1,t2,t3);}

C_noret_decl(trf_1859)
static void C_fcall trf_1859(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1859(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1859(t0,t1,t2);}

C_noret_decl(trf_1872)
static void C_fcall trf_1872(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1872(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1872(t0,t1);}

C_noret_decl(trf_1756)
static void C_fcall trf_1756(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1756(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1756(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1730)
static void C_fcall trf_1730(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1730(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1730(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1682)
static void C_fcall trf_1682(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1682(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1682(t0,t1,t2,t3);}

C_noret_decl(trf_1508)
static void C_fcall trf_1508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1508(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1508(t0,t1);}

C_noret_decl(trf_1522)
static void C_fcall trf_1522(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1522(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1522(t0,t1,t2,t3);}

C_noret_decl(trf_1543)
static void C_fcall trf_1543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1543(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1543(t0,t1);}

C_noret_decl(trf_1425)
static void C_fcall trf_1425(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1425(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1425(t0,t1,t2,t3);}

C_noret_decl(trf_1452)
static void C_fcall trf_1452(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1452(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1452(t0,t1,t2);}

C_noret_decl(trf_1369)
static void C_fcall trf_1369(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1369(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1369(t0,t1,t2);}

C_noret_decl(trf_1301)
static void C_fcall trf_1301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1301(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1301(t0,t1,t2);}

C_noret_decl(trf_1307)
static void C_fcall trf_1307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1307(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1307(t0,t1,t2);}

C_noret_decl(trf_1254)
static void C_fcall trf_1254(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1254(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1254(t0,t1,t2);}

C_noret_decl(trf_1244)
static void C_fcall trf_1244(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1244(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1244(t0,t1);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_14_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_14_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_14_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(862)){
C_save(t1);
C_rereclaim2(862*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,108);
lf[2]=C_h_intern(&lf[2],13,"make-char-set");
lf[3]=C_h_intern(&lf[3],8,"char-set");
lf[4]=C_h_intern(&lf[4],10,"char-set:s");
lf[5]=C_h_intern(&lf[5],9,"char-set\077");
lf[7]=C_h_intern(&lf[7],9,"substring");
lf[9]=C_h_intern(&lf[9],9,"\003syserror");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000 BASE-CS parameter not a char-set");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\0003Expected final base char set -- too many parameters");
lf[12]=C_h_intern(&lf[12],11,"make-string");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\016Not a char-set");
lf[17]=C_h_intern(&lf[17],13,"char-set-copy");
lf[18]=C_h_intern(&lf[18],9,"char-set=");
lf[19]=C_h_intern(&lf[19],10,"char-set<=");
lf[20]=C_h_intern(&lf[20],13,"char-set-hash");
lf[21]=C_h_intern(&lf[21],6,"modulo");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[23]=C_h_intern(&lf[23],18,"char-set-contains\077");
lf[24]=C_h_intern(&lf[24],13,"char-set-size");
lf[25]=C_h_intern(&lf[25],14,"char-set-count");
lf[27]=C_h_intern(&lf[27],12,"\003sysfor-each");
lf[29]=C_h_intern(&lf[29],15,"char-set-adjoin");
lf[30]=C_h_intern(&lf[30],16,"char-set-adjoin!");
lf[31]=C_h_intern(&lf[31],15,"char-set-delete");
lf[32]=C_h_intern(&lf[32],16,"char-set-delete!");
lf[33]=C_h_intern(&lf[33],15,"char-set-cursor");
lf[35]=C_h_intern(&lf[35],16,"end-of-char-set\077");
lf[36]=C_h_intern(&lf[36],12,"char-set-ref");
lf[37]=C_h_intern(&lf[37],20,"char-set-cursor-next");
lf[38]=C_h_intern(&lf[38],17,"char-set-for-each");
lf[39]=C_h_intern(&lf[39],12,"char-set-map");
lf[40]=C_h_intern(&lf[40],13,"char-set-fold");
lf[41]=C_h_intern(&lf[41],14,"char-set-every");
lf[42]=C_h_intern(&lf[42],12,"char-set-any");
lf[44]=C_h_intern(&lf[44],15,"char-set-unfold");
lf[45]=C_h_intern(&lf[45],16,"char-set-unfold!");
lf[47]=C_h_intern(&lf[47],14,"list->char-set");
lf[48]=C_h_intern(&lf[48],15,"list->char-set!");
lf[49]=C_h_intern(&lf[49],14,"char-set->list");
lf[51]=C_h_intern(&lf[51],16,"string->char-set");
lf[52]=C_h_intern(&lf[52],17,"string->char-set!");
lf[53]=C_h_intern(&lf[53],16,"char-set->string");
lf[55]=C_h_intern(&lf[55],3,"min");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000`Requested UCS range contains unavailable characters -- this implementation "
"only supports Latin-1");
lf[57]=C_h_intern(&lf[57],19,"ucs-range->char-set");
lf[58]=C_h_intern(&lf[58],20,"ucs-range->char-set!");
lf[60]=C_h_intern(&lf[60],15,"char-set-filter");
lf[61]=C_h_intern(&lf[61],16,"char-set-filter!");
lf[62]=C_h_intern(&lf[62],10,"->char-set");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\036Not a charset, string or char.");
lf[66]=C_h_intern(&lf[66],19,"char-set-complement");
lf[67]=C_h_intern(&lf[67],20,"char-set-complement!");
lf[68]=C_h_intern(&lf[68],15,"char-set-union!");
lf[69]=C_h_intern(&lf[69],14,"char-set-union");
lf[70]=C_h_intern(&lf[70],14,"char-set:empty");
lf[71]=C_h_intern(&lf[71],22,"char-set-intersection!");
lf[72]=C_h_intern(&lf[72],21,"char-set-intersection");
lf[73]=C_h_intern(&lf[73],13,"char-set:full");
lf[74]=C_h_intern(&lf[74],20,"char-set-difference!");
lf[75]=C_h_intern(&lf[75],19,"char-set-difference");
lf[76]=C_h_intern(&lf[76],13,"char-set-xor!");
lf[77]=C_h_intern(&lf[77],12,"char-set-xor");
lf[79]=C_h_intern(&lf[79],27,"char-set-diff+intersection!");
lf[80]=C_h_intern(&lf[80],26,"char-set-diff+intersection");
lf[81]=C_h_intern(&lf[81],11,"string-copy");
lf[82]=C_h_intern(&lf[82],19,"char-set:lower-case");
lf[83]=C_h_intern(&lf[83],19,"char-set:upper-case");
lf[84]=C_h_intern(&lf[84],19,"char-set:title-case");
lf[85]=C_h_intern(&lf[85],15,"char-set:letter");
lf[86]=C_h_intern(&lf[86],14,"char-set:digit");
lf[87]=C_h_intern(&lf[87],18,"char-set:hex-digit");
lf[88]=C_h_intern(&lf[88],21,"char-set:letter+digit");
lf[89]=C_h_intern(&lf[89],20,"char-set:punctuation");
lf[90]=C_h_intern(&lf[90],15,"char-set:symbol");
lf[91]=C_h_intern(&lf[91],16,"char-set:graphic");
lf[92]=C_h_intern(&lf[92],19,"char-set:whitespace");
lf[93]=C_h_intern(&lf[93],17,"char-set:printing");
lf[94]=C_h_intern(&lf[94],14,"char-set:blank");
lf[95]=C_h_intern(&lf[95],20,"char-set:iso-control");
lf[96]=C_h_intern(&lf[96],14,"char-set:ascii");
lf[97]=C_h_intern(&lf[97],7,"\003sysmap");
lf[98]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\011\376\003\000\000\002\376\377\001\000\000\000 \376\003\000\000\002\376\377\001\000\000\000\240\376\377\016");
lf[99]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\011\376\003\000\000\002\376\377\001\000\000\000\012\376\003\000\000\002\376\377\001\000\000\000\013\376\003\000\000\002\376\377\001\000\000\000\014\376\003\000\000\002\376\377\001\000\000\000\015\376\003\000\000\002\376\377\001\000\000\000 \376\003\000\000\002\376\377\001"
"\000\000\000\240\376\377\016");
lf[100]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\242\376\003\000\000\002\376\377\001\000\000\000\243\376\003\000\000\002\376\377\001\000\000\000\244\376\003\000\000\002\376\377\001\000\000\000\245\376\003\000\000\002\376\377\001\000\000\000\246\376\003\000\000\002\376\377\001\000\000\000\247\376\003\000\000\002\376\377\001"
"\000\000\000\250\376\003\000\000\002\376\377\001\000\000\000\251\376\003\000\000\002\376\377\001\000\000\000\254\376\003\000\000\002\376\377\001\000\000\000\256\376\003\000\000\002\376\377\001\000\000\000\257\376\003\000\000\002\376\377\001\000\000\000\260\376\003\000\000\002\376\377\001\000\000\000\261\376\003\000\000"
"\002\376\377\001\000\000\000\264\376\003\000\000\002\376\377\001\000\000\000\266\376\003\000\000\002\376\377\001\000\000\000\270\376\003\000\000\002\376\377\001\000\000\000\327\376\003\000\000\002\376\377\001\000\000\000\367\376\377\016");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\011$+<=>^`|~");
lf[102]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\241\376\003\000\000\002\376\377\001\000\000\000\253\376\003\000\000\002\376\377\001\000\000\000\255\376\003\000\000\002\376\377\001\000\000\000\267\376\003\000\000\002\376\377\001\000\000\000\273\376\003\000\000\002\376\377\001\000\000\000\277\376\377\016");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\027!\042#%&\047()*,-./:;\077@[\134]_{}");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\0260123456789abcdefABCDEF");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\0120123456789");
lf[106]=C_h_intern(&lf[106],17,"register-feature!");
lf[107]=C_h_intern(&lf[107],7,"srfi-14");
C_register_lf2(lf,108,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1212,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 28   register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[106]+1)))(3,*((C_word*)lf[106]+1),t2,lf[107]);}

/* k1210 */
static void C_ccall f_1212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1212,2,t0,t1);}
t2=C_mutate(&lf[0] /* (set! %latin1->char ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1214,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[1] /* (set! %char->latin1 ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1220,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[2]+1 /* (set! make-char-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1226,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[4]+1 /* (set! char-set:s ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1232,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[5]+1 /* (set! char-set? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1238,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[6] /* (set! %string-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1244,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate(&lf[8] /* (set! %default-base ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1254,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[13] /* (set! %char-set:s/check ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1301,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1328,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 154  %latin1->char */
t11=lf[0];
f_1214(3,t11,t10,C_fix(0));}

/* k1326 in k1210 */
static void C_ccall f_1328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1328,2,t0,t1);}
t2=C_mutate(&lf[15] /* (set! c0 ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1332,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 155  %latin1->char */
t4=lf[0];
f_1214(3,t4,t3,C_fix(1));}

/* k1330 in k1326 in k1210 */
static void C_ccall f_1332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word ab[174],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1332,2,t0,t1);}
t2=C_mutate(&lf[16] /* (set! c1 ...) */,t1);
t3=C_mutate((C_word*)lf[17]+1 /* (set! char-set-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1334,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[18]+1 /* (set! char-set= ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1348,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[19]+1 /* (set! char-set<= ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1403,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[20]+1 /* (set! char-set-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1501,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[23]+1 /* (set! char-set-contains? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1609,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[24]+1 /* (set! char-set-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1636,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[25]+1 /* (set! char-set-count ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1673,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate(&lf[26] /* (set! %set-char-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1730,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[28] /* (set! %set-char-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1756,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[29]+1 /* (set! char-set-adjoin ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1775,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[30]+1 /* (set! char-set-adjoin! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1787,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[31]+1 /* (set! char-set-delete ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1799,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[32]+1 /* (set! char-set-delete! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1811,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[33]+1 /* (set! char-set-cursor ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1823,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[35]+1 /* (set! end-of-char-set? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1829,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[36]+1 /* (set! char-set-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1835,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[37]+1 /* (set! char-set-cursor-next ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1841,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate(&lf[34] /* (set! %char-set-cursor-next ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1850,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[38]+1 /* (set! char-set-for-each ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1892,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[39]+1 /* (set! char-set-map ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1942,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[40]+1 /* (set! char-set-fold ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2005,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[41]+1 /* (set! char-set-every ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2052,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[42]+1 /* (set! char-set-any ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2101,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate(&lf[43] /* (set! %char-set-unfold! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2154,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[44]+1 /* (set! char-set-unfold ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2190,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[45]+1 /* (set! char-set-unfold! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2202,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate(&lf[46] /* (set! %list->char-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2212,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[3]+1 /* (set! char-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2227,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[47]+1 /* (set! list->char-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2239,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[48]+1 /* (set! list->char-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2251,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[49]+1 /* (set! char-set->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2261,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate(&lf[50] /* (set! %string->char-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2308,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp));
t35=C_mutate((C_word*)lf[51]+1 /* (set! string->char-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2351,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[52]+1 /* (set! string->char-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2363,a[2]=((C_word)li65),tmp=(C_word)a,a+=3,tmp));
t37=C_mutate((C_word*)lf[53]+1 /* (set! char-set->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2373,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp));
t38=C_mutate(&lf[54] /* (set! %ucs-range->char-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2429,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t39=C_mutate((C_word*)lf[57]+1 /* (set! ucs-range->char-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2486,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp));
t40=C_mutate((C_word*)lf[58]+1 /* (set! ucs-range->char-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2516,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t41=C_mutate(&lf[59] /* (set! %char-set-filter! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2526,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[60]+1 /* (set! char-set-filter ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2579,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[61]+1 /* (set! char-set-filter! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2595,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[62]+1 /* (set! ->char-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2609,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate(&lf[64] /* (set! %string-iter ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2639,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate(&lf[65] /* (set! %char-set-algebra ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2680,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[66]+1 /* (set! char-set-complement ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2722,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[67]+1 /* (set! char-set-complement! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2750,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[68]+1 /* (set! char-set-union! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2772,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[69]+1 /* (set! char-set-union ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2798,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[71]+1 /* (set! char-set-intersection! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2847,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[72]+1 /* (set! char-set-intersection ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2869,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[74]+1 /* (set! char-set-difference! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2914,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[75]+1 /* (set! char-set-difference ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2940,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[76]+1 /* (set! char-set-xor! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2981,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[77]+1 /* (set! char-set-xor ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3022,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate(&lf[78] /* (set! %char-set-diff+intersection! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3086,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[79]+1 /* (set! char-set-diff+intersection! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3139,a[2]=((C_word)li106),tmp=(C_word)a,a+=3,tmp));
t59=C_mutate((C_word*)lf[80]+1 /* (set! char-set-diff+intersection ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3190,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp));
t60=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3219,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 643  char-set */
t61=*((C_word*)lf[3]+1);
((C_proc2)(void*)(*((C_word*)t61+1)))(2,t61,t60);}

/* k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3219,2,t0,t1);}
t2=C_mutate((C_word*)lf[70]+1 /* (set! char-set:empty ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3223,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 644  char-set-complement */
t4=*((C_word*)lf[66]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[70]+1));}

/* k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3223,2,t0,t1);}
t2=C_mutate((C_word*)lf[73]+1 /* (set! char-set:full ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3227,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 647  ucs-range->char-set */
t4=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(97),C_fix(123));}

/* k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3227,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3230,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 648  ucs-range->char-set! */
t3=*((C_word*)lf[58]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_fix(223),C_fix(247),C_SCHEME_TRUE,t1);}

/* k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3230,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3233,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 649  ucs-range->char-set! */
t3=*((C_word*)lf[58]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_fix(248),C_fix(256),C_SCHEME_TRUE,t1);}

/* k3231 in k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3236,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3335,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 650  %latin1->char */
t4=lf[0];
f_1214(3,t4,t3,C_fix(181));}

/* k3333 in k3231 in k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 650  char-set-adjoin! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[30]+1)))(4,*((C_word*)lf[30]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3234 in k3231 in k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3236,2,t0,t1);}
t2=C_mutate((C_word*)lf[82]+1 /* (set! char-set:lower-case ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3240,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 653  ucs-range->char-set */
t4=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(65),C_fix(91));}

/* k3238 in k3234 in k3231 in k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3243,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3331,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 656  ucs-range->char-set! */
t4=*((C_word*)lf[58]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,C_fix(192),C_fix(215),C_SCHEME_TRUE,t1);}

/* k3329 in k3238 in k3234 in k3231 in k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 655  ucs-range->char-set! */
t2=*((C_word*)lf[58]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],C_fix(216),C_fix(223),C_SCHEME_TRUE,t1);}

/* k3241 in k3238 in k3234 in k3231 in k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3243,2,t0,t1);}
t2=C_mutate((C_word*)lf[83]+1 /* (set! char-set:upper-case ...) */,t1);
t3=C_mutate((C_word*)lf[84]+1 /* (set! char-set:title-case ...) */,*((C_word*)lf[70]+1));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3248,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 661  char-set-union */
t5=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[83]+1),*((C_word*)lf[82]+1));}

/* k3246 in k3241 in k3238 in k3234 in k3231 in k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3248,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3251,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3323,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 663  %latin1->char */
t4=lf[0];
f_1214(3,t4,t3,C_fix(170));}

/* k3321 in k3246 in k3241 in k3238 in k3234 in k3231 in k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3327,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 664  %latin1->char */
t3=lf[0];
f_1214(3,t3,t2,C_fix(186));}

/* k3325 in k3321 in k3246 in k3241 in k3238 in k3234 in k3231 in k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 662  char-set-adjoin! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[30]+1)))(5,*((C_word*)lf[30]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3249 in k3246 in k3241 in k3238 in k3234 in k3231 in k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3251,2,t0,t1);}
t2=C_mutate((C_word*)lf[85]+1 /* (set! char-set:letter ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3255,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 666  string->char-set */
t4=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[105]);}

/* k3253 in k3249 in k3246 in k3241 in k3238 in k3234 in k3231 in k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3255,2,t0,t1);}
t2=C_mutate((C_word*)lf[86]+1 /* (set! char-set:digit ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3259,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 667  string->char-set */
t4=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[104]);}

/* k3257 in k3253 in k3249 in k3246 in k3241 in k3238 in k3234 in k3231 in k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3259,2,t0,t1);}
t2=C_mutate((C_word*)lf[87]+1 /* (set! char-set:hex-digit ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3263,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 670  char-set-union */
t4=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[85]+1),*((C_word*)lf[86]+1));}

/* k3261 in k3257 in k3253 in k3249 in k3246 in k3241 in k3238 in k3234 in k3231 in k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3263,2,t0,t1);}
t2=C_mutate((C_word*)lf[88]+1 /* (set! char-set:letter+digit ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3267,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 673  string->char-set */
t4=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[103]);}

/* k3265 in k3261 in k3257 in k3253 in k3249 in k3246 in k3241 in k3238 in k3234 in k3231 in k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3270,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[0],lf[102]);}

/* k3268 in k3265 in k3261 in k3257 in k3253 in k3249 in k3246 in k3241 in k3238 in k3234 in k3231 in k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3273,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 680  list->char-set! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[48]+1)))(4,*((C_word*)lf[48]+1),t2,t1,((C_word*)t0)[2]);}

/* k3271 in k3268 in k3265 in k3261 in k3257 in k3253 in k3249 in k3246 in k3241 in k3238 in k3234 in k3231 in k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3273,2,t0,t1);}
t2=C_mutate((C_word*)lf[89]+1 /* (set! char-set:punctuation ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3277,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 683  string->char-set */
t4=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[101]);}

/* k3275 in k3271 in k3268 in k3265 in k3261 in k3257 in k3253 in k3249 in k3246 in k3241 in k3238 in k3234 in k3231 in k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3280,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[0],lf[100]);}

/* k3278 in k3275 in k3271 in k3268 in k3265 in k3261 in k3257 in k3253 in k3249 in k3246 in k3241 in k3238 in k3234 in k3231 in k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3283,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 702  list->char-set! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[48]+1)))(4,*((C_word*)lf[48]+1),t2,t1,((C_word*)t0)[2]);}

/* k3281 in k3278 in k3275 in k3271 in k3268 in k3265 in k3261 in k3257 in k3253 in k3249 in k3246 in k3241 in k3238 in k3234 in k3231 in k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3283,2,t0,t1);}
t2=C_mutate((C_word*)lf[90]+1 /* (set! char-set:symbol ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3287,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 706  char-set-union */
t4=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,*((C_word*)lf[88]+1),*((C_word*)lf[89]+1),*((C_word*)lf[90]+1));}

/* k3285 in k3281 in k3278 in k3275 in k3271 in k3268 in k3265 in k3261 in k3257 in k3253 in k3249 in k3246 in k3241 in k3238 in k3234 in k3231 in k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3287,2,t0,t1);}
t2=C_mutate((C_word*)lf[91]+1 /* (set! char-set:graphic ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3291,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3319,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[0],lf[99]);}

/* k3317 in k3285 in k3281 in k3278 in k3275 in k3271 in k3268 in k3265 in k3261 in k3257 in k3253 in k3249 in k3246 in k3241 in k3238 in k3234 in k3231 in k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 709  list->char-set */
t2=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3289 in k3285 in k3281 in k3278 in k3275 in k3271 in k3268 in k3265 in k3261 in k3257 in k3253 in k3249 in k3246 in k3241 in k3238 in k3234 in k3231 in k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3291,2,t0,t1);}
t2=C_mutate((C_word*)lf[92]+1 /* (set! char-set:whitespace ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3295,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 717  char-set-union */
t4=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[92]+1),*((C_word*)lf[91]+1));}

/* k3293 in k3289 in k3285 in k3281 in k3278 in k3275 in k3271 in k3268 in k3265 in k3261 in k3257 in k3253 in k3249 in k3246 in k3241 in k3238 in k3234 in k3231 in k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3295,2,t0,t1);}
t2=C_mutate((C_word*)lf[93]+1 /* (set! char-set:printing ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3299,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3315,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[0],lf[98]);}

/* k3313 in k3293 in k3289 in k3285 in k3281 in k3278 in k3275 in k3271 in k3268 in k3265 in k3261 in k3257 in k3253 in k3249 in k3246 in k3241 in k3238 in k3234 in k3231 in k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 720  list->char-set */
t2=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3297 in k3293 in k3289 in k3285 in k3281 in k3278 in k3275 in k3271 in k3268 in k3265 in k3261 in k3257 in k3253 in k3249 in k3246 in k3241 in k3238 in k3234 in k3231 in k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3299,2,t0,t1);}
t2=C_mutate((C_word*)lf[94]+1 /* (set! char-set:blank ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3303,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3311,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 726  ucs-range->char-set */
t5=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_fix(0),C_fix(32));}

/* k3309 in k3297 in k3293 in k3289 in k3285 in k3281 in k3278 in k3275 in k3271 in k3268 in k3265 in k3261 in k3257 in k3253 in k3249 in k3246 in k3241 in k3238 in k3234 in k3231 in k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 726  ucs-range->char-set! */
t2=*((C_word*)lf[58]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],C_fix(127),C_fix(160),C_SCHEME_TRUE,t1);}

/* k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3278 in k3275 in k3271 in k3268 in k3265 in k3261 in k3257 in k3253 in k3249 in k3246 in k3241 in k3238 in k3234 in k3231 in k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3303,2,t0,t1);}
t2=C_mutate((C_word*)lf[95]+1 /* (set! char-set:iso-control ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3307,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 728  ucs-range->char-set */
t4=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(0),C_fix(128));}

/* k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3278 in k3275 in k3271 in k3268 in k3265 in k3261 in k3257 in k3253 in k3249 in k3246 in k3241 in k3238 in k3234 in k3231 in k3228 in k3225 in k3221 in k3217 in k1330 in k1326 in k1210 */
static void C_ccall f_3307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[96]+1 /* (set! char-set:ascii ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* char-set-diff+intersection in k1330 in k1326 in k1210 */
static void C_ccall f_3190(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_3190r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3190r(t0,t1,t2,t3);}}

static void C_ccall f_3190r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3194,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3215,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 629  %char-set:s/check */
f_1301(t5,t2,lf[80]);}

/* k3213 in char-set-diff+intersection in k1330 in k1326 in k1210 */
static void C_ccall f_3215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 629  string-copy */
t2=*((C_word*)lf[81]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3192 in char-set-diff+intersection in k1330 in k1326 in k1210 */
static void C_ccall f_3194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3197,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 630  make-string */
t3=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(256),lf[15]);}

/* k3195 in k3192 in char-set-diff+intersection in k1330 in k1326 in k1210 */
static void C_ccall f_3197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3197,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3200,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 631  %char-set-diff+intersection! */
f_3086(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],lf[80]);}

/* k3198 in k3195 in k3192 in char-set-diff+intersection in k1330 in k1326 in k1210 */
static void C_ccall f_3200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3207,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 632  make-char-set */
t3=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3205 in k3198 in k3195 in k3192 in char-set-diff+intersection in k1330 in k1326 in k1210 */
static void C_ccall f_3207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3211,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 632  make-char-set */
t3=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3209 in k3205 in k3198 in k3195 in k3192 in char-set-diff+intersection in k1330 in k1326 in k1210 */
static void C_ccall f_3211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 632  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* char-set-diff+intersection! in k1330 in k1326 in k1210 */
static void C_ccall f_3139(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_3139r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3139r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3139r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3143,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-14.scm: 619  %char-set:s/check */
f_1301(t5,t2,lf[79]);}

/* k3141 in char-set-diff+intersection! in k1330 in k1326 in k1210 */
static void C_ccall f_3143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3143,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3146,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* srfi-14.scm: 620  %char-set:s/check */
f_1301(t2,((C_word*)t0)[3],lf[79]);}

/* k3144 in k3141 in char-set-diff+intersection! in k1330 in k1326 in k1210 */
static void C_ccall f_3146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3146,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3149,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3157,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li105),tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 621  %string-iter */
f_2639(t2,t3,((C_word*)t0)[3]);}

/* a3156 in k3144 in k3141 in char-set-diff+intersection! in k1330 in k1326 in k1210 */
static void C_ccall f_3157(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3157,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_string_set(((C_word*)t0)[3],t5,lf[15]));}
else{
t5=t2;
t6=(C_word)C_i_string_ref(((C_word*)t0)[3],t5);
t7=f_1220(t6);
t8=(C_word)C_eqp(t7,C_fix(0));
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}
else{
t9=t2;
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_i_string_set(((C_word*)t0)[2],t9,lf[15]));}}}

/* k3147 in k3144 in k3141 in char-set-diff+intersection! in k1330 in k1326 in k1210 */
static void C_ccall f_3149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3149,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3152,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 625  %char-set-diff+intersection! */
f_3086(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[79]);}

/* k3150 in k3147 in k3144 in k3141 in char-set-diff+intersection! in k1330 in k1326 in k1210 */
static void C_ccall f_3152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 626  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-diff+intersection! in k1330 in k1326 in k1210 */
static void C_fcall f_3086(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3086,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3092,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=((C_word)li103),tmp=(C_word)a,a+=6,tmp);
/* for-each */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t4);}

/* a3091 in %char-set-diff+intersection! in k1330 in k1326 in k1210 */
static void C_ccall f_3092(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3092,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3098,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li102),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3137,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 615  %char-set:s/check */
f_1301(t4,t2,((C_word*)t0)[2]);}

/* k3135 in a3091 in %char-set-diff+intersection! in k1330 in k1326 in k1210 */
static void C_ccall f_3137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 610  %string-iter */
f_2639(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3097 in a3091 in %char-set-diff+intersection! in k1330 in k1326 in k1210 */
static void C_ccall f_3098(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3098,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=((C_word*)t0)[3];
t6=t2;
t7=(C_word)C_i_string_ref(t5,t6);
t8=f_1220(t7);
t9=(C_word)C_eqp(t8,C_fix(0));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}
else{
t10=((C_word*)t0)[3];
t11=t2;
t12=(C_word)C_i_string_set(t10,t11,lf[15]);
t13=((C_word*)t0)[2];
t14=t2;
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_i_string_set(t13,t14,lf[16]));}}}

/* char-set-xor in k1330 in k1326 in k1210 */
static void C_ccall f_3022(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_3022r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3022r(t0,t1,t2);}}

static void C_ccall f_3022r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3032,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3077,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(t2);
/* srfi-14.scm: 600  %char-set:s/check */
f_1301(t4,t5,lf[77]);}
else{
/* srfi-14.scm: 603  char-set-copy */
t3=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,*((C_word*)lf[70]+1));}}

/* k3075 in char-set-xor in k1330 in k1326 in k1210 */
static void C_ccall f_3077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 600  %string-copy */
f_1244(((C_word*)t0)[2],t1);}

/* k3030 in char-set-xor in k1330 in k1326 in k1210 */
static void C_ccall f_3032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3035,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3044,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 601  %char-set-algebra */
f_2680(t2,t1,t3,t4,lf[77]);}

/* a3043 in k3030 in char-set-xor in k1330 in k1326 in k1210 */
static void C_ccall f_3044(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3044,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=t2;
t7=t3;
t8=t2;
t9=t3;
t10=(C_word)C_i_string_ref(t8,t9);
t11=f_1220(t10);
t12=(C_word)C_fixnum_difference(C_fix(1),t11);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3061,a[2]=t7,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 160  %latin1->char */
t14=lf[0];
f_1214(3,t14,t13,t12);}}

/* k3059 in a3043 in k3030 in char-set-xor in k1330 in k1326 in k1210 */
static void C_ccall f_3061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_string_set(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k3033 in k3030 in char-set-xor in k1330 in k1326 in k1210 */
static void C_ccall f_3035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 602  make-char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-xor! in k1330 in k1326 in k1210 */
static void C_ccall f_2981(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2981r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2981r(t0,t1,t2,t3);}}

static void C_ccall f_2981r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2985,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2989,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 594  %char-set:s/check */
f_1301(t5,t2,lf[76]);}

/* k2987 in char-set-xor! in k1330 in k1326 in k1210 */
static void C_ccall f_2989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2991,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 594  %char-set-algebra */
f_2680(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[76]);}

/* a2990 in k2987 in char-set-xor! in k1330 in k1326 in k1210 */
static void C_ccall f_2991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2991,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=t2;
t7=t3;
t8=t2;
t9=t3;
t10=(C_word)C_i_string_ref(t8,t9);
t11=f_1220(t10);
t12=(C_word)C_fixnum_difference(C_fix(1),t11);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3008,a[2]=t7,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 160  %latin1->char */
t14=lf[0];
f_1214(3,t14,t13,t12);}}

/* k3006 in a2990 in k2987 in char-set-xor! in k1330 in k1326 in k1210 */
static void C_ccall f_3008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_string_set(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2983 in char-set-xor! in k1330 in k1326 in k1210 */
static void C_ccall f_2985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-difference in k1330 in k1326 in k1210 */
static void C_ccall f_2940(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_2940r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2940r(t0,t1,t2,t3);}}

static void C_ccall f_2940r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2950,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2976,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 585  %char-set:s/check */
f_1301(t5,t2,lf[75]);}
else{
/* srfi-14.scm: 588  char-set-copy */
t4=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}}

/* k2974 in char-set-difference in k1330 in k1326 in k1210 */
static void C_ccall f_2976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 585  %string-copy */
f_1244(((C_word*)t0)[2],t1);}

/* k2948 in char-set-difference in k1330 in k1326 in k1210 */
static void C_ccall f_2950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2953,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2958,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 586  %char-set-algebra */
f_2680(t2,t1,((C_word*)t0)[2],t3,lf[75]);}

/* a2957 in k2948 in char-set-difference in k1330 in k1326 in k1210 */
static void C_ccall f_2958(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2958,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?C_SCHEME_UNDEFINED:(C_word)C_i_string_set(t2,t3,lf[15])));}

/* k2951 in k2948 in char-set-difference in k1330 in k1326 in k1210 */
static void C_ccall f_2953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 587  make-char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-difference! in k1330 in k1326 in k1210 */
static void C_ccall f_2914(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2914r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2914r(t0,t1,t2,t3);}}

static void C_ccall f_2914r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2918,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2922,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 579  %char-set:s/check */
f_1301(t5,t2,lf[74]);}

/* k2920 in char-set-difference! in k1330 in k1326 in k1210 */
static void C_ccall f_2922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2924,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 579  %char-set-algebra */
f_2680(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[74]);}

/* a2923 in k2920 in char-set-difference! in k1330 in k1326 in k1210 */
static void C_ccall f_2924(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2924,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?C_SCHEME_UNDEFINED:(C_word)C_i_string_set(t2,t3,lf[15])));}

/* k2916 in char-set-difference! in k1330 in k1326 in k1210 */
static void C_ccall f_2918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-intersection in k1330 in k1326 in k1210 */
static void C_ccall f_2869(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2869r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2869r(t0,t1,t2);}}

static void C_ccall f_2869r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2879,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2905,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(t2);
/* srfi-14.scm: 570  %char-set:s/check */
f_1301(t4,t5,lf[72]);}
else{
/* srfi-14.scm: 573  char-set-copy */
t3=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,*((C_word*)lf[73]+1));}}

/* k2903 in char-set-intersection in k1330 in k1326 in k1210 */
static void C_ccall f_2905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 570  %string-copy */
f_1244(((C_word*)t0)[2],t1);}

/* k2877 in char-set-intersection in k1330 in k1326 in k1210 */
static void C_ccall f_2879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2882,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2891,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 571  %char-set-algebra */
f_2680(t2,t1,t3,t4,lf[72]);}

/* a2890 in k2877 in char-set-intersection in k1330 in k1326 in k1210 */
static void C_ccall f_2891(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2891,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?(C_word)C_i_string_set(t2,t3,lf[15]):C_SCHEME_UNDEFINED));}

/* k2880 in k2877 in char-set-intersection in k1330 in k1326 in k1210 */
static void C_ccall f_2882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 572  make-char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-intersection! in k1330 in k1326 in k1210 */
static void C_ccall f_2847(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2847r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2847r(t0,t1,t2,t3);}}

static void C_ccall f_2847r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2851,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2855,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 564  %char-set:s/check */
f_1301(t5,t2,lf[71]);}

/* k2853 in char-set-intersection! in k1330 in k1326 in k1210 */
static void C_ccall f_2855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2857,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 564  %char-set-algebra */
f_2680(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[71]);}

/* a2856 in k2853 in char-set-intersection! in k1330 in k1326 in k1210 */
static void C_ccall f_2857(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2857,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?(C_word)C_i_string_set(t2,t3,lf[15]):C_SCHEME_UNDEFINED));}

/* k2849 in char-set-intersection! in k1330 in k1326 in k1210 */
static void C_ccall f_2851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-union in k1330 in k1326 in k1210 */
static void C_ccall f_2798(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2798r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2798r(t0,t1,t2);}}

static void C_ccall f_2798r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2808,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2838,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(t2);
/* srfi-14.scm: 555  %char-set:s/check */
f_1301(t4,t5,lf[69]);}
else{
/* srfi-14.scm: 558  char-set-copy */
t3=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,*((C_word*)lf[70]+1));}}

/* k2836 in char-set-union in k1330 in k1326 in k1210 */
static void C_ccall f_2838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 555  %string-copy */
f_1244(((C_word*)t0)[2],t1);}

/* k2806 in char-set-union in k1330 in k1326 in k1210 */
static void C_ccall f_2808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2808,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2811,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2820,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 556  %char-set-algebra */
f_2680(t2,t1,t3,t4,lf[69]);}

/* a2819 in k2806 in char-set-union in k1330 in k1326 in k1210 */
static void C_ccall f_2820(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2820,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?C_SCHEME_UNDEFINED:(C_word)C_i_string_set(t2,t3,lf[16])));}

/* k2809 in k2806 in char-set-union in k1330 in k1326 in k1210 */
static void C_ccall f_2811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 557  make-char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-union! in k1330 in k1326 in k1210 */
static void C_ccall f_2772(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2772r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2772r(t0,t1,t2,t3);}}

static void C_ccall f_2772r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2776,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2780,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 549  %char-set:s/check */
f_1301(t5,t2,lf[68]);}

/* k2778 in char-set-union! in k1330 in k1326 in k1210 */
static void C_ccall f_2780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2780,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2782,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 549  %char-set-algebra */
f_2680(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[68]);}

/* a2781 in k2778 in char-set-union! in k1330 in k1326 in k1210 */
static void C_ccall f_2782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2782,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?C_SCHEME_UNDEFINED:(C_word)C_i_string_set(t2,t3,lf[16])));}

/* k2774 in char-set-union! in k1330 in k1326 in k1210 */
static void C_ccall f_2776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-complement! in k1330 in k1326 in k1210 */
static void C_ccall f_2750(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2750,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2754,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 541  %char-set:s/check */
f_1301(t3,t2,lf[67]);}

/* k2752 in char-set-complement! in k1330 in k1326 in k1210 */
static void C_ccall f_2754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2757,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2759,a[2]=t1,a[3]=((C_word)li84),tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 542  %string-iter */
f_2639(t2,t3,t1);}

/* a2758 in k2752 in char-set-complement! in k1330 in k1326 in k1210 */
static void C_ccall f_2759(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2759,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(C_fix(1),t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2770,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 160  %latin1->char */
t6=lf[0];
f_1214(3,t6,t5,t4);}

/* k2768 in a2758 in k2752 in char-set-complement! in k1330 in k1326 in k1210 */
static void C_ccall f_2770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_string_set(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2755 in k2752 in char-set-complement! in k1330 in k1326 in k1210 */
static void C_ccall f_2757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-complement in k1330 in k1326 in k1210 */
static void C_ccall f_2722(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2722,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2726,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 535  %char-set:s/check */
f_1301(t3,t2,lf[66]);}

/* k2724 in char-set-complement in k1330 in k1326 in k1210 */
static void C_ccall f_2726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2726,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2729,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 536  make-string */
t3=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(256));}

/* k2727 in k2724 in char-set-complement in k1330 in k1326 in k1210 */
static void C_ccall f_2729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2732,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2737,a[2]=t1,a[3]=((C_word)li82),tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 537  %string-iter */
f_2639(t2,t3,((C_word*)t0)[2]);}

/* a2736 in k2727 in k2724 in char-set-complement in k1330 in k1326 in k1210 */
static void C_ccall f_2737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2737,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(C_fix(1),t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2748,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 160  %latin1->char */
t6=lf[0];
f_1214(3,t6,t5,t4);}

/* k2746 in a2736 in k2727 in k2724 in char-set-complement in k1330 in k1326 in k1210 */
static void C_ccall f_2748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_string_set(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2730 in k2727 in k2724 in char-set-complement in k1330 in k1326 in k1210 */
static void C_ccall f_2732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 538  make-char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-algebra in k1330 in k1326 in k1210 */
static void C_fcall f_2680(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2680,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2686,a[2]=t5,a[3]=t2,a[4]=t4,a[5]=((C_word)li80),tmp=(C_word)a,a+=6,tmp);
/* for-each */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t3);}

/* a2685 in %char-set-algebra in k1330 in k1326 in k1210 */
static void C_ccall f_2686(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2686,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2690,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 524  %char-set:s/check */
f_1301(t3,t2,((C_word*)t0)[2]);}

/* k2688 in a2685 in %char-set-algebra in k1330 in k1326 in k1210 */
static void C_ccall f_2690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2690,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2695,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,a[6]=((C_word)li79),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2695(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k2688 in a2685 in %char-set-algebra in k1330 in k1326 in k1210 */
static void C_fcall f_2695(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2695,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2705,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_i_string_ref(((C_word*)t0)[4],t5);
t7=f_1220(t6);
/* srfi-14.scm: 527  op */
t8=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t8))(5,t8,t4,((C_word*)t0)[2],t2,t7);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2703 in lp in k2688 in a2685 in %char-set-algebra in k1330 in k1326 in k1210 */
static void C_ccall f_2705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 528  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2695(t3,((C_word*)t0)[2],t2);}

/* %string-iter in k1330 in k1326 in k1210 */
static void C_fcall f_2639(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2639,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_string_length(t3);
t5=(C_word)C_fixnum_difference(t4,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2649,a[2]=t2,a[3]=t3,a[4]=t7,a[5]=((C_word)li77),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_2649(t9,t1,t5);}

/* lp in %string-iter in k1330 in k1326 in k1210 */
static void C_fcall f_2649(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2649,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2659,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t6=f_1220(t5);
/* srfi-14.scm: 513  p */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t2,t6);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2657 in lp in %string-iter in k1330 in k1326 in k1210 */
static void C_ccall f_2659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 514  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2649(t3,((C_word*)t0)[2],t2);}

/* ->char-set in k1330 in k1326 in k1210 */
static void C_ccall f_2609(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2609,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2616,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 490  char-set? */
t4=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2614 in ->char-set in k1330 in k1326 in k1210 */
static void C_ccall f_2616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[2]))){
/* srfi-14.scm: 491  string->char-set */
t2=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[2]))){
/* srfi-14.scm: 492  char-set */
t2=*((C_word*)lf[3]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-14.scm: 493  ##sys#error */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[62],lf[63],((C_word*)t0)[2]);}}}}

/* char-set-filter! in k1330 in k1326 in k1210 */
static void C_ccall f_2595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2595,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2599,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2603,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 481  %char-set:s/check */
f_1301(t6,t3,lf[61]);}

/* k2601 in char-set-filter! in k1330 in k1326 in k1210 */
static void C_ccall f_2603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2607,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 482  %char-set:s/check */
f_1301(t2,((C_word*)t0)[2],lf[61]);}

/* k2605 in k2601 in char-set-filter! in k1330 in k1326 in k1210 */
static void C_ccall f_2607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 480  %char-set-filter! */
f_2526(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2597 in char-set-filter! in k1330 in k1326 in k1210 */
static void C_ccall f_2599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-filter in k1330 in k1326 in k1210 */
static void C_ccall f_2579(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_2579r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2579r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2579r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2583,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 472  %default-base */
f_1254(t5,t4,*((C_word*)lf[60]+1));}

/* k2581 in char-set-filter in k1330 in k1326 in k1210 */
static void C_ccall f_2583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2586,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2593,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 474  %char-set:s/check */
f_1301(t3,((C_word*)t0)[2],lf[61]);}

/* k2591 in k2581 in char-set-filter in k1330 in k1326 in k1210 */
static void C_ccall f_2593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 473  %char-set-filter! */
f_2526(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2584 in k2581 in char-set-filter in k1330 in k1326 in k1210 */
static void C_ccall f_2586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 477  make-char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-filter! in k1330 in k1326 in k1210 */
static void C_fcall f_2526(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2526,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2532,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t6,a[6]=((C_word)li72),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_2532(t8,t1,C_fix(255));}

/* lp in %char-set-filter! in k1330 in k1326 in k1210 */
static void C_fcall f_2532(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2532,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2542,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2552,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)t0)[3];
t7=t2;
t8=(C_word)C_i_string_ref(t6,t7);
t9=f_1220(t8);
t10=(C_word)C_eqp(t9,C_fix(0));
if(C_truep(t10)){
t11=t5;
f_2552(2,t11,C_SCHEME_FALSE);}
else{
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2565,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 467  %latin1->char */
t12=lf[0];
f_1214(3,t12,t11,t2);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2563 in lp in %char-set-filter! in k1330 in k1326 in k1210 */
static void C_ccall f_2565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 467  pred */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2550 in lp in %char-set-filter! in k1330 in k1326 in k1210 */
static void C_ccall f_2552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
f_2542(t4,(C_word)C_i_string_set(t2,t3,lf[16]));}
else{
t2=((C_word*)t0)[2];
f_2542(t2,C_SCHEME_UNDEFINED);}}

/* k2540 in lp in %char-set-filter! in k1330 in k1326 in k1210 */
static void C_fcall f_2542(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 469  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2532(t3,((C_word*)t0)[2],t2);}

/* ucs-range->char-set! in k1330 in k1326 in k1210 */
static void C_ccall f_2516(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2516,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2520,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2524,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* srfi-14.scm: 456  %char-set:s/check */
f_1301(t7,t5,lf[58]);}

/* k2522 in ucs-range->char-set! in k1330 in k1326 in k1210 */
static void C_ccall f_2524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 455  %ucs-range->char-set! */
f_2429(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[57]);}

/* k2518 in ucs-range->char-set! in k1330 in k1326 in k1210 */
static void C_ccall f_2520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ucs-range->char-set in k1330 in k1326 in k1210 */
static void C_ccall f_2486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2486r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2486r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2486r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_car(t4));
t7=(C_word)C_i_nullp(t4);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t4));
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2496,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-14.scm: 450  %default-base */
f_1254(t9,t8,*((C_word*)lf[57]+1));}

/* k2494 in ucs-range->char-set in k1330 in k1326 in k1210 */
static void C_ccall f_2496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2496,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2499,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 451  %ucs-range->char-set! */
f_2429(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[57]);}

/* k2497 in k2494 in ucs-range->char-set in k1330 in k1326 in k1210 */
static void C_ccall f_2499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 452  make-char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %ucs-range->char-set! in k1330 in k1326 in k1210 */
static void C_fcall f_2429(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2429,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_exact_2(t2,t6);
t8=(C_word)C_i_check_exact_2(t3,t6);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2439,a[2]=t3,a[3]=t1,a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2472,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
t11=t2;
t12=t3;
if(C_truep((C_word)C_fixnum_lessp(t11,t12))){
t13=t3;
t14=(C_word)C_fixnum_lessp(C_fix(256),t13);
t15=t10;
f_2472(t15,(C_truep(t14)?t4:C_SCHEME_FALSE));}
else{
t13=t10;
f_2472(t13,C_SCHEME_FALSE);}}

/* k2470 in %ucs-range->char-set! in k1330 in k1326 in k1210 */
static void C_fcall f_2472(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-14.scm: 442  ##sys#error */
t2=*((C_word*)lf[9]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],lf[56],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_2439(2,t2,C_SCHEME_UNDEFINED);}}

/* k2437 in %ucs-range->char-set! in k1330 in k1326 in k1210 */
static void C_ccall f_2439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2469,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 445  min */
t3=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(256));}

/* k2467 in k2437 in %ucs-range->char-set! in k1330 in k1326 in k1210 */
static void C_ccall f_2469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2469,2,t0,t1);}
t2=(C_word)C_fixnum_difference(t1,C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2448,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li68),tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_2448(t3,t2));}

/* lp in k2467 in k2437 in %ucs-range->char-set! in k1330 in k1326 in k1210 */
static C_word C_fcall f_2448(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
t2=((C_word*)t0)[3];
t3=t1;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t3))){
t4=((C_word*)t0)[2];
t5=t1;
t6=(C_word)C_i_string_set(t4,t5,lf[16]);
t7=(C_word)C_fixnum_difference(t1,C_fix(1));
t9=t7;
t1=t9;
goto loop;}
else{
return(C_SCHEME_UNDEFINED);}}

/* char-set->string in k1330 in k1326 in k1210 */
static void C_ccall f_2373(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2373,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2377,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 423  %char-set:s/check */
f_1301(t3,t2,lf[53]);}

/* k2375 in char-set->string in k1330 in k1326 in k1210 */
static void C_ccall f_2377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2380,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2427,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 424  char-set-size */
t4=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2425 in k2375 in char-set->string in k1330 in k1326 in k1210 */
static void C_ccall f_2427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 424  make-string */
t2=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2378 in k2375 in char-set->string in k1330 in k1326 in k1210 */
static void C_ccall f_2380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2380,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2385,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word)li66),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2385(t5,((C_word*)t0)[2],C_fix(255),C_fix(0));}

/* lp in k2378 in k2375 in char-set->string in k1330 in k1326 in k1210 */
static void C_fcall f_2385(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2385,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2395,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=t2;
t7=(C_word)C_i_string_ref(((C_word*)t0)[2],t6);
t8=f_1220(t7);
t9=(C_word)C_eqp(t8,C_fix(0));
if(C_truep(t9)){
t10=t5;
f_2395(t10,t3);}
else{
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2415,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 428  %latin1->char */
t11=lf[0];
f_1214(3,t11,t10,t2);}}}

/* k2413 in lp in k2378 in k2375 in char-set->string in k1330 in k1326 in k1210 */
static void C_ccall f_2415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_string_set(((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_2395(t3,(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1)));}

/* k2393 in lp in k2378 in k2375 in char-set->string in k1330 in k1326 in k1210 */
static void C_fcall f_2395(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 430  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2385(t3,((C_word*)t0)[2],t2,t1);}

/* string->char-set! in k1330 in k1326 in k1210 */
static void C_ccall f_2363(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2363,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2367,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2371,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 417  %char-set:s/check */
f_1301(t5,t3,lf[52]);}

/* k2369 in string->char-set! in k1330 in k1326 in k1210 */
static void C_ccall f_2371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 417  %string->char-set! */
f_2308(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[52]);}

/* k2365 in string->char-set! in k1330 in k1326 in k1210 */
static void C_ccall f_2367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* string->char-set in k1330 in k1326 in k1210 */
static void C_ccall f_2351(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2351r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2351r(t0,t1,t2,t3);}}

static void C_ccall f_2351r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2355,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 412  %default-base */
f_1254(t4,t3,*((C_word*)lf[51]+1));}

/* k2353 in string->char-set in k1330 in k1326 in k1210 */
static void C_ccall f_2355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2358,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 413  %string->char-set! */
f_2308(t2,((C_word*)t0)[2],t1,lf[51]);}

/* k2356 in k2353 in string->char-set in k1330 in k1326 in k1210 */
static void C_ccall f_2358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 414  make-char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string->char-set! in k1330 in k1326 in k1210 */
static void C_fcall f_2308(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2308,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(C_word)C_i_string_length(t2);
t7=(C_word)C_fixnum_difference(t6,C_fix(1));
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2321,a[2]=t2,a[3]=t3,a[4]=((C_word)li62),tmp=(C_word)a,a+=5,tmp);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,f_2321(t8,t7));}

/* doloop613 in %string->char-set! in k1330 in k1326 in k1210 */
static C_word C_fcall f_2321(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
t2=t1;
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
return(C_SCHEME_UNDEFINED);}
else{
t3=((C_word*)t0)[3];
t4=(C_word)C_i_string_ref(((C_word*)t0)[2],t1);
t5=f_1220(t4);
t6=(C_word)C_i_string_set(t3,t5,lf[16]);
t7=(C_word)C_fixnum_difference(t1,C_fix(1));
t9=t7;
t1=t9;
goto loop;}}

/* char-set->list in k1330 in k1326 in k1210 */
static void C_ccall f_2261(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2261,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2265,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 393  %char-set:s/check */
f_1301(t3,t2,lf[49]);}

/* k2263 in char-set->list in k1330 in k1326 in k1210 */
static void C_ccall f_2265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2265,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2270,a[2]=t1,a[3]=t3,a[4]=((C_word)li60),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2270(t5,((C_word*)t0)[2],C_fix(255),C_SCHEME_END_OF_LIST);}

/* lp in k2263 in char-set->list in k1330 in k1326 in k1210 */
static void C_fcall f_2270(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2270,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2288,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=t2;
t8=(C_word)C_i_string_ref(((C_word*)t0)[2],t7);
t9=f_1220(t8);
t10=(C_word)C_eqp(t9,C_fix(0));
if(C_truep(t10)){
t11=t6;
f_2288(t11,t3);}
else{
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2298,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 398  %latin1->char */
t12=lf[0];
f_1214(3,t12,t11,t2);}}}

/* k2296 in lp in k2263 in char-set->list in k1330 in k1326 in k1210 */
static void C_ccall f_2298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2298,2,t0,t1);}
t2=((C_word*)t0)[3];
f_2288(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k2286 in lp in k2263 in char-set->list in k1330 in k1326 in k1210 */
static void C_fcall f_2288(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 396  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2270(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* list->char-set! in k1330 in k1326 in k1210 */
static void C_ccall f_2251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2251,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2255,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2259,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 388  %char-set:s/check */
f_1301(t5,t3,lf[48]);}

/* k2257 in list->char-set! in k1330 in k1326 in k1210 */
static void C_ccall f_2259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 388  %list->char-set! */
f_2212(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2253 in list->char-set! in k1330 in k1326 in k1210 */
static void C_ccall f_2255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* list->char-set in k1330 in k1326 in k1210 */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2239r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2239r(t0,t1,t2,t3);}}

static void C_ccall f_2239r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2243,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 383  %default-base */
f_1254(t4,t3,*((C_word*)lf[47]+1));}

/* k2241 in list->char-set in k1330 in k1326 in k1210 */
static void C_ccall f_2243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2246,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 384  %list->char-set! */
f_2212(t2,((C_word*)t0)[2],t1);}

/* k2244 in k2241 in list->char-set in k1330 in k1326 in k1210 */
static void C_ccall f_2246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 385  make-char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set in k1330 in k1326 in k1210 */
static void C_ccall f_2227(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2227r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2227r(t0,t1,t2);}}

static void C_ccall f_2227r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2231,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 378  make-string */
t4=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(256),lf[15]);}

/* k2229 in char-set in k1330 in k1326 in k1210 */
static void C_ccall f_2231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2231,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2234,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 379  %list->char-set! */
f_2212(t2,((C_word*)t0)[2],t1);}

/* k2232 in k2229 in char-set in k1330 in k1326 in k1210 */
static void C_ccall f_2234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 380  make-char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %list->char-set! in k1330 in k1326 in k1210 */
static void C_fcall f_2212(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2212,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2218,a[2]=t3,a[3]=((C_word)li55),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a2217 in %list->char-set! in k1330 in k1326 in k1210 */
static void C_ccall f_2218(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2218,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
t4=f_1220(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_string_set(t3,t4,lf[16]));}

/* char-set-unfold! in k1330 in k1326 in k1210 */
static void C_ccall f_2202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_2202,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2206,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2210,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* srfi-14.scm: 365  %char-set:s/check */
f_1301(t8,t6,lf[45]);}

/* k2208 in char-set-unfold! in k1330 in k1326 in k1210 */
static void C_ccall f_2210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 364  %char-set-unfold! */
f_2154(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2204 in char-set-unfold! in k1330 in k1326 in k1210 */
static void C_ccall f_2206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-unfold in k1330 in k1326 in k1210 */
static void C_ccall f_2190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc_2(c,6,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr6r,(void*)f_2190r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_2190r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_2190r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word *a=C_alloc(7);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2194,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-14.scm: 359  %default-base */
f_1254(t7,t6,*((C_word*)lf[44]+1));}

/* k2192 in char-set-unfold in k1330 in k1326 in k1210 */
static void C_ccall f_2194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2197,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 360  %char-set-unfold! */
f_2154(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2195 in k2192 in char-set-unfold in k1330 in k1326 in k1210 */
static void C_ccall f_2197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 361  make-char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-unfold! in k1330 in k1326 in k1210 */
static void C_fcall f_2154(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2154,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2160,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t8,a[6]=t5,a[7]=((C_word)li51),tmp=(C_word)a,a+=8,tmp));
t10=((C_word*)t8)[1];
f_2160(t10,t1,t6);}

/* lp in %char-set-unfold! in k1330 in k1326 in k1210 */
static void C_fcall f_2160(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2160,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2188,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* srfi-14.scm: 354  p */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2186 in lp in %char-set-unfold! in k1330 in k1326 in k1210 */
static void C_ccall f_2188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2188,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=((C_word*)t0)[6];
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2184,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-14.scm: 355  f */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}}

/* k2182 in k2186 in lp in %char-set-unfold! in k1330 in k1326 in k1210 */
static void C_ccall f_2184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2184,2,t0,t1);}
t2=f_1220(t1);
t3=(C_word)C_i_string_set(((C_word*)t0)[6],t2,lf[16]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2180,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 356  g */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k2178 in k2182 in k2186 in lp in %char-set-unfold! in k1330 in k1326 in k1210 */
static void C_ccall f_2180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 356  lp */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2160(t2,((C_word*)t0)[2],t1);}

/* char-set-any in k1330 in k1326 in k1210 */
static void C_ccall f_2101(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2101,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2105,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 342  %char-set:s/check */
f_1301(t4,t3,lf[42]);}

/* k2103 in char-set-any in k1330 in k1326 in k1210 */
static void C_ccall f_2105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2105,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2110,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,a[5]=((C_word)li49),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2110(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k2103 in char-set-any in k1330 in k1326 in k1210 */
static void C_fcall f_2110(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2110,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2120,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_i_string_ref(((C_word*)t0)[3],t5);
t7=f_1220(t6);
t8=(C_word)C_eqp(t7,C_fix(0));
if(C_truep(t8)){
t9=t4;
f_2120(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2140,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 345  %latin1->char */
t10=lf[0];
f_1214(3,t10,t9,t2);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k2138 in lp in k2103 in char-set-any in k1330 in k1326 in k1210 */
static void C_ccall f_2140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 345  pred */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2118 in lp in k2103 in char-set-any in k1330 in k1326 in k1210 */
static void C_ccall f_2120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* srfi-14.scm: 346  lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2110(t3,((C_word*)t0)[4],t2);}}

/* char-set-every in k1330 in k1326 in k1210 */
static void C_ccall f_2052(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2052,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2056,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 334  %char-set:s/check */
f_1301(t4,t3,lf[41]);}

/* k2054 in char-set-every in k1330 in k1326 in k1210 */
static void C_ccall f_2056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2056,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2061,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word)li47),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2061(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k2054 in char-set-every in k1330 in k1326 in k1210 */
static void C_fcall f_2061(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2061,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_fixnum_lessp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=t2;
t6=(C_word)C_i_string_ref(((C_word*)t0)[4],t5);
t7=f_1220(t6);
t8=(C_word)C_eqp(t7,C_fix(0));
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2077,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t8)){
t10=t9;
f_2077(2,t10,t8);}
else{
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2091,a[2]=t9,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 337  %latin1->char */
t11=lf[0];
f_1214(3,t11,t10,t2);}}}

/* k2089 in lp in k2054 in char-set-every in k1330 in k1326 in k1210 */
static void C_ccall f_2091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 337  pred */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2075 in lp in k2054 in char-set-every in k1330 in k1326 in k1210 */
static void C_ccall f_2077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 338  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2061(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* char-set-fold in k1330 in k1326 in k1210 */
static void C_ccall f_2005(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2005,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2009,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 325  %char-set:s/check */
f_1301(t5,t4,lf[40]);}

/* k2007 in char-set-fold in k1330 in k1326 in k1210 */
static void C_ccall f_2009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2009,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2014,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,a[5]=((C_word)li45),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2014(t5,((C_word*)t0)[3],C_fix(255),((C_word*)t0)[2]);}

/* lp in k2007 in char-set-fold in k1330 in k1326 in k1210 */
static void C_fcall f_2014(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2014,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2032,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=t2;
t8=(C_word)C_i_string_ref(((C_word*)t0)[3],t7);
t9=f_1220(t8);
t10=(C_word)C_eqp(t9,C_fix(0));
if(C_truep(t10)){
t11=t6;
f_2032(2,t11,t3);}
else{
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2042,a[2]=t3,a[3]=t6,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 330  %latin1->char */
t12=lf[0];
f_1214(3,t12,t11,t2);}}}

/* k2040 in lp in k2007 in char-set-fold in k1330 in k1326 in k1210 */
static void C_ccall f_2042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 330  kons */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2030 in lp in k2007 in char-set-fold in k1330 in k1326 in k1210 */
static void C_ccall f_2032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 328  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2014(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* char-set-map in k1330 in k1326 in k1210 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1942,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1946,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 314  %char-set:s/check */
f_1301(t4,t3,lf[39]);}

/* k1944 in char-set-map in k1330 in k1326 in k1210 */
static void C_ccall f_1946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1949,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 315  make-string */
t3=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(256),lf[15]);}

/* k1947 in k1944 in char-set-map in k1330 in k1326 in k1210 */
static void C_ccall f_1949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1952,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1957,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=((C_word)li43),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_1957(t6,t2,C_fix(255));}

/* lp in k1947 in k1944 in char-set-map in k1330 in k1326 in k1210 */
static void C_fcall f_1957(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1957,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1967,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_i_string_ref(((C_word*)t0)[4],t5);
t7=f_1220(t6);
t8=(C_word)C_eqp(t7,C_fix(0));
if(C_truep(t8)){
t9=t4;
f_1967(t9,C_SCHEME_UNDEFINED);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1987,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1991,a[2]=t9,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 319  %latin1->char */
t11=lf[0];
f_1214(3,t11,t10,t2);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1989 in lp in k1947 in k1944 in char-set-map in k1330 in k1326 in k1210 */
static void C_ccall f_1991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 319  proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1985 in lp in k1947 in k1944 in char-set-map in k1330 in k1326 in k1210 */
static void C_ccall f_1987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_1220(t1);
t3=((C_word*)t0)[3];
f_1967(t3,(C_word)C_i_string_set(((C_word*)t0)[2],t2,lf[16]));}

/* k1965 in lp in k1947 in k1944 in char-set-map in k1330 in k1326 in k1210 */
static void C_fcall f_1967(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 320  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1957(t3,((C_word*)t0)[2],t2);}

/* k1950 in k1947 in k1944 in char-set-map in k1330 in k1326 in k1210 */
static void C_ccall f_1952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 321  make-char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-for-each in k1330 in k1326 in k1210 */
static void C_ccall f_1892(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1892,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1896,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 306  %char-set:s/check */
f_1301(t4,t3,lf[38]);}

/* k1894 in char-set-for-each in k1330 in k1326 in k1210 */
static void C_ccall f_1896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1896,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1901,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,a[5]=((C_word)li41),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1901(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k1894 in char-set-for-each in k1330 in k1326 in k1210 */
static void C_fcall f_1901(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1901,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1911,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_i_string_ref(((C_word*)t0)[3],t5);
t7=f_1220(t6);
t8=(C_word)C_eqp(t7,C_fix(0));
if(C_truep(t8)){
t9=t4;
f_1911(2,t9,C_SCHEME_UNDEFINED);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1928,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 309  %latin1->char */
t10=lf[0];
f_1214(3,t10,t9,t2);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1926 in lp in k1894 in char-set-for-each in k1330 in k1326 in k1210 */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 309  proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1909 in lp in k1894 in char-set-for-each in k1330 in k1326 in k1210 */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 310  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1901(t3,((C_word*)t0)[2],t2);}

/* %char-set-cursor-next in k1330 in k1326 in k1210 */
static void C_fcall f_1850(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1850,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1854,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 295  %char-set:s/check */
f_1301(t5,t2,t4);}

/* k1852 in %char-set-cursor-next in k1330 in k1326 in k1210 */
static void C_ccall f_1854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1854,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1859,a[2]=t1,a[3]=t3,a[4]=((C_word)li39),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1859(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k1852 in %char-set-cursor-next in k1330 in k1326 in k1210 */
static void C_fcall f_1859(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1859,NULL,3,t0,t1,t2);}
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
t4=(C_word)C_fixnum_lessp(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1872,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_1872(t6,t4);}
else{
t6=(C_word)C_i_string_ref(((C_word*)t0)[2],t3);
t7=f_1220(t6);
t8=(C_word)C_eqp(t7,C_fix(0));
t9=t5;
f_1872(t9,(C_word)C_i_not(t8));}}

/* k1870 in lp in k1852 in %char-set-cursor-next in k1330 in k1326 in k1210 */
static void C_fcall f_1872(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
/* srfi-14.scm: 299  lp */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1859(t2,((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* char-set-cursor-next in k1330 in k1326 in k1210 */
static void C_ccall f_1841(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1841,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[37]);
/* srfi-14.scm: 292  %char-set-cursor-next */
f_1850(t1,t2,t3,lf[37]);}

/* char-set-ref in k1330 in k1326 in k1210 */
static void C_ccall f_1835(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1835,4,t0,t1,t2,t3);}
/* srfi-14.scm: 286  %latin1->char */
t4=lf[0];
f_1214(3,t4,t1,t3);}

/* end-of-char-set? in k1330 in k1326 in k1210 */
static void C_ccall f_1829(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1829,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_lessp(t2,C_fix(0)));}

/* char-set-cursor in k1330 in k1326 in k1210 */
static void C_ccall f_1823(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1823,3,t0,t1,t2);}
/* srfi-14.scm: 282  %char-set-cursor-next */
f_1850(t1,t2,C_fix(256),lf[33]);}

/* char-set-delete! in k1330 in k1326 in k1210 */
static void C_ccall f_1811(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_1811r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1811r(t0,t1,t2,t3);}}

static void C_ccall f_1811r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1817,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 268  %set-char-set! */
f_1756(t1,t4,lf[32],t2,t3);}

/* a1816 in char-set-delete! in k1330 in k1326 in k1210 */
static void C_ccall f_1817(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1817,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[15]));}

/* char-set-delete in k1330 in k1326 in k1210 */
static void C_ccall f_1799(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_1799r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1799r(t0,t1,t2,t3);}}

static void C_ccall f_1799r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1805,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 266  %set-char-set */
f_1730(t1,t4,lf[31],t2,t3);}

/* a1804 in char-set-delete in k1330 in k1326 in k1210 */
static void C_ccall f_1805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1805,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[15]));}

/* char-set-adjoin! in k1330 in k1326 in k1210 */
static void C_ccall f_1787(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_1787r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1787r(t0,t1,t2,t3);}}

static void C_ccall f_1787r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1793,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 264  %set-char-set! */
f_1756(t1,t4,lf[30],t2,t3);}

/* a1792 in char-set-adjoin! in k1330 in k1326 in k1210 */
static void C_ccall f_1793(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1793,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[16]));}

/* char-set-adjoin in k1330 in k1326 in k1210 */
static void C_ccall f_1775(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_1775r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1775r(t0,t1,t2,t3);}}

static void C_ccall f_1775r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1781,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 262  %set-char-set */
f_1730(t1,t4,lf[29],t2,t3);}

/* a1780 in char-set-adjoin in k1330 in k1326 in k1210 */
static void C_ccall f_1781(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1781,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[16]));}

/* %set-char-set! in k1330 in k1326 in k1210 */
static void C_fcall f_1756(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1756,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1760,a[2]=t5,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-14.scm: 256  %char-set:s/check */
f_1301(t6,t4,t3);}

/* k1758 in %set-char-set! in k1330 in k1326 in k1210 */
static void C_ccall f_1760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1763,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1765,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li25),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a1764 in k1758 in %set-char-set! in k1330 in k1326 in k1210 */
static void C_ccall f_1765(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1765,3,t0,t1,t2);}
t3=f_1220(t2);
/* srfi-14.scm: 257  set */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,((C_word*)t0)[2],t3);}

/* k1761 in k1758 in %set-char-set! in k1330 in k1326 in k1210 */
static void C_ccall f_1763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* %set-char-set in k1330 in k1326 in k1210 */
static void C_fcall f_1730(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1730,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1734,a[2]=t5,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1754,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 250  %char-set:s/check */
f_1301(t7,t4,t3);}

/* k1752 in %set-char-set in k1330 in k1326 in k1210 */
static void C_ccall f_1754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 250  %string-copy */
f_1244(((C_word*)t0)[2],t1);}

/* k1732 in %set-char-set in k1330 in k1326 in k1210 */
static void C_ccall f_1734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1737,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1742,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li23),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a1741 in k1732 in %set-char-set in k1330 in k1326 in k1210 */
static void C_ccall f_1742(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1742,3,t0,t1,t2);}
t3=f_1220(t2);
/* srfi-14.scm: 251  set */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,((C_word*)t0)[2],t3);}

/* k1735 in k1732 in %set-char-set in k1330 in k1326 in k1210 */
static void C_ccall f_1737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 253  make-char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-count in k1330 in k1326 in k1210 */
static void C_ccall f_1673(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1673,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1677,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 238  %char-set:s/check */
f_1301(t4,t3,lf[25]);}

/* k1675 in char-set-count in k1330 in k1326 in k1210 */
static void C_ccall f_1677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1677,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1682,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,a[5]=((C_word)li21),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1682(t5,((C_word*)t0)[2],C_fix(255),C_fix(0));}

/* lp in k1675 in char-set-count in k1330 in k1326 in k1210 */
static void C_fcall f_1682(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1682,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1703,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=t2;
t8=(C_word)C_i_string_ref(((C_word*)t0)[3],t7);
t9=f_1220(t8);
t10=(C_word)C_eqp(t9,C_fix(0));
if(C_truep(t10)){
t11=t6;
f_1703(2,t11,C_SCHEME_FALSE);}
else{
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1716,a[2]=t6,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 242  %latin1->char */
t12=lf[0];
f_1214(3,t12,t11,t2);}}}

/* k1714 in lp in k1675 in char-set-count in k1330 in k1326 in k1210 */
static void C_ccall f_1716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 242  pred */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1701 in lp in k1675 in char-set-count in k1330 in k1326 in k1210 */
static void C_ccall f_1703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1)):((C_word*)t0)[5]);
/* srfi-14.scm: 241  lp */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1682(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* char-set-size in k1330 in k1326 in k1210 */
static void C_ccall f_1636(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1636,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1640,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 231  %char-set:s/check */
f_1301(t3,t2,lf[24]);}

/* k1638 in char-set-size in k1330 in k1326 in k1210 */
static void C_ccall f_1640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1645,a[2]=t1,a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1645(t2,C_fix(255),C_fix(0)));}

/* lp in k1638 in char-set-size in k1330 in k1326 in k1210 */
static C_word C_fcall f_1645(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
t3=t1;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
return(t2);}
else{
t4=(C_word)C_fixnum_difference(t1,C_fix(1));
t5=t1;
t6=(C_word)C_i_string_ref(((C_word*)t0)[2],t5);
t7=f_1220(t6);
t8=(C_word)C_fixnum_plus(t2,t7);
t10=t4;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* char-set-contains? in k1330 in k1326 in k1210 */
static void C_ccall f_1609(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1609,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_char_2(t3,lf[23]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1616,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 226  %char-set:s/check */
f_1301(t5,t2,lf[23]);}

/* k1614 in char-set-contains? in k1330 in k1326 in k1210 */
static void C_ccall f_1616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=f_1220(((C_word*)t0)[3]);
t3=(C_word)C_i_string_ref(t1,t2);
t4=f_1220(t3);
t5=(C_word)C_eqp(t4,C_fix(0));
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_not(t5));}

/* char-set-hash in k1330 in k1326 in k1210 */
static void C_ccall f_1501(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1501r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1501r(t0,t1,t2,t3);}}

static void C_ccall f_1501r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1505,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_1505(2,t5,C_fix(4194304));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_1505(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[22],t3);}}}

/* k1503 in char-set-hash in k1330 in k1326 in k1210 */
static void C_ccall f_1505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1505,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1508,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(((C_word*)t3)[1],C_fix(0));
if(C_truep(t5)){
t6=C_set_block_item(t3,0,C_fix(4194304));
t7=t4;
f_1508(t7,t6);}
else{
t6=t4;
f_1508(t6,C_SCHEME_UNDEFINED);}}

/* k1506 in k1503 in char-set-hash in k1330 in k1326 in k1210 */
static void C_fcall f_1508(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1508,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[4])[1],lf[20]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1514,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 213  %char-set:s/check */
f_1301(t3,((C_word*)t0)[2],lf[20]);}

/* k1512 in k1506 in k1503 in char-set-hash in k1330 in k1326 in k1210 */
static void C_ccall f_1514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1567,a[2]=((C_word*)t0)[3],a[3]=((C_word)li15),tmp=(C_word)a,a+=4,tmp);
t3=f_1567(t2,C_fix(65536));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1522,a[2]=t3,a[3]=t1,a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word)li16),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_1522(t7,((C_word*)t0)[2],C_fix(255),C_fix(0));}

/* lp in k1512 in k1506 in k1503 in char-set-hash in k1330 in k1326 in k1210 */
static void C_fcall f_1522(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1522,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
/* srfi-14.scm: 218  modulo */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,((C_word*)((C_word*)t0)[5])[1]);}
else{
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1543,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=t2;
t8=(C_word)C_i_string_ref(((C_word*)t0)[3],t7);
t9=f_1220(t8);
t10=(C_word)C_eqp(t9,C_fix(0));
if(C_truep(t10)){
t11=t6;
f_1543(t11,t3);}
else{
t11=(C_word)C_fixnum_times(C_fix(37),t3);
t12=(C_word)C_fixnum_plus(t11,t2);
t13=t6;
f_1543(t13,(C_word)C_fixnum_and(((C_word*)t0)[2],t12));}}}

/* k1541 in lp in k1512 in k1506 in k1503 in char-set-hash in k1330 in k1326 in k1210 */
static void C_fcall f_1543(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 219  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1522(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* lp in k1512 in k1506 in k1503 in char-set-hash in k1330 in k1326 in k1210 */
static C_word C_fcall f_1567(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=t1;
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,t3))){
return((C_word)C_fixnum_difference(t1,C_fix(1)));}
else{
t4=(C_word)C_fixnum_plus(t1,t1);
t6=t4;
t1=t6;
goto loop;}}

/* char-set<= in k1330 in k1326 in k1210 */
static void C_ccall f_1403(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1403r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1403r(t0,t1,t2);}}

static void C_ccall f_1403r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1423,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 186  %char-set:s/check */
f_1301(t6,t4,lf[19]);}}

/* k1421 in char-set<= in k1330 in k1326 in k1210 */
static void C_ccall f_1423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1423,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1425,a[2]=t3,a[3]=((C_word)li13),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_1425(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* lp in k1421 in char-set<= in k1330 in k1326 in k1210 */
static void C_fcall f_1425(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1425,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(t3);
t5=(C_word)C_i_not(t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1435,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t3);
/* srfi-14.scm: 188  %char-set:s/check */
f_1301(t6,t7,lf[19]);}}

/* k1433 in lp in k1421 in char-set<= in k1330 in k1326 in k1210 */
static void C_ccall f_1435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1435,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t3)){
/* srfi-14.scm: 190  lp */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1425(t4,((C_word*)t0)[2],t1,t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1452,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=((C_word)li12),tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_1452(t7,((C_word*)t0)[2],C_fix(255));}}

/* lp2 in k1433 in lp in k1421 in char-set<= in k1330 in k1326 in k1210 */
static void C_fcall f_1452(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1452,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* srfi-14.scm: 192  lp */
t4=((C_word*)((C_word*)t0)[6])[1];
f_1425(t4,t1,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t4=((C_word*)t0)[3];
t5=t2;
t6=(C_word)C_i_string_ref(t4,t5);
t7=f_1220(t6);
t8=t2;
t9=(C_word)C_i_string_ref(((C_word*)t0)[5],t8);
t10=f_1220(t9);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t7,t10))){
t11=(C_word)C_fixnum_difference(t2,C_fix(1));
/* srfi-14.scm: 194  lp2 */
t13=t1;
t14=t11;
t1=t13;
t2=t14;
goto loop;}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}}

/* char-set= in k1330 in k1326 in k1210 */
static void C_ccall f_1348(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1348r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1348r(t0,t1,t2);}}

static void C_ccall f_1348r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1364,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 175  %char-set:s/check */
f_1301(t6,t4,lf[18]);}}

/* k1362 in char-set= in k1330 in k1326 in k1210 */
static void C_ccall f_1364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1364,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1369,a[2]=t3,a[3]=t1,a[4]=((C_word)li10),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1369(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k1362 in char-set= in k1330 in k1326 in k1210 */
static void C_fcall f_1369(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1369,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_word)C_i_not(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1393,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t2);
/* srfi-14.scm: 178  %char-set:s/check */
f_1301(t5,t6,lf[18]);}}

/* k1391 in lp in k1362 in char-set= in k1330 in k1326 in k1210 */
static void C_ccall f_1393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_string_equal_p(((C_word*)t0)[5],t1))){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* srfi-14.scm: 179  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1369(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* char-set-copy in k1330 in k1326 in k1210 */
static void C_ccall f_1334(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1334,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1342,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1346,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 168  %char-set:s/check */
f_1301(t4,t2,lf[17]);}

/* k1344 in char-set-copy in k1330 in k1326 in k1210 */
static void C_ccall f_1346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 168  %string-copy */
f_1244(((C_word*)t0)[2],t1);}

/* k1340 in char-set-copy in k1330 in k1326 in k1210 */
static void C_ccall f_1342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 168  make-char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* %char-set:s/check in k1210 */
static void C_fcall f_1301(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1301,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1307,a[2]=t3,a[3]=t5,a[4]=((C_word)li7),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1307(t7,t1,t2);}

/* lp in %char-set:s/check in k1210 */
static void C_fcall f_1307(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1307,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1314,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-14.scm: 139  char-set? */
t4=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k1312 in lp in %char-set:s/check in k1210 */
static void C_ccall f_1314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1314,2,t0,t1);}
if(C_truep(t1)){
/* srfi-14.scm: 139  char-set:s */
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1324,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 140  ##sys#error */
t3=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],lf[14],((C_word*)t0)[4]);}}

/* k1322 in k1312 in lp in %char-set:s/check in k1210 */
static void C_ccall f_1324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 140  lp */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1307(t2,((C_word*)t0)[2],t1);}

/* %default-base in k1210 */
static void C_fcall f_1254(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1254,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1279,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 127  char-set? */
t7=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}
else{
/* srfi-14.scm: 129  ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,lf[11],t3,t2);}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1299,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 131  %latin1->char */
t5=lf[0];
f_1214(3,t5,t4,C_fix(0));}}

/* k1297 in %default-base in k1210 */
static void C_ccall f_1299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 131  make-string */
t2=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_fix(256),t1);}

/* k1277 in %default-base in k1210 */
static void C_ccall f_1279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1279,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1286,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 127  char-set:s */
t3=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
/* srfi-14.scm: 128  ##sys#error */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[10],((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k1284 in k1277 in %default-base in k1210 */
static void C_ccall f_1286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 127  %string-copy */
f_1244(((C_word*)t0)[2],t1);}

/* %string-copy in k1210 */
static void C_fcall f_1244(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1244,NULL,2,t1,t2);}
t3=(C_word)C_i_string_length(t2);
/* srfi-14.scm: 115  substring */
t4=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,t2,C_fix(0),t3);}

/* char-set? in k1210 */
static void C_ccall f_1238(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1238,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[3]));}

/* char-set:s in k1210 */
static void C_ccall f_1232(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1232,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* make-char-set in k1210 */
static void C_ccall f_1226(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1226,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,2,lf[3],t2));}

/* %char->latin1 in k1210 */
static C_word C_fcall f_1220(C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)C_fix((C_word)C_character_code(t1)));}

/* %latin1->char in k1210 */
static void C_ccall f_1214(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1214,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_make_character((C_word)C_unfix(t2)));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[275] = {
{"toplevel:srfi_14_scm",(void*)C_srfi_14_toplevel},
{"f_1212:srfi_14_scm",(void*)f_1212},
{"f_1328:srfi_14_scm",(void*)f_1328},
{"f_1332:srfi_14_scm",(void*)f_1332},
{"f_3219:srfi_14_scm",(void*)f_3219},
{"f_3223:srfi_14_scm",(void*)f_3223},
{"f_3227:srfi_14_scm",(void*)f_3227},
{"f_3230:srfi_14_scm",(void*)f_3230},
{"f_3233:srfi_14_scm",(void*)f_3233},
{"f_3335:srfi_14_scm",(void*)f_3335},
{"f_3236:srfi_14_scm",(void*)f_3236},
{"f_3240:srfi_14_scm",(void*)f_3240},
{"f_3331:srfi_14_scm",(void*)f_3331},
{"f_3243:srfi_14_scm",(void*)f_3243},
{"f_3248:srfi_14_scm",(void*)f_3248},
{"f_3323:srfi_14_scm",(void*)f_3323},
{"f_3327:srfi_14_scm",(void*)f_3327},
{"f_3251:srfi_14_scm",(void*)f_3251},
{"f_3255:srfi_14_scm",(void*)f_3255},
{"f_3259:srfi_14_scm",(void*)f_3259},
{"f_3263:srfi_14_scm",(void*)f_3263},
{"f_3267:srfi_14_scm",(void*)f_3267},
{"f_3270:srfi_14_scm",(void*)f_3270},
{"f_3273:srfi_14_scm",(void*)f_3273},
{"f_3277:srfi_14_scm",(void*)f_3277},
{"f_3280:srfi_14_scm",(void*)f_3280},
{"f_3283:srfi_14_scm",(void*)f_3283},
{"f_3287:srfi_14_scm",(void*)f_3287},
{"f_3319:srfi_14_scm",(void*)f_3319},
{"f_3291:srfi_14_scm",(void*)f_3291},
{"f_3295:srfi_14_scm",(void*)f_3295},
{"f_3315:srfi_14_scm",(void*)f_3315},
{"f_3299:srfi_14_scm",(void*)f_3299},
{"f_3311:srfi_14_scm",(void*)f_3311},
{"f_3303:srfi_14_scm",(void*)f_3303},
{"f_3307:srfi_14_scm",(void*)f_3307},
{"f_3190:srfi_14_scm",(void*)f_3190},
{"f_3215:srfi_14_scm",(void*)f_3215},
{"f_3194:srfi_14_scm",(void*)f_3194},
{"f_3197:srfi_14_scm",(void*)f_3197},
{"f_3200:srfi_14_scm",(void*)f_3200},
{"f_3207:srfi_14_scm",(void*)f_3207},
{"f_3211:srfi_14_scm",(void*)f_3211},
{"f_3139:srfi_14_scm",(void*)f_3139},
{"f_3143:srfi_14_scm",(void*)f_3143},
{"f_3146:srfi_14_scm",(void*)f_3146},
{"f_3157:srfi_14_scm",(void*)f_3157},
{"f_3149:srfi_14_scm",(void*)f_3149},
{"f_3152:srfi_14_scm",(void*)f_3152},
{"f_3086:srfi_14_scm",(void*)f_3086},
{"f_3092:srfi_14_scm",(void*)f_3092},
{"f_3137:srfi_14_scm",(void*)f_3137},
{"f_3098:srfi_14_scm",(void*)f_3098},
{"f_3022:srfi_14_scm",(void*)f_3022},
{"f_3077:srfi_14_scm",(void*)f_3077},
{"f_3032:srfi_14_scm",(void*)f_3032},
{"f_3044:srfi_14_scm",(void*)f_3044},
{"f_3061:srfi_14_scm",(void*)f_3061},
{"f_3035:srfi_14_scm",(void*)f_3035},
{"f_2981:srfi_14_scm",(void*)f_2981},
{"f_2989:srfi_14_scm",(void*)f_2989},
{"f_2991:srfi_14_scm",(void*)f_2991},
{"f_3008:srfi_14_scm",(void*)f_3008},
{"f_2985:srfi_14_scm",(void*)f_2985},
{"f_2940:srfi_14_scm",(void*)f_2940},
{"f_2976:srfi_14_scm",(void*)f_2976},
{"f_2950:srfi_14_scm",(void*)f_2950},
{"f_2958:srfi_14_scm",(void*)f_2958},
{"f_2953:srfi_14_scm",(void*)f_2953},
{"f_2914:srfi_14_scm",(void*)f_2914},
{"f_2922:srfi_14_scm",(void*)f_2922},
{"f_2924:srfi_14_scm",(void*)f_2924},
{"f_2918:srfi_14_scm",(void*)f_2918},
{"f_2869:srfi_14_scm",(void*)f_2869},
{"f_2905:srfi_14_scm",(void*)f_2905},
{"f_2879:srfi_14_scm",(void*)f_2879},
{"f_2891:srfi_14_scm",(void*)f_2891},
{"f_2882:srfi_14_scm",(void*)f_2882},
{"f_2847:srfi_14_scm",(void*)f_2847},
{"f_2855:srfi_14_scm",(void*)f_2855},
{"f_2857:srfi_14_scm",(void*)f_2857},
{"f_2851:srfi_14_scm",(void*)f_2851},
{"f_2798:srfi_14_scm",(void*)f_2798},
{"f_2838:srfi_14_scm",(void*)f_2838},
{"f_2808:srfi_14_scm",(void*)f_2808},
{"f_2820:srfi_14_scm",(void*)f_2820},
{"f_2811:srfi_14_scm",(void*)f_2811},
{"f_2772:srfi_14_scm",(void*)f_2772},
{"f_2780:srfi_14_scm",(void*)f_2780},
{"f_2782:srfi_14_scm",(void*)f_2782},
{"f_2776:srfi_14_scm",(void*)f_2776},
{"f_2750:srfi_14_scm",(void*)f_2750},
{"f_2754:srfi_14_scm",(void*)f_2754},
{"f_2759:srfi_14_scm",(void*)f_2759},
{"f_2770:srfi_14_scm",(void*)f_2770},
{"f_2757:srfi_14_scm",(void*)f_2757},
{"f_2722:srfi_14_scm",(void*)f_2722},
{"f_2726:srfi_14_scm",(void*)f_2726},
{"f_2729:srfi_14_scm",(void*)f_2729},
{"f_2737:srfi_14_scm",(void*)f_2737},
{"f_2748:srfi_14_scm",(void*)f_2748},
{"f_2732:srfi_14_scm",(void*)f_2732},
{"f_2680:srfi_14_scm",(void*)f_2680},
{"f_2686:srfi_14_scm",(void*)f_2686},
{"f_2690:srfi_14_scm",(void*)f_2690},
{"f_2695:srfi_14_scm",(void*)f_2695},
{"f_2705:srfi_14_scm",(void*)f_2705},
{"f_2639:srfi_14_scm",(void*)f_2639},
{"f_2649:srfi_14_scm",(void*)f_2649},
{"f_2659:srfi_14_scm",(void*)f_2659},
{"f_2609:srfi_14_scm",(void*)f_2609},
{"f_2616:srfi_14_scm",(void*)f_2616},
{"f_2595:srfi_14_scm",(void*)f_2595},
{"f_2603:srfi_14_scm",(void*)f_2603},
{"f_2607:srfi_14_scm",(void*)f_2607},
{"f_2599:srfi_14_scm",(void*)f_2599},
{"f_2579:srfi_14_scm",(void*)f_2579},
{"f_2583:srfi_14_scm",(void*)f_2583},
{"f_2593:srfi_14_scm",(void*)f_2593},
{"f_2586:srfi_14_scm",(void*)f_2586},
{"f_2526:srfi_14_scm",(void*)f_2526},
{"f_2532:srfi_14_scm",(void*)f_2532},
{"f_2565:srfi_14_scm",(void*)f_2565},
{"f_2552:srfi_14_scm",(void*)f_2552},
{"f_2542:srfi_14_scm",(void*)f_2542},
{"f_2516:srfi_14_scm",(void*)f_2516},
{"f_2524:srfi_14_scm",(void*)f_2524},
{"f_2520:srfi_14_scm",(void*)f_2520},
{"f_2486:srfi_14_scm",(void*)f_2486},
{"f_2496:srfi_14_scm",(void*)f_2496},
{"f_2499:srfi_14_scm",(void*)f_2499},
{"f_2429:srfi_14_scm",(void*)f_2429},
{"f_2472:srfi_14_scm",(void*)f_2472},
{"f_2439:srfi_14_scm",(void*)f_2439},
{"f_2469:srfi_14_scm",(void*)f_2469},
{"f_2448:srfi_14_scm",(void*)f_2448},
{"f_2373:srfi_14_scm",(void*)f_2373},
{"f_2377:srfi_14_scm",(void*)f_2377},
{"f_2427:srfi_14_scm",(void*)f_2427},
{"f_2380:srfi_14_scm",(void*)f_2380},
{"f_2385:srfi_14_scm",(void*)f_2385},
{"f_2415:srfi_14_scm",(void*)f_2415},
{"f_2395:srfi_14_scm",(void*)f_2395},
{"f_2363:srfi_14_scm",(void*)f_2363},
{"f_2371:srfi_14_scm",(void*)f_2371},
{"f_2367:srfi_14_scm",(void*)f_2367},
{"f_2351:srfi_14_scm",(void*)f_2351},
{"f_2355:srfi_14_scm",(void*)f_2355},
{"f_2358:srfi_14_scm",(void*)f_2358},
{"f_2308:srfi_14_scm",(void*)f_2308},
{"f_2321:srfi_14_scm",(void*)f_2321},
{"f_2261:srfi_14_scm",(void*)f_2261},
{"f_2265:srfi_14_scm",(void*)f_2265},
{"f_2270:srfi_14_scm",(void*)f_2270},
{"f_2298:srfi_14_scm",(void*)f_2298},
{"f_2288:srfi_14_scm",(void*)f_2288},
{"f_2251:srfi_14_scm",(void*)f_2251},
{"f_2259:srfi_14_scm",(void*)f_2259},
{"f_2255:srfi_14_scm",(void*)f_2255},
{"f_2239:srfi_14_scm",(void*)f_2239},
{"f_2243:srfi_14_scm",(void*)f_2243},
{"f_2246:srfi_14_scm",(void*)f_2246},
{"f_2227:srfi_14_scm",(void*)f_2227},
{"f_2231:srfi_14_scm",(void*)f_2231},
{"f_2234:srfi_14_scm",(void*)f_2234},
{"f_2212:srfi_14_scm",(void*)f_2212},
{"f_2218:srfi_14_scm",(void*)f_2218},
{"f_2202:srfi_14_scm",(void*)f_2202},
{"f_2210:srfi_14_scm",(void*)f_2210},
{"f_2206:srfi_14_scm",(void*)f_2206},
{"f_2190:srfi_14_scm",(void*)f_2190},
{"f_2194:srfi_14_scm",(void*)f_2194},
{"f_2197:srfi_14_scm",(void*)f_2197},
{"f_2154:srfi_14_scm",(void*)f_2154},
{"f_2160:srfi_14_scm",(void*)f_2160},
{"f_2188:srfi_14_scm",(void*)f_2188},
{"f_2184:srfi_14_scm",(void*)f_2184},
{"f_2180:srfi_14_scm",(void*)f_2180},
{"f_2101:srfi_14_scm",(void*)f_2101},
{"f_2105:srfi_14_scm",(void*)f_2105},
{"f_2110:srfi_14_scm",(void*)f_2110},
{"f_2140:srfi_14_scm",(void*)f_2140},
{"f_2120:srfi_14_scm",(void*)f_2120},
{"f_2052:srfi_14_scm",(void*)f_2052},
{"f_2056:srfi_14_scm",(void*)f_2056},
{"f_2061:srfi_14_scm",(void*)f_2061},
{"f_2091:srfi_14_scm",(void*)f_2091},
{"f_2077:srfi_14_scm",(void*)f_2077},
{"f_2005:srfi_14_scm",(void*)f_2005},
{"f_2009:srfi_14_scm",(void*)f_2009},
{"f_2014:srfi_14_scm",(void*)f_2014},
{"f_2042:srfi_14_scm",(void*)f_2042},
{"f_2032:srfi_14_scm",(void*)f_2032},
{"f_1942:srfi_14_scm",(void*)f_1942},
{"f_1946:srfi_14_scm",(void*)f_1946},
{"f_1949:srfi_14_scm",(void*)f_1949},
{"f_1957:srfi_14_scm",(void*)f_1957},
{"f_1991:srfi_14_scm",(void*)f_1991},
{"f_1987:srfi_14_scm",(void*)f_1987},
{"f_1967:srfi_14_scm",(void*)f_1967},
{"f_1952:srfi_14_scm",(void*)f_1952},
{"f_1892:srfi_14_scm",(void*)f_1892},
{"f_1896:srfi_14_scm",(void*)f_1896},
{"f_1901:srfi_14_scm",(void*)f_1901},
{"f_1928:srfi_14_scm",(void*)f_1928},
{"f_1911:srfi_14_scm",(void*)f_1911},
{"f_1850:srfi_14_scm",(void*)f_1850},
{"f_1854:srfi_14_scm",(void*)f_1854},
{"f_1859:srfi_14_scm",(void*)f_1859},
{"f_1872:srfi_14_scm",(void*)f_1872},
{"f_1841:srfi_14_scm",(void*)f_1841},
{"f_1835:srfi_14_scm",(void*)f_1835},
{"f_1829:srfi_14_scm",(void*)f_1829},
{"f_1823:srfi_14_scm",(void*)f_1823},
{"f_1811:srfi_14_scm",(void*)f_1811},
{"f_1817:srfi_14_scm",(void*)f_1817},
{"f_1799:srfi_14_scm",(void*)f_1799},
{"f_1805:srfi_14_scm",(void*)f_1805},
{"f_1787:srfi_14_scm",(void*)f_1787},
{"f_1793:srfi_14_scm",(void*)f_1793},
{"f_1775:srfi_14_scm",(void*)f_1775},
{"f_1781:srfi_14_scm",(void*)f_1781},
{"f_1756:srfi_14_scm",(void*)f_1756},
{"f_1760:srfi_14_scm",(void*)f_1760},
{"f_1765:srfi_14_scm",(void*)f_1765},
{"f_1763:srfi_14_scm",(void*)f_1763},
{"f_1730:srfi_14_scm",(void*)f_1730},
{"f_1754:srfi_14_scm",(void*)f_1754},
{"f_1734:srfi_14_scm",(void*)f_1734},
{"f_1742:srfi_14_scm",(void*)f_1742},
{"f_1737:srfi_14_scm",(void*)f_1737},
{"f_1673:srfi_14_scm",(void*)f_1673},
{"f_1677:srfi_14_scm",(void*)f_1677},
{"f_1682:srfi_14_scm",(void*)f_1682},
{"f_1716:srfi_14_scm",(void*)f_1716},
{"f_1703:srfi_14_scm",(void*)f_1703},
{"f_1636:srfi_14_scm",(void*)f_1636},
{"f_1640:srfi_14_scm",(void*)f_1640},
{"f_1645:srfi_14_scm",(void*)f_1645},
{"f_1609:srfi_14_scm",(void*)f_1609},
{"f_1616:srfi_14_scm",(void*)f_1616},
{"f_1501:srfi_14_scm",(void*)f_1501},
{"f_1505:srfi_14_scm",(void*)f_1505},
{"f_1508:srfi_14_scm",(void*)f_1508},
{"f_1514:srfi_14_scm",(void*)f_1514},
{"f_1522:srfi_14_scm",(void*)f_1522},
{"f_1543:srfi_14_scm",(void*)f_1543},
{"f_1567:srfi_14_scm",(void*)f_1567},
{"f_1403:srfi_14_scm",(void*)f_1403},
{"f_1423:srfi_14_scm",(void*)f_1423},
{"f_1425:srfi_14_scm",(void*)f_1425},
{"f_1435:srfi_14_scm",(void*)f_1435},
{"f_1452:srfi_14_scm",(void*)f_1452},
{"f_1348:srfi_14_scm",(void*)f_1348},
{"f_1364:srfi_14_scm",(void*)f_1364},
{"f_1369:srfi_14_scm",(void*)f_1369},
{"f_1393:srfi_14_scm",(void*)f_1393},
{"f_1334:srfi_14_scm",(void*)f_1334},
{"f_1346:srfi_14_scm",(void*)f_1346},
{"f_1342:srfi_14_scm",(void*)f_1342},
{"f_1301:srfi_14_scm",(void*)f_1301},
{"f_1307:srfi_14_scm",(void*)f_1307},
{"f_1314:srfi_14_scm",(void*)f_1314},
{"f_1324:srfi_14_scm",(void*)f_1324},
{"f_1254:srfi_14_scm",(void*)f_1254},
{"f_1299:srfi_14_scm",(void*)f_1299},
{"f_1279:srfi_14_scm",(void*)f_1279},
{"f_1286:srfi_14_scm",(void*)f_1286},
{"f_1244:srfi_14_scm",(void*)f_1244},
{"f_1238:srfi_14_scm",(void*)f_1238},
{"f_1232:srfi_14_scm",(void*)f_1232},
{"f_1226:srfi_14_scm",(void*)f_1226},
{"f_1220:srfi_14_scm",(void*)f_1220},
{"f_1214:srfi_14_scm",(void*)f_1214},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
