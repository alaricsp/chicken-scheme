/* Generated from srfi-14.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-12-30 14:21
   Version 4.0.0x5 - SVN rev. 12341
   macosx-unix-gnu-ppc [ dload ptables applyhook ]
   compiled 2008-11-03 on apfel (Darwin)
   command line: srfi-14.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -output-file srfi-14.c
   unit: srfi_14
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[108];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,19),40,37,108,97,116,105,110,49,45,62,99,104,97,114,32,110,50,49,41,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,15),40,37,99,104,97,114,45,62,108,97,116,105,110,49,41,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,19),40,109,97,107,101,45,99,104,97,114,45,115,101,116,32,115,50,57,41,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,17),40,99,104,97,114,45,115,101,116,58,115,32,99,115,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,15),40,99,104,97,114,45,115,101,116,63,32,120,51,55,41,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,18),40,37,115,116,114,105,110,103,45,99,111,112,121,32,115,52,49,41,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,35),40,37,100,101,102,97,117,108,116,45,98,97,115,101,32,109,97,121,98,101,45,98,97,115,101,52,53,32,112,114,111,99,52,54,41,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,9),40,108,112,32,99,115,53,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,31),40,37,99,104,97,114,45,115,101,116,58,115,47,99,104,101,99,107,32,99,115,53,51,32,112,114,111,99,53,52,41,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,20),40,99,104,97,114,45,115,101,116,45,99,111,112,121,32,99,115,56,56,41,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,12),40,108,112,32,114,101,115,116,49,48,57,41,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,20),40,99,104,97,114,45,115,101,116,61,32,46,32,114,101,115,116,57,49,41,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,18),40,102,95,49,52,51,51,32,115,49,53,54,32,105,49,53,55,41,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,18),40,102,95,49,52,52,50,32,115,49,53,51,32,105,49,53,52,41,0,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,10),40,108,112,50,32,105,49,52,57,41,0,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,18),40,108,112,32,115,49,49,51,53,32,114,101,115,116,49,51,54,41,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,22),40,99,104,97,114,45,115,101,116,60,61,32,46,32,114,101,115,116,49,50,50,41,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,4),40,108,112,41,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,18),40,102,95,49,53,49,55,32,115,49,57,54,32,105,49,57,55,41,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,16),40,108,112,32,105,49,57,51,32,97,110,115,49,57,52,41};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,38),40,99,104,97,114,45,115,101,116,45,104,97,115,104,32,99,115,49,54,53,32,46,32,109,97,121,98,101,45,98,111,117,110,100,49,54,54,41,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,18),40,102,95,49,53,57,56,32,115,50,49,49,32,105,50,49,50,41,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,18),40,102,95,49,53,56,57,32,115,50,48,56,32,105,50,48,57,41,0,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,34),40,99,104,97,114,45,115,101,116,45,99,111,110,116,97,105,110,115,63,32,99,115,50,48,53,32,99,104,97,114,50,48,54,41,0,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,18),40,102,95,49,54,52,52,32,115,50,50,54,32,105,50,50,55,41,0,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,17),40,108,112,32,105,50,50,51,32,115,105,122,101,50,50,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,21),40,99,104,97,114,45,115,101,116,45,115,105,122,101,32,99,115,50,49,55,41,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,18),40,102,95,49,55,48,55,32,115,50,52,56,32,105,50,52,57,41,0,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,18),40,102,95,49,54,57,56,32,115,50,52,53,32,105,50,52,54,41,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,18),40,108,112,32,105,50,52,48,32,99,111,117,110,116,50,52,49,41,0,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,32),40,99,104,97,114,45,115,101,116,45,99,111,117,110,116,32,112,114,101,100,50,51,51,32,99,115,101,116,50,51,52,41};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,12),40,97,49,55,51,50,32,99,50,54,50,41,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,45),40,37,115,101,116,45,99,104,97,114,45,115,101,116,32,115,101,116,50,53,53,32,112,114,111,99,50,53,54,32,99,115,50,53,55,32,99,104,97,114,115,50,53,56,41,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,12),40,97,49,55,53,53,32,99,50,55,52,41,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,46),40,37,115,101,116,45,99,104,97,114,45,115,101,116,33,32,115,101,116,50,54,55,32,112,114,111,99,50,54,56,32,99,115,50,54,57,32,99,104,97,114,115,50,55,48,41,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,17),40,97,49,55,55,49,32,115,50,56,50,32,105,50,56,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,34),40,99,104,97,114,45,115,101,116,45,97,100,106,111,105,110,32,99,115,50,55,57,32,46,32,99,104,97,114,115,50,56,48,41,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,17),40,97,49,55,56,51,32,115,50,57,48,32,105,50,57,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,35),40,99,104,97,114,45,115,101,116,45,97,100,106,111,105,110,33,32,99,115,50,56,55,32,46,32,99,104,97,114,115,50,56,56,41,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,17),40,97,49,55,57,53,32,115,50,57,56,32,105,50,57,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,34),40,99,104,97,114,45,115,101,116,45,100,101,108,101,116,101,32,99,115,50,57,53,32,46,32,99,104,97,114,115,50,57,54,41,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,17),40,97,49,56,48,55,32,115,51,48,54,32,105,51,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,35),40,99,104,97,114,45,115,101,116,45,100,101,108,101,116,101,33,32,99,115,51,48,51,32,46,32,99,104,97,114,115,51,48,52,41,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,25),40,99,104,97,114,45,115,101,116,45,99,117,114,115,111,114,32,99,115,101,116,51,49,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,28),40,101,110,100,45,111,102,45,99,104,97,114,45,115,101,116,63,32,99,117,114,115,111,114,51,49,53,41,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,32),40,99,104,97,114,45,115,101,116,45,114,101,102,32,99,115,101,116,51,49,57,32,99,117,114,115,111,114,51,50,48,41};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,40),40,99,104,97,114,45,115,101,116,45,99,117,114,115,111,114,45,110,101,120,116,32,99,115,101,116,51,50,52,32,99,117,114,115,111,114,51,50,53,41};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,18),40,102,95,49,56,55,57,32,115,51,53,49,32,105,51,53,50,41,0,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,18),40,102,95,49,56,55,48,32,115,51,52,56,32,105,51,52,57,41,0,0,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,11),40,108,112,32,99,117,114,51,51,56,41,0,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,49),40,37,99,104,97,114,45,115,101,116,45,99,117,114,115,111,114,45,110,101,120,116,32,99,115,101,116,51,51,48,32,99,117,114,115,111,114,51,51,49,32,112,114,111,99,51,51,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,18),40,102,95,49,57,51,57,32,115,51,55,55,32,105,51,55,56,41,0,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,18),40,102,95,49,57,51,48,32,115,51,55,52,32,105,51,55,53,41,0,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,51,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,33),40,99,104,97,114,45,115,101,116,45,102,111,114,45,101,97,99,104,32,112,114,111,99,51,53,56,32,99,115,51,53,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,18),40,102,95,49,57,57,54,32,115,52,48,56,32,105,52,48,57,41,0,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,18),40,102,95,50,48,49,56,32,115,52,48,53,32,105,52,48,54,41,0,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,18),40,102,95,50,48,48,57,32,115,52,48,50,32,105,52,48,51,41,0,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,51,57,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,28),40,99,104,97,114,45,115,101,116,45,109,97,112,32,112,114,111,99,51,56,53,32,99,115,51,56,54,41,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,18),40,102,95,50,48,55,48,32,115,52,50,56,32,105,52,50,57,41,0,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,16),40,108,112,32,105,52,50,53,32,97,110,115,52,50,54,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,37),40,99,104,97,114,45,115,101,116,45,102,111,108,100,32,107,111,110,115,52,49,55,32,107,110,105,108,52,49,56,32,99,115,52,49,57,41,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,18),40,102,95,50,49,50,52,32,115,52,53,55,32,105,52,53,56,41,0,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,52,52,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,30),40,99,104,97,114,45,115,101,116,45,101,118,101,114,121,32,112,114,101,100,52,51,53,32,99,115,52,51,54,41,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,18),40,102,95,50,49,56,55,32,115,52,56,54,32,105,52,56,55,41,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,18),40,102,95,50,49,55,56,32,115,52,56,51,32,105,52,56,52,41,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,52,55,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,28),40,99,104,97,114,45,115,101,116,45,97,110,121,32,112,114,101,100,52,54,53,32,99,115,52,54,54,41,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,18),40,102,95,50,50,50,57,32,115,53,49,50,32,105,53,49,51,41,0,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,12),40,108,112,32,115,101,101,100,53,48,51,41,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,47),40,37,99,104,97,114,45,115,101,116,45,117,110,102,111,108,100,33,32,112,52,57,53,32,102,52,57,54,32,103,52,57,55,32,115,52,57,56,32,115,101,101,100,52,57,57,41,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,56),40,99,104,97,114,45,115,101,116,45,117,110,102,111,108,100,32,112,53,50,48,32,102,53,50,49,32,103,53,50,50,32,115,101,101,100,53,50,51,32,46,32,109,97,121,98,101,45,98,97,115,101,53,50,52,41};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,54),40,99,104,97,114,45,115,101,116,45,117,110,102,111,108,100,33,32,112,53,51,49,32,102,53,51,50,32,103,53,51,51,32,115,101,101,100,53,51,52,32,98,97,115,101,45,99,115,101,116,53,51,53,41,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,18),40,102,95,50,50,56,48,32,115,53,52,53,32,105,53,52,54,41,0,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,15),40,97,50,50,55,48,32,99,104,97,114,53,52,51,41,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,32),40,37,108,105,115,116,45,62,99,104,97,114,45,115,101,116,33,32,99,104,97,114,115,53,52,48,32,115,53,52,49,41};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,21),40,99,104,97,114,45,115,101,116,32,46,32,99,104,97,114,115,53,53,48,41,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,41),40,108,105,115,116,45,62,99,104,97,114,45,115,101,116,32,99,104,97,114,115,53,53,55,32,46,32,109,97,121,98,101,45,98,97,115,101,53,53,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,37),40,108,105,115,116,45,62,99,104,97,114,45,115,101,116,33,32,99,104,97,114,115,53,54,53,32,98,97,115,101,45,99,115,53,54,54,41,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,18),40,102,95,50,51,53,56,32,115,53,56,48,32,105,53,56,49,41,0,0,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,16),40,108,112,32,105,53,55,55,32,97,110,115,53,55,56,41};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,22),40,99,104,97,114,45,115,101,116,45,62,108,105,115,116,32,99,115,53,55,49,41,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,18),40,102,95,50,52,48,55,32,115,54,48,48,32,105,54,48,49,41,0,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,53,57,49,32,105,53,57,55,41};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,41),40,37,115,116,114,105,110,103,45,62,99,104,97,114,45,115,101,116,33,32,115,116,114,53,56,55,32,98,115,53,56,56,32,112,114,111,99,53,56,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,41),40,115,116,114,105,110,103,45,62,99,104,97,114,45,115,101,116,32,115,116,114,54,48,57,32,46,32,109,97,121,98,101,45,98,97,115,101,54,49,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,37),40,115,116,114,105,110,103,45,62,99,104,97,114,45,115,101,116,33,32,115,116,114,54,49,55,32,98,97,115,101,45,99,115,54,49,56,41,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,18),40,102,95,50,52,56,54,32,115,54,51,55,32,105,54,51,56,41,0,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,14),40,108,112,32,105,54,51,51,32,106,54,51,52,41,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,24),40,99,104,97,114,45,115,101,116,45,62,115,116,114,105,110,103,32,99,115,54,50,51,41};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,18),40,102,95,50,53,52,49,32,115,54,54,55,32,105,54,54,56,41,0,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,54,53,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,65),40,37,117,99,115,45,114,97,110,103,101,45,62,99,104,97,114,45,115,101,116,33,32,108,111,119,101,114,54,52,54,32,117,112,112,101,114,54,52,55,32,101,114,114,111,114,63,54,52,56,32,98,115,54,52,57,32,112,114,111,99,54,53,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,49),40,117,99,115,45,114,97,110,103,101,45,62,99,104,97,114,45,115,101,116,32,108,111,119,101,114,54,55,56,32,117,112,112,101,114,54,55,57,32,46,32,114,101,115,116,54,56,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,61),40,117,99,115,45,114,97,110,103,101,45,62,99,104,97,114,45,115,101,116,33,32,108,111,119,101,114,55,48,49,32,117,112,112,101,114,55,48,50,32,101,114,114,111,114,63,55,48,51,32,98,97,115,101,45,99,115,55,48,52,41,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,18),40,102,95,50,54,51,54,32,115,55,51,51,32,105,55,51,52,41,0,0,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,18),40,102,95,50,54,54,48,32,115,55,51,48,32,105,55,51,49,41,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,18),40,102,95,50,54,53,49,32,115,55,50,55,32,105,55,50,56,41,0,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,55,49,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,39),40,37,99,104,97,114,45,115,101,116,45,102,105,108,116,101,114,33,32,112,114,101,100,55,48,57,32,100,115,55,49,48,32,98,115,55,49,49,41,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,56),40,99,104,97,114,45,115,101,116,45,102,105,108,116,101,114,32,112,114,101,100,105,99,97,116,101,55,52,49,32,100,111,109,97,105,110,55,52,50,32,46,32,109,97,121,98,101,45,98,97,115,101,55,52,51,41};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,52),40,99,104,97,114,45,115,101,116,45,102,105,108,116,101,114,33,32,112,114,101,100,105,99,97,116,101,55,53,48,32,100,111,109,97,105,110,55,53,49,32,98,97,115,101,45,99,115,55,53,50,41,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,17),40,45,62,99,104,97,114,45,115,101,116,32,120,55,53,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,55,55,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,24),40,37,115,116,114,105,110,103,45,105,116,101,114,32,112,55,54,56,32,115,55,54,57,41};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,18),40,102,95,50,56,49,50,32,115,56,48,55,32,105,56,48,56,41,0,0,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,55,57,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,15),40,97,50,55,56,48,32,99,115,101,116,55,57,50,41,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,47),40,37,99,104,97,114,45,115,101,116,45,97,108,103,101,98,114,97,32,115,55,56,55,32,99,115,101,116,115,55,56,56,32,111,112,55,56,57,32,112,114,111,99,55,57,48,41,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,23),40,102,95,50,56,53,49,32,115,56,50,55,32,105,56,50,56,32,118,56,50,57,41,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,23),40,102,95,50,56,52,50,32,115,56,50,51,32,105,56,50,52,32,118,56,50,53,41,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,17),40,97,50,56,51,54,32,105,56,50,48,32,118,56,50,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,27),40,99,104,97,114,45,115,101,116,45,99,111,109,112,108,101,109,101,110,116,32,99,115,56,49,53,41,0,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,23),40,102,95,50,56,56,52,32,115,56,52,53,32,105,56,52,54,32,118,56,52,55,41,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,23),40,102,95,50,56,55,53,32,115,56,52,49,32,105,56,52,50,32,118,56,52,51,41,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,17),40,97,50,56,54,57,32,105,56,51,56,32,118,56,51,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,30),40,99,104,97,114,45,115,101,116,45,99,111,109,112,108,101,109,101,110,116,33,32,99,115,101,116,56,51,52,41,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,18),40,102,95,50,57,49,53,32,115,56,53,57,32,105,56,54,48,41,0,0,0,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,22),40,97,50,57,48,51,32,115,56,53,53,32,105,56,53,54,32,118,56,53,55,41,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,37),40,99,104,97,114,45,115,101,116,45,117,110,105,111,110,33,32,99,115,101,116,49,56,53,50,32,46,32,99,115,101,116,115,56,53,51,41,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,18),40,102,95,50,57,53,56,32,115,56,55,51,32,105,56,55,52,41,0,0,0,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,22),40,97,50,57,52,54,32,115,56,54,57,32,105,56,55,48,32,118,56,55,49,41,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,27),40,99,104,97,114,45,115,101,116,45,117,110,105,111,110,32,46,32,99,115,101,116,115,56,54,53,41,0,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,18),40,102,95,51,48,48,48,32,115,56,56,54,32,105,56,56,55,41,0,0,0,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,22),40,97,50,57,56,56,32,115,56,56,50,32,105,56,56,51,32,118,56,56,52,41,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,44),40,99,104,97,114,45,115,101,116,45,105,110,116,101,114,115,101,99,116,105,111,110,33,32,99,115,101,116,49,56,55,57,32,46,32,99,115,101,116,115,56,56,48,41,0,0,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,18),40,102,95,51,48,51,57,32,115,57,48,48,32,105,57,48,49,41,0,0,0,0,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,22),40,97,51,48,50,55,32,115,56,57,54,32,105,56,57,55,32,118,56,57,56,41,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,34),40,99,104,97,114,45,115,101,116,45,105,110,116,101,114,115,101,99,116,105,111,110,32,46,32,99,115,101,116,115,56,57,50,41,0,0,0,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,18),40,102,95,51,48,55,55,32,115,57,49,51,32,105,57,49,52,41,0,0,0,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,22),40,97,51,48,54,53,32,115,57,48,57,32,105,57,49,48,32,118,57,49,49,41,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,42),40,99,104,97,114,45,115,101,116,45,100,105,102,102,101,114,101,110,99,101,33,32,99,115,101,116,49,57,48,54,32,46,32,99,115,101,116,115,57,48,55,41,0,0,0,0,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,18),40,102,95,51,49,49,54,32,115,57,50,56,32,105,57,50,57,41,0,0,0,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,22),40,97,51,49,48,52,32,115,57,50,52,32,105,57,50,53,32,118,57,50,54,41,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,39),40,99,104,97,114,45,115,101,116,45,100,105,102,102,101,114,101,110,99,101,32,99,115,49,57,49,57,32,46,32,99,115,101,116,115,57,50,48,41,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,23),40,102,95,51,49,53,56,32,115,57,52,49,32,105,57,52,50,32,118,57,52,51,41,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,18),40,102,95,51,49,55,49,32,115,57,52,53,32,105,57,52,54,41,0,0,0,0,0,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,22),40,97,51,49,52,50,32,115,57,51,55,32,105,57,51,56,32,118,57,51,57,41,0,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,35),40,99,104,97,114,45,115,101,116,45,120,111,114,33,32,99,115,101,116,49,57,51,52,32,46,32,99,115,101,116,115,57,51,53,41,0,0,0,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,23),40,102,95,51,50,50,50,32,115,57,53,57,32,105,57,54,48,32,118,57,54,49,41,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,18),40,102,95,51,50,51,53,32,115,57,54,51,32,105,57,54,52,41,0,0,0,0,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,22),40,97,51,50,48,54,32,115,57,53,53,32,105,57,53,54,32,118,57,53,55,41,0,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,25),40,99,104,97,114,45,115,101,116,45,120,111,114,32,46,32,99,115,101,116,115,57,53,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,18),40,102,95,51,50,57,50,32,115,57,57,53,32,105,57,57,54,41,0,0,0,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,18),40,102,95,51,50,57,55,32,115,57,57,50,32,105,57,57,51,41,0,0,0,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,18),40,102,95,51,51,49,49,32,115,57,56,57,32,105,57,57,48,41,0,0,0,0,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,18),40,102,95,51,51,48,50,32,115,57,56,54,32,105,57,56,55,41,0,0,0,0,0,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,17),40,97,51,50,55,49,32,105,57,55,54,32,118,57,55,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,13),40,97,51,50,54,53,32,99,115,57,55,52,41,0,0,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,62),40,37,99,104,97,114,45,115,101,116,45,100,105,102,102,43,105,110,116,101,114,115,101,99,116,105,111,110,33,32,100,105,102,102,57,54,57,32,105,110,116,57,55,48,32,99,115,101,116,115,57,55,49,32,112,114,111,99,57,55,50,41,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,20),40,102,95,51,51,54,50,32,115,49,48,49,49,32,105,49,48,49,50,41,0,0,0,0};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,20),40,102,95,51,51,55,54,32,115,49,48,50,48,32,105,49,48,50,49,41,0,0,0,0};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,20),40,102,95,51,51,57,48,32,115,49,48,49,55,32,105,49,48,49,56,41,0,0,0,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,20),40,102,95,51,51,56,49,32,115,49,48,49,52,32,105,49,48,49,53,41,0,0,0,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,19),40,97,51,51,53,48,32,105,49,48,48,56,32,118,49,48,48,57,41,0,0,0,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,57),40,99,104,97,114,45,115,101,116,45,100,105,102,102,43,105,110,116,101,114,115,101,99,116,105,111,110,33,32,99,115,49,49,48,48,49,32,99,115,50,49,48,48,50,32,46,32,99,115,101,116,115,49,48,48,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,48),40,99,104,97,114,45,115,101,116,45,100,105,102,102,43,105,110,116,101,114,115,101,99,116,105,111,110,32,99,115,49,49,48,50,55,32,46,32,99,115,101,116,115,49,48,50,56,41};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_srfi_14_toplevel)
C_externexport void C_ccall C_srfi_14_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1161)
static void C_ccall f_1161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1277)
static void C_ccall f_1277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1281)
static void C_ccall f_1281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3433)
static void C_ccall f_3433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3437)
static void C_ccall f_3437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3441)
static void C_ccall f_3441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3444)
static void C_ccall f_3444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3447)
static void C_ccall f_3447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3549)
static void C_ccall f_3549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3450)
static void C_ccall f_3450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3454)
static void C_ccall f_3454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3545)
static void C_ccall f_3545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3457)
static void C_ccall f_3457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3462)
static void C_ccall f_3462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3537)
static void C_ccall f_3537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3541)
static void C_ccall f_3541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3465)
static void C_ccall f_3465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3473)
static void C_ccall f_3473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3477)
static void C_ccall f_3477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3481)
static void C_ccall f_3481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3484)
static void C_ccall f_3484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3487)
static void C_ccall f_3487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3491)
static void C_ccall f_3491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3494)
static void C_ccall f_3494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3497)
static void C_ccall f_3497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3501)
static void C_ccall f_3501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3533)
static void C_ccall f_3533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3505)
static void C_ccall f_3505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3509)
static void C_ccall f_3509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3529)
static void C_ccall f_3529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3513)
static void C_ccall f_3513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3525)
static void C_ccall f_3525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3517)
static void C_ccall f_3517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3521)
static void C_ccall f_3521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3404)
static void C_ccall f_3404(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3404)
static void C_ccall f_3404r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3429)
static void C_ccall f_3429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3408)
static void C_ccall f_3408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3411)
static void C_ccall f_3411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3414)
static void C_ccall f_3414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3421)
static void C_ccall f_3421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3425)
static void C_ccall f_3425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3333)
static void C_ccall f_3333(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3333)
static void C_ccall f_3333r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3337)
static void C_ccall f_3337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3340)
static void C_ccall f_3340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3351)
static void C_ccall f_3351(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3381)
static void C_ccall f_3381(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3390)
static void C_ccall f_3390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3389)
static void C_ccall f_3389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3372)
static void C_ccall f_3372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3376)
static void C_ccall f_3376(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3362)
static void C_ccall f_3362(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3343)
static void C_ccall f_3343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3346)
static void C_ccall f_3346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3260)
static void C_fcall f_3260(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3266)
static void C_ccall f_3266(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3272)
static void C_ccall f_3272(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3302)
static void C_ccall f_3302(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3311)
static void C_ccall f_3311(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3310)
static void C_ccall f_3310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3285)
static void C_ccall f_3285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3297)
static void C_ccall f_3297(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3288)
static void C_ccall f_3288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3292)
static void C_ccall f_3292(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3185)
static void C_ccall f_3185(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3185)
static void C_ccall f_3185r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3251)
static void C_ccall f_3251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3195)
static void C_ccall f_3195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3207)
static void C_ccall f_3207(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3235)
static void C_ccall f_3235(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3234)
static void C_ccall f_3234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3222)
static void C_ccall f_3222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3230)
static void C_ccall f_3230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3198)
static void C_ccall f_3198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3141)
static void C_ccall f_3141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3143)
static void C_ccall f_3143(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3171)
static void C_ccall f_3171(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3170)
static void C_ccall f_3170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3158)
static void C_ccall f_3158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3166)
static void C_ccall f_3166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3137)
static void C_ccall f_3137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3087)
static void C_ccall f_3087(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3087)
static void C_ccall f_3087r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3128)
static void C_ccall f_3128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3097)
static void C_ccall f_3097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3105)
static void C_ccall f_3105(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3116)
static void C_ccall f_3116(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3100)
static void C_ccall f_3100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3056)
static void C_ccall f_3056(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3056)
static void C_ccall f_3056r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3064)
static void C_ccall f_3064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3066)
static void C_ccall f_3066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3077)
static void C_ccall f_3077(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3060)
static void C_ccall f_3060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3006)
static void C_ccall f_3006(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3006)
static void C_ccall f_3006r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3047)
static void C_ccall f_3047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3016)
static void C_ccall f_3016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3028)
static void C_ccall f_3028(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3039)
static void C_ccall f_3039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3019)
static void C_ccall f_3019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2979)
static void C_ccall f_2979(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2979)
static void C_ccall f_2979r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2989)
static void C_ccall f_2989(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3000)
static void C_ccall f_3000(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2925)
static void C_ccall f_2925(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2925)
static void C_ccall f_2925r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2970)
static void C_ccall f_2970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2935)
static void C_ccall f_2935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2947)
static void C_ccall f_2947(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2958)
static void C_ccall f_2958(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2938)
static void C_ccall f_2938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2894)
static void C_ccall f_2894(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2894)
static void C_ccall f_2894r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2902)
static void C_ccall f_2902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2904)
static void C_ccall f_2904(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2915)
static void C_ccall f_2915(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2898)
static void C_ccall f_2898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2861)
static void C_ccall f_2861(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2865)
static void C_ccall f_2865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2870)
static void C_ccall f_2870(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2875)
static void C_ccall f_2875(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2884)
static void C_ccall f_2884(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2892)
static void C_ccall f_2892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2868)
static void C_ccall f_2868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2822)
static void C_ccall f_2822(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2826)
static void C_ccall f_2826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2829)
static void C_ccall f_2829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2837)
static void C_ccall f_2837(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2851)
static void C_ccall f_2851(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2859)
static void C_ccall f_2859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2832)
static void C_ccall f_2832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2775)
static void C_fcall f_2775(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2781)
static void C_ccall f_2781(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2785)
static void C_ccall f_2785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2790)
static void C_fcall f_2790(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2812)
static void C_ccall f_2812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2811)
static void C_ccall f_2811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2800)
static void C_ccall f_2800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2734)
static void C_fcall f_2734(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2744)
static void C_fcall f_2744(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2754)
static void C_ccall f_2754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2704)
static void C_ccall f_2704(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2711)
static void C_ccall f_2711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2690)
static void C_ccall f_2690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2698)
static void C_ccall f_2698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2702)
static void C_ccall f_2702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2694)
static void C_ccall f_2694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2674)
static void C_ccall f_2674(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2674)
static void C_ccall f_2674r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2678)
static void C_ccall f_2678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2688)
static void C_ccall f_2688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2681)
static void C_ccall f_2681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2606)
static void C_fcall f_2606(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2612)
static void C_fcall f_2612(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2651)
static void C_ccall f_2651(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2660)
static void C_ccall f_2660(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2659)
static void C_ccall f_2659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2643)
static void C_ccall f_2643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2632)
static void C_ccall f_2632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2636)
static void C_ccall f_2636(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2622)
static void C_ccall f_2622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2596)
static void C_ccall f_2596(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2604)
static void C_ccall f_2604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2600)
static void C_ccall f_2600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2566)
static void C_ccall f_2566(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2566)
static void C_ccall f_2566r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2576)
static void C_ccall f_2576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2579)
static void C_ccall f_2579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2504)
static void C_fcall f_2504(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2552)
static void C_fcall f_2552(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2549)
static void C_ccall f_2549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2523)
static void C_fcall f_2523(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2541)
static void C_ccall f_2541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2533)
static void C_ccall f_2533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2443)
static void C_ccall f_2443(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2447)
static void C_ccall f_2447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2502)
static void C_ccall f_2502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2450)
static void C_ccall f_2450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static void C_fcall f_2455(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2486)
static void C_ccall f_2486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2475)
static void C_ccall f_2475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2485)
static void C_ccall f_2485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2465)
static void C_fcall f_2465(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2433)
static void C_ccall f_2433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2441)
static void C_ccall f_2441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2437)
static void C_ccall f_2437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2421)
static void C_ccall f_2421(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2421)
static void C_ccall f_2421r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2425)
static void C_ccall f_2425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2428)
static void C_ccall f_2428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2372)
static void C_fcall f_2372(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2385)
static void C_fcall f_2385(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2407)
static void C_ccall f_2407(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2395)
static void C_ccall f_2395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2320)
static void C_ccall f_2320(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2324)
static void C_ccall f_2324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2329)
static void C_fcall f_2329(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2358)
static void C_ccall f_2358(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2350)
static void C_ccall f_2350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2357)
static void C_ccall f_2357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2347)
static void C_fcall f_2347(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2310)
static void C_ccall f_2310(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2318)
static void C_ccall f_2318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2314)
static void C_ccall f_2314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2298)
static void C_ccall f_2298(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2298)
static void C_ccall f_2298r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2302)
static void C_ccall f_2302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2305)
static void C_ccall f_2305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2286)
static void C_ccall f_2286(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2286)
static void C_ccall f_2286r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2290)
static void C_ccall f_2290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2293)
static void C_ccall f_2293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2265)
static void C_fcall f_2265(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2271)
static void C_ccall f_2271(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2280)
static void C_ccall f_2280(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2255)
static void C_ccall f_2255(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2263)
static void C_ccall f_2263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2259)
static void C_ccall f_2259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2243)
static void C_ccall f_2243(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_2243)
static void C_ccall f_2243r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_2247)
static void C_ccall f_2247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2250)
static void C_ccall f_2250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2201)
static void C_fcall f_2201(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2207)
static void C_fcall f_2207(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2241)
static void C_ccall f_2241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2237)
static void C_ccall f_2237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2229)
static void C_ccall f_2229(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2217)
static void C_ccall f_2217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2224)
static void C_ccall f_2224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2138)
static void C_ccall f_2138(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2147)
static void C_fcall f_2147(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2178)
static void C_ccall f_2178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2187)
static void C_ccall f_2187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2186)
static void C_ccall f_2186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2170)
static void C_ccall f_2170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2177)
static void C_ccall f_2177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2157)
static void C_ccall f_2157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2084)
static void C_ccall f_2084(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2088)
static void C_ccall f_2088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2093)
static void C_fcall f_2093(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2124)
static void C_ccall f_2124(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2106)
static void C_ccall f_2106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2123)
static void C_ccall f_2123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2109)
static void C_ccall f_2109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2032)
static void C_ccall f_2032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2036)
static void C_ccall f_2036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2041)
static void C_fcall f_2041(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2070)
static void C_ccall f_2070(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2062)
static void C_ccall f_2062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2069)
static void C_ccall f_2069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2059)
static void C_ccall f_2059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1953)
static void C_ccall f_1953(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1957)
static void C_ccall f_1957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1960)
static void C_ccall f_1960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1968)
static void C_fcall f_1968(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2009)
static void C_ccall f_2009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2018)
static void C_ccall f_2018(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2017)
static void C_ccall f_2017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1988)
static void C_ccall f_1988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2008)
static void C_ccall f_2008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2004)
static void C_ccall f_2004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1996)
static void C_ccall f_1996(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1978)
static void C_ccall f_1978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1963)
static void C_ccall f_1963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1893)
static void C_ccall f_1893(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1897)
static void C_ccall f_1897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1902)
static void C_fcall f_1902(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1930)
static void C_ccall f_1930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1939)
static void C_ccall f_1939(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1938)
static void C_ccall f_1938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1922)
static void C_ccall f_1922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1929)
static void C_ccall f_1929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1912)
static void C_ccall f_1912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1841)
static void C_fcall f_1841(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1845)
static void C_ccall f_1845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1850)
static void C_fcall f_1850(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1879)
static void C_ccall f_1879(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1878)
static void C_ccall f_1878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1863)
static void C_ccall f_1863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1832)
static void C_ccall f_1832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1826)
static void C_ccall f_1826(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1814)
static void C_ccall f_1814(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1802)
static void C_ccall f_1802(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1802)
static void C_ccall f_1802r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1808)
static void C_ccall f_1808(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1790)
static void C_ccall f_1790(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1790)
static void C_ccall f_1790r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1796)
static void C_ccall f_1796(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1778)
static void C_ccall f_1778(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1778)
static void C_ccall f_1778r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1784)
static void C_ccall f_1784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1766)
static void C_ccall f_1766(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1766)
static void C_ccall f_1766r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1772)
static void C_ccall f_1772(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1747)
static void C_fcall f_1747(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1751)
static void C_ccall f_1751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1756)
static void C_ccall f_1756(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1754)
static void C_ccall f_1754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1721)
static void C_fcall f_1721(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1745)
static void C_ccall f_1745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1725)
static void C_ccall f_1725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1733)
static void C_ccall f_1733(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1728)
static void C_ccall f_1728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1654)
static void C_ccall f_1654(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1658)
static void C_ccall f_1658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1663)
static void C_fcall f_1663(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1698)
static void C_ccall f_1698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1707)
static void C_ccall f_1707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1706)
static void C_ccall f_1706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1690)
static void C_ccall f_1690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1697)
static void C_ccall f_1697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1684)
static void C_ccall f_1684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1612)
static void C_ccall f_1612(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1616)
static void C_ccall f_1616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1621)
static void C_fcall f_1621(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1644)
static void C_ccall f_1644(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1643)
static void C_ccall f_1643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1573)
static void C_ccall f_1573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1584)
static void C_ccall f_1584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1589)
static void C_ccall f_1589(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1598)
static void C_ccall f_1598(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1597)
static void C_ccall f_1597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1460)
static void C_ccall f_1460(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1460)
static void C_ccall f_1460r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1464)
static void C_ccall f_1464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1467)
static void C_fcall f_1467(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1473)
static void C_ccall f_1473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1481)
static void C_fcall f_1481(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1517)
static void C_ccall f_1517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1505)
static void C_ccall f_1505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1502)
static void C_fcall f_1502(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1531)
static C_word C_fcall f_1531(C_word t0,C_word t1);
C_noret_decl(f_1352)
static void C_ccall f_1352(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1352)
static void C_ccall f_1352r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1372)
static void C_ccall f_1372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1374)
static void C_fcall f_1374(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1384)
static void C_ccall f_1384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1401)
static void C_fcall f_1401(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1442)
static void C_ccall f_1442(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1428)
static void C_ccall f_1428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1433)
static void C_ccall f_1433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1432)
static void C_ccall f_1432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1297)
static void C_ccall f_1297(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1297)
static void C_ccall f_1297r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1313)
static void C_ccall f_1313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1318)
static void C_fcall f_1318(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1342)
static void C_ccall f_1342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1283)
static void C_ccall f_1283(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1295)
static void C_ccall f_1295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1291)
static void C_ccall f_1291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1250)
static void C_fcall f_1250(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1256)
static void C_fcall f_1256(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1263)
static void C_ccall f_1263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1273)
static void C_ccall f_1273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1203)
static void C_fcall f_1203(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1248)
static void C_ccall f_1248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1228)
static void C_ccall f_1228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1235)
static void C_ccall f_1235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1193)
static void C_fcall f_1193(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1187)
static void C_ccall f_1187(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1181)
static void C_ccall f_1181(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1175)
static void C_ccall f_1175(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1169)
static C_word C_fcall f_1169(C_word t0);
C_noret_decl(f_1163)
static void C_ccall f_1163(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_3260)
static void C_fcall trf_3260(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3260(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3260(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2775)
static void C_fcall trf_2775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2775(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2775(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2790)
static void C_fcall trf_2790(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2790(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2790(t0,t1,t2);}

C_noret_decl(trf_2734)
static void C_fcall trf_2734(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2734(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2734(t0,t1,t2);}

C_noret_decl(trf_2744)
static void C_fcall trf_2744(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2744(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2744(t0,t1,t2);}

C_noret_decl(trf_2606)
static void C_fcall trf_2606(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2606(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2606(t0,t1,t2,t3);}

C_noret_decl(trf_2612)
static void C_fcall trf_2612(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2612(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2612(t0,t1,t2);}

C_noret_decl(trf_2504)
static void C_fcall trf_2504(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2504(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2504(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2552)
static void C_fcall trf_2552(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2552(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2552(t0,t1);}

C_noret_decl(trf_2523)
static void C_fcall trf_2523(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2523(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2523(t0,t1,t2);}

C_noret_decl(trf_2455)
static void C_fcall trf_2455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2455(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2455(t0,t1,t2,t3);}

C_noret_decl(trf_2465)
static void C_fcall trf_2465(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2465(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2465(t0,t1);}

C_noret_decl(trf_2372)
static void C_fcall trf_2372(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2372(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2372(t0,t1,t2,t3);}

C_noret_decl(trf_2385)
static void C_fcall trf_2385(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2385(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2385(t0,t1,t2);}

C_noret_decl(trf_2329)
static void C_fcall trf_2329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2329(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2329(t0,t1,t2,t3);}

C_noret_decl(trf_2347)
static void C_fcall trf_2347(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2347(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2347(t0,t1);}

C_noret_decl(trf_2265)
static void C_fcall trf_2265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2265(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2265(t0,t1,t2);}

C_noret_decl(trf_2201)
static void C_fcall trf_2201(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2201(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2201(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2207)
static void C_fcall trf_2207(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2207(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2207(t0,t1,t2);}

C_noret_decl(trf_2147)
static void C_fcall trf_2147(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2147(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2147(t0,t1,t2);}

C_noret_decl(trf_2093)
static void C_fcall trf_2093(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2093(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2093(t0,t1,t2);}

C_noret_decl(trf_2041)
static void C_fcall trf_2041(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2041(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2041(t0,t1,t2,t3);}

C_noret_decl(trf_1968)
static void C_fcall trf_1968(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1968(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1968(t0,t1,t2);}

C_noret_decl(trf_1902)
static void C_fcall trf_1902(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1902(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1902(t0,t1,t2);}

C_noret_decl(trf_1841)
static void C_fcall trf_1841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1841(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1841(t0,t1,t2,t3);}

C_noret_decl(trf_1850)
static void C_fcall trf_1850(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1850(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1850(t0,t1,t2);}

C_noret_decl(trf_1747)
static void C_fcall trf_1747(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1747(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1747(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1721)
static void C_fcall trf_1721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1721(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1721(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1663)
static void C_fcall trf_1663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1663(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1663(t0,t1,t2,t3);}

C_noret_decl(trf_1621)
static void C_fcall trf_1621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1621(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1621(t0,t1,t2,t3);}

C_noret_decl(trf_1467)
static void C_fcall trf_1467(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1467(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1467(t0,t1);}

C_noret_decl(trf_1481)
static void C_fcall trf_1481(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1481(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1481(t0,t1,t2,t3);}

C_noret_decl(trf_1502)
static void C_fcall trf_1502(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1502(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1502(t0,t1);}

C_noret_decl(trf_1374)
static void C_fcall trf_1374(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1374(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1374(t0,t1,t2,t3);}

C_noret_decl(trf_1401)
static void C_fcall trf_1401(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1401(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1401(t0,t1,t2);}

C_noret_decl(trf_1318)
static void C_fcall trf_1318(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1318(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1318(t0,t1,t2);}

C_noret_decl(trf_1250)
static void C_fcall trf_1250(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1250(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1250(t0,t1,t2);}

C_noret_decl(trf_1256)
static void C_fcall trf_1256(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1256(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1256(t0,t1,t2);}

C_noret_decl(trf_1203)
static void C_fcall trf_1203(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1203(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1203(t0,t1,t2);}

C_noret_decl(trf_1193)
static void C_fcall trf_1193(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1193(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1193(t0,t1);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_14_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_14_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_14_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(862)){
C_save(t1);
C_rereclaim2(862*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,108);
lf[2]=C_h_intern(&lf[2],13,"make-char-set");
lf[3]=C_h_intern(&lf[3],8,"char-set");
lf[4]=C_h_intern(&lf[4],10,"char-set:s");
lf[5]=C_h_intern(&lf[5],9,"char-set\077");
lf[7]=C_h_intern(&lf[7],9,"substring");
lf[9]=C_h_intern(&lf[9],9,"\003syserror");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000 BASE-CS parameter not a char-set");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\0003Expected final base char set -- too many parameters");
lf[12]=C_h_intern(&lf[12],11,"make-string");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\016Not a char-set");
lf[17]=C_h_intern(&lf[17],13,"char-set-copy");
lf[18]=C_h_intern(&lf[18],9,"char-set=");
lf[19]=C_h_intern(&lf[19],10,"char-set<=");
lf[20]=C_h_intern(&lf[20],13,"char-set-hash");
lf[21]=C_h_intern(&lf[21],6,"modulo");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[23]=C_h_intern(&lf[23],18,"char-set-contains\077");
lf[24]=C_h_intern(&lf[24],13,"char-set-size");
lf[25]=C_h_intern(&lf[25],14,"char-set-count");
lf[27]=C_h_intern(&lf[27],12,"\003sysfor-each");
lf[29]=C_h_intern(&lf[29],15,"char-set-adjoin");
lf[30]=C_h_intern(&lf[30],16,"char-set-adjoin!");
lf[31]=C_h_intern(&lf[31],15,"char-set-delete");
lf[32]=C_h_intern(&lf[32],16,"char-set-delete!");
lf[33]=C_h_intern(&lf[33],15,"char-set-cursor");
lf[35]=C_h_intern(&lf[35],16,"end-of-char-set\077");
lf[36]=C_h_intern(&lf[36],12,"char-set-ref");
lf[37]=C_h_intern(&lf[37],20,"char-set-cursor-next");
lf[38]=C_h_intern(&lf[38],17,"char-set-for-each");
lf[39]=C_h_intern(&lf[39],12,"char-set-map");
lf[40]=C_h_intern(&lf[40],13,"char-set-fold");
lf[41]=C_h_intern(&lf[41],14,"char-set-every");
lf[42]=C_h_intern(&lf[42],12,"char-set-any");
lf[44]=C_h_intern(&lf[44],15,"char-set-unfold");
lf[45]=C_h_intern(&lf[45],16,"char-set-unfold!");
lf[47]=C_h_intern(&lf[47],14,"list->char-set");
lf[48]=C_h_intern(&lf[48],15,"list->char-set!");
lf[49]=C_h_intern(&lf[49],14,"char-set->list");
lf[51]=C_h_intern(&lf[51],16,"string->char-set");
lf[52]=C_h_intern(&lf[52],17,"string->char-set!");
lf[53]=C_h_intern(&lf[53],16,"char-set->string");
lf[55]=C_h_intern(&lf[55],3,"min");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000`Requested UCS range contains unavailable characters -- this implementation "
"only supports Latin-1");
lf[57]=C_h_intern(&lf[57],19,"ucs-range->char-set");
lf[58]=C_h_intern(&lf[58],20,"ucs-range->char-set!");
lf[60]=C_h_intern(&lf[60],15,"char-set-filter");
lf[61]=C_h_intern(&lf[61],16,"char-set-filter!");
lf[62]=C_h_intern(&lf[62],10,"->char-set");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\036Not a charset, string or char.");
lf[66]=C_h_intern(&lf[66],19,"char-set-complement");
lf[67]=C_h_intern(&lf[67],20,"char-set-complement!");
lf[68]=C_h_intern(&lf[68],15,"char-set-union!");
lf[69]=C_h_intern(&lf[69],14,"char-set-union");
lf[70]=C_h_intern(&lf[70],14,"char-set:empty");
lf[71]=C_h_intern(&lf[71],22,"char-set-intersection!");
lf[72]=C_h_intern(&lf[72],21,"char-set-intersection");
lf[73]=C_h_intern(&lf[73],13,"char-set:full");
lf[74]=C_h_intern(&lf[74],20,"char-set-difference!");
lf[75]=C_h_intern(&lf[75],19,"char-set-difference");
lf[76]=C_h_intern(&lf[76],13,"char-set-xor!");
lf[77]=C_h_intern(&lf[77],12,"char-set-xor");
lf[79]=C_h_intern(&lf[79],27,"char-set-diff+intersection!");
lf[80]=C_h_intern(&lf[80],26,"char-set-diff+intersection");
lf[81]=C_h_intern(&lf[81],11,"string-copy");
lf[82]=C_h_intern(&lf[82],19,"char-set:lower-case");
lf[83]=C_h_intern(&lf[83],19,"char-set:upper-case");
lf[84]=C_h_intern(&lf[84],19,"char-set:title-case");
lf[85]=C_h_intern(&lf[85],15,"char-set:letter");
lf[86]=C_h_intern(&lf[86],14,"char-set:digit");
lf[87]=C_h_intern(&lf[87],18,"char-set:hex-digit");
lf[88]=C_h_intern(&lf[88],21,"char-set:letter+digit");
lf[89]=C_h_intern(&lf[89],20,"char-set:punctuation");
lf[90]=C_h_intern(&lf[90],15,"char-set:symbol");
lf[91]=C_h_intern(&lf[91],16,"char-set:graphic");
lf[92]=C_h_intern(&lf[92],19,"char-set:whitespace");
lf[93]=C_h_intern(&lf[93],17,"char-set:printing");
lf[94]=C_h_intern(&lf[94],14,"char-set:blank");
lf[95]=C_h_intern(&lf[95],20,"char-set:iso-control");
lf[96]=C_h_intern(&lf[96],14,"char-set:ascii");
lf[97]=C_h_intern(&lf[97],7,"\003sysmap");
lf[98]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\011\376\003\000\000\002\376\377\001\000\000\000 \376\003\000\000\002\376\377\001\000\000\000\240\376\377\016");
lf[99]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\011\376\003\000\000\002\376\377\001\000\000\000\012\376\003\000\000\002\376\377\001\000\000\000\013\376\003\000\000\002\376\377\001\000\000\000\014\376\003\000\000\002\376\377\001\000\000\000\015\376\003\000\000\002\376\377\001\000\000\000 \376\003\000\000\002\376\377\001"
"\000\000\000\240\376\377\016");
lf[100]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\242\376\003\000\000\002\376\377\001\000\000\000\243\376\003\000\000\002\376\377\001\000\000\000\244\376\003\000\000\002\376\377\001\000\000\000\245\376\003\000\000\002\376\377\001\000\000\000\246\376\003\000\000\002\376\377\001\000\000\000\247\376\003\000\000\002\376\377\001"
"\000\000\000\250\376\003\000\000\002\376\377\001\000\000\000\251\376\003\000\000\002\376\377\001\000\000\000\254\376\003\000\000\002\376\377\001\000\000\000\256\376\003\000\000\002\376\377\001\000\000\000\257\376\003\000\000\002\376\377\001\000\000\000\260\376\003\000\000\002\376\377\001\000\000\000\261\376\003\000\000"
"\002\376\377\001\000\000\000\264\376\003\000\000\002\376\377\001\000\000\000\266\376\003\000\000\002\376\377\001\000\000\000\270\376\003\000\000\002\376\377\001\000\000\000\327\376\003\000\000\002\376\377\001\000\000\000\367\376\377\016");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\011$+<=>^`|~");
lf[102]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\241\376\003\000\000\002\376\377\001\000\000\000\253\376\003\000\000\002\376\377\001\000\000\000\255\376\003\000\000\002\376\377\001\000\000\000\267\376\003\000\000\002\376\377\001\000\000\000\273\376\003\000\000\002\376\377\001\000\000\000\277\376\377\016");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\027!\042#%&\047()*,-./:;\077@[\134]_{}");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\0260123456789abcdefABCDEF");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\0120123456789");
lf[106]=C_h_intern(&lf[106],17,"register-feature!");
lf[107]=C_h_intern(&lf[107],7,"srfi-14");
C_register_lf2(lf,108,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1161,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 28   register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[106]+1)))(3,*((C_word*)lf[106]+1),t2,lf[107]);}

/* k1159 */
static void C_ccall f_1161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1161,2,t0,t1);}
t2=C_mutate(&lf[0] /* (set! %latin1->char ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1163,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[1] /* (set! %char->latin1 ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1169,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[2]+1 /* (set! make-char-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1175,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[4]+1 /* (set! char-set:s ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1181,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[5]+1 /* (set! char-set? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1187,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[6] /* (set! %string-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1193,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate(&lf[8] /* (set! %default-base ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1203,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[13] /* (set! %char-set:s/check ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1250,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1277,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 154  %latin1->char */
t11=lf[0];
f_1163(3,t11,t10,C_fix(0));}

/* k1275 in k1159 */
static void C_ccall f_1277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1277,2,t0,t1);}
t2=C_mutate(&lf[15] /* (set! c0 ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1281,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 155  %latin1->char */
t4=lf[0];
f_1163(3,t4,t3,C_fix(1));}

/* k1279 in k1275 in k1159 */
static void C_ccall f_1281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word ab[174],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1281,2,t0,t1);}
t2=C_mutate(&lf[16] /* (set! c1 ...) */,t1);
t3=C_mutate((C_word*)lf[17]+1 /* (set! char-set-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1283,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[18]+1 /* (set! char-set= ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1297,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[19]+1 /* (set! char-set<= ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1352,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[20]+1 /* (set! char-set-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1460,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[23]+1 /* (set! char-set-contains? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1573,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[24]+1 /* (set! char-set-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1612,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[25]+1 /* (set! char-set-count ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1654,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate(&lf[26] /* (set! %set-char-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1721,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[28] /* (set! %set-char-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1747,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[29]+1 /* (set! char-set-adjoin ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1766,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[30]+1 /* (set! char-set-adjoin! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1778,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[31]+1 /* (set! char-set-delete ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1790,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[32]+1 /* (set! char-set-delete! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1802,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[33]+1 /* (set! char-set-cursor ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1814,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[35]+1 /* (set! end-of-char-set? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1820,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[36]+1 /* (set! char-set-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1826,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[37]+1 /* (set! char-set-cursor-next ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1832,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate(&lf[34] /* (set! %char-set-cursor-next ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1841,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[38]+1 /* (set! char-set-for-each ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1893,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[39]+1 /* (set! char-set-map ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1953,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[40]+1 /* (set! char-set-fold ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2032,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[41]+1 /* (set! char-set-every ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2084,a[2]=((C_word)li65),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[42]+1 /* (set! char-set-any ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2138,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate(&lf[43] /* (set! %char-set-unfold! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2201,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[44]+1 /* (set! char-set-unfold ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2243,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[45]+1 /* (set! char-set-unfold! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2255,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate(&lf[46] /* (set! %list->char-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2265,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[3]+1 /* (set! char-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2286,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[47]+1 /* (set! list->char-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2298,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[48]+1 /* (set! list->char-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2310,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[49]+1 /* (set! char-set->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2320,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate(&lf[50] /* (set! %string->char-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2372,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t35=C_mutate((C_word*)lf[51]+1 /* (set! string->char-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2421,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[52]+1 /* (set! string->char-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2433,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp));
t37=C_mutate((C_word*)lf[53]+1 /* (set! char-set->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2443,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp));
t38=C_mutate(&lf[54] /* (set! %ucs-range->char-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2504,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp));
t39=C_mutate((C_word*)lf[57]+1 /* (set! ucs-range->char-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2566,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp));
t40=C_mutate((C_word*)lf[58]+1 /* (set! ucs-range->char-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2596,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp));
t41=C_mutate(&lf[59] /* (set! %char-set-filter! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2606,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[60]+1 /* (set! char-set-filter ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2674,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[61]+1 /* (set! char-set-filter! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2690,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[62]+1 /* (set! ->char-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2704,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate(&lf[64] /* (set! %string-iter ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2734,a[2]=((C_word)li106),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate(&lf[65] /* (set! %char-set-algebra ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2775,a[2]=((C_word)li110),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[66]+1 /* (set! char-set-complement ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2822,a[2]=((C_word)li114),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[67]+1 /* (set! char-set-complement! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2861,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[68]+1 /* (set! char-set-union! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2894,a[2]=((C_word)li121),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[69]+1 /* (set! char-set-union ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2925,a[2]=((C_word)li124),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[71]+1 /* (set! char-set-intersection! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2979,a[2]=((C_word)li127),tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[72]+1 /* (set! char-set-intersection ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3006,a[2]=((C_word)li130),tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[74]+1 /* (set! char-set-difference! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3056,a[2]=((C_word)li133),tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[75]+1 /* (set! char-set-difference ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3087,a[2]=((C_word)li136),tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[76]+1 /* (set! char-set-xor! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3133,a[2]=((C_word)li140),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[77]+1 /* (set! char-set-xor ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3185,a[2]=((C_word)li144),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate(&lf[78] /* (set! %char-set-diff+intersection! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3260,a[2]=((C_word)li151),tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[79]+1 /* (set! char-set-diff+intersection! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3333,a[2]=((C_word)li157),tmp=(C_word)a,a+=3,tmp));
t59=C_mutate((C_word*)lf[80]+1 /* (set! char-set-diff+intersection ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3404,a[2]=((C_word)li158),tmp=(C_word)a,a+=3,tmp));
t60=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3433,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 643  char-set */
t61=*((C_word*)lf[3]+1);
((C_proc2)(void*)(*((C_word*)t61+1)))(2,t61,t60);}

/* k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3433,2,t0,t1);}
t2=C_mutate((C_word*)lf[70]+1 /* (set! char-set:empty ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3437,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 644  char-set-complement */
t4=*((C_word*)lf[66]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[70]+1));}

/* k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3437,2,t0,t1);}
t2=C_mutate((C_word*)lf[73]+1 /* (set! char-set:full ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3441,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 647  ucs-range->char-set */
t4=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(97),C_fix(123));}

/* k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3444,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 648  ucs-range->char-set! */
t3=*((C_word*)lf[58]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_fix(223),C_fix(247),C_SCHEME_TRUE,t1);}

/* k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3447,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 649  ucs-range->char-set! */
t3=*((C_word*)lf[58]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_fix(248),C_fix(256),C_SCHEME_TRUE,t1);}

/* k3445 in k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3450,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3549,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 650  %latin1->char */
t4=lf[0];
f_1163(3,t4,t3,C_fix(181));}

/* k3547 in k3445 in k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 650  char-set-adjoin! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[30]+1)))(4,*((C_word*)lf[30]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3448 in k3445 in k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3450,2,t0,t1);}
t2=C_mutate((C_word*)lf[82]+1 /* (set! char-set:lower-case ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3454,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 653  ucs-range->char-set */
t4=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(65),C_fix(91));}

/* k3452 in k3448 in k3445 in k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3457,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3545,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 656  ucs-range->char-set! */
t4=*((C_word*)lf[58]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,C_fix(192),C_fix(215),C_SCHEME_TRUE,t1);}

/* k3543 in k3452 in k3448 in k3445 in k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 655  ucs-range->char-set! */
t2=*((C_word*)lf[58]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],C_fix(216),C_fix(223),C_SCHEME_TRUE,t1);}

/* k3455 in k3452 in k3448 in k3445 in k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3457,2,t0,t1);}
t2=C_mutate((C_word*)lf[83]+1 /* (set! char-set:upper-case ...) */,t1);
t3=C_mutate((C_word*)lf[84]+1 /* (set! char-set:title-case ...) */,*((C_word*)lf[70]+1));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3462,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 661  char-set-union */
t5=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[83]+1),*((C_word*)lf[82]+1));}

/* k3460 in k3455 in k3452 in k3448 in k3445 in k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3465,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3537,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 663  %latin1->char */
t4=lf[0];
f_1163(3,t4,t3,C_fix(170));}

/* k3535 in k3460 in k3455 in k3452 in k3448 in k3445 in k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3541,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 664  %latin1->char */
t3=lf[0];
f_1163(3,t3,t2,C_fix(186));}

/* k3539 in k3535 in k3460 in k3455 in k3452 in k3448 in k3445 in k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 662  char-set-adjoin! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[30]+1)))(5,*((C_word*)lf[30]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3463 in k3460 in k3455 in k3452 in k3448 in k3445 in k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3465,2,t0,t1);}
t2=C_mutate((C_word*)lf[85]+1 /* (set! char-set:letter ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3469,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 666  string->char-set */
t4=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[105]);}

/* k3467 in k3463 in k3460 in k3455 in k3452 in k3448 in k3445 in k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3469,2,t0,t1);}
t2=C_mutate((C_word*)lf[86]+1 /* (set! char-set:digit ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3473,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 667  string->char-set */
t4=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[104]);}

/* k3471 in k3467 in k3463 in k3460 in k3455 in k3452 in k3448 in k3445 in k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3473,2,t0,t1);}
t2=C_mutate((C_word*)lf[87]+1 /* (set! char-set:hex-digit ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3477,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 670  char-set-union */
t4=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[85]+1),*((C_word*)lf[86]+1));}

/* k3475 in k3471 in k3467 in k3463 in k3460 in k3455 in k3452 in k3448 in k3445 in k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3477,2,t0,t1);}
t2=C_mutate((C_word*)lf[88]+1 /* (set! char-set:letter+digit ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3481,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 673  string->char-set */
t4=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[103]);}

/* k3479 in k3475 in k3471 in k3467 in k3463 in k3460 in k3455 in k3452 in k3448 in k3445 in k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3481,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3484,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[0],lf[102]);}

/* k3482 in k3479 in k3475 in k3471 in k3467 in k3463 in k3460 in k3455 in k3452 in k3448 in k3445 in k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3487,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 680  list->char-set! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[48]+1)))(4,*((C_word*)lf[48]+1),t2,t1,((C_word*)t0)[2]);}

/* k3485 in k3482 in k3479 in k3475 in k3471 in k3467 in k3463 in k3460 in k3455 in k3452 in k3448 in k3445 in k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3487,2,t0,t1);}
t2=C_mutate((C_word*)lf[89]+1 /* (set! char-set:punctuation ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3491,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 683  string->char-set */
t4=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[101]);}

/* k3489 in k3485 in k3482 in k3479 in k3475 in k3471 in k3467 in k3463 in k3460 in k3455 in k3452 in k3448 in k3445 in k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3494,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[0],lf[100]);}

/* k3492 in k3489 in k3485 in k3482 in k3479 in k3475 in k3471 in k3467 in k3463 in k3460 in k3455 in k3452 in k3448 in k3445 in k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3494,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3497,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 702  list->char-set! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[48]+1)))(4,*((C_word*)lf[48]+1),t2,t1,((C_word*)t0)[2]);}

/* k3495 in k3492 in k3489 in k3485 in k3482 in k3479 in k3475 in k3471 in k3467 in k3463 in k3460 in k3455 in k3452 in k3448 in k3445 in k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3497,2,t0,t1);}
t2=C_mutate((C_word*)lf[90]+1 /* (set! char-set:symbol ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3501,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 706  char-set-union */
t4=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,*((C_word*)lf[88]+1),*((C_word*)lf[89]+1),*((C_word*)lf[90]+1));}

/* k3499 in k3495 in k3492 in k3489 in k3485 in k3482 in k3479 in k3475 in k3471 in k3467 in k3463 in k3460 in k3455 in k3452 in k3448 in k3445 in k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3501,2,t0,t1);}
t2=C_mutate((C_word*)lf[91]+1 /* (set! char-set:graphic ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3505,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3533,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[0],lf[99]);}

/* k3531 in k3499 in k3495 in k3492 in k3489 in k3485 in k3482 in k3479 in k3475 in k3471 in k3467 in k3463 in k3460 in k3455 in k3452 in k3448 in k3445 in k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 709  list->char-set */
t2=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3503 in k3499 in k3495 in k3492 in k3489 in k3485 in k3482 in k3479 in k3475 in k3471 in k3467 in k3463 in k3460 in k3455 in k3452 in k3448 in k3445 in k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3505,2,t0,t1);}
t2=C_mutate((C_word*)lf[92]+1 /* (set! char-set:whitespace ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3509,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 717  char-set-union */
t4=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[92]+1),*((C_word*)lf[91]+1));}

/* k3507 in k3503 in k3499 in k3495 in k3492 in k3489 in k3485 in k3482 in k3479 in k3475 in k3471 in k3467 in k3463 in k3460 in k3455 in k3452 in k3448 in k3445 in k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3509,2,t0,t1);}
t2=C_mutate((C_word*)lf[93]+1 /* (set! char-set:printing ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3513,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3529,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[0],lf[98]);}

/* k3527 in k3507 in k3503 in k3499 in k3495 in k3492 in k3489 in k3485 in k3482 in k3479 in k3475 in k3471 in k3467 in k3463 in k3460 in k3455 in k3452 in k3448 in k3445 in k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 720  list->char-set */
t2=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3511 in k3507 in k3503 in k3499 in k3495 in k3492 in k3489 in k3485 in k3482 in k3479 in k3475 in k3471 in k3467 in k3463 in k3460 in k3455 in k3452 in k3448 in k3445 in k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3513,2,t0,t1);}
t2=C_mutate((C_word*)lf[94]+1 /* (set! char-set:blank ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3517,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3525,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 726  ucs-range->char-set */
t5=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_fix(0),C_fix(32));}

/* k3523 in k3511 in k3507 in k3503 in k3499 in k3495 in k3492 in k3489 in k3485 in k3482 in k3479 in k3475 in k3471 in k3467 in k3463 in k3460 in k3455 in k3452 in k3448 in k3445 in k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 726  ucs-range->char-set! */
t2=*((C_word*)lf[58]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],C_fix(127),C_fix(160),C_SCHEME_TRUE,t1);}

/* k3515 in k3511 in k3507 in k3503 in k3499 in k3495 in k3492 in k3489 in k3485 in k3482 in k3479 in k3475 in k3471 in k3467 in k3463 in k3460 in k3455 in k3452 in k3448 in k3445 in k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3517,2,t0,t1);}
t2=C_mutate((C_word*)lf[95]+1 /* (set! char-set:iso-control ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3521,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 728  ucs-range->char-set */
t4=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(0),C_fix(128));}

/* k3519 in k3515 in k3511 in k3507 in k3503 in k3499 in k3495 in k3492 in k3489 in k3485 in k3482 in k3479 in k3475 in k3471 in k3467 in k3463 in k3460 in k3455 in k3452 in k3448 in k3445 in k3442 in k3439 in k3435 in k3431 in k1279 in k1275 in k1159 */
static void C_ccall f_3521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[96]+1 /* (set! char-set:ascii ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* char-set-diff+intersection in k1279 in k1275 in k1159 */
static void C_ccall f_3404(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_3404r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3404r(t0,t1,t2,t3);}}

static void C_ccall f_3404r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3408,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3429,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 629  %char-set:s/check */
f_1250(t5,t2,lf[80]);}

/* k3427 in char-set-diff+intersection in k1279 in k1275 in k1159 */
static void C_ccall f_3429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 629  string-copy */
t2=*((C_word*)lf[81]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3406 in char-set-diff+intersection in k1279 in k1275 in k1159 */
static void C_ccall f_3408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3411,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 630  make-string */
t3=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(256),lf[15]);}

/* k3409 in k3406 in char-set-diff+intersection in k1279 in k1275 in k1159 */
static void C_ccall f_3411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3414,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 631  %char-set-diff+intersection! */
f_3260(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],lf[80]);}

/* k3412 in k3409 in k3406 in char-set-diff+intersection in k1279 in k1275 in k1159 */
static void C_ccall f_3414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3421,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 632  make-char-set */
t3=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3419 in k3412 in k3409 in k3406 in char-set-diff+intersection in k1279 in k1275 in k1159 */
static void C_ccall f_3421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3425,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 632  make-char-set */
t3=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3423 in k3419 in k3412 in k3409 in k3406 in char-set-diff+intersection in k1279 in k1275 in k1159 */
static void C_ccall f_3425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 632  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* char-set-diff+intersection! in k1279 in k1275 in k1159 */
static void C_ccall f_3333(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_3333r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3333r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3333r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3337,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-14.scm: 619  %char-set:s/check */
f_1250(t5,t2,lf[79]);}

/* k3335 in char-set-diff+intersection! in k1279 in k1275 in k1159 */
static void C_ccall f_3337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3340,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* srfi-14.scm: 620  %char-set:s/check */
f_1250(t2,((C_word*)t0)[3],lf[79]);}

/* k3338 in k3335 in char-set-diff+intersection! in k1279 in k1275 in k1159 */
static void C_ccall f_3340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3343,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3351,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li156),tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 621  %string-iter */
f_2734(t2,t3,((C_word*)t0)[3]);}

/* a3350 in k3338 in k3335 in char-set-diff+intersection! in k1279 in k1275 in k1159 */
static void C_ccall f_3351(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3351,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3362,a[2]=((C_word)li152),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,((C_word*)t0)[3],t2);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3372,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3381,a[2]=((C_word)li155),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[3],t2);}}

/* f_3381 in a3350 in k3338 in k3335 in char-set-diff+intersection! in k1279 in k1275 in k1159 */
static void C_ccall f_3381(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3381,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3389,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3390,a[2]=((C_word)li154),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* f_3390 */
static void C_ccall f_3390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3390,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=f_1169(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t5,C_fix(0)));}

/* k3387 */
static void C_ccall f_3389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k3370 in a3350 in k3338 in k3335 in char-set-diff+intersection! in k1279 in k1275 in k1159 */
static void C_ccall f_3372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3372,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3376,a[2]=((C_word)li153),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* f_3376 in k3370 in a3350 in k3338 in k3335 in char-set-diff+intersection! in k1279 in k1275 in k1159 */
static void C_ccall f_3376(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3376,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[15]));}

/* f_3362 in a3350 in k3338 in k3335 in char-set-diff+intersection! in k1279 in k1275 in k1159 */
static void C_ccall f_3362(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3362,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[15]));}

/* k3341 in k3338 in k3335 in char-set-diff+intersection! in k1279 in k1275 in k1159 */
static void C_ccall f_3343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3346,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 625  %char-set-diff+intersection! */
f_3260(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[79]);}

/* k3344 in k3341 in k3338 in k3335 in char-set-diff+intersection! in k1279 in k1275 in k1159 */
static void C_ccall f_3346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 626  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-diff+intersection! in k1279 in k1275 in k1159 */
static void C_fcall f_3260(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3260,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3266,a[2]=t5,a[3]=t2,a[4]=t3,a[5]=((C_word)li150),tmp=(C_word)a,a+=6,tmp);
/* for-each */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t4);}

/* a3265 in %char-set-diff+intersection! in k1279 in k1275 in k1159 */
static void C_ccall f_3266(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3266,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3272,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li149),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3331,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 615  %char-set:s/check */
f_1250(t4,t2,((C_word*)t0)[2]);}

/* k3329 in a3265 in %char-set-diff+intersection! in k1279 in k1275 in k1159 */
static void C_ccall f_3331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 610  %string-iter */
f_2734(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3271 in a3265 in %char-set-diff+intersection! in k1279 in k1275 in k1159 */
static void C_ccall f_3272(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3272,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3285,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3302,a[2]=((C_word)li148),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t2);}}

/* f_3302 in a3271 in a3265 in %char-set-diff+intersection! in k1279 in k1275 in k1159 */
static void C_ccall f_3302(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3302,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3310,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3311,a[2]=((C_word)li147),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* f_3311 */
static void C_ccall f_3311(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3311,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=f_1169(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t5,C_fix(0)));}

/* k3308 */
static void C_ccall f_3310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k3283 in a3271 in a3265 in %char-set-diff+intersection! in k1279 in k1275 in k1159 */
static void C_ccall f_3285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3285,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3288,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3297,a[2]=((C_word)li146),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* f_3297 in k3283 in a3271 in a3265 in %char-set-diff+intersection! in k1279 in k1275 in k1159 */
static void C_ccall f_3297(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3297,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[15]));}

/* k3286 in k3283 in a3271 in a3265 in %char-set-diff+intersection! in k1279 in k1275 in k1159 */
static void C_ccall f_3288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3292,a[2]=((C_word)li145),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_3292 in k3286 in k3283 in a3271 in a3265 in %char-set-diff+intersection! in k1279 in k1275 in k1159 */
static void C_ccall f_3292(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3292,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[16]));}

/* char-set-xor in k1279 in k1275 in k1159 */
static void C_ccall f_3185(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_3185r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3185r(t0,t1,t2);}}

static void C_ccall f_3185r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3195,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3251,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(t2);
/* srfi-14.scm: 600  %char-set:s/check */
f_1250(t4,t5,lf[77]);}
else{
/* srfi-14.scm: 603  char-set-copy */
t3=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,*((C_word*)lf[70]+1));}}

/* k3249 in char-set-xor in k1279 in k1275 in k1159 */
static void C_ccall f_3251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 600  %string-copy */
f_1193(((C_word*)t0)[2],t1);}

/* k3193 in char-set-xor in k1279 in k1275 in k1159 */
static void C_ccall f_3195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3198,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3207,a[2]=((C_word)li143),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 601  %char-set-algebra */
f_2775(t2,t1,t3,t4,lf[77]);}

/* a3206 in k3193 in char-set-xor in k1279 in k1275 in k1159 */
static void C_ccall f_3207(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3207,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3234,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3235,a[2]=((C_word)li142),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,t3);}}

/* f_3235 in a3206 in k3193 in char-set-xor in k1279 in k1275 in k1159 */
static void C_ccall f_3235(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3235,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
/* srfi-14.scm: 150  %char->latin1 */
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_1169(t4));}

/* k3232 in a3206 in k3193 in char-set-xor in k1279 in k1275 in k1159 */
static void C_ccall f_3234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3234,2,t0,t1);}
t2=(C_word)C_fixnum_difference(C_fix(1),t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3222,a[2]=((C_word)li141),tmp=(C_word)a,a+=3,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* f_3222 in k3232 in a3206 in k3193 in char-set-xor in k1279 in k1275 in k1159 */
static void C_ccall f_3222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3222,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3230,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 160  %latin1->char */
t6=lf[0];
f_1163(3,t6,t5,t4);}

/* k3228 */
static void C_ccall f_3230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_string_set(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k3196 in k3193 in char-set-xor in k1279 in k1275 in k1159 */
static void C_ccall f_3198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 602  make-char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-xor! in k1279 in k1275 in k1159 */
static void C_ccall f_3133(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_3133r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3133r(t0,t1,t2,t3);}}

static void C_ccall f_3133r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3137,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3141,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 594  %char-set:s/check */
f_1250(t5,t2,lf[76]);}

/* k3139 in char-set-xor! in k1279 in k1275 in k1159 */
static void C_ccall f_3141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3143,a[2]=((C_word)li139),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 594  %char-set-algebra */
f_2775(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[76]);}

/* a3142 in k3139 in char-set-xor! in k1279 in k1275 in k1159 */
static void C_ccall f_3143(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3143,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3170,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3171,a[2]=((C_word)li138),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,t3);}}

/* f_3171 in a3142 in k3139 in char-set-xor! in k1279 in k1275 in k1159 */
static void C_ccall f_3171(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3171,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
/* srfi-14.scm: 150  %char->latin1 */
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_1169(t4));}

/* k3168 in a3142 in k3139 in char-set-xor! in k1279 in k1275 in k1159 */
static void C_ccall f_3170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3170,2,t0,t1);}
t2=(C_word)C_fixnum_difference(C_fix(1),t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3158,a[2]=((C_word)li137),tmp=(C_word)a,a+=3,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* f_3158 in k3168 in a3142 in k3139 in char-set-xor! in k1279 in k1275 in k1159 */
static void C_ccall f_3158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3158,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3166,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 160  %latin1->char */
t6=lf[0];
f_1163(3,t6,t5,t4);}

/* k3164 */
static void C_ccall f_3166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_string_set(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k3135 in char-set-xor! in k1279 in k1275 in k1159 */
static void C_ccall f_3137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-difference in k1279 in k1275 in k1159 */
static void C_ccall f_3087(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_3087r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3087r(t0,t1,t2,t3);}}

static void C_ccall f_3087r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3097,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3128,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 585  %char-set:s/check */
f_1250(t5,t2,lf[75]);}
else{
/* srfi-14.scm: 588  char-set-copy */
t4=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}}

/* k3126 in char-set-difference in k1279 in k1275 in k1159 */
static void C_ccall f_3128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 585  %string-copy */
f_1193(((C_word*)t0)[2],t1);}

/* k3095 in char-set-difference in k1279 in k1275 in k1159 */
static void C_ccall f_3097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3097,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3100,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3105,a[2]=((C_word)li135),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 586  %char-set-algebra */
f_2775(t2,t1,((C_word*)t0)[2],t3,lf[75]);}

/* a3104 in k3095 in char-set-difference in k1279 in k1275 in k1159 */
static void C_ccall f_3105(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3105,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3116,a[2]=((C_word)li134),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t2,t3);}}

/* f_3116 in a3104 in k3095 in char-set-difference in k1279 in k1275 in k1159 */
static void C_ccall f_3116(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3116,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[15]));}

/* k3098 in k3095 in char-set-difference in k1279 in k1275 in k1159 */
static void C_ccall f_3100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 587  make-char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-difference! in k1279 in k1275 in k1159 */
static void C_ccall f_3056(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_3056r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3056r(t0,t1,t2,t3);}}

static void C_ccall f_3056r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3060,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3064,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 579  %char-set:s/check */
f_1250(t5,t2,lf[74]);}

/* k3062 in char-set-difference! in k1279 in k1275 in k1159 */
static void C_ccall f_3064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3066,a[2]=((C_word)li132),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 579  %char-set-algebra */
f_2775(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[74]);}

/* a3065 in k3062 in char-set-difference! in k1279 in k1275 in k1159 */
static void C_ccall f_3066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3066,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3077,a[2]=((C_word)li131),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t2,t3);}}

/* f_3077 in a3065 in k3062 in char-set-difference! in k1279 in k1275 in k1159 */
static void C_ccall f_3077(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3077,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[15]));}

/* k3058 in char-set-difference! in k1279 in k1275 in k1159 */
static void C_ccall f_3060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-intersection in k1279 in k1275 in k1159 */
static void C_ccall f_3006(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_3006r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3006r(t0,t1,t2);}}

static void C_ccall f_3006r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3016,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3047,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(t2);
/* srfi-14.scm: 570  %char-set:s/check */
f_1250(t4,t5,lf[72]);}
else{
/* srfi-14.scm: 573  char-set-copy */
t3=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,*((C_word*)lf[73]+1));}}

/* k3045 in char-set-intersection in k1279 in k1275 in k1159 */
static void C_ccall f_3047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 570  %string-copy */
f_1193(((C_word*)t0)[2],t1);}

/* k3014 in char-set-intersection in k1279 in k1275 in k1159 */
static void C_ccall f_3016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3019,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3028,a[2]=((C_word)li129),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 571  %char-set-algebra */
f_2775(t2,t1,t3,t4,lf[72]);}

/* a3027 in k3014 in char-set-intersection in k1279 in k1275 in k1159 */
static void C_ccall f_3028(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3028,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3039,a[2]=((C_word)li128),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t2,t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* f_3039 in a3027 in k3014 in char-set-intersection in k1279 in k1275 in k1159 */
static void C_ccall f_3039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3039,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[15]));}

/* k3017 in k3014 in char-set-intersection in k1279 in k1275 in k1159 */
static void C_ccall f_3019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 572  make-char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-intersection! in k1279 in k1275 in k1159 */
static void C_ccall f_2979(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2979r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2979r(t0,t1,t2,t3);}}

static void C_ccall f_2979r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2983,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2987,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 564  %char-set:s/check */
f_1250(t5,t2,lf[71]);}

/* k2985 in char-set-intersection! in k1279 in k1275 in k1159 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2989,a[2]=((C_word)li126),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 564  %char-set-algebra */
f_2775(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[71]);}

/* a2988 in k2985 in char-set-intersection! in k1279 in k1275 in k1159 */
static void C_ccall f_2989(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2989,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3000,a[2]=((C_word)li125),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t2,t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* f_3000 in a2988 in k2985 in char-set-intersection! in k1279 in k1275 in k1159 */
static void C_ccall f_3000(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3000,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[15]));}

/* k2981 in char-set-intersection! in k1279 in k1275 in k1159 */
static void C_ccall f_2983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-union in k1279 in k1275 in k1159 */
static void C_ccall f_2925(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2925r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2925r(t0,t1,t2);}}

static void C_ccall f_2925r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2935,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2970,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(t2);
/* srfi-14.scm: 555  %char-set:s/check */
f_1250(t4,t5,lf[69]);}
else{
/* srfi-14.scm: 558  char-set-copy */
t3=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,*((C_word*)lf[70]+1));}}

/* k2968 in char-set-union in k1279 in k1275 in k1159 */
static void C_ccall f_2970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 555  %string-copy */
f_1193(((C_word*)t0)[2],t1);}

/* k2933 in char-set-union in k1279 in k1275 in k1159 */
static void C_ccall f_2935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2938,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2947,a[2]=((C_word)li123),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 556  %char-set-algebra */
f_2775(t2,t1,t3,t4,lf[69]);}

/* a2946 in k2933 in char-set-union in k1279 in k1275 in k1159 */
static void C_ccall f_2947(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2947,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2958,a[2]=((C_word)li122),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t2,t3);}}

/* f_2958 in a2946 in k2933 in char-set-union in k1279 in k1275 in k1159 */
static void C_ccall f_2958(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2958,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[16]));}

/* k2936 in k2933 in char-set-union in k1279 in k1275 in k1159 */
static void C_ccall f_2938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 557  make-char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-union! in k1279 in k1275 in k1159 */
static void C_ccall f_2894(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2894r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2894r(t0,t1,t2,t3);}}

static void C_ccall f_2894r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2898,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2902,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 549  %char-set:s/check */
f_1250(t5,t2,lf[68]);}

/* k2900 in char-set-union! in k1279 in k1275 in k1159 */
static void C_ccall f_2902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2904,a[2]=((C_word)li120),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 549  %char-set-algebra */
f_2775(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[68]);}

/* a2903 in k2900 in char-set-union! in k1279 in k1275 in k1159 */
static void C_ccall f_2904(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2904,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2915,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t2,t3);}}

/* f_2915 in a2903 in k2900 in char-set-union! in k1279 in k1275 in k1159 */
static void C_ccall f_2915(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2915,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[16]));}

/* k2896 in char-set-union! in k1279 in k1275 in k1159 */
static void C_ccall f_2898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-complement! in k1279 in k1275 in k1159 */
static void C_ccall f_2861(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2861,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2865,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 541  %char-set:s/check */
f_1250(t3,t2,lf[67]);}

/* k2863 in char-set-complement! in k1279 in k1275 in k1159 */
static void C_ccall f_2865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2868,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2870,a[2]=t1,a[3]=((C_word)li117),tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 542  %string-iter */
f_2734(t2,t3,t1);}

/* a2869 in k2863 in char-set-complement! in k1279 in k1275 in k1159 */
static void C_ccall f_2870(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2870,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2875,a[2]=((C_word)li116),tmp=(C_word)a,a+=3,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* f_2875 in a2869 in k2863 in char-set-complement! in k1279 in k1275 in k1159 */
static void C_ccall f_2875(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2875,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(C_fix(1),t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2884,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t3,t5);}

/* f_2884 */
static void C_ccall f_2884(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2884,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2892,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 160  %latin1->char */
t6=lf[0];
f_1163(3,t6,t5,t4);}

/* k2890 */
static void C_ccall f_2892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_string_set(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2866 in k2863 in char-set-complement! in k1279 in k1275 in k1159 */
static void C_ccall f_2868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-complement in k1279 in k1275 in k1159 */
static void C_ccall f_2822(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2822,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2826,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 535  %char-set:s/check */
f_1250(t3,t2,lf[66]);}

/* k2824 in char-set-complement in k1279 in k1275 in k1159 */
static void C_ccall f_2826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2829,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 536  make-string */
t3=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(256));}

/* k2827 in k2824 in char-set-complement in k1279 in k1275 in k1159 */
static void C_ccall f_2829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2829,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2832,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2837,a[2]=t1,a[3]=((C_word)li113),tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 537  %string-iter */
f_2734(t2,t3,((C_word*)t0)[2]);}

/* a2836 in k2827 in k2824 in char-set-complement in k1279 in k1275 in k1159 */
static void C_ccall f_2837(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2837,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2842,a[2]=((C_word)li112),tmp=(C_word)a,a+=3,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* f_2842 in a2836 in k2827 in k2824 in char-set-complement in k1279 in k1275 in k1159 */
static void C_ccall f_2842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2842,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(C_fix(1),t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2851,a[2]=((C_word)li111),tmp=(C_word)a,a+=3,tmp);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t3,t5);}

/* f_2851 */
static void C_ccall f_2851(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2851,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2859,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 160  %latin1->char */
t6=lf[0];
f_1163(3,t6,t5,t4);}

/* k2857 */
static void C_ccall f_2859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_string_set(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2830 in k2827 in k2824 in char-set-complement in k1279 in k1275 in k1159 */
static void C_ccall f_2832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 538  make-char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-algebra in k1279 in k1275 in k1159 */
static void C_fcall f_2775(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2775,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2781,a[2]=t5,a[3]=t2,a[4]=t4,a[5]=((C_word)li109),tmp=(C_word)a,a+=6,tmp);
/* for-each */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t3);}

/* a2780 in %char-set-algebra in k1279 in k1275 in k1159 */
static void C_ccall f_2781(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2781,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2785,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 524  %char-set:s/check */
f_1250(t3,t2,((C_word*)t0)[2]);}

/* k2783 in a2780 in %char-set-algebra in k1279 in k1275 in k1159 */
static void C_ccall f_2785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2785,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2790,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word)li108),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2790(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k2783 in a2780 in %char-set-algebra in k1279 in k1275 in k1159 */
static void C_fcall f_2790(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2790,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2800,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2811,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2812,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* f_2812 in lp in k2783 in a2780 in %char-set-algebra in k1279 in k1275 in k1159 */
static void C_ccall f_2812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2812,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
/* srfi-14.scm: 150  %char->latin1 */
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_1169(t4));}

/* k2809 in lp in k2783 in a2780 in %char-set-algebra in k1279 in k1275 in k1159 */
static void C_ccall f_2811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 527  op */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2798 in lp in k2783 in a2780 in %char-set-algebra in k1279 in k1275 in k1159 */
static void C_ccall f_2800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 528  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2790(t3,((C_word*)t0)[2],t2);}

/* %string-iter in k1279 in k1275 in k1159 */
static void C_fcall f_2734(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2734,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_string_length(t3);
t5=(C_word)C_fixnum_difference(t4,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2744,a[2]=t2,a[3]=t3,a[4]=t7,a[5]=((C_word)li105),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_2744(t9,t1,t5);}

/* lp in %string-iter in k1279 in k1275 in k1159 */
static void C_fcall f_2744(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2744,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2754,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t6=f_1169(t5);
/* srfi-14.scm: 513  p */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t2,t6);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2752 in lp in %string-iter in k1279 in k1275 in k1159 */
static void C_ccall f_2754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 514  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2744(t3,((C_word*)t0)[2],t2);}

/* ->char-set in k1279 in k1275 in k1159 */
static void C_ccall f_2704(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2704,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2711,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 490  char-set? */
t4=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2709 in ->char-set in k1279 in k1275 in k1159 */
static void C_ccall f_2711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[2]))){
/* srfi-14.scm: 491  string->char-set */
t2=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[2]))){
/* srfi-14.scm: 492  char-set */
t2=*((C_word*)lf[3]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-14.scm: 493  ##sys#error */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[62],lf[63],((C_word*)t0)[2]);}}}}

/* char-set-filter! in k1279 in k1275 in k1159 */
static void C_ccall f_2690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2690,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2694,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2698,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 481  %char-set:s/check */
f_1250(t6,t3,lf[61]);}

/* k2696 in char-set-filter! in k1279 in k1275 in k1159 */
static void C_ccall f_2698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2702,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 482  %char-set:s/check */
f_1250(t2,((C_word*)t0)[2],lf[61]);}

/* k2700 in k2696 in char-set-filter! in k1279 in k1275 in k1159 */
static void C_ccall f_2702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 480  %char-set-filter! */
f_2606(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2692 in char-set-filter! in k1279 in k1275 in k1159 */
static void C_ccall f_2694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-filter in k1279 in k1275 in k1159 */
static void C_ccall f_2674(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_2674r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2674r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2674r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2678,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 472  %default-base */
f_1203(t5,t4,*((C_word*)lf[60]+1));}

/* k2676 in char-set-filter in k1279 in k1275 in k1159 */
static void C_ccall f_2678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2681,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2688,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 474  %char-set:s/check */
f_1250(t3,((C_word*)t0)[2],lf[61]);}

/* k2686 in k2676 in char-set-filter in k1279 in k1275 in k1159 */
static void C_ccall f_2688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 473  %char-set-filter! */
f_2606(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2679 in k2676 in char-set-filter in k1279 in k1275 in k1159 */
static void C_ccall f_2681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 477  make-char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-filter! in k1279 in k1275 in k1159 */
static void C_fcall f_2606(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2606,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2612,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t6,a[6]=((C_word)li100),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_2612(t8,t1,C_fix(255));}

/* lp in %char-set-filter! in k1279 in k1275 in k1159 */
static void C_fcall f_2612(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2612,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2622,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2632,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2643,a[2]=t2,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2651,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* f_2651 in lp in %char-set-filter! in k1279 in k1275 in k1159 */
static void C_ccall f_2651(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2651,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2659,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2660,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* f_2660 */
static void C_ccall f_2660(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2660,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=f_1169(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t5,C_fix(0)));}

/* k2657 */
static void C_ccall f_2659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k2641 in lp in %char-set-filter! in k1279 in k1275 in k1159 */
static void C_ccall f_2643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2643,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2650,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 467  %latin1->char */
t3=lf[0];
f_1163(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2632(2,t2,C_SCHEME_FALSE);}}

/* k2648 in k2641 in lp in %char-set-filter! in k1279 in k1275 in k1159 */
static void C_ccall f_2650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 467  pred */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2630 in lp in %char-set-filter! in k1279 in k1275 in k1159 */
static void C_ccall f_2632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2632,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2636,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_2622(2,t2,C_SCHEME_UNDEFINED);}}

/* f_2636 in k2630 in lp in %char-set-filter! in k1279 in k1275 in k1159 */
static void C_ccall f_2636(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2636,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[16]));}

/* k2620 in lp in %char-set-filter! in k1279 in k1275 in k1159 */
static void C_ccall f_2622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 469  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2612(t3,((C_word*)t0)[2],t2);}

/* ucs-range->char-set! in k1279 in k1275 in k1159 */
static void C_ccall f_2596(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2596,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2600,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2604,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* srfi-14.scm: 456  %char-set:s/check */
f_1250(t7,t5,lf[58]);}

/* k2602 in ucs-range->char-set! in k1279 in k1275 in k1159 */
static void C_ccall f_2604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 455  %ucs-range->char-set! */
f_2504(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[57]);}

/* k2598 in ucs-range->char-set! in k1279 in k1275 in k1159 */
static void C_ccall f_2600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ucs-range->char-set in k1279 in k1275 in k1159 */
static void C_ccall f_2566(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2566r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2566r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2566r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_car(t4));
t7=(C_word)C_i_nullp(t4);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t4));
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2576,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-14.scm: 450  %default-base */
f_1203(t9,t8,*((C_word*)lf[57]+1));}

/* k2574 in ucs-range->char-set in k1279 in k1275 in k1159 */
static void C_ccall f_2576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2579,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 451  %ucs-range->char-set! */
f_2504(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[57]);}

/* k2577 in k2574 in ucs-range->char-set in k1279 in k1275 in k1159 */
static void C_ccall f_2579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 452  make-char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %ucs-range->char-set! in k1279 in k1275 in k1159 */
static void C_fcall f_2504(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2504,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_exact_2(t2,t6);
t8=(C_word)C_i_check_exact_2(t3,t6);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2514,a[2]=t3,a[3]=t1,a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2552,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
t11=t2;
t12=t3;
if(C_truep((C_word)C_fixnum_lessp(t11,t12))){
t13=t3;
t14=(C_word)C_fixnum_lessp(C_fix(256),t13);
t15=t10;
f_2552(t15,(C_truep(t14)?t4:C_SCHEME_FALSE));}
else{
t13=t10;
f_2552(t13,C_SCHEME_FALSE);}}

/* k2550 in %ucs-range->char-set! in k1279 in k1275 in k1159 */
static void C_fcall f_2552(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-14.scm: 442  ##sys#error */
t2=*((C_word*)lf[9]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],lf[56],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_2514(2,t2,C_SCHEME_UNDEFINED);}}

/* k2512 in %ucs-range->char-set! in k1279 in k1275 in k1159 */
static void C_ccall f_2514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2549,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 445  min */
t3=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(256));}

/* k2547 in k2512 in %ucs-range->char-set! in k1279 in k1275 in k1159 */
static void C_ccall f_2549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2549,2,t0,t1);}
t2=(C_word)C_fixnum_difference(t1,C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2523,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word)li93),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2523(t6,((C_word*)t0)[2],t2);}

/* lp in k2547 in k2512 in %ucs-range->char-set! in k1279 in k1275 in k1159 */
static void C_fcall f_2523(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2523,NULL,3,t0,t1,t2);}
t3=((C_word*)t0)[4];
t4=t2;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2533,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2541,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t2);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* f_2541 in lp in k2547 in k2512 in %ucs-range->char-set! in k1279 in k1275 in k1159 */
static void C_ccall f_2541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2541,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[16]));}

/* k2531 in lp in k2547 in k2512 in %ucs-range->char-set! in k1279 in k1275 in k1159 */
static void C_ccall f_2533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 446  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2523(t3,((C_word*)t0)[2],t2);}

/* char-set->string in k1279 in k1275 in k1159 */
static void C_ccall f_2443(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2443,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2447,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 423  %char-set:s/check */
f_1250(t3,t2,lf[53]);}

/* k2445 in char-set->string in k1279 in k1275 in k1159 */
static void C_ccall f_2447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2450,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2502,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 424  char-set-size */
t4=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2500 in k2445 in char-set->string in k1279 in k1275 in k1159 */
static void C_ccall f_2502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 424  make-string */
t2=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2448 in k2445 in char-set->string in k1279 in k1275 in k1159 */
static void C_ccall f_2450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2450,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2455,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word)li90),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2455(t5,((C_word*)t0)[2],C_fix(255),C_fix(0));}

/* lp in k2448 in k2445 in char-set->string in k1279 in k1275 in k1159 */
static void C_fcall f_2455(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2455,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2465,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2475,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2486,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],t2);}}

/* f_2486 in lp in k2448 in k2445 in char-set->string in k1279 in k1275 in k1159 */
static void C_ccall f_2486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2486,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=f_1169(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t5,C_fix(0)));}

/* k2473 in lp in k2448 in k2445 in char-set->string in k1279 in k1275 in k1159 */
static void C_ccall f_2475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2475,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_2465(t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2485,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 428  %latin1->char */
t3=lf[0];
f_1163(3,t3,t2,((C_word*)t0)[2]);}}

/* k2483 in k2473 in lp in k2448 in k2445 in char-set->string in k1279 in k1275 in k1159 */
static void C_ccall f_2485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_string_set(((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_2465(t3,(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1)));}

/* k2463 in lp in k2448 in k2445 in char-set->string in k1279 in k1275 in k1159 */
static void C_fcall f_2465(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 430  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2455(t3,((C_word*)t0)[2],t2,t1);}

/* string->char-set! in k1279 in k1275 in k1159 */
static void C_ccall f_2433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2433,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2437,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2441,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 417  %char-set:s/check */
f_1250(t5,t3,lf[52]);}

/* k2439 in string->char-set! in k1279 in k1275 in k1159 */
static void C_ccall f_2441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 417  %string->char-set! */
f_2372(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[52]);}

/* k2435 in string->char-set! in k1279 in k1275 in k1159 */
static void C_ccall f_2437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* string->char-set in k1279 in k1275 in k1159 */
static void C_ccall f_2421(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2421r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2421r(t0,t1,t2,t3);}}

static void C_ccall f_2421r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2425,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 412  %default-base */
f_1203(t4,t3,*((C_word*)lf[51]+1));}

/* k2423 in string->char-set in k1279 in k1275 in k1159 */
static void C_ccall f_2425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2428,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 413  %string->char-set! */
f_2372(t2,((C_word*)t0)[2],t1,lf[51]);}

/* k2426 in k2423 in string->char-set in k1279 in k1275 in k1159 */
static void C_ccall f_2428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 414  make-char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string->char-set! in k1279 in k1275 in k1159 */
static void C_fcall f_2372(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2372,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(C_word)C_i_string_length(t2);
t7=(C_word)C_fixnum_difference(t6,C_fix(1));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2385,a[2]=t3,a[3]=t2,a[4]=t9,a[5]=((C_word)li85),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_2385(t11,t1,t7);}

/* doloop591 in %string->char-set! in k1279 in k1275 in k1159 */
static void C_fcall f_2385(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2385,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2395,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t6=f_1169(t5);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2407,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,((C_word*)t0)[2],t6);}}

/* f_2407 in doloop591 in %string->char-set! in k1279 in k1275 in k1159 */
static void C_ccall f_2407(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2407,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[16]));}

/* k2393 in doloop591 in %string->char-set! in k1279 in k1275 in k1159 */
static void C_ccall f_2395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2385(t3,((C_word*)t0)[2],t2);}

/* char-set->list in k1279 in k1275 in k1159 */
static void C_ccall f_2320(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2320,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2324,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 393  %char-set:s/check */
f_1250(t3,t2,lf[49]);}

/* k2322 in char-set->list in k1279 in k1275 in k1159 */
static void C_ccall f_2324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2324,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2329,a[2]=t1,a[3]=t3,a[4]=((C_word)li82),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2329(t5,((C_word*)t0)[2],C_fix(255),C_SCHEME_END_OF_LIST);}

/* lp in k2322 in char-set->list in k1279 in k1275 in k1159 */
static void C_fcall f_2329(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2329,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2347,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2350,a[2]=t2,a[3]=t3,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2358,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t0)[2],t2);}}

/* f_2358 in lp in k2322 in char-set->list in k1279 in k1275 in k1159 */
static void C_ccall f_2358(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2358,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=f_1169(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t5,C_fix(0)));}

/* k2348 in lp in k2322 in char-set->list in k1279 in k1275 in k1159 */
static void C_ccall f_2350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2350,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2347(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2357,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 398  %latin1->char */
t3=lf[0];
f_1163(3,t3,t2,((C_word*)t0)[2]);}}

/* k2355 in k2348 in lp in k2322 in char-set->list in k1279 in k1275 in k1159 */
static void C_ccall f_2357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2357,2,t0,t1);}
t2=((C_word*)t0)[3];
f_2347(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k2345 in lp in k2322 in char-set->list in k1279 in k1275 in k1159 */
static void C_fcall f_2347(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 396  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2329(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* list->char-set! in k1279 in k1275 in k1159 */
static void C_ccall f_2310(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2310,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2314,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2318,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 388  %char-set:s/check */
f_1250(t5,t3,lf[48]);}

/* k2316 in list->char-set! in k1279 in k1275 in k1159 */
static void C_ccall f_2318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 388  %list->char-set! */
f_2265(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2312 in list->char-set! in k1279 in k1275 in k1159 */
static void C_ccall f_2314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* list->char-set in k1279 in k1275 in k1159 */
static void C_ccall f_2298(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2298r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2298r(t0,t1,t2,t3);}}

static void C_ccall f_2298r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2302,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 383  %default-base */
f_1203(t4,t3,*((C_word*)lf[47]+1));}

/* k2300 in list->char-set in k1279 in k1275 in k1159 */
static void C_ccall f_2302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2305,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 384  %list->char-set! */
f_2265(t2,((C_word*)t0)[2],t1);}

/* k2303 in k2300 in list->char-set in k1279 in k1275 in k1159 */
static void C_ccall f_2305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 385  make-char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set in k1279 in k1275 in k1159 */
static void C_ccall f_2286(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2286r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2286r(t0,t1,t2);}}

static void C_ccall f_2286r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2290,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 378  make-string */
t4=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(256),lf[15]);}

/* k2288 in char-set in k1279 in k1275 in k1159 */
static void C_ccall f_2290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2293,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 379  %list->char-set! */
f_2265(t2,((C_word*)t0)[2],t1);}

/* k2291 in k2288 in char-set in k1279 in k1275 in k1159 */
static void C_ccall f_2293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 380  make-char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %list->char-set! in k1279 in k1275 in k1159 */
static void C_fcall f_2265(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2265,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2271,a[2]=t3,a[3]=((C_word)li76),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a2270 in %list->char-set! in k1279 in k1275 in k1159 */
static void C_ccall f_2271(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2271,3,t0,t1,t2);}
t3=f_1169(t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2280,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,((C_word*)t0)[2],t3);}

/* f_2280 in a2270 in %list->char-set! in k1279 in k1275 in k1159 */
static void C_ccall f_2280(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2280,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[16]));}

/* char-set-unfold! in k1279 in k1275 in k1159 */
static void C_ccall f_2255(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_2255,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2259,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2263,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* srfi-14.scm: 365  %char-set:s/check */
f_1250(t8,t6,lf[45]);}

/* k2261 in char-set-unfold! in k1279 in k1275 in k1159 */
static void C_ccall f_2263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 364  %char-set-unfold! */
f_2201(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2257 in char-set-unfold! in k1279 in k1275 in k1159 */
static void C_ccall f_2259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-unfold in k1279 in k1275 in k1159 */
static void C_ccall f_2243(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc_2(c,6,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr6r,(void*)f_2243r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_2243r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_2243r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word *a=C_alloc(7);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2247,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-14.scm: 359  %default-base */
f_1203(t7,t6,*((C_word*)lf[44]+1));}

/* k2245 in char-set-unfold in k1279 in k1275 in k1159 */
static void C_ccall f_2247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2250,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 360  %char-set-unfold! */
f_2201(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2248 in k2245 in char-set-unfold in k1279 in k1275 in k1159 */
static void C_ccall f_2250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 361  make-char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-unfold! in k1279 in k1275 in k1159 */
static void C_fcall f_2201(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2201,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2207,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=t4,a[6]=t8,a[7]=((C_word)li71),tmp=(C_word)a,a+=8,tmp));
t10=((C_word*)t8)[1];
f_2207(t10,t1,t6);}

/* lp in %char-set-unfold! in k1279 in k1275 in k1159 */
static void C_fcall f_2207(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2207,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2241,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* srfi-14.scm: 354  p */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2239 in lp in %char-set-unfold! in k1279 in k1275 in k1159 */
static void C_ccall f_2241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2241,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2217,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2237,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 355  f */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}}

/* k2235 in k2239 in lp in %char-set-unfold! in k1279 in k1275 in k1159 */
static void C_ccall f_2237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2237,2,t0,t1);}
t2=f_1169(t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2229,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* f_2229 in k2235 in k2239 in lp in %char-set-unfold! in k1279 in k1275 in k1159 */
static void C_ccall f_2229(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2229,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[16]));}

/* k2215 in k2239 in lp in %char-set-unfold! in k1279 in k1275 in k1159 */
static void C_ccall f_2217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2224,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 356  g */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2222 in k2215 in k2239 in lp in %char-set-unfold! in k1279 in k1275 in k1159 */
static void C_ccall f_2224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 356  lp */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2207(t2,((C_word*)t0)[2],t1);}

/* char-set-any in k1279 in k1275 in k1159 */
static void C_ccall f_2138(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2138,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2142,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 342  %char-set:s/check */
f_1250(t4,t3,lf[42]);}

/* k2140 in char-set-any in k1279 in k1275 in k1159 */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2142,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2147,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word)li68),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2147(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k2140 in char-set-any in k1279 in k1275 in k1159 */
static void C_fcall f_2147(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2147,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2157,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2170,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2178,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* f_2178 in lp in k2140 in char-set-any in k1279 in k1275 in k1159 */
static void C_ccall f_2178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2178,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2186,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2187,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* f_2187 */
static void C_ccall f_2187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2187,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=f_1169(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t5,C_fix(0)));}

/* k2184 */
static void C_ccall f_2186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k2168 in lp in k2140 in char-set-any in k1279 in k1275 in k1159 */
static void C_ccall f_2170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2170,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2177,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 345  %latin1->char */
t3=lf[0];
f_1163(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2157(2,t2,C_SCHEME_FALSE);}}

/* k2175 in k2168 in lp in k2140 in char-set-any in k1279 in k1275 in k1159 */
static void C_ccall f_2177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 345  pred */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2155 in lp in k2140 in char-set-any in k1279 in k1275 in k1159 */
static void C_ccall f_2157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* srfi-14.scm: 346  lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2147(t3,((C_word*)t0)[4],t2);}}

/* char-set-every in k1279 in k1275 in k1159 */
static void C_ccall f_2084(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2084,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2088,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 334  %char-set:s/check */
f_1250(t4,t3,lf[41]);}

/* k2086 in char-set-every in k1279 in k1275 in k1159 */
static void C_ccall f_2088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2088,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2093,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word)li64),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2093(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k2086 in char-set-every in k1279 in k1275 in k1159 */
static void C_fcall f_2093(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2093,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_fixnum_lessp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2106,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2124,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t2);}}

/* f_2124 in lp in k2086 in char-set-every in k1279 in k1275 in k1159 */
static void C_ccall f_2124(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2124,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=f_1169(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t5,C_fix(0)));}

/* k2104 in lp in k2086 in char-set-every in k1279 in k1275 in k1159 */
static void C_ccall f_2106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2106,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2109,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_2109(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2123,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 337  %latin1->char */
t4=lf[0];
f_1163(3,t4,t3,((C_word*)t0)[5]);}}

/* k2121 in k2104 in lp in k2086 in char-set-every in k1279 in k1275 in k1159 */
static void C_ccall f_2123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 337  pred */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2107 in k2104 in lp in k2086 in char-set-every in k1279 in k1275 in k1159 */
static void C_ccall f_2109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 338  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2093(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* char-set-fold in k1279 in k1275 in k1159 */
static void C_ccall f_2032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2032,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2036,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 325  %char-set:s/check */
f_1250(t5,t4,lf[40]);}

/* k2034 in char-set-fold in k1279 in k1275 in k1159 */
static void C_ccall f_2036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2036,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2041,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word)li61),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2041(t5,((C_word*)t0)[3],C_fix(255),((C_word*)t0)[2]);}

/* lp in k2034 in char-set-fold in k1279 in k1275 in k1159 */
static void C_fcall f_2041(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2041,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2059,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2062,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2070,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t0)[2],t2);}}

/* f_2070 in lp in k2034 in char-set-fold in k1279 in k1275 in k1159 */
static void C_ccall f_2070(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2070,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=f_1169(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t5,C_fix(0)));}

/* k2060 in lp in k2034 in char-set-fold in k1279 in k1275 in k1159 */
static void C_ccall f_2062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2062,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_2059(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2069,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 330  %latin1->char */
t3=lf[0];
f_1163(3,t3,t2,((C_word*)t0)[2]);}}

/* k2067 in k2060 in lp in k2034 in char-set-fold in k1279 in k1275 in k1159 */
static void C_ccall f_2069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 330  kons */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2057 in lp in k2034 in char-set-fold in k1279 in k1275 in k1159 */
static void C_ccall f_2059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 328  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2041(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* char-set-map in k1279 in k1275 in k1159 */
static void C_ccall f_1953(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1953,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1957,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 314  %char-set:s/check */
f_1250(t4,t3,lf[39]);}

/* k1955 in char-set-map in k1279 in k1275 in k1159 */
static void C_ccall f_1957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1960,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 315  make-string */
t3=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(256),lf[15]);}

/* k1958 in k1955 in char-set-map in k1279 in k1275 in k1159 */
static void C_ccall f_1960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1963,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1968,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t4,a[6]=((C_word)li58),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_1968(t6,t2,C_fix(255));}

/* lp in k1958 in k1955 in char-set-map in k1279 in k1275 in k1159 */
static void C_fcall f_1968(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1968,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1978,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1988,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2009,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* f_2009 in lp in k1958 in k1955 in char-set-map in k1279 in k1275 in k1159 */
static void C_ccall f_2009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2009,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2017,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2018,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* f_2018 */
static void C_ccall f_2018(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2018,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=f_1169(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t5,C_fix(0)));}

/* k2015 */
static void C_ccall f_2017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k1986 in lp in k1958 in k1955 in char-set-map in k1279 in k1275 in k1159 */
static void C_ccall f_1988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1988,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2004,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2008,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 319  %latin1->char */
t4=lf[0];
f_1163(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_1978(2,t2,C_SCHEME_UNDEFINED);}}

/* k2006 in k1986 in lp in k1958 in k1955 in char-set-map in k1279 in k1275 in k1159 */
static void C_ccall f_2008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 319  proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2002 in k1986 in lp in k1958 in k1955 in char-set-map in k1279 in k1275 in k1159 */
static void C_ccall f_2004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2004,2,t0,t1);}
t2=f_1169(t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1996,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* f_1996 in k2002 in k1986 in lp in k1958 in k1955 in char-set-map in k1279 in k1275 in k1159 */
static void C_ccall f_1996(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1996,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[16]));}

/* k1976 in lp in k1958 in k1955 in char-set-map in k1279 in k1275 in k1159 */
static void C_ccall f_1978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 320  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1968(t3,((C_word*)t0)[2],t2);}

/* k1961 in k1958 in k1955 in char-set-map in k1279 in k1275 in k1159 */
static void C_ccall f_1963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 321  make-char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-for-each in k1279 in k1275 in k1159 */
static void C_ccall f_1893(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1893,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1897,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 306  %char-set:s/check */
f_1250(t4,t3,lf[38]);}

/* k1895 in char-set-for-each in k1279 in k1275 in k1159 */
static void C_ccall f_1897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1897,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1902,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word)li53),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1902(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k1895 in char-set-for-each in k1279 in k1275 in k1159 */
static void C_fcall f_1902(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1902,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1912,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1922,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1930,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* f_1930 in lp in k1895 in char-set-for-each in k1279 in k1275 in k1159 */
static void C_ccall f_1930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1930,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1938,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1939,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* f_1939 */
static void C_ccall f_1939(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1939,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=f_1169(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t5,C_fix(0)));}

/* k1936 */
static void C_ccall f_1938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k1920 in lp in k1895 in char-set-for-each in k1279 in k1275 in k1159 */
static void C_ccall f_1922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1922,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1929,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 309  %latin1->char */
t3=lf[0];
f_1163(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1912(2,t2,C_SCHEME_UNDEFINED);}}

/* k1927 in k1920 in lp in k1895 in char-set-for-each in k1279 in k1275 in k1159 */
static void C_ccall f_1929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 309  proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1910 in lp in k1895 in char-set-for-each in k1279 in k1275 in k1159 */
static void C_ccall f_1912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 310  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1902(t3,((C_word*)t0)[2],t2);}

/* %char-set-cursor-next in k1279 in k1275 in k1159 */
static void C_fcall f_1841(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1841,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1845,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 295  %char-set:s/check */
f_1250(t5,t2,t4);}

/* k1843 in %char-set-cursor-next in k1279 in k1275 in k1159 */
static void C_ccall f_1845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1845,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1850,a[2]=t1,a[3]=t3,a[4]=((C_word)li49),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1850(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k1843 in %char-set-cursor-next in k1279 in k1275 in k1159 */
static void C_fcall f_1850(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1850,NULL,3,t0,t1,t2);}
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
t4=(C_word)C_fixnum_lessp(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1863,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_1863(2,t6,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1870,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* f_1870 in lp in k1843 in %char-set-cursor-next in k1279 in k1275 in k1159 */
static void C_ccall f_1870(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1870,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1878,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1879,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* f_1879 */
static void C_ccall f_1879(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1879,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=f_1169(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t5,C_fix(0)));}

/* k1876 */
static void C_ccall f_1878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k1861 in lp in k1843 in %char-set-cursor-next in k1279 in k1275 in k1159 */
static void C_ccall f_1863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
/* srfi-14.scm: 299  lp */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1850(t2,((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* char-set-cursor-next in k1279 in k1275 in k1159 */
static void C_ccall f_1832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1832,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[37]);
/* srfi-14.scm: 292  %char-set-cursor-next */
f_1841(t1,t2,t3,lf[37]);}

/* char-set-ref in k1279 in k1275 in k1159 */
static void C_ccall f_1826(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1826,4,t0,t1,t2,t3);}
/* srfi-14.scm: 286  %latin1->char */
t4=lf[0];
f_1163(3,t4,t1,t3);}

/* end-of-char-set? in k1279 in k1275 in k1159 */
static void C_ccall f_1820(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1820,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_lessp(t2,C_fix(0)));}

/* char-set-cursor in k1279 in k1275 in k1159 */
static void C_ccall f_1814(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1814,3,t0,t1,t2);}
/* srfi-14.scm: 282  %char-set-cursor-next */
f_1841(t1,t2,C_fix(256),lf[33]);}

/* char-set-delete! in k1279 in k1275 in k1159 */
static void C_ccall f_1802(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_1802r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1802r(t0,t1,t2,t3);}}

static void C_ccall f_1802r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1808,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 268  %set-char-set! */
f_1747(t1,t4,lf[32],t2,t3);}

/* a1807 in char-set-delete! in k1279 in k1275 in k1159 */
static void C_ccall f_1808(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1808,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[15]));}

/* char-set-delete in k1279 in k1275 in k1159 */
static void C_ccall f_1790(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_1790r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1790r(t0,t1,t2,t3);}}

static void C_ccall f_1790r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1796,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 266  %set-char-set */
f_1721(t1,t4,lf[31],t2,t3);}

/* a1795 in char-set-delete in k1279 in k1275 in k1159 */
static void C_ccall f_1796(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1796,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[15]));}

/* char-set-adjoin! in k1279 in k1275 in k1159 */
static void C_ccall f_1778(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_1778r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1778r(t0,t1,t2,t3);}}

static void C_ccall f_1778r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1784,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 264  %set-char-set! */
f_1747(t1,t4,lf[30],t2,t3);}

/* a1783 in char-set-adjoin! in k1279 in k1275 in k1159 */
static void C_ccall f_1784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1784,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[16]));}

/* char-set-adjoin in k1279 in k1275 in k1159 */
static void C_ccall f_1766(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_1766r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1766r(t0,t1,t2,t3);}}

static void C_ccall f_1766r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1772,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 262  %set-char-set */
f_1721(t1,t4,lf[29],t2,t3);}

/* a1771 in char-set-adjoin in k1279 in k1275 in k1159 */
static void C_ccall f_1772(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1772,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[16]));}

/* %set-char-set! in k1279 in k1275 in k1159 */
static void C_fcall f_1747(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1747,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1751,a[2]=t5,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-14.scm: 256  %char-set:s/check */
f_1250(t6,t4,t3);}

/* k1749 in %set-char-set! in k1279 in k1275 in k1159 */
static void C_ccall f_1751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1754,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1756,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li33),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a1755 in k1749 in %set-char-set! in k1279 in k1275 in k1159 */
static void C_ccall f_1756(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1756,3,t0,t1,t2);}
t3=f_1169(t2);
/* srfi-14.scm: 257  set */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,((C_word*)t0)[2],t3);}

/* k1752 in k1749 in %set-char-set! in k1279 in k1275 in k1159 */
static void C_ccall f_1754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* %set-char-set in k1279 in k1275 in k1159 */
static void C_fcall f_1721(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1721,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1725,a[2]=t5,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1745,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 250  %char-set:s/check */
f_1250(t7,t4,t3);}

/* k1743 in %set-char-set in k1279 in k1275 in k1159 */
static void C_ccall f_1745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 250  %string-copy */
f_1193(((C_word*)t0)[2],t1);}

/* k1723 in %set-char-set in k1279 in k1275 in k1159 */
static void C_ccall f_1725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1728,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1733,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li31),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a1732 in k1723 in %set-char-set in k1279 in k1275 in k1159 */
static void C_ccall f_1733(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1733,3,t0,t1,t2);}
t3=f_1169(t2);
/* srfi-14.scm: 251  set */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,((C_word*)t0)[2],t3);}

/* k1726 in k1723 in %set-char-set in k1279 in k1275 in k1159 */
static void C_ccall f_1728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 253  make-char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-count in k1279 in k1275 in k1159 */
static void C_ccall f_1654(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1654,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1658,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 238  %char-set:s/check */
f_1250(t4,t3,lf[25]);}

/* k1656 in char-set-count in k1279 in k1275 in k1159 */
static void C_ccall f_1658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1658,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1663,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word)li29),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1663(t5,((C_word*)t0)[2],C_fix(255),C_fix(0));}

/* lp in k1656 in char-set-count in k1279 in k1275 in k1159 */
static void C_fcall f_1663(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1663,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1684,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1690,a[2]=t2,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1698,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t0)[2],t2);}}

/* f_1698 in lp in k1656 in char-set-count in k1279 in k1275 in k1159 */
static void C_ccall f_1698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1698,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1706,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1707,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* f_1707 */
static void C_ccall f_1707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1707,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=f_1169(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t5,C_fix(0)));}

/* k1704 */
static void C_ccall f_1706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k1688 in lp in k1656 in char-set-count in k1279 in k1275 in k1159 */
static void C_ccall f_1690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1690,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1697,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 242  %latin1->char */
t3=lf[0];
f_1163(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1684(2,t2,C_SCHEME_FALSE);}}

/* k1695 in k1688 in lp in k1656 in char-set-count in k1279 in k1275 in k1159 */
static void C_ccall f_1697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 242  pred */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1682 in lp in k1656 in char-set-count in k1279 in k1275 in k1159 */
static void C_ccall f_1684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1)):((C_word*)t0)[5]);
/* srfi-14.scm: 241  lp */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1663(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* char-set-size in k1279 in k1275 in k1159 */
static void C_ccall f_1612(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1612,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1616,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 231  %char-set:s/check */
f_1250(t3,t2,lf[24]);}

/* k1614 in char-set-size in k1279 in k1275 in k1159 */
static void C_ccall f_1616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1616,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1621,a[2]=t1,a[3]=t3,a[4]=((C_word)li25),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1621(t5,((C_word*)t0)[2],C_fix(255),C_fix(0));}

/* lp in k1614 in char-set-size in k1279 in k1275 in k1159 */
static void C_fcall f_1621(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1621,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1643,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1644,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],t2);}}

/* f_1644 in lp in k1614 in char-set-size in k1279 in k1275 in k1159 */
static void C_ccall f_1644(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1644,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
/* srfi-14.scm: 150  %char->latin1 */
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_1169(t4));}

/* k1641 in lp in k1614 in char-set-size in k1279 in k1275 in k1159 */
static void C_ccall f_1643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],t1);
/* srfi-14.scm: 234  lp */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1621(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* char-set-contains? in k1279 in k1275 in k1159 */
static void C_ccall f_1573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1573,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_char_2(t3,lf[23]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1584,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 226  %char-set:s/check */
f_1250(t5,t2,lf[23]);}

/* k1582 in char-set-contains? in k1279 in k1275 in k1159 */
static void C_ccall f_1584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1584,2,t0,t1);}
t2=f_1169(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1589,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* f_1589 in k1582 in char-set-contains? in k1279 in k1275 in k1159 */
static void C_ccall f_1589(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1589,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1597,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1598,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* f_1598 */
static void C_ccall f_1598(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1598,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=f_1169(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t5,C_fix(0)));}

/* k1595 */
static void C_ccall f_1597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* char-set-hash in k1279 in k1275 in k1159 */
static void C_ccall f_1460(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1460r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1460r(t0,t1,t2,t3);}}

static void C_ccall f_1460r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1464,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_1464(2,t5,C_fix(4194304));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_1464(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[22],t3);}}}

/* k1462 in char-set-hash in k1279 in k1275 in k1159 */
static void C_ccall f_1464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1464,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1467,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(((C_word*)t3)[1],C_fix(0));
if(C_truep(t5)){
t6=C_set_block_item(t3,0,C_fix(4194304));
t7=t4;
f_1467(t7,t6);}
else{
t6=t4;
f_1467(t6,C_SCHEME_UNDEFINED);}}

/* k1465 in k1462 in char-set-hash in k1279 in k1275 in k1159 */
static void C_fcall f_1467(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1467,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[4])[1],lf[20]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1473,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 213  %char-set:s/check */
f_1250(t3,((C_word*)t0)[2],lf[20]);}

/* k1471 in k1465 in k1462 in char-set-hash in k1279 in k1275 in k1159 */
static void C_ccall f_1473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1531,a[2]=((C_word*)t0)[3],a[3]=((C_word)li17),tmp=(C_word)a,a+=4,tmp);
t3=f_1531(t2,C_fix(65536));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1481,a[2]=t1,a[3]=t3,a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word)li19),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_1481(t7,((C_word*)t0)[2],C_fix(255),C_fix(0));}

/* lp in k1471 in k1465 in k1462 in char-set-hash in k1279 in k1275 in k1159 */
static void C_fcall f_1481(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1481,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
/* srfi-14.scm: 218  modulo */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,((C_word*)((C_word*)t0)[5])[1]);}
else{
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1502,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1505,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1517,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t0)[2],t2);}}

/* f_1517 in lp in k1471 in k1465 in k1462 in char-set-hash in k1279 in k1275 in k1159 */
static void C_ccall f_1517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1517,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=f_1169(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t5,C_fix(0)));}

/* k1503 in lp in k1471 in k1465 in k1462 in char-set-hash in k1279 in k1275 in k1159 */
static void C_ccall f_1505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_1502(t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_fixnum_times(C_fix(37),((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(t2,((C_word*)t0)[3]);
t4=((C_word*)t0)[5];
f_1502(t4,(C_word)C_fixnum_and(((C_word*)t0)[2],t3));}}

/* k1500 in lp in k1471 in k1465 in k1462 in char-set-hash in k1279 in k1275 in k1159 */
static void C_fcall f_1502(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 219  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1481(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* lp in k1471 in k1465 in k1462 in char-set-hash in k1279 in k1275 in k1159 */
static C_word C_fcall f_1531(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=t1;
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,t3))){
return((C_word)C_fixnum_difference(t1,C_fix(1)));}
else{
t4=(C_word)C_fixnum_plus(t1,t1);
t6=t4;
t1=t6;
goto loop;}}

/* char-set<= in k1279 in k1275 in k1159 */
static void C_ccall f_1352(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1352r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1352r(t0,t1,t2);}}

static void C_ccall f_1352r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1372,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 186  %char-set:s/check */
f_1250(t6,t4,lf[19]);}}

/* k1370 in char-set<= in k1279 in k1275 in k1159 */
static void C_ccall f_1372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1372,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1374,a[2]=t3,a[3]=((C_word)li15),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_1374(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* lp in k1370 in char-set<= in k1279 in k1275 in k1159 */
static void C_fcall f_1374(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1374,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(t3);
t5=(C_word)C_i_not(t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1384,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t3);
/* srfi-14.scm: 188  %char-set:s/check */
f_1250(t6,t7,lf[19]);}}

/* k1382 in lp in k1370 in char-set<= in k1279 in k1275 in k1159 */
static void C_ccall f_1384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1384,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t3)){
/* srfi-14.scm: 190  lp */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1374(t4,((C_word*)t0)[2],t1,t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1401,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=((C_word)li14),tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_1401(t7,((C_word*)t0)[2],C_fix(255));}}

/* lp2 in k1382 in lp in k1370 in char-set<= in k1279 in k1275 in k1159 */
static void C_fcall f_1401(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1401,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* srfi-14.scm: 192  lp */
t4=((C_word*)((C_word*)t0)[6])[1];
f_1374(t4,t1,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1428,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1442,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],t2);}}

/* f_1442 in lp2 in k1382 in lp in k1370 in char-set<= in k1279 in k1275 in k1159 */
static void C_ccall f_1442(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1442,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
/* srfi-14.scm: 150  %char->latin1 */
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_1169(t4));}

/* k1426 in lp2 in k1382 in lp in k1370 in char-set<= in k1279 in k1275 in k1159 */
static void C_ccall f_1428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1432,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1433,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* f_1433 in k1426 in lp2 in k1382 in lp in k1370 in char-set<= in k1279 in k1275 in k1159 */
static void C_ccall f_1433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1433,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
/* srfi-14.scm: 150  %char->latin1 */
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_1169(t4));}

/* k1430 in k1426 in lp2 in k1382 in lp in k1370 in char-set<= in k1279 in k1275 in k1159 */
static void C_ccall f_1432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t1))){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 194  lp2 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1401(t4,((C_word*)t0)[2],t3);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* char-set= in k1279 in k1275 in k1159 */
static void C_ccall f_1297(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1297r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1297r(t0,t1,t2);}}

static void C_ccall f_1297r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1313,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 175  %char-set:s/check */
f_1250(t6,t4,lf[18]);}}

/* k1311 in char-set= in k1279 in k1275 in k1159 */
static void C_ccall f_1313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1313,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1318,a[2]=t3,a[3]=t1,a[4]=((C_word)li10),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1318(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k1311 in char-set= in k1279 in k1275 in k1159 */
static void C_fcall f_1318(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1318,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_word)C_i_not(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1342,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t2);
/* srfi-14.scm: 178  %char-set:s/check */
f_1250(t5,t6,lf[18]);}}

/* k1340 in lp in k1311 in char-set= in k1279 in k1275 in k1159 */
static void C_ccall f_1342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_string_equal_p(((C_word*)t0)[5],t1))){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* srfi-14.scm: 179  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1318(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* char-set-copy in k1279 in k1275 in k1159 */
static void C_ccall f_1283(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1283,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1291,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1295,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 168  %char-set:s/check */
f_1250(t4,t2,lf[17]);}

/* k1293 in char-set-copy in k1279 in k1275 in k1159 */
static void C_ccall f_1295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 168  %string-copy */
f_1193(((C_word*)t0)[2],t1);}

/* k1289 in char-set-copy in k1279 in k1275 in k1159 */
static void C_ccall f_1291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 168  make-char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* %char-set:s/check in k1159 */
static void C_fcall f_1250(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1250,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1256,a[2]=t3,a[3]=t5,a[4]=((C_word)li7),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1256(t7,t1,t2);}

/* lp in %char-set:s/check in k1159 */
static void C_fcall f_1256(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1256,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1263,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-14.scm: 139  char-set? */
t4=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k1261 in lp in %char-set:s/check in k1159 */
static void C_ccall f_1263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1263,2,t0,t1);}
if(C_truep(t1)){
/* srfi-14.scm: 139  char-set:s */
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1273,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 140  ##sys#error */
t3=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],lf[14],((C_word*)t0)[4]);}}

/* k1271 in k1261 in lp in %char-set:s/check in k1159 */
static void C_ccall f_1273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 140  lp */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1256(t2,((C_word*)t0)[2],t1);}

/* %default-base in k1159 */
static void C_fcall f_1203(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1203,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1228,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 127  char-set? */
t7=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}
else{
/* srfi-14.scm: 129  ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,lf[11],t3,t2);}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1248,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 131  %latin1->char */
t5=lf[0];
f_1163(3,t5,t4,C_fix(0));}}

/* k1246 in %default-base in k1159 */
static void C_ccall f_1248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 131  make-string */
t2=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_fix(256),t1);}

/* k1226 in %default-base in k1159 */
static void C_ccall f_1228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1228,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1235,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 127  char-set:s */
t3=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
/* srfi-14.scm: 128  ##sys#error */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[10],((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k1233 in k1226 in %default-base in k1159 */
static void C_ccall f_1235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 127  %string-copy */
f_1193(((C_word*)t0)[2],t1);}

/* %string-copy in k1159 */
static void C_fcall f_1193(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1193,NULL,2,t1,t2);}
t3=(C_word)C_i_string_length(t2);
/* srfi-14.scm: 115  substring */
t4=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,t2,C_fix(0),t3);}

/* char-set? in k1159 */
static void C_ccall f_1187(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1187,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[3]));}

/* char-set:s in k1159 */
static void C_ccall f_1181(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1181,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* make-char-set in k1159 */
static void C_ccall f_1175(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1175,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,2,lf[3],t2));}

/* %char->latin1 in k1159 */
static C_word C_fcall f_1169(C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)C_fix((C_word)C_character_code(t1)));}

/* %latin1->char in k1159 */
static void C_ccall f_1163(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1163,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_make_character((C_word)C_unfix(t2)));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[357] = {
{"toplevel:srfi_14_scm",(void*)C_srfi_14_toplevel},
{"f_1161:srfi_14_scm",(void*)f_1161},
{"f_1277:srfi_14_scm",(void*)f_1277},
{"f_1281:srfi_14_scm",(void*)f_1281},
{"f_3433:srfi_14_scm",(void*)f_3433},
{"f_3437:srfi_14_scm",(void*)f_3437},
{"f_3441:srfi_14_scm",(void*)f_3441},
{"f_3444:srfi_14_scm",(void*)f_3444},
{"f_3447:srfi_14_scm",(void*)f_3447},
{"f_3549:srfi_14_scm",(void*)f_3549},
{"f_3450:srfi_14_scm",(void*)f_3450},
{"f_3454:srfi_14_scm",(void*)f_3454},
{"f_3545:srfi_14_scm",(void*)f_3545},
{"f_3457:srfi_14_scm",(void*)f_3457},
{"f_3462:srfi_14_scm",(void*)f_3462},
{"f_3537:srfi_14_scm",(void*)f_3537},
{"f_3541:srfi_14_scm",(void*)f_3541},
{"f_3465:srfi_14_scm",(void*)f_3465},
{"f_3469:srfi_14_scm",(void*)f_3469},
{"f_3473:srfi_14_scm",(void*)f_3473},
{"f_3477:srfi_14_scm",(void*)f_3477},
{"f_3481:srfi_14_scm",(void*)f_3481},
{"f_3484:srfi_14_scm",(void*)f_3484},
{"f_3487:srfi_14_scm",(void*)f_3487},
{"f_3491:srfi_14_scm",(void*)f_3491},
{"f_3494:srfi_14_scm",(void*)f_3494},
{"f_3497:srfi_14_scm",(void*)f_3497},
{"f_3501:srfi_14_scm",(void*)f_3501},
{"f_3533:srfi_14_scm",(void*)f_3533},
{"f_3505:srfi_14_scm",(void*)f_3505},
{"f_3509:srfi_14_scm",(void*)f_3509},
{"f_3529:srfi_14_scm",(void*)f_3529},
{"f_3513:srfi_14_scm",(void*)f_3513},
{"f_3525:srfi_14_scm",(void*)f_3525},
{"f_3517:srfi_14_scm",(void*)f_3517},
{"f_3521:srfi_14_scm",(void*)f_3521},
{"f_3404:srfi_14_scm",(void*)f_3404},
{"f_3429:srfi_14_scm",(void*)f_3429},
{"f_3408:srfi_14_scm",(void*)f_3408},
{"f_3411:srfi_14_scm",(void*)f_3411},
{"f_3414:srfi_14_scm",(void*)f_3414},
{"f_3421:srfi_14_scm",(void*)f_3421},
{"f_3425:srfi_14_scm",(void*)f_3425},
{"f_3333:srfi_14_scm",(void*)f_3333},
{"f_3337:srfi_14_scm",(void*)f_3337},
{"f_3340:srfi_14_scm",(void*)f_3340},
{"f_3351:srfi_14_scm",(void*)f_3351},
{"f_3381:srfi_14_scm",(void*)f_3381},
{"f_3390:srfi_14_scm",(void*)f_3390},
{"f_3389:srfi_14_scm",(void*)f_3389},
{"f_3372:srfi_14_scm",(void*)f_3372},
{"f_3376:srfi_14_scm",(void*)f_3376},
{"f_3362:srfi_14_scm",(void*)f_3362},
{"f_3343:srfi_14_scm",(void*)f_3343},
{"f_3346:srfi_14_scm",(void*)f_3346},
{"f_3260:srfi_14_scm",(void*)f_3260},
{"f_3266:srfi_14_scm",(void*)f_3266},
{"f_3331:srfi_14_scm",(void*)f_3331},
{"f_3272:srfi_14_scm",(void*)f_3272},
{"f_3302:srfi_14_scm",(void*)f_3302},
{"f_3311:srfi_14_scm",(void*)f_3311},
{"f_3310:srfi_14_scm",(void*)f_3310},
{"f_3285:srfi_14_scm",(void*)f_3285},
{"f_3297:srfi_14_scm",(void*)f_3297},
{"f_3288:srfi_14_scm",(void*)f_3288},
{"f_3292:srfi_14_scm",(void*)f_3292},
{"f_3185:srfi_14_scm",(void*)f_3185},
{"f_3251:srfi_14_scm",(void*)f_3251},
{"f_3195:srfi_14_scm",(void*)f_3195},
{"f_3207:srfi_14_scm",(void*)f_3207},
{"f_3235:srfi_14_scm",(void*)f_3235},
{"f_3234:srfi_14_scm",(void*)f_3234},
{"f_3222:srfi_14_scm",(void*)f_3222},
{"f_3230:srfi_14_scm",(void*)f_3230},
{"f_3198:srfi_14_scm",(void*)f_3198},
{"f_3133:srfi_14_scm",(void*)f_3133},
{"f_3141:srfi_14_scm",(void*)f_3141},
{"f_3143:srfi_14_scm",(void*)f_3143},
{"f_3171:srfi_14_scm",(void*)f_3171},
{"f_3170:srfi_14_scm",(void*)f_3170},
{"f_3158:srfi_14_scm",(void*)f_3158},
{"f_3166:srfi_14_scm",(void*)f_3166},
{"f_3137:srfi_14_scm",(void*)f_3137},
{"f_3087:srfi_14_scm",(void*)f_3087},
{"f_3128:srfi_14_scm",(void*)f_3128},
{"f_3097:srfi_14_scm",(void*)f_3097},
{"f_3105:srfi_14_scm",(void*)f_3105},
{"f_3116:srfi_14_scm",(void*)f_3116},
{"f_3100:srfi_14_scm",(void*)f_3100},
{"f_3056:srfi_14_scm",(void*)f_3056},
{"f_3064:srfi_14_scm",(void*)f_3064},
{"f_3066:srfi_14_scm",(void*)f_3066},
{"f_3077:srfi_14_scm",(void*)f_3077},
{"f_3060:srfi_14_scm",(void*)f_3060},
{"f_3006:srfi_14_scm",(void*)f_3006},
{"f_3047:srfi_14_scm",(void*)f_3047},
{"f_3016:srfi_14_scm",(void*)f_3016},
{"f_3028:srfi_14_scm",(void*)f_3028},
{"f_3039:srfi_14_scm",(void*)f_3039},
{"f_3019:srfi_14_scm",(void*)f_3019},
{"f_2979:srfi_14_scm",(void*)f_2979},
{"f_2987:srfi_14_scm",(void*)f_2987},
{"f_2989:srfi_14_scm",(void*)f_2989},
{"f_3000:srfi_14_scm",(void*)f_3000},
{"f_2983:srfi_14_scm",(void*)f_2983},
{"f_2925:srfi_14_scm",(void*)f_2925},
{"f_2970:srfi_14_scm",(void*)f_2970},
{"f_2935:srfi_14_scm",(void*)f_2935},
{"f_2947:srfi_14_scm",(void*)f_2947},
{"f_2958:srfi_14_scm",(void*)f_2958},
{"f_2938:srfi_14_scm",(void*)f_2938},
{"f_2894:srfi_14_scm",(void*)f_2894},
{"f_2902:srfi_14_scm",(void*)f_2902},
{"f_2904:srfi_14_scm",(void*)f_2904},
{"f_2915:srfi_14_scm",(void*)f_2915},
{"f_2898:srfi_14_scm",(void*)f_2898},
{"f_2861:srfi_14_scm",(void*)f_2861},
{"f_2865:srfi_14_scm",(void*)f_2865},
{"f_2870:srfi_14_scm",(void*)f_2870},
{"f_2875:srfi_14_scm",(void*)f_2875},
{"f_2884:srfi_14_scm",(void*)f_2884},
{"f_2892:srfi_14_scm",(void*)f_2892},
{"f_2868:srfi_14_scm",(void*)f_2868},
{"f_2822:srfi_14_scm",(void*)f_2822},
{"f_2826:srfi_14_scm",(void*)f_2826},
{"f_2829:srfi_14_scm",(void*)f_2829},
{"f_2837:srfi_14_scm",(void*)f_2837},
{"f_2842:srfi_14_scm",(void*)f_2842},
{"f_2851:srfi_14_scm",(void*)f_2851},
{"f_2859:srfi_14_scm",(void*)f_2859},
{"f_2832:srfi_14_scm",(void*)f_2832},
{"f_2775:srfi_14_scm",(void*)f_2775},
{"f_2781:srfi_14_scm",(void*)f_2781},
{"f_2785:srfi_14_scm",(void*)f_2785},
{"f_2790:srfi_14_scm",(void*)f_2790},
{"f_2812:srfi_14_scm",(void*)f_2812},
{"f_2811:srfi_14_scm",(void*)f_2811},
{"f_2800:srfi_14_scm",(void*)f_2800},
{"f_2734:srfi_14_scm",(void*)f_2734},
{"f_2744:srfi_14_scm",(void*)f_2744},
{"f_2754:srfi_14_scm",(void*)f_2754},
{"f_2704:srfi_14_scm",(void*)f_2704},
{"f_2711:srfi_14_scm",(void*)f_2711},
{"f_2690:srfi_14_scm",(void*)f_2690},
{"f_2698:srfi_14_scm",(void*)f_2698},
{"f_2702:srfi_14_scm",(void*)f_2702},
{"f_2694:srfi_14_scm",(void*)f_2694},
{"f_2674:srfi_14_scm",(void*)f_2674},
{"f_2678:srfi_14_scm",(void*)f_2678},
{"f_2688:srfi_14_scm",(void*)f_2688},
{"f_2681:srfi_14_scm",(void*)f_2681},
{"f_2606:srfi_14_scm",(void*)f_2606},
{"f_2612:srfi_14_scm",(void*)f_2612},
{"f_2651:srfi_14_scm",(void*)f_2651},
{"f_2660:srfi_14_scm",(void*)f_2660},
{"f_2659:srfi_14_scm",(void*)f_2659},
{"f_2643:srfi_14_scm",(void*)f_2643},
{"f_2650:srfi_14_scm",(void*)f_2650},
{"f_2632:srfi_14_scm",(void*)f_2632},
{"f_2636:srfi_14_scm",(void*)f_2636},
{"f_2622:srfi_14_scm",(void*)f_2622},
{"f_2596:srfi_14_scm",(void*)f_2596},
{"f_2604:srfi_14_scm",(void*)f_2604},
{"f_2600:srfi_14_scm",(void*)f_2600},
{"f_2566:srfi_14_scm",(void*)f_2566},
{"f_2576:srfi_14_scm",(void*)f_2576},
{"f_2579:srfi_14_scm",(void*)f_2579},
{"f_2504:srfi_14_scm",(void*)f_2504},
{"f_2552:srfi_14_scm",(void*)f_2552},
{"f_2514:srfi_14_scm",(void*)f_2514},
{"f_2549:srfi_14_scm",(void*)f_2549},
{"f_2523:srfi_14_scm",(void*)f_2523},
{"f_2541:srfi_14_scm",(void*)f_2541},
{"f_2533:srfi_14_scm",(void*)f_2533},
{"f_2443:srfi_14_scm",(void*)f_2443},
{"f_2447:srfi_14_scm",(void*)f_2447},
{"f_2502:srfi_14_scm",(void*)f_2502},
{"f_2450:srfi_14_scm",(void*)f_2450},
{"f_2455:srfi_14_scm",(void*)f_2455},
{"f_2486:srfi_14_scm",(void*)f_2486},
{"f_2475:srfi_14_scm",(void*)f_2475},
{"f_2485:srfi_14_scm",(void*)f_2485},
{"f_2465:srfi_14_scm",(void*)f_2465},
{"f_2433:srfi_14_scm",(void*)f_2433},
{"f_2441:srfi_14_scm",(void*)f_2441},
{"f_2437:srfi_14_scm",(void*)f_2437},
{"f_2421:srfi_14_scm",(void*)f_2421},
{"f_2425:srfi_14_scm",(void*)f_2425},
{"f_2428:srfi_14_scm",(void*)f_2428},
{"f_2372:srfi_14_scm",(void*)f_2372},
{"f_2385:srfi_14_scm",(void*)f_2385},
{"f_2407:srfi_14_scm",(void*)f_2407},
{"f_2395:srfi_14_scm",(void*)f_2395},
{"f_2320:srfi_14_scm",(void*)f_2320},
{"f_2324:srfi_14_scm",(void*)f_2324},
{"f_2329:srfi_14_scm",(void*)f_2329},
{"f_2358:srfi_14_scm",(void*)f_2358},
{"f_2350:srfi_14_scm",(void*)f_2350},
{"f_2357:srfi_14_scm",(void*)f_2357},
{"f_2347:srfi_14_scm",(void*)f_2347},
{"f_2310:srfi_14_scm",(void*)f_2310},
{"f_2318:srfi_14_scm",(void*)f_2318},
{"f_2314:srfi_14_scm",(void*)f_2314},
{"f_2298:srfi_14_scm",(void*)f_2298},
{"f_2302:srfi_14_scm",(void*)f_2302},
{"f_2305:srfi_14_scm",(void*)f_2305},
{"f_2286:srfi_14_scm",(void*)f_2286},
{"f_2290:srfi_14_scm",(void*)f_2290},
{"f_2293:srfi_14_scm",(void*)f_2293},
{"f_2265:srfi_14_scm",(void*)f_2265},
{"f_2271:srfi_14_scm",(void*)f_2271},
{"f_2280:srfi_14_scm",(void*)f_2280},
{"f_2255:srfi_14_scm",(void*)f_2255},
{"f_2263:srfi_14_scm",(void*)f_2263},
{"f_2259:srfi_14_scm",(void*)f_2259},
{"f_2243:srfi_14_scm",(void*)f_2243},
{"f_2247:srfi_14_scm",(void*)f_2247},
{"f_2250:srfi_14_scm",(void*)f_2250},
{"f_2201:srfi_14_scm",(void*)f_2201},
{"f_2207:srfi_14_scm",(void*)f_2207},
{"f_2241:srfi_14_scm",(void*)f_2241},
{"f_2237:srfi_14_scm",(void*)f_2237},
{"f_2229:srfi_14_scm",(void*)f_2229},
{"f_2217:srfi_14_scm",(void*)f_2217},
{"f_2224:srfi_14_scm",(void*)f_2224},
{"f_2138:srfi_14_scm",(void*)f_2138},
{"f_2142:srfi_14_scm",(void*)f_2142},
{"f_2147:srfi_14_scm",(void*)f_2147},
{"f_2178:srfi_14_scm",(void*)f_2178},
{"f_2187:srfi_14_scm",(void*)f_2187},
{"f_2186:srfi_14_scm",(void*)f_2186},
{"f_2170:srfi_14_scm",(void*)f_2170},
{"f_2177:srfi_14_scm",(void*)f_2177},
{"f_2157:srfi_14_scm",(void*)f_2157},
{"f_2084:srfi_14_scm",(void*)f_2084},
{"f_2088:srfi_14_scm",(void*)f_2088},
{"f_2093:srfi_14_scm",(void*)f_2093},
{"f_2124:srfi_14_scm",(void*)f_2124},
{"f_2106:srfi_14_scm",(void*)f_2106},
{"f_2123:srfi_14_scm",(void*)f_2123},
{"f_2109:srfi_14_scm",(void*)f_2109},
{"f_2032:srfi_14_scm",(void*)f_2032},
{"f_2036:srfi_14_scm",(void*)f_2036},
{"f_2041:srfi_14_scm",(void*)f_2041},
{"f_2070:srfi_14_scm",(void*)f_2070},
{"f_2062:srfi_14_scm",(void*)f_2062},
{"f_2069:srfi_14_scm",(void*)f_2069},
{"f_2059:srfi_14_scm",(void*)f_2059},
{"f_1953:srfi_14_scm",(void*)f_1953},
{"f_1957:srfi_14_scm",(void*)f_1957},
{"f_1960:srfi_14_scm",(void*)f_1960},
{"f_1968:srfi_14_scm",(void*)f_1968},
{"f_2009:srfi_14_scm",(void*)f_2009},
{"f_2018:srfi_14_scm",(void*)f_2018},
{"f_2017:srfi_14_scm",(void*)f_2017},
{"f_1988:srfi_14_scm",(void*)f_1988},
{"f_2008:srfi_14_scm",(void*)f_2008},
{"f_2004:srfi_14_scm",(void*)f_2004},
{"f_1996:srfi_14_scm",(void*)f_1996},
{"f_1978:srfi_14_scm",(void*)f_1978},
{"f_1963:srfi_14_scm",(void*)f_1963},
{"f_1893:srfi_14_scm",(void*)f_1893},
{"f_1897:srfi_14_scm",(void*)f_1897},
{"f_1902:srfi_14_scm",(void*)f_1902},
{"f_1930:srfi_14_scm",(void*)f_1930},
{"f_1939:srfi_14_scm",(void*)f_1939},
{"f_1938:srfi_14_scm",(void*)f_1938},
{"f_1922:srfi_14_scm",(void*)f_1922},
{"f_1929:srfi_14_scm",(void*)f_1929},
{"f_1912:srfi_14_scm",(void*)f_1912},
{"f_1841:srfi_14_scm",(void*)f_1841},
{"f_1845:srfi_14_scm",(void*)f_1845},
{"f_1850:srfi_14_scm",(void*)f_1850},
{"f_1870:srfi_14_scm",(void*)f_1870},
{"f_1879:srfi_14_scm",(void*)f_1879},
{"f_1878:srfi_14_scm",(void*)f_1878},
{"f_1863:srfi_14_scm",(void*)f_1863},
{"f_1832:srfi_14_scm",(void*)f_1832},
{"f_1826:srfi_14_scm",(void*)f_1826},
{"f_1820:srfi_14_scm",(void*)f_1820},
{"f_1814:srfi_14_scm",(void*)f_1814},
{"f_1802:srfi_14_scm",(void*)f_1802},
{"f_1808:srfi_14_scm",(void*)f_1808},
{"f_1790:srfi_14_scm",(void*)f_1790},
{"f_1796:srfi_14_scm",(void*)f_1796},
{"f_1778:srfi_14_scm",(void*)f_1778},
{"f_1784:srfi_14_scm",(void*)f_1784},
{"f_1766:srfi_14_scm",(void*)f_1766},
{"f_1772:srfi_14_scm",(void*)f_1772},
{"f_1747:srfi_14_scm",(void*)f_1747},
{"f_1751:srfi_14_scm",(void*)f_1751},
{"f_1756:srfi_14_scm",(void*)f_1756},
{"f_1754:srfi_14_scm",(void*)f_1754},
{"f_1721:srfi_14_scm",(void*)f_1721},
{"f_1745:srfi_14_scm",(void*)f_1745},
{"f_1725:srfi_14_scm",(void*)f_1725},
{"f_1733:srfi_14_scm",(void*)f_1733},
{"f_1728:srfi_14_scm",(void*)f_1728},
{"f_1654:srfi_14_scm",(void*)f_1654},
{"f_1658:srfi_14_scm",(void*)f_1658},
{"f_1663:srfi_14_scm",(void*)f_1663},
{"f_1698:srfi_14_scm",(void*)f_1698},
{"f_1707:srfi_14_scm",(void*)f_1707},
{"f_1706:srfi_14_scm",(void*)f_1706},
{"f_1690:srfi_14_scm",(void*)f_1690},
{"f_1697:srfi_14_scm",(void*)f_1697},
{"f_1684:srfi_14_scm",(void*)f_1684},
{"f_1612:srfi_14_scm",(void*)f_1612},
{"f_1616:srfi_14_scm",(void*)f_1616},
{"f_1621:srfi_14_scm",(void*)f_1621},
{"f_1644:srfi_14_scm",(void*)f_1644},
{"f_1643:srfi_14_scm",(void*)f_1643},
{"f_1573:srfi_14_scm",(void*)f_1573},
{"f_1584:srfi_14_scm",(void*)f_1584},
{"f_1589:srfi_14_scm",(void*)f_1589},
{"f_1598:srfi_14_scm",(void*)f_1598},
{"f_1597:srfi_14_scm",(void*)f_1597},
{"f_1460:srfi_14_scm",(void*)f_1460},
{"f_1464:srfi_14_scm",(void*)f_1464},
{"f_1467:srfi_14_scm",(void*)f_1467},
{"f_1473:srfi_14_scm",(void*)f_1473},
{"f_1481:srfi_14_scm",(void*)f_1481},
{"f_1517:srfi_14_scm",(void*)f_1517},
{"f_1505:srfi_14_scm",(void*)f_1505},
{"f_1502:srfi_14_scm",(void*)f_1502},
{"f_1531:srfi_14_scm",(void*)f_1531},
{"f_1352:srfi_14_scm",(void*)f_1352},
{"f_1372:srfi_14_scm",(void*)f_1372},
{"f_1374:srfi_14_scm",(void*)f_1374},
{"f_1384:srfi_14_scm",(void*)f_1384},
{"f_1401:srfi_14_scm",(void*)f_1401},
{"f_1442:srfi_14_scm",(void*)f_1442},
{"f_1428:srfi_14_scm",(void*)f_1428},
{"f_1433:srfi_14_scm",(void*)f_1433},
{"f_1432:srfi_14_scm",(void*)f_1432},
{"f_1297:srfi_14_scm",(void*)f_1297},
{"f_1313:srfi_14_scm",(void*)f_1313},
{"f_1318:srfi_14_scm",(void*)f_1318},
{"f_1342:srfi_14_scm",(void*)f_1342},
{"f_1283:srfi_14_scm",(void*)f_1283},
{"f_1295:srfi_14_scm",(void*)f_1295},
{"f_1291:srfi_14_scm",(void*)f_1291},
{"f_1250:srfi_14_scm",(void*)f_1250},
{"f_1256:srfi_14_scm",(void*)f_1256},
{"f_1263:srfi_14_scm",(void*)f_1263},
{"f_1273:srfi_14_scm",(void*)f_1273},
{"f_1203:srfi_14_scm",(void*)f_1203},
{"f_1248:srfi_14_scm",(void*)f_1248},
{"f_1228:srfi_14_scm",(void*)f_1228},
{"f_1235:srfi_14_scm",(void*)f_1235},
{"f_1193:srfi_14_scm",(void*)f_1193},
{"f_1187:srfi_14_scm",(void*)f_1187},
{"f_1181:srfi_14_scm",(void*)f_1181},
{"f_1175:srfi_14_scm",(void*)f_1175},
{"f_1169:srfi_14_scm",(void*)f_1169},
{"f_1163:srfi_14_scm",(void*)f_1163},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
