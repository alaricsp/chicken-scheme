/* Generated from srfi-14.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-08-25 23:15
   Version 4.0.0x - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11761	compiled 2008-08-25 on tesseract.thetesseract.org (Linux)
   command line: srfi-14.scm -optimize-level 2 -include-path . -include-path . -explicit-use -output-file srfi-14.c
   unit: srfi_14
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[109];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,19),40,37,108,97,116,105,110,49,45,62,99,104,97,114,32,110,50,49,41,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,15),40,37,99,104,97,114,45,62,108,97,116,105,110,49,41,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,19),40,109,97,107,101,45,99,104,97,114,45,115,101,116,32,115,50,57,41,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,17),40,99,104,97,114,45,115,101,116,58,115,32,99,115,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,15),40,99,104,97,114,45,115,101,116,63,32,120,51,55,41,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,18),40,37,115,116,114,105,110,103,45,99,111,112,121,32,115,52,49,41,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,35),40,37,100,101,102,97,117,108,116,45,98,97,115,101,32,109,97,121,98,101,45,98,97,115,101,52,53,32,112,114,111,99,52,54,41,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,9),40,108,112,32,99,115,54,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,31),40,37,99,104,97,114,45,115,101,116,58,115,47,99,104,101,99,107,32,99,115,53,51,32,112,114,111,99,53,52,41,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,20),40,99,104,97,114,45,115,101,116,45,99,111,112,121,32,99,115,57,48,41,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,12),40,108,112,32,114,101,115,116,49,49,51,41,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,20),40,99,104,97,114,45,115,101,116,61,32,46,32,114,101,115,116,57,51,41,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,18),40,102,95,49,52,55,55,32,115,49,54,52,32,105,49,54,53,41,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,18),40,102,95,49,52,56,54,32,115,49,54,49,32,105,49,54,50,41,0,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,10),40,108,112,50,32,105,49,53,55,41,0,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,18),40,108,112,32,115,49,49,52,49,32,114,101,115,116,49,52,50,41,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,22),40,99,104,97,114,45,115,101,116,60,61,32,46,32,114,101,115,116,49,50,54,41,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,4),40,108,112,41,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,18),40,102,95,49,53,54,49,32,115,50,48,56,32,105,50,48,57,41,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,16),40,108,112,32,105,50,48,53,32,97,110,115,50,48,54,41};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,38),40,99,104,97,114,45,115,101,116,45,104,97,115,104,32,99,115,49,55,51,32,46,32,109,97,121,98,101,45,98,111,117,110,100,49,55,52,41,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,18),40,102,95,49,54,52,50,32,115,50,50,51,32,105,50,50,52,41,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,18),40,102,95,49,54,51,51,32,115,50,50,48,32,105,50,50,49,41,0,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,34),40,99,104,97,114,45,115,101,116,45,99,111,110,116,97,105,110,115,63,32,99,115,50,49,55,32,99,104,97,114,50,49,56,41,0,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,18),40,102,95,49,54,56,56,32,115,50,52,48,32,105,50,52,49,41,0,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,17),40,108,112,32,105,50,51,55,32,115,105,122,101,50,51,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,21),40,99,104,97,114,45,115,101,116,45,115,105,122,101,32,99,115,50,50,57,41,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,18),40,102,95,49,55,53,49,32,115,50,54,52,32,105,50,54,53,41,0,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,18),40,102,95,49,55,52,50,32,115,50,54,49,32,105,50,54,50,41,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,18),40,108,112,32,105,50,53,54,32,99,111,117,110,116,50,53,55,41,0,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,32),40,99,104,97,114,45,115,101,116,45,99,111,117,110,116,32,112,114,101,100,50,52,55,32,99,115,101,116,50,52,56,41};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,12),40,97,49,55,55,54,32,99,50,55,56,41,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,45),40,37,115,101,116,45,99,104,97,114,45,115,101,116,32,115,101,116,50,55,49,32,112,114,111,99,50,55,50,32,99,115,50,55,51,32,99,104,97,114,115,50,55,52,41,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,12),40,97,49,55,57,57,32,99,50,57,48,41,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,46),40,37,115,101,116,45,99,104,97,114,45,115,101,116,33,32,115,101,116,50,56,51,32,112,114,111,99,50,56,52,32,99,115,50,56,53,32,99,104,97,114,115,50,56,54,41,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,17),40,97,49,56,49,53,32,115,50,57,56,32,105,50,57,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,34),40,99,104,97,114,45,115,101,116,45,97,100,106,111,105,110,32,99,115,50,57,53,32,46,32,99,104,97,114,115,50,57,54,41,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,17),40,97,49,56,50,55,32,115,51,48,54,32,105,51,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,35),40,99,104,97,114,45,115,101,116,45,97,100,106,111,105,110,33,32,99,115,51,48,51,32,46,32,99,104,97,114,115,51,48,52,41,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,17),40,97,49,56,51,57,32,115,51,49,52,32,105,51,49,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,34),40,99,104,97,114,45,115,101,116,45,100,101,108,101,116,101,32,99,115,51,49,49,32,46,32,99,104,97,114,115,51,49,50,41,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,17),40,97,49,56,53,49,32,115,51,50,50,32,105,51,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,35),40,99,104,97,114,45,115,101,116,45,100,101,108,101,116,101,33,32,99,115,51,49,57,32,46,32,99,104,97,114,115,51,50,48,41,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,25),40,99,104,97,114,45,115,101,116,45,99,117,114,115,111,114,32,99,115,101,116,51,50,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,28),40,101,110,100,45,111,102,45,99,104,97,114,45,115,101,116,63,32,99,117,114,115,111,114,51,51,49,41,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,32),40,99,104,97,114,45,115,101,116,45,114,101,102,32,99,115,101,116,51,51,53,32,99,117,114,115,111,114,51,51,54,41};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,40),40,99,104,97,114,45,115,101,116,45,99,117,114,115,111,114,45,110,101,120,116,32,99,115,101,116,51,52,48,32,99,117,114,115,111,114,51,52,49,41};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,18),40,102,95,49,57,50,51,32,115,51,54,57,32,105,51,55,48,41,0,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,18),40,102,95,49,57,49,52,32,115,51,54,54,32,105,51,54,55,41,0,0,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,11),40,108,112,32,99,117,114,51,53,54,41,0,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,49),40,37,99,104,97,114,45,115,101,116,45,99,117,114,115,111,114,45,110,101,120,116,32,99,115,101,116,51,52,54,32,99,117,114,115,111,114,51,52,55,32,112,114,111,99,51,52,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,18),40,102,95,49,57,56,51,32,115,51,57,55,32,105,51,57,56,41,0,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,18),40,102,95,49,57,55,52,32,115,51,57,52,32,105,51,57,53,41,0,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,51,56,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,33),40,99,104,97,114,45,115,101,116,45,102,111,114,45,101,97,99,104,32,112,114,111,99,51,55,54,32,99,115,51,55,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,18),40,102,95,50,48,52,48,32,115,52,51,48,32,105,52,51,49,41,0,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,18),40,102,95,50,48,54,50,32,115,52,50,55,32,105,52,50,56,41,0,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,18),40,102,95,50,48,53,51,32,115,52,50,52,32,105,52,50,53,41,0,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,52,49,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,28),40,99,104,97,114,45,115,101,116,45,109,97,112,32,112,114,111,99,52,48,53,32,99,115,52,48,54,41,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,18),40,102,95,50,49,49,52,32,115,52,53,50,32,105,52,53,51,41,0,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,16),40,108,112,32,105,52,52,57,32,97,110,115,52,53,48,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,37),40,99,104,97,114,45,115,101,116,45,102,111,108,100,32,107,111,110,115,52,51,57,32,107,110,105,108,52,52,48,32,99,115,52,52,49,41,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,18),40,102,95,50,49,54,56,32,115,52,56,51,32,105,52,56,52,41,0,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,52,54,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,30),40,99,104,97,114,45,115,101,116,45,101,118,101,114,121,32,112,114,101,100,52,53,57,32,99,115,52,54,48,41,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,18),40,102,95,50,50,51,49,32,115,53,49,52,32,105,53,49,53,41,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,18),40,102,95,50,50,50,50,32,115,53,49,49,32,105,53,49,50,41,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,53,48,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,28),40,99,104,97,114,45,115,101,116,45,97,110,121,32,112,114,101,100,52,57,49,32,99,115,52,57,50,41,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,18),40,102,95,50,50,55,51,32,115,53,52,50,32,105,53,52,51,41,0,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,12),40,108,112,32,115,101,101,100,53,51,51,41,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,47),40,37,99,104,97,114,45,115,101,116,45,117,110,102,111,108,100,33,32,112,53,50,51,32,102,53,50,52,32,103,53,50,53,32,115,53,50,54,32,115,101,101,100,53,50,55,41,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,56),40,99,104,97,114,45,115,101,116,45,117,110,102,111,108,100,32,112,53,53,48,32,102,53,53,49,32,103,53,53,50,32,115,101,101,100,53,53,51,32,46,32,109,97,121,98,101,45,98,97,115,101,53,53,52,41};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,54),40,99,104,97,114,45,115,101,116,45,117,110,102,111,108,100,33,32,112,53,54,49,32,102,53,54,50,32,103,53,54,51,32,115,101,101,100,53,54,52,32,98,97,115,101,45,99,115,101,116,53,54,53,41,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,18),40,102,95,50,51,50,52,32,115,53,55,53,32,105,53,55,54,41,0,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,15),40,97,50,51,49,52,32,99,104,97,114,53,55,51,41,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,32),40,37,108,105,115,116,45,62,99,104,97,114,45,115,101,116,33,32,99,104,97,114,115,53,55,48,32,115,53,55,49,41};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,21),40,99,104,97,114,45,115,101,116,32,46,32,99,104,97,114,115,53,56,48,41,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,41),40,108,105,115,116,45,62,99,104,97,114,45,115,101,116,32,99,104,97,114,115,53,56,55,32,46,32,109,97,121,98,101,45,98,97,115,101,53,56,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,37),40,108,105,115,116,45,62,99,104,97,114,45,115,101,116,33,32,99,104,97,114,115,53,57,53,32,98,97,115,101,45,99,115,53,57,54,41,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,18),40,102,95,50,52,48,50,32,115,54,49,50,32,105,54,49,51,41,0,0,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,16),40,108,112,32,105,54,48,57,32,97,110,115,54,49,48,41};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,22),40,99,104,97,114,45,115,101,116,45,62,108,105,115,116,32,99,115,54,48,49,41,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,18),40,102,95,50,52,53,49,32,115,54,51,52,32,105,54,51,53,41,0,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,54,50,51,32,105,54,51,49,41};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,41),40,37,115,116,114,105,110,103,45,62,99,104,97,114,45,115,101,116,33,32,115,116,114,54,49,57,32,98,115,54,50,48,32,112,114,111,99,54,50,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,41),40,115,116,114,105,110,103,45,62,99,104,97,114,45,115,101,116,32,115,116,114,54,52,51,32,46,32,109,97,121,98,101,45,98,97,115,101,54,52,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,37),40,115,116,114,105,110,103,45,62,99,104,97,114,45,115,101,116,33,32,115,116,114,54,53,49,32,98,97,115,101,45,99,115,54,53,50,41,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,18),40,102,95,50,53,51,48,32,115,54,55,51,32,105,54,55,52,41,0,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,14),40,108,112,32,105,54,54,57,32,106,54,55,48,41,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,24),40,99,104,97,114,45,115,101,116,45,62,115,116,114,105,110,103,32,99,115,54,53,55,41};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,18),40,102,95,50,53,56,53,32,115,55,48,53,32,105,55,48,54,41,0,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,54,57,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,65),40,37,117,99,115,45,114,97,110,103,101,45,62,99,104,97,114,45,115,101,116,33,32,108,111,119,101,114,54,56,50,32,117,112,112,101,114,54,56,51,32,101,114,114,111,114,63,54,56,52,32,98,115,54,56,53,32,112,114,111,99,54,56,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,49),40,117,99,115,45,114,97,110,103,101,45,62,99,104,97,114,45,115,101,116,32,108,111,119,101,114,55,49,54,32,117,112,112,101,114,55,49,55,32,46,32,114,101,115,116,55,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,61),40,117,99,115,45,114,97,110,103,101,45,62,99,104,97,114,45,115,101,116,33,32,108,111,119,101,114,55,51,57,32,117,112,112,101,114,55,52,48,32,101,114,114,111,114,63,55,52,49,32,98,97,115,101,45,99,115,55,52,50,41,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,18),40,102,95,50,54,56,48,32,115,55,55,51,32,105,55,55,52,41,0,0,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,18),40,102,95,50,55,48,52,32,115,55,55,48,32,105,55,55,49,41,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,18),40,102,95,50,54,57,53,32,115,55,54,55,32,105,55,54,56,41,0,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,55,53,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,39),40,37,99,104,97,114,45,115,101,116,45,102,105,108,116,101,114,33,32,112,114,101,100,55,52,55,32,100,115,55,52,56,32,98,115,55,52,57,41,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,56),40,99,104,97,114,45,115,101,116,45,102,105,108,116,101,114,32,112,114,101,100,105,99,97,116,101,55,56,49,32,100,111,109,97,105,110,55,56,50,32,46,32,109,97,121,98,101,45,98,97,115,101,55,56,51,41};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,52),40,99,104,97,114,45,115,101,116,45,102,105,108,116,101,114,33,32,112,114,101,100,105,99,97,116,101,55,57,48,32,100,111,109,97,105,110,55,57,49,32,98,97,115,101,45,99,115,55,57,50,41,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,17),40,45,62,99,104,97,114,45,115,101,116,32,120,55,57,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,56,49,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,24),40,37,115,116,114,105,110,103,45,105,116,101,114,32,112,56,48,56,32,115,56,48,57,41};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,18),40,102,95,50,56,53,54,32,115,56,53,49,32,105,56,53,50,41,0,0,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,56,52,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,15),40,97,50,56,50,52,32,99,115,101,116,56,51,52,41,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,47),40,37,99,104,97,114,45,115,101,116,45,97,108,103,101,98,114,97,32,115,56,50,57,32,99,115,101,116,115,56,51,48,32,111,112,56,51,49,32,112,114,111,99,56,51,50,41,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,23),40,102,95,50,56,57,53,32,115,56,55,49,32,105,56,55,50,32,118,56,55,51,41,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,23),40,102,95,50,56,56,54,32,115,56,54,55,32,105,56,54,56,32,118,56,54,57,41,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,17),40,97,50,56,56,48,32,105,56,54,52,32,118,56,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,27),40,99,104,97,114,45,115,101,116,45,99,111,109,112,108,101,109,101,110,116,32,99,115,56,53,57,41,0,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,23),40,102,95,50,57,50,56,32,115,56,56,57,32,105,56,57,48,32,118,56,57,49,41,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,23),40,102,95,50,57,49,57,32,115,56,56,53,32,105,56,56,54,32,118,56,56,55,41,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,17),40,97,50,57,49,51,32,105,56,56,50,32,118,56,56,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,30),40,99,104,97,114,45,115,101,116,45,99,111,109,112,108,101,109,101,110,116,33,32,99,115,101,116,56,55,56,41,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,18),40,102,95,50,57,53,57,32,115,57,48,51,32,105,57,48,52,41,0,0,0,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,22),40,97,50,57,52,55,32,115,56,57,57,32,105,57,48,48,32,118,57,48,49,41,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,37),40,99,104,97,114,45,115,101,116,45,117,110,105,111,110,33,32,99,115,101,116,49,56,57,54,32,46,32,99,115,101,116,115,56,57,55,41,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,18),40,102,95,51,48,48,50,32,115,57,49,55,32,105,57,49,56,41,0,0,0,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,22),40,97,50,57,57,48,32,115,57,49,51,32,105,57,49,52,32,118,57,49,53,41,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,27),40,99,104,97,114,45,115,101,116,45,117,110,105,111,110,32,46,32,99,115,101,116,115,57,48,57,41,0,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,18),40,102,95,51,48,52,52,32,115,57,51,48,32,105,57,51,49,41,0,0,0,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,22),40,97,51,48,51,50,32,115,57,50,54,32,105,57,50,55,32,118,57,50,56,41,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,44),40,99,104,97,114,45,115,101,116,45,105,110,116,101,114,115,101,99,116,105,111,110,33,32,99,115,101,116,49,57,50,51,32,46,32,99,115,101,116,115,57,50,52,41,0,0,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,18),40,102,95,51,48,56,51,32,115,57,52,52,32,105,57,52,53,41,0,0,0,0,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,22),40,97,51,48,55,49,32,115,57,52,48,32,105,57,52,49,32,118,57,52,50,41,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,34),40,99,104,97,114,45,115,101,116,45,105,110,116,101,114,115,101,99,116,105,111,110,32,46,32,99,115,101,116,115,57,51,54,41,0,0,0,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,18),40,102,95,51,49,50,49,32,115,57,53,55,32,105,57,53,56,41,0,0,0,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,22),40,97,51,49,48,57,32,115,57,53,51,32,105,57,53,52,32,118,57,53,53,41,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,42),40,99,104,97,114,45,115,101,116,45,100,105,102,102,101,114,101,110,99,101,33,32,99,115,101,116,49,57,53,48,32,46,32,99,115,101,116,115,57,53,49,41,0,0,0,0,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,18),40,102,95,51,49,54,48,32,115,57,55,50,32,105,57,55,51,41,0,0,0,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,22),40,97,51,49,52,56,32,115,57,54,56,32,105,57,54,57,32,118,57,55,48,41,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,39),40,99,104,97,114,45,115,101,116,45,100,105,102,102,101,114,101,110,99,101,32,99,115,49,57,54,51,32,46,32,99,115,101,116,115,57,54,52,41,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,23),40,102,95,51,50,48,50,32,115,57,56,53,32,105,57,56,54,32,118,57,56,55,41,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,18),40,102,95,51,50,49,53,32,115,57,56,57,32,105,57,57,48,41,0,0,0,0,0,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,22),40,97,51,49,56,54,32,115,57,56,49,32,105,57,56,50,32,118,57,56,51,41,0,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,35),40,99,104,97,114,45,115,101,116,45,120,111,114,33,32,99,115,101,116,49,57,55,56,32,46,32,99,115,101,116,115,57,55,57,41,0,0,0,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,26),40,102,95,51,50,54,54,32,115,49,48,48,51,32,105,49,48,48,52,32,118,49,48,48,53,41,0,0,0,0,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,20),40,102,95,51,50,55,57,32,115,49,48,48,55,32,105,49,48,48,56,41,0,0,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,24),40,97,51,50,53,48,32,115,57,57,57,32,105,49,48,48,48,32,118,49,48,48,49,41};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,25),40,99,104,97,114,45,115,101,116,45,120,111,114,32,46,32,99,115,101,116,115,57,57,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,20),40,102,95,51,51,51,54,32,115,49,48,51,57,32,105,49,48,52,48,41,0,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,20),40,102,95,51,51,52,49,32,115,49,48,51,54,32,105,49,48,51,55,41,0,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,20),40,102,95,51,51,53,53,32,115,49,48,51,51,32,105,49,48,51,52,41,0,0,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,20),40,102,95,51,51,52,54,32,115,49,48,51,48,32,105,49,48,51,49,41,0,0,0,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,19),40,97,51,51,49,53,32,105,49,48,50,48,32,118,49,48,50,49,41,0,0,0,0,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,14),40,97,51,51,48,57,32,99,115,49,48,49,56,41,0,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,66),40,37,99,104,97,114,45,115,101,116,45,100,105,102,102,43,105,110,116,101,114,115,101,99,116,105,111,110,33,32,100,105,102,102,49,48,49,51,32,105,110,116,49,48,49,52,32,99,115,101,116,115,49,48,49,53,32,112,114,111,99,49,48,49,54,41,0,0,0,0,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,20),40,102,95,51,52,48,54,32,115,49,48,53,53,32,105,49,48,53,54,41,0,0,0,0};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,20),40,102,95,51,52,50,48,32,115,49,48,54,52,32,105,49,48,54,53,41,0,0,0,0};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,20),40,102,95,51,52,51,52,32,115,49,48,54,49,32,105,49,48,54,50,41,0,0,0,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,20),40,102,95,51,52,50,53,32,115,49,48,53,56,32,105,49,48,53,57,41,0,0,0,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,19),40,97,51,51,57,52,32,105,49,48,53,50,32,118,49,48,53,51,41,0,0,0,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,57),40,99,104,97,114,45,115,101,116,45,100,105,102,102,43,105,110,116,101,114,115,101,99,116,105,111,110,33,32,99,115,49,49,48,52,53,32,99,115,50,49,48,52,54,32,46,32,99,115,101,116,115,49,48,52,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,48),40,99,104,97,114,45,115,101,116,45,100,105,102,102,43,105,110,116,101,114,115,101,99,116,105,111,110,32,99,115,49,49,48,55,49,32,46,32,99,115,101,116,115,49,48,55,50,41};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_srfi_14_toplevel)
C_externexport void C_ccall C_srfi_14_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1205)
static void C_ccall f_1205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1321)
static void C_ccall f_1321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1325)
static void C_ccall f_1325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3477)
static void C_ccall f_3477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3481)
static void C_ccall f_3481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3485)
static void C_ccall f_3485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3488)
static void C_ccall f_3488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3491)
static void C_ccall f_3491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3593)
static void C_ccall f_3593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3494)
static void C_ccall f_3494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3498)
static void C_ccall f_3498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3589)
static void C_ccall f_3589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3501)
static void C_ccall f_3501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3506)
static void C_ccall f_3506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3581)
static void C_ccall f_3581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3585)
static void C_ccall f_3585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3509)
static void C_ccall f_3509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3513)
static void C_ccall f_3513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3517)
static void C_ccall f_3517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3521)
static void C_ccall f_3521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3525)
static void C_ccall f_3525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3528)
static void C_ccall f_3528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3531)
static void C_ccall f_3531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3535)
static void C_ccall f_3535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3538)
static void C_ccall f_3538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3541)
static void C_ccall f_3541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3545)
static void C_ccall f_3545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3577)
static void C_ccall f_3577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3549)
static void C_ccall f_3549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3553)
static void C_ccall f_3553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3573)
static void C_ccall f_3573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3557)
static void C_ccall f_3557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3569)
static void C_ccall f_3569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3561)
static void C_ccall f_3561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3565)
static void C_ccall f_3565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3448)
static void C_ccall f_3448(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3448)
static void C_ccall f_3448r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3473)
static void C_ccall f_3473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3452)
static void C_ccall f_3452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3455)
static void C_ccall f_3455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3458)
static void C_ccall f_3458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3465)
static void C_ccall f_3465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3377)
static void C_ccall f_3377(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3377)
static void C_ccall f_3377r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3381)
static void C_ccall f_3381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3384)
static void C_ccall f_3384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3395)
static void C_ccall f_3395(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3425)
static void C_ccall f_3425(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3434)
static void C_ccall f_3434(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3433)
static void C_ccall f_3433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3416)
static void C_ccall f_3416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3420)
static void C_ccall f_3420(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3406)
static void C_ccall f_3406(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3387)
static void C_ccall f_3387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3390)
static void C_ccall f_3390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3304)
static void C_fcall f_3304(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3310)
static void C_ccall f_3310(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3375)
static void C_ccall f_3375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3316)
static void C_ccall f_3316(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3346)
static void C_ccall f_3346(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3355)
static void C_ccall f_3355(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3354)
static void C_ccall f_3354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3341)
static void C_ccall f_3341(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3332)
static void C_ccall f_3332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3336)
static void C_ccall f_3336(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3229)
static void C_ccall f_3229(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3229)
static void C_ccall f_3229r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3239)
static void C_ccall f_3239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3251)
static void C_ccall f_3251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3279)
static void C_ccall f_3279(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3278)
static void C_ccall f_3278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3266)
static void C_ccall f_3266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3274)
static void C_ccall f_3274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3242)
static void C_ccall f_3242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3177)
static void C_ccall f_3177(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3177)
static void C_ccall f_3177r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3185)
static void C_ccall f_3185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3187)
static void C_ccall f_3187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3215)
static void C_ccall f_3215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3214)
static void C_ccall f_3214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3202)
static void C_ccall f_3202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3210)
static void C_ccall f_3210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3181)
static void C_ccall f_3181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3131)
static void C_ccall f_3131(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3131)
static void C_ccall f_3131r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3172)
static void C_ccall f_3172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3141)
static void C_ccall f_3141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3149)
static void C_ccall f_3149(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3160)
static void C_ccall f_3160(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3144)
static void C_ccall f_3144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3100)
static void C_ccall f_3100(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3100)
static void C_ccall f_3100r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3108)
static void C_ccall f_3108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3110)
static void C_ccall f_3110(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3121)
static void C_ccall f_3121(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3104)
static void C_ccall f_3104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3050)
static void C_ccall f_3050(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3050)
static void C_ccall f_3050r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3091)
static void C_ccall f_3091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3060)
static void C_ccall f_3060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3072)
static void C_ccall f_3072(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3083)
static void C_ccall f_3083(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3063)
static void C_ccall f_3063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3023)
static void C_ccall f_3023(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3023)
static void C_ccall f_3023r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3031)
static void C_ccall f_3031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3044)
static void C_ccall f_3044(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2969)
static void C_ccall f_2969(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2969)
static void C_ccall f_2969r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3014)
static void C_ccall f_3014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2979)
static void C_ccall f_2979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2991)
static void C_ccall f_2991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3002)
static void C_ccall f_3002(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2982)
static void C_ccall f_2982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2938)
static void C_ccall f_2938(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2938)
static void C_ccall f_2938r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2946)
static void C_ccall f_2946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2948)
static void C_ccall f_2948(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2959)
static void C_ccall f_2959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2942)
static void C_ccall f_2942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2905)
static void C_ccall f_2905(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2909)
static void C_ccall f_2909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2914)
static void C_ccall f_2914(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2919)
static void C_ccall f_2919(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2928)
static void C_ccall f_2928(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2936)
static void C_ccall f_2936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2912)
static void C_ccall f_2912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2866)
static void C_ccall f_2866(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2870)
static void C_ccall f_2870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2873)
static void C_ccall f_2873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2881)
static void C_ccall f_2881(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2886)
static void C_ccall f_2886(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2895)
static void C_ccall f_2895(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2903)
static void C_ccall f_2903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2876)
static void C_ccall f_2876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2819)
static void C_fcall f_2819(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2825)
static void C_ccall f_2825(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2829)
static void C_ccall f_2829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2834)
static void C_fcall f_2834(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2856)
static void C_ccall f_2856(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2855)
static void C_ccall f_2855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2844)
static void C_ccall f_2844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2778)
static void C_fcall f_2778(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2788)
static void C_fcall f_2788(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2798)
static void C_ccall f_2798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2748)
static void C_ccall f_2748(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2755)
static void C_ccall f_2755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2734)
static void C_ccall f_2734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2742)
static void C_ccall f_2742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2746)
static void C_ccall f_2746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2738)
static void C_ccall f_2738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2718)
static void C_ccall f_2718(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2718)
static void C_ccall f_2718r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2722)
static void C_ccall f_2722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2732)
static void C_ccall f_2732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2725)
static void C_ccall f_2725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2650)
static void C_fcall f_2650(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2656)
static void C_fcall f_2656(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2695)
static void C_ccall f_2695(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2704)
static void C_ccall f_2704(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2703)
static void C_ccall f_2703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2687)
static void C_ccall f_2687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2694)
static void C_ccall f_2694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2676)
static void C_ccall f_2676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2680)
static void C_ccall f_2680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2640)
static void C_ccall f_2640(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2648)
static void C_ccall f_2648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2644)
static void C_ccall f_2644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2610)
static void C_ccall f_2610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2610)
static void C_ccall f_2610r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2620)
static void C_ccall f_2620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2623)
static void C_ccall f_2623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2548)
static void C_fcall f_2548(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2596)
static void C_fcall f_2596(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2558)
static void C_ccall f_2558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2593)
static void C_ccall f_2593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2567)
static void C_fcall f_2567(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2585)
static void C_ccall f_2585(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2577)
static void C_ccall f_2577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2487)
static void C_ccall f_2487(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2491)
static void C_ccall f_2491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2546)
static void C_ccall f_2546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2494)
static void C_ccall f_2494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2499)
static void C_fcall f_2499(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2530)
static void C_ccall f_2530(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2519)
static void C_ccall f_2519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2529)
static void C_ccall f_2529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2509)
static void C_fcall f_2509(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2477)
static void C_ccall f_2477(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2485)
static void C_ccall f_2485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2481)
static void C_ccall f_2481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2465)
static void C_ccall f_2465(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2465)
static void C_ccall f_2465r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2469)
static void C_ccall f_2469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2472)
static void C_ccall f_2472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2416)
static void C_fcall f_2416(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2429)
static void C_fcall f_2429(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2451)
static void C_ccall f_2451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2364)
static void C_ccall f_2364(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2373)
static void C_fcall f_2373(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2402)
static void C_ccall f_2402(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2401)
static void C_ccall f_2401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2391)
static void C_fcall f_2391(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2354)
static void C_ccall f_2354(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2362)
static void C_ccall f_2362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2358)
static void C_ccall f_2358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2342)
static void C_ccall f_2342(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2342)
static void C_ccall f_2342r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2346)
static void C_ccall f_2346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2349)
static void C_ccall f_2349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2330)
static void C_ccall f_2330(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2330)
static void C_ccall f_2330r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2334)
static void C_ccall f_2334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2337)
static void C_ccall f_2337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2309)
static void C_fcall f_2309(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2315)
static void C_ccall f_2315(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2324)
static void C_ccall f_2324(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2299)
static void C_ccall f_2299(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2303)
static void C_ccall f_2303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2287)
static void C_ccall f_2287(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_2287)
static void C_ccall f_2287r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2294)
static void C_ccall f_2294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2245)
static void C_fcall f_2245(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2251)
static void C_fcall f_2251(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2285)
static void C_ccall f_2285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2273)
static void C_ccall f_2273(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2268)
static void C_ccall f_2268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2182)
static void C_ccall f_2182(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2186)
static void C_ccall f_2186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2191)
static void C_fcall f_2191(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2222)
static void C_ccall f_2222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2231)
static void C_ccall f_2231(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2230)
static void C_ccall f_2230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2214)
static void C_ccall f_2214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2221)
static void C_ccall f_2221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2201)
static void C_ccall f_2201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2128)
static void C_ccall f_2128(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2132)
static void C_ccall f_2132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2137)
static void C_fcall f_2137(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2150)
static void C_ccall f_2150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2167)
static void C_ccall f_2167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2153)
static void C_ccall f_2153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2076)
static void C_ccall f_2076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2080)
static void C_ccall f_2080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2085)
static void C_fcall f_2085(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2114)
static void C_ccall f_2114(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2106)
static void C_ccall f_2106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2113)
static void C_ccall f_2113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2103)
static void C_ccall f_2103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1997)
static void C_ccall f_1997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2001)
static void C_ccall f_2001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2004)
static void C_ccall f_2004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2012)
static void C_fcall f_2012(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2053)
static void C_ccall f_2053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2062)
static void C_ccall f_2062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2061)
static void C_ccall f_2061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2032)
static void C_ccall f_2032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2052)
static void C_ccall f_2052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2048)
static void C_ccall f_2048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2040)
static void C_ccall f_2040(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2022)
static void C_ccall f_2022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2007)
static void C_ccall f_2007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1937)
static void C_ccall f_1937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1941)
static void C_ccall f_1941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1946)
static void C_fcall f_1946(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1974)
static void C_ccall f_1974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1983)
static void C_ccall f_1983(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1982)
static void C_ccall f_1982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1966)
static void C_ccall f_1966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1956)
static void C_ccall f_1956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1885)
static void C_fcall f_1885(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1889)
static void C_ccall f_1889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_fcall f_1894(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1923)
static void C_ccall f_1923(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1922)
static void C_ccall f_1922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1907)
static void C_ccall f_1907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1876)
static void C_ccall f_1876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1864)
static void C_ccall f_1864(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1834)
static void C_ccall f_1834(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1834)
static void C_ccall f_1834r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1840)
static void C_ccall f_1840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1822)
static void C_ccall f_1822(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1822)
static void C_ccall f_1822r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1828)
static void C_ccall f_1828(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1810)
static void C_ccall f_1810(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1810)
static void C_ccall f_1810r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1816)
static void C_ccall f_1816(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1791)
static void C_fcall f_1791(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1795)
static void C_ccall f_1795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1800)
static void C_ccall f_1800(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1798)
static void C_ccall f_1798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1765)
static void C_fcall f_1765(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1789)
static void C_ccall f_1789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1769)
static void C_ccall f_1769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1777)
static void C_ccall f_1777(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1772)
static void C_ccall f_1772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1698)
static void C_ccall f_1698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1702)
static void C_ccall f_1702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1707)
static void C_fcall f_1707(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1742)
static void C_ccall f_1742(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1751)
static void C_ccall f_1751(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1750)
static void C_ccall f_1750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1734)
static void C_ccall f_1734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1741)
static void C_ccall f_1741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1728)
static void C_ccall f_1728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1656)
static void C_ccall f_1656(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1660)
static void C_ccall f_1660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1665)
static void C_fcall f_1665(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1688)
static void C_ccall f_1688(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1687)
static void C_ccall f_1687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1617)
static void C_ccall f_1617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1628)
static void C_ccall f_1628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1633)
static void C_ccall f_1633(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1642)
static void C_ccall f_1642(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1641)
static void C_ccall f_1641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1504)
static void C_ccall f_1504(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1504)
static void C_ccall f_1504r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1508)
static void C_ccall f_1508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1511)
static void C_fcall f_1511(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1517)
static void C_ccall f_1517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1525)
static void C_fcall f_1525(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1561)
static void C_ccall f_1561(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1549)
static void C_ccall f_1549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1546)
static void C_fcall f_1546(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1575)
static C_word C_fcall f_1575(C_word t0,C_word t1);
C_noret_decl(f_1396)
static void C_ccall f_1396(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1396)
static void C_ccall f_1396r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1416)
static void C_ccall f_1416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1418)
static void C_fcall f_1418(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1428)
static void C_ccall f_1428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1445)
static void C_fcall f_1445(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1486)
static void C_ccall f_1486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1472)
static void C_ccall f_1472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1477)
static void C_ccall f_1477(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1476)
static void C_ccall f_1476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1341)
static void C_ccall f_1341(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1341)
static void C_ccall f_1341r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1357)
static void C_ccall f_1357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1362)
static void C_fcall f_1362(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1386)
static void C_ccall f_1386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1327)
static void C_ccall f_1327(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1339)
static void C_ccall f_1339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1335)
static void C_ccall f_1335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1294)
static void C_fcall f_1294(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1300)
static void C_fcall f_1300(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1307)
static void C_ccall f_1307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1317)
static void C_ccall f_1317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1247)
static void C_fcall f_1247(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1292)
static void C_ccall f_1292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1272)
static void C_ccall f_1272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1279)
static void C_ccall f_1279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1237)
static void C_fcall f_1237(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1231)
static void C_ccall f_1231(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1225)
static void C_ccall f_1225(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1219)
static void C_ccall f_1219(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1213)
static C_word C_fcall f_1213(C_word t0);
C_noret_decl(f_1207)
static void C_ccall f_1207(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_3304)
static void C_fcall trf_3304(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3304(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3304(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2819)
static void C_fcall trf_2819(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2819(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2819(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2834)
static void C_fcall trf_2834(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2834(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2834(t0,t1,t2);}

C_noret_decl(trf_2778)
static void C_fcall trf_2778(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2778(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2778(t0,t1,t2);}

C_noret_decl(trf_2788)
static void C_fcall trf_2788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2788(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2788(t0,t1,t2);}

C_noret_decl(trf_2650)
static void C_fcall trf_2650(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2650(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2650(t0,t1,t2,t3);}

C_noret_decl(trf_2656)
static void C_fcall trf_2656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2656(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2656(t0,t1,t2);}

C_noret_decl(trf_2548)
static void C_fcall trf_2548(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2548(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2548(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2596)
static void C_fcall trf_2596(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2596(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2596(t0,t1);}

C_noret_decl(trf_2567)
static void C_fcall trf_2567(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2567(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2567(t0,t1,t2);}

C_noret_decl(trf_2499)
static void C_fcall trf_2499(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2499(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2499(t0,t1,t2,t3);}

C_noret_decl(trf_2509)
static void C_fcall trf_2509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2509(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2509(t0,t1);}

C_noret_decl(trf_2416)
static void C_fcall trf_2416(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2416(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2416(t0,t1,t2,t3);}

C_noret_decl(trf_2429)
static void C_fcall trf_2429(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2429(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2429(t0,t1,t2);}

C_noret_decl(trf_2373)
static void C_fcall trf_2373(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2373(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2373(t0,t1,t2,t3);}

C_noret_decl(trf_2391)
static void C_fcall trf_2391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2391(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2391(t0,t1);}

C_noret_decl(trf_2309)
static void C_fcall trf_2309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2309(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2309(t0,t1,t2);}

C_noret_decl(trf_2245)
static void C_fcall trf_2245(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2245(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2245(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2251)
static void C_fcall trf_2251(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2251(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2251(t0,t1,t2);}

C_noret_decl(trf_2191)
static void C_fcall trf_2191(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2191(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2191(t0,t1,t2);}

C_noret_decl(trf_2137)
static void C_fcall trf_2137(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2137(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2137(t0,t1,t2);}

C_noret_decl(trf_2085)
static void C_fcall trf_2085(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2085(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2085(t0,t1,t2,t3);}

C_noret_decl(trf_2012)
static void C_fcall trf_2012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2012(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2012(t0,t1,t2);}

C_noret_decl(trf_1946)
static void C_fcall trf_1946(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1946(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1946(t0,t1,t2);}

C_noret_decl(trf_1885)
static void C_fcall trf_1885(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1885(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1885(t0,t1,t2,t3);}

C_noret_decl(trf_1894)
static void C_fcall trf_1894(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1894(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1894(t0,t1,t2);}

C_noret_decl(trf_1791)
static void C_fcall trf_1791(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1791(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1791(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1765)
static void C_fcall trf_1765(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1765(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1765(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1707)
static void C_fcall trf_1707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1707(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1707(t0,t1,t2,t3);}

C_noret_decl(trf_1665)
static void C_fcall trf_1665(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1665(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1665(t0,t1,t2,t3);}

C_noret_decl(trf_1511)
static void C_fcall trf_1511(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1511(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1511(t0,t1);}

C_noret_decl(trf_1525)
static void C_fcall trf_1525(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1525(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1525(t0,t1,t2,t3);}

C_noret_decl(trf_1546)
static void C_fcall trf_1546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1546(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1546(t0,t1);}

C_noret_decl(trf_1418)
static void C_fcall trf_1418(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1418(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1418(t0,t1,t2,t3);}

C_noret_decl(trf_1445)
static void C_fcall trf_1445(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1445(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1445(t0,t1,t2);}

C_noret_decl(trf_1362)
static void C_fcall trf_1362(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1362(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1362(t0,t1,t2);}

C_noret_decl(trf_1294)
static void C_fcall trf_1294(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1294(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1294(t0,t1,t2);}

C_noret_decl(trf_1300)
static void C_fcall trf_1300(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1300(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1300(t0,t1,t2);}

C_noret_decl(trf_1247)
static void C_fcall trf_1247(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1247(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1247(t0,t1,t2);}

C_noret_decl(trf_1237)
static void C_fcall trf_1237(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1237(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1237(t0,t1);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_14_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_14_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_14_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(862)){
C_save(t1);
C_rereclaim2(862*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,109);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[4]=C_h_intern(&lf[4],13,"make-char-set");
lf[5]=C_h_intern(&lf[5],8,"char-set");
lf[6]=C_h_intern(&lf[6],10,"char-set:s");
lf[7]=C_h_intern(&lf[7],9,"char-set\077");
lf[9]=C_h_intern(&lf[9],9,"substring");
lf[11]=C_h_intern(&lf[11],9,"\003syserror");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000 BASE-CS parameter not a char-set");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\0003Expected final base char set -- too many parameters");
lf[14]=C_h_intern(&lf[14],11,"make-string");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\016Not a char-set");
lf[19]=C_h_intern(&lf[19],13,"char-set-copy");
lf[20]=C_h_intern(&lf[20],9,"char-set=");
lf[21]=C_h_intern(&lf[21],10,"char-set<=");
lf[22]=C_h_intern(&lf[22],13,"char-set-hash");
lf[23]=C_h_intern(&lf[23],6,"modulo");
lf[24]=C_h_intern(&lf[24],18,"char-set-contains\077");
lf[25]=C_h_intern(&lf[25],13,"char-set-size");
lf[26]=C_h_intern(&lf[26],14,"char-set-count");
lf[28]=C_h_intern(&lf[28],12,"\003sysfor-each");
lf[30]=C_h_intern(&lf[30],15,"char-set-adjoin");
lf[31]=C_h_intern(&lf[31],16,"char-set-adjoin!");
lf[32]=C_h_intern(&lf[32],15,"char-set-delete");
lf[33]=C_h_intern(&lf[33],16,"char-set-delete!");
lf[34]=C_h_intern(&lf[34],15,"char-set-cursor");
lf[36]=C_h_intern(&lf[36],16,"end-of-char-set\077");
lf[37]=C_h_intern(&lf[37],12,"char-set-ref");
lf[38]=C_h_intern(&lf[38],20,"char-set-cursor-next");
lf[39]=C_h_intern(&lf[39],17,"char-set-for-each");
lf[40]=C_h_intern(&lf[40],12,"char-set-map");
lf[41]=C_h_intern(&lf[41],13,"char-set-fold");
lf[42]=C_h_intern(&lf[42],14,"char-set-every");
lf[43]=C_h_intern(&lf[43],12,"char-set-any");
lf[45]=C_h_intern(&lf[45],15,"char-set-unfold");
lf[46]=C_h_intern(&lf[46],16,"char-set-unfold!");
lf[48]=C_h_intern(&lf[48],14,"list->char-set");
lf[49]=C_h_intern(&lf[49],15,"list->char-set!");
lf[50]=C_h_intern(&lf[50],14,"char-set->list");
lf[52]=C_h_intern(&lf[52],16,"string->char-set");
lf[53]=C_h_intern(&lf[53],17,"string->char-set!");
lf[54]=C_h_intern(&lf[54],16,"char-set->string");
lf[56]=C_h_intern(&lf[56],3,"min");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000`Requested UCS range contains unavailable characters -- this implementation "
"only supports Latin-1");
lf[58]=C_h_intern(&lf[58],19,"ucs-range->char-set");
lf[59]=C_h_intern(&lf[59],20,"ucs-range->char-set!");
lf[61]=C_h_intern(&lf[61],15,"char-set-filter");
lf[62]=C_h_intern(&lf[62],16,"char-set-filter!");
lf[63]=C_h_intern(&lf[63],10,"->char-set");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\036Not a charset, string or char.");
lf[67]=C_h_intern(&lf[67],19,"char-set-complement");
lf[68]=C_h_intern(&lf[68],20,"char-set-complement!");
lf[69]=C_h_intern(&lf[69],15,"char-set-union!");
lf[70]=C_h_intern(&lf[70],14,"char-set-union");
lf[71]=C_h_intern(&lf[71],14,"char-set:empty");
lf[72]=C_h_intern(&lf[72],22,"char-set-intersection!");
lf[73]=C_h_intern(&lf[73],21,"char-set-intersection");
lf[74]=C_h_intern(&lf[74],13,"char-set:full");
lf[75]=C_h_intern(&lf[75],20,"char-set-difference!");
lf[76]=C_h_intern(&lf[76],19,"char-set-difference");
lf[77]=C_h_intern(&lf[77],13,"char-set-xor!");
lf[78]=C_h_intern(&lf[78],12,"char-set-xor");
lf[80]=C_h_intern(&lf[80],27,"char-set-diff+intersection!");
lf[81]=C_h_intern(&lf[81],26,"char-set-diff+intersection");
lf[82]=C_h_intern(&lf[82],11,"string-copy");
lf[83]=C_h_intern(&lf[83],19,"char-set:lower-case");
lf[84]=C_h_intern(&lf[84],19,"char-set:upper-case");
lf[85]=C_h_intern(&lf[85],19,"char-set:title-case");
lf[86]=C_h_intern(&lf[86],15,"char-set:letter");
lf[87]=C_h_intern(&lf[87],14,"char-set:digit");
lf[88]=C_h_intern(&lf[88],18,"char-set:hex-digit");
lf[89]=C_h_intern(&lf[89],21,"char-set:letter+digit");
lf[90]=C_h_intern(&lf[90],20,"char-set:punctuation");
lf[91]=C_h_intern(&lf[91],15,"char-set:symbol");
lf[92]=C_h_intern(&lf[92],16,"char-set:graphic");
lf[93]=C_h_intern(&lf[93],19,"char-set:whitespace");
lf[94]=C_h_intern(&lf[94],17,"char-set:printing");
lf[95]=C_h_intern(&lf[95],14,"char-set:blank");
lf[96]=C_h_intern(&lf[96],20,"char-set:iso-control");
lf[97]=C_h_intern(&lf[97],14,"char-set:ascii");
lf[98]=C_h_intern(&lf[98],7,"\003sysmap");
lf[99]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\011\376\003\000\000\002\376\377\001\000\000\000 \376\003\000\000\002\376\377\001\000\000\000\240\376\377\016");
lf[100]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\011\376\003\000\000\002\376\377\001\000\000\000\012\376\003\000\000\002\376\377\001\000\000\000\013\376\003\000\000\002\376\377\001\000\000\000\014\376\003\000\000\002\376\377\001\000\000\000\015\376\003\000\000\002\376\377\001\000\000\000 \376\003\000\000\002\376\377\001"
"\000\000\000\240\376\377\016");
lf[101]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\242\376\003\000\000\002\376\377\001\000\000\000\243\376\003\000\000\002\376\377\001\000\000\000\244\376\003\000\000\002\376\377\001\000\000\000\245\376\003\000\000\002\376\377\001\000\000\000\246\376\003\000\000\002\376\377\001\000\000\000\247\376\003\000\000\002\376\377\001"
"\000\000\000\250\376\003\000\000\002\376\377\001\000\000\000\251\376\003\000\000\002\376\377\001\000\000\000\254\376\003\000\000\002\376\377\001\000\000\000\256\376\003\000\000\002\376\377\001\000\000\000\257\376\003\000\000\002\376\377\001\000\000\000\260\376\003\000\000\002\376\377\001\000\000\000\261\376\003\000\000"
"\002\376\377\001\000\000\000\264\376\003\000\000\002\376\377\001\000\000\000\266\376\003\000\000\002\376\377\001\000\000\000\270\376\003\000\000\002\376\377\001\000\000\000\327\376\003\000\000\002\376\377\001\000\000\000\367\376\377\016");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\011$+<=>^`|~");
lf[103]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\241\376\003\000\000\002\376\377\001\000\000\000\253\376\003\000\000\002\376\377\001\000\000\000\255\376\003\000\000\002\376\377\001\000\000\000\267\376\003\000\000\002\376\377\001\000\000\000\273\376\003\000\000\002\376\377\001\000\000\000\277\376\377\016");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\027!\042#%&\047()*,-./:;\077@[\134]_{}");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\0260123456789abcdefABCDEF");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\0120123456789");
lf[107]=C_h_intern(&lf[107],17,"register-feature!");
lf[108]=C_h_intern(&lf[108],7,"srfi-14");
C_register_lf2(lf,109,create_ptable());
t2=C_mutate(&lf[0] /* c185 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1205,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 28   register-feature!");
t4=*((C_word*)lf[107]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[108]);}

/* k1203 */
static void C_ccall f_1205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1205,2,t0,t1);}
t2=C_mutate(&lf[2] /* %latin1->char ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1207,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[3] /* %char->latin1 ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1213,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[4]+1 /* make-char-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1219,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[6]+1 /* char-set:s ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1225,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[7]+1 /* char-set? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1231,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[8] /* %string-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1237,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate(&lf[10] /* %default-base ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1247,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[15] /* %char-set:s/check ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1294,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1321,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 154  %latin1->char");
t11=lf[2];
f_1207(3,t11,t10,C_fix(0));}

/* k1319 in k1203 */
static void C_ccall f_1321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1321,2,t0,t1);}
t2=C_mutate(&lf[17] /* c0 ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1325,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 155  %latin1->char");
t4=lf[2];
f_1207(3,t4,t3,C_fix(1));}

/* k1323 in k1319 in k1203 */
static void C_ccall f_1325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word ab[174],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1325,2,t0,t1);}
t2=C_mutate(&lf[18] /* c1 ...) */,t1);
t3=C_mutate((C_word*)lf[19]+1 /* char-set-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1327,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[20]+1 /* char-set= ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1341,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[21]+1 /* char-set<= ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1396,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[22]+1 /* char-set-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1504,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[24]+1 /* char-set-contains? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1617,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[25]+1 /* char-set-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1656,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[26]+1 /* char-set-count ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1698,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate(&lf[27] /* %set-char-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1765,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[29] /* %set-char-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1791,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[30]+1 /* char-set-adjoin ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1810,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[31]+1 /* char-set-adjoin! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1822,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[32]+1 /* char-set-delete ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1834,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[33]+1 /* char-set-delete! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1846,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[34]+1 /* char-set-cursor ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1858,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[36]+1 /* end-of-char-set? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1864,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[37]+1 /* char-set-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1870,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[38]+1 /* char-set-cursor-next ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1876,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate(&lf[35] /* %char-set-cursor-next ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1885,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[39]+1 /* char-set-for-each ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1937,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[40]+1 /* char-set-map ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1997,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[41]+1 /* char-set-fold ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2076,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[42]+1 /* char-set-every ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2128,a[2]=((C_word)li65),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[43]+1 /* char-set-any ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2182,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate(&lf[44] /* %char-set-unfold! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2245,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[45]+1 /* char-set-unfold ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2287,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[46]+1 /* char-set-unfold! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2299,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate(&lf[47] /* %list->char-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2309,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[5]+1 /* char-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2330,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[48]+1 /* list->char-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2342,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[49]+1 /* list->char-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2354,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[50]+1 /* char-set->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2364,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate(&lf[51] /* %string->char-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2416,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t35=C_mutate((C_word*)lf[52]+1 /* string->char-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2465,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[53]+1 /* string->char-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2477,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp));
t37=C_mutate((C_word*)lf[54]+1 /* char-set->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2487,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp));
t38=C_mutate(&lf[55] /* %ucs-range->char-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2548,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp));
t39=C_mutate((C_word*)lf[58]+1 /* ucs-range->char-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2610,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp));
t40=C_mutate((C_word*)lf[59]+1 /* ucs-range->char-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2640,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp));
t41=C_mutate(&lf[60] /* %char-set-filter! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2650,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[61]+1 /* char-set-filter ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2718,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[62]+1 /* char-set-filter! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2734,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[63]+1 /* ->char-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2748,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate(&lf[65] /* %string-iter ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2778,a[2]=((C_word)li106),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate(&lf[66] /* %char-set-algebra ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2819,a[2]=((C_word)li110),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[67]+1 /* char-set-complement ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2866,a[2]=((C_word)li114),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[68]+1 /* char-set-complement! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2905,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[69]+1 /* char-set-union! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2938,a[2]=((C_word)li121),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[70]+1 /* char-set-union ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2969,a[2]=((C_word)li124),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[72]+1 /* char-set-intersection! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3023,a[2]=((C_word)li127),tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[73]+1 /* char-set-intersection ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3050,a[2]=((C_word)li130),tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[75]+1 /* char-set-difference! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3100,a[2]=((C_word)li133),tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[76]+1 /* char-set-difference ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3131,a[2]=((C_word)li136),tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[77]+1 /* char-set-xor! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3177,a[2]=((C_word)li140),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[78]+1 /* char-set-xor ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3229,a[2]=((C_word)li144),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate(&lf[79] /* %char-set-diff+intersection! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3304,a[2]=((C_word)li151),tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[80]+1 /* char-set-diff+intersection! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3377,a[2]=((C_word)li157),tmp=(C_word)a,a+=3,tmp));
t59=C_mutate((C_word*)lf[81]+1 /* char-set-diff+intersection ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3448,a[2]=((C_word)li158),tmp=(C_word)a,a+=3,tmp));
t60=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3477,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 643  char-set");
t61=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t61+1)))(2,t61,t60);}

/* k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3477,2,t0,t1);}
t2=C_mutate((C_word*)lf[71]+1 /* char-set:empty ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3481,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 644  char-set-complement");
t4=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[71]+1));}

/* k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3481,2,t0,t1);}
t2=C_mutate((C_word*)lf[74]+1 /* char-set:full ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3485,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 647  ucs-range->char-set");
t4=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(97),C_fix(123));}

/* k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3488,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 648  ucs-range->char-set!");
t3=*((C_word*)lf[59]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_fix(223),C_fix(247),C_SCHEME_TRUE,t1);}

/* k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3491,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 649  ucs-range->char-set!");
t3=*((C_word*)lf[59]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_fix(248),C_fix(256),C_SCHEME_TRUE,t1);}

/* k3489 in k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3494,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3593,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 650  %latin1->char");
t4=lf[2];
f_1207(3,t4,t3,C_fix(181));}

/* k3591 in k3489 in k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 650  char-set-adjoin!");
t2=*((C_word*)lf[31]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3492 in k3489 in k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3494,2,t0,t1);}
t2=C_mutate((C_word*)lf[83]+1 /* char-set:lower-case ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3498,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 653  ucs-range->char-set");
t4=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(65),C_fix(91));}

/* k3496 in k3492 in k3489 in k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3498,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3501,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3589,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 656  ucs-range->char-set!");
t4=*((C_word*)lf[59]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,C_fix(192),C_fix(215),C_SCHEME_TRUE,t1);}

/* k3587 in k3496 in k3492 in k3489 in k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 655  ucs-range->char-set!");
t2=*((C_word*)lf[59]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],C_fix(216),C_fix(223),C_SCHEME_TRUE,t1);}

/* k3499 in k3496 in k3492 in k3489 in k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3501,2,t0,t1);}
t2=C_mutate((C_word*)lf[84]+1 /* char-set:upper-case ...) */,t1);
t3=C_mutate((C_word*)lf[85]+1 /* char-set:title-case ...) */,*((C_word*)lf[71]+1));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3506,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 661  char-set-union");
t5=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[84]+1),*((C_word*)lf[83]+1));}

/* k3504 in k3499 in k3496 in k3492 in k3489 in k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3509,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3581,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 663  %latin1->char");
t4=lf[2];
f_1207(3,t4,t3,C_fix(170));}

/* k3579 in k3504 in k3499 in k3496 in k3492 in k3489 in k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3581,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3585,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("srfi-14.scm: 664  %latin1->char");
t3=lf[2];
f_1207(3,t3,t2,C_fix(186));}

/* k3583 in k3579 in k3504 in k3499 in k3496 in k3492 in k3489 in k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 662  char-set-adjoin!");
t2=*((C_word*)lf[31]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3507 in k3504 in k3499 in k3496 in k3492 in k3489 in k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3509,2,t0,t1);}
t2=C_mutate((C_word*)lf[86]+1 /* char-set:letter ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3513,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 666  string->char-set");
t4=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[106]);}

/* k3511 in k3507 in k3504 in k3499 in k3496 in k3492 in k3489 in k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3513,2,t0,t1);}
t2=C_mutate((C_word*)lf[87]+1 /* char-set:digit ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3517,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 667  string->char-set");
t4=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[105]);}

/* k3515 in k3511 in k3507 in k3504 in k3499 in k3496 in k3492 in k3489 in k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3517,2,t0,t1);}
t2=C_mutate((C_word*)lf[88]+1 /* char-set:hex-digit ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3521,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 670  char-set-union");
t4=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[86]+1),*((C_word*)lf[87]+1));}

/* k3519 in k3515 in k3511 in k3507 in k3504 in k3499 in k3496 in k3492 in k3489 in k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3521,2,t0,t1);}
t2=C_mutate((C_word*)lf[89]+1 /* char-set:letter+digit ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3525,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 673  string->char-set");
t4=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[104]);}

/* k3523 in k3519 in k3515 in k3511 in k3507 in k3504 in k3499 in k3496 in k3492 in k3489 in k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3528,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t3=*((C_word*)lf[98]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[2],lf[103]);}

/* k3526 in k3523 in k3519 in k3515 in k3511 in k3507 in k3504 in k3499 in k3496 in k3492 in k3489 in k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3531,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 680  list->char-set!");
t3=*((C_word*)lf[49]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k3529 in k3526 in k3523 in k3519 in k3515 in k3511 in k3507 in k3504 in k3499 in k3496 in k3492 in k3489 in k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3531,2,t0,t1);}
t2=C_mutate((C_word*)lf[90]+1 /* char-set:punctuation ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3535,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 683  string->char-set");
t4=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[102]);}

/* k3533 in k3529 in k3526 in k3523 in k3519 in k3515 in k3511 in k3507 in k3504 in k3499 in k3496 in k3492 in k3489 in k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3538,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t3=*((C_word*)lf[98]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[2],lf[101]);}

/* k3536 in k3533 in k3529 in k3526 in k3523 in k3519 in k3515 in k3511 in k3507 in k3504 in k3499 in k3496 in k3492 in k3489 in k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3541,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 702  list->char-set!");
t3=*((C_word*)lf[49]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k3539 in k3536 in k3533 in k3529 in k3526 in k3523 in k3519 in k3515 in k3511 in k3507 in k3504 in k3499 in k3496 in k3492 in k3489 in k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3541,2,t0,t1);}
t2=C_mutate((C_word*)lf[91]+1 /* char-set:symbol ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3545,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 706  char-set-union");
t4=*((C_word*)lf[70]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,*((C_word*)lf[89]+1),*((C_word*)lf[90]+1),*((C_word*)lf[91]+1));}

/* k3543 in k3539 in k3536 in k3533 in k3529 in k3526 in k3523 in k3519 in k3515 in k3511 in k3507 in k3504 in k3499 in k3496 in k3492 in k3489 in k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3545,2,t0,t1);}
t2=C_mutate((C_word*)lf[92]+1 /* char-set:graphic ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3549,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3577,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t5=*((C_word*)lf[98]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[2],lf[100]);}

/* k3575 in k3543 in k3539 in k3536 in k3533 in k3529 in k3526 in k3523 in k3519 in k3515 in k3511 in k3507 in k3504 in k3499 in k3496 in k3492 in k3489 in k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 709  list->char-set");
t2=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3547 in k3543 in k3539 in k3536 in k3533 in k3529 in k3526 in k3523 in k3519 in k3515 in k3511 in k3507 in k3504 in k3499 in k3496 in k3492 in k3489 in k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3549,2,t0,t1);}
t2=C_mutate((C_word*)lf[93]+1 /* char-set:whitespace ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3553,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 717  char-set-union");
t4=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[93]+1),*((C_word*)lf[92]+1));}

/* k3551 in k3547 in k3543 in k3539 in k3536 in k3533 in k3529 in k3526 in k3523 in k3519 in k3515 in k3511 in k3507 in k3504 in k3499 in k3496 in k3492 in k3489 in k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3553,2,t0,t1);}
t2=C_mutate((C_word*)lf[94]+1 /* char-set:printing ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3557,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3573,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t5=*((C_word*)lf[98]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[2],lf[99]);}

/* k3571 in k3551 in k3547 in k3543 in k3539 in k3536 in k3533 in k3529 in k3526 in k3523 in k3519 in k3515 in k3511 in k3507 in k3504 in k3499 in k3496 in k3492 in k3489 in k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 720  list->char-set");
t2=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3555 in k3551 in k3547 in k3543 in k3539 in k3536 in k3533 in k3529 in k3526 in k3523 in k3519 in k3515 in k3511 in k3507 in k3504 in k3499 in k3496 in k3492 in k3489 in k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3557,2,t0,t1);}
t2=C_mutate((C_word*)lf[95]+1 /* char-set:blank ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3561,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3569,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 726  ucs-range->char-set");
t5=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_fix(0),C_fix(32));}

/* k3567 in k3555 in k3551 in k3547 in k3543 in k3539 in k3536 in k3533 in k3529 in k3526 in k3523 in k3519 in k3515 in k3511 in k3507 in k3504 in k3499 in k3496 in k3492 in k3489 in k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 726  ucs-range->char-set!");
t2=*((C_word*)lf[59]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],C_fix(127),C_fix(160),C_SCHEME_TRUE,t1);}

/* k3559 in k3555 in k3551 in k3547 in k3543 in k3539 in k3536 in k3533 in k3529 in k3526 in k3523 in k3519 in k3515 in k3511 in k3507 in k3504 in k3499 in k3496 in k3492 in k3489 in k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3561,2,t0,t1);}
t2=C_mutate((C_word*)lf[96]+1 /* char-set:iso-control ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3565,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 728  ucs-range->char-set");
t4=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(0),C_fix(128));}

/* k3563 in k3559 in k3555 in k3551 in k3547 in k3543 in k3539 in k3536 in k3533 in k3529 in k3526 in k3523 in k3519 in k3515 in k3511 in k3507 in k3504 in k3499 in k3496 in k3492 in k3489 in k3486 in k3483 in k3479 in k3475 in k1323 in k1319 in k1203 */
static void C_ccall f_3565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[97]+1 /* char-set:ascii ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* char-set-diff+intersection in k1323 in k1319 in k1203 */
static void C_ccall f_3448(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_3448r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3448r(t0,t1,t2,t3);}}

static void C_ccall f_3448r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3452,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3473,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 629  %char-set:s/check");
f_1294(t5,t2,lf[81]);}

/* k3471 in char-set-diff+intersection in k1323 in k1319 in k1203 */
static void C_ccall f_3473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 629  string-copy");
t2=*((C_word*)lf[82]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3450 in char-set-diff+intersection in k1323 in k1319 in k1203 */
static void C_ccall f_3452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3455,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("srfi-14.scm: 630  make-string");
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(256),lf[17]);}

/* k3453 in k3450 in char-set-diff+intersection in k1323 in k1319 in k1203 */
static void C_ccall f_3455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3458,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("srfi-14.scm: 631  %char-set-diff+intersection!");
f_3304(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],lf[81]);}

/* k3456 in k3453 in k3450 in char-set-diff+intersection in k1323 in k1319 in k1203 */
static void C_ccall f_3458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3465,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 632  make-char-set");
t3=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3463 in k3456 in k3453 in k3450 in char-set-diff+intersection in k1323 in k1319 in k1203 */
static void C_ccall f_3465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3469,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 632  make-char-set");
t3=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3467 in k3463 in k3456 in k3453 in k3450 in char-set-diff+intersection in k1323 in k1319 in k1203 */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 632  values");
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* char-set-diff+intersection! in k1323 in k1319 in k1203 */
static void C_ccall f_3377(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_3377r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3377r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3377r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3381,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("srfi-14.scm: 619  %char-set:s/check");
f_1294(t5,t2,lf[80]);}

/* k3379 in char-set-diff+intersection! in k1323 in k1319 in k1203 */
static void C_ccall f_3381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3384,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("srfi-14.scm: 620  %char-set:s/check");
f_1294(t2,((C_word*)t0)[3],lf[80]);}

/* k3382 in k3379 in char-set-diff+intersection! in k1323 in k1319 in k1203 */
static void C_ccall f_3384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3387,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3395,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li156),tmp=(C_word)a,a+=5,tmp);
C_trace("srfi-14.scm: 621  %string-iter");
f_2778(t2,t3,((C_word*)t0)[3]);}

/* a3394 in k3382 in k3379 in char-set-diff+intersection! in k1323 in k1319 in k1203 */
static void C_ccall f_3395(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3395,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3406,a[2]=((C_word)li152),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,((C_word*)t0)[3],t2);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3416,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3425,a[2]=((C_word)li155),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[3],t2);}}

/* f_3425 in a3394 in k3382 in k3379 in char-set-diff+intersection! in k1323 in k1319 in k1203 */
static void C_ccall f_3425(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3425,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3433,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3434,a[2]=((C_word)li154),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* f_3434 */
static void C_ccall f_3434(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3434,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=f_1213(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t5,C_fix(0)));}

/* k3431 */
static void C_ccall f_3433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k3414 in a3394 in k3382 in k3379 in char-set-diff+intersection! in k1323 in k1319 in k1203 */
static void C_ccall f_3416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3416,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3420,a[2]=((C_word)li153),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* f_3420 in k3414 in a3394 in k3382 in k3379 in char-set-diff+intersection! in k1323 in k1319 in k1203 */
static void C_ccall f_3420(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3420,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[17]));}

/* f_3406 in a3394 in k3382 in k3379 in char-set-diff+intersection! in k1323 in k1319 in k1203 */
static void C_ccall f_3406(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3406,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[17]));}

/* k3385 in k3382 in k3379 in char-set-diff+intersection! in k1323 in k1319 in k1203 */
static void C_ccall f_3387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3390,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
C_trace("srfi-14.scm: 625  %char-set-diff+intersection!");
f_3304(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[80]);}

/* k3388 in k3385 in k3382 in k3379 in char-set-diff+intersection! in k1323 in k1319 in k1203 */
static void C_ccall f_3390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 626  values");
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-diff+intersection! in k1323 in k1319 in k1203 */
static void C_fcall f_3304(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3304,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3310,a[2]=t5,a[3]=t2,a[4]=t3,a[5]=((C_word)li150),tmp=(C_word)a,a+=6,tmp);
C_trace("for-each");
t7=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t4);}

/* a3309 in %char-set-diff+intersection! in k1323 in k1319 in k1203 */
static void C_ccall f_3310(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3310,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3316,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li149),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3375,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 615  %char-set:s/check");
f_1294(t4,t2,((C_word*)t0)[2]);}

/* k3373 in a3309 in %char-set-diff+intersection! in k1323 in k1319 in k1203 */
static void C_ccall f_3375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 610  %string-iter");
f_2778(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3315 in a3309 in %char-set-diff+intersection! in k1323 in k1319 in k1203 */
static void C_ccall f_3316(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3316,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3329,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3346,a[2]=((C_word)li148),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t2);}}

/* f_3346 in a3315 in a3309 in %char-set-diff+intersection! in k1323 in k1319 in k1203 */
static void C_ccall f_3346(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3346,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3354,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3355,a[2]=((C_word)li147),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* f_3355 */
static void C_ccall f_3355(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3355,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=f_1213(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t5,C_fix(0)));}

/* k3352 */
static void C_ccall f_3354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k3327 in a3315 in a3309 in %char-set-diff+intersection! in k1323 in k1319 in k1203 */
static void C_ccall f_3329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3329,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3332,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3341,a[2]=((C_word)li146),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* f_3341 in k3327 in a3315 in a3309 in %char-set-diff+intersection! in k1323 in k1319 in k1203 */
static void C_ccall f_3341(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3341,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[17]));}

/* k3330 in k3327 in a3315 in a3309 in %char-set-diff+intersection! in k1323 in k1319 in k1203 */
static void C_ccall f_3332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3336,a[2]=((C_word)li145),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_3336 in k3330 in k3327 in a3315 in a3309 in %char-set-diff+intersection! in k1323 in k1319 in k1203 */
static void C_ccall f_3336(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3336,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[18]));}

/* char-set-xor in k1323 in k1319 in k1203 */
static void C_ccall f_3229(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_3229r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3229r(t0,t1,t2);}}

static void C_ccall f_3229r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3239,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3295,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(t2);
C_trace("srfi-14.scm: 600  %char-set:s/check");
f_1294(t4,t5,lf[78]);}
else{
C_trace("srfi-14.scm: 603  char-set-copy");
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,*((C_word*)lf[71]+1));}}

/* k3293 in char-set-xor in k1323 in k1319 in k1203 */
static void C_ccall f_3295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 600  %string-copy");
f_1237(((C_word*)t0)[2],t1);}

/* k3237 in char-set-xor in k1323 in k1319 in k1203 */
static void C_ccall f_3239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3242,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3251,a[2]=((C_word)li143),tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 601  %char-set-algebra");
f_2819(t2,t1,t3,t4,lf[78]);}

/* a3250 in k3237 in char-set-xor in k1323 in k1319 in k1203 */
static void C_ccall f_3251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3251,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3278,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3279,a[2]=((C_word)li142),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,t3);}}

/* f_3279 in a3250 in k3237 in char-set-xor in k1323 in k1319 in k1203 */
static void C_ccall f_3279(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3279,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
C_trace("srfi-14.scm: 150  %char->latin1");
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_1213(t4));}

/* k3276 in a3250 in k3237 in char-set-xor in k1323 in k1319 in k1203 */
static void C_ccall f_3278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3278,2,t0,t1);}
t2=(C_word)C_fixnum_difference(C_fix(1),t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3266,a[2]=((C_word)li141),tmp=(C_word)a,a+=3,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* f_3266 in k3276 in a3250 in k3237 in char-set-xor in k1323 in k1319 in k1203 */
static void C_ccall f_3266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3266,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3274,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("srfi-14.scm: 160  %latin1->char");
t6=lf[2];
f_1207(3,t6,t5,t4);}

/* k3272 */
static void C_ccall f_3274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_string_set(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k3240 in k3237 in char-set-xor in k1323 in k1319 in k1203 */
static void C_ccall f_3242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 602  make-char-set");
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-xor! in k1323 in k1319 in k1203 */
static void C_ccall f_3177(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_3177r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3177r(t0,t1,t2,t3);}}

static void C_ccall f_3177r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3181,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3185,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 594  %char-set:s/check");
f_1294(t5,t2,lf[77]);}

/* k3183 in char-set-xor! in k1323 in k1319 in k1203 */
static void C_ccall f_3185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3187,a[2]=((C_word)li139),tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 594  %char-set-algebra");
f_2819(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[77]);}

/* a3186 in k3183 in char-set-xor! in k1323 in k1319 in k1203 */
static void C_ccall f_3187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3187,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3214,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3215,a[2]=((C_word)li138),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,t3);}}

/* f_3215 in a3186 in k3183 in char-set-xor! in k1323 in k1319 in k1203 */
static void C_ccall f_3215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3215,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
C_trace("srfi-14.scm: 150  %char->latin1");
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_1213(t4));}

/* k3212 in a3186 in k3183 in char-set-xor! in k1323 in k1319 in k1203 */
static void C_ccall f_3214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3214,2,t0,t1);}
t2=(C_word)C_fixnum_difference(C_fix(1),t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3202,a[2]=((C_word)li137),tmp=(C_word)a,a+=3,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* f_3202 in k3212 in a3186 in k3183 in char-set-xor! in k1323 in k1319 in k1203 */
static void C_ccall f_3202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3202,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3210,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("srfi-14.scm: 160  %latin1->char");
t6=lf[2];
f_1207(3,t6,t5,t4);}

/* k3208 */
static void C_ccall f_3210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_string_set(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k3179 in char-set-xor! in k1323 in k1319 in k1203 */
static void C_ccall f_3181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-difference in k1323 in k1319 in k1203 */
static void C_ccall f_3131(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_3131r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3131r(t0,t1,t2,t3);}}

static void C_ccall f_3131r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3141,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3172,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 585  %char-set:s/check");
f_1294(t5,t2,lf[76]);}
else{
C_trace("srfi-14.scm: 588  char-set-copy");
t4=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}}

/* k3170 in char-set-difference in k1323 in k1319 in k1203 */
static void C_ccall f_3172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 585  %string-copy");
f_1237(((C_word*)t0)[2],t1);}

/* k3139 in char-set-difference in k1323 in k1319 in k1203 */
static void C_ccall f_3141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3144,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3149,a[2]=((C_word)li135),tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 586  %char-set-algebra");
f_2819(t2,t1,((C_word*)t0)[2],t3,lf[76]);}

/* a3148 in k3139 in char-set-difference in k1323 in k1319 in k1203 */
static void C_ccall f_3149(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3149,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3160,a[2]=((C_word)li134),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t2,t3);}}

/* f_3160 in a3148 in k3139 in char-set-difference in k1323 in k1319 in k1203 */
static void C_ccall f_3160(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3160,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[17]));}

/* k3142 in k3139 in char-set-difference in k1323 in k1319 in k1203 */
static void C_ccall f_3144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 587  make-char-set");
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-difference! in k1323 in k1319 in k1203 */
static void C_ccall f_3100(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_3100r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3100r(t0,t1,t2,t3);}}

static void C_ccall f_3100r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3104,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3108,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 579  %char-set:s/check");
f_1294(t5,t2,lf[75]);}

/* k3106 in char-set-difference! in k1323 in k1319 in k1203 */
static void C_ccall f_3108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3108,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3110,a[2]=((C_word)li132),tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 579  %char-set-algebra");
f_2819(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[75]);}

/* a3109 in k3106 in char-set-difference! in k1323 in k1319 in k1203 */
static void C_ccall f_3110(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3110,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3121,a[2]=((C_word)li131),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t2,t3);}}

/* f_3121 in a3109 in k3106 in char-set-difference! in k1323 in k1319 in k1203 */
static void C_ccall f_3121(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3121,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[17]));}

/* k3102 in char-set-difference! in k1323 in k1319 in k1203 */
static void C_ccall f_3104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-intersection in k1323 in k1319 in k1203 */
static void C_ccall f_3050(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_3050r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3050r(t0,t1,t2);}}

static void C_ccall f_3050r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3060,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3091,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(t2);
C_trace("srfi-14.scm: 570  %char-set:s/check");
f_1294(t4,t5,lf[73]);}
else{
C_trace("srfi-14.scm: 573  char-set-copy");
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,*((C_word*)lf[74]+1));}}

/* k3089 in char-set-intersection in k1323 in k1319 in k1203 */
static void C_ccall f_3091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 570  %string-copy");
f_1237(((C_word*)t0)[2],t1);}

/* k3058 in char-set-intersection in k1323 in k1319 in k1203 */
static void C_ccall f_3060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3063,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3072,a[2]=((C_word)li129),tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 571  %char-set-algebra");
f_2819(t2,t1,t3,t4,lf[73]);}

/* a3071 in k3058 in char-set-intersection in k1323 in k1319 in k1203 */
static void C_ccall f_3072(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3072,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3083,a[2]=((C_word)li128),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t2,t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* f_3083 in a3071 in k3058 in char-set-intersection in k1323 in k1319 in k1203 */
static void C_ccall f_3083(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3083,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[17]));}

/* k3061 in k3058 in char-set-intersection in k1323 in k1319 in k1203 */
static void C_ccall f_3063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 572  make-char-set");
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-intersection! in k1323 in k1319 in k1203 */
static void C_ccall f_3023(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_3023r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3023r(t0,t1,t2,t3);}}

static void C_ccall f_3023r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3027,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3031,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 564  %char-set:s/check");
f_1294(t5,t2,lf[72]);}

/* k3029 in char-set-intersection! in k1323 in k1319 in k1203 */
static void C_ccall f_3031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3033,a[2]=((C_word)li126),tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 564  %char-set-algebra");
f_2819(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[72]);}

/* a3032 in k3029 in char-set-intersection! in k1323 in k1319 in k1203 */
static void C_ccall f_3033(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3033,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3044,a[2]=((C_word)li125),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t2,t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* f_3044 in a3032 in k3029 in char-set-intersection! in k1323 in k1319 in k1203 */
static void C_ccall f_3044(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3044,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[17]));}

/* k3025 in char-set-intersection! in k1323 in k1319 in k1203 */
static void C_ccall f_3027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-union in k1323 in k1319 in k1203 */
static void C_ccall f_2969(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2969r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2969r(t0,t1,t2);}}

static void C_ccall f_2969r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2979,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3014,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(t2);
C_trace("srfi-14.scm: 555  %char-set:s/check");
f_1294(t4,t5,lf[70]);}
else{
C_trace("srfi-14.scm: 558  char-set-copy");
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,*((C_word*)lf[71]+1));}}

/* k3012 in char-set-union in k1323 in k1319 in k1203 */
static void C_ccall f_3014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 555  %string-copy");
f_1237(((C_word*)t0)[2],t1);}

/* k2977 in char-set-union in k1323 in k1319 in k1203 */
static void C_ccall f_2979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2982,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2991,a[2]=((C_word)li123),tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 556  %char-set-algebra");
f_2819(t2,t1,t3,t4,lf[70]);}

/* a2990 in k2977 in char-set-union in k1323 in k1319 in k1203 */
static void C_ccall f_2991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2991,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3002,a[2]=((C_word)li122),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t2,t3);}}

/* f_3002 in a2990 in k2977 in char-set-union in k1323 in k1319 in k1203 */
static void C_ccall f_3002(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3002,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[18]));}

/* k2980 in k2977 in char-set-union in k1323 in k1319 in k1203 */
static void C_ccall f_2982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 557  make-char-set");
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-union! in k1323 in k1319 in k1203 */
static void C_ccall f_2938(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2938r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2938r(t0,t1,t2,t3);}}

static void C_ccall f_2938r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2942,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2946,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 549  %char-set:s/check");
f_1294(t5,t2,lf[69]);}

/* k2944 in char-set-union! in k1323 in k1319 in k1203 */
static void C_ccall f_2946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2948,a[2]=((C_word)li120),tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 549  %char-set-algebra");
f_2819(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[69]);}

/* a2947 in k2944 in char-set-union! in k1323 in k1319 in k1203 */
static void C_ccall f_2948(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2948,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2959,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t2,t3);}}

/* f_2959 in a2947 in k2944 in char-set-union! in k1323 in k1319 in k1203 */
static void C_ccall f_2959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2959,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[18]));}

/* k2940 in char-set-union! in k1323 in k1319 in k1203 */
static void C_ccall f_2942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-complement! in k1323 in k1319 in k1203 */
static void C_ccall f_2905(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2905,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2909,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 541  %char-set:s/check");
f_1294(t3,t2,lf[68]);}

/* k2907 in char-set-complement! in k1323 in k1319 in k1203 */
static void C_ccall f_2909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2912,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2914,a[2]=t1,a[3]=((C_word)li117),tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 542  %string-iter");
f_2778(t2,t3,t1);}

/* a2913 in k2907 in char-set-complement! in k1323 in k1319 in k1203 */
static void C_ccall f_2914(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2914,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2919,a[2]=((C_word)li116),tmp=(C_word)a,a+=3,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* f_2919 in a2913 in k2907 in char-set-complement! in k1323 in k1319 in k1203 */
static void C_ccall f_2919(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2919,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(C_fix(1),t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2928,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t3,t5);}

/* f_2928 */
static void C_ccall f_2928(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2928,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2936,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("srfi-14.scm: 160  %latin1->char");
t6=lf[2];
f_1207(3,t6,t5,t4);}

/* k2934 */
static void C_ccall f_2936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_string_set(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2910 in k2907 in char-set-complement! in k1323 in k1319 in k1203 */
static void C_ccall f_2912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-complement in k1323 in k1319 in k1203 */
static void C_ccall f_2866(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2866,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2870,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 535  %char-set:s/check");
f_1294(t3,t2,lf[67]);}

/* k2868 in char-set-complement in k1323 in k1319 in k1203 */
static void C_ccall f_2870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2873,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 536  make-string");
t3=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(256));}

/* k2871 in k2868 in char-set-complement in k1323 in k1319 in k1203 */
static void C_ccall f_2873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2876,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2881,a[2]=t1,a[3]=((C_word)li113),tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 537  %string-iter");
f_2778(t2,t3,((C_word*)t0)[2]);}

/* a2880 in k2871 in k2868 in char-set-complement in k1323 in k1319 in k1203 */
static void C_ccall f_2881(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2881,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2886,a[2]=((C_word)li112),tmp=(C_word)a,a+=3,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* f_2886 in a2880 in k2871 in k2868 in char-set-complement in k1323 in k1319 in k1203 */
static void C_ccall f_2886(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2886,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(C_fix(1),t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2895,a[2]=((C_word)li111),tmp=(C_word)a,a+=3,tmp);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t3,t5);}

/* f_2895 */
static void C_ccall f_2895(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2895,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2903,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("srfi-14.scm: 160  %latin1->char");
t6=lf[2];
f_1207(3,t6,t5,t4);}

/* k2901 */
static void C_ccall f_2903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_string_set(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2874 in k2871 in k2868 in char-set-complement in k1323 in k1319 in k1203 */
static void C_ccall f_2876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 538  make-char-set");
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-algebra in k1323 in k1319 in k1203 */
static void C_fcall f_2819(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2819,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2825,a[2]=t5,a[3]=t2,a[4]=t4,a[5]=((C_word)li109),tmp=(C_word)a,a+=6,tmp);
C_trace("for-each");
t7=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t3);}

/* a2824 in %char-set-algebra in k1323 in k1319 in k1203 */
static void C_ccall f_2825(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2825,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2829,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("srfi-14.scm: 524  %char-set:s/check");
f_1294(t3,t2,((C_word*)t0)[2]);}

/* k2827 in a2824 in %char-set-algebra in k1323 in k1319 in k1203 */
static void C_ccall f_2829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2829,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2834,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word)li108),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2834(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k2827 in a2824 in %char-set-algebra in k1323 in k1319 in k1203 */
static void C_fcall f_2834(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2834,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2844,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2855,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2856,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* f_2856 in lp in k2827 in a2824 in %char-set-algebra in k1323 in k1319 in k1203 */
static void C_ccall f_2856(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2856,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
C_trace("srfi-14.scm: 150  %char->latin1");
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_1213(t4));}

/* k2853 in lp in k2827 in a2824 in %char-set-algebra in k1323 in k1319 in k1203 */
static void C_ccall f_2855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 527  op");
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2842 in lp in k2827 in a2824 in %char-set-algebra in k1323 in k1319 in k1203 */
static void C_ccall f_2844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
C_trace("srfi-14.scm: 528  lp");
t3=((C_word*)((C_word*)t0)[3])[1];
f_2834(t3,((C_word*)t0)[2],t2);}

/* %string-iter in k1323 in k1319 in k1203 */
static void C_fcall f_2778(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2778,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_string_length(t3);
t5=(C_word)C_fixnum_difference(t4,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2788,a[2]=t2,a[3]=t3,a[4]=t7,a[5]=((C_word)li105),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_2788(t9,t1,t5);}

/* lp in %string-iter in k1323 in k1319 in k1203 */
static void C_fcall f_2788(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2788,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2798,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t6=f_1213(t5);
C_trace("srfi-14.scm: 513  p");
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t2,t6);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2796 in lp in %string-iter in k1323 in k1319 in k1203 */
static void C_ccall f_2798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
C_trace("srfi-14.scm: 514  lp");
t3=((C_word*)((C_word*)t0)[3])[1];
f_2788(t3,((C_word*)t0)[2],t2);}

/* ->char-set in k1323 in k1319 in k1203 */
static void C_ccall f_2748(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2748,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2755,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 490  char-set?");
t4=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2753 in ->char-set in k1323 in k1319 in k1203 */
static void C_ccall f_2755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[2]))){
C_trace("srfi-14.scm: 491  string->char-set");
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[2]))){
C_trace("srfi-14.scm: 492  char-set");
t2=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
C_trace("srfi-14.scm: 493  ##sys#error");
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[63],lf[64],((C_word*)t0)[2]);}}}}

/* char-set-filter! in k1323 in k1319 in k1203 */
static void C_ccall f_2734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2734,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2738,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2742,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("srfi-14.scm: 481  %char-set:s/check");
f_1294(t6,t3,lf[62]);}

/* k2740 in char-set-filter! in k1323 in k1319 in k1203 */
static void C_ccall f_2742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2746,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("srfi-14.scm: 482  %char-set:s/check");
f_1294(t2,((C_word*)t0)[2],lf[62]);}

/* k2744 in k2740 in char-set-filter! in k1323 in k1319 in k1203 */
static void C_ccall f_2746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 480  %char-set-filter!");
f_2650(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2736 in char-set-filter! in k1323 in k1319 in k1203 */
static void C_ccall f_2738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-filter in k1323 in k1319 in k1203 */
static void C_ccall f_2718(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_2718r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2718r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2718r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2722,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("srfi-14.scm: 472  %default-base");
f_1247(t5,t4,*((C_word*)lf[61]+1));}

/* k2720 in char-set-filter in k1323 in k1319 in k1203 */
static void C_ccall f_2722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2722,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2725,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2732,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("srfi-14.scm: 474  %char-set:s/check");
f_1294(t3,((C_word*)t0)[2],lf[62]);}

/* k2730 in k2720 in char-set-filter in k1323 in k1319 in k1203 */
static void C_ccall f_2732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 473  %char-set-filter!");
f_2650(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2723 in k2720 in char-set-filter in k1323 in k1319 in k1203 */
static void C_ccall f_2725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 477  make-char-set");
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-filter! in k1323 in k1319 in k1203 */
static void C_fcall f_2650(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2650,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2656,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t6,a[6]=((C_word)li100),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_2656(t8,t1,C_fix(255));}

/* lp in %char-set-filter! in k1323 in k1319 in k1203 */
static void C_fcall f_2656(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2656,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2666,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2676,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2687,a[2]=t2,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2695,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* f_2695 in lp in %char-set-filter! in k1323 in k1319 in k1203 */
static void C_ccall f_2695(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2695,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2703,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2704,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* f_2704 */
static void C_ccall f_2704(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2704,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=f_1213(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t5,C_fix(0)));}

/* k2701 */
static void C_ccall f_2703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k2685 in lp in %char-set-filter! in k1323 in k1319 in k1203 */
static void C_ccall f_2687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2687,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2694,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 467  %latin1->char");
t3=lf[2];
f_1207(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2676(2,t2,C_SCHEME_FALSE);}}

/* k2692 in k2685 in lp in %char-set-filter! in k1323 in k1319 in k1203 */
static void C_ccall f_2694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 467  pred");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2674 in lp in %char-set-filter! in k1323 in k1319 in k1203 */
static void C_ccall f_2676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2676,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2680,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_2666(2,t2,C_SCHEME_UNDEFINED);}}

/* f_2680 in k2674 in lp in %char-set-filter! in k1323 in k1319 in k1203 */
static void C_ccall f_2680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2680,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[18]));}

/* k2664 in lp in %char-set-filter! in k1323 in k1319 in k1203 */
static void C_ccall f_2666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
C_trace("srfi-14.scm: 469  lp");
t3=((C_word*)((C_word*)t0)[3])[1];
f_2656(t3,((C_word*)t0)[2],t2);}

/* ucs-range->char-set! in k1323 in k1319 in k1203 */
static void C_ccall f_2640(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2640,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2644,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2648,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
C_trace("srfi-14.scm: 456  %char-set:s/check");
f_1294(t7,t5,lf[59]);}

/* k2646 in ucs-range->char-set! in k1323 in k1319 in k1203 */
static void C_ccall f_2648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 455  %ucs-range->char-set!");
f_2548(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[58]);}

/* k2642 in ucs-range->char-set! in k1323 in k1319 in k1203 */
static void C_ccall f_2644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ucs-range->char-set in k1323 in k1319 in k1203 */
static void C_ccall f_2610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2610r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2610r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2610r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_car(t4));
t7=(C_word)C_i_nullp(t4);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t4));
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2620,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("srfi-14.scm: 450  %default-base");
f_1247(t9,t8,*((C_word*)lf[58]+1));}

/* k2618 in ucs-range->char-set in k1323 in k1319 in k1203 */
static void C_ccall f_2620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2623,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 451  %ucs-range->char-set!");
f_2548(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[58]);}

/* k2621 in k2618 in ucs-range->char-set in k1323 in k1319 in k1203 */
static void C_ccall f_2623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 452  make-char-set");
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %ucs-range->char-set! in k1323 in k1319 in k1203 */
static void C_fcall f_2548(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2548,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_exact_2(t2,t6);
t8=(C_word)C_i_check_exact_2(t3,t6);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2558,a[2]=t3,a[3]=t1,a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2596,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
t11=t2;
t12=t3;
if(C_truep((C_word)C_fixnum_lessp(t11,t12))){
t13=t3;
t14=(C_word)C_fixnum_lessp(C_fix(256),t13);
t15=t10;
f_2596(t15,(C_truep(t14)?t4:C_SCHEME_FALSE));}
else{
t13=t10;
f_2596(t13,C_SCHEME_FALSE);}}

/* k2594 in %ucs-range->char-set! in k1323 in k1319 in k1203 */
static void C_fcall f_2596(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("srfi-14.scm: 442  ##sys#error");
t2=*((C_word*)lf[11]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],lf[57],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_2558(2,t2,C_SCHEME_UNDEFINED);}}

/* k2556 in %ucs-range->char-set! in k1323 in k1319 in k1203 */
static void C_ccall f_2558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2593,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("srfi-14.scm: 445  min");
t3=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(256));}

/* k2591 in k2556 in %ucs-range->char-set! in k1323 in k1319 in k1203 */
static void C_ccall f_2593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2593,2,t0,t1);}
t2=(C_word)C_fixnum_difference(t1,C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2567,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word)li93),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2567(t6,((C_word*)t0)[2],t2);}

/* lp in k2591 in k2556 in %ucs-range->char-set! in k1323 in k1319 in k1203 */
static void C_fcall f_2567(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2567,NULL,3,t0,t1,t2);}
t3=((C_word*)t0)[4];
t4=t2;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2577,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2585,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t2);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* f_2585 in lp in k2591 in k2556 in %ucs-range->char-set! in k1323 in k1319 in k1203 */
static void C_ccall f_2585(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2585,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[18]));}

/* k2575 in lp in k2591 in k2556 in %ucs-range->char-set! in k1323 in k1319 in k1203 */
static void C_ccall f_2577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
C_trace("srfi-14.scm: 446  lp");
t3=((C_word*)((C_word*)t0)[3])[1];
f_2567(t3,((C_word*)t0)[2],t2);}

/* char-set->string in k1323 in k1319 in k1203 */
static void C_ccall f_2487(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2487,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2491,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 423  %char-set:s/check");
f_1294(t3,t2,lf[54]);}

/* k2489 in char-set->string in k1323 in k1319 in k1203 */
static void C_ccall f_2491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2494,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2546,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 424  char-set-size");
t4=*((C_word*)lf[25]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2544 in k2489 in char-set->string in k1323 in k1319 in k1203 */
static void C_ccall f_2546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 424  make-string");
t2=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2492 in k2489 in char-set->string in k1323 in k1319 in k1203 */
static void C_ccall f_2494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2494,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2499,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word)li90),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2499(t5,((C_word*)t0)[2],C_fix(255),C_fix(0));}

/* lp in k2492 in k2489 in char-set->string in k1323 in k1319 in k1203 */
static void C_fcall f_2499(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2499,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2509,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2519,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2530,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],t2);}}

/* f_2530 in lp in k2492 in k2489 in char-set->string in k1323 in k1319 in k1203 */
static void C_ccall f_2530(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2530,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=f_1213(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t5,C_fix(0)));}

/* k2517 in lp in k2492 in k2489 in char-set->string in k1323 in k1319 in k1203 */
static void C_ccall f_2519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2519,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_2509(t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2529,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("srfi-14.scm: 428  %latin1->char");
t3=lf[2];
f_1207(3,t3,t2,((C_word*)t0)[2]);}}

/* k2527 in k2517 in lp in k2492 in k2489 in char-set->string in k1323 in k1319 in k1203 */
static void C_ccall f_2529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_string_set(((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_2509(t3,(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1)));}

/* k2507 in lp in k2492 in k2489 in char-set->string in k1323 in k1319 in k1203 */
static void C_fcall f_2509(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
C_trace("srfi-14.scm: 430  lp");
t3=((C_word*)((C_word*)t0)[3])[1];
f_2499(t3,((C_word*)t0)[2],t2,t1);}

/* string->char-set! in k1323 in k1319 in k1203 */
static void C_ccall f_2477(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2477,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2481,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2485,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 417  %char-set:s/check");
f_1294(t5,t3,lf[53]);}

/* k2483 in string->char-set! in k1323 in k1319 in k1203 */
static void C_ccall f_2485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 417  %string->char-set!");
f_2416(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[53]);}

/* k2479 in string->char-set! in k1323 in k1319 in k1203 */
static void C_ccall f_2481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* string->char-set in k1323 in k1319 in k1203 */
static void C_ccall f_2465(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2465r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2465r(t0,t1,t2,t3);}}

static void C_ccall f_2465r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2469,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 412  %default-base");
f_1247(t4,t3,*((C_word*)lf[52]+1));}

/* k2467 in string->char-set in k1323 in k1319 in k1203 */
static void C_ccall f_2469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2472,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 413  %string->char-set!");
f_2416(t2,((C_word*)t0)[2],t1,lf[52]);}

/* k2470 in k2467 in string->char-set in k1323 in k1319 in k1203 */
static void C_ccall f_2472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 414  make-char-set");
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string->char-set! in k1323 in k1319 in k1203 */
static void C_fcall f_2416(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2416,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(C_word)C_i_string_length(t2);
t7=(C_word)C_fixnum_difference(t6,C_fix(1));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2429,a[2]=t3,a[3]=t2,a[4]=t9,a[5]=((C_word)li85),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_2429(t11,t1,t7);}

/* doloop623 in %string->char-set! in k1323 in k1319 in k1203 */
static void C_fcall f_2429(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2429,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2439,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t6=f_1213(t5);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2451,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,((C_word*)t0)[2],t6);}}

/* f_2451 in doloop623 in %string->char-set! in k1323 in k1319 in k1203 */
static void C_ccall f_2451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2451,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[18]));}

/* k2437 in doloop623 in %string->char-set! in k1323 in k1319 in k1203 */
static void C_ccall f_2439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2429(t3,((C_word*)t0)[2],t2);}

/* char-set->list in k1323 in k1319 in k1203 */
static void C_ccall f_2364(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2364,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2368,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 393  %char-set:s/check");
f_1294(t3,t2,lf[50]);}

/* k2366 in char-set->list in k1323 in k1319 in k1203 */
static void C_ccall f_2368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2368,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2373,a[2]=t1,a[3]=t3,a[4]=((C_word)li82),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2373(t5,((C_word*)t0)[2],C_fix(255),C_SCHEME_END_OF_LIST);}

/* lp in k2366 in char-set->list in k1323 in k1319 in k1203 */
static void C_fcall f_2373(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2373,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2391,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2394,a[2]=t2,a[3]=t3,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2402,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t0)[2],t2);}}

/* f_2402 in lp in k2366 in char-set->list in k1323 in k1319 in k1203 */
static void C_ccall f_2402(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2402,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=f_1213(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t5,C_fix(0)));}

/* k2392 in lp in k2366 in char-set->list in k1323 in k1319 in k1203 */
static void C_ccall f_2394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2394,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2391(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2401,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 398  %latin1->char");
t3=lf[2];
f_1207(3,t3,t2,((C_word*)t0)[2]);}}

/* k2399 in k2392 in lp in k2366 in char-set->list in k1323 in k1319 in k1203 */
static void C_ccall f_2401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2401,2,t0,t1);}
t2=((C_word*)t0)[3];
f_2391(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k2389 in lp in k2366 in char-set->list in k1323 in k1319 in k1203 */
static void C_fcall f_2391(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 396  lp");
t2=((C_word*)((C_word*)t0)[4])[1];
f_2373(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* list->char-set! in k1323 in k1319 in k1203 */
static void C_ccall f_2354(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2354,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2358,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2362,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 388  %char-set:s/check");
f_1294(t5,t3,lf[49]);}

/* k2360 in list->char-set! in k1323 in k1319 in k1203 */
static void C_ccall f_2362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 388  %list->char-set!");
f_2309(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2356 in list->char-set! in k1323 in k1319 in k1203 */
static void C_ccall f_2358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* list->char-set in k1323 in k1319 in k1203 */
static void C_ccall f_2342(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2342r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2342r(t0,t1,t2,t3);}}

static void C_ccall f_2342r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2346,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 383  %default-base");
f_1247(t4,t3,*((C_word*)lf[48]+1));}

/* k2344 in list->char-set in k1323 in k1319 in k1203 */
static void C_ccall f_2346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2349,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 384  %list->char-set!");
f_2309(t2,((C_word*)t0)[2],t1);}

/* k2347 in k2344 in list->char-set in k1323 in k1319 in k1203 */
static void C_ccall f_2349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 385  make-char-set");
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set in k1323 in k1319 in k1203 */
static void C_ccall f_2330(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2330r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2330r(t0,t1,t2);}}

static void C_ccall f_2330r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2334,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 378  make-string");
t4=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(256),lf[17]);}

/* k2332 in char-set in k1323 in k1319 in k1203 */
static void C_ccall f_2334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2337,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 379  %list->char-set!");
f_2309(t2,((C_word*)t0)[2],t1);}

/* k2335 in k2332 in char-set in k1323 in k1319 in k1203 */
static void C_ccall f_2337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 380  make-char-set");
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %list->char-set! in k1323 in k1319 in k1203 */
static void C_fcall f_2309(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2309,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2315,a[2]=t3,a[3]=((C_word)li76),tmp=(C_word)a,a+=4,tmp);
C_trace("for-each");
t5=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a2314 in %list->char-set! in k1323 in k1319 in k1203 */
static void C_ccall f_2315(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2315,3,t0,t1,t2);}
t3=f_1213(t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2324,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,((C_word*)t0)[2],t3);}

/* f_2324 in a2314 in %list->char-set! in k1323 in k1319 in k1203 */
static void C_ccall f_2324(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2324,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[18]));}

/* char-set-unfold! in k1323 in k1319 in k1203 */
static void C_ccall f_2299(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_2299,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2303,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2307,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
C_trace("srfi-14.scm: 365  %char-set:s/check");
f_1294(t8,t6,lf[46]);}

/* k2305 in char-set-unfold! in k1323 in k1319 in k1203 */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 364  %char-set-unfold!");
f_2245(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2301 in char-set-unfold! in k1323 in k1319 in k1203 */
static void C_ccall f_2303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-unfold in k1323 in k1319 in k1203 */
static void C_ccall f_2287(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc_2(c,6,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr6r,(void*)f_2287r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_2287r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_2287r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word *a=C_alloc(7);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2291,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
C_trace("srfi-14.scm: 359  %default-base");
f_1247(t7,t6,*((C_word*)lf[45]+1));}

/* k2289 in char-set-unfold in k1323 in k1319 in k1203 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2294,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 360  %char-set-unfold!");
f_2245(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2292 in k2289 in char-set-unfold in k1323 in k1319 in k1203 */
static void C_ccall f_2294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 361  make-char-set");
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-unfold! in k1323 in k1319 in k1203 */
static void C_fcall f_2245(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2245,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2251,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=t4,a[6]=t8,a[7]=((C_word)li71),tmp=(C_word)a,a+=8,tmp));
t10=((C_word*)t8)[1];
f_2251(t10,t1,t6);}

/* lp in %char-set-unfold! in k1323 in k1319 in k1203 */
static void C_fcall f_2251(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2251,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2285,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("srfi-14.scm: 354  p");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2283 in lp in %char-set-unfold! in k1323 in k1319 in k1203 */
static void C_ccall f_2285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2285,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2261,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2281,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 355  f");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}}

/* k2279 in k2283 in lp in %char-set-unfold! in k1323 in k1319 in k1203 */
static void C_ccall f_2281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2281,2,t0,t1);}
t2=f_1213(t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2273,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* f_2273 in k2279 in k2283 in lp in %char-set-unfold! in k1323 in k1319 in k1203 */
static void C_ccall f_2273(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2273,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[18]));}

/* k2259 in k2283 in lp in %char-set-unfold! in k1323 in k1319 in k1203 */
static void C_ccall f_2261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2268,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 356  g");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2266 in k2259 in k2283 in lp in %char-set-unfold! in k1323 in k1319 in k1203 */
static void C_ccall f_2268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 356  lp");
t2=((C_word*)((C_word*)t0)[3])[1];
f_2251(t2,((C_word*)t0)[2],t1);}

/* char-set-any in k1323 in k1319 in k1203 */
static void C_ccall f_2182(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2182,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2186,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 342  %char-set:s/check");
f_1294(t4,t3,lf[43]);}

/* k2184 in char-set-any in k1323 in k1319 in k1203 */
static void C_ccall f_2186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2186,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2191,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word)li68),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2191(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k2184 in char-set-any in k1323 in k1319 in k1203 */
static void C_fcall f_2191(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2191,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2201,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2214,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2222,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* f_2222 in lp in k2184 in char-set-any in k1323 in k1319 in k1203 */
static void C_ccall f_2222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2222,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2230,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2231,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* f_2231 */
static void C_ccall f_2231(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2231,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=f_1213(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t5,C_fix(0)));}

/* k2228 */
static void C_ccall f_2230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k2212 in lp in k2184 in char-set-any in k1323 in k1319 in k1203 */
static void C_ccall f_2214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2214,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2221,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 345  %latin1->char");
t3=lf[2];
f_1207(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2201(2,t2,C_SCHEME_FALSE);}}

/* k2219 in k2212 in lp in k2184 in char-set-any in k1323 in k1319 in k1203 */
static void C_ccall f_2221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 345  pred");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2199 in lp in k2184 in char-set-any in k1323 in k1319 in k1203 */
static void C_ccall f_2201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
C_trace("srfi-14.scm: 346  lp");
t3=((C_word*)((C_word*)t0)[2])[1];
f_2191(t3,((C_word*)t0)[4],t2);}}

/* char-set-every in k1323 in k1319 in k1203 */
static void C_ccall f_2128(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2128,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2132,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 334  %char-set:s/check");
f_1294(t4,t3,lf[42]);}

/* k2130 in char-set-every in k1323 in k1319 in k1203 */
static void C_ccall f_2132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2132,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2137,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word)li64),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2137(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k2130 in char-set-every in k1323 in k1319 in k1203 */
static void C_fcall f_2137(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2137,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_fixnum_lessp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2150,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2168,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t2);}}

/* f_2168 in lp in k2130 in char-set-every in k1323 in k1319 in k1203 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2168,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=f_1213(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t5,C_fix(0)));}

/* k2148 in lp in k2130 in char-set-every in k1323 in k1319 in k1203 */
static void C_ccall f_2150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2150,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2153,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_2153(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2167,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 337  %latin1->char");
t4=lf[2];
f_1207(3,t4,t3,((C_word*)t0)[5]);}}

/* k2165 in k2148 in lp in k2130 in char-set-every in k1323 in k1319 in k1203 */
static void C_ccall f_2167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 337  pred");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2151 in k2148 in lp in k2130 in char-set-every in k1323 in k1319 in k1203 */
static void C_ccall f_2153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
C_trace("srfi-14.scm: 338  lp");
t3=((C_word*)((C_word*)t0)[3])[1];
f_2137(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* char-set-fold in k1323 in k1319 in k1203 */
static void C_ccall f_2076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2076,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2080,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("srfi-14.scm: 325  %char-set:s/check");
f_1294(t5,t4,lf[41]);}

/* k2078 in char-set-fold in k1323 in k1319 in k1203 */
static void C_ccall f_2080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2080,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2085,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word)li61),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2085(t5,((C_word*)t0)[3],C_fix(255),((C_word*)t0)[2]);}

/* lp in k2078 in char-set-fold in k1323 in k1319 in k1203 */
static void C_fcall f_2085(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2085,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2103,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2106,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2114,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t0)[2],t2);}}

/* f_2114 in lp in k2078 in char-set-fold in k1323 in k1319 in k1203 */
static void C_ccall f_2114(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2114,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=f_1213(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t5,C_fix(0)));}

/* k2104 in lp in k2078 in char-set-fold in k1323 in k1319 in k1203 */
static void C_ccall f_2106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2106,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_2103(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2113,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("srfi-14.scm: 330  %latin1->char");
t3=lf[2];
f_1207(3,t3,t2,((C_word*)t0)[2]);}}

/* k2111 in k2104 in lp in k2078 in char-set-fold in k1323 in k1319 in k1203 */
static void C_ccall f_2113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 330  kons");
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2101 in lp in k2078 in char-set-fold in k1323 in k1319 in k1203 */
static void C_ccall f_2103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 328  lp");
t2=((C_word*)((C_word*)t0)[4])[1];
f_2085(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* char-set-map in k1323 in k1319 in k1203 */
static void C_ccall f_1997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1997,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2001,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 314  %char-set:s/check");
f_1294(t4,t3,lf[40]);}

/* k1999 in char-set-map in k1323 in k1319 in k1203 */
static void C_ccall f_2001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2004,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("srfi-14.scm: 315  make-string");
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(256),lf[17]);}

/* k2002 in k1999 in char-set-map in k1323 in k1319 in k1203 */
static void C_ccall f_2004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2007,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t4,a[6]=((C_word)li58),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2012(t6,t2,C_fix(255));}

/* lp in k2002 in k1999 in char-set-map in k1323 in k1319 in k1203 */
static void C_fcall f_2012(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2012,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2022,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2032,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2053,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* f_2053 in lp in k2002 in k1999 in char-set-map in k1323 in k1319 in k1203 */
static void C_ccall f_2053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2053,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2061,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2062,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* f_2062 */
static void C_ccall f_2062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2062,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=f_1213(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t5,C_fix(0)));}

/* k2059 */
static void C_ccall f_2061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k2030 in lp in k2002 in k1999 in char-set-map in k1323 in k1319 in k1203 */
static void C_ccall f_2032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2032,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2048,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2052,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 319  %latin1->char");
t4=lf[2];
f_1207(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_2022(2,t2,C_SCHEME_UNDEFINED);}}

/* k2050 in k2030 in lp in k2002 in k1999 in char-set-map in k1323 in k1319 in k1203 */
static void C_ccall f_2052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 319  proc");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2046 in k2030 in lp in k2002 in k1999 in char-set-map in k1323 in k1319 in k1203 */
static void C_ccall f_2048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2048,2,t0,t1);}
t2=f_1213(t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2040,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* f_2040 in k2046 in k2030 in lp in k2002 in k1999 in char-set-map in k1323 in k1319 in k1203 */
static void C_ccall f_2040(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2040,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[18]));}

/* k2020 in lp in k2002 in k1999 in char-set-map in k1323 in k1319 in k1203 */
static void C_ccall f_2022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
C_trace("srfi-14.scm: 320  lp");
t3=((C_word*)((C_word*)t0)[3])[1];
f_2012(t3,((C_word*)t0)[2],t2);}

/* k2005 in k2002 in k1999 in char-set-map in k1323 in k1319 in k1203 */
static void C_ccall f_2007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 321  make-char-set");
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-for-each in k1323 in k1319 in k1203 */
static void C_ccall f_1937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1937,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1941,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 306  %char-set:s/check");
f_1294(t4,t3,lf[39]);}

/* k1939 in char-set-for-each in k1323 in k1319 in k1203 */
static void C_ccall f_1941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1941,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1946,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word)li53),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1946(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k1939 in char-set-for-each in k1323 in k1319 in k1203 */
static void C_fcall f_1946(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1946,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1956,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1966,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1974,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* f_1974 in lp in k1939 in char-set-for-each in k1323 in k1319 in k1203 */
static void C_ccall f_1974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1974,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1982,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1983,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* f_1983 */
static void C_ccall f_1983(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1983,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=f_1213(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t5,C_fix(0)));}

/* k1980 */
static void C_ccall f_1982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k1964 in lp in k1939 in char-set-for-each in k1323 in k1319 in k1203 */
static void C_ccall f_1966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1966,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1973,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 309  %latin1->char");
t3=lf[2];
f_1207(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1956(2,t2,C_SCHEME_UNDEFINED);}}

/* k1971 in k1964 in lp in k1939 in char-set-for-each in k1323 in k1319 in k1203 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 309  proc");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1954 in lp in k1939 in char-set-for-each in k1323 in k1319 in k1203 */
static void C_ccall f_1956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
C_trace("srfi-14.scm: 310  lp");
t3=((C_word*)((C_word*)t0)[3])[1];
f_1946(t3,((C_word*)t0)[2],t2);}

/* %char-set-cursor-next in k1323 in k1319 in k1203 */
static void C_fcall f_1885(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1885,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1889,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 295  %char-set:s/check");
f_1294(t5,t2,t4);}

/* k1887 in %char-set-cursor-next in k1323 in k1319 in k1203 */
static void C_ccall f_1889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1889,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1894,a[2]=t1,a[3]=t3,a[4]=((C_word)li49),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1894(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k1887 in %char-set-cursor-next in k1323 in k1319 in k1203 */
static void C_fcall f_1894(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1894,NULL,3,t0,t1,t2);}
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
t4=(C_word)C_fixnum_lessp(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1907,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_1907(2,t6,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1914,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* f_1914 in lp in k1887 in %char-set-cursor-next in k1323 in k1319 in k1203 */
static void C_ccall f_1914(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1914,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1922,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1923,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* f_1923 */
static void C_ccall f_1923(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1923,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=f_1213(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t5,C_fix(0)));}

/* k1920 */
static void C_ccall f_1922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k1905 in lp in k1887 in %char-set-cursor-next in k1323 in k1319 in k1203 */
static void C_ccall f_1907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
C_trace("srfi-14.scm: 299  lp");
t2=((C_word*)((C_word*)t0)[2])[1];
f_1894(t2,((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* char-set-cursor-next in k1323 in k1319 in k1203 */
static void C_ccall f_1876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1876,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[38]);
C_trace("srfi-14.scm: 292  %char-set-cursor-next");
f_1885(t1,t2,t3,lf[38]);}

/* char-set-ref in k1323 in k1319 in k1203 */
static void C_ccall f_1870(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1870,4,t0,t1,t2,t3);}
C_trace("srfi-14.scm: 286  %latin1->char");
t4=lf[2];
f_1207(3,t4,t1,t3);}

/* end-of-char-set? in k1323 in k1319 in k1203 */
static void C_ccall f_1864(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1864,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_lessp(t2,C_fix(0)));}

/* char-set-cursor in k1323 in k1319 in k1203 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1858,3,t0,t1,t2);}
C_trace("srfi-14.scm: 282  %char-set-cursor-next");
f_1885(t1,t2,C_fix(256),lf[34]);}

/* char-set-delete! in k1323 in k1319 in k1203 */
static void C_ccall f_1846(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_1846r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1846r(t0,t1,t2,t3);}}

static void C_ccall f_1846r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1852,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 268  %set-char-set!");
f_1791(t1,t4,lf[33],t2,t3);}

/* a1851 in char-set-delete! in k1323 in k1319 in k1203 */
static void C_ccall f_1852(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1852,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[17]));}

/* char-set-delete in k1323 in k1319 in k1203 */
static void C_ccall f_1834(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_1834r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1834r(t0,t1,t2,t3);}}

static void C_ccall f_1834r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1840,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 266  %set-char-set");
f_1765(t1,t4,lf[32],t2,t3);}

/* a1839 in char-set-delete in k1323 in k1319 in k1203 */
static void C_ccall f_1840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1840,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[17]));}

/* char-set-adjoin! in k1323 in k1319 in k1203 */
static void C_ccall f_1822(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_1822r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1822r(t0,t1,t2,t3);}}

static void C_ccall f_1822r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1828,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 264  %set-char-set!");
f_1791(t1,t4,lf[31],t2,t3);}

/* a1827 in char-set-adjoin! in k1323 in k1319 in k1203 */
static void C_ccall f_1828(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1828,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[18]));}

/* char-set-adjoin in k1323 in k1319 in k1203 */
static void C_ccall f_1810(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_1810r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1810r(t0,t1,t2,t3);}}

static void C_ccall f_1810r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1816,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 262  %set-char-set");
f_1765(t1,t4,lf[30],t2,t3);}

/* a1815 in char-set-adjoin in k1323 in k1319 in k1203 */
static void C_ccall f_1816(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1816,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[18]));}

/* %set-char-set! in k1323 in k1319 in k1203 */
static void C_fcall f_1791(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1791,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1795,a[2]=t5,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("srfi-14.scm: 256  %char-set:s/check");
f_1294(t6,t4,t3);}

/* k1793 in %set-char-set! in k1323 in k1319 in k1203 */
static void C_ccall f_1795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1798,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1800,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li33),tmp=(C_word)a,a+=5,tmp);
C_trace("for-each");
t4=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a1799 in k1793 in %set-char-set! in k1323 in k1319 in k1203 */
static void C_ccall f_1800(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1800,3,t0,t1,t2);}
t3=f_1213(t2);
C_trace("srfi-14.scm: 257  set");
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,((C_word*)t0)[2],t3);}

/* k1796 in k1793 in %set-char-set! in k1323 in k1319 in k1203 */
static void C_ccall f_1798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* %set-char-set in k1323 in k1319 in k1203 */
static void C_fcall f_1765(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1765,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1769,a[2]=t5,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1789,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 250  %char-set:s/check");
f_1294(t7,t4,t3);}

/* k1787 in %set-char-set in k1323 in k1319 in k1203 */
static void C_ccall f_1789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 250  %string-copy");
f_1237(((C_word*)t0)[2],t1);}

/* k1767 in %set-char-set in k1323 in k1319 in k1203 */
static void C_ccall f_1769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1772,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1777,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li31),tmp=(C_word)a,a+=5,tmp);
C_trace("for-each");
t4=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a1776 in k1767 in %set-char-set in k1323 in k1319 in k1203 */
static void C_ccall f_1777(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1777,3,t0,t1,t2);}
t3=f_1213(t2);
C_trace("srfi-14.scm: 251  set");
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,((C_word*)t0)[2],t3);}

/* k1770 in k1767 in %set-char-set in k1323 in k1319 in k1203 */
static void C_ccall f_1772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 253  make-char-set");
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-count in k1323 in k1319 in k1203 */
static void C_ccall f_1698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1698,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1702,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 238  %char-set:s/check");
f_1294(t4,t3,lf[26]);}

/* k1700 in char-set-count in k1323 in k1319 in k1203 */
static void C_ccall f_1702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1702,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1707,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word)li29),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1707(t5,((C_word*)t0)[2],C_fix(255),C_fix(0));}

/* lp in k1700 in char-set-count in k1323 in k1319 in k1203 */
static void C_fcall f_1707(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1707,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1728,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1734,a[2]=t2,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1742,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t0)[2],t2);}}

/* f_1742 in lp in k1700 in char-set-count in k1323 in k1319 in k1203 */
static void C_ccall f_1742(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1742,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1750,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1751,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* f_1751 */
static void C_ccall f_1751(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1751,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=f_1213(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t5,C_fix(0)));}

/* k1748 */
static void C_ccall f_1750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k1732 in lp in k1700 in char-set-count in k1323 in k1319 in k1203 */
static void C_ccall f_1734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1734,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1741,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 242  %latin1->char");
t3=lf[2];
f_1207(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1728(2,t2,C_SCHEME_FALSE);}}

/* k1739 in k1732 in lp in k1700 in char-set-count in k1323 in k1319 in k1203 */
static void C_ccall f_1741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 242  pred");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1726 in lp in k1700 in char-set-count in k1323 in k1319 in k1203 */
static void C_ccall f_1728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1)):((C_word*)t0)[5]);
C_trace("srfi-14.scm: 241  lp");
t3=((C_word*)((C_word*)t0)[4])[1];
f_1707(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* char-set-size in k1323 in k1319 in k1203 */
static void C_ccall f_1656(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1656,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1660,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 231  %char-set:s/check");
f_1294(t3,t2,lf[25]);}

/* k1658 in char-set-size in k1323 in k1319 in k1203 */
static void C_ccall f_1660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1660,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1665,a[2]=t1,a[3]=t3,a[4]=((C_word)li25),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1665(t5,((C_word*)t0)[2],C_fix(255),C_fix(0));}

/* lp in k1658 in char-set-size in k1323 in k1319 in k1203 */
static void C_fcall f_1665(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1665,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1687,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1688,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],t2);}}

/* f_1688 in lp in k1658 in char-set-size in k1323 in k1319 in k1203 */
static void C_ccall f_1688(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1688,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
C_trace("srfi-14.scm: 150  %char->latin1");
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_1213(t4));}

/* k1685 in lp in k1658 in char-set-size in k1323 in k1319 in k1203 */
static void C_ccall f_1687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],t1);
C_trace("srfi-14.scm: 234  lp");
t3=((C_word*)((C_word*)t0)[4])[1];
f_1665(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* char-set-contains? in k1323 in k1319 in k1203 */
static void C_ccall f_1617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1617,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_char_2(t3,lf[24]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1628,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 226  %char-set:s/check");
f_1294(t5,t2,lf[24]);}

/* k1626 in char-set-contains? in k1323 in k1319 in k1203 */
static void C_ccall f_1628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1628,2,t0,t1);}
t2=f_1213(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1633,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* f_1633 in k1626 in char-set-contains? in k1323 in k1319 in k1203 */
static void C_ccall f_1633(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1633,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1641,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1642,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* f_1642 */
static void C_ccall f_1642(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1642,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=f_1213(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t5,C_fix(0)));}

/* k1639 */
static void C_ccall f_1641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* char-set-hash in k1323 in k1319 in k1203 */
static void C_ccall f_1504(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1504r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1504r(t0,t1,t2,t3);}}

static void C_ccall f_1504r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1508,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_1508(2,t5,C_fix(4194304));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_1508(2,t6,(C_word)C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[1],t3);}}}

/* k1506 in char-set-hash in k1323 in k1319 in k1203 */
static void C_ccall f_1508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1508,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1511,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(((C_word*)t3)[1],C_fix(0));
if(C_truep(t5)){
t6=C_set_block_item(t3,0,C_fix(4194304));
t7=t4;
f_1511(t7,t6);}
else{
t6=t4;
f_1511(t6,C_SCHEME_UNDEFINED);}}

/* k1509 in k1506 in char-set-hash in k1323 in k1319 in k1203 */
static void C_fcall f_1511(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1511,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[4])[1],lf[22]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1517,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 213  %char-set:s/check");
f_1294(t3,((C_word*)t0)[2],lf[22]);}

/* k1515 in k1509 in k1506 in char-set-hash in k1323 in k1319 in k1203 */
static void C_ccall f_1517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1575,a[2]=((C_word*)t0)[3],a[3]=((C_word)li17),tmp=(C_word)a,a+=4,tmp);
t3=f_1575(t2,C_fix(65536));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1525,a[2]=t1,a[3]=t3,a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word)li19),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_1525(t7,((C_word*)t0)[2],C_fix(255),C_fix(0));}

/* lp in k1515 in k1509 in k1506 in char-set-hash in k1323 in k1319 in k1203 */
static void C_fcall f_1525(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1525,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
C_trace("srfi-14.scm: 218  modulo");
t5=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,((C_word*)((C_word*)t0)[5])[1]);}
else{
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1546,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1549,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1561,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t0)[2],t2);}}

/* f_1561 in lp in k1515 in k1509 in k1506 in char-set-hash in k1323 in k1319 in k1203 */
static void C_ccall f_1561(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1561,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
t5=f_1213(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t5,C_fix(0)));}

/* k1547 in lp in k1515 in k1509 in k1506 in char-set-hash in k1323 in k1319 in k1203 */
static void C_ccall f_1549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_1546(t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_fixnum_times(C_fix(37),((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(t2,((C_word*)t0)[3]);
t4=((C_word*)t0)[5];
f_1546(t4,(C_word)C_fixnum_and(((C_word*)t0)[2],t3));}}

/* k1544 in lp in k1515 in k1509 in k1506 in char-set-hash in k1323 in k1319 in k1203 */
static void C_fcall f_1546(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 219  lp");
t2=((C_word*)((C_word*)t0)[4])[1];
f_1525(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* lp in k1515 in k1509 in k1506 in char-set-hash in k1323 in k1319 in k1203 */
static C_word C_fcall f_1575(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=t1;
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,t3))){
return((C_word)C_fixnum_difference(t1,C_fix(1)));}
else{
t4=(C_word)C_fixnum_plus(t1,t1);
t6=t4;
t1=t6;
goto loop;}}

/* char-set<= in k1323 in k1319 in k1203 */
static void C_ccall f_1396(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1396r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1396r(t0,t1,t2);}}

static void C_ccall f_1396r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1416,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 186  %char-set:s/check");
f_1294(t6,t4,lf[21]);}}

/* k1414 in char-set<= in k1323 in k1319 in k1203 */
static void C_ccall f_1416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1416,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1418,a[2]=t3,a[3]=((C_word)li15),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_1418(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* lp in k1414 in char-set<= in k1323 in k1319 in k1203 */
static void C_fcall f_1418(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1418,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(t3);
t5=(C_word)C_i_not(t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1428,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t3);
C_trace("srfi-14.scm: 188  %char-set:s/check");
f_1294(t6,t7,lf[21]);}}

/* k1426 in lp in k1414 in char-set<= in k1323 in k1319 in k1203 */
static void C_ccall f_1428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1428,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t3)){
C_trace("srfi-14.scm: 190  lp");
t4=((C_word*)((C_word*)t0)[3])[1];
f_1418(t4,((C_word*)t0)[2],t1,t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1445,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=((C_word)li14),tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_1445(t7,((C_word*)t0)[2],C_fix(255));}}

/* lp2 in k1426 in lp in k1414 in char-set<= in k1323 in k1319 in k1203 */
static void C_fcall f_1445(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1445,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
C_trace("srfi-14.scm: 192  lp");
t4=((C_word*)((C_word*)t0)[6])[1];
f_1418(t4,t1,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1472,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1486,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],t2);}}

/* f_1486 in lp2 in k1426 in lp in k1414 in char-set<= in k1323 in k1319 in k1203 */
static void C_ccall f_1486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1486,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
C_trace("srfi-14.scm: 150  %char->latin1");
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_1213(t4));}

/* k1470 in lp2 in k1426 in lp in k1414 in char-set<= in k1323 in k1319 in k1203 */
static void C_ccall f_1472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1472,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1476,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1477,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* f_1477 in k1470 in lp2 in k1426 in lp in k1414 in char-set<= in k1323 in k1319 in k1203 */
static void C_ccall f_1477(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1477,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
C_trace("srfi-14.scm: 150  %char->latin1");
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_1213(t4));}

/* k1474 in k1470 in lp2 in k1426 in lp in k1414 in char-set<= in k1323 in k1319 in k1203 */
static void C_ccall f_1476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t1))){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
C_trace("srfi-14.scm: 194  lp2");
t4=((C_word*)((C_word*)t0)[3])[1];
f_1445(t4,((C_word*)t0)[2],t3);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* char-set= in k1323 in k1319 in k1203 */
static void C_ccall f_1341(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1341r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1341r(t0,t1,t2);}}

static void C_ccall f_1341r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1357,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 175  %char-set:s/check");
f_1294(t6,t4,lf[20]);}}

/* k1355 in char-set= in k1323 in k1319 in k1203 */
static void C_ccall f_1357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1357,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1362,a[2]=t3,a[3]=t1,a[4]=((C_word)li10),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1362(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k1355 in char-set= in k1323 in k1319 in k1203 */
static void C_fcall f_1362(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1362,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_word)C_i_not(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1386,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t2);
C_trace("srfi-14.scm: 178  %char-set:s/check");
f_1294(t5,t6,lf[20]);}}

/* k1384 in lp in k1355 in char-set= in k1323 in k1319 in k1203 */
static void C_ccall f_1386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_string_equal_p(((C_word*)t0)[5],t1))){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("srfi-14.scm: 179  lp");
t3=((C_word*)((C_word*)t0)[3])[1];
f_1362(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* char-set-copy in k1323 in k1319 in k1203 */
static void C_ccall f_1327(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1327,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1335,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1339,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 168  %char-set:s/check");
f_1294(t4,t2,lf[19]);}

/* k1337 in char-set-copy in k1323 in k1319 in k1203 */
static void C_ccall f_1339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 168  %string-copy");
f_1237(((C_word*)t0)[2],t1);}

/* k1333 in char-set-copy in k1323 in k1319 in k1203 */
static void C_ccall f_1335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 168  make-char-set");
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* %char-set:s/check in k1203 */
static void C_fcall f_1294(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1294,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1300,a[2]=t3,a[3]=t5,a[4]=((C_word)li7),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1300(t7,t1,t2);}

/* lp in %char-set:s/check in k1203 */
static void C_fcall f_1300(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1300,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1307,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("srfi-14.scm: 139  char-set?");
t4=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k1305 in lp in %char-set:s/check in k1203 */
static void C_ccall f_1307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1307,2,t0,t1);}
if(C_truep(t1)){
C_trace("srfi-14.scm: 139  char-set:s");
t2=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1317,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-14.scm: 140  ##sys#error");
t3=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],lf[16],((C_word*)t0)[4]);}}

/* k1315 in k1305 in lp in %char-set:s/check in k1203 */
static void C_ccall f_1317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 140  lp");
t2=((C_word*)((C_word*)t0)[3])[1];
f_1300(t2,((C_word*)t0)[2],t1);}

/* %default-base in k1203 */
static void C_fcall f_1247(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1247,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1272,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("srfi-14.scm: 127  char-set?");
t7=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}
else{
C_trace("srfi-14.scm: 129  ##sys#error");
t6=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,lf[13],t3,t2);}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1292,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 131  %latin1->char");
t5=lf[2];
f_1207(3,t5,t4,C_fix(0));}}

/* k1290 in %default-base in k1203 */
static void C_ccall f_1292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 131  make-string");
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_fix(256),t1);}

/* k1270 in %default-base in k1203 */
static void C_ccall f_1272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1272,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1279,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-14.scm: 127  char-set:s");
t3=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
C_trace("srfi-14.scm: 128  ##sys#error");
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[12],((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k1277 in k1270 in %default-base in k1203 */
static void C_ccall f_1279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-14.scm: 127  %string-copy");
f_1237(((C_word*)t0)[2],t1);}

/* %string-copy in k1203 */
static void C_fcall f_1237(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1237,NULL,2,t1,t2);}
t3=(C_word)C_i_string_length(t2);
C_trace("srfi-14.scm: 115  substring");
t4=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,t2,C_fix(0),t3);}

/* char-set? in k1203 */
static void C_ccall f_1231(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1231,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[5]));}

/* char-set:s in k1203 */
static void C_ccall f_1225(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1225,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* make-char-set in k1203 */
static void C_ccall f_1219(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1219,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,2,lf[5],t2));}

/* %char->latin1 in k1203 */
static C_word C_fcall f_1213(C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)C_fix((C_word)C_character_code(t1)));}

/* %latin1->char in k1203 */
static void C_ccall f_1207(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1207,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_make_character((C_word)C_unfix(t2)));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[357] = {
{"toplevelsrfi-14.scm",(void*)C_srfi_14_toplevel},
{"f_1205srfi-14.scm",(void*)f_1205},
{"f_1321srfi-14.scm",(void*)f_1321},
{"f_1325srfi-14.scm",(void*)f_1325},
{"f_3477srfi-14.scm",(void*)f_3477},
{"f_3481srfi-14.scm",(void*)f_3481},
{"f_3485srfi-14.scm",(void*)f_3485},
{"f_3488srfi-14.scm",(void*)f_3488},
{"f_3491srfi-14.scm",(void*)f_3491},
{"f_3593srfi-14.scm",(void*)f_3593},
{"f_3494srfi-14.scm",(void*)f_3494},
{"f_3498srfi-14.scm",(void*)f_3498},
{"f_3589srfi-14.scm",(void*)f_3589},
{"f_3501srfi-14.scm",(void*)f_3501},
{"f_3506srfi-14.scm",(void*)f_3506},
{"f_3581srfi-14.scm",(void*)f_3581},
{"f_3585srfi-14.scm",(void*)f_3585},
{"f_3509srfi-14.scm",(void*)f_3509},
{"f_3513srfi-14.scm",(void*)f_3513},
{"f_3517srfi-14.scm",(void*)f_3517},
{"f_3521srfi-14.scm",(void*)f_3521},
{"f_3525srfi-14.scm",(void*)f_3525},
{"f_3528srfi-14.scm",(void*)f_3528},
{"f_3531srfi-14.scm",(void*)f_3531},
{"f_3535srfi-14.scm",(void*)f_3535},
{"f_3538srfi-14.scm",(void*)f_3538},
{"f_3541srfi-14.scm",(void*)f_3541},
{"f_3545srfi-14.scm",(void*)f_3545},
{"f_3577srfi-14.scm",(void*)f_3577},
{"f_3549srfi-14.scm",(void*)f_3549},
{"f_3553srfi-14.scm",(void*)f_3553},
{"f_3573srfi-14.scm",(void*)f_3573},
{"f_3557srfi-14.scm",(void*)f_3557},
{"f_3569srfi-14.scm",(void*)f_3569},
{"f_3561srfi-14.scm",(void*)f_3561},
{"f_3565srfi-14.scm",(void*)f_3565},
{"f_3448srfi-14.scm",(void*)f_3448},
{"f_3473srfi-14.scm",(void*)f_3473},
{"f_3452srfi-14.scm",(void*)f_3452},
{"f_3455srfi-14.scm",(void*)f_3455},
{"f_3458srfi-14.scm",(void*)f_3458},
{"f_3465srfi-14.scm",(void*)f_3465},
{"f_3469srfi-14.scm",(void*)f_3469},
{"f_3377srfi-14.scm",(void*)f_3377},
{"f_3381srfi-14.scm",(void*)f_3381},
{"f_3384srfi-14.scm",(void*)f_3384},
{"f_3395srfi-14.scm",(void*)f_3395},
{"f_3425srfi-14.scm",(void*)f_3425},
{"f_3434srfi-14.scm",(void*)f_3434},
{"f_3433srfi-14.scm",(void*)f_3433},
{"f_3416srfi-14.scm",(void*)f_3416},
{"f_3420srfi-14.scm",(void*)f_3420},
{"f_3406srfi-14.scm",(void*)f_3406},
{"f_3387srfi-14.scm",(void*)f_3387},
{"f_3390srfi-14.scm",(void*)f_3390},
{"f_3304srfi-14.scm",(void*)f_3304},
{"f_3310srfi-14.scm",(void*)f_3310},
{"f_3375srfi-14.scm",(void*)f_3375},
{"f_3316srfi-14.scm",(void*)f_3316},
{"f_3346srfi-14.scm",(void*)f_3346},
{"f_3355srfi-14.scm",(void*)f_3355},
{"f_3354srfi-14.scm",(void*)f_3354},
{"f_3329srfi-14.scm",(void*)f_3329},
{"f_3341srfi-14.scm",(void*)f_3341},
{"f_3332srfi-14.scm",(void*)f_3332},
{"f_3336srfi-14.scm",(void*)f_3336},
{"f_3229srfi-14.scm",(void*)f_3229},
{"f_3295srfi-14.scm",(void*)f_3295},
{"f_3239srfi-14.scm",(void*)f_3239},
{"f_3251srfi-14.scm",(void*)f_3251},
{"f_3279srfi-14.scm",(void*)f_3279},
{"f_3278srfi-14.scm",(void*)f_3278},
{"f_3266srfi-14.scm",(void*)f_3266},
{"f_3274srfi-14.scm",(void*)f_3274},
{"f_3242srfi-14.scm",(void*)f_3242},
{"f_3177srfi-14.scm",(void*)f_3177},
{"f_3185srfi-14.scm",(void*)f_3185},
{"f_3187srfi-14.scm",(void*)f_3187},
{"f_3215srfi-14.scm",(void*)f_3215},
{"f_3214srfi-14.scm",(void*)f_3214},
{"f_3202srfi-14.scm",(void*)f_3202},
{"f_3210srfi-14.scm",(void*)f_3210},
{"f_3181srfi-14.scm",(void*)f_3181},
{"f_3131srfi-14.scm",(void*)f_3131},
{"f_3172srfi-14.scm",(void*)f_3172},
{"f_3141srfi-14.scm",(void*)f_3141},
{"f_3149srfi-14.scm",(void*)f_3149},
{"f_3160srfi-14.scm",(void*)f_3160},
{"f_3144srfi-14.scm",(void*)f_3144},
{"f_3100srfi-14.scm",(void*)f_3100},
{"f_3108srfi-14.scm",(void*)f_3108},
{"f_3110srfi-14.scm",(void*)f_3110},
{"f_3121srfi-14.scm",(void*)f_3121},
{"f_3104srfi-14.scm",(void*)f_3104},
{"f_3050srfi-14.scm",(void*)f_3050},
{"f_3091srfi-14.scm",(void*)f_3091},
{"f_3060srfi-14.scm",(void*)f_3060},
{"f_3072srfi-14.scm",(void*)f_3072},
{"f_3083srfi-14.scm",(void*)f_3083},
{"f_3063srfi-14.scm",(void*)f_3063},
{"f_3023srfi-14.scm",(void*)f_3023},
{"f_3031srfi-14.scm",(void*)f_3031},
{"f_3033srfi-14.scm",(void*)f_3033},
{"f_3044srfi-14.scm",(void*)f_3044},
{"f_3027srfi-14.scm",(void*)f_3027},
{"f_2969srfi-14.scm",(void*)f_2969},
{"f_3014srfi-14.scm",(void*)f_3014},
{"f_2979srfi-14.scm",(void*)f_2979},
{"f_2991srfi-14.scm",(void*)f_2991},
{"f_3002srfi-14.scm",(void*)f_3002},
{"f_2982srfi-14.scm",(void*)f_2982},
{"f_2938srfi-14.scm",(void*)f_2938},
{"f_2946srfi-14.scm",(void*)f_2946},
{"f_2948srfi-14.scm",(void*)f_2948},
{"f_2959srfi-14.scm",(void*)f_2959},
{"f_2942srfi-14.scm",(void*)f_2942},
{"f_2905srfi-14.scm",(void*)f_2905},
{"f_2909srfi-14.scm",(void*)f_2909},
{"f_2914srfi-14.scm",(void*)f_2914},
{"f_2919srfi-14.scm",(void*)f_2919},
{"f_2928srfi-14.scm",(void*)f_2928},
{"f_2936srfi-14.scm",(void*)f_2936},
{"f_2912srfi-14.scm",(void*)f_2912},
{"f_2866srfi-14.scm",(void*)f_2866},
{"f_2870srfi-14.scm",(void*)f_2870},
{"f_2873srfi-14.scm",(void*)f_2873},
{"f_2881srfi-14.scm",(void*)f_2881},
{"f_2886srfi-14.scm",(void*)f_2886},
{"f_2895srfi-14.scm",(void*)f_2895},
{"f_2903srfi-14.scm",(void*)f_2903},
{"f_2876srfi-14.scm",(void*)f_2876},
{"f_2819srfi-14.scm",(void*)f_2819},
{"f_2825srfi-14.scm",(void*)f_2825},
{"f_2829srfi-14.scm",(void*)f_2829},
{"f_2834srfi-14.scm",(void*)f_2834},
{"f_2856srfi-14.scm",(void*)f_2856},
{"f_2855srfi-14.scm",(void*)f_2855},
{"f_2844srfi-14.scm",(void*)f_2844},
{"f_2778srfi-14.scm",(void*)f_2778},
{"f_2788srfi-14.scm",(void*)f_2788},
{"f_2798srfi-14.scm",(void*)f_2798},
{"f_2748srfi-14.scm",(void*)f_2748},
{"f_2755srfi-14.scm",(void*)f_2755},
{"f_2734srfi-14.scm",(void*)f_2734},
{"f_2742srfi-14.scm",(void*)f_2742},
{"f_2746srfi-14.scm",(void*)f_2746},
{"f_2738srfi-14.scm",(void*)f_2738},
{"f_2718srfi-14.scm",(void*)f_2718},
{"f_2722srfi-14.scm",(void*)f_2722},
{"f_2732srfi-14.scm",(void*)f_2732},
{"f_2725srfi-14.scm",(void*)f_2725},
{"f_2650srfi-14.scm",(void*)f_2650},
{"f_2656srfi-14.scm",(void*)f_2656},
{"f_2695srfi-14.scm",(void*)f_2695},
{"f_2704srfi-14.scm",(void*)f_2704},
{"f_2703srfi-14.scm",(void*)f_2703},
{"f_2687srfi-14.scm",(void*)f_2687},
{"f_2694srfi-14.scm",(void*)f_2694},
{"f_2676srfi-14.scm",(void*)f_2676},
{"f_2680srfi-14.scm",(void*)f_2680},
{"f_2666srfi-14.scm",(void*)f_2666},
{"f_2640srfi-14.scm",(void*)f_2640},
{"f_2648srfi-14.scm",(void*)f_2648},
{"f_2644srfi-14.scm",(void*)f_2644},
{"f_2610srfi-14.scm",(void*)f_2610},
{"f_2620srfi-14.scm",(void*)f_2620},
{"f_2623srfi-14.scm",(void*)f_2623},
{"f_2548srfi-14.scm",(void*)f_2548},
{"f_2596srfi-14.scm",(void*)f_2596},
{"f_2558srfi-14.scm",(void*)f_2558},
{"f_2593srfi-14.scm",(void*)f_2593},
{"f_2567srfi-14.scm",(void*)f_2567},
{"f_2585srfi-14.scm",(void*)f_2585},
{"f_2577srfi-14.scm",(void*)f_2577},
{"f_2487srfi-14.scm",(void*)f_2487},
{"f_2491srfi-14.scm",(void*)f_2491},
{"f_2546srfi-14.scm",(void*)f_2546},
{"f_2494srfi-14.scm",(void*)f_2494},
{"f_2499srfi-14.scm",(void*)f_2499},
{"f_2530srfi-14.scm",(void*)f_2530},
{"f_2519srfi-14.scm",(void*)f_2519},
{"f_2529srfi-14.scm",(void*)f_2529},
{"f_2509srfi-14.scm",(void*)f_2509},
{"f_2477srfi-14.scm",(void*)f_2477},
{"f_2485srfi-14.scm",(void*)f_2485},
{"f_2481srfi-14.scm",(void*)f_2481},
{"f_2465srfi-14.scm",(void*)f_2465},
{"f_2469srfi-14.scm",(void*)f_2469},
{"f_2472srfi-14.scm",(void*)f_2472},
{"f_2416srfi-14.scm",(void*)f_2416},
{"f_2429srfi-14.scm",(void*)f_2429},
{"f_2451srfi-14.scm",(void*)f_2451},
{"f_2439srfi-14.scm",(void*)f_2439},
{"f_2364srfi-14.scm",(void*)f_2364},
{"f_2368srfi-14.scm",(void*)f_2368},
{"f_2373srfi-14.scm",(void*)f_2373},
{"f_2402srfi-14.scm",(void*)f_2402},
{"f_2394srfi-14.scm",(void*)f_2394},
{"f_2401srfi-14.scm",(void*)f_2401},
{"f_2391srfi-14.scm",(void*)f_2391},
{"f_2354srfi-14.scm",(void*)f_2354},
{"f_2362srfi-14.scm",(void*)f_2362},
{"f_2358srfi-14.scm",(void*)f_2358},
{"f_2342srfi-14.scm",(void*)f_2342},
{"f_2346srfi-14.scm",(void*)f_2346},
{"f_2349srfi-14.scm",(void*)f_2349},
{"f_2330srfi-14.scm",(void*)f_2330},
{"f_2334srfi-14.scm",(void*)f_2334},
{"f_2337srfi-14.scm",(void*)f_2337},
{"f_2309srfi-14.scm",(void*)f_2309},
{"f_2315srfi-14.scm",(void*)f_2315},
{"f_2324srfi-14.scm",(void*)f_2324},
{"f_2299srfi-14.scm",(void*)f_2299},
{"f_2307srfi-14.scm",(void*)f_2307},
{"f_2303srfi-14.scm",(void*)f_2303},
{"f_2287srfi-14.scm",(void*)f_2287},
{"f_2291srfi-14.scm",(void*)f_2291},
{"f_2294srfi-14.scm",(void*)f_2294},
{"f_2245srfi-14.scm",(void*)f_2245},
{"f_2251srfi-14.scm",(void*)f_2251},
{"f_2285srfi-14.scm",(void*)f_2285},
{"f_2281srfi-14.scm",(void*)f_2281},
{"f_2273srfi-14.scm",(void*)f_2273},
{"f_2261srfi-14.scm",(void*)f_2261},
{"f_2268srfi-14.scm",(void*)f_2268},
{"f_2182srfi-14.scm",(void*)f_2182},
{"f_2186srfi-14.scm",(void*)f_2186},
{"f_2191srfi-14.scm",(void*)f_2191},
{"f_2222srfi-14.scm",(void*)f_2222},
{"f_2231srfi-14.scm",(void*)f_2231},
{"f_2230srfi-14.scm",(void*)f_2230},
{"f_2214srfi-14.scm",(void*)f_2214},
{"f_2221srfi-14.scm",(void*)f_2221},
{"f_2201srfi-14.scm",(void*)f_2201},
{"f_2128srfi-14.scm",(void*)f_2128},
{"f_2132srfi-14.scm",(void*)f_2132},
{"f_2137srfi-14.scm",(void*)f_2137},
{"f_2168srfi-14.scm",(void*)f_2168},
{"f_2150srfi-14.scm",(void*)f_2150},
{"f_2167srfi-14.scm",(void*)f_2167},
{"f_2153srfi-14.scm",(void*)f_2153},
{"f_2076srfi-14.scm",(void*)f_2076},
{"f_2080srfi-14.scm",(void*)f_2080},
{"f_2085srfi-14.scm",(void*)f_2085},
{"f_2114srfi-14.scm",(void*)f_2114},
{"f_2106srfi-14.scm",(void*)f_2106},
{"f_2113srfi-14.scm",(void*)f_2113},
{"f_2103srfi-14.scm",(void*)f_2103},
{"f_1997srfi-14.scm",(void*)f_1997},
{"f_2001srfi-14.scm",(void*)f_2001},
{"f_2004srfi-14.scm",(void*)f_2004},
{"f_2012srfi-14.scm",(void*)f_2012},
{"f_2053srfi-14.scm",(void*)f_2053},
{"f_2062srfi-14.scm",(void*)f_2062},
{"f_2061srfi-14.scm",(void*)f_2061},
{"f_2032srfi-14.scm",(void*)f_2032},
{"f_2052srfi-14.scm",(void*)f_2052},
{"f_2048srfi-14.scm",(void*)f_2048},
{"f_2040srfi-14.scm",(void*)f_2040},
{"f_2022srfi-14.scm",(void*)f_2022},
{"f_2007srfi-14.scm",(void*)f_2007},
{"f_1937srfi-14.scm",(void*)f_1937},
{"f_1941srfi-14.scm",(void*)f_1941},
{"f_1946srfi-14.scm",(void*)f_1946},
{"f_1974srfi-14.scm",(void*)f_1974},
{"f_1983srfi-14.scm",(void*)f_1983},
{"f_1982srfi-14.scm",(void*)f_1982},
{"f_1966srfi-14.scm",(void*)f_1966},
{"f_1973srfi-14.scm",(void*)f_1973},
{"f_1956srfi-14.scm",(void*)f_1956},
{"f_1885srfi-14.scm",(void*)f_1885},
{"f_1889srfi-14.scm",(void*)f_1889},
{"f_1894srfi-14.scm",(void*)f_1894},
{"f_1914srfi-14.scm",(void*)f_1914},
{"f_1923srfi-14.scm",(void*)f_1923},
{"f_1922srfi-14.scm",(void*)f_1922},
{"f_1907srfi-14.scm",(void*)f_1907},
{"f_1876srfi-14.scm",(void*)f_1876},
{"f_1870srfi-14.scm",(void*)f_1870},
{"f_1864srfi-14.scm",(void*)f_1864},
{"f_1858srfi-14.scm",(void*)f_1858},
{"f_1846srfi-14.scm",(void*)f_1846},
{"f_1852srfi-14.scm",(void*)f_1852},
{"f_1834srfi-14.scm",(void*)f_1834},
{"f_1840srfi-14.scm",(void*)f_1840},
{"f_1822srfi-14.scm",(void*)f_1822},
{"f_1828srfi-14.scm",(void*)f_1828},
{"f_1810srfi-14.scm",(void*)f_1810},
{"f_1816srfi-14.scm",(void*)f_1816},
{"f_1791srfi-14.scm",(void*)f_1791},
{"f_1795srfi-14.scm",(void*)f_1795},
{"f_1800srfi-14.scm",(void*)f_1800},
{"f_1798srfi-14.scm",(void*)f_1798},
{"f_1765srfi-14.scm",(void*)f_1765},
{"f_1789srfi-14.scm",(void*)f_1789},
{"f_1769srfi-14.scm",(void*)f_1769},
{"f_1777srfi-14.scm",(void*)f_1777},
{"f_1772srfi-14.scm",(void*)f_1772},
{"f_1698srfi-14.scm",(void*)f_1698},
{"f_1702srfi-14.scm",(void*)f_1702},
{"f_1707srfi-14.scm",(void*)f_1707},
{"f_1742srfi-14.scm",(void*)f_1742},
{"f_1751srfi-14.scm",(void*)f_1751},
{"f_1750srfi-14.scm",(void*)f_1750},
{"f_1734srfi-14.scm",(void*)f_1734},
{"f_1741srfi-14.scm",(void*)f_1741},
{"f_1728srfi-14.scm",(void*)f_1728},
{"f_1656srfi-14.scm",(void*)f_1656},
{"f_1660srfi-14.scm",(void*)f_1660},
{"f_1665srfi-14.scm",(void*)f_1665},
{"f_1688srfi-14.scm",(void*)f_1688},
{"f_1687srfi-14.scm",(void*)f_1687},
{"f_1617srfi-14.scm",(void*)f_1617},
{"f_1628srfi-14.scm",(void*)f_1628},
{"f_1633srfi-14.scm",(void*)f_1633},
{"f_1642srfi-14.scm",(void*)f_1642},
{"f_1641srfi-14.scm",(void*)f_1641},
{"f_1504srfi-14.scm",(void*)f_1504},
{"f_1508srfi-14.scm",(void*)f_1508},
{"f_1511srfi-14.scm",(void*)f_1511},
{"f_1517srfi-14.scm",(void*)f_1517},
{"f_1525srfi-14.scm",(void*)f_1525},
{"f_1561srfi-14.scm",(void*)f_1561},
{"f_1549srfi-14.scm",(void*)f_1549},
{"f_1546srfi-14.scm",(void*)f_1546},
{"f_1575srfi-14.scm",(void*)f_1575},
{"f_1396srfi-14.scm",(void*)f_1396},
{"f_1416srfi-14.scm",(void*)f_1416},
{"f_1418srfi-14.scm",(void*)f_1418},
{"f_1428srfi-14.scm",(void*)f_1428},
{"f_1445srfi-14.scm",(void*)f_1445},
{"f_1486srfi-14.scm",(void*)f_1486},
{"f_1472srfi-14.scm",(void*)f_1472},
{"f_1477srfi-14.scm",(void*)f_1477},
{"f_1476srfi-14.scm",(void*)f_1476},
{"f_1341srfi-14.scm",(void*)f_1341},
{"f_1357srfi-14.scm",(void*)f_1357},
{"f_1362srfi-14.scm",(void*)f_1362},
{"f_1386srfi-14.scm",(void*)f_1386},
{"f_1327srfi-14.scm",(void*)f_1327},
{"f_1339srfi-14.scm",(void*)f_1339},
{"f_1335srfi-14.scm",(void*)f_1335},
{"f_1294srfi-14.scm",(void*)f_1294},
{"f_1300srfi-14.scm",(void*)f_1300},
{"f_1307srfi-14.scm",(void*)f_1307},
{"f_1317srfi-14.scm",(void*)f_1317},
{"f_1247srfi-14.scm",(void*)f_1247},
{"f_1292srfi-14.scm",(void*)f_1292},
{"f_1272srfi-14.scm",(void*)f_1272},
{"f_1279srfi-14.scm",(void*)f_1279},
{"f_1237srfi-14.scm",(void*)f_1237},
{"f_1231srfi-14.scm",(void*)f_1231},
{"f_1225srfi-14.scm",(void*)f_1225},
{"f_1219srfi-14.scm",(void*)f_1219},
{"f_1213srfi-14.scm",(void*)f_1213},
{"f_1207srfi-14.scm",(void*)f_1207},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
