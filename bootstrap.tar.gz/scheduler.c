/* Generated from scheduler.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-08-25 23:16
   Version 4.0.0x - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11761	compiled 2008-08-25 on tesseract.thetesseract.org (Linux)
   command line: scheduler.scm -optimize-level 2 -include-path . -include-path . -explicit-use -output-file scheduler.c
   unit: scheduler
*/

#include "chicken.h"

#ifdef HAVE_ERRNO_H
# include <errno.h>
# define C_signal_interrupted_p     C_mk_bool(errno == EINTR)
#else
# define C_signal_interrupted_p     C_SCHEME_FALSE
#endif

#ifdef _WIN32
# if _MSC_VER > 1300
# include <winsock2.h>
# include <ws2tcpip.h>
# else
# include <winsock.h>
# endif
/* Beware: winsock2.h must come BEFORE windows.h */
# define C_msleep(n)     (Sleep(C_unfix(n)), C_SCHEME_TRUE)
#else
# include <unistd.h>
# include <sys/types.h>
# include <sys/time.h>
# include <time.h>
static C_word C_msleep(C_word ms);
C_word C_msleep(C_word ms) {
#ifdef __CYGWIN__
  if(usleep(C_unfix(ms) * 1000) == -1) return C_SCHEME_FALSE;
#else
  struct timespec ts;
  unsigned long mss = C_unfix(ms);
  ts.tv_sec = mss / 1000;
  ts.tv_nsec = (mss % 1000) * 1000000;
  
  if(nanosleep(&ts, NULL) == -1) return C_SCHEME_FALSE;
#endif
  return C_SCHEME_TRUE;
}
#endif
static fd_set C_fdset_input, C_fdset_output, C_fdset_input_2, C_fdset_output_2;
#define C_fd_test_input(fd)  C_mk_bool(FD_ISSET(C_unfix(fd), &C_fdset_input))
#define C_fd_test_output(fd)  C_mk_bool(FD_ISSET(C_unfix(fd), &C_fdset_output))

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[77];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,7),40,108,111,111,112,50,41,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,50,32,116,104,114,101,97,100,115,52,56,52,41,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,110,52,53,53,32,108,115,116,52,53,54,41,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,53,49,55,41,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,49,49,48,41,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,7),40,108,111,111,112,49,41,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,16),40,35,35,115,121,115,35,115,99,104,101,100,117,108,101,41};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,24),40,35,35,115,121,115,35,102,111,114,99,101,45,112,114,105,109,111,114,100,105,97,108,41};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,19),40,35,35,115,121,115,35,114,101,97,100,121,45,113,117,101,117,101,41,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,36),40,35,35,115,121,115,35,97,100,100,45,116,111,45,114,101,97,100,121,45,113,117,101,117,101,32,116,104,114,101,97,100,49,55,54,41,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,7),40,97,49,48,51,48,41,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,41),40,35,35,115,121,115,35,105,110,116,101,114,114,117,112,116,45,104,111,111,107,32,114,101,97,115,111,110,50,50,55,32,115,116,97,116,101,50,50,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,116,108,50,52,55,32,112,114,101,118,50,52,56,41,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,44),40,35,35,115,121,115,35,116,104,114,101,97,100,45,98,108,111,99,107,45,102,111,114,45,116,105,109,101,111,117,116,33,32,116,50,52,48,32,116,109,50,52,49,41,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,48),40,35,35,115,121,115,35,116,104,114,101,97,100,45,98,108,111,99,107,45,102,111,114,45,116,101,114,109,105,110,97,116,105,111,110,33,32,116,50,54,51,32,116,50,50,54,52,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,13),40,97,49,49,55,49,32,116,50,50,56,56,41,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,30),40,35,35,115,121,115,35,116,104,114,101,97,100,45,107,105,108,108,33,32,116,50,56,49,32,115,50,56,50,41,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,116,104,114,101,97,100,45,98,97,115,105,99,45,117,110,98,108,111,99,107,33,32,116,51,48,48,41,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,7),40,97,49,50,50,51,41,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,40),40,35,35,115,121,115,35,100,101,102,97,117,108,116,45,101,120,99,101,112,116,105,111,110,45,104,97,110,100,108,101,114,32,97,114,103,51,49,49,41};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,23),40,35,35,115,121,115,35,102,100,115,101,116,45,105,110,112,117,116,45,115,101,116,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,24),40,35,35,115,121,115,35,102,100,115,101,116,45,111,117,116,112,117,116,45,115,101,116,41};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,19),40,35,35,115,121,115,35,102,100,115,101,116,45,99,108,101,97,114,41,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,51,56,56,41,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,47),40,35,35,115,121,115,35,116,104,114,101,97,100,45,98,108,111,99,107,45,102,111,114,45,105,47,111,33,32,116,51,56,48,32,102,100,51,56,49,32,105,47,111,51,56,50,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,19),40,35,35,115,121,115,35,97,108,108,45,116,104,114,101,97,100,115,41,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,102,101,116,99,104,45,97,110,100,45,99,108,101,97,114,45,116,104,114,101,97,100,115,41,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,30),40,35,35,115,121,115,35,114,101,115,116,111,114,101,45,116,104,114,101,97,100,115,32,118,101,99,53,53,51,41,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,102,100,108,53,54,56,41,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,28),40,35,35,115,121,115,35,116,104,114,101,97,100,45,117,110,98,108,111,99,107,33,32,116,53,54,48,41,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,7),40,97,49,56,49,49,41,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,7),40,97,49,56,48,50,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,14),40,97,49,56,51,53,32,46,32,95,53,57,52,41,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,12),40,97,49,55,54,53,32,107,53,57,48,41,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,98,114,101,97,107,45,101,110,116,114,121,32,110,97,109,101,53,55,57,32,97,114,103,115,53,56,48,41,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,7),40,97,49,56,57,50,41,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,27),40,35,35,115,121,115,35,98,114,101,97,107,45,114,101,115,117,109,101,32,101,120,110,54,49,57,41,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,8),40,102,95,49,57,48,52,41};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from ##sys#fdset-clear in k1264 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub374(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub374(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
FD_CLR(fd, &C_fdset_input_2);FD_CLR(fd, &C_fdset_output_2);
C_ret:
#undef return

return C_r;}

/* from ##sys#fdset-output-set in k1264 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub368(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub368(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
FD_SET(fd, &C_fdset_output);
C_ret:
#undef return

return C_r;}

/* from ##sys#fdset-input-set in k1264 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub362(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub362(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
FD_SET(fd, &C_fdset_input);
C_ret:
#undef return

return C_r;}

/* from f_1904 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub357(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub357(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
FD_ZERO(&C_fdset_input);FD_ZERO(&C_fdset_output);
C_ret:
#undef return

return C_r;}

/* from ##sys#fdset-restore */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub353(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub353(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_fdset_input = C_fdset_input_2;C_fdset_output = C_fdset_output_2;
C_ret:
#undef return

return C_r;}

/* from ##sys#fdset-select-timeout */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub347(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub347(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int to=(int )C_truep(C_a0);
unsigned long tm=(unsigned long )C_num_to_unsigned_long(C_a1);
struct timeval timeout;timeout.tv_sec = tm / 1000;timeout.tv_usec = (tm % 1000) * 1000;C_fdset_input_2 = C_fdset_input;C_fdset_output_2 = C_fdset_output;return(select(FD_SETSIZE, &C_fdset_input, &C_fdset_output, NULL, to ? &timeout : NULL));
C_ret:
#undef return

return C_r;}

C_noret_decl(C_scheduler_toplevel)
C_externexport void C_ccall C_scheduler_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1904)
static void C_ccall f_1904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1266)
static void C_ccall f_1266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1848)
static void C_ccall f_1848(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1893)
static void C_ccall f_1893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1885)
static void C_ccall f_1885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1867)
static void C_ccall f_1867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1751)
static void C_ccall f_1751(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1766)
static void C_ccall f_1766(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1836)
static void C_ccall f_1836(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1770)
static void C_fcall f_1770(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1798)
static void C_ccall f_1798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1803)
static void C_ccall f_1803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1807)
static void C_ccall f_1807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1812)
static void C_ccall f_1812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1685)
static void C_ccall f_1685(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1696)
static void C_ccall f_1696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1708)
static void C_fcall f_1708(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1741)
static void C_ccall f_1741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1729)
static void C_ccall f_1729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1700)
static void C_ccall f_1700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1666)
static void C_ccall f_1666(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1656)
static void C_ccall f_1656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1638)
static void C_ccall f_1638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1654)
static void C_ccall f_1654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1646)
static void C_ccall f_1646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1650)
static void C_ccall f_1650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1277)
static void C_ccall f_1277(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1338)
static void C_fcall f_1338(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1281)
static void C_ccall f_1281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1284)
static void C_fcall f_1284(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1274)
static C_word C_fcall f_1274(C_word t0);
C_noret_decl(f_1271)
static C_word C_fcall f_1271(C_word t0);
C_noret_decl(f_1268)
static C_word C_fcall f_1268(C_word t0);
C_noret_decl(f_1262)
static C_word C_fcall f_1262();
C_noret_decl(f_1200)
static void C_ccall f_1200(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1237)
static void C_ccall f_1237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1240)
static void C_ccall f_1240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1243)
static void C_ccall f_1243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1246)
static void C_ccall f_1246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1256)
static void C_ccall f_1256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1249)
static void C_ccall f_1249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1224)
static void C_ccall f_1224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1228)
static void C_ccall f_1228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1204)
static void C_ccall f_1204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1210)
static void C_ccall f_1210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1188)
static void C_ccall f_1188(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1139)
static void C_ccall f_1139(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1143)
static void C_ccall f_1143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1172)
static void C_ccall f_1172(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1161)
static void C_ccall f_1161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1101)
static void C_ccall f_1101(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1038)
static void C_ccall f_1038(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1053)
static void C_fcall f_1053(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1063)
static void C_fcall f_1063(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1042)
static void C_ccall f_1042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1013)
static void C_ccall f_1013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1031)
static void C_ccall f_1031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1017)
static void C_ccall f_1017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_912)
static void C_ccall f_912(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_922)
static void C_fcall f_922(C_word t0,C_word t1) C_noret;
C_noret_decl(f_909)
static void C_ccall f_909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_901)
static void C_fcall f_901(C_word t0) C_noret;
C_noret_decl(f_680)
static void C_ccall f_680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_710)
static void C_ccall f_710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_715)
static void C_fcall f_715(C_word t0,C_word t1) C_noret;
C_noret_decl(f_794)
static void C_fcall f_794(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_846)
static void C_fcall f_846(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1573)
static void C_fcall f_1573(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1624)
static void C_ccall f_1624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1595)
static void C_ccall f_1595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1571)
static void C_ccall f_1571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_829)
static void C_fcall f_829(C_word t0,C_word t1) C_noret;
C_noret_decl(f_832)
static void C_ccall f_832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_719)
static void C_ccall f_719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1536)
static void C_fcall f_1536(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1420)
static void C_fcall f_1420(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1521)
static void C_ccall f_1521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1451)
static void C_fcall f_1451(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1491)
static void C_fcall f_1491(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1481)
static void C_ccall f_1481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1418)
static void C_ccall f_1418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1399)
static void C_ccall f_1399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_722)
static void C_ccall f_722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_727)
static void C_fcall f_727(C_word t0,C_word t1) C_noret;
C_noret_decl(f_946)
static void C_fcall f_946(C_word t0,C_word t1) C_noret;
C_noret_decl(f_731)
static void C_fcall f_731(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1770)
static void C_fcall trf_1770(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1770(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1770(t0,t1);}

C_noret_decl(trf_1708)
static void C_fcall trf_1708(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1708(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1708(t0,t1,t2);}

C_noret_decl(trf_1338)
static void C_fcall trf_1338(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1338(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1338(t0,t1,t2);}

C_noret_decl(trf_1284)
static void C_fcall trf_1284(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1284(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1284(t0,t1);}

C_noret_decl(trf_1053)
static void C_fcall trf_1053(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1053(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1053(t0,t1,t2,t3);}

C_noret_decl(trf_1063)
static void C_fcall trf_1063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1063(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1063(t0,t1);}

C_noret_decl(trf_922)
static void C_fcall trf_922(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_922(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_922(t0,t1);}

C_noret_decl(trf_901)
static void C_fcall trf_901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_901(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_901(t0);}

C_noret_decl(trf_715)
static void C_fcall trf_715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_715(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_715(t0,t1);}

C_noret_decl(trf_794)
static void C_fcall trf_794(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_794(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_794(t0,t1,t2);}

C_noret_decl(trf_846)
static void C_fcall trf_846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_846(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_846(t0,t1);}

C_noret_decl(trf_1573)
static void C_fcall trf_1573(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1573(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1573(t0,t1,t2);}

C_noret_decl(trf_829)
static void C_fcall trf_829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_829(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_829(t0,t1);}

C_noret_decl(trf_1536)
static void C_fcall trf_1536(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1536(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1536(t0,t1);}

C_noret_decl(trf_1420)
static void C_fcall trf_1420(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1420(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1420(t0,t1,t2,t3);}

C_noret_decl(trf_1451)
static void C_fcall trf_1451(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1451(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1451(t0,t1,t2);}

C_noret_decl(trf_1491)
static void C_fcall trf_1491(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1491(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1491(t0,t1);}

C_noret_decl(trf_727)
static void C_fcall trf_727(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_727(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_727(t0,t1);}

C_noret_decl(trf_946)
static void C_fcall trf_946(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_946(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_946(t0,t1);}

C_noret_decl(trf_731)
static void C_fcall trf_731(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_731(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_731(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_scheduler_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("scheduler_toplevel"));
C_check_nursery_minimum(44);
if(!C_demand(44)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(763)){
C_save(t1);
C_rereclaim2(763*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(44);
C_initialize_lf(lf,77);
lf[0]=C_h_intern(&lf[0],12,"\003sysschedule");
lf[1]=C_h_intern(&lf[1],18,"\003syscurrent-thread");
lf[2]=C_h_intern(&lf[2],17,"\003sysdynamic-winds");
lf[3]=C_h_intern(&lf[3],18,"\003sysstandard-input");
lf[4]=C_h_intern(&lf[4],19,"\003sysstandard-output");
lf[5]=C_h_intern(&lf[5],18,"\003sysstandard-error");
lf[6]=C_h_intern(&lf[6],29,"\003syscurrent-exception-handler");
lf[7]=C_h_intern(&lf[7],28,"\003syscurrent-parameter-vector");
lf[8]=C_h_intern(&lf[8],5,"ready");
lf[9]=C_h_intern(&lf[9],7,"running");
lf[11]=C_h_intern(&lf[11],11,"\003sysfd-list");
lf[12]=C_h_intern(&lf[12],15,"\003syssignal-hook");
lf[13]=C_h_intern(&lf[13],14,"\000runtime-error");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\010deadlock");
lf[20]=C_h_intern(&lf[20],25,"\003systhread-basic-unblock!");
lf[21]=C_h_intern(&lf[21],8,"\003sysdelq");
lf[22]=C_h_intern(&lf[22],22,"\003sysadd-to-ready-queue");
lf[23]=C_h_intern(&lf[23],19,"\003systhread-unblock!");
lf[24]=C_h_intern(&lf[24],21,"\003sysprimordial-thread");
lf[25]=C_h_intern(&lf[25],15,"\003sysready-queue");
lf[26]=C_h_intern(&lf[26],18,"\003sysinterrupt-hook");
lf[27]=C_h_intern(&lf[27],29,"\003systhread-block-for-timeout!");
lf[28]=C_h_intern(&lf[28],7,"blocked");
lf[29]=C_h_intern(&lf[29],33,"\003systhread-block-for-termination!");
lf[30]=C_h_intern(&lf[30],4,"dead");
lf[31]=C_h_intern(&lf[31],10,"terminated");
lf[32]=C_h_intern(&lf[32],16,"\003systhread-kill!");
lf[33]=C_h_intern(&lf[33],12,"\003sysfor-each");
lf[34]=C_h_intern(&lf[34],19,"\003sysabandon-mutexes");
lf[35]=C_h_intern(&lf[35],19,"print-error-message");
lf[36]=C_h_intern(&lf[36],7,"display");
lf[37]=C_h_intern(&lf[37],16,"print-call-chain");
lf[38]=C_h_intern(&lf[38],18,"open-output-string");
lf[39]=C_h_intern(&lf[39],17,"get-output-string");
lf[40]=C_h_intern(&lf[40],29,"\003sysdefault-exception-handler");
lf[41]=C_h_intern(&lf[41],10,"\003syssignal");
lf[42]=C_h_intern(&lf[42],20,"\003syswarnings-enabled");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\003): ");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\011Warning (");
lf[47]=C_h_intern(&lf[47],25,"\003systhread-block-for-i/o!");
lf[48]=C_h_intern(&lf[48],6,"\000input");
lf[49]=C_h_intern(&lf[49],7,"\000output");
lf[50]=C_h_intern(&lf[50],4,"\000all");
lf[51]=C_h_intern(&lf[51],15,"\003sysall-threads");
lf[52]=C_h_intern(&lf[52],6,"append");
lf[53]=C_h_intern(&lf[53],7,"\003sysmap");
lf[54]=C_h_intern(&lf[54],3,"cdr");
lf[55]=C_h_intern(&lf[55],27,"\003sysfetch-and-clear-threads");
lf[56]=C_h_intern(&lf[56],19,"\003sysrestore-threads");
lf[57]=C_h_intern(&lf[57],15,"\003sysbreak-entry");
lf[58]=C_h_intern(&lf[58],19,"\003sysbreak-in-thread");
lf[59]=C_h_intern(&lf[59],9,"condition");
lf[60]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\003\000\000\002\376\001\000\000\012breakpoint\376\377\016");
lf[61]=C_h_intern(&lf[61],19,"\003syslast-breakpoint");
lf[62]=C_h_intern(&lf[62],9,"suspended");
lf[63]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\022*** breakpoint ***");
lf[65]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\011arguments");
lf[66]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\010location");
lf[67]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\014continuation");
lf[68]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\006thread");
lf[69]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\027primordial-continuation");
lf[70]=C_h_intern(&lf[70],16,"\003sysbreak-resume");
lf[71]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\014continuation");
lf[72]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\006thread");
lf[73]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\027primordial-continuation");
lf[74]=C_h_intern(&lf[74],11,"\000type-error");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\035condition has no continuation");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\035condition has no continuation");
C_register_lf2(lf,77,create_ptable());
t2=C_mutate((C_word*)lf[0]+1 /* schedule ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_680,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[17] /* force-primordial ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_901,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t4=lf[15] /* ready-queue-head */ =C_SCHEME_END_OF_LIST;;
t5=lf[16] /* ready-queue-tail */ =C_SCHEME_END_OF_LIST;;
t6=C_mutate((C_word*)lf[25]+1 /* ready-queue ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_909,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[22]+1 /* add-to-ready-queue ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_912,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t8=*((C_word*)lf[26]+1);
t9=C_mutate((C_word*)lf[26]+1 /* interrupt-hook ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1013,a[2]=t8,a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp));
t10=lf[10] /* timeout-list */ =C_SCHEME_END_OF_LIST;;
t11=C_mutate((C_word*)lf[27]+1 /* thread-block-for-timeout! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1038,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[29]+1 /* thread-block-for-termination! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1101,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[32]+1 /* thread-kill! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1139,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[20]+1 /* thread-basic-unblock! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1188,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t15=*((C_word*)lf[35]+1);
t16=*((C_word*)lf[36]+1);
t17=*((C_word*)lf[37]+1);
t18=*((C_word*)lf[38]+1);
t19=*((C_word*)lf[39]+1);
t20=C_mutate((C_word*)lf[40]+1 /* default-exception-handler ...) */,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1200,a[2]=t18,a[3]=t16,a[4]=t19,a[5]=t15,a[6]=t17,a[7]=((C_word)li19),tmp=(C_word)a,a+=8,tmp));
t21=C_set_block_item(lf[11] /* fd-list */,0,C_SCHEME_END_OF_LIST);
t22=C_mutate(&lf[18] /* fdset-restore ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1262,tmp=(C_word)a,a+=2,tmp));
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1266,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1904,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp);
((C_proc2)(void*)(*((C_word*)t24+1)))(2,t24,t23);}

/* f_1904 */
static void C_ccall f_1904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1904,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub357(C_SCHEME_UNDEFINED));}

/* k1264 */
static void C_ccall f_1266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1266,2,t0,t1);}
t2=C_mutate(&lf[45] /* fdset-input-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1268,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[46] /* fdset-output-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1271,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[19] /* fdset-clear ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1274,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[47]+1 /* thread-block-for-i/o! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1277,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[51]+1 /* all-threads ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1638,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[55]+1 /* fetch-and-clear-threads ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1656,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[56]+1 /* restore-threads ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1666,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[23]+1 /* thread-unblock! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1685,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[57]+1 /* break-entry ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1751,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[70]+1 /* break-resume ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1848,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}

/* ##sys#break-resume in k1264 */
static void C_ccall f_1848(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1848,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(2));
t4=(C_word)C_i_member(lf[71],t3);
t5=(C_word)C_i_member(lf[72],t3);
t6=(C_word)C_i_member(lf[73],t3);
t7=(C_truep(t6)?t6:t4);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1867,a[2]=t2,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t9=(C_word)C_u_i_cadr(t5);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1885,a[2]=t9,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1893,a[2]=t4,a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp);
t12=t10;
f_1885(2,t12,(C_word)C_i_setslot(t9,C_fix(1),t11));}
else{
C_trace("scheduler.scm: 505  ##sys#signal-hook");
t11=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t10,lf[74],lf[76],t2);}}
else{
t9=t8;
f_1867(2,t9,C_SCHEME_UNDEFINED);}}

/* a1892 in ##sys#break-resume in k1264 */
static void C_ccall f_1893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1893,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,C_SCHEME_UNDEFINED);}

/* k1883 in ##sys#break-resume in k1264 */
static void C_ccall f_1885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("scheduler.scm: 506  ##sys#add-to-ready-queue");
t2=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1865 in ##sys#break-resume in k1264 */
static void C_ccall f_1867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],C_SCHEME_UNDEFINED);}
else{
C_trace("scheduler.scm: 509  ##sys#signal-hook");
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[74],lf[75],((C_word*)t0)[2]);}}

/* ##sys#break-entry in k1264 */
static void C_ccall f_1751(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1751,4,t0,t1,t2,t3);}
t4=(C_word)C_i_not(*((C_word*)lf[58]+1));
t5=(C_truep(t4)?t4:(C_word)C_eqp(*((C_word*)lf[58]+1),*((C_word*)lf[1]+1)));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1766,a[2]=t3,a[3]=t2,a[4]=((C_word)li33),tmp=(C_word)a,a+=5,tmp);
C_trace("scheduler.scm: 464  ##sys#call-with-current-continuation");
C_call_cc(3,0,t1,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* a1765 in ##sys#break-entry in k1264 */
static void C_ccall f_1766(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1766,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(*((C_word*)lf[1]+1),*((C_word*)lf[24]+1));
if(C_truep(t4)){
t5=t3;
f_1770(t5,C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1836,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp);
t6=t3;
f_1770(t6,(C_word)C_a_i_list(&a,4,lf[68],*((C_word*)lf[1]+1),lf[69],t5));}}

/* a1835 in a1765 in ##sys#break-entry in k1264 */
static void C_ccall f_1836(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1836,2,t0,t1);}
t2=(C_word)C_slot(*((C_word*)lf[24]+1),C_fix(1));
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k1768 in a1765 in ##sys#break-entry in k1264 */
static void C_fcall f_1770(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1770,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1820,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t4=(C_word)C_a_i_list(&a,8,lf[63],lf[64],lf[65],t3,lf[66],((C_word*)t0)[3],lf[67],((C_word*)t0)[4]);
C_trace("scheduler.scm: 474  append");
t5=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t4,t1);}

/* k1818 in k1768 in a1765 in ##sys#break-entry in k1264 */
static void C_ccall f_1820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1820,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,3,lf[59],lf[60],t1);
t3=C_mutate((C_word*)lf[61]+1 /* last-breakpoint ...) */,t2);
t4=(C_word)C_eqp(*((C_word*)lf[1]+1),*((C_word*)lf[24]+1));
if(C_truep(t4)){
C_trace("scheduler.scm: 482  ##sys#signal");
t5=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,((C_word*)t0)[3],t2);}
else{
t5=(C_word)C_i_setslot(*((C_word*)lf[1]+1),C_fix(3),lf[62]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1812,a[2]=((C_word*)t0)[2],a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_setslot(*((C_word*)lf[1]+1),C_fix(1),t6);
t8=(C_word)C_slot(*((C_word*)lf[24]+1),C_fix(1));
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1803,a[2]=t2,a[3]=t8,a[4]=((C_word)li31),tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_i_setslot(*((C_word*)lf[24]+1),C_fix(1),t9);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1798,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("scheduler.scm: 492  ##sys#thread-unblock!");
t12=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,*((C_word*)lf[24]+1));}}

/* k1796 in k1818 in k1768 in a1765 in ##sys#break-entry in k1264 */
static void C_ccall f_1798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("scheduler.scm: 493  ##sys#schedule");
t2=*((C_word*)lf[0]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a1802 in k1818 in k1768 in a1765 in ##sys#break-entry in k1264 */
static void C_ccall f_1803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1807,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("scheduler.scm: 490  ##sys#signal");
t3=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1805 in a1802 in k1818 in k1768 in a1765 in ##sys#break-entry in k1264 */
static void C_ccall f_1807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("scheduler.scm: 491  old");
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a1811 in k1818 in k1768 in a1765 in ##sys#break-entry in k1264 */
static void C_ccall f_1812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1812,2,t0,t1);}
C_trace("scheduler.scm: 485  k");
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* ##sys#thread-unblock! in k1264 */
static void C_ccall f_1685(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1685,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_eqp(lf[28],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1696,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("scheduler.scm: 446  ##sys#delq");
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[10]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k1694 in ##sys#thread-unblock! in k1264 */
static void C_ccall f_1696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1696,2,t0,t1);}
t2=C_mutate(&lf[10] /* timeout-list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1700,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1708,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word)li28),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1708(t7,t3,*((C_word*)lf[11]+1));}

/* loop in k1694 in ##sys#thread-unblock! in k1264 */
static void C_fcall f_1708(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1708,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1741,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(t3,C_fix(1));
C_trace("scheduler.scm: 454  ##sys#delq");
t7=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}}

/* k1739 in loop in k1694 in ##sys#thread-unblock! in k1264 */
static void C_ccall f_1741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1741,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1729,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
C_trace("scheduler.scm: 455  loop");
t5=((C_word*)((C_word*)t0)[2])[1];
f_1708(t5,t3,t4);}

/* k1727 in k1739 in loop in k1694 in ##sys#thread-unblock! in k1264 */
static void C_ccall f_1729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1729,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1698 in k1694 in ##sys#thread-unblock! in k1264 */
static void C_ccall f_1700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate((C_word*)lf[11]+1 /* fd-list ...) */,t1);
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[3],C_fix(12),C_SCHEME_END_OF_LIST);
C_trace("scheduler.scm: 457  ##sys#thread-basic-unblock!");
t4=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* ##sys#restore-threads in k1264 */
static void C_ccall f_1666(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1666,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=C_mutate(&lf[15] /* ready-queue-head ...) */,t3);
t5=(C_word)C_slot(t2,C_fix(1));
t6=C_mutate(&lf[16] /* ready-queue-tail ...) */,t5);
t7=(C_word)C_slot(t2,C_fix(2));
t8=C_mutate((C_word*)lf[11]+1 /* fd-list ...) */,t7);
t9=(C_word)C_slot(t2,C_fix(3));
t10=C_mutate(&lf[10] /* timeout-list ...) */,t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}

/* ##sys#fetch-and-clear-threads in k1264 */
static void C_ccall f_1656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1656,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,4,lf[15],lf[16],*((C_word*)lf[11]+1),lf[10]);
t3=lf[15] /* ready-queue-head */ =C_SCHEME_END_OF_LIST;;
t4=lf[16] /* ready-queue-tail */ =C_SCHEME_END_OF_LIST;;
t5=C_set_block_item(lf[11] /* fd-list */,0,C_SCHEME_END_OF_LIST);
t6=lf[10] /* timeout-list */ =C_SCHEME_END_OF_LIST;;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t2);}

/* ##sys#all-threads in k1264 */
static void C_ccall f_1638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1646,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1654,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t4=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[54]+1),*((C_word*)lf[11]+1));}

/* k1652 in ##sys#all-threads in k1264 */
static void C_ccall f_1654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[52]+1),t1);}

/* k1644 in ##sys#all-threads in k1264 */
static void C_ccall f_1646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1650,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t3=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[54]+1),lf[10]);}

/* k1648 in k1644 in ##sys#all-threads in k1264 */
static void C_ccall f_1650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("scheduler.scm: 417  append");
t2=*((C_word*)lf[52]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[15],((C_word*)t0)[2],t1);}

/* ##sys#thread-block-for-i/o! in k1264 */
static void C_ccall f_1277(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1277,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1281,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1338,a[2]=t7,a[3]=t2,a[4]=t3,a[5]=((C_word)li23),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_1338(t9,t5,*((C_word*)lf[11]+1));}

/* loop in ##sys#thread-block-for-i/o! in k1264 */
static void C_fcall f_1338(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1338,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t3,*((C_word*)lf[11]+1));
t5=C_mutate((C_word*)lf[11]+1 /* fd-list ...) */,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_u_i_car(t3);
t5=(C_word)C_eqp(((C_word*)t0)[4],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(t3,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_setslot(t3,C_fix(1),t7));}
else{
t6=(C_word)C_slot(t2,C_fix(1));
C_trace("scheduler.scm: 338  loop");
t13=t1;
t14=t6;
t1=t13;
t2=t14;
goto loop;}}}

/* k1279 in ##sys#thread-block-for-i/o! in k1264 */
static void C_ccall f_1281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1281,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1284,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,C_SCHEME_TRUE);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t2,lf[48]));
if(C_truep(t5)){
C_trace("scheduler.scm: 340  ##sys#fdset-input-set");
t6=t3;
f_1284(t6,f_1268(((C_word*)t0)[3]));}
else{
t6=(C_word)C_eqp(t2,C_SCHEME_FALSE);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t2,lf[49]));
if(C_truep(t7)){
C_trace("scheduler.scm: 341  ##sys#fdset-output-set");
t8=t3;
f_1284(t8,f_1271(((C_word*)t0)[3]));}
else{
t8=(C_word)C_eqp(t2,lf[50]);
if(C_truep(t8)){
t9=f_1268(((C_word*)t0)[3]);
C_trace("scheduler.scm: 344  ##sys#fdset-output-set");
t10=t3;
f_1284(t10,f_1271(((C_word*)t0)[3]));}
else{
t9=t3;
f_1284(t9,C_SCHEME_UNDEFINED);}}}}

/* k1282 in k1279 in ##sys#thread-block-for-i/o! in k1264 */
static void C_fcall f_1284(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1284,NULL,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(3),lf[28]);
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[5],C_fix(13),C_SCHEME_FALSE);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(11),t4));}

/* ##sys#fdset-clear in k1264 */
static C_word C_fcall f_1274(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub374(C_SCHEME_UNDEFINED,t1));}

/* ##sys#fdset-output-set in k1264 */
static C_word C_fcall f_1271(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub368(C_SCHEME_UNDEFINED,t1));}

/* ##sys#fdset-input-set in k1264 */
static C_word C_fcall f_1268(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub362(C_SCHEME_UNDEFINED,t1));}

/* ##sys#fdset-restore */
static C_word C_fcall f_1262(){
C_word tmp;
C_word t1;
return((C_word)stub353(C_SCHEME_UNDEFINED));}

/* ##sys#default-exception-handler */
static void C_ccall f_1200(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1200,3,t0,t1,t2);}
t3=*((C_word*)lf[1]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1204,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_mk_bool(C_abort_on_thread_exceptions))){
t5=*((C_word*)lf[24]+1);
t6=(C_word)C_slot(t5,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1224,a[2]=t2,a[3]=t6,a[4]=((C_word)li18),tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_setslot(t5,C_fix(1),t7);
C_trace("scheduler.scm: 282  ##sys#thread-unblock!");
t9=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t4,t5);}
else{
if(C_truep(*((C_word*)lf[42]+1))){
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1237,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t4,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
C_trace("scheduler.scm: 284  open-output-string");
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t4;
f_1204(2,t5,C_SCHEME_UNDEFINED);}}}

/* k1235 in ##sys#default-exception-handler */
static void C_ccall f_1237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1240,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("scheduler.scm: 285  display");
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[44],t1);}

/* k1238 in k1235 in ##sys#default-exception-handler */
static void C_ccall f_1240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1243,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
C_trace("scheduler.scm: 286  display");
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[7],((C_word*)t0)[3]);}

/* k1241 in k1238 in k1235 in ##sys#default-exception-handler */
static void C_ccall f_1243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1246,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
C_trace("scheduler.scm: 287  display");
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[43],((C_word*)t0)[3]);}

/* k1244 in k1241 in k1238 in k1235 in ##sys#default-exception-handler */
static void C_ccall f_1246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1249,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1256,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("scheduler.scm: 288  get-output-string");
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k1254 in k1244 in k1241 in k1238 in k1235 in ##sys#default-exception-handler */
static void C_ccall f_1256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("scheduler.scm: 288  print-error-message");
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[5]+1),t1);}

/* k1247 in k1244 in k1241 in k1238 in k1235 in ##sys#default-exception-handler */
static void C_ccall f_1249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("scheduler.scm: 289  print-call-chain");
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[5]+1),C_fix(0),((C_word*)t0)[2]);}

/* a1223 in ##sys#default-exception-handler */
static void C_ccall f_1224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1228,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("scheduler.scm: 280  ##sys#signal");
t3=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1226 in a1223 in ##sys#default-exception-handler */
static void C_ccall f_1228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("scheduler.scm: 281  ptx");
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k1202 in ##sys#default-exception-handler */
static void C_ccall f_1204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1204,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(7),((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1210,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("scheduler.scm: 291  ##sys#thread-kill!");
t4=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],lf[31]);}

/* k1208 in k1202 in ##sys#default-exception-handler */
static void C_ccall f_1210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("scheduler.scm: 292  ##sys#schedule");
t2=*((C_word*)lf[0]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##sys#thread-basic-unblock! */
static void C_ccall f_1188(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1188,3,t0,t1,t2);}
t3=(C_word)C_i_set_i_slot(t2,C_fix(11),C_SCHEME_FALSE);
t4=(C_word)C_i_set_i_slot(t2,C_fix(4),C_SCHEME_FALSE);
C_trace("scheduler.scm: 263  ##sys#add-to-ready-queue");
t5=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t2);}

/* ##sys#thread-kill! */
static void C_ccall f_1139(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1139,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1143,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("scheduler.scm: 244  ##sys#abandon-mutexes");
t5=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1141 in ##sys#thread-kill! */
static void C_ccall f_1143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1143,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),((C_word*)t0)[3]);
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(4),C_SCHEME_FALSE);
t4=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(11),C_SCHEME_FALSE);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(8),C_SCHEME_END_OF_LIST);
t6=(C_word)C_slot(((C_word*)t0)[4],C_fix(12));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1161,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t6))){
t8=t7;
f_1161(2,t8,C_SCHEME_UNDEFINED);}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1172,a[2]=((C_word*)t0)[4],a[3]=((C_word)li15),tmp=(C_word)a,a+=4,tmp);
C_trace("for-each");
t9=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,t6);}}

/* a1171 in k1141 in ##sys#thread-kill! */
static void C_ccall f_1172(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1172,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(11));
t4=(C_word)C_eqp(t3,((C_word*)t0)[2]);
if(C_truep(t4)){
C_trace("scheduler.scm: 255  ##sys#thread-basic-unblock!");
t5=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t2);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k1159 in k1141 in ##sys#thread-kill! */
static void C_ccall f_1161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(12),C_SCHEME_END_OF_LIST));}

/* ##sys#thread-block-for-termination! */
static void C_ccall f_1101(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1101,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_eqp(t4,lf[30]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(t4,lf[31]));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}
else{
t7=(C_word)C_slot(t3,C_fix(12));
t8=(C_word)C_a_i_cons(&a,2,t2,t7);
t9=(C_word)C_i_setslot(t3,C_fix(12),t8);
t10=(C_word)C_i_setslot(t2,C_fix(3),lf[28]);
t11=(C_word)C_i_set_i_slot(t2,C_fix(13),C_SCHEME_FALSE);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_i_setslot(t2,C_fix(11),t3));}}

/* ##sys#thread-block-for-timeout! */
static void C_ccall f_1038(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1038,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1042,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1053,a[2]=t6,a[3]=t2,a[4]=t3,a[5]=((C_word)li12),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_1053(t8,t4,lf[10],C_SCHEME_FALSE);}

/* loop in ##sys#thread-block-for-timeout! */
static void C_fcall f_1053(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1053,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_nullp(t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1063,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
t6=t5;
f_1063(t6,t4);}
else{
t6=(C_word)C_u_i_caar(t2);
t7=((C_word*)t0)[4];
t8=t5;
f_1063(t8,(C_word)C_fixnum_lessp(t7,t6));}}

/* k1061 in loop in ##sys#thread-block-for-timeout! */
static void C_fcall f_1063(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1063,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[7])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_setslot(((C_word*)t0)[7],C_fix(1),t3));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=C_mutate(&lf[10] /* timeout-list ...) */,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
C_trace("scheduler.scm: 228  loop");
t3=((C_word*)((C_word*)t0)[2])[1];
f_1053(t3,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}}

/* k1040 in ##sys#thread-block-for-timeout! */
static void C_ccall f_1042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),lf[28]);
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(13),C_SCHEME_FALSE);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(4),((C_word*)t0)[2]));}

/* ##sys#interrupt-hook */
static void C_ccall f_1013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1013,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1017,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(t2,C_fix(255));
if(C_truep(t5)){
t6=*((C_word*)lf[1]+1);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1031,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word)li10),tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_setslot(t6,C_fix(1),t7);
C_trace("scheduler.scm: 215  ##sys#schedule");
t9=*((C_word*)lf[0]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t4);}
else{
t6=t4;
f_1017(2,t6,C_SCHEME_UNDEFINED);}}

/* a1030 in ##sys#interrupt-hook */
static void C_ccall f_1031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1031,2,t0,t1);}
C_trace("scheduler.scm: 214  oldhook");
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1015 in ##sys#interrupt-hook */
static void C_ccall f_1017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("scheduler.scm: 216  oldhook");
t2=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#add-to-ready-queue */
static void C_ccall f_912(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_912,3,t0,t1,t2);}
t3=(C_word)C_i_setslot(t2,C_fix(3),lf[8]);
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_922,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(C_SCHEME_END_OF_LIST,lf[15]);
if(C_truep(t6)){
t7=C_mutate(&lf[15] /* ready-queue-head ...) */,t4);
t8=t5;
f_922(t8,t7);}
else{
t7=t5;
f_922(t7,(C_word)C_i_setslot(lf[16],C_fix(1),t4));}}

/* k920 in ##sys#add-to-ready-queue */
static void C_fcall f_922(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[16] /* ready-queue-tail ...) */,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##sys#ready-queue */
static void C_ccall f_909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_909,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[15]);}

/* ##sys#force-primordial */
static void C_fcall f_901(C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_901,NULL,1,t1);}
C_trace("scheduler.scm: 168  ##sys#thread-unblock!");
t2=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,*((C_word*)lf[24]+1));}

/* ##sys#schedule */
static void C_ccall f_680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_680,2,t0,t1);}
t2=*((C_word*)lf[1]+1);
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_slot(t2,C_fix(3));
t6=(C_word)C_slot(t2,C_fix(5));
t7=(C_word)C_i_setslot(t6,C_fix(0),*((C_word*)lf[2]+1));
t8=(C_word)C_i_setslot(t6,C_fix(1),*((C_word*)lf[3]+1));
t9=(C_word)C_i_setslot(t6,C_fix(2),*((C_word*)lf[4]+1));
t10=(C_word)C_i_setslot(t6,C_fix(3),*((C_word*)lf[5]+1));
t11=(C_word)C_i_setslot(t6,C_fix(4),*((C_word*)lf[6]+1));
t12=(C_word)C_i_setslot(t6,C_fix(5),*((C_word*)lf[7]+1));
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_710,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_eqp(t5,lf[9]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t5,lf[8]));
if(C_truep(t15)){
t16=(C_word)C_i_set_i_slot(t2,C_fix(13),C_SCHEME_FALSE);
C_trace("scheduler.scm: 116  ##sys#add-to-ready-queue");
t17=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t13,t2);}
else{
t16=t13;
f_710(2,t16,C_SCHEME_UNDEFINED);}}

/* k708 in ##sys#schedule */
static void C_ccall f_710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_710,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_715,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li5),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_715(t5,((C_word*)t0)[2]);}

/* loop1 in k708 in ##sys#schedule */
static void C_fcall f_715(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_715,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_719,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(lf[10]))){
t3=t2;
f_719(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_fudge(C_fix(16));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_794,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t3,a[5]=((C_word)li4),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_794(t7,t2,lf[10]);}}

/* loop in loop1 in k708 in ##sys#schedule */
static void C_fcall f_794(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
loop:
a=C_alloc(22);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_794,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=lf[10] /* timeout-list */ =C_SCHEME_END_OF_LIST;;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(C_word)C_u_i_caar(t2);
t4=(C_word)C_u_i_cdar(t2);
t5=(C_word)C_slot(t4,C_fix(4));
t6=(C_word)C_eqp(t3,t5);
if(C_truep(t6)){
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)t0)[4],t3))){
t7=(C_word)C_i_set_i_slot(t4,C_fix(13),C_SCHEME_TRUE);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_829,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_slot(t4,C_fix(11));
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_slot(t4,C_fix(11));
t11=(C_word)C_slot(t10,C_fix(0));
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1571,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1573,a[2]=t14,a[3]=t4,a[4]=t11,a[5]=((C_word)li3),tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_1573(t16,t12,*((C_word*)lf[11]+1));}
else{
t10=t8;
f_829(t10,C_SCHEME_UNDEFINED);}}
else{
t7=C_mutate(&lf[10] /* timeout-list ...) */,t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_846,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(lf[15]))){
t9=(C_word)C_i_nullp(*((C_word*)lf[11]+1));
t10=t8;
f_846(t10,(C_truep(t9)?(C_word)C_i_pairp(lf[10]):C_SCHEME_FALSE));}
else{
t9=t8;
f_846(t9,C_SCHEME_FALSE);}}}
else{
t7=(C_word)C_slot(t2,C_fix(1));
C_trace("scheduler.scm: 149  loop");
t22=t1;
t23=t7;
t1=t22;
t2=t23;
goto loop;}}}

/* k844 in loop in loop1 in k708 in ##sys#schedule */
static void C_fcall f_846(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_caar(lf[10]);
t3=(C_word)C_u_fixnum_difference(t2,((C_word*)t0)[4]);
t4=(C_word)C_i_fixnum_max(C_fix(0),t3);
t5=(C_truep((C_word)C_msleep(t4))?C_SCHEME_FALSE:C_mk_bool(C_signal_interrupted_p));
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* loop in loop in loop1 in k708 in ##sys#schedule */
static void C_fcall f_1573(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1573,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[4],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1595,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(t3,C_fix(1));
C_trace("scheduler.scm: 402  ##sys#delq");
t8=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[3],t7);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1624,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
C_trace("scheduler.scm: 411  loop");
t11=t6;
t12=t7;
t1=t11;
t2=t12;
goto loop;}}}

/* k1622 in loop in loop in loop1 in k708 in ##sys#schedule */
static void C_ccall f_1624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1624,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1593 in loop in loop in loop1 in k708 in ##sys#schedule */
static void C_ccall f_1595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep((C_word)C_i_nullp(t1))){
t2=f_1274(((C_word*)t0)[5]);
t3=f_1262();
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[3],C_fix(1)));}
else{
t2=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1569 in loop in loop1 in k708 in ##sys#schedule */
static void C_ccall f_1571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[11]+1 /* fd-list ...) */,t1);
t3=((C_word*)t0)[2];
f_829(t3,t2);}

/* k827 in loop in loop1 in k708 in ##sys#schedule */
static void C_fcall f_829(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_829,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_832,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("scheduler.scm: 135  ##sys#thread-basic-unblock!");
t3=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k830 in k827 in loop in loop1 in k708 in ##sys#schedule */
static void C_ccall f_832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
C_trace("scheduler.scm: 136  loop");
t3=((C_word*)((C_word*)t0)[3])[1];
f_794(t3,((C_word*)t0)[2],t2);}

/* k717 in loop1 in k708 in ##sys#schedule */
static void C_ccall f_719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_719,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_722,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
C_trace("scheduler.scm: 152  ##sys#force-primordial");
f_901(t2);}
else{
if(C_truep((C_word)C_i_nullp(*((C_word*)lf[11]+1)))){
t3=t2;
f_722(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_pairp(lf[10]);
t4=(C_word)C_i_pairp(lf[15]);
t5=(C_truep(t4)?t4:t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1536,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?(C_word)C_i_not(t4):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_u_i_caar(lf[10]);
t9=(C_word)C_fudge(C_fix(16));
t10=(C_word)C_u_fixnum_difference(t8,t9);
t11=t6;
f_1536(t11,(C_word)C_i_fixnum_max(C_fix(0),t10));}
else{
t8=t6;
f_1536(t8,C_fix(0));}}}}

/* k1534 in k717 in loop1 in k708 in ##sys#schedule */
static void C_fcall f_1536(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1536,NULL,2,t0,t1);}
t2=(C_word)stub347(C_SCHEME_UNDEFINED,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1399,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
C_trace("scheduler.scm: 362  ##sys#force-primordial");
f_901(t3);}
else{
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1418,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1420,a[2]=t7,a[3]=((C_word)li2),tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_1420(t9,t5,t2,*((C_word*)lf[11]+1));}
else{
t5=t3;
f_1399(2,t5,C_SCHEME_UNDEFINED);}}}

/* loop in k1534 in k717 in loop1 in k708 in ##sys#schedule */
static void C_fcall f_1420(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1420,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t3));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_u_i_car(t3);
t7=(C_word)C_u_i_car(t6);
t8=(C_word)C_fd_test_input(t7);
t9=(C_word)C_fd_test_output(t7);
t10=(C_truep(t8)?t8:t9);
if(C_truep(t10)){
t11=(C_word)C_slot(t6,C_fix(1));
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1451,a[2]=t13,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=t7,a[7]=((C_word)li1),tmp=(C_word)a,a+=8,tmp));
t15=((C_word*)t13)[1];
f_1451(t15,t1,t11);}
else{
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1521,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_slot(t3,C_fix(1));
C_trace("scheduler.scm: 386  loop");
t18=t11;
t19=t2;
t20=t12;
t1=t18;
t2=t19;
t3=t20;
goto loop;}}}

/* k1519 in loop in k1534 in k717 in loop1 in k708 in ##sys#schedule */
static void C_ccall f_1521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1521,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* loop2 in loop in k1534 in k717 in loop1 in k708 in ##sys#schedule */
static void C_fcall f_1451(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1451,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=f_1274(((C_word*)t0)[6]);
t4=(C_word)C_u_fixnum_decrease(((C_word*)t0)[5]);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
C_trace("scheduler.scm: 378  loop");
t6=((C_word*)((C_word*)t0)[3])[1];
f_1420(t6,t1,t4,t5);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t3,C_fix(11));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1481,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1491,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_u_i_car(t4);
t8=(C_word)C_eqp(((C_word*)t0)[6],t7);
if(C_truep(t8)){
t9=(C_word)C_slot(t3,C_fix(13));
t10=t6;
f_1491(t10,(C_word)C_i_not(t9));}
else{
t9=t6;
f_1491(t9,C_SCHEME_FALSE);}}
else{
t7=t6;
f_1491(t7,C_SCHEME_FALSE);}}}

/* k1489 in loop2 in loop in k1534 in k717 in loop1 in k708 in ##sys#schedule */
static void C_fcall f_1491(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("scheduler.scm: 384  ##sys#thread-basic-unblock!");
t2=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1481(2,t2,C_SCHEME_UNDEFINED);}}

/* k1479 in loop2 in loop in k1534 in k717 in loop1 in k708 in ##sys#schedule */
static void C_ccall f_1481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
C_trace("scheduler.scm: 385  loop2");
t3=((C_word*)((C_word*)t0)[3])[1];
f_1451(t3,((C_word*)t0)[2],t2);}

/* k1416 in k1534 in k717 in loop1 in k708 in ##sys#schedule */
static void C_ccall f_1418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[11]+1 /* fd-list ...) */,t1);
t3=((C_word*)t0)[2];
f_1399(2,t3,t2);}

/* k1397 in k1534 in k717 in loop1 in k708 in ##sys#schedule */
static void C_ccall f_1399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("scheduler.scm: 387  ##sys#fdset-restore");
t2=((C_word*)t0)[2];
f_722(2,t2,f_1262());}

/* k720 in k717 in loop1 in k708 in ##sys#schedule */
static void C_ccall f_722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_722,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_727,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li0),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_727(t5,((C_word*)t0)[2]);}

/* loop2 in k720 in k717 in loop1 in k708 in ##sys#schedule */
static void C_fcall f_727(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_727,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_731,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=lf[15];
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_731(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(1));
t5=C_mutate(&lf[15] /* ready-queue-head ...) */,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_946,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t7)){
t8=lf[16] /* ready-queue-tail */ =C_SCHEME_END_OF_LIST;;
t9=t6;
f_946(t9,t8);}
else{
t8=t6;
f_946(t8,C_SCHEME_UNDEFINED);}}}

/* k944 in loop2 in k720 in k717 in loop1 in k708 in ##sys#schedule */
static void C_fcall f_946(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_731(t2,(C_word)C_u_i_car(((C_word*)t0)[2]));}

/* k729 in loop2 in k720 in k717 in loop1 in k708 in ##sys#schedule */
static void C_fcall f_731(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word *a;
t2=t1;
if(C_truep(t2)){
t3=(C_word)C_slot(t1,C_fix(3));
t4=(C_word)C_eqp(t3,lf[8]);
if(C_truep(t4)){
t5=((C_word*)t0)[4];
t6=t1;
t7=C_mutate((C_word*)lf[1]+1 /* current-thread ...) */,t6);
t8=(C_word)C_i_setslot(t6,C_fix(3),lf[9]);
t9=(C_word)C_slot(t6,C_fix(5));
t10=(C_word)C_slot(t9,C_fix(0));
t11=C_mutate((C_word*)lf[2]+1 /* dynamic-winds ...) */,t10);
t12=(C_word)C_slot(t9,C_fix(1));
t13=C_mutate((C_word*)lf[3]+1 /* standard-input ...) */,t12);
t14=(C_word)C_slot(t9,C_fix(2));
t15=C_mutate((C_word*)lf[4]+1 /* standard-output ...) */,t14);
t16=(C_word)C_slot(t9,C_fix(3));
t17=C_mutate((C_word*)lf[5]+1 /* standard-error ...) */,t16);
t18=(C_word)C_slot(t9,C_fix(4));
t19=C_mutate((C_word*)lf[6]+1 /* current-exception-handler ...) */,t18);
t20=(C_word)C_slot(t9,C_fix(5));
t21=C_mutate((C_word*)lf[7]+1 /* current-parameter-vector ...) */,t20);
t22=(C_word)C_slot(t6,C_fix(9));
t23=(C_word)C_set_initial_timer_interrupt_period(t22);
t24=(C_word)C_slot(t6,C_fix(1));
t25=t24;
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,t5);}
else{
C_trace("scheduler.scm: 164  loop2");
t5=((C_word*)((C_word*)t0)[3])[1];
f_727(t5,((C_word*)t0)[4]);}}
else{
t3=(C_word)C_i_nullp(lf[10]);
t4=(C_truep(t3)?(C_word)C_i_nullp(*((C_word*)lf[11]+1)):C_SCHEME_FALSE);
if(C_truep(t4)){
C_trace("scheduler.scm: 161  ##sys#signal-hook");
t5=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[4],lf[13],lf[14]);}
else{
C_trace("scheduler.scm: 162  loop1");
t5=((C_word*)((C_word*)t0)[2])[1];
f_715(t5,((C_word*)t0)[4]);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[89] = {
{"toplevelscheduler.scm",(void*)C_scheduler_toplevel},
{"f_1904scheduler.scm",(void*)f_1904},
{"f_1266scheduler.scm",(void*)f_1266},
{"f_1848scheduler.scm",(void*)f_1848},
{"f_1893scheduler.scm",(void*)f_1893},
{"f_1885scheduler.scm",(void*)f_1885},
{"f_1867scheduler.scm",(void*)f_1867},
{"f_1751scheduler.scm",(void*)f_1751},
{"f_1766scheduler.scm",(void*)f_1766},
{"f_1836scheduler.scm",(void*)f_1836},
{"f_1770scheduler.scm",(void*)f_1770},
{"f_1820scheduler.scm",(void*)f_1820},
{"f_1798scheduler.scm",(void*)f_1798},
{"f_1803scheduler.scm",(void*)f_1803},
{"f_1807scheduler.scm",(void*)f_1807},
{"f_1812scheduler.scm",(void*)f_1812},
{"f_1685scheduler.scm",(void*)f_1685},
{"f_1696scheduler.scm",(void*)f_1696},
{"f_1708scheduler.scm",(void*)f_1708},
{"f_1741scheduler.scm",(void*)f_1741},
{"f_1729scheduler.scm",(void*)f_1729},
{"f_1700scheduler.scm",(void*)f_1700},
{"f_1666scheduler.scm",(void*)f_1666},
{"f_1656scheduler.scm",(void*)f_1656},
{"f_1638scheduler.scm",(void*)f_1638},
{"f_1654scheduler.scm",(void*)f_1654},
{"f_1646scheduler.scm",(void*)f_1646},
{"f_1650scheduler.scm",(void*)f_1650},
{"f_1277scheduler.scm",(void*)f_1277},
{"f_1338scheduler.scm",(void*)f_1338},
{"f_1281scheduler.scm",(void*)f_1281},
{"f_1284scheduler.scm",(void*)f_1284},
{"f_1274scheduler.scm",(void*)f_1274},
{"f_1271scheduler.scm",(void*)f_1271},
{"f_1268scheduler.scm",(void*)f_1268},
{"f_1262scheduler.scm",(void*)f_1262},
{"f_1200scheduler.scm",(void*)f_1200},
{"f_1237scheduler.scm",(void*)f_1237},
{"f_1240scheduler.scm",(void*)f_1240},
{"f_1243scheduler.scm",(void*)f_1243},
{"f_1246scheduler.scm",(void*)f_1246},
{"f_1256scheduler.scm",(void*)f_1256},
{"f_1249scheduler.scm",(void*)f_1249},
{"f_1224scheduler.scm",(void*)f_1224},
{"f_1228scheduler.scm",(void*)f_1228},
{"f_1204scheduler.scm",(void*)f_1204},
{"f_1210scheduler.scm",(void*)f_1210},
{"f_1188scheduler.scm",(void*)f_1188},
{"f_1139scheduler.scm",(void*)f_1139},
{"f_1143scheduler.scm",(void*)f_1143},
{"f_1172scheduler.scm",(void*)f_1172},
{"f_1161scheduler.scm",(void*)f_1161},
{"f_1101scheduler.scm",(void*)f_1101},
{"f_1038scheduler.scm",(void*)f_1038},
{"f_1053scheduler.scm",(void*)f_1053},
{"f_1063scheduler.scm",(void*)f_1063},
{"f_1042scheduler.scm",(void*)f_1042},
{"f_1013scheduler.scm",(void*)f_1013},
{"f_1031scheduler.scm",(void*)f_1031},
{"f_1017scheduler.scm",(void*)f_1017},
{"f_912scheduler.scm",(void*)f_912},
{"f_922scheduler.scm",(void*)f_922},
{"f_909scheduler.scm",(void*)f_909},
{"f_901scheduler.scm",(void*)f_901},
{"f_680scheduler.scm",(void*)f_680},
{"f_710scheduler.scm",(void*)f_710},
{"f_715scheduler.scm",(void*)f_715},
{"f_794scheduler.scm",(void*)f_794},
{"f_846scheduler.scm",(void*)f_846},
{"f_1573scheduler.scm",(void*)f_1573},
{"f_1624scheduler.scm",(void*)f_1624},
{"f_1595scheduler.scm",(void*)f_1595},
{"f_1571scheduler.scm",(void*)f_1571},
{"f_829scheduler.scm",(void*)f_829},
{"f_832scheduler.scm",(void*)f_832},
{"f_719scheduler.scm",(void*)f_719},
{"f_1536scheduler.scm",(void*)f_1536},
{"f_1420scheduler.scm",(void*)f_1420},
{"f_1521scheduler.scm",(void*)f_1521},
{"f_1451scheduler.scm",(void*)f_1451},
{"f_1491scheduler.scm",(void*)f_1491},
{"f_1481scheduler.scm",(void*)f_1481},
{"f_1418scheduler.scm",(void*)f_1418},
{"f_1399scheduler.scm",(void*)f_1399},
{"f_722scheduler.scm",(void*)f_722},
{"f_727scheduler.scm",(void*)f_727},
{"f_946scheduler.scm",(void*)f_946},
{"f_731scheduler.scm",(void*)f_731},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
