/* Generated from scheduler.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2007-10-25 22:02
   Version 2.713 - macosx-unix-gnu-ppc - [ manyargs dload ptables applyhook ]
(c)2000-2007 Felix L. Winkelmann | compiled 2007-09-29 on o3184.o.pppool.de (Darwin)
   command line: scheduler.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file scheduler.c
   unit: scheduler
*/

#include "chicken.h"

#ifdef HAVE_ERRNO_H
# include <errno.h>
# define C_signal_interrupted_p     C_mk_bool(errno == EINTR)
#else
# define C_signal_interrupted_p     C_SCHEME_FALSE
#endif

#ifdef _WIN32
# if _MSC_VER > 1300
# include <winsock2.h>
# include <ws2tcpip.h>
# else
# include <winsock.h>
# endif
/* Beware: winsock2.h must come BEFORE windows.h */
# define C_msleep(n)     (Sleep(C_unfix(n)), C_SCHEME_TRUE)
#else
# include <unistd.h>
# include <sys/types.h>
# include <sys/time.h>
# include <time.h>
static C_word C_msleep(C_word ms);
C_word C_msleep(C_word ms) {
#ifdef __CYGWIN__
  if(usleep(C_unfix(ms) * 1000) == -1) return C_SCHEME_FALSE;
#else
  struct timespec ts;
  unsigned long mss = C_unfix(ms);
  ts.tv_sec = mss / 1000;
  ts.tv_nsec = (mss % 1000) * 1000000;
  
  if(nanosleep(&ts, NULL) == -1) return C_SCHEME_FALSE;
#endif
  return C_SCHEME_TRUE;
}
#endif
static fd_set C_fdset_input, C_fdset_output, C_fdset_input_2, C_fdset_output_2;
#define C_fd_test_input(fd)  C_mk_bool(FD_ISSET(C_unfix(fd), &C_fdset_input))
#define C_fd_test_output(fd)  C_mk_bool(FD_ISSET(C_unfix(fd), &C_fdset_output))

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[116];


/* from ##sys#fdset-clear in k855 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub134(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub134(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
FD_CLR(fd, &C_fdset_input_2);FD_CLR(fd, &C_fdset_output_2);
C_ret:
#undef return

return C_r;}

/* from ##sys#fdset-output-set in k855 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub130(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub130(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
FD_SET(fd, &C_fdset_output);
C_ret:
#undef return

return C_r;}

/* from ##sys#fdset-input-set in k855 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub126(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub126(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
FD_SET(fd, &C_fdset_input);
C_ret:
#undef return

return C_r;}

/* from f_1495 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub123(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub123(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
FD_ZERO(&C_fdset_input);FD_ZERO(&C_fdset_output);
C_ret:
#undef return

return C_r;}

/* from ##sys#fdset-restore */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub121(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub121(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_fdset_input = C_fdset_input_2;C_fdset_output = C_fdset_output_2;
C_ret:
#undef return

return C_r;}

/* from ##sys#fdset-select-timeout */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub117(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub117(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int to=(int )C_truep(C_a0);
unsigned long tm=(unsigned long )C_num_to_unsigned_long(C_a1);
struct timeval timeout;timeout.tv_sec = tm / 1000;timeout.tv_usec = (tm % 1000) * 1000;C_fdset_input_2 = C_fdset_input;C_fdset_output_2 = C_fdset_output;return(select(FD_SETSIZE, &C_fdset_input, &C_fdset_output, NULL, to ? &timeout : NULL));
C_ret:
#undef return

return C_r;}

C_noret_decl(C_scheduler_toplevel)
C_externexport void C_ccall C_scheduler_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1495)
static void C_ccall f_1495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_857)
static void C_ccall f_857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1439)
static void C_ccall f_1439(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1484)
static void C_ccall f_1484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1476)
static void C_ccall f_1476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1458)
static void C_ccall f_1458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1342)
static void C_ccall f_1342(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1357)
static void C_ccall f_1357(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1427)
static void C_ccall f_1427(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1361)
static void C_fcall f_1361(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1411)
static void C_ccall f_1411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1389)
static void C_ccall f_1389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1394)
static void C_ccall f_1394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1398)
static void C_ccall f_1398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1403)
static void C_ccall f_1403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1276)
static void C_ccall f_1276(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1287)
static void C_ccall f_1287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1299)
static void C_fcall f_1299(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1332)
static void C_ccall f_1332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1320)
static void C_ccall f_1320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1291)
static void C_ccall f_1291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1257)
static void C_ccall f_1257(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1247)
static void C_ccall f_1247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1229)
static void C_ccall f_1229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1245)
static void C_ccall f_1245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1237)
static void C_ccall f_1237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1241)
static void C_ccall f_1241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_868)
static void C_ccall f_868(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_929)
static void C_fcall f_929(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_872)
static void C_ccall f_872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_875)
static void C_fcall f_875(C_word t0,C_word t1) C_noret;
C_noret_decl(f_865)
static C_word C_fcall f_865(C_word t0);
C_noret_decl(f_862)
static C_word C_fcall f_862(C_word t0);
C_noret_decl(f_859)
static C_word C_fcall f_859(C_word t0);
C_noret_decl(f_853)
static C_word C_fcall f_853();
C_noret_decl(f_791)
static void C_ccall f_791(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_828)
static void C_ccall f_828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_831)
static void C_ccall f_831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_834)
static void C_ccall f_834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_837)
static void C_ccall f_837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_847)
static void C_ccall f_847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_840)
static void C_ccall f_840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_815)
static void C_ccall f_815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_819)
static void C_ccall f_819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_795)
static void C_ccall f_795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_801)
static void C_ccall f_801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_779)
static void C_ccall f_779(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_730)
static void C_ccall f_730(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_734)
static void C_ccall f_734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_763)
static void C_ccall f_763(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_752)
static void C_ccall f_752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_692)
static void C_ccall f_692(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_629)
static void C_ccall f_629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_644)
static void C_fcall f_644(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_654)
static void C_fcall f_654(C_word t0,C_word t1) C_noret;
C_noret_decl(f_633)
static void C_ccall f_633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_604)
static void C_ccall f_604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_622)
static void C_ccall f_622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_608)
static void C_ccall f_608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_503)
static void C_ccall f_503(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_513)
static void C_fcall f_513(C_word t0,C_word t1) C_noret;
C_noret_decl(f_500)
static void C_ccall f_500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_492)
static void C_fcall f_492(C_word t0) C_noret;
C_noret_decl(f_271)
static void C_ccall f_271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_301)
static void C_ccall f_301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_306)
static void C_fcall f_306(C_word t0,C_word t1) C_noret;
C_noret_decl(f_385)
static void C_fcall f_385(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_437)
static void C_fcall f_437(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1164)
static void C_fcall f_1164(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1215)
static void C_ccall f_1215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1186)
static void C_ccall f_1186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1162)
static void C_ccall f_1162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_420)
static void C_fcall f_420(C_word t0,C_word t1) C_noret;
C_noret_decl(f_423)
static void C_ccall f_423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_310)
static void C_ccall f_310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1127)
static void C_fcall f_1127(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1011)
static void C_fcall f_1011(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1112)
static void C_ccall f_1112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1042)
static void C_fcall f_1042(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1082)
static void C_fcall f_1082(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1072)
static void C_ccall f_1072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1009)
static void C_ccall f_1009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_990)
static void C_ccall f_990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_313)
static void C_ccall f_313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_318)
static void C_fcall f_318(C_word t0,C_word t1) C_noret;
C_noret_decl(f_537)
static void C_fcall f_537(C_word t0,C_word t1) C_noret;
C_noret_decl(f_322)
static void C_fcall f_322(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1361)
static void C_fcall trf_1361(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1361(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1361(t0,t1);}

C_noret_decl(trf_1299)
static void C_fcall trf_1299(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1299(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1299(t0,t1,t2);}

C_noret_decl(trf_929)
static void C_fcall trf_929(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_929(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_929(t0,t1,t2);}

C_noret_decl(trf_875)
static void C_fcall trf_875(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_875(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_875(t0,t1);}

C_noret_decl(trf_644)
static void C_fcall trf_644(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_644(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_644(t0,t1,t2,t3);}

C_noret_decl(trf_654)
static void C_fcall trf_654(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_654(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_654(t0,t1);}

C_noret_decl(trf_513)
static void C_fcall trf_513(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_513(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_513(t0,t1);}

C_noret_decl(trf_492)
static void C_fcall trf_492(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_492(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_492(t0);}

C_noret_decl(trf_306)
static void C_fcall trf_306(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_306(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_306(t0,t1);}

C_noret_decl(trf_385)
static void C_fcall trf_385(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_385(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_385(t0,t1,t2);}

C_noret_decl(trf_437)
static void C_fcall trf_437(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_437(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_437(t0,t1);}

C_noret_decl(trf_1164)
static void C_fcall trf_1164(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1164(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1164(t0,t1,t2);}

C_noret_decl(trf_420)
static void C_fcall trf_420(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_420(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_420(t0,t1);}

C_noret_decl(trf_1127)
static void C_fcall trf_1127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1127(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1127(t0,t1);}

C_noret_decl(trf_1011)
static void C_fcall trf_1011(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1011(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1011(t0,t1,t2,t3);}

C_noret_decl(trf_1042)
static void C_fcall trf_1042(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1042(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1042(t0,t1,t2);}

C_noret_decl(trf_1082)
static void C_fcall trf_1082(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1082(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1082(t0,t1);}

C_noret_decl(trf_318)
static void C_fcall trf_318(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_318(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_318(t0,t1);}

C_noret_decl(trf_537)
static void C_fcall trf_537(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_537(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_537(t0,t1);}

C_noret_decl(trf_322)
static void C_fcall trf_322(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_322(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_322(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_scheduler_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("scheduler_toplevel"));
C_check_nursery_minimum(44);
if(!C_demand(44)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(763)){
C_save(t1);
C_rereclaim2(763*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(44);
C_initialize_lf(lf,116);
lf[0]=C_h_intern(&lf[0],12,"\003sysschedule");
lf[1]=C_h_intern(&lf[1],18,"\003syscurrent-thread");
lf[2]=C_h_intern(&lf[2],17,"\003sysdynamic-winds");
lf[3]=C_h_intern(&lf[3],18,"\003sysstandard-input");
lf[4]=C_h_intern(&lf[4],19,"\003sysstandard-output");
lf[5]=C_h_intern(&lf[5],18,"\003sysstandard-error");
lf[6]=C_h_intern(&lf[6],29,"\003syscurrent-exception-handler");
lf[7]=C_h_intern(&lf[7],28,"\003syscurrent-parameter-vector");
lf[8]=C_h_intern(&lf[8],5,"ready");
lf[9]=C_h_intern(&lf[9],7,"running");
lf[11]=C_h_intern(&lf[11],11,"\003sysfd-list");
lf[12]=C_h_intern(&lf[12],15,"\003syssignal-hook");
lf[13]=C_h_intern(&lf[13],14,"\000runtime-error");
lf[14]=C_static_string(C_heaptop,8,"deadlock");
lf[17]=C_static_lambda_info(C_heaptop,7,"(loop2)");
lf[21]=C_h_intern(&lf[21],25,"\003systhread-basic-unblock!");
lf[22]=C_static_lambda_info(C_heaptop,18,"(loop2 threads174)");
lf[23]=C_static_lambda_info(C_heaptop,18,"(loop n163 lst164)");
lf[24]=C_h_intern(&lf[24],8,"\003sysdelq");
lf[25]=C_static_lambda_info(C_heaptop,13,"(loop lst185)");
lf[26]=C_static_lambda_info(C_heaptop,12,"(loop lst15)");
lf[27]=C_static_lambda_info(C_heaptop,7,"(loop1)");
lf[28]=C_h_intern(&lf[28],22,"\003sysadd-to-ready-queue");
lf[29]=C_static_lambda_info(C_heaptop,16,"(##sys#schedule)");
lf[30]=C_h_intern(&lf[30],19,"\003systhread-unblock!");
lf[31]=C_h_intern(&lf[31],21,"\003sysprimordial-thread");
lf[32]=C_static_lambda_info(C_heaptop,24,"(##sys#force-primordial)");
lf[33]=C_h_intern(&lf[33],15,"\003sysready-queue");
lf[34]=C_static_lambda_info(C_heaptop,19,"(##sys#ready-queue)");
lf[35]=C_static_lambda_info(C_heaptop,35,"(##sys#add-to-ready-queue thread35)");
lf[36]=C_h_intern(&lf[36],18,"\003sysinterrupt-hook");
lf[37]=C_static_lambda_info(C_heaptop,6,"(a621)");
lf[38]=C_static_lambda_info(C_heaptop,39,"(##sys#interrupt-hook reason58 state59)");
lf[39]=C_h_intern(&lf[39],29,"\003systhread-block-for-timeout!");
lf[40]=C_h_intern(&lf[40],7,"blocked");
lf[41]=C_static_lambda_info(C_heaptop,18,"(loop tl66 prev67)");
lf[42]=C_static_lambda_info(C_heaptop,42,"(##sys#thread-block-for-timeout! t63 tm64)");
lf[43]=C_h_intern(&lf[43],33,"\003systhread-block-for-termination!");
lf[44]=C_h_intern(&lf[44],4,"dead");
lf[45]=C_h_intern(&lf[45],10,"terminated");
lf[46]=C_static_lambda_info(C_heaptop,46,"(##sys#thread-block-for-termination! t74 t275)");
lf[47]=C_h_intern(&lf[47],16,"\003systhread-kill!");
lf[48]=C_static_lambda_info(C_heaptop,11,"(a762 t285)");
lf[49]=C_h_intern(&lf[49],12,"\003sysfor-each");
lf[50]=C_h_intern(&lf[50],19,"\003sysabandon-mutexes");
lf[51]=C_static_lambda_info(C_heaptop,28,"(##sys#thread-kill! t82 s83)");
lf[52]=C_static_lambda_info(C_heaptop,33,"(##sys#thread-basic-unblock! t92)");
lf[53]=C_h_intern(&lf[53],19,"print-error-message");
lf[54]=C_h_intern(&lf[54],7,"display");
lf[55]=C_h_intern(&lf[55],16,"print-call-chain");
lf[56]=C_h_intern(&lf[56],18,"open-output-string");
lf[57]=C_h_intern(&lf[57],17,"get-output-string");
lf[58]=C_h_intern(&lf[58],29,"\003sysdefault-exception-handler");
lf[59]=C_h_intern(&lf[59],10,"\003syssignal");
lf[60]=C_static_lambda_info(C_heaptop,6,"(a814)");
lf[61]=C_h_intern(&lf[61],20,"\003syswarnings-enabled");
lf[62]=C_static_string(C_heaptop,3,"): ");
lf[63]=C_static_string(C_heaptop,9,"Warning (");
lf[64]=C_static_lambda_info(C_heaptop,40,"(##sys#default-exception-handler arg100)");
lf[66]=C_static_lambda_info(C_heaptop,23,"(##sys#fdset-input-set)");
lf[68]=C_static_lambda_info(C_heaptop,24,"(##sys#fdset-output-set)");
lf[69]=C_static_lambda_info(C_heaptop,19,"(##sys#fdset-clear)");
lf[70]=C_h_intern(&lf[70],25,"\003systhread-block-for-i/o!");
lf[71]=C_h_intern(&lf[71],6,"\000input");
lf[72]=C_h_intern(&lf[72],7,"\000output");
lf[73]=C_h_intern(&lf[73],4,"\000all");
lf[74]=C_static_lambda_info(C_heaptop,13,"(loop lst141)");
lf[75]=C_static_lambda_info(C_heaptop,47,"(##sys#thread-block-for-i/o! t137 fd138 i/o139)");
lf[76]=C_h_intern(&lf[76],15,"\003sysall-threads");
lf[77]=C_h_intern(&lf[77],6,"append");
lf[78]=C_h_intern(&lf[78],7,"\003sysmap");
lf[79]=C_h_intern(&lf[79],3,"cdr");
lf[80]=C_static_lambda_info(C_heaptop,19,"(##sys#all-threads)");
lf[81]=C_h_intern(&lf[81],27,"\003sysfetch-and-clear-threads");
lf[82]=C_static_lambda_info(C_heaptop,31,"(##sys#fetch-and-clear-threads)");
lf[83]=C_h_intern(&lf[83],19,"\003sysrestore-threads");
lf[84]=C_static_lambda_info(C_heaptop,30,"(##sys#restore-threads vec198)");
lf[85]=C_static_lambda_info(C_heaptop,13,"(loop fdl204)");
lf[86]=C_static_lambda_info(C_heaptop,28,"(##sys#thread-unblock! t202)");
lf[87]=C_h_intern(&lf[87],15,"\003sysbreak-entry");
lf[88]=C_h_intern(&lf[88],19,"\003sysbreak-in-thread");
lf[89]=C_h_intern(&lf[89],9,"condition");
tmp=C_intern(C_heaptop,3,"exn");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"breakpoint");
C_save(tmp);
lf[90]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[91]=C_h_intern(&lf[91],19,"\003syslast-breakpoint");
lf[92]=C_h_intern(&lf[92],9,"suspended");
lf[93]=C_static_lambda_info(C_heaptop,7,"(a1402)");
lf[94]=C_static_lambda_info(C_heaptop,7,"(a1393)");
tmp=C_intern(C_heaptop,3,"exn");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"message");
lf[95]=C_h_pair(C_restore,tmp);
lf[96]=C_static_string(C_heaptop,18,"*** breakpoint ***");
tmp=C_intern(C_heaptop,3,"exn");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"arguments");
lf[97]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,3,"exn");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"location");
lf[98]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,3,"exn");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"continuation");
lf[99]=C_h_pair(C_restore,tmp);
lf[100]=C_static_lambda_info(C_heaptop,14,"(a1426 . _216)");
tmp=C_intern(C_heaptop,3,"exn");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"thread");
lf[101]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,3,"exn");
C_save(tmp);
tmp=C_intern(C_heaptop,23,"primordial-continuation");
lf[102]=C_h_pair(C_restore,tmp);
lf[103]=C_static_lambda_info(C_heaptop,12,"(a1356 k214)");
lf[104]=C_static_lambda_info(C_heaptop,35,"(##sys#break-entry name210 args211)");
lf[105]=C_h_intern(&lf[105],16,"\003sysbreak-resume");
tmp=C_intern(C_heaptop,3,"exn");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"continuation");
lf[106]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,3,"exn");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"thread");
lf[107]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,3,"exn");
C_save(tmp);
tmp=C_intern(C_heaptop,23,"primordial-continuation");
lf[108]=C_h_pair(C_restore,tmp);
lf[109]=C_h_intern(&lf[109],11,"\000type-error");
lf[110]=C_static_string(C_heaptop,29,"condition has no continuation");
lf[111]=C_static_lambda_info(C_heaptop,7,"(a1483)");
lf[112]=C_static_string(C_heaptop,29,"condition has no continuation");
lf[113]=C_static_lambda_info(C_heaptop,27,"(##sys#break-resume exn225)");
lf[114]=C_static_lambda_info(C_heaptop,8,"(f_1495)");
lf[115]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf2(lf,116,create_ptable());
t2=C_mutate((C_word*)lf[0]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_271,a[2]=lf[29],tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[18],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_492,a[2]=lf[32],tmp=(C_word)a,a+=3,tmp));
t4=lf[15]=C_SCHEME_END_OF_LIST;;
t5=lf[16]=C_SCHEME_END_OF_LIST;;
t6=C_mutate((C_word*)lf[33]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_500,a[2]=lf[34],tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[28]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_503,a[2]=lf[35],tmp=(C_word)a,a+=3,tmp));
t8=*((C_word*)lf[36]+1);
t9=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_604,a[2]=t8,a[3]=lf[38],tmp=(C_word)a,a+=4,tmp));
t10=lf[10]=C_SCHEME_END_OF_LIST;;
t11=C_mutate((C_word*)lf[39]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_629,a[2]=lf[42],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[43]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_692,a[2]=lf[46],tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[47]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_730,a[2]=lf[51],tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[21]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_779,a[2]=lf[52],tmp=(C_word)a,a+=3,tmp));
t15=*((C_word*)lf[53]+1);
t16=*((C_word*)lf[54]+1);
t17=*((C_word*)lf[55]+1);
t18=*((C_word*)lf[56]+1);
t19=*((C_word*)lf[57]+1);
t20=C_mutate((C_word*)lf[58]+1,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_791,a[2]=t18,a[3]=t16,a[4]=t19,a[5]=t15,a[6]=t17,a[7]=lf[64],tmp=(C_word)a,a+=8,tmp));
t21=C_set_block_item(lf[11],0,C_SCHEME_END_OF_LIST);
t22=C_mutate(&lf[19],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_853,tmp=(C_word)a,a+=2,tmp));
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_857,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1495,a[2]=lf[114],tmp=(C_word)a,a+=3,tmp);
((C_proc2)(void*)(*((C_word*)t24+1)))(2,t24,t23);}

/* f_1495 */
static void C_ccall f_1495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1495,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub123(C_SCHEME_UNDEFINED));}

/* k855 */
static void C_ccall f_857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_857,2,t0,t1);}
t2=C_mutate(&lf[65],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_859,a[2]=lf[66],tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[67],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_862,a[2]=lf[68],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[20],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_865,a[2]=lf[69],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[70]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_868,a[2]=lf[75],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[76]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1229,a[2]=lf[80],tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[81]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1247,a[2]=lf[82],tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1257,a[2]=lf[84],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[30]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1276,a[2]=lf[86],tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[87]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1342,a[2]=lf[104],tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[105]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1439,a[2]=lf[113],tmp=(C_word)a,a+=3,tmp));
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}

/* ##sys#break-resume in k855 */
static void C_ccall f_1439(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1439,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(2));
t4=(C_word)C_i_member(lf[106],t3);
t5=(C_word)C_i_member(lf[107],t3);
t6=(C_word)C_i_member(lf[108],t3);
t7=(C_truep(t6)?t6:t4);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1458,a[2]=t2,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t9=(C_word)C_u_i_cadr(t5);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1476,a[2]=t9,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1484,a[2]=t4,a[3]=lf[111],tmp=(C_word)a,a+=4,tmp);
t12=t10;
f_1476(2,t12,(C_word)C_i_setslot(t9,C_fix(1),t11));}
else{
/* scheduler.scm: 508  ##sys#signal-hook */
t11=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t10,lf[109],lf[112],t2);}}
else{
t9=t8;
f_1458(2,t9,C_SCHEME_UNDEFINED);}}

/* a1483 in ##sys#break-resume in k855 */
static void C_ccall f_1484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1484,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,C_SCHEME_UNDEFINED);}

/* k1474 in ##sys#break-resume in k855 */
static void C_ccall f_1476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 509  ##sys#add-to-ready-queue */
t2=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1456 in ##sys#break-resume in k855 */
static void C_ccall f_1458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],C_SCHEME_UNDEFINED);}
else{
/* scheduler.scm: 512  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[109],lf[110],((C_word*)t0)[2]);}}

/* ##sys#break-entry in k855 */
static void C_ccall f_1342(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1342,4,t0,t1,t2,t3);}
t4=(C_word)C_i_not(*((C_word*)lf[88]+1));
t5=(C_truep(t4)?t4:(C_word)C_eqp(*((C_word*)lf[88]+1),*((C_word*)lf[1]+1)));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1357,a[2]=t3,a[3]=t2,a[4]=lf[103],tmp=(C_word)a,a+=5,tmp);
/* scheduler.scm: 467  ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* a1356 in ##sys#break-entry in k855 */
static void C_ccall f_1357(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1357,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1361,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(*((C_word*)lf[1]+1),*((C_word*)lf[31]+1));
if(C_truep(t4)){
t5=t3;
f_1361(t5,C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1427,a[2]=lf[100],tmp=(C_word)a,a+=3,tmp);
t6=t3;
f_1361(t6,(C_word)C_a_i_list(&a,4,lf[101],*((C_word*)lf[1]+1),lf[102],t5));}}

/* a1426 in a1356 in ##sys#break-entry in k855 */
static void C_ccall f_1427(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1427,2,t0,t1);}
t2=(C_word)C_slot(*((C_word*)lf[31]+1),C_fix(1));
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k1359 in a1356 in ##sys#break-entry in k855 */
static void C_fcall f_1361(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1361,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1411,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t4=(C_word)C_a_i_list(&a,8,lf[95],lf[96],lf[97],t3,lf[98],((C_word*)t0)[3],lf[99],((C_word*)t0)[4]);
/* scheduler.scm: 477  append */
t5=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t4,t1);}

/* k1409 in k1359 in a1356 in ##sys#break-entry in k855 */
static void C_ccall f_1411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1411,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,3,lf[89],lf[90],t1);
t3=C_mutate((C_word*)lf[91]+1,t2);
t4=(C_word)C_eqp(*((C_word*)lf[1]+1),*((C_word*)lf[31]+1));
if(C_truep(t4)){
/* scheduler.scm: 485  ##sys#signal */
t5=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,((C_word*)t0)[3],t2);}
else{
t5=(C_word)C_i_setslot(*((C_word*)lf[1]+1),C_fix(3),lf[92]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1403,a[2]=((C_word*)t0)[2],a[3]=lf[93],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_setslot(*((C_word*)lf[1]+1),C_fix(1),t6);
t8=(C_word)C_slot(*((C_word*)lf[31]+1),C_fix(1));
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1394,a[2]=t2,a[3]=t8,a[4]=lf[94],tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_i_setslot(*((C_word*)lf[31]+1),C_fix(1),t9);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1389,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* scheduler.scm: 495  ##sys#thread-unblock! */
t12=*((C_word*)lf[30]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,*((C_word*)lf[31]+1));}}

/* k1387 in k1409 in k1359 in a1356 in ##sys#break-entry in k855 */
static void C_ccall f_1389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 496  ##sys#schedule */
t2=*((C_word*)lf[0]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a1393 in k1409 in k1359 in a1356 in ##sys#break-entry in k855 */
static void C_ccall f_1394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1398,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* scheduler.scm: 493  ##sys#signal */
t3=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1396 in a1393 in k1409 in k1359 in a1356 in ##sys#break-entry in k855 */
static void C_ccall f_1398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 494  old */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a1402 in k1409 in k1359 in a1356 in ##sys#break-entry in k855 */
static void C_ccall f_1403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1403,2,t0,t1);}
/* scheduler.scm: 488  k */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* ##sys#thread-unblock! in k855 */
static void C_ccall f_1276(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1276,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_eqp(lf[40],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1287,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* scheduler.scm: 449  ##sys#delq */
t6=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[10]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k1285 in ##sys#thread-unblock! in k855 */
static void C_ccall f_1287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1287,2,t0,t1);}
t2=C_mutate(&lf[10],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1291,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1299,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=lf[85],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1299(t7,t3,*((C_word*)lf[11]+1));}

/* loop in k1285 in ##sys#thread-unblock! in k855 */
static void C_fcall f_1299(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1299,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1332,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(t3,C_fix(1));
/* scheduler.scm: 457  ##sys#delq */
t7=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}}

/* k1330 in loop in k1285 in ##sys#thread-unblock! in k855 */
static void C_ccall f_1332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1332,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1320,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* scheduler.scm: 458  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1299(t5,t3,t4);}

/* k1318 in k1330 in loop in k1285 in ##sys#thread-unblock! in k855 */
static void C_ccall f_1320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1320,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1289 in k1285 in ##sys#thread-unblock! in k855 */
static void C_ccall f_1291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate((C_word*)lf[11]+1,t1);
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[3],C_fix(12),C_SCHEME_END_OF_LIST);
/* scheduler.scm: 460  ##sys#thread-basic-unblock! */
t4=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* ##sys#restore-threads in k855 */
static void C_ccall f_1257(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1257,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=C_mutate(&lf[15],t3);
t5=(C_word)C_slot(t2,C_fix(1));
t6=C_mutate(&lf[16],t5);
t7=(C_word)C_slot(t2,C_fix(2));
t8=C_mutate((C_word*)lf[11]+1,t7);
t9=(C_word)C_slot(t2,C_fix(3));
t10=C_mutate(&lf[10],t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}

/* ##sys#fetch-and-clear-threads in k855 */
static void C_ccall f_1247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1247,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,4,lf[15],lf[16],*((C_word*)lf[11]+1),lf[10]);
t3=lf[15]=C_SCHEME_END_OF_LIST;;
t4=lf[16]=C_SCHEME_END_OF_LIST;;
t5=C_set_block_item(lf[11],0,C_SCHEME_END_OF_LIST);
t6=lf[10]=C_SCHEME_END_OF_LIST;;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t2);}

/* ##sys#all-threads in k855 */
static void C_ccall f_1229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1237,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1245,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[79]+1),*((C_word*)lf[11]+1));}

/* k1243 in ##sys#all-threads in k855 */
static void C_ccall f_1245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[77]+1),t1);}

/* k1235 in ##sys#all-threads in k855 */
static void C_ccall f_1237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1241,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[79]+1),lf[10]);}

/* k1239 in k1235 in ##sys#all-threads in k855 */
static void C_ccall f_1241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 420  append */
t2=*((C_word*)lf[77]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[15],((C_word*)t0)[2],t1);}

/* ##sys#thread-block-for-i/o! in k855 */
static void C_ccall f_868(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_868,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_872,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_929,a[2]=t7,a[3]=t2,a[4]=t3,a[5]=lf[74],tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_929(t9,t5,*((C_word*)lf[11]+1));}

/* loop in ##sys#thread-block-for-i/o! in k855 */
static void C_fcall f_929(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_929,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t3,*((C_word*)lf[11]+1));
t5=C_mutate((C_word*)lf[11]+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_u_i_car(t3);
t5=(C_word)C_eqp(((C_word*)t0)[4],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(t3,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_setslot(t3,C_fix(1),t7));}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* scheduler.scm: 341  loop */
t13=t1;
t14=t6;
t1=t13;
t2=t14;
goto loop;}}}

/* k870 in ##sys#thread-block-for-i/o! in k855 */
static void C_ccall f_872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_872,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_875,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,C_SCHEME_TRUE);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t2,lf[71]));
if(C_truep(t5)){
/* scheduler.scm: 343  ##sys#fdset-input-set */
t6=t3;
f_875(t6,f_859(((C_word*)t0)[3]));}
else{
t6=(C_word)C_eqp(t2,C_SCHEME_FALSE);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t2,lf[72]));
if(C_truep(t7)){
/* scheduler.scm: 344  ##sys#fdset-output-set */
t8=t3;
f_875(t8,f_862(((C_word*)t0)[3]));}
else{
t8=(C_word)C_eqp(t2,lf[73]);
if(C_truep(t8)){
t9=f_859(((C_word*)t0)[3]);
/* scheduler.scm: 347  ##sys#fdset-output-set */
t10=t3;
f_875(t10,f_862(((C_word*)t0)[3]));}
else{
t9=t3;
f_875(t9,C_SCHEME_UNDEFINED);}}}}

/* k873 in k870 in ##sys#thread-block-for-i/o! in k855 */
static void C_fcall f_875(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_875,NULL,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(3),lf[40]);
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[5],C_fix(13),C_SCHEME_FALSE);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(11),t4));}

/* ##sys#fdset-clear in k855 */
static C_word C_fcall f_865(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub134(C_SCHEME_UNDEFINED,t1));}

/* ##sys#fdset-output-set in k855 */
static C_word C_fcall f_862(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub130(C_SCHEME_UNDEFINED,t1));}

/* ##sys#fdset-input-set in k855 */
static C_word C_fcall f_859(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub126(C_SCHEME_UNDEFINED,t1));}

/* ##sys#fdset-restore */
static C_word C_fcall f_853(){
C_word tmp;
C_word t1;
return((C_word)stub121(C_SCHEME_UNDEFINED));}

/* ##sys#default-exception-handler */
static void C_ccall f_791(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_791,3,t0,t1,t2);}
t3=*((C_word*)lf[1]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_795,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_mk_bool(C_abort_on_thread_exceptions))){
t5=*((C_word*)lf[31]+1);
t6=(C_word)C_slot(t5,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_815,a[2]=t2,a[3]=t6,a[4]=lf[60],tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_setslot(t5,C_fix(1),t7);
/* scheduler.scm: 285  ##sys#thread-unblock! */
t9=*((C_word*)lf[30]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t4,t5);}
else{
if(C_truep(*((C_word*)lf[61]+1))){
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_828,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t4,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* scheduler.scm: 287  open-output-string */
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t4;
f_795(2,t5,C_SCHEME_UNDEFINED);}}}

/* k826 in ##sys#default-exception-handler */
static void C_ccall f_828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_831,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* scheduler.scm: 288  display */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[63],t1);}

/* k829 in k826 in ##sys#default-exception-handler */
static void C_ccall f_831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_834,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* scheduler.scm: 289  display */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[7],((C_word*)t0)[3]);}

/* k832 in k829 in k826 in ##sys#default-exception-handler */
static void C_ccall f_834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_837,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* scheduler.scm: 290  display */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[62],((C_word*)t0)[3]);}

/* k835 in k832 in k829 in k826 in ##sys#default-exception-handler */
static void C_ccall f_837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_840,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_847,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* scheduler.scm: 291  get-output-string */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k845 in k835 in k832 in k829 in k826 in ##sys#default-exception-handler */
static void C_ccall f_847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 291  print-error-message */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[5]+1),t1);}

/* k838 in k835 in k832 in k829 in k826 in ##sys#default-exception-handler */
static void C_ccall f_840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 292  print-call-chain */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[5]+1),C_fix(0),((C_word*)t0)[2]);}

/* a814 in ##sys#default-exception-handler */
static void C_ccall f_815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_819,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* scheduler.scm: 283  ##sys#signal */
t3=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k817 in a814 in ##sys#default-exception-handler */
static void C_ccall f_819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 284  ptx */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k793 in ##sys#default-exception-handler */
static void C_ccall f_795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_795,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(7),((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_801,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* scheduler.scm: 294  ##sys#thread-kill! */
t4=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],lf[45]);}

/* k799 in k793 in ##sys#default-exception-handler */
static void C_ccall f_801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 295  ##sys#schedule */
t2=*((C_word*)lf[0]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##sys#thread-basic-unblock! */
static void C_ccall f_779(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_779,3,t0,t1,t2);}
t3=(C_word)C_i_set_i_slot(t2,C_fix(11),C_SCHEME_FALSE);
t4=(C_word)C_i_set_i_slot(t2,C_fix(4),C_SCHEME_FALSE);
/* scheduler.scm: 266  ##sys#add-to-ready-queue */
t5=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t2);}

/* ##sys#thread-kill! */
static void C_ccall f_730(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_730,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_734,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* scheduler.scm: 247  ##sys#abandon-mutexes */
t5=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k732 in ##sys#thread-kill! */
static void C_ccall f_734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_734,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),((C_word*)t0)[3]);
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(4),C_SCHEME_FALSE);
t4=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(11),C_SCHEME_FALSE);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(8),C_SCHEME_END_OF_LIST);
t6=(C_word)C_slot(((C_word*)t0)[4],C_fix(12));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_752,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t6))){
t8=t7;
f_752(2,t8,C_SCHEME_UNDEFINED);}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_763,a[2]=((C_word*)t0)[4],a[3]=lf[48],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t9=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,t6);}}

/* a762 in k732 in ##sys#thread-kill! */
static void C_ccall f_763(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_763,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(11));
t4=(C_word)C_eqp(t3,((C_word*)t0)[2]);
if(C_truep(t4)){
/* scheduler.scm: 258  ##sys#thread-basic-unblock! */
t5=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t2);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k750 in k732 in ##sys#thread-kill! */
static void C_ccall f_752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(12),C_SCHEME_END_OF_LIST));}

/* ##sys#thread-block-for-termination! */
static void C_ccall f_692(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_692,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_eqp(t4,lf[44]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(t4,lf[45]));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}
else{
t7=(C_word)C_slot(t3,C_fix(12));
t8=(C_word)C_a_i_cons(&a,2,t2,t7);
t9=(C_word)C_i_setslot(t3,C_fix(12),t8);
t10=(C_word)C_i_setslot(t2,C_fix(3),lf[40]);
t11=(C_word)C_i_set_i_slot(t2,C_fix(13),C_SCHEME_FALSE);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_i_setslot(t2,C_fix(11),t3));}}

/* ##sys#thread-block-for-timeout! */
static void C_ccall f_629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_629,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_633,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_644,a[2]=t6,a[3]=t2,a[4]=t3,a[5]=lf[41],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_644(t8,t4,lf[10],C_SCHEME_FALSE);}

/* loop in ##sys#thread-block-for-timeout! */
static void C_fcall f_644(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_644,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_nullp(t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_654,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
t6=t5;
f_654(t6,t4);}
else{
t6=(C_word)C_u_i_caar(t2);
t7=((C_word*)t0)[4];
t8=t5;
f_654(t8,(C_word)C_fixnum_lessp(t7,t6));}}

/* k652 in loop in ##sys#thread-block-for-timeout! */
static void C_fcall f_654(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_654,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[7])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_setslot(((C_word*)t0)[7],C_fix(1),t3));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=C_mutate(&lf[10],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* scheduler.scm: 231  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_644(t3,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}}

/* k631 in ##sys#thread-block-for-timeout! */
static void C_ccall f_633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),lf[40]);
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(13),C_SCHEME_FALSE);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(4),((C_word*)t0)[2]));}

/* ##sys#interrupt-hook */
static void C_ccall f_604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_604,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_608,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(t2,C_fix(255));
if(C_truep(t5)){
t6=*((C_word*)lf[1]+1);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_622,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=lf[37],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_setslot(t6,C_fix(1),t7);
/* scheduler.scm: 218  ##sys#schedule */
t9=*((C_word*)lf[0]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t4);}
else{
t6=t4;
f_608(2,t6,C_SCHEME_UNDEFINED);}}

/* a621 in ##sys#interrupt-hook */
static void C_ccall f_622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_622,2,t0,t1);}
/* scheduler.scm: 217  oldhook */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k606 in ##sys#interrupt-hook */
static void C_ccall f_608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 219  oldhook */
t2=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#add-to-ready-queue */
static void C_ccall f_503(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_503,3,t0,t1,t2);}
t3=(C_word)C_i_setslot(t2,C_fix(3),lf[8]);
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_513,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(C_SCHEME_END_OF_LIST,lf[15]);
if(C_truep(t6)){
t7=C_mutate(&lf[15],t4);
t8=t5;
f_513(t8,t7);}
else{
t7=t5;
f_513(t7,(C_word)C_i_setslot(lf[16],C_fix(1),t4));}}

/* k511 in ##sys#add-to-ready-queue */
static void C_fcall f_513(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[16],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##sys#ready-queue */
static void C_ccall f_500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_500,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[15]);}

/* ##sys#force-primordial */
static void C_fcall f_492(C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_492,NULL,1,t1);}
/* scheduler.scm: 171  ##sys#thread-unblock! */
t2=*((C_word*)lf[30]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,*((C_word*)lf[31]+1));}

/* ##sys#schedule */
static void C_ccall f_271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_271,2,t0,t1);}
t2=*((C_word*)lf[1]+1);
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_slot(t2,C_fix(3));
t6=(C_word)C_slot(t2,C_fix(5));
t7=(C_word)C_i_setslot(t6,C_fix(0),*((C_word*)lf[2]+1));
t8=(C_word)C_i_setslot(t6,C_fix(1),*((C_word*)lf[3]+1));
t9=(C_word)C_i_setslot(t6,C_fix(2),*((C_word*)lf[4]+1));
t10=(C_word)C_i_setslot(t6,C_fix(3),*((C_word*)lf[5]+1));
t11=(C_word)C_i_setslot(t6,C_fix(4),*((C_word*)lf[6]+1));
t12=(C_word)C_i_setslot(t6,C_fix(5),*((C_word*)lf[7]+1));
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_301,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_eqp(t5,lf[9]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t5,lf[8]));
if(C_truep(t15)){
t16=(C_word)C_i_set_i_slot(t2,C_fix(13),C_SCHEME_FALSE);
/* scheduler.scm: 119  ##sys#add-to-ready-queue */
t17=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t13,t2);}
else{
t16=t13;
f_301(2,t16,C_SCHEME_UNDEFINED);}}

/* k299 in ##sys#schedule */
static void C_ccall f_301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_301,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_306,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=lf[27],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_306(t5,((C_word*)t0)[2]);}

/* loop1 in k299 in ##sys#schedule */
static void C_fcall f_306(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_306,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_310,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(lf[10]))){
t3=t2;
f_310(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_fudge(C_fix(16));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_385,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t3,a[5]=lf[26],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_385(t7,t2,lf[10]);}}

/* loop in loop1 in k299 in ##sys#schedule */
static void C_fcall f_385(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
loop:
a=C_alloc(22);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_385,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=lf[10]=C_SCHEME_END_OF_LIST;;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(C_word)C_u_i_caar(t2);
t4=(C_word)C_u_i_cdar(t2);
t5=(C_word)C_slot(t4,C_fix(4));
t6=(C_word)C_eqp(t3,t5);
if(C_truep(t6)){
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)t0)[4],t3))){
t7=(C_word)C_i_set_i_slot(t4,C_fix(13),C_SCHEME_TRUE);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_420,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_slot(t4,C_fix(11));
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_slot(t4,C_fix(11));
t11=(C_word)C_slot(t10,C_fix(0));
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1162,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1164,a[2]=t14,a[3]=t4,a[4]=t11,a[5]=lf[25],tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_1164(t16,t12,*((C_word*)lf[11]+1));}
else{
t10=t8;
f_420(t10,C_SCHEME_UNDEFINED);}}
else{
t7=C_mutate(&lf[10],t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_437,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(lf[15]))){
t9=(C_word)C_i_nullp(*((C_word*)lf[11]+1));
t10=t8;
f_437(t10,(C_truep(t9)?(C_word)C_i_pairp(lf[10]):C_SCHEME_FALSE));}
else{
t9=t8;
f_437(t9,C_SCHEME_FALSE);}}}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* scheduler.scm: 152  loop */
t22=t1;
t23=t7;
t1=t22;
t2=t23;
goto loop;}}}

/* k435 in loop in loop1 in k299 in ##sys#schedule */
static void C_fcall f_437(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_caar(lf[10]);
t3=(C_word)C_u_fixnum_difference(t2,((C_word*)t0)[4]);
t4=(C_word)C_i_fixnum_max(C_fix(0),t3);
t5=(C_truep((C_word)C_msleep(t4))?C_SCHEME_FALSE:C_mk_bool(C_signal_interrupted_p));
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* loop in loop in loop1 in k299 in ##sys#schedule */
static void C_fcall f_1164(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1164,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[4],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1186,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(t3,C_fix(1));
/* scheduler.scm: 405  ##sys#delq */
t8=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[3],t7);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1215,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
/* scheduler.scm: 414  loop */
t11=t6;
t12=t7;
t1=t11;
t2=t12;
goto loop;}}}

/* k1213 in loop in loop in loop1 in k299 in ##sys#schedule */
static void C_ccall f_1215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1215,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1184 in loop in loop in loop1 in k299 in ##sys#schedule */
static void C_ccall f_1186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep((C_word)C_i_nullp(t1))){
t2=f_865(((C_word*)t0)[5]);
t3=f_853();
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[3],C_fix(1)));}
else{
t2=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1160 in loop in loop1 in k299 in ##sys#schedule */
static void C_ccall f_1162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[11]+1,t1);
t3=((C_word*)t0)[2];
f_420(t3,t2);}

/* k418 in loop in loop1 in k299 in ##sys#schedule */
static void C_fcall f_420(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_420,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_423,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* scheduler.scm: 138  ##sys#thread-basic-unblock! */
t3=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k421 in k418 in loop in loop1 in k299 in ##sys#schedule */
static void C_ccall f_423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* scheduler.scm: 139  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_385(t3,((C_word*)t0)[2],t2);}

/* k308 in loop1 in k299 in ##sys#schedule */
static void C_ccall f_310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_313,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
/* scheduler.scm: 155  ##sys#force-primordial */
f_492(t2);}
else{
if(C_truep((C_word)C_i_nullp(*((C_word*)lf[11]+1)))){
t3=t2;
f_313(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_pairp(lf[10]);
t4=(C_word)C_i_pairp(lf[15]);
t5=(C_truep(t4)?t4:t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1127,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?(C_word)C_i_not(t4):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_u_i_caar(lf[10]);
t9=(C_word)C_fudge(C_fix(16));
t10=(C_word)C_u_fixnum_difference(t8,t9);
t11=t6;
f_1127(t11,(C_word)C_i_fixnum_max(C_fix(0),t10));}
else{
t8=t6;
f_1127(t8,C_fix(0));}}}}

/* k1125 in k308 in loop1 in k299 in ##sys#schedule */
static void C_fcall f_1127(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1127,NULL,2,t0,t1);}
t2=(C_word)stub117(C_SCHEME_UNDEFINED,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_990,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* scheduler.scm: 365  ##sys#force-primordial */
f_492(t3);}
else{
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1009,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1011,a[2]=t7,a[3]=lf[23],tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_1011(t9,t5,t2,*((C_word*)lf[11]+1));}
else{
t5=t3;
f_990(2,t5,C_SCHEME_UNDEFINED);}}}

/* loop in k1125 in k308 in loop1 in k299 in ##sys#schedule */
static void C_fcall f_1011(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1011,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t3));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_u_i_car(t3);
t7=(C_word)C_u_i_car(t6);
t8=(C_word)C_fd_test_input(t7);
t9=(C_word)C_fd_test_output(t7);
t10=(C_truep(t8)?t8:t9);
if(C_truep(t10)){
t11=(C_word)C_slot(t6,C_fix(1));
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1042,a[2]=t13,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=t7,a[7]=lf[22],tmp=(C_word)a,a+=8,tmp));
t15=((C_word*)t13)[1];
f_1042(t15,t1,t11);}
else{
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1112,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_slot(t3,C_fix(1));
/* scheduler.scm: 389  loop */
t18=t11;
t19=t2;
t20=t12;
t1=t18;
t2=t19;
t3=t20;
goto loop;}}}

/* k1110 in loop in k1125 in k308 in loop1 in k299 in ##sys#schedule */
static void C_ccall f_1112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1112,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* loop2 in loop in k1125 in k308 in loop1 in k299 in ##sys#schedule */
static void C_fcall f_1042(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1042,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=f_865(((C_word*)t0)[6]);
t4=(C_word)C_u_fixnum_decrease(((C_word*)t0)[5]);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* scheduler.scm: 381  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1011(t6,t1,t4,t5);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t3,C_fix(11));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1072,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1082,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_u_i_car(t4);
t8=(C_word)C_eqp(((C_word*)t0)[6],t7);
if(C_truep(t8)){
t9=(C_word)C_slot(t3,C_fix(13));
t10=t6;
f_1082(t10,(C_word)C_i_not(t9));}
else{
t9=t6;
f_1082(t9,C_SCHEME_FALSE);}}
else{
t7=t6;
f_1082(t7,C_SCHEME_FALSE);}}}

/* k1080 in loop2 in loop in k1125 in k308 in loop1 in k299 in ##sys#schedule */
static void C_fcall f_1082(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* scheduler.scm: 387  ##sys#thread-basic-unblock! */
t2=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1072(2,t2,C_SCHEME_UNDEFINED);}}

/* k1070 in loop2 in loop in k1125 in k308 in loop1 in k299 in ##sys#schedule */
static void C_ccall f_1072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* scheduler.scm: 388  loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1042(t3,((C_word*)t0)[2],t2);}

/* k1007 in k1125 in k308 in loop1 in k299 in ##sys#schedule */
static void C_ccall f_1009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[11]+1,t1);
t3=((C_word*)t0)[2];
f_990(2,t3,t2);}

/* k988 in k1125 in k308 in loop1 in k299 in ##sys#schedule */
static void C_ccall f_990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 390  ##sys#fdset-restore */
t2=((C_word*)t0)[2];
f_313(2,t2,f_853());}

/* k311 in k308 in loop1 in k299 in ##sys#schedule */
static void C_ccall f_313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_313,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_318,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=lf[17],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_318(t5,((C_word*)t0)[2]);}

/* loop2 in k311 in k308 in loop1 in k299 in ##sys#schedule */
static void C_fcall f_318(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_318,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_322,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=lf[15];
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_322(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(1));
t5=C_mutate(&lf[15],t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_537,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t7)){
t8=lf[16]=C_SCHEME_END_OF_LIST;;
t9=t6;
f_537(t9,t8);}
else{
t8=t6;
f_537(t8,C_SCHEME_UNDEFINED);}}}

/* k535 in loop2 in k311 in k308 in loop1 in k299 in ##sys#schedule */
static void C_fcall f_537(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_322(t2,(C_word)C_u_i_car(((C_word*)t0)[2]));}

/* k320 in loop2 in k311 in k308 in loop1 in k299 in ##sys#schedule */
static void C_fcall f_322(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word *a;
t2=t1;
if(C_truep(t2)){
t3=(C_word)C_slot(t1,C_fix(3));
t4=(C_word)C_eqp(t3,lf[8]);
if(C_truep(t4)){
t5=((C_word*)t0)[4];
t6=t1;
t7=C_mutate((C_word*)lf[1]+1,t6);
t8=(C_word)C_i_setslot(t6,C_fix(3),lf[9]);
t9=(C_word)C_slot(t6,C_fix(5));
t10=(C_word)C_slot(t9,C_fix(0));
t11=C_mutate((C_word*)lf[2]+1,t10);
t12=(C_word)C_slot(t9,C_fix(1));
t13=C_mutate((C_word*)lf[3]+1,t12);
t14=(C_word)C_slot(t9,C_fix(2));
t15=C_mutate((C_word*)lf[4]+1,t14);
t16=(C_word)C_slot(t9,C_fix(3));
t17=C_mutate((C_word*)lf[5]+1,t16);
t18=(C_word)C_slot(t9,C_fix(4));
t19=C_mutate((C_word*)lf[6]+1,t18);
t20=(C_word)C_slot(t9,C_fix(5));
t21=C_mutate((C_word*)lf[7]+1,t20);
t22=(C_word)C_slot(t6,C_fix(9));
t23=(C_word)C_set_initial_timer_interrupt_period(t22);
t24=(C_word)C_slot(t6,C_fix(1));
t25=t24;
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,t5);}
else{
/* scheduler.scm: 167  loop2 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_318(t5,((C_word*)t0)[4]);}}
else{
t3=(C_word)C_i_nullp(lf[10]);
t4=(C_truep(t3)?(C_word)C_i_nullp(*((C_word*)lf[11]+1)):C_SCHEME_FALSE);
if(C_truep(t4)){
/* scheduler.scm: 164  ##sys#signal-hook */
t5=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[4],lf[13],lf[14]);}
else{
/* scheduler.scm: 165  loop1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_306(t5,((C_word*)t0)[4]);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[89] = {
{"toplevelscheduler.scm",(void*)C_scheduler_toplevel},
{"f_1495scheduler.scm",(void*)f_1495},
{"f_857scheduler.scm",(void*)f_857},
{"f_1439scheduler.scm",(void*)f_1439},
{"f_1484scheduler.scm",(void*)f_1484},
{"f_1476scheduler.scm",(void*)f_1476},
{"f_1458scheduler.scm",(void*)f_1458},
{"f_1342scheduler.scm",(void*)f_1342},
{"f_1357scheduler.scm",(void*)f_1357},
{"f_1427scheduler.scm",(void*)f_1427},
{"f_1361scheduler.scm",(void*)f_1361},
{"f_1411scheduler.scm",(void*)f_1411},
{"f_1389scheduler.scm",(void*)f_1389},
{"f_1394scheduler.scm",(void*)f_1394},
{"f_1398scheduler.scm",(void*)f_1398},
{"f_1403scheduler.scm",(void*)f_1403},
{"f_1276scheduler.scm",(void*)f_1276},
{"f_1287scheduler.scm",(void*)f_1287},
{"f_1299scheduler.scm",(void*)f_1299},
{"f_1332scheduler.scm",(void*)f_1332},
{"f_1320scheduler.scm",(void*)f_1320},
{"f_1291scheduler.scm",(void*)f_1291},
{"f_1257scheduler.scm",(void*)f_1257},
{"f_1247scheduler.scm",(void*)f_1247},
{"f_1229scheduler.scm",(void*)f_1229},
{"f_1245scheduler.scm",(void*)f_1245},
{"f_1237scheduler.scm",(void*)f_1237},
{"f_1241scheduler.scm",(void*)f_1241},
{"f_868scheduler.scm",(void*)f_868},
{"f_929scheduler.scm",(void*)f_929},
{"f_872scheduler.scm",(void*)f_872},
{"f_875scheduler.scm",(void*)f_875},
{"f_865scheduler.scm",(void*)f_865},
{"f_862scheduler.scm",(void*)f_862},
{"f_859scheduler.scm",(void*)f_859},
{"f_853scheduler.scm",(void*)f_853},
{"f_791scheduler.scm",(void*)f_791},
{"f_828scheduler.scm",(void*)f_828},
{"f_831scheduler.scm",(void*)f_831},
{"f_834scheduler.scm",(void*)f_834},
{"f_837scheduler.scm",(void*)f_837},
{"f_847scheduler.scm",(void*)f_847},
{"f_840scheduler.scm",(void*)f_840},
{"f_815scheduler.scm",(void*)f_815},
{"f_819scheduler.scm",(void*)f_819},
{"f_795scheduler.scm",(void*)f_795},
{"f_801scheduler.scm",(void*)f_801},
{"f_779scheduler.scm",(void*)f_779},
{"f_730scheduler.scm",(void*)f_730},
{"f_734scheduler.scm",(void*)f_734},
{"f_763scheduler.scm",(void*)f_763},
{"f_752scheduler.scm",(void*)f_752},
{"f_692scheduler.scm",(void*)f_692},
{"f_629scheduler.scm",(void*)f_629},
{"f_644scheduler.scm",(void*)f_644},
{"f_654scheduler.scm",(void*)f_654},
{"f_633scheduler.scm",(void*)f_633},
{"f_604scheduler.scm",(void*)f_604},
{"f_622scheduler.scm",(void*)f_622},
{"f_608scheduler.scm",(void*)f_608},
{"f_503scheduler.scm",(void*)f_503},
{"f_513scheduler.scm",(void*)f_513},
{"f_500scheduler.scm",(void*)f_500},
{"f_492scheduler.scm",(void*)f_492},
{"f_271scheduler.scm",(void*)f_271},
{"f_301scheduler.scm",(void*)f_301},
{"f_306scheduler.scm",(void*)f_306},
{"f_385scheduler.scm",(void*)f_385},
{"f_437scheduler.scm",(void*)f_437},
{"f_1164scheduler.scm",(void*)f_1164},
{"f_1215scheduler.scm",(void*)f_1215},
{"f_1186scheduler.scm",(void*)f_1186},
{"f_1162scheduler.scm",(void*)f_1162},
{"f_420scheduler.scm",(void*)f_420},
{"f_423scheduler.scm",(void*)f_423},
{"f_310scheduler.scm",(void*)f_310},
{"f_1127scheduler.scm",(void*)f_1127},
{"f_1011scheduler.scm",(void*)f_1011},
{"f_1112scheduler.scm",(void*)f_1112},
{"f_1042scheduler.scm",(void*)f_1042},
{"f_1082scheduler.scm",(void*)f_1082},
{"f_1072scheduler.scm",(void*)f_1072},
{"f_1009scheduler.scm",(void*)f_1009},
{"f_990scheduler.scm",(void*)f_990},
{"f_313scheduler.scm",(void*)f_313},
{"f_318scheduler.scm",(void*)f_318},
{"f_537scheduler.scm",(void*)f_537},
{"f_322scheduler.scm",(void*)f_322},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
