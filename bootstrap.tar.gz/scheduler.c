/* Generated from scheduler.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-11-07 15:21
   Version 4.0.0x1 - SVN rev. 12338
   linux-unix-gnu-x86 [ dload ptables applyhook ]
   compiled 2008-11-03 on dill (Linux)
   command line: scheduler.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -output-file scheduler.c
   unit: scheduler
*/

#include "chicken.h"

#ifdef HAVE_ERRNO_H
# include <errno.h>
# define C_signal_interrupted_p     C_mk_bool(errno == EINTR)
#else
# define C_signal_interrupted_p     C_SCHEME_FALSE
#endif

#ifdef _WIN32
# if _MSC_VER > 1300
# include <winsock2.h>
# include <ws2tcpip.h>
# else
# include <winsock.h>
# endif
/* Beware: winsock2.h must come BEFORE windows.h */
# define C_msleep(n)     (Sleep(C_unfix(n)), C_SCHEME_TRUE)
#else
# include <unistd.h>
# include <sys/types.h>
# include <sys/time.h>
# include <time.h>
static C_word C_msleep(C_word ms);
C_word C_msleep(C_word ms) {
#ifdef __CYGWIN__
  if(usleep(C_unfix(ms) * 1000) == -1) return C_SCHEME_FALSE;
#else
  struct timespec ts;
  unsigned long mss = C_unfix(ms);
  ts.tv_sec = mss / 1000;
  ts.tv_nsec = (mss % 1000) * 1000000;
  
  if(nanosleep(&ts, NULL) == -1) return C_SCHEME_FALSE;
#endif
  return C_SCHEME_TRUE;
}
#endif
static fd_set C_fdset_input, C_fdset_output, C_fdset_input_2, C_fdset_output_2;
#define C_fd_test_input(fd)  C_mk_bool(FD_ISSET(C_unfix(fd), &C_fdset_input))
#define C_fd_test_output(fd)  C_mk_bool(FD_ISSET(C_unfix(fd), &C_fdset_output))

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[78];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,7),40,108,111,111,112,50,41,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,50,32,116,104,114,101,97,100,115,52,54,54,41,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,110,52,51,57,32,108,115,116,52,52,48,41,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,52,57,55,41,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,108,115,116,56,56,41,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,7),40,108,111,111,112,49,41,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,16),40,35,35,115,121,115,35,115,99,104,101,100,117,108,101,41};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,24),40,35,35,115,121,115,35,102,111,114,99,101,45,112,114,105,109,111,114,100,105,97,108,41};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,19),40,35,35,115,121,115,35,114,101,97,100,121,45,113,117,101,117,101,41,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,36),40,35,35,115,121,115,35,97,100,100,45,116,111,45,114,101,97,100,121,45,113,117,101,117,101,32,116,104,114,101,97,100,49,53,50,41,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,7),40,97,49,48,56,56,41,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,41),40,35,35,115,121,115,35,105,110,116,101,114,114,117,112,116,45,104,111,111,107,32,114,101,97,115,111,110,50,48,51,32,115,116,97,116,101,50,48,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,112,114,101,118,50,50,49,41,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,37),40,35,35,115,121,115,35,114,101,109,111,118,101,45,102,114,111,109,45,116,105,109,101,111,117,116,45,108,105,115,116,32,116,50,49,54,41,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,116,108,50,51,53,32,112,114,101,118,50,51,54,41,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,44),40,35,35,115,121,115,35,116,104,114,101,97,100,45,98,108,111,99,107,45,102,111,114,45,116,105,109,101,111,117,116,33,32,116,50,51,48,32,116,109,50,51,49,41,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,48),40,35,35,115,121,115,35,116,104,114,101,97,100,45,98,108,111,99,107,45,102,111,114,45,116,101,114,109,105,110,97,116,105,111,110,33,32,116,50,53,49,32,116,50,50,53,50,41};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,13),40,97,49,50,55,51,32,116,50,50,55,54,41,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,30),40,35,35,115,121,115,35,116,104,114,101,97,100,45,107,105,108,108,33,32,116,50,54,57,32,115,50,55,48,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,116,104,114,101,97,100,45,98,97,115,105,99,45,117,110,98,108,111,99,107,33,32,116,50,56,57,41,0,0,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,7),40,97,49,51,50,53,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,40),40,35,35,115,121,115,35,100,101,102,97,117,108,116,45,101,120,99,101,112,116,105,111,110,45,104,97,110,100,108,101,114,32,97,114,103,51,48,48,41};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,23),40,35,35,115,121,115,35,102,100,115,101,116,45,105,110,112,117,116,45,115,101,116,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,24),40,35,35,115,121,115,35,102,100,115,101,116,45,111,117,116,112,117,116,45,115,101,116,41};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,19),40,35,35,115,121,115,35,102,100,115,101,116,45,99,108,101,97,114,41,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,51,55,53,41,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,47),40,35,35,115,121,115,35,116,104,114,101,97,100,45,98,108,111,99,107,45,102,111,114,45,105,47,111,33,32,116,51,54,57,32,102,100,51,55,48,32,105,47,111,51,55,49,41,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,108,53,54,51,41,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,108,53,54,57,32,105,53,55,48,41};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,108,53,53,54,32,105,53,53,55,41};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,108,53,53,49,32,105,53,53,50,41};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,24),40,98,111,100,121,53,51,54,32,99,110,115,53,52,54,32,105,110,105,116,53,52,55,41};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,24),40,100,101,102,45,105,110,105,116,53,51,57,32,37,99,110,115,53,51,52,53,56,48,41};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,38),40,97,49,56,54,54,32,113,117,101,117,101,53,56,53,32,97,114,103,53,56,54,32,118,97,108,53,56,55,32,105,110,105,116,53,56,56,41,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,99,110,115,53,51,56,41,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,97,108,108,45,116,104,114,101,97,100,115,32,46,32,116,109,112,53,50,54,53,50,55,41,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,102,101,116,99,104,45,97,110,100,45,99,108,101,97,114,45,116,104,114,101,97,100,115,41,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,30),40,35,35,115,121,115,35,114,101,115,116,111,114,101,45,116,104,114,101,97,100,115,32,118,101,99,54,49,48,41,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,102,100,108,54,50,51,41,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,28),40,35,35,115,121,115,35,116,104,114,101,97,100,45,117,110,98,108,111,99,107,33,32,116,54,49,55,41,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,7),40,97,50,48,54,54,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,7),40,97,50,48,53,55,41,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,14),40,97,50,48,57,48,32,46,32,95,54,52,57,41,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,12),40,97,50,48,50,48,32,107,54,52,53,41,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,98,114,101,97,107,45,101,110,116,114,121,32,110,97,109,101,54,51,52,32,97,114,103,115,54,51,53,41,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,7),40,97,50,49,52,55,41,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,27),40,35,35,115,121,115,35,98,114,101,97,107,45,114,101,115,117,109,101,32,101,120,110,54,55,52,41,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,8),40,102,95,50,49,53,57,41};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from ##sys#fdset-clear in k1366 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub363(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub363(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
FD_CLR(fd, &C_fdset_input_2);FD_CLR(fd, &C_fdset_output_2);
C_ret:
#undef return

return C_r;}

/* from ##sys#fdset-output-set in k1366 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub357(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub357(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
FD_SET(fd, &C_fdset_output);
C_ret:
#undef return

return C_r;}

/* from ##sys#fdset-input-set in k1366 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub351(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub351(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
FD_SET(fd, &C_fdset_input);
C_ret:
#undef return

return C_r;}

/* from f_2159 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub346(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub346(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
FD_ZERO(&C_fdset_input);FD_ZERO(&C_fdset_output);
C_ret:
#undef return

return C_r;}

/* from ##sys#fdset-restore */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub342(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub342(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_fdset_input = C_fdset_input_2;C_fdset_output = C_fdset_output_2;
C_ret:
#undef return

return C_r;}

/* from ##sys#fdset-select-timeout */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub336(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub336(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int to=(int )C_truep(C_a0);
unsigned long tm=(unsigned long )C_num_to_unsigned_long(C_a1);
struct timeval timeout;timeout.tv_sec = tm / 1000;timeout.tv_usec = (tm % 1000) * 1000;C_fdset_input_2 = C_fdset_input;C_fdset_output_2 = C_fdset_output;return(select(FD_SETSIZE, &C_fdset_input, &C_fdset_output, NULL, to ? &timeout : NULL));
C_ret:
#undef return

return C_r;}

C_noret_decl(C_scheduler_toplevel)
C_externexport void C_ccall C_scheduler_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2159)
static void C_ccall f_2159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1368)
static void C_ccall f_1368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2103)
static void C_ccall f_2103(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2148)
static void C_ccall f_2148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2140)
static void C_ccall f_2140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2122)
static void C_ccall f_2122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2006)
static void C_ccall f_2006(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2021)
static void C_ccall f_2021(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2091)
static void C_ccall f_2091(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2025)
static void C_fcall f_2025(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2075)
static void C_ccall f_2075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2053)
static void C_ccall f_2053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2062)
static void C_ccall f_2062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2067)
static void C_ccall f_2067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1941)
static void C_ccall f_1941(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1951)
static void C_ccall f_1951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1963)
static void C_fcall f_1963(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1996)
static void C_ccall f_1996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1955)
static void C_ccall f_1955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1922)
static void C_ccall f_1922(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1912)
static void C_ccall f_1912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1740)
static void C_ccall f_1740(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1740)
static void C_ccall f_1740r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1861)
static void C_fcall f_1861(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1867)
static void C_ccall f_1867(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1856)
static void C_fcall f_1856(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1742)
static void C_fcall f_1742(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1748)
static void C_fcall f_1748(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1775)
static void C_fcall f_1775(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1829)
static void C_fcall f_1829(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1847)
static void C_ccall f_1847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1802)
static void C_fcall f_1802(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1796)
static void C_ccall f_1796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1766)
static void C_ccall f_1766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1379)
static void C_ccall f_1379(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1440)
static void C_fcall f_1440(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1383)
static void C_ccall f_1383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1386)
static void C_fcall f_1386(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1376)
static C_word C_fcall f_1376(C_word t0);
C_noret_decl(f_1373)
static C_word C_fcall f_1373(C_word t0);
C_noret_decl(f_1370)
static C_word C_fcall f_1370(C_word t0);
C_noret_decl(f_1364)
static C_word C_fcall f_1364();
C_noret_decl(f_1302)
static void C_ccall f_1302(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1339)
static void C_ccall f_1339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1342)
static void C_ccall f_1342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1345)
static void C_ccall f_1345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1348)
static void C_ccall f_1348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1358)
static void C_ccall f_1358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1351)
static void C_ccall f_1351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1326)
static void C_ccall f_1326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1330)
static void C_ccall f_1330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1306)
static void C_ccall f_1306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1312)
static void C_ccall f_1312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1290)
static void C_ccall f_1290(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1238)
static void C_ccall f_1238(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1242)
static void C_ccall f_1242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1257)
static void C_ccall f_1257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1274)
static void C_ccall f_1274(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1263)
static void C_ccall f_1263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1200)
static void C_ccall f_1200(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1137)
static void C_ccall f_1137(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1152)
static void C_fcall f_1152(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1162)
static void C_fcall f_1162(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1141)
static void C_ccall f_1141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1096)
static void C_ccall f_1096(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1102)
static C_word C_fcall f_1102(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_1071)
static void C_ccall f_1071(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1089)
static void C_ccall f_1089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1075)
static void C_ccall f_1075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_970)
static void C_ccall f_970(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_980)
static void C_fcall f_980(C_word t0,C_word t1) C_noret;
C_noret_decl(f_967)
static void C_ccall f_967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_959)
static void C_fcall f_959(C_word t0) C_noret;
C_noret_decl(f_738)
static void C_ccall f_738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_768)
static void C_ccall f_768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_773)
static void C_fcall f_773(C_word t0,C_word t1) C_noret;
C_noret_decl(f_852)
static void C_fcall f_852(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_904)
static void C_fcall f_904(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1675)
static void C_fcall f_1675(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1726)
static void C_ccall f_1726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1697)
static void C_ccall f_1697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1673)
static void C_ccall f_1673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_887)
static void C_fcall f_887(C_word t0,C_word t1) C_noret;
C_noret_decl(f_890)
static void C_ccall f_890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_777)
static void C_ccall f_777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1638)
static void C_fcall f_1638(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1522)
static void C_fcall f_1522(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1623)
static void C_ccall f_1623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1553)
static void C_fcall f_1553(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1593)
static void C_fcall f_1593(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1583)
static void C_ccall f_1583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1520)
static void C_ccall f_1520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1501)
static void C_ccall f_1501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_780)
static void C_ccall f_780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_785)
static void C_fcall f_785(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1004)
static void C_fcall f_1004(C_word t0,C_word t1) C_noret;
C_noret_decl(f_789)
static void C_fcall f_789(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2025)
static void C_fcall trf_2025(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2025(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2025(t0,t1);}

C_noret_decl(trf_1963)
static void C_fcall trf_1963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1963(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1963(t0,t1,t2);}

C_noret_decl(trf_1861)
static void C_fcall trf_1861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1861(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1861(t0,t1);}

C_noret_decl(trf_1856)
static void C_fcall trf_1856(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1856(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1856(t0,t1,t2);}

C_noret_decl(trf_1742)
static void C_fcall trf_1742(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1742(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1742(t0,t1,t2);}

C_noret_decl(trf_1748)
static void C_fcall trf_1748(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1748(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1748(t0,t1,t2,t3);}

C_noret_decl(trf_1775)
static void C_fcall trf_1775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1775(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1775(t0,t1,t2,t3);}

C_noret_decl(trf_1829)
static void C_fcall trf_1829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1829(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1829(t0,t1,t2,t3);}

C_noret_decl(trf_1802)
static void C_fcall trf_1802(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1802(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1802(t0,t1,t2);}

C_noret_decl(trf_1440)
static void C_fcall trf_1440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1440(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1440(t0,t1,t2);}

C_noret_decl(trf_1386)
static void C_fcall trf_1386(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1386(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1386(t0,t1);}

C_noret_decl(trf_1152)
static void C_fcall trf_1152(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1152(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1152(t0,t1,t2,t3);}

C_noret_decl(trf_1162)
static void C_fcall trf_1162(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1162(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1162(t0,t1);}

C_noret_decl(trf_980)
static void C_fcall trf_980(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_980(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_980(t0,t1);}

C_noret_decl(trf_959)
static void C_fcall trf_959(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_959(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_959(t0);}

C_noret_decl(trf_773)
static void C_fcall trf_773(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_773(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_773(t0,t1);}

C_noret_decl(trf_852)
static void C_fcall trf_852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_852(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_852(t0,t1,t2);}

C_noret_decl(trf_904)
static void C_fcall trf_904(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_904(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_904(t0,t1);}

C_noret_decl(trf_1675)
static void C_fcall trf_1675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1675(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1675(t0,t1,t2);}

C_noret_decl(trf_887)
static void C_fcall trf_887(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_887(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_887(t0,t1);}

C_noret_decl(trf_1638)
static void C_fcall trf_1638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1638(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1638(t0,t1);}

C_noret_decl(trf_1522)
static void C_fcall trf_1522(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1522(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1522(t0,t1,t2,t3);}

C_noret_decl(trf_1553)
static void C_fcall trf_1553(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1553(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1553(t0,t1,t2);}

C_noret_decl(trf_1593)
static void C_fcall trf_1593(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1593(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1593(t0,t1);}

C_noret_decl(trf_785)
static void C_fcall trf_785(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_785(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_785(t0,t1);}

C_noret_decl(trf_1004)
static void C_fcall trf_1004(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1004(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1004(t0,t1);}

C_noret_decl(trf_789)
static void C_fcall trf_789(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_789(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_789(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_scheduler_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("scheduler_toplevel"));
C_check_nursery_minimum(47);
if(!C_demand(47)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(773)){
C_save(t1);
C_rereclaim2(773*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(47);
C_initialize_lf(lf,78);
lf[0]=C_h_intern(&lf[0],12,"\003sysschedule");
lf[1]=C_h_intern(&lf[1],18,"\003syscurrent-thread");
lf[2]=C_h_intern(&lf[2],17,"\003sysdynamic-winds");
lf[3]=C_h_intern(&lf[3],18,"\003sysstandard-input");
lf[4]=C_h_intern(&lf[4],19,"\003sysstandard-output");
lf[5]=C_h_intern(&lf[5],18,"\003sysstandard-error");
lf[6]=C_h_intern(&lf[6],29,"\003syscurrent-exception-handler");
lf[7]=C_h_intern(&lf[7],28,"\003syscurrent-parameter-vector");
lf[8]=C_h_intern(&lf[8],5,"ready");
lf[9]=C_h_intern(&lf[9],7,"running");
lf[11]=C_h_intern(&lf[11],11,"\003sysfd-list");
lf[12]=C_h_intern(&lf[12],15,"\003syssignal-hook");
lf[13]=C_h_intern(&lf[13],14,"\000runtime-error");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\010deadlock");
lf[20]=C_h_intern(&lf[20],25,"\003systhread-basic-unblock!");
lf[21]=C_h_intern(&lf[21],8,"\003sysdelq");
lf[22]=C_h_intern(&lf[22],22,"\003sysadd-to-ready-queue");
lf[23]=C_h_intern(&lf[23],19,"\003systhread-unblock!");
lf[24]=C_h_intern(&lf[24],21,"\003sysprimordial-thread");
lf[25]=C_h_intern(&lf[25],15,"\003sysready-queue");
lf[26]=C_h_intern(&lf[26],18,"\003sysinterrupt-hook");
lf[27]=C_h_intern(&lf[27],28,"\003sysremove-from-timeout-list");
lf[28]=C_h_intern(&lf[28],29,"\003systhread-block-for-timeout!");
lf[29]=C_h_intern(&lf[29],7,"blocked");
lf[30]=C_h_intern(&lf[30],33,"\003systhread-block-for-termination!");
lf[31]=C_h_intern(&lf[31],4,"dead");
lf[32]=C_h_intern(&lf[32],10,"terminated");
lf[33]=C_h_intern(&lf[33],16,"\003systhread-kill!");
lf[34]=C_h_intern(&lf[34],12,"\003sysfor-each");
lf[35]=C_h_intern(&lf[35],19,"\003sysabandon-mutexes");
lf[36]=C_h_intern(&lf[36],19,"print-error-message");
lf[37]=C_h_intern(&lf[37],7,"display");
lf[38]=C_h_intern(&lf[38],16,"print-call-chain");
lf[39]=C_h_intern(&lf[39],18,"open-output-string");
lf[40]=C_h_intern(&lf[40],17,"get-output-string");
lf[41]=C_h_intern(&lf[41],29,"\003sysdefault-exception-handler");
lf[42]=C_h_intern(&lf[42],10,"\003syssignal");
lf[43]=C_h_intern(&lf[43],20,"\003syswarnings-enabled");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\003): ");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\011Warning (");
lf[48]=C_h_intern(&lf[48],25,"\003systhread-block-for-i/o!");
lf[49]=C_h_intern(&lf[49],6,"\000input");
lf[50]=C_h_intern(&lf[50],7,"\000output");
lf[51]=C_h_intern(&lf[51],4,"\000all");
lf[52]=C_h_intern(&lf[52],15,"\003sysall-threads");
lf[53]=C_h_intern(&lf[53],3,"i/o");
lf[54]=C_h_intern(&lf[54],7,"timeout");
lf[55]=C_h_intern(&lf[55],27,"\003sysfetch-and-clear-threads");
lf[56]=C_h_intern(&lf[56],19,"\003sysrestore-threads");
lf[57]=C_h_intern(&lf[57],15,"\003sysbreak-entry");
lf[58]=C_h_intern(&lf[58],19,"\003sysbreak-in-thread");
lf[59]=C_h_intern(&lf[59],9,"condition");
lf[60]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\003\000\000\002\376\001\000\000\012breakpoint\376\377\016");
lf[61]=C_h_intern(&lf[61],19,"\003syslast-breakpoint");
lf[62]=C_h_intern(&lf[62],9,"suspended");
lf[63]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\022*** breakpoint ***");
lf[65]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\011arguments");
lf[66]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\010location");
lf[67]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\014continuation");
lf[68]=C_h_intern(&lf[68],6,"append");
lf[69]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\006thread");
lf[70]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\027primordial-continuation");
lf[71]=C_h_intern(&lf[71],16,"\003sysbreak-resume");
lf[72]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\014continuation");
lf[73]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\006thread");
lf[74]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\027primordial-continuation");
lf[75]=C_h_intern(&lf[75],11,"\000type-error");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\035condition has no continuation");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\035condition has no continuation");
C_register_lf2(lf,78,create_ptable());
t2=C_mutate((C_word*)lf[0]+1 /* (set! schedule ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_738,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[17] /* (set! force-primordial ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_959,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t4=lf[15] /* ready-queue-head */ =C_SCHEME_END_OF_LIST;;
t5=lf[16] /* ready-queue-tail */ =C_SCHEME_END_OF_LIST;;
t6=C_mutate((C_word*)lf[25]+1 /* (set! ready-queue ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_967,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[22]+1 /* (set! add-to-ready-queue ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_970,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t8=*((C_word*)lf[26]+1);
t9=C_mutate((C_word*)lf[26]+1 /* (set! interrupt-hook ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1071,a[2]=t8,a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp));
t10=lf[10] /* timeout-list */ =C_SCHEME_END_OF_LIST;;
t11=C_mutate((C_word*)lf[27]+1 /* (set! remove-from-timeout-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1096,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[28]+1 /* (set! thread-block-for-timeout! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1137,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[30]+1 /* (set! thread-block-for-termination! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1200,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[33]+1 /* (set! thread-kill! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1238,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[20]+1 /* (set! thread-basic-unblock! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1290,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t16=*((C_word*)lf[36]+1);
t17=*((C_word*)lf[37]+1);
t18=*((C_word*)lf[38]+1);
t19=*((C_word*)lf[39]+1);
t20=*((C_word*)lf[40]+1);
t21=C_mutate((C_word*)lf[41]+1 /* (set! default-exception-handler ...) */,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1302,a[2]=t19,a[3]=t17,a[4]=t20,a[5]=t16,a[6]=t18,a[7]=((C_word)li21),tmp=(C_word)a,a+=8,tmp));
t22=C_set_block_item(lf[11] /* fd-list */,0,C_SCHEME_END_OF_LIST);
t23=C_mutate(&lf[18] /* (set! fdset-restore ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1364,tmp=(C_word)a,a+=2,tmp));
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1368,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2159,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp);
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,t24);}

/* f_2159 */
static void C_ccall f_2159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2159,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub346(C_SCHEME_UNDEFINED));}

/* k1366 */
static void C_ccall f_1368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1368,2,t0,t1);}
t2=C_mutate(&lf[46] /* (set! fdset-input-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1370,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[47] /* (set! fdset-output-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1373,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[19] /* (set! fdset-clear ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1376,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[48]+1 /* (set! thread-block-for-i/o! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1379,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[52]+1 /* (set! all-threads ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1740,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[55]+1 /* (set! fetch-and-clear-threads ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1912,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[56]+1 /* (set! restore-threads ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1922,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[23]+1 /* (set! thread-unblock! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1941,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[57]+1 /* (set! break-entry ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2006,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[71]+1 /* (set! break-resume ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2103,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp));
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}

/* ##sys#break-resume in k1366 */
static void C_ccall f_2103(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2103,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(2));
t4=(C_word)C_i_member(lf[72],t3);
t5=(C_word)C_i_member(lf[73],t3);
t6=(C_word)C_i_member(lf[74],t3);
t7=(C_truep(t6)?t6:t4);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2122,a[2]=t2,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t9=(C_word)C_u_i_cadr(t5);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2140,a[2]=t9,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2148,a[2]=t4,a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
t12=t10;
f_2140(2,t12,(C_word)C_i_setslot(t9,C_fix(1),t11));}
else{
/* scheduler.scm: 534  ##sys#signal-hook */
t11=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t10,lf[75],lf[77],t2);}}
else{
t9=t8;
f_2122(2,t9,C_SCHEME_UNDEFINED);}}

/* a2147 in ##sys#break-resume in k1366 */
static void C_ccall f_2148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2148,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,C_SCHEME_UNDEFINED);}

/* k2138 in ##sys#break-resume in k1366 */
static void C_ccall f_2140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 535  ##sys#add-to-ready-queue */
t2=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2120 in ##sys#break-resume in k1366 */
static void C_ccall f_2122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],C_SCHEME_UNDEFINED);}
else{
/* scheduler.scm: 538  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[75],lf[76],((C_word*)t0)[2]);}}

/* ##sys#break-entry in k1366 */
static void C_ccall f_2006(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2006,4,t0,t1,t2,t3);}
t4=(C_word)C_i_not(*((C_word*)lf[58]+1));
t5=(C_truep(t4)?t4:(C_word)C_eqp(*((C_word*)lf[58]+1),*((C_word*)lf[1]+1)));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2021,a[2]=t3,a[3]=t2,a[4]=((C_word)li43),tmp=(C_word)a,a+=5,tmp);
/* scheduler.scm: 493  ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* a2020 in ##sys#break-entry in k1366 */
static void C_ccall f_2021(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2021,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(*((C_word*)lf[1]+1),*((C_word*)lf[24]+1));
if(C_truep(t4)){
t5=t3;
f_2025(t5,C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2091,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp);
t6=t3;
f_2025(t6,(C_word)C_a_i_list(&a,4,lf[69],*((C_word*)lf[1]+1),lf[70],t5));}}

/* a2090 in a2020 in ##sys#break-entry in k1366 */
static void C_ccall f_2091(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2091,2,t0,t1);}
t2=(C_word)C_slot(*((C_word*)lf[24]+1),C_fix(1));
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k2023 in a2020 in ##sys#break-entry in k1366 */
static void C_fcall f_2025(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2025,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2075,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t4=(C_word)C_a_i_list(&a,8,lf[63],lf[64],lf[65],t3,lf[66],((C_word*)t0)[3],lf[67],((C_word*)t0)[4]);
/* scheduler.scm: 503  append */
t5=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t4,t1);}

/* k2073 in k2023 in a2020 in ##sys#break-entry in k1366 */
static void C_ccall f_2075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2075,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,3,lf[59],lf[60],t1);
t3=C_mutate((C_word*)lf[61]+1 /* (set! last-breakpoint ...) */,t2);
t4=(C_word)C_eqp(*((C_word*)lf[1]+1),*((C_word*)lf[24]+1));
if(C_truep(t4)){
/* scheduler.scm: 511  ##sys#signal */
t5=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,((C_word*)t0)[3],t2);}
else{
t5=(C_word)C_i_setslot(*((C_word*)lf[1]+1),C_fix(3),lf[62]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2067,a[2]=((C_word*)t0)[2],a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_setslot(*((C_word*)lf[1]+1),C_fix(1),t6);
t8=(C_word)C_slot(*((C_word*)lf[24]+1),C_fix(1));
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2058,a[2]=t2,a[3]=t8,a[4]=((C_word)li41),tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_i_setslot(*((C_word*)lf[24]+1),C_fix(1),t9);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2053,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* scheduler.scm: 521  ##sys#thread-unblock! */
t12=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,*((C_word*)lf[24]+1));}}

/* k2051 in k2073 in k2023 in a2020 in ##sys#break-entry in k1366 */
static void C_ccall f_2053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 522  ##sys#schedule */
t2=*((C_word*)lf[0]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a2057 in k2073 in k2023 in a2020 in ##sys#break-entry in k1366 */
static void C_ccall f_2058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2062,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* scheduler.scm: 519  ##sys#signal */
t3=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2060 in a2057 in k2073 in k2023 in a2020 in ##sys#break-entry in k1366 */
static void C_ccall f_2062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 520  old */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a2066 in k2073 in k2023 in a2020 in ##sys#break-entry in k1366 */
static void C_ccall f_2067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2067,2,t0,t1);}
/* scheduler.scm: 514  k */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* ##sys#thread-unblock! in k1366 */
static void C_ccall f_1941(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1941,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_eqp(lf[29],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1951,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* scheduler.scm: 475  ##sys#remove-from-timeout-list */
t6=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k1949 in ##sys#thread-unblock! in k1366 */
static void C_ccall f_1951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1955,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1963,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word)li38),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1963(t6,t2,*((C_word*)lf[11]+1));}

/* loop in k1949 in ##sys#thread-unblock! in k1366 */
static void C_fcall f_1963(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1963,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1996,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(t3,C_fix(1));
/* scheduler.scm: 483  ##sys#delq */
t7=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}}

/* k1994 in loop in k1949 in ##sys#thread-unblock! in k1366 */
static void C_ccall f_1996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1996,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1984,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* scheduler.scm: 484  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1963(t5,t3,t4);}

/* k1982 in k1994 in loop in k1949 in ##sys#thread-unblock! in k1366 */
static void C_ccall f_1984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1984,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1953 in k1949 in ##sys#thread-unblock! in k1366 */
static void C_ccall f_1955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate((C_word*)lf[11]+1 /* (set! fd-list ...) */,t1);
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[3],C_fix(12),C_SCHEME_END_OF_LIST);
/* scheduler.scm: 486  ##sys#thread-basic-unblock! */
t4=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* ##sys#restore-threads in k1366 */
static void C_ccall f_1922(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1922,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=C_mutate(&lf[15] /* (set! ready-queue-head ...) */,t3);
t5=(C_word)C_slot(t2,C_fix(1));
t6=C_mutate(&lf[16] /* (set! ready-queue-tail ...) */,t5);
t7=(C_word)C_slot(t2,C_fix(2));
t8=C_mutate((C_word*)lf[11]+1 /* (set! fd-list ...) */,t7);
t9=(C_word)C_slot(t2,C_fix(3));
t10=C_mutate(&lf[10] /* (set! timeout-list ...) */,t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}

/* ##sys#fetch-and-clear-threads in k1366 */
static void C_ccall f_1912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1912,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,4,lf[15],lf[16],*((C_word*)lf[11]+1),lf[10]);
t3=lf[15] /* ready-queue-head */ =C_SCHEME_END_OF_LIST;;
t4=lf[16] /* ready-queue-tail */ =C_SCHEME_END_OF_LIST;;
t5=C_set_block_item(lf[11] /* fd-list */,0,C_SCHEME_END_OF_LIST);
t6=lf[10] /* timeout-list */ =C_SCHEME_END_OF_LIST;;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t2);}

/* ##sys#all-threads in k1366 */
static void C_ccall f_1740(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr2r,(void*)f_1740r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1740r(t0,t1,t2);}}

static void C_ccall f_1740r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(11);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1742,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1856,a[2]=t3,a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1861,a[2]=t4,a[3]=((C_word)li34),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-cns538583 */
t6=t5;
f_1861(t6,t1);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t7))){
/* def-init539579 */
t8=t4;
f_1856(t8,t1,t6);}
else{
t8=(C_word)C_u_i_car(t7);
t9=(C_word)C_slot(t7,C_fix(1));
/* body536545 */
f_1742(t1,t6,t8);}}}

/* def-cns538 in ##sys#all-threads in k1366 */
static void C_fcall f_1861(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1861,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1867,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp);
/* def-init539579 */
t3=((C_word*)t0)[2];
f_1856(t3,t1,t2);}

/* a1866 in def-cns538 in ##sys#all-threads in k1366 */
static void C_ccall f_1867(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1867,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,t4,t5));}

/* def-init539 in ##sys#all-threads in k1366 */
static void C_fcall f_1856(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1856,NULL,3,t0,t1,t2);}
/* body536545 */
f_1742(t1,t2,C_SCHEME_END_OF_LIST);}

/* body536 in ##sys#all-threads in k1366 */
static void C_fcall f_1742(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1742,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1748,a[2]=t2,a[3]=t5,a[4]=((C_word)li30),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1748(t7,t1,lf[15],t3);}

/* loop in body536 in ##sys#all-threads in k1366 */
static void C_fcall f_1748(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1748,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1766,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t2);
/* scheduler.scm: 437  cns */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t5,lf[8],C_SCHEME_FALSE,t6,t3);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1775,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word)li29),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1775(t7,t1,*((C_word*)lf[11]+1),t3);}}

/* loop in loop in body536 in ##sys#all-threads in k1366 */
static void C_fcall f_1775(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1775,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_u_i_caar(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1796,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_u_i_cdar(t2);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1802,a[2]=t9,a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=((C_word)li27),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_1802(t11,t6,t7);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1829,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word)li28),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1829(t7,t1,lf[10],t3);}}

/* loop in loop in loop in body536 in ##sys#all-threads in k1366 */
static void C_fcall f_1829(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1829,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1847,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_caar(t2);
t7=(C_word)C_u_i_cdar(t2);
/* scheduler.scm: 447  cns */
t8=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t5,lf[54],t6,t7,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1845 in loop in loop in loop in body536 in ##sys#all-threads in k1366 */
static void C_ccall f_1847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 447  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1829(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in loop in loop in body536 in ##sys#all-threads in k1366 */
static void C_fcall f_1802(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1802,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1820,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* scheduler.scm: 444  loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k1818 in loop in loop in loop in body536 in ##sys#all-threads in k1366 */
static void C_ccall f_1820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 444  cns */
t2=((C_word*)t0)[5];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[53],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1794 in loop in loop in body536 in ##sys#all-threads in k1366 */
static void C_ccall f_1796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 440  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1775(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1764 in loop in body536 in ##sys#all-threads in k1366 */
static void C_ccall f_1766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 437  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1748(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#thread-block-for-i/o! in k1366 */
static void C_ccall f_1379(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1379,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1383,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1440,a[2]=t7,a[3]=t2,a[4]=t3,a[5]=((C_word)li25),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_1440(t9,t5,*((C_word*)lf[11]+1));}

/* loop in ##sys#thread-block-for-i/o! in k1366 */
static void C_fcall f_1440(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1440,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t3,*((C_word*)lf[11]+1));
t5=C_mutate((C_word*)lf[11]+1 /* (set! fd-list ...) */,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_u_i_car(t3);
t5=(C_word)C_eqp(((C_word*)t0)[4],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(t3,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_setslot(t3,C_fix(1),t7));}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* scheduler.scm: 351  loop */
t13=t1;
t14=t6;
t1=t13;
t2=t14;
goto loop;}}}

/* k1381 in ##sys#thread-block-for-i/o! in k1366 */
static void C_ccall f_1383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1383,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1386,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,C_SCHEME_TRUE);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t2,lf[49]));
if(C_truep(t5)){
/* scheduler.scm: 353  ##sys#fdset-input-set */
t6=t3;
f_1386(t6,f_1370(((C_word*)t0)[3]));}
else{
t6=(C_word)C_eqp(t2,C_SCHEME_FALSE);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t2,lf[50]));
if(C_truep(t7)){
/* scheduler.scm: 354  ##sys#fdset-output-set */
t8=t3;
f_1386(t8,f_1373(((C_word*)t0)[3]));}
else{
t8=(C_word)C_eqp(t2,lf[51]);
if(C_truep(t8)){
t9=f_1370(((C_word*)t0)[3]);
/* scheduler.scm: 357  ##sys#fdset-output-set */
t10=t3;
f_1386(t10,f_1373(((C_word*)t0)[3]));}
else{
t9=t3;
f_1386(t9,C_SCHEME_UNDEFINED);}}}}

/* k1384 in k1381 in ##sys#thread-block-for-i/o! in k1366 */
static void C_fcall f_1386(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1386,NULL,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(3),lf[29]);
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[5],C_fix(13),C_SCHEME_FALSE);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(11),t4));}

/* ##sys#fdset-clear in k1366 */
static C_word C_fcall f_1376(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub363(C_SCHEME_UNDEFINED,t1));}

/* ##sys#fdset-output-set in k1366 */
static C_word C_fcall f_1373(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub357(C_SCHEME_UNDEFINED,t1));}

/* ##sys#fdset-input-set in k1366 */
static C_word C_fcall f_1370(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub351(C_SCHEME_UNDEFINED,t1));}

/* ##sys#fdset-restore */
static C_word C_fcall f_1364(){
C_word tmp;
C_word t1;
return((C_word)stub342(C_SCHEME_UNDEFINED));}

/* ##sys#default-exception-handler */
static void C_ccall f_1302(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1302,3,t0,t1,t2);}
t3=*((C_word*)lf[1]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1306,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_mk_bool(C_abort_on_thread_exceptions))){
t5=*((C_word*)lf[24]+1);
t6=(C_word)C_slot(t5,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1326,a[2]=t2,a[3]=t6,a[4]=((C_word)li20),tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_setslot(t5,C_fix(1),t7);
/* scheduler.scm: 295  ##sys#thread-unblock! */
t9=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t4,t5);}
else{
if(C_truep(*((C_word*)lf[43]+1))){
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1339,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t4,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* scheduler.scm: 297  open-output-string */
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t4;
f_1306(2,t5,C_SCHEME_UNDEFINED);}}}

/* k1337 in ##sys#default-exception-handler */
static void C_ccall f_1339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1342,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* scheduler.scm: 298  display */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[45],t1);}

/* k1340 in k1337 in ##sys#default-exception-handler */
static void C_ccall f_1342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1345,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* scheduler.scm: 299  display */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[7],((C_word*)t0)[3]);}

/* k1343 in k1340 in k1337 in ##sys#default-exception-handler */
static void C_ccall f_1345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1348,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* scheduler.scm: 300  display */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[44],((C_word*)t0)[3]);}

/* k1346 in k1343 in k1340 in k1337 in ##sys#default-exception-handler */
static void C_ccall f_1348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1351,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1358,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* scheduler.scm: 301  get-output-string */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k1356 in k1346 in k1343 in k1340 in k1337 in ##sys#default-exception-handler */
static void C_ccall f_1358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 301  print-error-message */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[5]+1),t1);}

/* k1349 in k1346 in k1343 in k1340 in k1337 in ##sys#default-exception-handler */
static void C_ccall f_1351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 302  print-call-chain */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[5]+1),C_fix(0),((C_word*)t0)[2]);}

/* a1325 in ##sys#default-exception-handler */
static void C_ccall f_1326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1330,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* scheduler.scm: 293  ##sys#signal */
t3=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1328 in a1325 in ##sys#default-exception-handler */
static void C_ccall f_1330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 294  ptx */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k1304 in ##sys#default-exception-handler */
static void C_ccall f_1306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1306,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(7),((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1312,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* scheduler.scm: 304  ##sys#thread-kill! */
t4=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],lf[32]);}

/* k1310 in k1304 in ##sys#default-exception-handler */
static void C_ccall f_1312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 305  ##sys#schedule */
t2=*((C_word*)lf[0]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##sys#thread-basic-unblock! */
static void C_ccall f_1290(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1290,3,t0,t1,t2);}
t3=(C_word)C_i_set_i_slot(t2,C_fix(11),C_SCHEME_FALSE);
t4=(C_word)C_i_set_i_slot(t2,C_fix(4),C_SCHEME_FALSE);
/* scheduler.scm: 276  ##sys#add-to-ready-queue */
t5=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t2);}

/* ##sys#thread-kill! */
static void C_ccall f_1238(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1238,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1242,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* scheduler.scm: 256  ##sys#abandon-mutexes */
t5=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1240 in ##sys#thread-kill! */
static void C_ccall f_1242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1242,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),((C_word*)t0)[3]);
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(4),C_SCHEME_FALSE);
t4=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(11),C_SCHEME_FALSE);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(8),C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1257,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* scheduler.scm: 261  ##sys#remove-from-timeout-list */
t7=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[4]);}

/* k1255 in k1240 in ##sys#thread-kill! */
static void C_ccall f_1257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1257,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(12));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1263,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_1263(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1274,a[2]=((C_word*)t0)[3],a[3]=((C_word)li17),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}}

/* a1273 in k1255 in k1240 in ##sys#thread-kill! */
static void C_ccall f_1274(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1274,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(11));
t4=(C_word)C_eqp(t3,((C_word*)t0)[2]);
if(C_truep(t4)){
/* scheduler.scm: 268  ##sys#thread-basic-unblock! */
t5=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t2);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k1261 in k1255 in k1240 in ##sys#thread-kill! */
static void C_ccall f_1263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(12),C_SCHEME_END_OF_LIST));}

/* ##sys#thread-block-for-termination! */
static void C_ccall f_1200(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1200,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_eqp(t4,lf[31]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(t4,lf[32]));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}
else{
t7=(C_word)C_slot(t3,C_fix(12));
t8=(C_word)C_a_i_cons(&a,2,t2,t7);
t9=(C_word)C_i_setslot(t3,C_fix(12),t8);
t10=(C_word)C_i_setslot(t2,C_fix(3),lf[29]);
t11=(C_word)C_i_set_i_slot(t2,C_fix(13),C_SCHEME_FALSE);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_i_setslot(t2,C_fix(11),t3));}}

/* ##sys#thread-block-for-timeout! */
static void C_ccall f_1137(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1137,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1141,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1152,a[2]=t6,a[3]=t2,a[4]=t3,a[5]=((C_word)li14),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_1152(t8,t4,lf[10],C_SCHEME_FALSE);}

/* loop in ##sys#thread-block-for-timeout! */
static void C_fcall f_1152(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1152,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_nullp(t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1162,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
t6=t5;
f_1162(t6,t4);}
else{
t6=(C_word)C_u_i_caar(t2);
t7=((C_word*)t0)[4];
t8=t5;
f_1162(t8,(C_word)C_fixnum_lessp(t7,t6));}}

/* k1160 in loop in ##sys#thread-block-for-timeout! */
static void C_fcall f_1162(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1162,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[7])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_setslot(((C_word*)t0)[7],C_fix(1),t3));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=C_mutate(&lf[10] /* (set! timeout-list ...) */,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* scheduler.scm: 240  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1152(t3,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}}

/* k1139 in ##sys#thread-block-for-timeout! */
static void C_ccall f_1141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),lf[29]);
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(13),C_SCHEME_FALSE);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(4),((C_word*)t0)[2]));}

/* ##sys#remove-from-timeout-list */
static void C_ccall f_1096(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1096,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1102,a[2]=t2,a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_1102(t3,lf[10],C_SCHEME_FALSE));}

/* loop in ##sys#remove-from-timeout-list */
static C_word C_fcall f_1102(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(t1);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_slot(t1,C_fix(1));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_eqp(t5,((C_word*)t0)[2]);
if(C_truep(t6)){
if(C_truep(t2)){
return((C_word)C_i_setslot(t2,C_fix(1),t4));}
else{
t7=C_mutate(&lf[10] /* (set! timeout-list ...) */,t4);
return(t7);}}
else{
t9=t4;
t10=t1;
t1=t9;
t2=t10;
goto loop;}}}

/* ##sys#interrupt-hook */
static void C_ccall f_1071(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1071,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1075,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(t2,C_fix(255));
if(C_truep(t5)){
t6=*((C_word*)lf[1]+1);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1089,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word)li10),tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_setslot(t6,C_fix(1),t7);
/* scheduler.scm: 215  ##sys#schedule */
t9=*((C_word*)lf[0]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t4);}
else{
t6=t4;
f_1075(2,t6,C_SCHEME_UNDEFINED);}}

/* a1088 in ##sys#interrupt-hook */
static void C_ccall f_1089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1089,2,t0,t1);}
/* scheduler.scm: 214  oldhook */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1073 in ##sys#interrupt-hook */
static void C_ccall f_1075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 216  oldhook */
t2=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#add-to-ready-queue */
static void C_ccall f_970(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_970,3,t0,t1,t2);}
t3=(C_word)C_i_setslot(t2,C_fix(3),lf[8]);
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_980,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(C_SCHEME_END_OF_LIST,lf[15]);
if(C_truep(t6)){
t7=C_mutate(&lf[15] /* (set! ready-queue-head ...) */,t4);
t8=t5;
f_980(t8,t7);}
else{
t7=t5;
f_980(t7,(C_word)C_i_setslot(lf[16],C_fix(1),t4));}}

/* k978 in ##sys#add-to-ready-queue */
static void C_fcall f_980(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[16] /* (set! ready-queue-tail ...) */,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##sys#ready-queue */
static void C_ccall f_967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_967,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[15]);}

/* ##sys#force-primordial */
static void C_fcall f_959(C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_959,NULL,1,t1);}
/* scheduler.scm: 168  ##sys#thread-unblock! */
t2=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,*((C_word*)lf[24]+1));}

/* ##sys#schedule */
static void C_ccall f_738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_738,2,t0,t1);}
t2=*((C_word*)lf[1]+1);
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_slot(t2,C_fix(3));
t6=(C_word)C_slot(t2,C_fix(5));
t7=(C_word)C_i_setslot(t6,C_fix(0),*((C_word*)lf[2]+1));
t8=(C_word)C_i_setslot(t6,C_fix(1),*((C_word*)lf[3]+1));
t9=(C_word)C_i_setslot(t6,C_fix(2),*((C_word*)lf[4]+1));
t10=(C_word)C_i_setslot(t6,C_fix(3),*((C_word*)lf[5]+1));
t11=(C_word)C_i_setslot(t6,C_fix(4),*((C_word*)lf[6]+1));
t12=(C_word)C_i_setslot(t6,C_fix(5),*((C_word*)lf[7]+1));
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_768,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_eqp(t5,lf[9]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t5,lf[8]));
if(C_truep(t15)){
t16=(C_word)C_i_set_i_slot(t2,C_fix(13),C_SCHEME_FALSE);
/* scheduler.scm: 116  ##sys#add-to-ready-queue */
t17=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t13,t2);}
else{
t16=t13;
f_768(2,t16,C_SCHEME_UNDEFINED);}}

/* k766 in ##sys#schedule */
static void C_ccall f_768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_768,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_773,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li5),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_773(t5,((C_word*)t0)[2]);}

/* loop1 in k766 in ##sys#schedule */
static void C_fcall f_773(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_773,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_777,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(lf[10]))){
t3=t2;
f_777(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_fudge(C_fix(16));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_852,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t3,a[5]=((C_word)li4),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_852(t7,t2,lf[10]);}}

/* loop in loop1 in k766 in ##sys#schedule */
static void C_fcall f_852(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
loop:
a=C_alloc(17);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_852,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=lf[10] /* timeout-list */ =C_SCHEME_END_OF_LIST;;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(C_word)C_u_i_caar(t2);
t4=(C_word)C_u_i_cdar(t2);
t5=(C_word)C_slot(t4,C_fix(4));
t6=(C_word)C_eqp(t3,t5);
if(C_truep(t6)){
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)t0)[4],t3))){
t7=(C_word)C_i_set_i_slot(t4,C_fix(13),C_SCHEME_TRUE);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_887,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_slot(t4,C_fix(11));
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_slot(t4,C_fix(11));
t11=(C_word)C_slot(t10,C_fix(0));
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1673,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1675,a[2]=t14,a[3]=t4,a[4]=t11,a[5]=((C_word)li3),tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_1675(t16,t12,*((C_word*)lf[11]+1));}
else{
t10=t8;
f_887(t10,C_SCHEME_UNDEFINED);}}
else{
t7=C_mutate(&lf[10] /* (set! timeout-list ...) */,t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_904,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(lf[15]))){
t9=(C_word)C_i_nullp(*((C_word*)lf[11]+1));
t10=t8;
f_904(t10,(C_truep(t9)?(C_word)C_i_pairp(lf[10]):C_SCHEME_FALSE));}
else{
t9=t8;
f_904(t9,C_SCHEME_FALSE);}}}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* scheduler.scm: 149  loop */
t22=t1;
t23=t7;
t1=t22;
t2=t23;
goto loop;}}}

/* k902 in loop in loop1 in k766 in ##sys#schedule */
static void C_fcall f_904(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_caar(lf[10]);
t3=(C_word)C_u_fixnum_difference(t2,((C_word*)t0)[4]);
t4=(C_word)C_i_fixnum_max(C_fix(0),t3);
t5=(C_truep((C_word)C_msleep(t4))?C_SCHEME_FALSE:C_mk_bool(C_signal_interrupted_p));
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* loop in loop in loop1 in k766 in ##sys#schedule */
static void C_fcall f_1675(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1675,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[4],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1697,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(t3,C_fix(1));
/* scheduler.scm: 415  ##sys#delq */
t8=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[3],t7);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1726,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
/* scheduler.scm: 424  loop */
t11=t6;
t12=t7;
t1=t11;
t2=t12;
goto loop;}}}

/* k1724 in loop in loop in loop1 in k766 in ##sys#schedule */
static void C_ccall f_1726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1726,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1695 in loop in loop in loop1 in k766 in ##sys#schedule */
static void C_ccall f_1697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep((C_word)C_i_nullp(t1))){
t2=f_1376(((C_word*)t0)[5]);
t3=f_1364();
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[3],C_fix(1)));}
else{
t2=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1671 in loop in loop1 in k766 in ##sys#schedule */
static void C_ccall f_1673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[11]+1 /* (set! fd-list ...) */,t1);
t3=((C_word*)t0)[2];
f_887(t3,t2);}

/* k885 in loop in loop1 in k766 in ##sys#schedule */
static void C_fcall f_887(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_887,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_890,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* scheduler.scm: 135  ##sys#thread-basic-unblock! */
t3=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k888 in k885 in loop in loop1 in k766 in ##sys#schedule */
static void C_ccall f_890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* scheduler.scm: 136  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_852(t3,((C_word*)t0)[2],t2);}

/* k775 in loop1 in k766 in ##sys#schedule */
static void C_ccall f_777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_780,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
/* scheduler.scm: 152  ##sys#force-primordial */
f_959(t2);}
else{
if(C_truep((C_word)C_i_nullp(*((C_word*)lf[11]+1)))){
t3=t2;
f_780(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_pairp(lf[10]);
t4=(C_word)C_i_pairp(lf[15]);
t5=(C_truep(t4)?t4:t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1638,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?(C_word)C_i_not(t4):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_u_i_caar(lf[10]);
t9=(C_word)C_fudge(C_fix(16));
t10=(C_word)C_u_fixnum_difference(t8,t9);
t11=t6;
f_1638(t11,(C_word)C_i_fixnum_max(C_fix(0),t10));}
else{
t8=t6;
f_1638(t8,C_fix(0));}}}}

/* k1636 in k775 in loop1 in k766 in ##sys#schedule */
static void C_fcall f_1638(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1638,NULL,2,t0,t1);}
t2=(C_word)stub336(C_SCHEME_UNDEFINED,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1501,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* scheduler.scm: 375  ##sys#force-primordial */
f_959(t3);}
else{
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1520,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1522,a[2]=t7,a[3]=((C_word)li2),tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_1522(t9,t5,t2,*((C_word*)lf[11]+1));}
else{
t5=t3;
f_1501(2,t5,C_SCHEME_UNDEFINED);}}}

/* loop in k1636 in k775 in loop1 in k766 in ##sys#schedule */
static void C_fcall f_1522(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1522,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t3));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_u_i_car(t3);
t7=(C_word)C_u_i_car(t6);
t8=(C_word)C_fd_test_input(t7);
t9=(C_word)C_fd_test_output(t7);
t10=(C_truep(t8)?t8:t9);
if(C_truep(t10)){
t11=(C_word)C_slot(t6,C_fix(1));
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1553,a[2]=t13,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=t7,a[7]=((C_word)li1),tmp=(C_word)a,a+=8,tmp));
t15=((C_word*)t13)[1];
f_1553(t15,t1,t11);}
else{
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1623,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_slot(t3,C_fix(1));
/* scheduler.scm: 399  loop */
t18=t11;
t19=t2;
t20=t12;
t1=t18;
t2=t19;
t3=t20;
goto loop;}}}

/* k1621 in loop in k1636 in k775 in loop1 in k766 in ##sys#schedule */
static void C_ccall f_1623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1623,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* loop2 in loop in k1636 in k775 in loop1 in k766 in ##sys#schedule */
static void C_fcall f_1553(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1553,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=f_1376(((C_word*)t0)[6]);
t4=(C_word)C_u_fixnum_decrease(((C_word*)t0)[5]);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* scheduler.scm: 391  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1522(t6,t1,t4,t5);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t3,C_fix(11));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1583,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1593,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_u_i_car(t4);
t8=(C_word)C_eqp(((C_word*)t0)[6],t7);
if(C_truep(t8)){
t9=(C_word)C_slot(t3,C_fix(13));
t10=t6;
f_1593(t10,(C_word)C_i_not(t9));}
else{
t9=t6;
f_1593(t9,C_SCHEME_FALSE);}}
else{
t7=t6;
f_1593(t7,C_SCHEME_FALSE);}}}

/* k1591 in loop2 in loop in k1636 in k775 in loop1 in k766 in ##sys#schedule */
static void C_fcall f_1593(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* scheduler.scm: 397  ##sys#thread-basic-unblock! */
t2=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1583(2,t2,C_SCHEME_UNDEFINED);}}

/* k1581 in loop2 in loop in k1636 in k775 in loop1 in k766 in ##sys#schedule */
static void C_ccall f_1583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* scheduler.scm: 398  loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1553(t3,((C_word*)t0)[2],t2);}

/* k1518 in k1636 in k775 in loop1 in k766 in ##sys#schedule */
static void C_ccall f_1520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[11]+1 /* (set! fd-list ...) */,t1);
t3=((C_word*)t0)[2];
f_1501(2,t3,t2);}

/* k1499 in k1636 in k775 in loop1 in k766 in ##sys#schedule */
static void C_ccall f_1501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 400  ##sys#fdset-restore */
t2=((C_word*)t0)[2];
f_780(2,t2,f_1364());}

/* k778 in k775 in loop1 in k766 in ##sys#schedule */
static void C_ccall f_780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_780,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_785,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li0),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_785(t5,((C_word*)t0)[2]);}

/* loop2 in k778 in k775 in loop1 in k766 in ##sys#schedule */
static void C_fcall f_785(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_785,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_789,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=lf[15];
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_789(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(1));
t5=C_mutate(&lf[15] /* (set! ready-queue-head ...) */,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1004,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t7)){
t8=lf[16] /* ready-queue-tail */ =C_SCHEME_END_OF_LIST;;
t9=t6;
f_1004(t9,t8);}
else{
t8=t6;
f_1004(t8,C_SCHEME_UNDEFINED);}}}

/* k1002 in loop2 in k778 in k775 in loop1 in k766 in ##sys#schedule */
static void C_fcall f_1004(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_789(t2,(C_word)C_u_i_car(((C_word*)t0)[2]));}

/* k787 in loop2 in k778 in k775 in loop1 in k766 in ##sys#schedule */
static void C_fcall f_789(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word *a;
t2=t1;
if(C_truep(t2)){
t3=(C_word)C_slot(t1,C_fix(3));
t4=(C_word)C_eqp(t3,lf[8]);
if(C_truep(t4)){
t5=((C_word*)t0)[4];
t6=t1;
t7=C_mutate((C_word*)lf[1]+1 /* (set! current-thread ...) */,t6);
t8=(C_word)C_i_setslot(t6,C_fix(3),lf[9]);
t9=(C_word)C_slot(t6,C_fix(5));
t10=(C_word)C_slot(t9,C_fix(0));
t11=C_mutate((C_word*)lf[2]+1 /* (set! dynamic-winds ...) */,t10);
t12=(C_word)C_slot(t9,C_fix(1));
t13=C_mutate((C_word*)lf[3]+1 /* (set! standard-input ...) */,t12);
t14=(C_word)C_slot(t9,C_fix(2));
t15=C_mutate((C_word*)lf[4]+1 /* (set! standard-output ...) */,t14);
t16=(C_word)C_slot(t9,C_fix(3));
t17=C_mutate((C_word*)lf[5]+1 /* (set! standard-error ...) */,t16);
t18=(C_word)C_slot(t9,C_fix(4));
t19=C_mutate((C_word*)lf[6]+1 /* (set! current-exception-handler ...) */,t18);
t20=(C_word)C_slot(t9,C_fix(5));
t21=C_mutate((C_word*)lf[7]+1 /* (set! current-parameter-vector ...) */,t20);
t22=(C_word)C_slot(t6,C_fix(9));
t23=(C_word)C_set_initial_timer_interrupt_period(t22);
t24=(C_word)C_slot(t6,C_fix(1));
t25=t24;
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,t5);}
else{
/* scheduler.scm: 164  loop2 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_785(t5,((C_word*)t0)[4]);}}
else{
t3=(C_word)C_i_nullp(lf[10]);
t4=(C_truep(t3)?(C_word)C_i_nullp(*((C_word*)lf[11]+1)):C_SCHEME_FALSE);
if(C_truep(t4)){
/* scheduler.scm: 161  ##sys#signal-hook */
t5=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[4],lf[13],lf[14]);}
else{
/* scheduler.scm: 162  loop1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_773(t5,((C_word*)t0)[4]);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[101] = {
{"toplevelscheduler.scm",(void*)C_scheduler_toplevel},
{"f_2159scheduler.scm",(void*)f_2159},
{"f_1368scheduler.scm",(void*)f_1368},
{"f_2103scheduler.scm",(void*)f_2103},
{"f_2148scheduler.scm",(void*)f_2148},
{"f_2140scheduler.scm",(void*)f_2140},
{"f_2122scheduler.scm",(void*)f_2122},
{"f_2006scheduler.scm",(void*)f_2006},
{"f_2021scheduler.scm",(void*)f_2021},
{"f_2091scheduler.scm",(void*)f_2091},
{"f_2025scheduler.scm",(void*)f_2025},
{"f_2075scheduler.scm",(void*)f_2075},
{"f_2053scheduler.scm",(void*)f_2053},
{"f_2058scheduler.scm",(void*)f_2058},
{"f_2062scheduler.scm",(void*)f_2062},
{"f_2067scheduler.scm",(void*)f_2067},
{"f_1941scheduler.scm",(void*)f_1941},
{"f_1951scheduler.scm",(void*)f_1951},
{"f_1963scheduler.scm",(void*)f_1963},
{"f_1996scheduler.scm",(void*)f_1996},
{"f_1984scheduler.scm",(void*)f_1984},
{"f_1955scheduler.scm",(void*)f_1955},
{"f_1922scheduler.scm",(void*)f_1922},
{"f_1912scheduler.scm",(void*)f_1912},
{"f_1740scheduler.scm",(void*)f_1740},
{"f_1861scheduler.scm",(void*)f_1861},
{"f_1867scheduler.scm",(void*)f_1867},
{"f_1856scheduler.scm",(void*)f_1856},
{"f_1742scheduler.scm",(void*)f_1742},
{"f_1748scheduler.scm",(void*)f_1748},
{"f_1775scheduler.scm",(void*)f_1775},
{"f_1829scheduler.scm",(void*)f_1829},
{"f_1847scheduler.scm",(void*)f_1847},
{"f_1802scheduler.scm",(void*)f_1802},
{"f_1820scheduler.scm",(void*)f_1820},
{"f_1796scheduler.scm",(void*)f_1796},
{"f_1766scheduler.scm",(void*)f_1766},
{"f_1379scheduler.scm",(void*)f_1379},
{"f_1440scheduler.scm",(void*)f_1440},
{"f_1383scheduler.scm",(void*)f_1383},
{"f_1386scheduler.scm",(void*)f_1386},
{"f_1376scheduler.scm",(void*)f_1376},
{"f_1373scheduler.scm",(void*)f_1373},
{"f_1370scheduler.scm",(void*)f_1370},
{"f_1364scheduler.scm",(void*)f_1364},
{"f_1302scheduler.scm",(void*)f_1302},
{"f_1339scheduler.scm",(void*)f_1339},
{"f_1342scheduler.scm",(void*)f_1342},
{"f_1345scheduler.scm",(void*)f_1345},
{"f_1348scheduler.scm",(void*)f_1348},
{"f_1358scheduler.scm",(void*)f_1358},
{"f_1351scheduler.scm",(void*)f_1351},
{"f_1326scheduler.scm",(void*)f_1326},
{"f_1330scheduler.scm",(void*)f_1330},
{"f_1306scheduler.scm",(void*)f_1306},
{"f_1312scheduler.scm",(void*)f_1312},
{"f_1290scheduler.scm",(void*)f_1290},
{"f_1238scheduler.scm",(void*)f_1238},
{"f_1242scheduler.scm",(void*)f_1242},
{"f_1257scheduler.scm",(void*)f_1257},
{"f_1274scheduler.scm",(void*)f_1274},
{"f_1263scheduler.scm",(void*)f_1263},
{"f_1200scheduler.scm",(void*)f_1200},
{"f_1137scheduler.scm",(void*)f_1137},
{"f_1152scheduler.scm",(void*)f_1152},
{"f_1162scheduler.scm",(void*)f_1162},
{"f_1141scheduler.scm",(void*)f_1141},
{"f_1096scheduler.scm",(void*)f_1096},
{"f_1102scheduler.scm",(void*)f_1102},
{"f_1071scheduler.scm",(void*)f_1071},
{"f_1089scheduler.scm",(void*)f_1089},
{"f_1075scheduler.scm",(void*)f_1075},
{"f_970scheduler.scm",(void*)f_970},
{"f_980scheduler.scm",(void*)f_980},
{"f_967scheduler.scm",(void*)f_967},
{"f_959scheduler.scm",(void*)f_959},
{"f_738scheduler.scm",(void*)f_738},
{"f_768scheduler.scm",(void*)f_768},
{"f_773scheduler.scm",(void*)f_773},
{"f_852scheduler.scm",(void*)f_852},
{"f_904scheduler.scm",(void*)f_904},
{"f_1675scheduler.scm",(void*)f_1675},
{"f_1726scheduler.scm",(void*)f_1726},
{"f_1697scheduler.scm",(void*)f_1697},
{"f_1673scheduler.scm",(void*)f_1673},
{"f_887scheduler.scm",(void*)f_887},
{"f_890scheduler.scm",(void*)f_890},
{"f_777scheduler.scm",(void*)f_777},
{"f_1638scheduler.scm",(void*)f_1638},
{"f_1522scheduler.scm",(void*)f_1522},
{"f_1623scheduler.scm",(void*)f_1623},
{"f_1553scheduler.scm",(void*)f_1553},
{"f_1593scheduler.scm",(void*)f_1593},
{"f_1583scheduler.scm",(void*)f_1583},
{"f_1520scheduler.scm",(void*)f_1520},
{"f_1501scheduler.scm",(void*)f_1501},
{"f_780scheduler.scm",(void*)f_780},
{"f_785scheduler.scm",(void*)f_785},
{"f_1004scheduler.scm",(void*)f_1004},
{"f_789scheduler.scm",(void*)f_789},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
