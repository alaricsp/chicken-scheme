/* Generated from profiler.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-08-25 23:16
   Version 4.0.0x - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11761	compiled 2008-08-25 on tesseract.thetesseract.org (Linux)
   command line: profiler.scm -optimize-level 2 -include-path . -include-path . -explicit-use -output-file profiler.c
   unit: profiler
*/

#include "chicken.h"

#if !defined(_MSC_VER) && !defined(__DJGPP__) && !defined(__MWERKS__)
# include <unistd.h>
#endif

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[21];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,6),40,97,49,56,48,41,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,15),40,97,49,56,57,32,46,32,97,114,103,115,50,57,41,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,47),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,112,114,111,102,105,108,101,45,105,110,102,111,32,115,105,122,101,50,49,32,102,105,108,101,110,97,109,101,50,50,41,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,46),40,35,35,115,121,115,35,115,101,116,45,112,114,111,102,105,108,101,45,105,110,102,111,45,118,101,99,116,111,114,33,32,118,101,99,52,50,32,105,52,51,32,120,52,52,41,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,112,114,111,102,105,108,101,45,101,110,116,114,121,32,105,110,100,101,120,52,57,32,118,101,99,53,48,41,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,112,114,111,102,105,108,101,45,101,120,105,116,32,105,110,100,101,120,55,57,32,118,101,99,56,48,41,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,49,49,48,32,105,49,49,57,41};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,13),40,97,51,52,55,32,118,101,99,49,48,55,41,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,6),40,97,51,52,49,41,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,22),40,35,35,115,121,115,35,102,105,110,105,115,104,45,112,114,111,102,105,108,101,41,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_profiler_toplevel)
C_externexport void C_ccall C_profiler_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_333)
static void C_ccall f_333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_337)
static void C_ccall f_337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_342)
static void C_ccall f_342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_348)
static void C_ccall f_348(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_357)
static void C_fcall f_357(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_367)
static void C_ccall f_367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_370)
static void C_ccall f_370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_373)
static void C_ccall f_373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_376)
static void C_ccall f_376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_379)
static void C_ccall f_379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_382)
static void C_ccall f_382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_385)
static void C_ccall f_385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_388)
static void C_ccall f_388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_276)
static void C_ccall f_276(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_216)
static void C_ccall f_216(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_262)
static void C_fcall f_262(C_word t0,C_word t1) C_noret;
C_noret_decl(f_241)
static void C_fcall f_241(C_word t0,C_word t1) C_noret;
C_noret_decl(f_203)
static void C_ccall f_203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_148)
static void C_ccall f_148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_201)
static void C_ccall f_201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_167)
static void C_ccall f_167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_170)
static void C_ccall f_170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_173)
static void C_ccall f_173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_190)
static void C_ccall f_190(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_190)
static void C_ccall f_190r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_194)
static void C_ccall f_194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_176)
static void C_ccall f_176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_181)
static void C_ccall f_181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_185)
static void C_ccall f_185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_152)
static void C_ccall f_152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_155)
static void C_ccall f_155(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_357)
static void C_fcall trf_357(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_357(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_357(t0,t1,t2);}

C_noret_decl(trf_262)
static void C_fcall trf_262(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_262(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_262(t0,t1);}

C_noret_decl(trf_241)
static void C_fcall trf_241(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_241(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_241(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_profiler_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_profiler_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("profiler_toplevel"));
C_check_nursery_minimum(20);
if(!C_demand(20)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(173)){
C_save(t1);
C_rereclaim2(173*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(20);
C_initialize_lf(lf,21);
lf[2]=C_h_intern(&lf[2],23,"\003sysprofile-append-mode");
lf[3]=C_h_intern(&lf[3],11,"make-vector");
lf[4]=C_h_intern(&lf[4],25,"\003sysregister-profile-info");
lf[5]=C_h_intern(&lf[5],18,"\003sysfinish-profile");
lf[6]=C_h_intern(&lf[6],25,"\003sysimplicit-exit-handler");
lf[7]=C_h_intern(&lf[7],16,"\003sysexit-handler");
lf[8]=C_h_intern(&lf[8],13,"string-append");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[10]=C_h_intern(&lf[10],28,"\003sysset-profile-info-vector!");
lf[11]=C_h_intern(&lf[11],17,"\003sysprofile-entry");
lf[12]=C_h_intern(&lf[12],16,"\003sysprofile-exit");
lf[13]=C_h_intern(&lf[13],19,"with-output-to-file");
lf[14]=C_h_intern(&lf[14],10,"write-char");
lf[15]=C_h_intern(&lf[15],5,"write");
lf[16]=C_h_intern(&lf[16],12,"\003sysfor-each");
lf[17]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007\000append\376\377\016");
lf[18]=C_h_intern(&lf[18],9,"\003sysprint");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\033[debug] writing profile...\012");
lf[20]=C_h_intern(&lf[20],19,"\003sysstandard-output");
C_register_lf2(lf,21,create_ptable());
t2=lf[0] /* profile-vector-list */ =C_SCHEME_END_OF_LIST;;
t3=lf[1] /* profile-name */ =C_SCHEME_FALSE;;
t4=C_set_block_item(lf[2] /* profile-append-mode */,0,C_SCHEME_FALSE);
t5=*((C_word*)lf[3]+1);
t6=C_mutate((C_word*)lf[4]+1 /* register-profile-info ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_148,a[2]=t5,a[3]=((C_word)li2),tmp=(C_word)a,a+=4,tmp));
t7=C_mutate((C_word*)lf[10]+1 /* set-profile-info-vector! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_203,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t8=(C_word)C_fudge(C_fix(21));
t9=C_mutate((C_word*)lf[11]+1 /* profile-entry ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_216,a[2]=t8,a[3]=((C_word)li4),tmp=(C_word)a,a+=4,tmp));
t10=C_mutate((C_word*)lf[12]+1 /* profile-exit ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_276,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[13]+1);
t12=*((C_word*)lf[14]+1);
t13=*((C_word*)lf[15]+1);
t14=C_mutate((C_word*)lf[5]+1 /* finish-profile ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_333,a[2]=t11,a[3]=t13,a[4]=t12,a[5]=((C_word)li9),tmp=(C_word)a,a+=6,tmp));
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_UNDEFINED);}

/* ##sys#finish-profile */
static void C_ccall f_333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_337,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fudge(C_fix(13)))){
C_trace("profiler.scm: 129  ##sys#print");
t3=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[19],C_SCHEME_FALSE,*((C_word*)lf[20]+1));}
else{
t3=t2;
f_337(2,t3,C_SCHEME_UNDEFINED);}}

/* k335 in ##sys#finish-profile */
static void C_ccall f_337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_342,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word)li8),tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(*((C_word*)lf[2]+1))?lf[17]:C_SCHEME_END_OF_LIST);
C_apply(6,0,((C_word*)t0)[3],((C_word*)t0)[2],lf[1],t2,t3);}

/* a341 in k335 in ##sys#finish-profile */
static void C_ccall f_342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_348,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li7),tmp=(C_word)a,a+=5,tmp);
C_trace("for-each");
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[0]);}

/* a347 in a341 in k335 in ##sys#finish-profile */
static void C_ccall f_348(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_348,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_357,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=t3,a[7]=((C_word)li6),tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_357(t7,t1,C_fix(0));}

/* doloop110 in a347 in a341 in k335 in ##sys#finish-profile */
static void C_fcall f_357(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_357,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[6]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_367,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
C_trace("profiler.scm: 138  write-char");
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_make_character(40));}}

/* k365 in doloop110 in a347 in a341 in k335 in ##sys#finish-profile */
static void C_ccall f_367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_370,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],((C_word*)t0)[7]);
C_trace("profiler.scm: 139  write");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k368 in k365 in doloop110 in a347 in a341 in k335 in ##sys#finish-profile */
static void C_ccall f_370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_373,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("profiler.scm: 140  write-char");
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(32));}

/* k371 in k368 in k365 in doloop110 in a347 in a341 in k335 in ##sys#finish-profile */
static void C_ccall f_373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_376,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t4=(C_word)C_slot(((C_word*)t0)[3],t3);
C_trace("profiler.scm: 141  write");
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t2,t4);}

/* k374 in k371 in k368 in k365 in doloop110 in a347 in a341 in k335 in ##sys#finish-profile */
static void C_ccall f_376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_379,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("profiler.scm: 142  write-char");
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(32));}

/* k377 in k374 in k371 in k368 in k365 in doloop110 in a347 in a341 in k335 in ##sys#finish-profile */
static void C_ccall f_379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_382,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[3],t3);
C_trace("profiler.scm: 143  write");
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t2,t4);}

/* k380 in k377 in k374 in k371 in k368 in k365 in doloop110 in a347 in a341 in k335 in ##sys#finish-profile */
static void C_ccall f_382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_385,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("profiler.scm: 144  write-char");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(41));}

/* k383 in k380 in k377 in k374 in k371 in k368 in k365 in doloop110 in a347 in a341 in k335 in ##sys#finish-profile */
static void C_ccall f_385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_388,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("profiler.scm: 145  write-char");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(10));}

/* k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in doloop110 in a347 in a341 in k335 in ##sys#finish-profile */
static void C_ccall f_388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(5));
t3=((C_word*)((C_word*)t0)[3])[1];
f_357(t3,((C_word*)t0)[2],t2);}

/* ##sys#profile-exit */
static void C_ccall f_276(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_276,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_times(t2,C_fix(5));
t5=(C_word)C_fixnum_plus(t4,C_fix(2));
t6=(C_word)C_fixnum_plus(t4,C_fix(3));
t7=(C_word)C_fixnum_plus(t4,C_fix(4));
t8=(C_word)C_slot(t3,t7);
t9=(C_word)C_fixnum_decrease(t8);
t10=(C_word)C_i_set_i_slot(t3,t7,t9);
t11=(C_word)C_eqp(t9,C_fix(0));
if(C_truep(t11)){
t12=(C_word)C_slot(t3,t6);
t13=(C_word)C_fudge(C_fix(6));
t14=(C_word)C_slot(t3,t5);
t15=(C_word)C_fixnum_difference(t13,t14);
t16=(C_word)C_fixnum_plus(t12,t15);
t17=(C_word)C_i_set_i_slot(t3,t6,t16);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_i_set_i_slot(t3,t5,C_fix(0)));}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}}

/* ##sys#profile-entry */
static void C_ccall f_216(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_216,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_times(t2,C_fix(5));
t5=(C_word)C_fixnum_increase(t4);
t6=(C_word)C_slot(t3,t5);
t7=(C_word)C_fixnum_plus(t4,C_fix(2));
t8=(C_word)C_fixnum_plus(t4,C_fix(4));
t9=(C_word)C_slot(t3,t8);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_262,a[2]=t7,a[3]=t8,a[4]=t1,a[5]=t9,a[6]=t5,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t11=(C_word)C_eqp(((C_word*)t0)[2],t6);
t12=t10;
f_262(t12,(C_truep(t11)?C_SCHEME_FALSE:(C_word)C_fixnum_increase(t6)));}
else{
t11=t10;
f_262(t11,C_SCHEME_FALSE);}}

/* k260 in ##sys#profile-entry */
static void C_fcall f_262(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_262,NULL,2,t0,t1);}
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[7],((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_241,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[5],C_fix(0));
if(C_truep(t4)){
t5=(C_word)C_fudge(C_fix(6));
t6=t3;
f_241(t6,(C_word)C_i_set_i_slot(((C_word*)t0)[7],((C_word*)t0)[2],t5));}
else{
t5=t3;
f_241(t5,C_SCHEME_UNDEFINED);}}

/* k239 in k260 in ##sys#profile-entry */
static void C_fcall f_241(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_i_slot(((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* ##sys#set-profile-info-vector! */
static void C_ccall f_203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_203,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_times(t3,C_fix(5));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_setslot(t2,t5,t4));}

/* ##sys#register-profile-info */
static void C_ccall f_148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_148,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_152,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_167,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_201,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_trace("profiler.scm: 69   number->string");
C_number_to_string(3,0,t6,C_fix((C_word)getpid()));}
else{
t5=t4;
f_152(2,t5,C_SCHEME_UNDEFINED);}}

/* k199 in ##sys#register-profile-info */
static void C_ccall f_201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("profiler.scm: 69   string-append");
t2=*((C_word*)lf[8]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[9],t1);}

/* k165 in ##sys#register-profile-info */
static void C_ccall f_167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_167,2,t0,t1);}
t2=C_mutate(&lf[1] /* profile-name ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_170,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("profiler.scm: 70   ##sys#exit-handler");
t4=*((C_word*)lf[7]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k168 in k165 in ##sys#register-profile-info */
static void C_ccall f_170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_173,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("profiler.scm: 71   ##sys#implicit-exit-handler");
t3=*((C_word*)lf[6]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k171 in k168 in k165 in ##sys#register-profile-info */
static void C_ccall f_173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_173,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_176,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_190,a[2]=((C_word*)t0)[2],a[3]=((C_word)li1),tmp=(C_word)a,a+=4,tmp);
C_trace("profiler.scm: 72   ##sys#exit-handler");
t4=*((C_word*)lf[7]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* a189 in k171 in k168 in k165 in ##sys#register-profile-info */
static void C_ccall f_190(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_190r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_190r(t0,t1,t2);}}

static void C_ccall f_190r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_194,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("profiler.scm: 74   ##sys#finish-profile");
t4=*((C_word*)lf[5]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k192 in a189 in k171 in k168 in k165 in ##sys#register-profile-info */
static void C_ccall f_194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k174 in k171 in k168 in k165 in ##sys#register-profile-info */
static void C_ccall f_176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_181,a[2]=((C_word*)t0)[3],a[3]=((C_word)li0),tmp=(C_word)a,a+=4,tmp);
C_trace("profiler.scm: 76   ##sys#implicit-exit-handler");
t3=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* a180 in k174 in k171 in k168 in k165 in ##sys#register-profile-info */
static void C_ccall f_181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_181,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_185,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("profiler.scm: 78   ##sys#finish-profile");
t3=*((C_word*)lf[5]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k183 in a180 in k174 in k171 in k168 in k165 in ##sys#register-profile-info */
static void C_ccall f_185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("profiler.scm: 79   oldieh");
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k150 in ##sys#register-profile-info */
static void C_ccall f_152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_152,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_155,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_fixnum_times(((C_word*)t0)[3],C_fix(5));
C_trace("profiler.scm: 81   make-vector");
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_fix(0));}

/* k153 in k150 in ##sys#register-profile-info */
static void C_ccall f_155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_155,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,lf[0]);
t3=C_mutate(&lf[0] /* profile-vector-list ...) */,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[32] = {
{"toplevelprofiler.scm",(void*)C_profiler_toplevel},
{"f_333profiler.scm",(void*)f_333},
{"f_337profiler.scm",(void*)f_337},
{"f_342profiler.scm",(void*)f_342},
{"f_348profiler.scm",(void*)f_348},
{"f_357profiler.scm",(void*)f_357},
{"f_367profiler.scm",(void*)f_367},
{"f_370profiler.scm",(void*)f_370},
{"f_373profiler.scm",(void*)f_373},
{"f_376profiler.scm",(void*)f_376},
{"f_379profiler.scm",(void*)f_379},
{"f_382profiler.scm",(void*)f_382},
{"f_385profiler.scm",(void*)f_385},
{"f_388profiler.scm",(void*)f_388},
{"f_276profiler.scm",(void*)f_276},
{"f_216profiler.scm",(void*)f_216},
{"f_262profiler.scm",(void*)f_262},
{"f_241profiler.scm",(void*)f_241},
{"f_203profiler.scm",(void*)f_203},
{"f_148profiler.scm",(void*)f_148},
{"f_201profiler.scm",(void*)f_201},
{"f_167profiler.scm",(void*)f_167},
{"f_170profiler.scm",(void*)f_170},
{"f_173profiler.scm",(void*)f_173},
{"f_190profiler.scm",(void*)f_190},
{"f_194profiler.scm",(void*)f_194},
{"f_176profiler.scm",(void*)f_176},
{"f_181profiler.scm",(void*)f_181},
{"f_185profiler.scm",(void*)f_185},
{"f_152profiler.scm",(void*)f_152},
{"f_155profiler.scm",(void*)f_155},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
