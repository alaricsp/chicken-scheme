/* Generated from scrutinizer.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-06-19 09:27
   Version 4.0.7 - SVN rev. 14630
   windows-mingw32-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-05-14 on lenovo-1 (MINGW32_NT-6.0)
   command line: scrutinizer.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -no-lambda-info -inline -local -extend private-namespace.scm -output-file scrutinizer.c
   unit: scrutinizer
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[162];
static double C_possibly_force_alignment;


C_noret_decl(C_scrutinizer_toplevel)
C_externexport void C_ccall C_scrutinizer_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1306)
static void C_ccall f_1306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1309)
static void C_ccall f_1309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1312)
static void C_ccall f_1312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1315)
static void C_ccall f_1315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1318)
static void C_ccall f_1318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1321)
static void C_ccall f_1321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4692)
static void C_ccall f_4692(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4692)
static void C_ccall f_4692r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4696)
static void C_ccall f_4696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4750)
static void C_ccall f_4750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4699)
static void C_ccall f_4699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4705)
static void C_ccall f_4705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4743)
static void C_ccall f_4743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4710)
static void C_ccall f_4710(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4717)
static void C_ccall f_4717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4729)
static void C_fcall f_4729(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4723)
static void C_ccall f_4723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1335)
static void C_ccall f_1335(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4156)
static void C_fcall f_4156(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4663)
static void C_ccall f_4663(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4661)
static void C_ccall f_4661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4604)
static void C_ccall f_4604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4642)
static void C_ccall f_4642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4616)
static void C_ccall f_4616(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4632)
static void C_ccall f_4632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4624)
static void C_ccall f_4624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4628)
static void C_ccall f_4628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4607)
static void C_ccall f_4607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4526)
static void C_ccall f_4526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4578)
static void C_ccall f_4578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4582)
static void C_ccall f_4582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4529)
static void C_ccall f_4529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4574)
static void C_ccall f_4574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4554)
static void C_fcall f_4554(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4561)
static void C_ccall f_4561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4535)
static void C_ccall f_4535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4541)
static void C_fcall f_4541(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4444)
static void C_ccall f_4444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4504)
static void C_ccall f_4504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4451)
static void C_ccall f_4451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4497)
static void C_ccall f_4497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4489)
static void C_ccall f_4489(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4487)
static void C_ccall f_4487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4454)
static void C_ccall f_4454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4476)
static void C_ccall f_4476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4480)
static void C_ccall f_4480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4457)
static void C_ccall f_4457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4464)
static void C_ccall f_4464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4362)
static void C_fcall f_4362(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4422)
static void C_ccall f_4422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4406)
static void C_ccall f_4406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4410)
static void C_ccall f_4410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4383)
static void C_ccall f_4383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4398)
static void C_ccall f_4398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4380)
static void C_ccall f_4380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4347)
static void C_ccall f_4347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4236)
static void C_ccall f_4236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4239)
static void C_ccall f_4239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4242)
static void C_ccall f_4242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4245)
static void C_ccall f_4245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4251)
static void C_fcall f_4251(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4321)
static void C_ccall f_4321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4317)
static void C_ccall f_4317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4278)
static void C_fcall f_4278(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4289)
static void C_ccall f_4289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4285)
static void C_ccall f_4285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4254)
static void C_ccall f_4254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4259)
static void C_ccall f_4259(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4185)
static void C_fcall f_4185(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4172)
static void C_ccall f_4172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4124)
static void C_ccall f_4124(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3581)
static void C_fcall f_3581(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3811)
static void C_ccall f_3811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3803)
static void C_ccall f_3803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3799)
static void C_ccall f_3799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3778)
static void C_fcall f_3778(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3789)
static void C_ccall f_3789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3785)
static void C_ccall f_3785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3640)
static void C_ccall f_3640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3659)
static void C_ccall f_3659(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3763)
static void C_ccall f_3763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3759)
static void C_ccall f_3759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3666)
static void C_ccall f_3666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3685)
static void C_fcall f_3685(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3716)
static void C_ccall f_3716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3723)
static void C_ccall f_3723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3698)
static void C_ccall f_3698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3669)
static void C_ccall f_3669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4048)
static void C_ccall f_4048(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4095)
static void C_fcall f_4095(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4058)
static void C_fcall f_4058(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4085)
static void C_ccall f_4085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3672)
static void C_ccall f_3672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3645)
static void C_ccall f_3645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3584)
static void C_fcall f_3584(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3599)
static void C_fcall f_3599(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3602)
static void C_ccall f_3602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3596)
static void C_ccall f_3596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3863)
static void C_fcall f_3863(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3995)
static void C_fcall f_3995(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3898)
static void C_fcall f_3898(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3959)
static void C_fcall f_3959(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3970)
static void C_ccall f_3970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3928)
static void C_fcall f_3928(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3889)
static void C_ccall f_3889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3880)
static void C_ccall f_3880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3367)
static void C_fcall f_3367(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3409)
static void C_ccall f_3409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3402)
static void C_ccall f_3402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3399)
static void C_ccall f_3399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3395)
static void C_ccall f_3395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2972)
static void C_fcall f_2972(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3006)
static void C_ccall f_3006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2762)
static void C_fcall f_2762(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2827)
static void C_fcall f_2827(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2935)
static void C_ccall f_2935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2768)
static void C_fcall f_2768(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2786)
static void C_ccall f_2786(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2812)
static void C_ccall f_2812(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2793)
static void C_ccall f_2793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2800)
static void C_fcall f_2800(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2774)
static void C_ccall f_2774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2780)
static void C_ccall f_2780(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2490)
static void C_fcall f_2490(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2577)
static void C_fcall f_2577(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2596)
static void C_fcall f_2596(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2633)
static void C_fcall f_2633(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2693)
static void C_ccall f_2693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2684)
static void C_ccall f_2684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2675)
static void C_ccall f_2675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2660)
static void C_ccall f_2660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2601)
static void C_ccall f_2601(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2582)
static void C_ccall f_2582(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2481)
static void C_fcall f_2481(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2485)
static void C_ccall f_2485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2415)
static void C_fcall f_2415(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2444)
static void C_ccall f_2444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2448)
static void C_ccall f_2448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2213)
static void C_fcall f_2213(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2373)
static void C_ccall f_2373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2377)
static void C_ccall f_2377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2309)
static void C_fcall f_2309(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2320)
static void C_ccall f_2320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2328)
static void C_ccall f_2328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2324)
static void C_ccall f_2324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2248)
static void C_fcall f_2248(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2259)
static void C_ccall f_2259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1753)
static void C_fcall f_1753(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1759)
static void C_ccall f_1759(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2146)
static void C_ccall f_2146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2124)
static void C_ccall f_2124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2114)
static void C_ccall f_2114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1794)
static void C_ccall f_1794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2040)
static void C_ccall f_2040(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2044)
static void C_ccall f_2044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2050)
static void C_fcall f_2050(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1950)
static void C_fcall f_1950(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2022)
static void C_ccall f_2022(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1975)
static void C_ccall f_1975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2012)
static void C_ccall f_2012(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1988)
static void C_ccall f_1988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1938)
static void C_ccall f_1938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1931)
static void C_ccall f_1931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1897)
static void C_ccall f_1897(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1800)
static void C_ccall f_1800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1805)
static void C_ccall f_1805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1888)
static void C_ccall f_1888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1843)
static void C_ccall f_1843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1744)
static void C_ccall f_1744(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1748)
static void C_ccall f_1748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2151)
static void C_fcall f_2151(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2174)
static void C_fcall f_2174(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2191)
static C_word C_fcall f_2191(C_word t0);
C_noret_decl(f_3027)
static void C_fcall f_3027(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3134)
static void C_fcall f_3134(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3269)
static void C_ccall f_3269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3150)
static void C_fcall f_3150(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3155)
static void C_fcall f_3155(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3103)
static void C_ccall f_3103(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3821)
static void C_ccall f_3821(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1716)
static void C_fcall f_1716(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1742)
static void C_ccall f_1742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1694)
static void C_fcall f_1694(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1714)
static void C_ccall f_1714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1573)
static void C_ccall f_1573(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1669)
static void C_ccall f_1669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1619)
static void C_fcall f_1619(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1633)
static void C_ccall f_1633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1637)
static void C_ccall f_1637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1553)
static void C_fcall f_1553(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1557)
static void C_ccall f_1557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1571)
static void C_ccall f_1571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1567)
static void C_ccall f_1567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1560)
static void C_ccall f_1560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3561)
static void C_fcall f_3561(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3571)
static void C_ccall f_3571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3579)
static void C_ccall f_3579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3569)
static void C_ccall f_3569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3507)
static void C_fcall f_3507(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3511)
static void C_ccall f_3511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3516)
static void C_fcall f_3516(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3555)
static void C_ccall f_3555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3551)
static void C_ccall f_3551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3543)
static void C_ccall f_3543(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1521)
static void C_ccall f_1521(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1528)
static void C_fcall f_1528(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1465)
static void C_fcall f_1465(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1512)
static void C_ccall f_1512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1519)
static void C_ccall f_1519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1472)
static void C_fcall f_1472(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1495)
static void C_ccall f_1495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1491)
static void C_ccall f_1491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1487)
static void C_ccall f_1487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1440)
static void C_fcall f_1440(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1444)
static void C_ccall f_1444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1460)
static void C_ccall f_1460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1456)
static void C_ccall f_1456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3415)
static void C_fcall f_3415(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3423)
static void C_ccall f_3423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3425)
static void C_fcall f_3425(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3467)
static void C_fcall f_3467(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3484)
static void C_ccall f_3484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3488)
static void C_ccall f_3488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3458)
static void C_ccall f_3458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3428)
static void C_fcall f_3428(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3439)
static void C_ccall f_3439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1323)
static void C_ccall f_1323(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1323)
static void C_ccall f_1323r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;

C_noret_decl(trf_4729)
static void C_fcall trf_4729(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4729(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4729(t0,t1);}

C_noret_decl(trf_4156)
static void C_fcall trf_4156(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4156(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4156(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4554)
static void C_fcall trf_4554(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4554(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4554(t0,t1);}

C_noret_decl(trf_4541)
static void C_fcall trf_4541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4541(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4541(t0,t1);}

C_noret_decl(trf_4362)
static void C_fcall trf_4362(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4362(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4362(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4251)
static void C_fcall trf_4251(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4251(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4251(t0,t1);}

C_noret_decl(trf_4278)
static void C_fcall trf_4278(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4278(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4278(t0,t1);}

C_noret_decl(trf_4185)
static void C_fcall trf_4185(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4185(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4185(t0,t1);}

C_noret_decl(trf_3581)
static void C_fcall trf_3581(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3581(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3581(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3778)
static void C_fcall trf_3778(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3778(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3778(t0,t1);}

C_noret_decl(trf_3685)
static void C_fcall trf_3685(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3685(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3685(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4095)
static void C_fcall trf_4095(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4095(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4095(t0,t1);}

C_noret_decl(trf_4058)
static void C_fcall trf_4058(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4058(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4058(t0,t1,t2);}

C_noret_decl(trf_3584)
static void C_fcall trf_3584(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3584(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3584(t0,t1);}

C_noret_decl(trf_3599)
static void C_fcall trf_3599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3599(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3599(t0,t1);}

C_noret_decl(trf_3863)
static void C_fcall trf_3863(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3863(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3863(t0,t1,t2,t3);}

C_noret_decl(trf_3995)
static void C_fcall trf_3995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3995(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3995(t0,t1);}

C_noret_decl(trf_3898)
static void C_fcall trf_3898(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3898(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3898(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3959)
static void C_fcall trf_3959(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3959(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3959(t0,t1);}

C_noret_decl(trf_3928)
static void C_fcall trf_3928(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3928(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3928(t0,t1);}

C_noret_decl(trf_3367)
static void C_fcall trf_3367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3367(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3367(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2972)
static void C_fcall trf_2972(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2972(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2972(t0,t1,t2,t3);}

C_noret_decl(trf_2762)
static void C_fcall trf_2762(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2762(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2762(t0,t1,t2,t3);}

C_noret_decl(trf_2827)
static void C_fcall trf_2827(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2827(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2827(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2768)
static void C_fcall trf_2768(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2768(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2768(t0,t1,t2,t3);}

C_noret_decl(trf_2800)
static void C_fcall trf_2800(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2800(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2800(t0,t1);}

C_noret_decl(trf_2490)
static void C_fcall trf_2490(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2490(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2490(t0,t1,t2,t3);}

C_noret_decl(trf_2577)
static void C_fcall trf_2577(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2577(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2577(t0,t1);}

C_noret_decl(trf_2596)
static void C_fcall trf_2596(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2596(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2596(t0,t1);}

C_noret_decl(trf_2633)
static void C_fcall trf_2633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2633(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2633(t0,t1);}

C_noret_decl(trf_2481)
static void C_fcall trf_2481(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2481(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2481(t0,t1,t2,t3);}

C_noret_decl(trf_2415)
static void C_fcall trf_2415(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2415(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2415(t0,t1,t2,t3);}

C_noret_decl(trf_2213)
static void C_fcall trf_2213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2213(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2213(t0,t1,t2,t3);}

C_noret_decl(trf_2309)
static void C_fcall trf_2309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2309(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2309(t0,t1);}

C_noret_decl(trf_2248)
static void C_fcall trf_2248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2248(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2248(t0,t1);}

C_noret_decl(trf_1753)
static void C_fcall trf_1753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1753(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1753(t0,t1,t2);}

C_noret_decl(trf_2050)
static void C_fcall trf_2050(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2050(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2050(t0,t1);}

C_noret_decl(trf_1950)
static void C_fcall trf_1950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1950(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1950(t0,t1,t2,t3);}

C_noret_decl(trf_2151)
static void C_fcall trf_2151(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2151(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2151(t0,t1);}

C_noret_decl(trf_2174)
static void C_fcall trf_2174(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2174(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2174(t0,t1);}

C_noret_decl(trf_3027)
static void C_fcall trf_3027(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3027(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3027(t0,t1,t2,t3);}

C_noret_decl(trf_3134)
static void C_fcall trf_3134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3134(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3134(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3150)
static void C_fcall trf_3150(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3150(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3150(t0,t1);}

C_noret_decl(trf_3155)
static void C_fcall trf_3155(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3155(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3155(t0,t1,t2,t3);}

C_noret_decl(trf_1716)
static void C_fcall trf_1716(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1716(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1716(t0,t1,t2);}

C_noret_decl(trf_1694)
static void C_fcall trf_1694(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1694(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1694(t0,t1,t2);}

C_noret_decl(trf_1619)
static void C_fcall trf_1619(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1619(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1619(t0,t1);}

C_noret_decl(trf_1553)
static void C_fcall trf_1553(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1553(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1553(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3561)
static void C_fcall trf_3561(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3561(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3561(t0,t1,t2);}

C_noret_decl(trf_3507)
static void C_fcall trf_3507(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3507(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3507(t0,t1);}

C_noret_decl(trf_3516)
static void C_fcall trf_3516(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3516(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3516(t0,t1,t2,t3);}

C_noret_decl(trf_1528)
static void C_fcall trf_1528(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1528(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1528(t0,t1);}

C_noret_decl(trf_1465)
static void C_fcall trf_1465(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1465(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1465(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1472)
static void C_fcall trf_1472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1472(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1472(t0,t1);}

C_noret_decl(trf_1440)
static void C_fcall trf_1440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1440(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1440(t0,t1,t2,t3);}

C_noret_decl(trf_3415)
static void C_fcall trf_3415(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3415(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3415(t0,t1,t2,t3);}

C_noret_decl(trf_3425)
static void C_fcall trf_3425(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3425(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3425(t0,t1,t2);}

C_noret_decl(trf_3467)
static void C_fcall trf_3467(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3467(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3467(t0,t1,t2);}

C_noret_decl(trf_3428)
static void C_fcall trf_3428(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3428(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3428(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_scrutinizer_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_scrutinizer_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("scrutinizer_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1443)){
C_save(t1);
C_rereclaim2(1443*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,162);
lf[0]=C_h_intern(&lf[0],1,"d");
lf[1]=C_h_intern(&lf[1],6,"printf");
lf[2]=C_decode_literal(C_heaptop,"\376B\000\000\014[debug] ~\077~%");
lf[3]=C_h_intern(&lf[3],19,"\010compilerscrutinize");
lf[4]=C_h_intern(&lf[4],7,"sprintf");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\016procedure `~a\047");
lf[6]=C_h_intern(&lf[6],18,"\010compilerreal-name");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\021unknown procedure");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\017at toplevel:\012  ");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\022in toplevel ~a:\012  ");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\021in local ~a,\012  ~a");
lf[11]=C_h_intern(&lf[11],25,"\010compilercompiler-warning");
lf[12]=C_h_intern(&lf[12],8,"scrutiny");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~a");
lf[14]=C_h_intern(&lf[14],10,"deprecated");
lf[15]=C_h_intern(&lf[15],1,"*");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000*use of deprecated toplevel identifier `~a\047");
lf[17]=C_h_intern(&lf[17],7,"\003sysget");
lf[18]=C_h_intern(&lf[18],9,"\004coretype");
lf[19]=C_h_intern(&lf[19],9,"undefined");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\0004access to variable `~a\047 which has an undefined value");
lf[21]=C_h_intern(&lf[21],18,"\004coredeclared-type");
lf[22]=C_h_intern(&lf[22],12,"\010compilerget");
lf[23]=C_h_intern(&lf[23],8,"assigned");
lf[24]=C_h_intern(&lf[24],5,"every");
lf[25]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\007boolean\376\003\000\000\002\376\001\000\000\011undefined\376\003\000\000\002\376\001\000\000\010noreturn\376\377\016");
lf[26]=C_h_intern(&lf[26],2,"or");
lf[27]=C_h_intern(&lf[27],3,"...");
lf[28]=C_h_intern(&lf[28],7,"\003sysmap");
lf[29]=C_h_intern(&lf[29],4,"take");
lf[30]=C_h_intern(&lf[30],3,"min");
lf[31]=C_h_intern(&lf[31],30,"\010compilerbuild-expression-tree");
lf[32]=C_h_intern(&lf[32],12,"string-chomp");
lf[33]=C_h_intern(&lf[33],2,"pp");
lf[34]=C_h_intern(&lf[34],21,"with-output-to-string");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000mexpected value of type boolean in conditional but were given a value of typ"
"e `~a\047 which is always true:~%~%~a");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\010anything");
lf[37]=C_h_intern(&lf[37],4,"char");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\011character");
lf[39]=C_h_intern(&lf[39],14,"symbol->string");
lf[40]=C_h_intern(&lf[40],9,"procedure");
lf[41]=C_h_intern(&lf[41],8,"->string");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000 a procedure with ~a returning ~a");
lf[43]=C_h_intern(&lf[43],18,"string-intersperse");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\004 OR ");
lf[45]=C_h_intern(&lf[45],6,"struct");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\026a structure of type ~a");
lf[47]=C_h_intern(&lf[47],13,"\010compilerbomb");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid type: ~a");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid type: ~a");
lf[50]=C_h_intern(&lf[50],3,"len");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\016zero arguments");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\032~a argument~a of type~a ~a");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\033an unknown number of values");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\013zero values");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\027~a value~a of type~a ~a");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\011undefined\376\377\016");
lf[59]=C_h_intern(&lf[59],4,"list");
lf[60]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004null\376\003\000\000\002\376\001\000\000\004pair\376\377\016");
lf[61]=C_h_intern(&lf[61],6,"number");
lf[62]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006fixnum\376\003\000\000\002\376\001\000\000\005float\376\377\016");
lf[63]=C_h_intern(&lf[63],10,"#!optional");
lf[64]=C_h_intern(&lf[64],6,"#!rest");
lf[65]=C_h_intern(&lf[65],6,"values");
lf[66]=C_h_intern(&lf[66],19,"\003sysundefined-value");
lf[67]=C_h_intern(&lf[67],6,"append");
lf[68]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[69]=C_h_intern(&lf[69],6,"reduce");
lf[70]=C_h_intern(&lf[70],3,"any");
lf[71]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\377\016");
lf[72]=C_h_intern(&lf[72],10,"\003sysappend");
lf[73]=C_h_intern(&lf[73],7,"reverse");
lf[74]=C_h_intern(&lf[74],10,"append-map");
lf[75]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[76]=C_h_intern(&lf[76],7,"call/cc");
lf[77]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\003\000\000\002\376\001\000\000\012#!optional\376\377\016");
lf[78]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\377\016");
lf[79]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\377\016");
lf[80]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\377\016");
lf[81]=C_h_intern(&lf[81],8,"noreturn");
lf[82]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006number\376\003\000\000\002\376\001\000\000\006fixnum\376\003\000\000\002\376\001\000\000\005float\376\377\016");
lf[83]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006number\376\003\000\000\002\376\001\000\000\006fixnum\376\003\000\000\002\376\001\000\000\005float\376\377\016");
lf[84]=C_h_intern(&lf[84],4,"pair");
lf[85]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004pair\376\003\000\000\002\376\001\000\000\004list\376\377\016");
lf[86]=C_h_intern(&lf[86],4,"null");
lf[87]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004null\376\003\000\000\002\376\001\000\000\004list\376\377\016");
lf[88]=C_h_intern(&lf[88],5,"break");
lf[89]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\003\000\000\002\376\001\000\000\012#!optional\376\377\016");
lf[90]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\003\000\000\002\376\001\000\000\012#!optional\376\377\016");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\0008expected ~a a single result, but were given zero results");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\0007expected ~a a single result, but were given ~a result~a");
lf[93]=C_h_intern(&lf[93],4,"cons");
lf[94]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[95]=C_h_intern(&lf[95],9,"make-list");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\024not a procedure type");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\033in procedure call to `~s\047~a");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\012 (line ~a)");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[100]=C_h_intern(&lf[100],26,"\010compilersource-info->line");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[102]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\030not a procedure type: ~a");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000Oexpected argument #~a of type `~a\047 ~a, but where given an argument of type "
"`~a\047");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\0008expected ~a ~a argument~a, but where given ~a argument~a");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000Eexpected ~a a value of type `~a\047, but were given a value of type `~a\047");
lf[107]=C_h_intern(&lf[107],5,"quote");
lf[108]=C_h_intern(&lf[108],6,"string");
lf[109]=C_h_intern(&lf[109],6,"symbol");
lf[110]=C_h_intern(&lf[110],6,"fixnum");
lf[111]=C_h_intern(&lf[111],5,"float");
lf[112]=C_h_intern(&lf[112],7,"boolean");
lf[113]=C_h_intern(&lf[113],3,"eof");
lf[114]=C_h_intern(&lf[114],6,"vector");
lf[115]=C_h_intern(&lf[115],22,"\003sysgeneric-structure\077");
lf[116]=C_h_intern(&lf[116],14,"\004coreundefined");
lf[117]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\377\016");
lf[118]=C_h_intern(&lf[118],9,"\004coreproc");
lf[119]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[120]=C_h_intern(&lf[120],15,"\004coreglobal-ref");
lf[121]=C_h_intern(&lf[121],13,"\004corevariable");
lf[122]=C_h_intern(&lf[122],2,"if");
lf[123]=C_h_intern(&lf[123],3,"map");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000Ibranches in conditional expression differ in the number of results:~%~%~a");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\016in conditional");
lf[126]=C_h_intern(&lf[126],3,"let");
lf[127]=C_h_intern(&lf[127],10,"alist-cons");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\030in `let\047 binding of `~a\047");
lf[129]=C_h_intern(&lf[129],11,"\004corelambda");
lf[130]=C_h_intern(&lf[130],6,"lambda");
lf[131]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[132]=C_h_intern(&lf[132],7,"butlast");
lf[133]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\377\016");
lf[134]=C_h_intern(&lf[134],30,"\010compilerdecompose-lambda-list");
lf[135]=C_h_intern(&lf[135],4,"set!");
lf[136]=C_h_intern(&lf[136],9,"\004coreset!");
lf[137]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\011undefined\376\377\016");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\134assignment of value of type `~a\047 to toplevel variable `~a\047 does not match d"
"eclared type `~a\047");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\025in assignment to `~a\047");
lf[140]=C_h_intern(&lf[140],14,"\004coreprimitive");
lf[141]=C_h_intern(&lf[141],15,"\004coreinline_ref");
lf[142]=C_h_intern(&lf[142],9,"\004corecall");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\034in ~a of procedure call `~s\047");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\021operator position");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\014argument #~a");
lf[146]=C_h_intern(&lf[146],4,"iota");
lf[147]=C_h_intern(&lf[147],11,"\004coreswitch");
lf[148]=C_h_intern(&lf[148],9,"\004corecond");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\031unexpected node class: ~a");
lf[150]=C_h_intern(&lf[150],12,"\003sysfor-each");
lf[151]=C_h_intern(&lf[151],27,"\010compilerload-type-database");
lf[152]=C_h_intern(&lf[152],8,"\003sysput!");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000Ytype-definition `~a\047 for toplevel binding `~a\047 conflicts with previously lo"
"aded type `~a\047");
lf[154]=C_h_intern(&lf[154],9,"read-file");
lf[155]=C_h_intern(&lf[155],21,"\010compilerverbose-mode");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\036loading type database ~a ...~%");
lf[157]=C_h_intern(&lf[157],12,"file-exists\077");
lf[158]=C_h_intern(&lf[158],13,"make-pathname");
lf[159]=C_h_intern(&lf[159],15,"repository-path");
lf[160]=C_h_intern(&lf[160],9,"\003syserror");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
C_register_lf2(lf,162,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1306,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1304 */
static void C_ccall f_1306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1309,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1307 in k1304 */
static void C_ccall f_1309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1312,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1310 in k1307 in k1304 */
static void C_ccall f_1312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1315,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1318,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1321,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1321,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! d ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1323,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[3]+1 /* (set! scrutinize ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1335,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[151]+1 /* (set! load-type-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4692,tmp=(C_word)a,a+=2,tmp));
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}

/* ##compiler#load-type-database in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4692(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4692r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4692r(t0,t1,t2,t3);}}

static void C_ccall f_4692r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4696,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* scrutinizer.scm: 650  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[159]))(2,*((C_word*)lf[159]+1),t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4696(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[160]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[161],t3);}}}

/* k4694 in ##compiler#load-type-database in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4699,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4750,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 651  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[158]))(4,*((C_word*)lf[158]+1),t3,t1,((C_word*)t0)[2]);}

/* k4748 in k4694 in ##compiler#load-type-database in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 651  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[157]))(3,*((C_word*)lf[157]+1),((C_word*)t0)[2],t1);}

/* k4697 in k4694 in ##compiler#load-type-database in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4699,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4705,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[155]))){
/* scrutinizer.scm: 653  printf */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,lf[156],t1);}
else{
t3=t2;
f_4705(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4703 in k4697 in k4694 in ##compiler#load-type-database in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4705,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4710,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4743,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 665  read-file */
((C_proc3)C_retrieve_symbol_proc(lf[154]))(3,*((C_word*)lf[154]+1),t3,((C_word*)t0)[2]);}

/* k4741 in k4703 in k4697 in k4694 in ##compiler#load-type-database in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4709 in k4703 in k4697 in k4694 in ##compiler#load-type-database in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4710(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4710,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4717,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 657  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[17]))(4,*((C_word*)lf[17]+1),t4,t3,lf[18]);}

/* k4715 in a4709 in k4703 in k4697 in k4694 in ##compiler#load-type-database in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4717,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4723,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4729,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t5=(C_word)C_i_equalp(t1,t2);
t6=t4;
f_4729(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_4729(t5,C_SCHEME_FALSE);}}

/* k4727 in k4715 in a4709 in k4703 in k4697 in k4694 in ##compiler#load-type-database in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_4729(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* scrutinizer.scm: 660  compiler-warning */
((C_proc7)C_retrieve_symbol_proc(lf[11]))(7,*((C_word*)lf[11]+1),((C_word*)t0)[5],lf[12],lf[153],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_4723(2,t2,C_SCHEME_UNDEFINED);}}

/* k4721 in k4715 in a4709 in k4703 in k4697 in k4694 in ##compiler#load-type-database in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 664  ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[152]))(5,*((C_word*)lf[152]+1),((C_word*)t0)[4],((C_word*)t0)[3],lf[18],((C_word*)t0)[2]);}

/* ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1335(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word ab[150],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1335,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3425,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3415,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1440,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1465,a[2]=t8,a[3]=t3,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1521,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3507,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3561,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1553,a[2]=t11,a[3]=t14,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1573,a[2]=t17,a[3]=t19,a[4]=t21,tmp=(C_word)a,a+=5,tmp));
t23=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1694,a[2]=t17,tmp=(C_word)a,a+=3,tmp));
t24=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1716,a[2]=t17,tmp=(C_word)a,a+=3,tmp));
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_set_block_item(t26,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3821,a[2]=t26,tmp=(C_word)a,a+=3,tmp));
t28=C_SCHEME_UNDEFINED;
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_set_block_item(t29,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3027,a[2]=t29,tmp=(C_word)a,a+=3,tmp));
t31=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2191,tmp=(C_word)a,a+=2,tmp);
t32=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2151,tmp=(C_word)a,a+=2,tmp);
t33=C_SCHEME_UNDEFINED;
t34=(*a=C_VECTOR_TYPE|1,a[1]=t33,tmp=(C_word)a,a+=2,tmp);
t35=C_SCHEME_UNDEFINED;
t36=(*a=C_VECTOR_TYPE|1,a[1]=t35,tmp=(C_word)a,a+=2,tmp);
t37=C_SCHEME_UNDEFINED;
t38=(*a=C_VECTOR_TYPE|1,a[1]=t37,tmp=(C_word)a,a+=2,tmp);
t39=C_SCHEME_UNDEFINED;
t40=(*a=C_VECTOR_TYPE|1,a[1]=t39,tmp=(C_word)a,a+=2,tmp);
t41=C_set_block_item(t34,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1744,a[2]=t36,tmp=(C_word)a,a+=3,tmp));
t42=C_set_block_item(t36,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1753,a[2]=t26,a[3]=t29,a[4]=t32,a[5]=t38,a[6]=t40,a[7]=t34,tmp=(C_word)a,a+=8,tmp));
t43=C_set_block_item(t38,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2213,a[2]=t38,a[3]=t34,a[4]=t31,tmp=(C_word)a,a+=5,tmp));
t44=C_set_block_item(t40,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2415,a[2]=t34,a[3]=t40,tmp=(C_word)a,a+=4,tmp));
t45=C_SCHEME_UNDEFINED;
t46=(*a=C_VECTOR_TYPE|1,a[1]=t45,tmp=(C_word)a,a+=2,tmp);
t47=C_SCHEME_UNDEFINED;
t48=(*a=C_VECTOR_TYPE|1,a[1]=t47,tmp=(C_word)a,a+=2,tmp);
t49=C_SCHEME_UNDEFINED;
t50=(*a=C_VECTOR_TYPE|1,a[1]=t49,tmp=(C_word)a,a+=2,tmp);
t51=C_SCHEME_UNDEFINED;
t52=(*a=C_VECTOR_TYPE|1,a[1]=t51,tmp=(C_word)a,a+=2,tmp);
t53=C_set_block_item(t46,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2481,a[2]=t48,tmp=(C_word)a,a+=3,tmp));
t54=C_set_block_item(t48,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2490,a[2]=t32,a[3]=t50,a[4]=t52,a[5]=t46,tmp=(C_word)a,a+=6,tmp));
t55=C_set_block_item(t50,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2762,a[2]=t31,a[3]=t46,tmp=(C_word)a,a+=4,tmp));
t56=C_set_block_item(t52,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2972,a[2]=t46,a[3]=t52,tmp=(C_word)a,a+=4,tmp));
t57=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3367,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t58=*((C_word*)lf[93]+1);
t59=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3863,a[2]=t31,tmp=(C_word)a,a+=3,tmp);
t60=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3581,a[2]=t26,a[3]=t46,a[4]=t7,a[5]=t59,a[6]=t13,tmp=(C_word)a,a+=7,tmp);
t61=C_SCHEME_UNDEFINED;
t62=(*a=C_VECTOR_TYPE|1,a[1]=t61,tmp=(C_word)a,a+=2,tmp);
t63=C_set_block_item(t62,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4124,a[2]=t62,tmp=(C_word)a,a+=3,tmp));
t64=C_SCHEME_UNDEFINED;
t65=(*a=C_VECTOR_TYPE|1,a[1]=t64,tmp=(C_word)a,a+=2,tmp);
t66=C_set_block_item(t65,0,(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4156,a[2]=t13,a[3]=t60,a[4]=t46,a[5]=t58,a[6]=t57,a[7]=t15,a[8]=t65,a[9]=t62,a[10]=t14,a[11]=t7,a[12]=t34,a[13]=t9,a[14]=t8,tmp=(C_word)a,a+=15,tmp));
t67=(C_word)C_slot(t2,C_fix(3));
t68=(C_word)C_i_car(t67);
/* scrutinizer.scm: 648  walk */
t69=((C_word*)t65)[1];
f_4156(t69,t1,t68,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_4156(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word *a;
loop:
a=C_alloc(22);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4156,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(2));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=C_retrieve(lf[66]);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4172,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t14=(C_word)C_eqp(t11,lf[107]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4185,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t16=(C_word)C_i_car(t9);
if(C_truep((C_word)C_i_stringp(t16))){
t17=t15;
f_4185(t17,lf[108]);}
else{
if(C_truep((C_word)C_i_symbolp(t16))){
t17=t15;
f_4185(t17,lf[109]);}
else{
if(C_truep((C_word)C_fixnump(t16))){
t17=t15;
f_4185(t17,lf[110]);}
else{
if(C_truep((C_word)C_i_flonump(t16))){
t17=t15;
f_4185(t17,lf[111]);}
else{
if(C_truep((C_word)C_i_numberp(t16))){
t17=t15;
f_4185(t17,lf[61]);}
else{
if(C_truep((C_word)C_booleanp(t16))){
t17=t15;
f_4185(t17,lf[112]);}
else{
if(C_truep((C_word)C_i_listp(t16))){
t17=t15;
f_4185(t17,lf[59]);}
else{
if(C_truep((C_word)C_i_pairp(t16))){
t17=t15;
f_4185(t17,lf[84]);}
else{
if(C_truep((C_word)C_eofp(t16))){
t17=t15;
f_4185(t17,lf[113]);}
else{
if(C_truep((C_word)C_i_vectorp(t16))){
t17=t15;
f_4185(t17,lf[114]);}
else{
t17=(C_word)C_immp(t16);
t18=(C_truep(t17)?C_SCHEME_FALSE:(C_truep(*((C_word*)lf[115]+1))?t16:C_SCHEME_FALSE));
if(C_truep(t18)){
t19=(C_word)C_slot(t16,C_fix(0));
t20=(C_word)C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=t15;
f_4185(t21,(C_word)C_a_i_cons(&a,2,lf[45],t20));}
else{
if(C_truep((C_word)C_i_nullp(t16))){
t19=t15;
f_4185(t19,lf[86]);}
else{
t19=(C_word)C_charp(t16);
t20=t15;
f_4185(t20,(C_truep(t19)?lf[37]:lf[15]));}}}}}}}}}}}}}
else{
t15=(C_word)C_eqp(t11,lf[116]);
if(C_truep(t15)){
t16=t13;
f_4172(2,t16,lf[117]);}
else{
t16=(C_word)C_eqp(t11,lf[118]);
if(C_truep(t16)){
t17=t13;
f_4172(2,t17,lf[119]);}
else{
t17=(C_word)C_eqp(t11,lf[120]);
if(C_truep(t17)){
t18=(C_word)C_i_car(t9);
/* scrutinizer.scm: 563  global-result */
t19=((C_word*)t0)[14];
f_1440(t19,t13,t18,t4);}
else{
t18=(C_word)C_eqp(t11,lf[121]);
if(C_truep(t18)){
t19=(C_word)C_i_car(t9);
/* scrutinizer.scm: 564  variable-result */
t20=((C_word*)t0)[13];
f_1465(t20,t13,t19,t3,t4);}
else{
t19=(C_word)C_eqp(t11,lf[122]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4236,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=t3,a[5]=((C_word*)t0)[8],a[6]=t7,a[7]=((C_word*)t0)[9],a[8]=t2,a[9]=((C_word*)t0)[10],a[10]=t4,a[11]=((C_word*)t0)[11],a[12]=t13,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4347,a[2]=t4,a[3]=t20,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t22=(C_word)C_i_car(t7);
/* scrutinizer.scm: 565  walk */
t53=t21;
t54=t22;
t55=t3;
t56=t4;
t57=t5;
t1=t53;
t2=t54;
t3=t55;
t4=t56;
t5=t57;
goto loop;}
else{
t20=(C_word)C_eqp(t11,lf[126]);
if(C_truep(t20)){
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4362,a[2]=((C_word*)t0)[6],a[3]=t22,a[4]=t3,a[5]=t5,a[6]=t4,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp));
t24=((C_word*)t22)[1];
f_4362(t24,t13,t9,t7,C_SCHEME_END_OF_LIST);}
else{
t21=(C_word)C_eqp(t11,lf[129]);
t22=(C_truep(t21)?t21:(C_word)C_eqp(t11,lf[130]));
if(C_truep(t22)){
t23=(C_word)C_i_car(t9);
t24=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4444,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=t7,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* scrutinizer.scm: 591  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t13,t23,t24);}
else{
t23=(C_word)C_eqp(t11,lf[135]);
t24=(C_truep(t23)?t23:(C_word)C_eqp(t11,lf[136]));
if(C_truep(t24)){
t25=(C_word)C_i_car(t9);
t26=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4526,a[2]=((C_word*)t0)[8],a[3]=t7,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[11],a[8]=t13,a[9]=t3,a[10]=t25,tmp=(C_word)a,a+=11,tmp);
/* scrutinizer.scm: 611  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[17]))(4,*((C_word*)lf[17]+1),t26,t25,lf[18]);}
else{
t25=(C_word)C_eqp(t11,lf[140]);
t26=(C_truep(t25)?t25:(C_word)C_eqp(t11,lf[141]));
if(C_truep(t26)){
t27=t13;
f_4172(2,t27,lf[15]);}
else{
t27=(C_word)C_eqp(t11,lf[142]);
if(C_truep(t27)){
t28=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4604,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=t9,a[6]=t4,a[7]=t13,a[8]=((C_word*)t0)[3],a[9]=t7,tmp=(C_word)a,a+=10,tmp);
/* scrutinizer.scm: 629  fragment */
f_3507(t28,t2);}
else{
t28=(C_word)C_eqp(t11,lf[147]);
t29=(C_truep(t28)?t28:(C_word)C_eqp(t11,lf[148]));
if(C_truep(t29)){
/* scrutinizer.scm: 642  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t13,lf[149],t11);}
else{
t30=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4661,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t31=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4663,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t32=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t32+1)))(4,t32,t30,t31,t7);}}}}}}}}}}}}}

/* a4662 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4663(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4663,3,t0,t1,t2);}
/* scrutinizer.scm: 644  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4156(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4659 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4172(2,t2,lf[15]);}

/* k4602 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4607,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4616,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4642,a[2]=((C_word*)t0)[9],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_length(((C_word*)t0)[9]);
/* scrutinizer.scm: 639  iota */
((C_proc3)C_retrieve_symbol_proc(lf[146]))(3,*((C_word*)lf[146]+1),t4,t5);}

/* k4640 in k4602 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 630  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[123]+1)))(5,*((C_word*)lf[123]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4615 in k4602 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4616(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4616,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4624,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4632,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t6)){
t7=t5;
f_4632(2,t7,lf[144]);}
else{
/* scrutinizer.scm: 636  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),t5,lf[145],t3);}}

/* k4630 in a4615 in k4602 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 632  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[4]))(5,*((C_word*)lf[4]+1),((C_word*)t0)[3],lf[143],t1,((C_word*)t0)[2]);}

/* k4622 in a4615 in k4602 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4628,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm: 638  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4156(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5],C_SCHEME_FALSE);}

/* k4626 in k4622 in a4615 in k4602 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 631  single */
t2=((C_word*)t0)[5];
f_3367(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4605 in k4602 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[6]);
/* scrutinizer.scm: 640  call-result */
t3=((C_word*)t0)[5];
f_3581(t3,((C_word*)t0)[4],t1,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k4524 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4526,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4529,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4578,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
/* scrutinizer.scm: 613  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),t3,lf[139],((C_word*)t0)[10]);}

/* k4576 in k4524 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4578,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4582,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* scrutinizer.scm: 614  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4156(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2]);}

/* k4580 in k4576 in k4524 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 612  single */
t2=((C_word*)t0)[5];
f_3367(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4527 in k4524 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4529,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4535,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4554,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep(t2)){
t5=t4;
f_4554(t5,C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4574,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 618  match */
t6=((C_word*)((C_word*)t0)[2])[1];
f_2481(t6,t5,((C_word*)t0)[3],t1);}}
else{
t5=t4;
f_4554(t5,C_SCHEME_FALSE);}}

/* k4572 in k4527 in k4524 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4554(t2,(C_word)C_i_not(t1));}

/* k4552 in k4527 in k4524 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_4554(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4554,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4561,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 621  sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[4]))(6,*((C_word*)lf[4]+1),t2,lf[138],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[6];
f_4535(2,t2,C_SCHEME_UNDEFINED);}}

/* k4559 in k4552 in k4527 in k4524 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 619  report */
t2=((C_word*)t0)[4];
f_3415(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4533 in k4527 in k4524 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4541,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=t2;
f_4541(t4,(C_word)C_eqp(lf[19],t3));}
else{
t3=t2;
f_4541(t3,C_SCHEME_FALSE);}}

/* k4539 in k4533 in k4527 in k4524 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_4541(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_i_set_cdr(((C_word*)t0)[4],((C_word*)t0)[3]):C_SCHEME_UNDEFINED);
t3=((C_word*)t0)[2];
f_4172(2,t3,lf[137]);}

/* a4443 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4444,5,t0,t1,t2,t3,t4);}
t5=(C_truep(((C_word*)t0)[7])?(C_word)C_a_i_list(&a,1,((C_word*)t0)[7]):C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4451,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t5,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4504,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 595  make-list */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),t7,t3,lf[15]);}

/* k4502 in a4443 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[3])?lf[133]:C_SCHEME_END_OF_LIST);
/* scrutinizer.scm: 595  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),((C_word*)t0)[2],t1,t2);}

/* k4449 in a4443 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4454,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4487,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4489,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4497,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
/* scrutinizer.scm: 597  butlast */
((C_proc3)C_retrieve_symbol_proc(lf[132]))(3,*((C_word*)lf[132]+1),t5,((C_word*)t0)[2]);}
else{
t6=t5;
f_4497(2,t6,((C_word*)t0)[2]);}}

/* k4495 in k4449 in a4443 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4488 in k4449 in a4443 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4489(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4489,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t2,lf[15]));}

/* k4485 in k4449 in a4443 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 596  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4452 in k4449 in a4443 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4457,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4476,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
/* scrutinizer.scm: 600  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t4,((C_word*)t0)[2],lf[59],t1);}
else{
t5=t4;
f_4476(2,t5,t1);}}

/* k4474 in k4452 in k4449 in a4443 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4476,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4480,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm: 601  add-loc */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4478 in k4474 in k4452 in k4449 in a4443 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 599  walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_4156(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k4455 in k4452 in k4449 in a4443 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4464,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
/* scrutinizer.scm: 604  append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[67]+1)))(6,*((C_word*)lf[67]+1),t2,lf[131],((C_word*)t0)[2],t3,t1);}

/* k4462 in k4455 in k4452 in k4449 in a4443 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4464,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,t1));}

/* loop in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_4362(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4362,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4380,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* scrutinizer.scm: 585  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t6,t4,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4383,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4406,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=t5,a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4422,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_car(t2);
/* scrutinizer.scm: 587  real-name */
((C_proc3)C_retrieve_symbol_proc(lf[6]))(3,*((C_word*)lf[6]+1),t7,t8);}}

/* k4420 in loop in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 587  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),((C_word*)t0)[2],lf[128],t1);}

/* k4404 in loop in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4410,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
/* scrutinizer.scm: 588  walk */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4156(t5,t2,t3,((C_word*)t0)[2],((C_word*)t0)[6],t4);}

/* k4408 in k4404 in loop in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 586  single */
t2=((C_word*)t0)[5];
f_3367(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4381 in loop in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4383,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4398,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
/* scrutinizer.scm: 589  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t4,t5,t1,((C_word*)t0)[2]);}

/* k4396 in k4381 in loop in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 589  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_4362(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4378 in loop in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 585  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4156(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4345 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 565  single */
t2=((C_word*)t0)[4];
f_3367(t2,((C_word*)t0)[3],lf[125],t1,((C_word*)t0)[2]);}

/* k4234 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4239,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* scrutinizer.scm: 566  always-true */
t3=((C_word*)t0)[2];
f_1553(t3,t2,t1,((C_word*)t0)[10],((C_word*)t0)[8]);}

/* k4237 in k4234 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4242,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* scrutinizer.scm: 567  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4156(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[9],((C_word*)t0)[2]);}

/* k4240 in k4237 in k4234 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4245,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=t1,a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* scrutinizer.scm: 568  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4156(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[9],((C_word*)t0)[2]);}

/* k4243 in k4240 in k4237 in k4234 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4251,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[15]);
if(C_truep(t3)){
t4=t2;
f_4251(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_eqp(lf[15],t1);
t5=t2;
f_4251(t5,(C_word)C_i_not(t4));}}

/* k4249 in k4243 in k4240 in k4237 in k4234 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_4251(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4251,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4254,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4278,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4321,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm: 571  any */
((C_proc4)C_retrieve_symbol_proc(lf[70]))(4,*((C_word*)lf[70]+1),t4,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[8]);}
else{
t2=((C_word*)t0)[9];
f_4172(2,t2,lf[15]);}}

/* k4319 in k4249 in k4243 in k4240 in k4237 in k4234 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4321,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_4278(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4317,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 572  any */
((C_proc4)C_retrieve_symbol_proc(lf[70]))(4,*((C_word*)lf[70]+1),t2,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);}}

/* k4315 in k4319 in k4249 in k4243 in k4240 in k4237 in k4234 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4278(t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_length(((C_word*)t0)[3]);
t3=(C_word)C_i_length(((C_word*)t0)[2]);
t4=(C_word)C_eqp(t2,t3);
t5=((C_word*)t0)[4];
f_4278(t5,(C_word)C_i_not(t4));}}

/* k4276 in k4249 in k4243 in k4240 in k4237 in k4234 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_4278(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4278,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4285,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4289,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 578  pp-fragment */
t4=((C_word*)t0)[3];
f_3561(t4,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_4254(2,t2,C_SCHEME_UNDEFINED);}}

/* k4287 in k4276 in k4249 in k4243 in k4240 in k4237 in k4234 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 576  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),((C_word*)t0)[2],lf[124],t1);}

/* k4283 in k4276 in k4249 in k4243 in k4240 in k4237 in k4234 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 574  report */
t2=((C_word*)t0)[4];
f_3415(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4252 in k4249 in k4243 in k4240 in k4237 in k4234 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4254,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4259,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 579  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[123]+1)))(5,*((C_word*)lf[123]+1),((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4258 in k4252 in k4249 in k4243 in k4240 in k4237 in k4234 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4259(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4259,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=(C_word)C_a_i_cons(&a,2,lf[26],t5);
/* scrutinizer.scm: 579  simplify */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1744(3,t7,t1,t6);}

/* k4183 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_4185(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4185,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4172(2,t2,(C_word)C_a_i_list(&a,1,t1));}

/* k4170 in walk in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_retrieve(lf[66]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* noreturn-type? in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4124(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4124,3,t0,t1,t2);}
t3=(C_word)C_eqp(lf[81],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(lf[26],t4);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 552  any */
((C_proc4)C_retrieve_symbol_proc(lf[70]))(4,*((C_word*)lf[70]+1),t1,((C_word*)((C_word*)t0)[2])[1],t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_3581(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3581,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3584,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=C_retrieve(lf[66]);
t8=(C_word)C_i_car(t2);
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_length(t9);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3811,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t10,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=t3,a[8]=((C_word*)t0)[4],a[9]=t8,a[10]=((C_word*)t0)[5],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
/* scrutinizer.scm: 472  make-list */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),t11,t10,lf[15]);}

/* k3809 in call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3811,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[15],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[40],t3);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3640,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3778,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=t4,a[5]=((C_word*)t0)[7],a[6]=t5,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3803,a[2]=((C_word*)t0)[9],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm: 473  procedure-type? */
t8=((C_word*)((C_word*)t0)[2])[1];
f_3821(3,t8,t7,((C_word*)t0)[9]);}

/* k3801 in k3809 in call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3803,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_3778(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3799,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 474  match */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2481(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k3797 in k3801 in k3809 in call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3778(t2,(C_word)C_i_not(t1));}

/* k3776 in k3809 in call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_3778(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3778,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3785,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3789,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 479  pname */
t4=((C_word*)t0)[2];
f_3584(t4,t3);}
else{
t2=((C_word*)t0)[6];
f_3640(2,t2,C_SCHEME_UNDEFINED);}}

/* k3787 in k3776 in k3809 in call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 477  sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[4]))(6,*((C_word*)lf[4]+1),((C_word*)t0)[4],lf[106],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3783 in k3776 in k3809 in call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 475  report */
t2=((C_word*)t0)[4];
f_3415(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3638 in k3809 in call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3645,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3659,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a3658 in k3638 in k3809 in call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3659(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3659,4,t0,t1,t2,t3);}
t4=C_retrieve(lf[66]);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3666,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t3,a[9]=((C_word*)t0)[8],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t6=(C_word)C_i_length(t2);
t7=(C_word)C_eqp(t6,((C_word*)t0)[2]);
if(C_truep(t7)){
t8=t5;
f_3666(2,t8,C_SCHEME_UNDEFINED);}
else{
t8=(C_word)C_i_length(t2);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3759,a[2]=((C_word*)t0)[5],a[3]=t5,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3763,a[2]=t9,a[3]=((C_word*)t0)[2],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 490  pname */
t11=((C_word*)t0)[4];
f_3584(t11,t10);}}

/* k3761 in a3658 in k3638 in k3809 in call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[4],C_fix(1));
t3=(C_truep(t2)?lf[51]:lf[52]);
t4=(C_word)C_eqp(((C_word*)t0)[3],C_fix(1));
t5=(C_truep(t4)?lf[51]:lf[52]);
/* scrutinizer.scm: 488  sprintf */
((C_proc8)C_retrieve_symbol_proc(lf[4]))(8,*((C_word*)lf[4]+1),((C_word*)t0)[2],lf[105],t1,((C_word*)t0)[4],t3,((C_word*)t0)[3],t5);}

/* k3757 in a3658 in k3638 in k3809 in call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 486  report */
t2=((C_word*)t0)[4];
f_3415(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3664 in a3658 in k3638 in k3809 in call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3669,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[9]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3685,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_3685(t7,t2,t3,((C_word*)t0)[2],C_fix(1));}

/* doloop918 in k3664 in a3658 in k3638 in k3809 in call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_3685(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3685,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_nullp(t2);
t6=(C_truep(t5)?t5:(C_word)C_i_nullp(t3));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}
else{
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3698,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3716,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t9=(C_word)C_i_car(t3);
t10=(C_word)C_i_car(t2);
/* scrutinizer.scm: 496  match */
t11=((C_word*)((C_word*)t0)[2])[1];
f_2481(t11,t8,t9,t10);}}

/* k3714 in doloop918 in k3664 in a3658 in k3638 in k3809 in call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3716,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
f_3698(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3723,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3731,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm: 501  pname */
t5=((C_word*)t0)[2];
f_3584(t5,t4);}}

/* k3729 in k3714 in doloop918 in k3664 in a3658 in k3638 in k3809 in call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* scrutinizer.scm: 499  sprintf */
((C_proc7)C_retrieve_symbol_proc(lf[4]))(7,*((C_word*)lf[4]+1),((C_word*)t0)[4],lf[104],((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* k3721 in k3714 in doloop918 in k3664 in a3658 in k3638 in k3809 in call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 497  report */
t2=((C_word*)t0)[4];
f_3415(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3696 in doloop918 in k3664 in a3658 in k3638 in k3809 in call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
t5=((C_word*)((C_word*)t0)[3])[1];
f_3685(t5,((C_word*)t0)[2],t2,t3,t4);}

/* k3667 in k3664 in a3658 in k3638 in k3809 in call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3672,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
if(C_truep(t4)){
t5=t2;
f_3672(2,t5,t3);}
else{
t5=(C_word)C_i_memq(((C_word*)t0)[2],lf[102]);
t6=(C_truep(t5)?t5:(C_word)C_i_not_pair_p(((C_word*)t0)[2]));
if(C_truep(t6)){
t7=t2;
f_3672(2,t7,lf[15]);}
else{
t7=(C_word)C_i_car(((C_word*)t0)[2]);
t8=(C_word)C_eqp(lf[40],t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4048,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 539  call/cc */
((C_proc3)C_retrieve_proc(*((C_word*)lf[76]+1)))(3,*((C_word*)lf[76]+1),t2,t9);}
else{
/* scrutinizer.scm: 547  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[103],((C_word*)t0)[2]);}}}}

/* a4047 in k3667 in k3664 in a3658 in k3638 in k3809 in call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4048(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4048,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=(C_word)C_i_stringp(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4095,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_4095(t6,t4);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[2]);
t7=t5;
f_4095(t7,(C_word)C_i_symbolp(t6));}}

/* k4093 in a4047 in k3667 in k3664 in a3658 in k3638 in k3809 in call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_4095(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4095,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cdddr(((C_word*)t0)[4]):(C_word)C_i_cddr(((C_word*)t0)[4]));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4058,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4058(t6,((C_word*)t0)[2],t2);}

/* loop in k4093 in a4047 in k3667 in k3664 in a3658 in k3638 in k3809 in call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_4058(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4058,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_eqp(lf[15],t2);
if(C_truep(t3)){
/* scrutinizer.scm: 545  return */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,lf[15]);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4085,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 546  loop */
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* k4083 in loop in k4093 in a4047 in k3667 in k3664 in a3658 in k3638 in k3809 in call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_4085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4085,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3670 in k3667 in k3664 in a3658 in k3638 in k3809 in call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_retrieve(lf[66]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* a3644 in k3638 in k3809 in call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3645,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(C_word)C_i_length(t2);
/* scrutinizer.scm: 482  procedure-argument-types */
t4=((C_word*)t0)[3];
f_3863(t4,t1,((C_word*)t0)[2],t3);}

/* pname in call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_3584(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3584,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3592,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 462  fragment */
f_3507(t2,((C_word*)t0)[2]);}

/* k3590 in pname in call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3596,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3599,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
t5=t3;
f_3599(t5,(C_word)C_i_pairp(t4));}
else{
t4=t3;
f_3599(t4,C_SCHEME_FALSE);}}

/* k3597 in k3590 in pname in call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_3599(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3599,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3602,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* scrutinizer.scm: 464  source-info->line */
((C_proc3)C_retrieve_symbol_proc(lf[100]))(3,*((C_word*)lf[100]+1),t2,t3);}
else{
t2=((C_word*)t0)[3];
f_3596(2,t2,lf[101]);}}

/* k3600 in k3597 in k3590 in pname in call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_numberp(t1))){
/* scrutinizer.scm: 466  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),((C_word*)t0)[2],lf[98],t1);}
else{
t2=((C_word*)t0)[2];
f_3596(2,t2,lf[99]);}}

/* k3594 in k3590 in pname in call-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 460  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[4]))(5,*((C_word*)lf[4]+1),((C_word*)t0)[3],lf[97],((C_word*)t0)[2],t1);}

/* procedure-argument-types in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_3863(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3863,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_memq(t2,lf[94]);
t5=(C_truep(t4)?t4:(C_word)C_i_not_pair_p(t2));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3880,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 514  make-list */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),t6,t3,lf[15]);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(lf[40],t6);
if(C_truep(t7)){
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3889,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_i_cadr(t2);
t12=(C_word)C_i_stringp(t11);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3995,a[2]=t3,a[3]=t10,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t12)){
t14=t13;
f_3995(t14,t12);}
else{
t14=(C_word)C_i_cadr(t2);
t15=t13;
f_3995(t15,(C_word)C_i_symbolp(t14));}}
else{
/* scrutinizer.scm: 532  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t1,lf[96],t2);}}}

/* k3993 in procedure-argument-types in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_3995(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3995,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_caddr(((C_word*)t0)[6]):(C_word)C_i_cadr(((C_word*)t0)[6]));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3898,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_3898(t6,((C_word*)t0)[3],t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* loop in k3993 in procedure-argument-types in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_3898(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3898,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(lf[63],t5);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 525  loop */
t16=t1;
t17=t7;
t18=t3;
t19=C_SCHEME_TRUE;
t1=t16;
t2=t17;
t3=t18;
t4=t19;
goto loop;}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_eqp(lf[64],t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3928,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t10=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cadr(t2);
t12=t9;
f_3928(t12,(C_word)C_eqp(lf[65],t11));}
else{
t11=t9;
f_3928(t11,C_SCHEME_FALSE);}}
else{
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3959,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t10=t3;
t11=t9;
f_3959(t11,(C_word)C_fixnum_less_or_equal_p(t10,C_fix(0)));}
else{
t10=t9;
f_3959(t10,C_SCHEME_FALSE);}}}}}

/* k3957 in loop in k3993 in procedure-argument-types in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_3959(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3959,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3970,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
t5=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
/* scrutinizer.scm: 530  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_3898(t6,t3,t4,t5,((C_word*)t0)[2]);}}

/* k3968 in k3957 in loop in k3993 in procedure-argument-types in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3970,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3926 in loop in k3993 in procedure-argument-types in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_3928(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=f_2191(t3);
/* scrutinizer.scm: 528  make-list */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k3887 in procedure-argument-types in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 531  values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k3878 in procedure-argument-types in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 514  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* single in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_3367(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3367,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(lf[15],t3);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[15]);}
else{
t6=(C_word)C_i_length(t3);
t7=(C_word)C_eqp(C_fix(1),t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_car(t3));}
else{
t8=(C_word)C_eqp(t6,C_fix(0));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3395,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3399,a[2]=t4,a[3]=t9,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 418  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),t10,lf[91],t2);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3402,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3409,a[2]=t4,a[3]=t9,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t11=(C_word)C_eqp(t6,C_fix(1));
t12=(C_truep(t11)?lf[51]:lf[52]);
/* scrutinizer.scm: 423  sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[4]))(6,*((C_word*)lf[4]+1),t10,lf[92],t2,t6,t12);}}}}

/* k3407 in single in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 421  report */
t2=((C_word*)t0)[4];
f_3415(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3400 in single in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_car(((C_word*)t0)[2]));}

/* k3397 in single in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 416  report */
t2=((C_word*)t0)[4];
f_3415(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3393 in single in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[19]);}

/* match-results in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_2972(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2972,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_not_pair_p(t3));}
else{
t4=(C_word)C_eqp(lf[15],t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_eqp(lf[15],t3);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3006,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_car(t3);
/* scrutinizer.scm: 364  match */
t9=((C_word*)((C_word*)t0)[2])[1];
f_2481(t9,t6,t7,t8);}}}}}

/* k3004 in match-results in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* scrutinizer.scm: 365  match-results */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2972(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* match-args in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_2762(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2762,NULL,4,t0,t1,t2,t3);}
t4=C_retrieve(lf[66]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2768,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2827,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_2827(t9,t1,t2,t3,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* loop in match-args in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_2827(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2827,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=C_retrieve(lf[66]);
if(C_truep((C_word)C_i_nullp(t2))){
t7=t5;
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(C_word)C_i_nullp(t3);
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t9=(C_word)C_i_car(t3);
t10=t1;
t11=t10;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_i_memq(t9,lf[89]));}}}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t7=t4;
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(C_word)C_i_car(t2);
t9=t1;
t10=t9;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_i_memq(t8,lf[90]));}}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_eqp(lf[63],t7);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 350  loop */
t32=t1;
t33=t9;
t34=t3;
t35=C_SCHEME_TRUE;
t36=t5;
t1=t32;
t2=t33;
t3=t34;
t4=t35;
t5=t36;
goto loop;}
else{
t9=(C_word)C_i_car(t3);
t10=(C_word)C_eqp(lf[63],t9);
if(C_truep(t10)){
t11=(C_word)C_i_cdr(t3);
/* scrutinizer.scm: 352  loop */
t32=t1;
t33=t2;
t34=t11;
t35=t4;
t36=C_SCHEME_TRUE;
t1=t32;
t2=t33;
t3=t34;
t4=t35;
t5=t36;
goto loop;}
else{
t11=(C_word)C_i_car(t2);
t12=(C_word)C_eqp(lf[64],t11);
if(C_truep(t12)){
t13=(C_word)C_i_cdr(t2);
t14=f_2191(t13);
/* scrutinizer.scm: 354  match-rest */
t15=((C_word*)t0)[3];
f_2768(t15,t1,t14,t3);}
else{
t13=(C_word)C_i_car(t3);
t14=(C_word)C_eqp(lf[64],t13);
if(C_truep(t14)){
t15=(C_word)C_i_cdr(t3);
t16=f_2191(t15);
/* scrutinizer.scm: 356  match-rest */
t17=((C_word*)t0)[3];
f_2768(t17,t1,t16,t2);}
else{
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2935,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t16=(C_word)C_i_car(t2);
t17=(C_word)C_i_car(t3);
/* scrutinizer.scm: 357  match */
t18=((C_word*)((C_word*)t0)[2])[1];
f_2481(t18,t15,t16,t17);}}}}}}}

/* k2933 in loop in match-args in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* scrutinizer.scm: 357  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2827(t4,((C_word*)t0)[4],t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* match-rest in match-args in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_2768(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2768,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2774,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2786,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a2785 in match-rest in match-args in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2786(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2786,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2793,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2812,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 336  every */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),t4,t5,t2);}

/* a2811 in a2785 in match-rest in match-args in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2812(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2812,3,t0,t1,t2);}
/* match113 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2481(t3,t1,((C_word*)t0)[2],t2);}

/* k2791 in a2785 in match-rest in match-args in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2793,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2800,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* scrutinizer.scm: 337  rest-type */
t4=t2;
f_2800(t4,f_2191(t3));}
else{
t3=t2;
f_2800(t3,lf[15]);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2798 in k2791 in a2785 in match-rest in match-args in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_2800(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 337  match */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2481(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2773 in match-rest in match-args in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2780,tmp=(C_word)a,a+=2,tmp);
/* scrutinizer.scm: 335  break */
((C_proc4)C_retrieve_symbol_proc(lf[88]))(4,*((C_word*)lf[88]+1),t1,t2,((C_word*)t0)[2]);}

/* a2779 in a2773 in match-rest in match-args in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2780(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2780,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(lf[64],t2));}

/* match1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_2490(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2490,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_eqp(t2,lf[15]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_eqp(t3,lf[15]);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[81]);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(C_word)C_eqp(t3,lf[81]);
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[61]);
t10=(C_truep(t9)?(C_word)C_i_memq(t3,lf[82]):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
t11=(C_word)C_eqp(t3,lf[61]);
t12=(C_truep(t11)?(C_word)C_i_memq(t2,lf[83]):C_SCHEME_FALSE);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t13=(C_word)C_eqp(lf[40],t2);
if(C_truep(t13)){
if(C_truep((C_word)C_i_pairp(t3))){
t14=(C_word)C_i_car(t3);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_eqp(lf[40],t14));}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t14=(C_word)C_eqp(lf[40],t3);
if(C_truep(t14)){
if(C_truep((C_word)C_i_pairp(t2))){
t15=(C_word)C_i_car(t2);
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,(C_word)C_eqp(lf[40],t15));}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_FALSE);}}
else{
t15=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2577,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t16=(C_word)C_i_car(t2);
t17=t15;
f_2577(t17,(C_word)C_eqp(lf[26],t16));}
else{
t16=t15;
f_2577(t16,C_SCHEME_FALSE);}}}}}}}}}}}

/* k2575 in match1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_2577(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2577,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2582,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* scrutinizer.scm: 316  any */
((C_proc4)C_retrieve_symbol_proc(lf[70]))(4,*((C_word*)lf[70]+1),((C_word*)t0)[5],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2596,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=t2;
f_2596(t4,(C_word)C_eqp(lf[26],t3));}
else{
t3=t2;
f_2596(t3,C_SCHEME_FALSE);}}}

/* k2594 in k2575 in match1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_2596(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2596,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2601,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* scrutinizer.scm: 317  any */
((C_proc4)C_retrieve_symbol_proc(lf[70]))(4,*((C_word*)lf[70]+1),((C_word*)t0)[5],t2,t3);}
else{
t2=((C_word*)t0)[7];
if(C_truep((C_truep((C_word)C_eqp(t2,lf[84]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,lf[59]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_memq(((C_word*)t0)[6],lf[85]));}
else{
t3=((C_word*)t0)[7];
if(C_truep((C_truep((C_word)C_eqp(t3,lf[86]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,lf[59]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_memq(((C_word*)t0)[6],lf[87]));}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2633,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
t5=(C_word)C_i_car(((C_word*)t0)[7]);
t6=(C_word)C_i_car(((C_word*)t0)[6]);
t7=t4;
f_2633(t7,(C_word)C_eqp(t5,t6));}
else{
t5=t4;
f_2633(t5,C_SCHEME_FALSE);}}
else{
t5=t4;
f_2633(t5,C_SCHEME_FALSE);}}}}}

/* k2631 in k2594 in k2575 in match1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_2633(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2633,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_eqp(t2,lf[40]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2693,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* scrutinizer.scm: 323  named? */
f_2151(t4,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(t2,lf[45]);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?(C_word)C_i_equalp(((C_word*)t0)[7],((C_word*)t0)[6]):C_SCHEME_FALSE));}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2691 in k2631 in k2594 in k2575 in match1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2693,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_caddr(((C_word*)t0)[7]):(C_word)C_i_cadr(((C_word*)t0)[7]));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2684,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* scrutinizer.scm: 324  named? */
f_2151(t3,((C_word*)t0)[6]);}

/* k2682 in k2691 in k2631 in k2594 in k2575 in match1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2684,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_caddr(((C_word*)t0)[8]):(C_word)C_i_cadr(((C_word*)t0)[8]));
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2675,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* scrutinizer.scm: 325  named? */
f_2151(t3,((C_word*)t0)[7]);}

/* k2673 in k2682 in k2691 in k2631 in k2594 in k2575 in match1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2675,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cdddr(((C_word*)t0)[9]):(C_word)C_i_cddr(((C_word*)t0)[9]));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2666,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* scrutinizer.scm: 326  named? */
f_2151(t3,((C_word*)t0)[8]);}

/* k2664 in k2673 in k2682 in k2691 in k2631 in k2594 in k2575 in match1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2666,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cdddr(((C_word*)t0)[8]):(C_word)C_i_cddr(((C_word*)t0)[8]));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2660,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm: 327  match-args */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2762(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2658 in k2664 in k2673 in k2682 in k2691 in k2631 in k2594 in k2575 in match1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* scrutinizer.scm: 328  match-results */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2972(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a2600 in k2594 in k2575 in match1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2601(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2601,3,t0,t1,t2);}
/* match113 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2481(t3,t1,((C_word*)t0)[2],t2);}

/* a2581 in k2575 in match1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2582(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2582,3,t0,t1,t2);}
/* match113 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2481(t3,t1,t2,((C_word*)t0)[2]);}

/* match in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_2481(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2481,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2485,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 303  match1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2490(t5,t4,t2,t3);}

/* k2483 in match in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_retrieve(lf[66]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* merge-result-types in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_2415(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2415,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_i_not_pair_p(t2);
t5=(C_truep(t4)?t4:(C_word)C_i_not_pair_p(t3));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[15]);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2444,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_car(t3);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t7,t9);
t11=(C_word)C_a_i_cons(&a,2,lf[26],t10);
/* scrutinizer.scm: 300  simplify */
t12=((C_word*)((C_word*)t0)[2])[1];
f_1744(3,t12,t6,t11);}}}}

/* k2442 in merge-result-types in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2448,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* scrutinizer.scm: 301  merge-result-types */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2415(t5,t2,t3,t4);}

/* k2446 in k2442 in merge-result-types in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2448,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* merge-argument-types in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_2213(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2213,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_memq(t4,lf[77]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t3:lf[78]));}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(lf[64],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2248,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t7=(C_word)C_i_car(t3);
t8=t6;
f_2248(t8,(C_word)C_eqp(lf[64],t7));}
else{
t7=t6;
f_2248(t7,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(lf[63],t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2309,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t9=(C_word)C_i_car(t3);
t10=t8;
f_2309(t10,(C_word)C_eqp(lf[63],t9));}
else{
t9=t8;
f_2309(t9,C_SCHEME_FALSE);}}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2373,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_car(t2);
t10=(C_word)C_i_car(t3);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t9,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[26],t12);
/* scrutinizer.scm: 294  simplify */
t14=((C_word*)((C_word*)t0)[3])[1];
f_1744(3,t14,t8,t13);}}}}

/* k2371 in merge-argument-types in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2377,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* scrutinizer.scm: 295  merge-argument-types */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2213(t5,t2,t3,t4);}

/* k2375 in k2371 in merge-argument-types in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2377,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2307 in merge-argument-types in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_2309(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2309,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2320,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
t4=(C_word)C_i_cadr(((C_word*)t0)[4]);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=(C_word)C_a_i_cons(&a,2,lf[26],t6);
/* scrutinizer.scm: 291  simplify */
t8=((C_word*)((C_word*)t0)[2])[1];
f_1744(3,t8,t2,t7);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[80]);}}

/* k2318 in k2307 in merge-argument-types in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2324,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2328,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
t5=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* scrutinizer.scm: 292  merge-argument-types */
t6=((C_word*)((C_word*)t0)[2])[1];
f_2213(t6,t3,t4,t5);}

/* k2326 in k2318 in k2307 in merge-argument-types in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2322 in k2318 in k2307 in merge-argument-types in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2324,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[63],t2));}

/* k2246 in merge-argument-types in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_2248(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2248,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2259,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=f_2191(t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
t6=f_2191(t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t4,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[26],t8);
/* scrutinizer.scm: 284  simplify */
t10=((C_word*)((C_word*)t0)[2])[1];
f_1744(3,t10,t2,t9);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[79]);}}

/* k2257 in k2246 in merge-argument-types in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2259,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[64],t2));}

/* simplify1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_1753(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1753,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1759,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* scrutinizer.scm: 210  call/cc */
((C_proc3)C_retrieve_proc(*((C_word*)lf[76]+1)))(3,*((C_word*)lf[76]+1),t1,t3);}

/* a1758 in simplify1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1759(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1759,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[8]))){
t3=(C_word)C_i_car(((C_word*)t0)[8]);
t4=(C_word)C_eqp(t3,lf[26]);
if(C_truep(t4)){
t5=(C_word)C_i_length(((C_word*)t0)[8]);
t6=(C_word)C_eqp(C_fix(2),t5);
if(C_truep(t6)){
t7=(C_word)C_i_cadr(((C_word*)t0)[8]);
/* scrutinizer.scm: 215  simplify */
t8=((C_word*)((C_word*)t0)[7])[1];
f_1744(3,t8,t1,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1794,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* scrutinizer.scm: 216  every */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),t7,((C_word*)((C_word*)t0)[2])[1],t8);}}
else{
t5=(C_word)C_eqp(t3,lf[40]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2146,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 257  named? */
f_2151(t6,((C_word*)t0)[8]);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)t0)[8]);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[8]);}}

/* k2144 in a1758 in simplify1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2146,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[4]):C_SCHEME_FALSE);
t3=(C_truep(t2)?(C_word)C_i_cdddr(((C_word*)t0)[4]):(C_word)C_i_cddr(((C_word*)t0)[4]));
t4=(C_truep(t2)?(C_word)C_a_i_list(&a,1,t2):C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2124,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t4,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=(C_truep(t2)?(C_word)C_i_caddr(((C_word*)t0)[4]):(C_word)C_i_cadr(((C_word*)t0)[4]));
/* map */
t7=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)((C_word*)t0)[2])[1],t6);}

/* k2122 in k2144 in a1758 in simplify1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2124,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2114,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(lf[15],((C_word*)t0)[3]);
if(C_truep(t4)){
t5=t3;
f_2114(2,t5,lf[15]);}
else{
/* map */
t5=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);}}

/* k2112 in k2122 in k2144 in a1758 in simplify1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 259  append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[67]+1)))(6,*((C_word*)lf[67]+1),((C_word*)t0)[4],lf[75],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1792 in a1758 in simplify1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1794,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1800,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1897,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* scrutinizer.scm: 217  any */
((C_proc4)C_retrieve_symbol_proc(lf[70]))(4,*((C_word*)lf[70]+1),t2,t3,t4);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1908,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2040,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* scrutinizer.scm: 235  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[74]))(4,*((C_word*)lf[74]+1),t2,t3,t4);}}

/* a2039 in k1792 in a1758 in simplify1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2040(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2040,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2044,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 237  simplify */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1744(3,t4,t3,t2);}

/* k2042 in a2039 in k1792 in a1758 in simplify1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2050,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_i_car(t1);
t4=t2;
f_2050(t4,(C_word)C_eqp(lf[26],t3));}
else{
t3=t2;
f_2050(t3,C_SCHEME_FALSE);}}

/* k2048 in k2042 in a2039 in k1792 in a1758 in simplify1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_2050(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2050,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cdr(((C_word*)t0)[3]));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[19]);
if(C_truep(t2)){
/* scrutinizer.scm: 241  return */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[4],lf[19]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}}}

/* k1906 in k1792 in a1758 in simplify1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1911,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1950,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1950(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* loop in k1906 in k1792 in a1758 in simplify1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_1950(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1950,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* scrutinizer.scm: 245  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[73]+1)))(3,*((C_word*)lf[73]+1),t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(lf[15],t4);
if(C_truep(t5)){
/* scrutinizer.scm: 246  return */
t6=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t6))(3,t6,t1,lf[15]);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1975,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2022,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 247  any */
((C_proc4)C_retrieve_symbol_proc(lf[70]))(4,*((C_word*)lf[70]+1),t6,t7,t8);}}}

/* a2021 in loop in k1906 in k1792 in a1758 in simplify1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2022(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2022,3,t0,t1,t2);}
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* type<=?117 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3027(t4,t1,t3,t2);}

/* k1973 in loop in k1906 in k1792 in a1758 in simplify1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1975,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* scrutinizer.scm: 248  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1950(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1988,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 249  any */
((C_proc4)C_retrieve_symbol_proc(lf[70]))(4,*((C_word*)lf[70]+1),t2,t3,((C_word*)t0)[3]);}}

/* a2011 in k1973 in loop in k1906 in k1792 in a1758 in simplify1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_2012(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2012,3,t0,t1,t2);}
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* type<=?117 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3027(t4,t1,t3,t2);}

/* k1986 in k1973 in loop in k1906 in k1792 in a1758 in simplify1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1988,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* scrutinizer.scm: 250  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1950(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* scrutinizer.scm: 251  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_1950(t5,((C_word*)t0)[3],t2,t4);}}

/* k1909 in k1906 in k1792 in a1758 in simplify1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1911,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_equalp(t1,t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=C_retrieve(lf[66]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1931,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1938,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1940,tmp=(C_word)a,a+=2,tmp);
/* scrutinizer.scm: 255  any */
((C_proc4)C_retrieve_symbol_proc(lf[70]))(4,*((C_word*)lf[70]+1),t5,t6,t1);}}

/* a1939 in k1909 in k1906 in k1792 in a1758 in simplify1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1940(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1940,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(t2,lf[15]));}

/* k1936 in k1909 in k1906 in k1792 in a1758 in simplify1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[71]:((C_word*)t0)[3]);
/* ##sys#append */
t3=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST);}

/* k1929 in k1909 in k1906 in k1792 in a1758 in simplify1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1931,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[26],t1);
/* scrutinizer.scm: 255  simplify */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1744(3,t3,((C_word*)t0)[2],t2);}

/* a1896 in k1792 in a1758 in simplify1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1897(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1897,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(lf[40],t2));}

/* k1798 in k1792 in a1758 in simplify1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1800,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[40]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1805,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* scrutinizer.scm: 219  reduce */
((C_proc5)C_retrieve_symbol_proc(lf[69]))(5,*((C_word*)lf[69]+1),((C_word*)t0)[6],t2,C_SCHEME_FALSE,t3);}}

/* a1804 in k1798 in k1792 in a1758 in simplify1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1805,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* scrutinizer.scm: 221  named? */
f_2151(t4,t2);}

/* k1886 in a1804 in k1798 in k1792 in a1758 in simplify1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1888,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[7]):C_SCHEME_FALSE);
t3=(C_truep(t2)?(C_word)C_i_caddr(((C_word*)t0)[7]):(C_word)C_i_cadr(((C_word*)t0)[7]));
t4=(C_truep(t2)?(C_word)C_i_cdddr(((C_word*)t0)[7]):(C_word)C_i_cddr(((C_word*)t0)[7]));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1870,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* scrutinizer.scm: 224  named? */
f_2151(t5,((C_word*)t0)[6]);}

/* k1868 in k1886 in a1804 in k1798 in k1792 in a1758 in simplify1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1870,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[8]):C_SCHEME_FALSE);
t3=(C_truep(t2)?(C_word)C_i_caddr(((C_word*)t0)[8]):(C_word)C_i_cadr(((C_word*)t0)[8]));
t4=(C_truep(t2)?(C_word)C_i_cdddr(((C_word*)t0)[8]):(C_word)C_i_cddr(((C_word*)t0)[8]));
t5=(C_truep(((C_word*)t0)[7])?(C_truep(t2)?(C_word)C_eqp(((C_word*)t0)[7],t2):C_SCHEME_FALSE):C_SCHEME_FALSE);
t6=(C_truep(t5)?(C_word)C_a_i_list(&a,1,((C_word*)t0)[7]):C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1843,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* scrutinizer.scm: 230  merge-argument-types */
t8=((C_word*)((C_word*)t0)[3])[1];
f_2213(t8,t7,((C_word*)t0)[2],t3);}

/* k1841 in k1868 in k1886 in a1804 in k1798 in k1792 in a1758 in simplify1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1843,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1839,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 231  merge-result-types */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2415(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1837 in k1841 in k1868 in k1886 in a1804 in k1798 in k1792 in a1758 in simplify1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 227  append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[67]+1)))(6,*((C_word*)lf[67]+1),((C_word*)t0)[4],lf[68],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* simplify in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1744(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1744,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1748,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 206  simplify1 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1753(t4,t3,t2);}

/* k1746 in simplify in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_retrieve(lf[66]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* named? in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_2151(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2151,NULL,2,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(lf[40],t3);
if(C_truep(t4)){
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_nullp(t5);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2174,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t6)){
t8=t7;
f_2174(t8,t6);}
else{
t8=(C_word)C_i_cadr(t2);
t9=t7;
f_2174(t9,(C_word)C_i_pairp(t8));}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2172 in named? in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_2174(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* rest-type in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static C_word C_fcall f_2191(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(lf[15]);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_eqp(lf[65],t2);
return((C_truep(t3)?lf[15]:(C_word)C_i_car(t1)));}}

/* type<=? in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_3027(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3027,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_memq(t3,lf[58]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=t3;
t7=(C_word)C_eqp(t6,lf[59]);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_memq(t2,lf[60]));}
else{
t8=(C_word)C_eqp(t6,lf[40]);
if(C_truep(t8)){
if(C_truep((C_word)C_i_pairp(t2))){
t9=(C_word)C_i_car(t2);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_eqp(lf[40],t9));}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t6,lf[61]);
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_i_memq(t2,lf[62]));}
else{
if(C_truep((C_word)C_i_pairp(t2))){
if(C_truep((C_word)C_i_pairp(t3))){
t10=(C_word)C_i_car(t2);
t11=(C_word)C_eqp(t10,lf[26]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3103,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t13=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 377  every */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),t1,t12,t13);}
else{
t12=(C_word)C_eqp(t10,lf[40]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t2);
t14=(C_word)C_i_pairp(t13);
t15=(C_truep(t14)?(C_word)C_i_cadr(t2):(C_word)C_i_caddr(t2));
t16=(C_word)C_i_cadr(t3);
t17=(C_word)C_i_pairp(t16);
t18=(C_truep(t17)?(C_word)C_i_cadr(t3):(C_word)C_i_caddr(t3));
t19=(C_word)C_i_cadr(t2);
t20=(C_word)C_i_pairp(t19);
t21=(C_truep(t20)?(C_word)C_i_cddr(t2):(C_word)C_i_cdddr(t2));
t22=(C_word)C_i_cadr(t3);
t23=(C_word)C_i_pairp(t22);
t24=(C_truep(t23)?(C_word)C_i_cddr(t3):(C_word)C_i_cdddr(t3));
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_set_block_item(t26,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3134,a[2]=t26,a[3]=t24,a[4]=t21,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp));
t28=((C_word*)t26)[1];
f_3134(t28,t1,t15,t18,C_fix(0),C_fix(0));}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_UNDEFINED);}}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}}}}}}

/* loop1 in type<=? in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_3134(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3134,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(C_word)C_i_nullp(t3);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3150,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t8=t7;
f_3150(t8,t6);}
else{
t8=t5;
t9=t7;
f_3150(t9,(C_word)C_fixnum_greaterp(t8,C_fix(0)));}}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[63]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 398  loop1 */
t25=t1;
t26=t8;
t27=t3;
t28=C_fix(1);
t29=t5;
t1=t25;
t2=t26;
t3=t27;
t4=t28;
t5=t29;
goto loop;}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_eqp(t8,lf[63]);
if(C_truep(t9)){
t10=(C_word)C_i_cdr(t3);
/* scrutinizer.scm: 400  loop1 */
t25=t1;
t26=t2;
t27=t10;
t28=t4;
t29=C_fix(1);
t1=t25;
t2=t26;
t3=t27;
t4=t28;
t5=t29;
goto loop;}
else{
t10=(C_word)C_i_car(t2);
t11=(C_word)C_eqp(t10,lf[64]);
if(C_truep(t11)){
t12=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 402  loop1 */
t25=t1;
t26=t12;
t27=t3;
t28=C_fix(2);
t29=t5;
t1=t25;
t2=t26;
t3=t27;
t4=t28;
t5=t29;
goto loop;}
else{
t12=(C_word)C_i_car(t3);
t13=(C_word)C_eqp(t12,lf[64]);
if(C_truep(t13)){
t14=(C_word)C_i_cdr(t3);
/* scrutinizer.scm: 404  loop1 */
t25=t1;
t26=t2;
t27=t14;
t28=t4;
t29=C_fix(2);
t1=t25;
t2=t26;
t3=t27;
t4=t28;
t5=t29;
goto loop;}
else{
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3269,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t15=(C_word)C_i_car(t2);
t16=(C_word)C_i_car(t3);
/* scrutinizer.scm: 405  type<=? */
t17=((C_word*)((C_word*)t0)[5])[1];
f_3027(t17,t14,t15,t16);}}}}}}}

/* k3267 in loop1 in type<=? in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* scrutinizer.scm: 406  loop1 */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3134(t4,((C_word*)t0)[4],t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3148 in loop1 in type<=? in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_3150(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3150,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3155,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3155(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop2 in k3148 in loop1 in type<=? in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_3155(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3155,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(lf[15],t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_nullp(t2));}
else{
t5=(C_word)C_eqp(lf[15],t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3183,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_car(t3);
/* scrutinizer.scm: 393  type<=? */
t9=((C_word*)((C_word*)t0)[2])[1];
f_3027(t9,t6,t7,t8);}}}}

/* k3181 in loop2 in k3148 in loop1 in type<=? in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* scrutinizer.scm: 394  loop2 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3155(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a3102 in type<=? in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3103(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3103,3,t0,t1,t2);}
/* type<=?117 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3027(t3,t1,t2,((C_word*)t0)[2]);}

/* procedure-type? in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3821(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3821,3,t0,t1,t2);}
t3=(C_word)C_eqp(lf[40],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(lf[40],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(lf[26],t6);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 510  every */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),t1,((C_word*)((C_word*)t0)[2])[1],t8);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* result-string in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_1716(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1716,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(lf[15],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[55]);}
else{
t4=(C_word)C_i_length(t2);
t5=C_retrieve(lf[50]);
t6=(C_word)C_eqp(t5,C_fix(1));
t7=(C_truep(t6)?lf[51]:lf[52]);
t8=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[56]);}
else{
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1742,a[2]=t7,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* map */
t10=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,((C_word*)((C_word*)t0)[2])[1],t2);}}}

/* k1740 in result-string in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 201  sprintf */
((C_proc7)C_retrieve_symbol_proc(lf[4]))(7,*((C_word*)lf[4]+1),((C_word*)t0)[4],lf[57],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[2],t1);}

/* argument-string in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_1694(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1694,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_length(t2);
t4=C_retrieve(lf[50]);
t5=(C_word)C_eqp(t4,C_fix(1));
t6=(C_truep(t5)?lf[51]:lf[52]);
t7=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[53]);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1714,a[2]=t6,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* map */
t9=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)((C_word*)t0)[2])[1],t2);}}

/* k1712 in argument-string in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 190  sprintf */
((C_proc7)C_retrieve_symbol_proc(lf[4]))(7,*((C_word*)lf[4]+1),((C_word*)t0)[4],lf[54],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[2],t1);}

/* typename in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1573(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1573,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_eqp(t3,lf[15]);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[36]);}
else{
t5=(C_word)C_eqp(t3,lf[37]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[38]);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* scrutinizer.scm: 168  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[39]+1)))(3,*((C_word*)lf[39]+1),t1,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[40]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_i_stringp(t8);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1619,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t9)){
t11=t10;
f_1619(t11,t9);}
else{
t11=(C_word)C_i_cadr(t2);
t12=t10;
f_1619(t12,(C_word)C_i_symbolp(t11));}}
else{
t8=(C_word)C_eqp(t6,lf[26]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1669,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_i_cdr(t2);
/* map */
t11=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,((C_word*)((C_word*)t0)[2])[1],t10);}
else{
t9=(C_word)C_eqp(t6,lf[45]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(t2);
/* scrutinizer.scm: 182  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),t1,lf[46],t10);}
else{
/* scrutinizer.scm: 183  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t1,lf[48],t2);}}}}
else{
/* scrutinizer.scm: 184  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t1,lf[49],t2);}}}}}

/* k1667 in typename in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 178  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),((C_word*)t0)[2],t1,lf[44]);}

/* k1617 in typename in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_1619(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1619,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* scrutinizer.scm: 173  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),((C_word*)t0)[4],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1633,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* scrutinizer.scm: 175  argument-string */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1694(t4,t2,t3);}}

/* k1631 in k1617 in typename in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1633,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1637,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* scrutinizer.scm: 176  result-string */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1716(t4,t2,t3);}

/* k1635 in k1631 in k1617 in typename in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 174  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[4]))(5,*((C_word*)lf[4]+1),((C_word*)t0)[3],lf[42],((C_word*)t0)[2],t1);}

/* always-true in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_1553(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1553,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1557,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* scrutinizer.scm: 154  always-true1 */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1521(3,t6,t5,t2);}

/* k1555 in always-true in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1560,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1567,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1571,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 161  pp-fragment */
t5=((C_word*)t0)[3];
f_3561(t5,t4,((C_word*)t0)[2]);}
else{
t3=t2;
f_1560(2,t3,C_SCHEME_UNDEFINED);}}

/* k1569 in k1555 in always-true in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 158  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[4]))(5,*((C_word*)lf[4]+1),((C_word*)t0)[3],lf[35],((C_word*)t0)[2],t1);}

/* k1565 in k1555 in always-true in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 156  report */
t2=((C_word*)t0)[4];
f_3415(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1558 in k1555 in always-true in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* pp-fragment in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_3561(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3561,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3569,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3571,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 455  with-output-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[34]))(3,*((C_word*)lf[34]+1),t3,t4);}

/* a3570 in pp-fragment in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3579,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 457  fragment */
f_3507(t2,((C_word*)t0)[2]);}

/* k3577 in a3570 in pp-fragment in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 457  pp */
((C_proc3)C_retrieve_symbol_proc(lf[33]))(3,*((C_word*)lf[33]+1),((C_word*)t0)[2],t1);}

/* k3567 in pp-fragment in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 454  string-chomp */
((C_proc3)C_retrieve_symbol_proc(lf[32]))(3,*((C_word*)lf[32]+1),((C_word*)t0)[2],t1);}

/* fragment in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_3507(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3507,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3511,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 446  build-expression-tree */
((C_proc3)C_retrieve_symbol_proc(lf[31]))(3,*((C_word*)lf[31]+1),t3,t2);}

/* k3509 in fragment in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3511,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3516,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3516(t5,((C_word*)t0)[2],t1,C_fix(0));}

/* walk in k3509 in fragment in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_3516(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3516,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=t3;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,C_fix(3)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[27]);}
else{
if(C_truep((C_word)C_i_listp(t2))){
t5=(C_word)C_fixnum_increase(t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3543,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3551,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3555,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_length(t2);
/* scrutinizer.scm: 451  min */
((C_proc4)C_retrieve_proc(*((C_word*)lf[30]+1)))(4,*((C_word*)lf[30]+1),t8,C_fix(5),t9);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}}}

/* k3553 in walk in k3509 in fragment in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 451  take */
((C_proc4)C_retrieve_symbol_proc(lf[29]))(4,*((C_word*)lf[29]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3549 in walk in k3509 in fragment in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3539 in walk in k3509 in fragment in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3543(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3543,3,t0,t1,t2);}
/* g855856862 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3516(t3,t1,t2,((C_word*)t0)[2]);}

/* always-true1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1521(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1521,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1528,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=t3;
f_1528(t5,(C_word)C_eqp(lf[26],t4));}
else{
t4=t3;
f_1528(t4,C_SCHEME_FALSE);}}

/* k1526 in always-true1 in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_1528(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* scrutinizer.scm: 150  every */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}
else{
t2=(C_word)C_i_memq(((C_word*)t0)[4],lf[25]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_FALSE:C_SCHEME_TRUE));}}

/* variable-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_1465(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1465,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t2,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1512,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 135  get */
((C_proc5)C_retrieve_symbol_proc(lf[22]))(5,*((C_word*)lf[22]+1),t6,((C_word*)t0)[3],t2,lf[23]);}

/* k1510 in variable-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1512,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1519,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 136  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[17]))(4,*((C_word*)lf[17]+1),t2,((C_word*)t0)[2],lf[21]);}
else{
t2=((C_word*)t0)[3];
f_1472(t2,C_SCHEME_FALSE);}}

/* k1517 in k1510 in variable-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1472(t2,(C_word)C_i_not(t1));}

/* k1470 in variable-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_1472(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1472,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[15]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_eqp(lf[19],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1487,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1491,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1495,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 144  real-name */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t7,((C_word*)t0)[7],((C_word*)t0)[3]);}
else{
t5=(C_word)C_i_cdr(t2);
t6=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,1,t5));}}
else{
/* scrutinizer.scm: 147  global-result */
t3=((C_word*)t0)[2];
f_1440(t3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[4]);}}}

/* k1493 in k1470 in variable-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 143  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),((C_word*)t0)[2],lf[20],t1);}

/* k1489 in k1470 in variable-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 141  report */
t2=((C_word*)t0)[4];
f_3415(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1485 in k1470 in variable-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[15]);}

/* global-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_1440(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1440,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1444,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm: 121  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[17]))(4,*((C_word*)lf[17]+1),t4,t2,lf[18]);}

/* k1442 in global-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1444,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(t1,lf[14]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1456,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1460,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 130  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),t4,lf[16],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,1,t1));}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[15]);}}

/* k1458 in k1442 in global-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 128  report */
t2=((C_word*)t0)[4];
f_3415(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1454 in k1442 in global-result in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[15]);}

/* report in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_3415(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3415,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3423,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 430  location-name */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3425(t5,t4,t2);}

/* k3421 in report in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 427  compiler-warning */
((C_proc6)C_retrieve_symbol_proc(lf[11]))(6,*((C_word*)lf[11]+1),((C_word*)t0)[3],lf[12],lf[13],t1,((C_word*)t0)[2]);}

/* location-name in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_3425(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3425,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3428,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[8]);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3458,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_car(t2);
/* scrutinizer.scm: 438  lname */
f_3428(t5,t6);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3467,a[2]=t3,a[3]=t6,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3467(t8,t1,t2);}}}

/* rec in location-name in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_3467(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3467,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
/* scrutinizer.scm: 442  location-name */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3425(t4,t1,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3484,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t2);
/* scrutinizer.scm: 443  lname */
f_3428(t4,t5);}}

/* k3482 in rec in location-name in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3488,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* scrutinizer.scm: 443  rec */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3467(t4,t2,t3);}

/* k3486 in k3482 in rec in location-name in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 443  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[4]))(5,*((C_word*)lf[4]+1),((C_word*)t0)[3],lf[10],((C_word*)t0)[2],t1);}

/* k3456 in location-name in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 438  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),((C_word*)t0)[2],lf[9],t1);}

/* lname in location-name in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_fcall f_3428(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3428,NULL,2,t1,t2);}
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3439,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 434  real-name */
((C_proc3)C_retrieve_symbol_proc(lf[6]))(3,*((C_word*)lf[6]+1),t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[7]);}}

/* k3437 in lname in location-name in ##compiler#scrutinize in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_3439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 434  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),((C_word*)t0)[2],lf[5],t1);}

/* d in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 */
static void C_ccall f_1323(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_1323r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1323r(t0,t1,t2,t3);}}

static void C_ccall f_1323r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
if(C_truep((C_word)C_fudge(C_fix(13)))){
/* scrutinizer.scm: 74   printf */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t1,lf[2],t2,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[237] = {
{"toplevel:scrutinizer_scm",(void*)C_scrutinizer_toplevel},
{"f_1306:scrutinizer_scm",(void*)f_1306},
{"f_1309:scrutinizer_scm",(void*)f_1309},
{"f_1312:scrutinizer_scm",(void*)f_1312},
{"f_1315:scrutinizer_scm",(void*)f_1315},
{"f_1318:scrutinizer_scm",(void*)f_1318},
{"f_1321:scrutinizer_scm",(void*)f_1321},
{"f_4692:scrutinizer_scm",(void*)f_4692},
{"f_4696:scrutinizer_scm",(void*)f_4696},
{"f_4750:scrutinizer_scm",(void*)f_4750},
{"f_4699:scrutinizer_scm",(void*)f_4699},
{"f_4705:scrutinizer_scm",(void*)f_4705},
{"f_4743:scrutinizer_scm",(void*)f_4743},
{"f_4710:scrutinizer_scm",(void*)f_4710},
{"f_4717:scrutinizer_scm",(void*)f_4717},
{"f_4729:scrutinizer_scm",(void*)f_4729},
{"f_4723:scrutinizer_scm",(void*)f_4723},
{"f_1335:scrutinizer_scm",(void*)f_1335},
{"f_4156:scrutinizer_scm",(void*)f_4156},
{"f_4663:scrutinizer_scm",(void*)f_4663},
{"f_4661:scrutinizer_scm",(void*)f_4661},
{"f_4604:scrutinizer_scm",(void*)f_4604},
{"f_4642:scrutinizer_scm",(void*)f_4642},
{"f_4616:scrutinizer_scm",(void*)f_4616},
{"f_4632:scrutinizer_scm",(void*)f_4632},
{"f_4624:scrutinizer_scm",(void*)f_4624},
{"f_4628:scrutinizer_scm",(void*)f_4628},
{"f_4607:scrutinizer_scm",(void*)f_4607},
{"f_4526:scrutinizer_scm",(void*)f_4526},
{"f_4578:scrutinizer_scm",(void*)f_4578},
{"f_4582:scrutinizer_scm",(void*)f_4582},
{"f_4529:scrutinizer_scm",(void*)f_4529},
{"f_4574:scrutinizer_scm",(void*)f_4574},
{"f_4554:scrutinizer_scm",(void*)f_4554},
{"f_4561:scrutinizer_scm",(void*)f_4561},
{"f_4535:scrutinizer_scm",(void*)f_4535},
{"f_4541:scrutinizer_scm",(void*)f_4541},
{"f_4444:scrutinizer_scm",(void*)f_4444},
{"f_4504:scrutinizer_scm",(void*)f_4504},
{"f_4451:scrutinizer_scm",(void*)f_4451},
{"f_4497:scrutinizer_scm",(void*)f_4497},
{"f_4489:scrutinizer_scm",(void*)f_4489},
{"f_4487:scrutinizer_scm",(void*)f_4487},
{"f_4454:scrutinizer_scm",(void*)f_4454},
{"f_4476:scrutinizer_scm",(void*)f_4476},
{"f_4480:scrutinizer_scm",(void*)f_4480},
{"f_4457:scrutinizer_scm",(void*)f_4457},
{"f_4464:scrutinizer_scm",(void*)f_4464},
{"f_4362:scrutinizer_scm",(void*)f_4362},
{"f_4422:scrutinizer_scm",(void*)f_4422},
{"f_4406:scrutinizer_scm",(void*)f_4406},
{"f_4410:scrutinizer_scm",(void*)f_4410},
{"f_4383:scrutinizer_scm",(void*)f_4383},
{"f_4398:scrutinizer_scm",(void*)f_4398},
{"f_4380:scrutinizer_scm",(void*)f_4380},
{"f_4347:scrutinizer_scm",(void*)f_4347},
{"f_4236:scrutinizer_scm",(void*)f_4236},
{"f_4239:scrutinizer_scm",(void*)f_4239},
{"f_4242:scrutinizer_scm",(void*)f_4242},
{"f_4245:scrutinizer_scm",(void*)f_4245},
{"f_4251:scrutinizer_scm",(void*)f_4251},
{"f_4321:scrutinizer_scm",(void*)f_4321},
{"f_4317:scrutinizer_scm",(void*)f_4317},
{"f_4278:scrutinizer_scm",(void*)f_4278},
{"f_4289:scrutinizer_scm",(void*)f_4289},
{"f_4285:scrutinizer_scm",(void*)f_4285},
{"f_4254:scrutinizer_scm",(void*)f_4254},
{"f_4259:scrutinizer_scm",(void*)f_4259},
{"f_4185:scrutinizer_scm",(void*)f_4185},
{"f_4172:scrutinizer_scm",(void*)f_4172},
{"f_4124:scrutinizer_scm",(void*)f_4124},
{"f_3581:scrutinizer_scm",(void*)f_3581},
{"f_3811:scrutinizer_scm",(void*)f_3811},
{"f_3803:scrutinizer_scm",(void*)f_3803},
{"f_3799:scrutinizer_scm",(void*)f_3799},
{"f_3778:scrutinizer_scm",(void*)f_3778},
{"f_3789:scrutinizer_scm",(void*)f_3789},
{"f_3785:scrutinizer_scm",(void*)f_3785},
{"f_3640:scrutinizer_scm",(void*)f_3640},
{"f_3659:scrutinizer_scm",(void*)f_3659},
{"f_3763:scrutinizer_scm",(void*)f_3763},
{"f_3759:scrutinizer_scm",(void*)f_3759},
{"f_3666:scrutinizer_scm",(void*)f_3666},
{"f_3685:scrutinizer_scm",(void*)f_3685},
{"f_3716:scrutinizer_scm",(void*)f_3716},
{"f_3731:scrutinizer_scm",(void*)f_3731},
{"f_3723:scrutinizer_scm",(void*)f_3723},
{"f_3698:scrutinizer_scm",(void*)f_3698},
{"f_3669:scrutinizer_scm",(void*)f_3669},
{"f_4048:scrutinizer_scm",(void*)f_4048},
{"f_4095:scrutinizer_scm",(void*)f_4095},
{"f_4058:scrutinizer_scm",(void*)f_4058},
{"f_4085:scrutinizer_scm",(void*)f_4085},
{"f_3672:scrutinizer_scm",(void*)f_3672},
{"f_3645:scrutinizer_scm",(void*)f_3645},
{"f_3584:scrutinizer_scm",(void*)f_3584},
{"f_3592:scrutinizer_scm",(void*)f_3592},
{"f_3599:scrutinizer_scm",(void*)f_3599},
{"f_3602:scrutinizer_scm",(void*)f_3602},
{"f_3596:scrutinizer_scm",(void*)f_3596},
{"f_3863:scrutinizer_scm",(void*)f_3863},
{"f_3995:scrutinizer_scm",(void*)f_3995},
{"f_3898:scrutinizer_scm",(void*)f_3898},
{"f_3959:scrutinizer_scm",(void*)f_3959},
{"f_3970:scrutinizer_scm",(void*)f_3970},
{"f_3928:scrutinizer_scm",(void*)f_3928},
{"f_3889:scrutinizer_scm",(void*)f_3889},
{"f_3880:scrutinizer_scm",(void*)f_3880},
{"f_3367:scrutinizer_scm",(void*)f_3367},
{"f_3409:scrutinizer_scm",(void*)f_3409},
{"f_3402:scrutinizer_scm",(void*)f_3402},
{"f_3399:scrutinizer_scm",(void*)f_3399},
{"f_3395:scrutinizer_scm",(void*)f_3395},
{"f_2972:scrutinizer_scm",(void*)f_2972},
{"f_3006:scrutinizer_scm",(void*)f_3006},
{"f_2762:scrutinizer_scm",(void*)f_2762},
{"f_2827:scrutinizer_scm",(void*)f_2827},
{"f_2935:scrutinizer_scm",(void*)f_2935},
{"f_2768:scrutinizer_scm",(void*)f_2768},
{"f_2786:scrutinizer_scm",(void*)f_2786},
{"f_2812:scrutinizer_scm",(void*)f_2812},
{"f_2793:scrutinizer_scm",(void*)f_2793},
{"f_2800:scrutinizer_scm",(void*)f_2800},
{"f_2774:scrutinizer_scm",(void*)f_2774},
{"f_2780:scrutinizer_scm",(void*)f_2780},
{"f_2490:scrutinizer_scm",(void*)f_2490},
{"f_2577:scrutinizer_scm",(void*)f_2577},
{"f_2596:scrutinizer_scm",(void*)f_2596},
{"f_2633:scrutinizer_scm",(void*)f_2633},
{"f_2693:scrutinizer_scm",(void*)f_2693},
{"f_2684:scrutinizer_scm",(void*)f_2684},
{"f_2675:scrutinizer_scm",(void*)f_2675},
{"f_2666:scrutinizer_scm",(void*)f_2666},
{"f_2660:scrutinizer_scm",(void*)f_2660},
{"f_2601:scrutinizer_scm",(void*)f_2601},
{"f_2582:scrutinizer_scm",(void*)f_2582},
{"f_2481:scrutinizer_scm",(void*)f_2481},
{"f_2485:scrutinizer_scm",(void*)f_2485},
{"f_2415:scrutinizer_scm",(void*)f_2415},
{"f_2444:scrutinizer_scm",(void*)f_2444},
{"f_2448:scrutinizer_scm",(void*)f_2448},
{"f_2213:scrutinizer_scm",(void*)f_2213},
{"f_2373:scrutinizer_scm",(void*)f_2373},
{"f_2377:scrutinizer_scm",(void*)f_2377},
{"f_2309:scrutinizer_scm",(void*)f_2309},
{"f_2320:scrutinizer_scm",(void*)f_2320},
{"f_2328:scrutinizer_scm",(void*)f_2328},
{"f_2324:scrutinizer_scm",(void*)f_2324},
{"f_2248:scrutinizer_scm",(void*)f_2248},
{"f_2259:scrutinizer_scm",(void*)f_2259},
{"f_1753:scrutinizer_scm",(void*)f_1753},
{"f_1759:scrutinizer_scm",(void*)f_1759},
{"f_2146:scrutinizer_scm",(void*)f_2146},
{"f_2124:scrutinizer_scm",(void*)f_2124},
{"f_2114:scrutinizer_scm",(void*)f_2114},
{"f_1794:scrutinizer_scm",(void*)f_1794},
{"f_2040:scrutinizer_scm",(void*)f_2040},
{"f_2044:scrutinizer_scm",(void*)f_2044},
{"f_2050:scrutinizer_scm",(void*)f_2050},
{"f_1908:scrutinizer_scm",(void*)f_1908},
{"f_1950:scrutinizer_scm",(void*)f_1950},
{"f_2022:scrutinizer_scm",(void*)f_2022},
{"f_1975:scrutinizer_scm",(void*)f_1975},
{"f_2012:scrutinizer_scm",(void*)f_2012},
{"f_1988:scrutinizer_scm",(void*)f_1988},
{"f_1911:scrutinizer_scm",(void*)f_1911},
{"f_1940:scrutinizer_scm",(void*)f_1940},
{"f_1938:scrutinizer_scm",(void*)f_1938},
{"f_1931:scrutinizer_scm",(void*)f_1931},
{"f_1897:scrutinizer_scm",(void*)f_1897},
{"f_1800:scrutinizer_scm",(void*)f_1800},
{"f_1805:scrutinizer_scm",(void*)f_1805},
{"f_1888:scrutinizer_scm",(void*)f_1888},
{"f_1870:scrutinizer_scm",(void*)f_1870},
{"f_1843:scrutinizer_scm",(void*)f_1843},
{"f_1839:scrutinizer_scm",(void*)f_1839},
{"f_1744:scrutinizer_scm",(void*)f_1744},
{"f_1748:scrutinizer_scm",(void*)f_1748},
{"f_2151:scrutinizer_scm",(void*)f_2151},
{"f_2174:scrutinizer_scm",(void*)f_2174},
{"f_2191:scrutinizer_scm",(void*)f_2191},
{"f_3027:scrutinizer_scm",(void*)f_3027},
{"f_3134:scrutinizer_scm",(void*)f_3134},
{"f_3269:scrutinizer_scm",(void*)f_3269},
{"f_3150:scrutinizer_scm",(void*)f_3150},
{"f_3155:scrutinizer_scm",(void*)f_3155},
{"f_3183:scrutinizer_scm",(void*)f_3183},
{"f_3103:scrutinizer_scm",(void*)f_3103},
{"f_3821:scrutinizer_scm",(void*)f_3821},
{"f_1716:scrutinizer_scm",(void*)f_1716},
{"f_1742:scrutinizer_scm",(void*)f_1742},
{"f_1694:scrutinizer_scm",(void*)f_1694},
{"f_1714:scrutinizer_scm",(void*)f_1714},
{"f_1573:scrutinizer_scm",(void*)f_1573},
{"f_1669:scrutinizer_scm",(void*)f_1669},
{"f_1619:scrutinizer_scm",(void*)f_1619},
{"f_1633:scrutinizer_scm",(void*)f_1633},
{"f_1637:scrutinizer_scm",(void*)f_1637},
{"f_1553:scrutinizer_scm",(void*)f_1553},
{"f_1557:scrutinizer_scm",(void*)f_1557},
{"f_1571:scrutinizer_scm",(void*)f_1571},
{"f_1567:scrutinizer_scm",(void*)f_1567},
{"f_1560:scrutinizer_scm",(void*)f_1560},
{"f_3561:scrutinizer_scm",(void*)f_3561},
{"f_3571:scrutinizer_scm",(void*)f_3571},
{"f_3579:scrutinizer_scm",(void*)f_3579},
{"f_3569:scrutinizer_scm",(void*)f_3569},
{"f_3507:scrutinizer_scm",(void*)f_3507},
{"f_3511:scrutinizer_scm",(void*)f_3511},
{"f_3516:scrutinizer_scm",(void*)f_3516},
{"f_3555:scrutinizer_scm",(void*)f_3555},
{"f_3551:scrutinizer_scm",(void*)f_3551},
{"f_3543:scrutinizer_scm",(void*)f_3543},
{"f_1521:scrutinizer_scm",(void*)f_1521},
{"f_1528:scrutinizer_scm",(void*)f_1528},
{"f_1465:scrutinizer_scm",(void*)f_1465},
{"f_1512:scrutinizer_scm",(void*)f_1512},
{"f_1519:scrutinizer_scm",(void*)f_1519},
{"f_1472:scrutinizer_scm",(void*)f_1472},
{"f_1495:scrutinizer_scm",(void*)f_1495},
{"f_1491:scrutinizer_scm",(void*)f_1491},
{"f_1487:scrutinizer_scm",(void*)f_1487},
{"f_1440:scrutinizer_scm",(void*)f_1440},
{"f_1444:scrutinizer_scm",(void*)f_1444},
{"f_1460:scrutinizer_scm",(void*)f_1460},
{"f_1456:scrutinizer_scm",(void*)f_1456},
{"f_3415:scrutinizer_scm",(void*)f_3415},
{"f_3423:scrutinizer_scm",(void*)f_3423},
{"f_3425:scrutinizer_scm",(void*)f_3425},
{"f_3467:scrutinizer_scm",(void*)f_3467},
{"f_3484:scrutinizer_scm",(void*)f_3484},
{"f_3488:scrutinizer_scm",(void*)f_3488},
{"f_3458:scrutinizer_scm",(void*)f_3458},
{"f_3428:scrutinizer_scm",(void*)f_3428},
{"f_3439:scrutinizer_scm",(void*)f_3439},
{"f_1323:scrutinizer_scm",(void*)f_1323},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
