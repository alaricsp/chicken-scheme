/* Generated from utils.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-08-25 23:15
   Version 4.0.0x - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11761	compiled 2008-08-25 on tesseract.thetesseract.org (Linux)
   command line: utils.scm -optimize-level 2 -include-path . -include-path . -explicit-use -output-file utils.c
   unit: utils
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[50];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,15),40,109,97,107,112,97,116,32,112,97,116,116,50,55,41,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,12),40,97,51,51,55,32,115,121,109,51,57,41,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,37),40,35,35,115,121,115,35,97,112,114,111,112,111,115,45,105,110,116,101,114,110,101,100,32,112,97,116,116,51,54,32,101,110,118,51,55,41,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,10),40,97,51,54,51,32,97,52,57,41,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,97,112,114,111,112,111,115,45,109,97,99,114,111,115,32,112,97,116,116,52,52,32,101,110,118,52,53,41,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,97,112,114,111,112,111,115,32,112,97,116,116,54,54,32,101,110,118,54,55,32,46,32,116,109,112,54,53,54,56,41,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,35),40,37,97,112,114,111,112,111,115,45,108,105,115,116,32,108,111,99,56,57,32,112,97,116,116,57,48,32,97,114,103,115,57,49,41,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,15),40,115,121,109,108,101,110,32,115,121,109,49,51,57,41,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,32),40,97,112,114,111,112,111,115,45,108,105,115,116,32,112,97,116,116,49,52,52,32,46,32,114,101,115,116,49,52,53,41};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,49,53,55,32,105,49,54,53,41};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,13),40,97,53,54,54,32,115,121,109,49,53,53,41,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,13),40,97,54,51,53,32,115,121,109,49,53,51,41,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,27),40,97,112,114,111,112,111,115,32,112,97,116,116,49,52,55,32,46,32,114,101,115,116,49,52,56,41,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,27),40,115,121,115,116,101,109,42,32,102,115,116,114,49,57,50,32,46,32,97,114,103,115,49,57,51,41,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,33),40,102,111,114,45,101,97,99,104,45,108,105,110,101,32,112,114,111,99,50,48,54,32,46,32,112,111,114,116,50,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,6),40,97,55,49,56,41,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,13),40,97,55,51,57,32,97,114,103,50,52,48,41,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,29),40,102,111,114,45,101,97,99,104,45,97,114,103,118,45,108,105,110,101,32,116,104,117,110,107,50,50,54,41,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,6),40,97,55,54,51,41,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,20),40,114,101,97,100,45,97,108,108,32,46,32,102,105,108,101,50,52,53,41,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_utils_toplevel)
C_externexport void C_ccall C_utils_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_286)
static void C_ccall f_286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_289)
static void C_ccall f_289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_292)
static void C_ccall f_292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_295)
static void C_ccall f_295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_298)
static void C_ccall f_298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_746)
static void C_ccall f_746(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_746)
static void C_ccall f_746r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_750)
static void C_ccall f_750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_756)
static void C_ccall f_756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_764)
static void C_ccall f_764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_701)
static void C_ccall f_701(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_726)
static void C_ccall f_726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_740)
static void C_ccall f_740(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_719)
static void C_ccall f_719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_665)
static void C_ccall f_665(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_665)
static void C_ccall f_665r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_672)
static void C_ccall f_672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_677)
static void C_fcall f_677(C_word t0,C_word t1) C_noret;
C_noret_decl(f_681)
static void C_ccall f_681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_690)
static void C_ccall f_690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_647)
static void C_ccall f_647(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_647)
static void C_ccall f_647r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_651)
static void C_ccall f_651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_654)
static void C_ccall f_654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_555)
static void C_ccall f_555(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_555)
static void C_ccall f_555r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_559)
static void C_ccall f_559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_636)
static void C_ccall f_636(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_645)
static void C_ccall f_645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_562)
static void C_ccall f_562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_567)
static void C_ccall f_567(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_571)
static void C_ccall f_571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_634)
static void C_ccall f_634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_613)
static void C_fcall f_613(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_623)
static void C_ccall f_623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_574)
static void C_ccall f_574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_577)
static void C_ccall f_577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_580)
static void C_ccall f_580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_583)
static void C_ccall f_583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_592)
static void C_ccall f_592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_503)
static void C_ccall f_503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_586)
static void C_ccall f_586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_549)
static void C_ccall f_549(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_549)
static void C_ccall f_549r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_530)
static void C_fcall f_530(C_word t0,C_word t1) C_noret;
C_noret_decl(f_547)
static void C_ccall f_547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_540)
static void C_ccall f_540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_427)
static void C_fcall f_427(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_431)
static void C_ccall f_431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_449)
static void C_ccall f_449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_440)
static void C_ccall f_440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_463)
static C_word C_fcall f_463(C_word t0,C_word t1);
C_noret_decl(f_388)
static void C_ccall f_388(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_388)
static void C_ccall f_388r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_392)
static void C_ccall f_392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_395)
static void C_ccall f_395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_405)
static void C_ccall f_405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_354)
static void C_ccall f_354(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_359)
static void C_ccall f_359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_386)
static void C_ccall f_386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_364)
static void C_ccall f_364(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_382)
static void C_ccall f_382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_374)
static void C_ccall f_374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_362)
static void C_ccall f_362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_328)
static void C_ccall f_328(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_333)
static void C_ccall f_333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_338)
static void C_ccall f_338(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_352)
static void C_ccall f_352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_345)
static void C_ccall f_345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_301)
static void C_fcall f_301(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_326)
static void C_ccall f_326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_305)
static void C_fcall f_305(C_word t0,C_word t1) C_noret;
C_noret_decl(f_319)
static void C_ccall f_319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_315)
static void C_ccall f_315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_308)
static void C_fcall f_308(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_677)
static void C_fcall trf_677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_677(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_677(t0,t1);}

C_noret_decl(trf_613)
static void C_fcall trf_613(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_613(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_613(t0,t1,t2);}

C_noret_decl(trf_530)
static void C_fcall trf_530(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_530(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_530(t0,t1);}

C_noret_decl(trf_427)
static void C_fcall trf_427(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_427(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_427(t0,t1,t2,t3);}

C_noret_decl(trf_301)
static void C_fcall trf_301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_301(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_301(t0,t1,t2);}

C_noret_decl(trf_305)
static void C_fcall trf_305(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_305(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_305(t0,t1);}

C_noret_decl(trf_308)
static void C_fcall trf_308(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_308(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_308(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_utils_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_utils_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("utils_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(450)){
C_save(t1);
C_rereclaim2(450*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,50);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],20,"\003sysapropos-interned");
lf[3]=C_h_intern(&lf[3],18,"\003sysapropos-macros");
lf[4]=C_h_intern(&lf[4],13,"string-search");
lf[5]=C_h_intern(&lf[5],6,"regexp");
lf[6]=C_h_intern(&lf[6],13,"regexp-escape");
lf[7]=C_h_intern(&lf[7],14,"symbol->string");
lf[8]=C_h_intern(&lf[8],32,"\003syssymbol-has-toplevel-binding\077");
lf[9]=C_h_intern(&lf[9],23,"\003sysenvironment-symbols");
lf[10]=C_h_intern(&lf[10],12,"\003sysfor-each");
lf[11]=C_h_intern(&lf[11],21,"\003sysmacro-environment");
lf[12]=C_h_intern(&lf[12],11,"\003sysapropos");
lf[13]=C_h_intern(&lf[13],10,"\003sysappend");
lf[14]=C_h_intern(&lf[14],9,"\003syserror");
lf[15]=C_h_intern(&lf[15],12,"apropos-list");
lf[16]=C_h_intern(&lf[16],7,"apropos");
lf[17]=C_h_intern(&lf[17],8,"\000macros\077");
lf[18]=C_h_intern(&lf[18],11,"environment");
lf[19]=C_h_intern(&lf[19],15,"\003syssignal-hook");
lf[20]=C_h_intern(&lf[20],11,"\000type-error");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\0003bad argument type - not a string, symbol, or regexp");
lf[22]=C_h_intern(&lf[22],7,"regexp\077");
lf[23]=C_h_intern(&lf[23],23,"interaction-environment");
lf[24]=C_h_intern(&lf[24],8,"keyword\077");
lf[25]=C_h_intern(&lf[25],28,"\003syssymbol->qualified-string");
lf[26]=C_h_intern(&lf[26],7,"newline");
lf[27]=C_h_intern(&lf[27],7,"display");
lf[28]=C_h_intern(&lf[28],5,"macro");
lf[29]=C_h_intern(&lf[29],9,"procedure");
lf[30]=C_h_intern(&lf[30],21,"procedure-information");
lf[31]=C_h_intern(&lf[31],8,"variable");
lf[32]=C_h_intern(&lf[32],6,"macro\077");
lf[33]=C_h_intern(&lf[33],7,"sprintf");
lf[34]=C_h_intern(&lf[34],6,"system");
lf[35]=C_h_intern(&lf[35],7,"system*");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\0003shell invocation failed with non-zero return status");
lf[37]=C_h_intern(&lf[37],9,"read-line");
lf[38]=C_h_intern(&lf[38],13,"for-each-line");
lf[39]=C_h_intern(&lf[39],18,"\003sysstandard-input");
lf[40]=C_h_intern(&lf[40],14,"\003syscheck-port");
lf[41]=C_h_intern(&lf[41],18,"for-each-argv-line");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[43]=C_h_intern(&lf[43],20,"with-input-from-file");
lf[44]=C_h_intern(&lf[44],22,"command-line-arguments");
lf[45]=C_h_intern(&lf[45],8,"read-all");
lf[46]=C_h_intern(&lf[46],20,"\003sysread-string/port");
lf[47]=C_h_intern(&lf[47],5,"port\077");
lf[48]=C_h_intern(&lf[48],17,"register-feature!");
lf[49]=C_h_intern(&lf[49],5,"utils");
C_register_lf2(lf,50,create_ptable());
t2=C_mutate(&lf[0] /* c79 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_286,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k284 */
static void C_ccall f_286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_286,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_289,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k287 in k284 */
static void C_ccall f_289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_292,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k290 in k287 in k284 */
static void C_ccall f_292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_292,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_295,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k293 in k290 in k287 in k284 */
static void C_ccall f_295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_298,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("utils.scm: 55   register-feature!");
t3=*((C_word*)lf[48]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[49]);}

/* k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[48],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_298,2,t0,t1);}
t2=C_set_block_item(lf[2] /* apropos-interned */,0,C_SCHEME_UNDEFINED);
t3=C_set_block_item(lf[3] /* apropos-macros */,0,C_SCHEME_UNDEFINED);
t4=*((C_word*)lf[4]+1);
t5=*((C_word*)lf[5]+1);
t6=*((C_word*)lf[6]+1);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_301,a[2]=t6,a[3]=t5,a[4]=((C_word)li0),tmp=(C_word)a,a+=5,tmp);
t8=C_mutate((C_word*)lf[2]+1 /* apropos-interned ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_328,a[2]=t7,a[3]=t4,a[4]=((C_word)li2),tmp=(C_word)a,a+=5,tmp));
t9=C_mutate((C_word*)lf[3]+1 /* apropos-macros ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_354,a[2]=t7,a[3]=t4,a[4]=((C_word)li4),tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[12]+1 /* apropos ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_388,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t11=C_set_block_item(lf[15] /* apropos-list */,0,C_SCHEME_UNDEFINED);
t12=C_set_block_item(lf[16] /* apropos */,0,C_SCHEME_UNDEFINED);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_427,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_530,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp);
t15=C_mutate((C_word*)lf[15]+1 /* apropos-list ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_549,a[2]=t13,a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp));
t16=C_mutate((C_word*)lf[16]+1 /* apropos ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_555,a[2]=t13,a[3]=t14,a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp));
t17=*((C_word*)lf[33]+1);
t18=*((C_word*)lf[34]+1);
t19=C_mutate((C_word*)lf[35]+1 /* system* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_647,a[2]=t17,a[3]=t18,a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp));
t20=*((C_word*)lf[37]+1);
t21=C_mutate((C_word*)lf[38]+1 /* for-each-line ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_665,a[2]=t20,a[3]=((C_word)li16),tmp=(C_word)a,a+=4,tmp));
t22=C_mutate((C_word*)lf[41]+1 /* for-each-argv-line ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_701,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[45]+1 /* read-all ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_746,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t24=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t24+1)))(2,t24,C_SCHEME_UNDEFINED);}

/* read-all in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_746(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_746r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_746r(t0,t1,t2);}}

static void C_ccall f_746r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_750,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_750(2,t4,*((C_word*)lf[39]+1));}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_750(2,t5,(C_word)C_i_car(t2));}
else{
C_trace("##sys#error");
t5=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k748 in read-all in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_756,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("utils.scm: 209  port?");
t3=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k754 in k748 in read-all in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_756,2,t0,t1);}
if(C_truep(t1)){
C_trace("read-string/port");
t2=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_764,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp);
C_trace("utils.scm: 211  with-input-from-file");
t3=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* a763 in k754 in k748 in read-all in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_764,2,t0,t1);}
C_trace("read-string/port");
t2=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_SCHEME_FALSE,*((C_word*)lf[39]+1));}

/* for-each-argv-line in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_701(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_701,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_726,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("utils.scm: 197  command-line-arguments");
t4=*((C_word*)lf[44]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k724 in for-each-argv-line in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_726,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
C_trace("utils.scm: 200  for-each-line");
t2=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_740,a[2]=((C_word*)t0)[2],a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
C_trace("for-each");
t3=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,t1);}}

/* a739 in k724 in for-each-argv-line in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_740(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_740,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
if(C_truep((C_word)C_i_string_equal_p(t2,lf[42]))){
C_trace("utils.scm: 195  for-each-line");
t4=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_719,a[2]=t3,a[3]=((C_word)li17),tmp=(C_word)a,a+=4,tmp);
C_trace("utils.scm: 196  with-input-from-file");
t5=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t4);}}

/* a718 in a739 in k724 in for-each-argv-line in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_719,2,t0,t1);}
C_trace("for-each-line");
t2=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* for-each-line in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_665(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_665r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_665r(t0,t1,t2,t3);}}

static void C_ccall f_665r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):*((C_word*)lf[39]+1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_672,a[2]=t1,a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("utils.scm: 182  ##sys#check-port");
t7=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t5,lf[38]);}

/* k670 in for-each-line in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_672,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_677,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word)li15),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_677(t5,((C_word*)t0)[2]);}

/* loop in k670 in for-each-line in k296 in k293 in k290 in k287 in k284 */
static void C_fcall f_677(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_677,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_681,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("utils.scm: 184  read-line");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k679 in loop in k670 in for-each-line in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_681,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_690,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("utils.scm: 186  proc");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}}

/* k688 in k679 in loop in k670 in for-each-line in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("utils.scm: 187  loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_677(t2,((C_word*)t0)[2]);}

/* system* in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_647(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_647r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_647r(t0,t1,t2,t3);}}

static void C_ccall f_647r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_651,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,((C_word*)t0)[2],t2,t3);}

/* k649 in system* in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_654,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("utils.scm: 171  system");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k652 in k649 in system* in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
C_trace("utils.scm: 173  ##sys#error");
t3=*((C_word*)lf[14]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[36],((C_word*)t0)[2],t1);}}

/* apropos in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_555(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_555r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_555r(t0,t1,t2,t3);}}

static void C_ccall f_555r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_559,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("utils.scm: 139  %apropos-list");
f_427(t4,lf[16],t2,t3);}

/* k557 in apropos in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_559,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_562,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_636,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li12),tmp=(C_word)a,a+=5,tmp);
C_trace("for-each");
t6=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t1);}

/* a635 in k557 in apropos in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_636(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_636,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_645,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("utils.scm: 143  symlen");
f_530(t3,t2);}

/* k643 in a635 in k557 in apropos in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k560 in k557 in apropos in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_567,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word)li11),tmp=(C_word)a,a+=5,tmp);
C_trace("for-each");
t3=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a566 in k560 in k557 in apropos in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_567(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_567,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("utils.scm: 147  display");
t4=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k569 in a566 in k560 in k557 in apropos in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_574,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_634,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("utils.scm: 148  symlen");
f_530(t3,((C_word*)t0)[4]);}

/* k632 in k569 in a566 in k560 in k557 in apropos in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_634,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[3])[1],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_613,a[2]=t4,a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_613(t6,((C_word*)t0)[2],t2);}

/* doloop157 in k632 in k569 in a566 in k560 in k557 in apropos in k296 in k293 in k290 in k287 in k284 */
static void C_fcall f_613(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_613,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_623,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("utils.scm: 150  display");
t4=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_make_character(32));}}

/* k621 in doloop157 in k632 in k569 in a566 in k560 in k557 in apropos in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_613(t3,((C_word*)t0)[2],t2);}

/* k572 in k569 in a566 in k560 in k557 in apropos in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_577,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("utils.scm: 151  display");
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(32));}

/* k575 in k572 in k569 in a566 in k560 in k557 in apropos in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_577,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_580,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("utils.scm: 151  display");
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(58));}

/* k578 in k575 in k572 in k569 in a566 in k560 in k557 in apropos in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("utils.scm: 151  display");
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(32));}

/* k581 in k578 in k575 in k572 in k569 in a566 in k560 in k557 in apropos in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_586,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_592,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("utils.scm: 152  macro?");
t4=*((C_word*)lf[32]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k590 in k581 in k578 in k575 in k572 in k569 in a566 in k560 in k557 in apropos in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_592,2,t0,t1);}
if(C_truep(t1)){
C_trace("utils.scm: 154  display");
t2=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],lf[28]);}
else{
t2=(C_word)C_retrieve(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_503,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("utils.scm: 122  procedure-information");
t4=*((C_word*)lf[30]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
C_trace("utils.scm: 159  display");
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],lf[31]);}}}

/* k501 in k590 in k581 in k578 in k575 in k572 in k569 in a566 in k560 in k557 in apropos in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_503,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_cdr(t1);
t3=(C_word)C_a_i_cons(&a,2,lf[29],t2);
C_trace("utils.scm: 123  display");
t4=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}
else{
if(C_truep(t1)){
C_trace("utils.scm: 124  display");
t2=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[29]);}
else{
C_trace("utils.scm: 125  display");
t2=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[29]);}}}

/* k584 in k581 in k578 in k575 in k572 in k569 in a566 in k560 in k557 in apropos in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("utils.scm: 160  newline");
t2=*((C_word*)lf[26]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* apropos-list in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_549(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_549r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_549r(t0,t1,t2,t3);}}

static void C_ccall f_549r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_trace("utils.scm: 135  %apropos-list");
f_427(t1,lf[15],t2,t3);}

/* symlen in k296 in k293 in k290 in k287 in k284 */
static void C_fcall f_530(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_530,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_547,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("utils.scm: 128  ##sys#symbol->qualified-string");
t4=*((C_word*)lf[25]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k545 in symlen in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_547,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_540,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("utils.scm: 129  keyword?");
t4=*((C_word*)lf[24]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k538 in k545 in symlen in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_fixnum_difference(((C_word*)t0)[2],C_fix(2)):((C_word*)t0)[2]));}

/* %apropos-list in k296 in k293 in k290 in k287 in k284 */
static void C_fcall f_427(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_427,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_431,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
C_trace("utils.scm: 103  interaction-environment");
t6=*((C_word*)lf[23]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k429 in %apropos-list in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_431,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_463,a[2]=t3,a[3]=t5,a[4]=((C_word)li6),tmp=(C_word)a,a+=5,tmp);
t7=f_463(t6,((C_word*)t0)[5]);
t8=(C_word)C_i_check_structure_2(((C_word*)t3)[1],lf[18],((C_word*)t0)[4]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_440,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t10=(C_word)C_i_stringp(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_449,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t10)){
t12=t11;
f_449(2,t12,t10);}
else{
t12=(C_word)C_i_symbolp(((C_word*)t0)[2]);
if(C_truep(t12)){
t13=t11;
f_449(2,t13,t12);}
else{
C_trace("utils.scm: 117  regexp?");
t13=*((C_word*)lf[22]+1);
((C_proc3)C_retrieve_proc(t13))(3,t13,t11,((C_word*)t0)[2]);}}}

/* k447 in k429 in %apropos-list in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_440(2,t2,C_SCHEME_UNDEFINED);}
else{
C_trace("utils.scm: 118  ##sys#signal-hook");
t2=*((C_word*)lf[19]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[20],((C_word*)t0)[3],lf[21],((C_word*)t0)[2]);}}

/* k438 in k429 in %apropos-list in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("utils.scm: 119  ##sys#apropos");
t2=*((C_word*)lf[12]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* loop in k429 in %apropos-list in k296 in k293 in k290 in k287 in k284 */
static C_word C_fcall f_463(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
C_stack_check;
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_eqp(lf[17],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cadr(t1);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=(C_word)C_i_cddr(t1);
t10=t6;
t1=t10;
goto loop;}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=(C_word)C_i_cdr(t1);
t10=t5;
t1=t10;
goto loop;}}
else{
return(C_SCHEME_UNDEFINED);}}

/* ##sys#apropos in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_388(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_388r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_388r(t0,t1,t2,t3,t4);}}

static void C_ccall f_388r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_392,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_392(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_392(2,t7,(C_word)C_i_car(t4));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k390 in ##sys#apropos in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_395,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("utils.scm: 94   ##sys#apropos-interned");
t3=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k393 in k390 in ##sys#apropos in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_395,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_405,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("utils.scm: 96   ##sys#apropos-macros");
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* k403 in k393 in k390 in ##sys#apropos in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("utils.scm: 96   ##sys#append");
t2=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#apropos-macros in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_354(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_354,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_359,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
C_trace("utils.scm: 83   makpat");
t6=((C_word*)t0)[2];
f_301(t6,t5,((C_word*)t4)[1]);}

/* k357 in ##sys#apropos-macros in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_359,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_362,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_364,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word)li3),tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_386,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_trace("utils.scm: 90   ##sys#macro-environment");
t8=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}

/* k384 in k357 in ##sys#apropos-macros in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("for-each");
t2=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a363 in k357 in ##sys#apropos-macros in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_364(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_364,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_374,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_382,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("utils.scm: 88   symbol->string");
t6=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}

/* k380 in a363 in k357 in ##sys#apropos-macros in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("utils.scm: 88   string-search");
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k372 in a363 in k357 in ##sys#apropos-macros in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_374,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k360 in k357 in ##sys#apropos-macros in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##sys#apropos-interned in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_328(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_328,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_333,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
C_trace("utils.scm: 75   makpat");
t6=((C_word*)t0)[2];
f_301(t6,t5,((C_word*)t4)[1]);}

/* k331 in ##sys#apropos-interned in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_333,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_338,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word)li1),tmp=(C_word)a,a+=5,tmp);
C_trace("utils.scm: 76   ##sys#environment-symbols");
t4=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a337 in k331 in ##sys#apropos-interned in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_338(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_338,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_345,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_352,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("utils.scm: 78   symbol->string");
t5=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k350 in a337 in k331 in ##sys#apropos-interned in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("utils.scm: 78   string-search");
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k343 in a337 in k331 in ##sys#apropos-interned in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("utils.scm: 79   ##sys#symbol-has-toplevel-binding?");
t2=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* makpat in k296 in k293 in k290 in k287 in k284 */
static void C_fcall f_301(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_301,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_305,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t3)[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_326,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("utils.scm: 68   symbol->string");
t6=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t3)[1]);}
else{
t5=t4;
f_305(t5,C_SCHEME_UNDEFINED);}}

/* k324 in makpat in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_305(t3,t2);}

/* k303 in makpat in k296 in k293 in k290 in k287 in k284 */
static void C_fcall f_305(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_305,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_308,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[4])[1]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_315,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_319,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("utils.scm: 70   regexp-escape");
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t2;
f_308(t3,C_SCHEME_UNDEFINED);}}

/* k317 in k303 in makpat in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("utils.scm: 70   regexp");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k313 in k303 in makpat in k296 in k293 in k290 in k287 in k284 */
static void C_ccall f_315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_308(t3,t2);}

/* k306 in k303 in makpat in k296 in k293 in k290 in k287 in k284 */
static void C_fcall f_308(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[71] = {
{"toplevelutils.scm",(void*)C_utils_toplevel},
{"f_286utils.scm",(void*)f_286},
{"f_289utils.scm",(void*)f_289},
{"f_292utils.scm",(void*)f_292},
{"f_295utils.scm",(void*)f_295},
{"f_298utils.scm",(void*)f_298},
{"f_746utils.scm",(void*)f_746},
{"f_750utils.scm",(void*)f_750},
{"f_756utils.scm",(void*)f_756},
{"f_764utils.scm",(void*)f_764},
{"f_701utils.scm",(void*)f_701},
{"f_726utils.scm",(void*)f_726},
{"f_740utils.scm",(void*)f_740},
{"f_719utils.scm",(void*)f_719},
{"f_665utils.scm",(void*)f_665},
{"f_672utils.scm",(void*)f_672},
{"f_677utils.scm",(void*)f_677},
{"f_681utils.scm",(void*)f_681},
{"f_690utils.scm",(void*)f_690},
{"f_647utils.scm",(void*)f_647},
{"f_651utils.scm",(void*)f_651},
{"f_654utils.scm",(void*)f_654},
{"f_555utils.scm",(void*)f_555},
{"f_559utils.scm",(void*)f_559},
{"f_636utils.scm",(void*)f_636},
{"f_645utils.scm",(void*)f_645},
{"f_562utils.scm",(void*)f_562},
{"f_567utils.scm",(void*)f_567},
{"f_571utils.scm",(void*)f_571},
{"f_634utils.scm",(void*)f_634},
{"f_613utils.scm",(void*)f_613},
{"f_623utils.scm",(void*)f_623},
{"f_574utils.scm",(void*)f_574},
{"f_577utils.scm",(void*)f_577},
{"f_580utils.scm",(void*)f_580},
{"f_583utils.scm",(void*)f_583},
{"f_592utils.scm",(void*)f_592},
{"f_503utils.scm",(void*)f_503},
{"f_586utils.scm",(void*)f_586},
{"f_549utils.scm",(void*)f_549},
{"f_530utils.scm",(void*)f_530},
{"f_547utils.scm",(void*)f_547},
{"f_540utils.scm",(void*)f_540},
{"f_427utils.scm",(void*)f_427},
{"f_431utils.scm",(void*)f_431},
{"f_449utils.scm",(void*)f_449},
{"f_440utils.scm",(void*)f_440},
{"f_463utils.scm",(void*)f_463},
{"f_388utils.scm",(void*)f_388},
{"f_392utils.scm",(void*)f_392},
{"f_395utils.scm",(void*)f_395},
{"f_405utils.scm",(void*)f_405},
{"f_354utils.scm",(void*)f_354},
{"f_359utils.scm",(void*)f_359},
{"f_386utils.scm",(void*)f_386},
{"f_364utils.scm",(void*)f_364},
{"f_382utils.scm",(void*)f_382},
{"f_374utils.scm",(void*)f_374},
{"f_362utils.scm",(void*)f_362},
{"f_328utils.scm",(void*)f_328},
{"f_333utils.scm",(void*)f_333},
{"f_338utils.scm",(void*)f_338},
{"f_352utils.scm",(void*)f_352},
{"f_345utils.scm",(void*)f_345},
{"f_301utils.scm",(void*)f_301},
{"f_326utils.scm",(void*)f_326},
{"f_305utils.scm",(void*)f_305},
{"f_319utils.scm",(void*)f_319},
{"f_315utils.scm",(void*)f_315},
{"f_308utils.scm",(void*)f_308},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
