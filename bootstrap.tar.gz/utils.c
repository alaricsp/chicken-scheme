/* Generated from utils.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-03-11 20:07
   Version 3.0.6 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 9483	compiled 2008-03-11 on tablet (Linux)
   command line: utils.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file utils.c
   unit: utils
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[120];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,14),40,109,97,107,112,97,116,32,112,97,116,116,52,41,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,11),40,97,52,56,56,32,115,121,109,57,41,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,97,112,114,111,112,111,115,45,105,110,116,101,114,110,101,100,32,112,97,116,116,55,32,101,110,118,56,41,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,18),40,97,53,49,52,32,107,101,121,49,52,32,118,97,108,49,53,41,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,97,112,114,111,112,111,115,45,109,97,99,114,111,115,32,112,97,116,116,49,49,32,101,110,118,49,50,41,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,36),40,35,35,115,121,115,35,97,112,114,111,112,111,115,32,112,97,116,116,50,48,32,101,110,118,50,49,32,46,32,103,49,57,50,50,41,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,35),40,37,97,112,114,111,112,111,115,45,108,105,115,116,32,108,111,99,51,49,32,112,97,116,116,51,50,32,97,114,103,115,51,51,41,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,14),40,115,121,109,108,101,110,32,115,121,109,53,50,41,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,30),40,97,112,114,111,112,111,115,45,108,105,115,116,32,112,97,116,116,53,52,32,46,32,114,101,115,116,53,53,41,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,10),40,100,111,54,50,32,105,54,52,41,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,12),40,97,55,49,54,32,115,121,109,54,49,41,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,12),40,97,55,56,53,32,115,121,109,54,48,41,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,25),40,97,112,114,111,112,111,115,32,112,97,116,116,53,54,32,46,32,114,101,115,116,53,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,25),40,115,121,115,116,101,109,42,32,102,115,116,114,55,56,32,46,32,97,114,103,115,55,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,21),40,100,101,108,101,116,101,45,102,105,108,101,42,32,102,105,108,101,56,52,41,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,25),40,97,98,115,111,108,117,116,101,45,112,97,116,104,110,97,109,101,63,32,112,110,57,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,22),40,99,104,111,112,45,112,100,115,32,115,116,114,57,51,32,112,100,115,57,52,41,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,115,116,114,115,49,48,54,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,26),40,99,111,110,99,45,100,105,114,115,32,100,105,114,115,49,48,51,32,112,100,115,49,48,52,41,0,0,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,34),40,99,97,110,111,110,105,99,97,108,105,122,101,45,100,105,114,115,32,100,105,114,115,49,49,50,32,112,100,115,49,49,51,41,0,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,52),40,95,109,97,107,101,45,112,97,116,104,110,97,109,101,32,108,111,99,49,49,54,32,100,105,114,49,49,55,32,102,105,108,101,49,49,56,32,101,120,116,49,49,57,32,112,100,115,49,50,48,41,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,23),40,98,111,100,121,49,51,56,32,101,120,116,49,52,52,32,112,100,115,49,52,53,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,23),40,100,101,102,45,112,100,115,49,52,49,32,37,101,120,116,49,51,54,49,52,55,41,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,101,120,116,49,52,48,41,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,41),40,109,97,107,101,45,112,97,116,104,110,97,109,101,32,100,105,114,115,49,51,51,32,102,105,108,101,49,51,52,32,46,32,103,49,51,50,49,51,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,23),40,98,111,100,121,49,53,57,32,101,120,116,49,54,53,32,112,100,115,49,54,54,41,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,23),40,100,101,102,45,112,100,115,49,54,50,32,37,101,120,116,49,53,55,49,55,49,41,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,101,120,116,49,54,49,41,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,50),40,109,97,107,101,45,97,98,115,111,108,117,116,101,45,112,97,116,104,110,97,109,101,32,100,105,114,115,49,53,52,32,102,105,108,101,49,53,53,32,46,32,103,49,53,51,49,53,54,41,0,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,18),40,115,116,114,105,112,45,112,100,115,32,100,105,114,49,56,57,41,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,26),40,100,101,99,111,109,112,111,115,101,45,112,97,116,104,110,97,109,101,32,112,110,49,57,48,41,0,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,7),40,97,49,51,53,51,41,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,38),40,97,49,51,53,57,32,100,105,114,49,57,54,49,57,57,32,102,105,108,101,49,57,55,50,48,48,32,101,120,116,49,57,56,50,48,49,41,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,26),40,112,97,116,104,110,97,109,101,45,100,105,114,101,99,116,111,114,121,32,112,110,49,57,53,41,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,7),40,97,49,51,54,56,41,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,38),40,97,49,51,55,52,32,100,105,114,50,48,54,50,48,57,32,102,105,108,101,50,48,55,50,49,48,32,101,120,116,50,48,56,50,49,49,41,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,21),40,112,97,116,104,110,97,109,101,45,102,105,108,101,32,112,110,50,48,53,41,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,7),40,97,49,51,56,51,41,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,38),40,97,49,51,56,57,32,100,105,114,50,49,54,50,49,57,32,102,105,108,101,50,49,55,50,50,48,32,101,120,116,50,49,56,50,50,49,41,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,26),40,112,97,116,104,110,97,109,101,45,101,120,116,101,110,115,105,111,110,32,112,110,50,49,53,41,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,7),40,97,49,51,57,56,41,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,38),40,97,49,52,48,52,32,100,105,114,50,50,54,50,50,57,32,102,105,108,101,50,50,55,50,51,48,32,101,120,116,50,50,56,50,51,49,41,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,32),40,112,97,116,104,110,97,109,101,45,115,116,114,105,112,45,100,105,114,101,99,116,111,114,121,32,112,110,50,50,53,41};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,7),40,97,49,52,49,54,41,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,38),40,97,49,52,50,50,32,100,105,114,50,51,54,50,51,57,32,102,105,108,101,50,51,55,50,52,48,32,101,120,116,50,51,56,50,52,49,41,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,32),40,112,97,116,104,110,97,109,101,45,115,116,114,105,112,45,101,120,116,101,110,115,105,111,110,32,112,110,50,51,53,41};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,7),40,97,49,52,51,52,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,36),40,97,49,52,52,48,32,95,50,52,55,50,53,48,32,102,105,108,101,50,52,56,50,53,49,32,101,120,116,50,52,57,50,53,50,41,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,41),40,112,97,116,104,110,97,109,101,45,114,101,112,108,97,99,101,45,100,105,114,101,99,116,111,114,121,32,112,110,50,52,53,32,100,105,114,50,52,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,7),40,97,49,52,53,50,41,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,35),40,97,49,52,53,56,32,100,105,114,50,53,56,50,54,49,32,95,50,53,57,50,54,50,32,101,120,116,50,54,48,50,54,51,41,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,37),40,112,97,116,104,110,97,109,101,45,114,101,112,108,97,99,101,45,102,105,108,101,32,112,110,50,53,54,32,102,105,108,101,50,53,55,41,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,7),40,97,49,52,55,48,41,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,36),40,97,49,52,55,54,32,100,105,114,50,54,57,50,55,50,32,102,105,108,101,50,55,48,50,55,51,32,95,50,55,49,50,55,52,41,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,41),40,112,97,116,104,110,97,109,101,45,114,101,112,108,97,99,101,45,101,120,116,101,110,115,105,111,110,32,112,110,50,54,55,32,101,120,116,50,54,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,12),40,97,49,53,50,49,32,112,50,57,57,41,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,32),40,99,114,101,97,116,101,45,116,101,109,112,111,114,97,114,121,45,102,105,108,101,32,46,32,101,120,116,50,56,57,41};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,24),40,100,105,114,101,99,116,111,114,121,45,110,117,108,108,63,32,100,105,114,51,48,50,41};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,33),40,102,111,114,45,101,97,99,104,45,108,105,110,101,32,112,114,111,99,51,49,48,32,46,32,112,111,114,116,51,49,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,7),40,97,49,54,52,54,41,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,14),40,97,49,54,54,55,32,97,114,103,51,50,51,41,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,29),40,102,111,114,45,101,97,99,104,45,97,114,103,118,45,108,105,110,101,32,116,104,117,110,107,51,49,56,41,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,7),40,97,49,54,57,49,41,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,20),40,114,101,97,100,45,97,108,108,32,46,32,102,105,108,101,51,50,53,41,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,25),40,115,104,105,102,116,33,32,108,115,116,51,51,48,32,46,32,103,51,50,57,51,51,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,22),40,117,110,115,104,105,102,116,33,32,120,51,52,49,32,108,115,116,51,52,50,41,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,30),40,112,111,114,116,45,102,111,114,45,101,97,99,104,32,102,110,51,52,54,32,116,104,117,110,107,51,52,55,41,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,120,115,51,53,54,41,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,25),40,112,111,114,116,45,109,97,112,32,102,110,51,53,51,32,116,104,117,110,107,51,53,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,97,99,99,51,54,51,41,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,33),40,112,111,114,116,45,102,111,108,100,32,102,110,51,53,57,32,97,99,99,51,54,48,32,116,104,117,110,107,51,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,15),40,97,49,56,57,48,32,103,51,54,56,51,54,57,41,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,12),40,97,49,56,56,52,32,115,51,54,55,41,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,7),40,97,49,56,57,54,41,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,32),40,109,97,107,101,45,98,114,111,97,100,99,97,115,116,45,112,111,114,116,32,46,32,112,111,114,116,115,51,54,54,41};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,7),40,97,49,57,49,49,41,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,7),40,97,49,57,52,54,41,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,7),40,97,49,57,54,54,41,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,110,51,56,54,32,99,51,56,55,41};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,34),40,97,50,48,48,49,32,112,51,56,49,32,110,51,56,50,32,100,101,115,116,51,56,51,32,115,116,97,114,116,51,56,52,41,0,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,41),40,109,97,107,101,45,99,111,110,99,97,116,101,110,97,116,101,100,45,112,111,114,116,32,112,49,51,55,48,32,46,32,112,111,114,116,115,51,55,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_utils_toplevel)
C_externexport void C_ccall C_utils_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_437)
static void C_ccall f_437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_440)
static void C_ccall f_440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_443)
static void C_ccall f_443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2057)
static void C_ccall f_2057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_835)
static void C_ccall f_835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_838)
static void C_ccall f_838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1222)
static void C_ccall f_1222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1225)
static void C_ccall f_1225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1903)
static void C_ccall f_1903(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1903)
static void C_ccall f_1903r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2002)
static void C_ccall f_2002(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2008)
static void C_fcall f_2008(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2024)
static void C_ccall f_2024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2027)
static void C_fcall f_2027(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1967)
static void C_ccall f_1967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_fcall f_1973(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1983)
static void C_ccall f_1983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1947)
static void C_ccall f_1947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1912)
static void C_ccall f_1912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1918)
static void C_fcall f_1918(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1879)
static void C_ccall f_1879(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1879)
static void C_ccall f_1879r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1897)
static void C_ccall f_1897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1885)
static void C_ccall f_1885(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1891)
static void C_ccall f_1891(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1854)
static void C_ccall f_1854(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1860)
static void C_fcall f_1860(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1864)
static void C_ccall f_1864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1877)
static void C_ccall f_1877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1822)
static void C_ccall f_1822(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1828)
static void C_fcall f_1828(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1832)
static void C_ccall f_1832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1798)
static void C_ccall f_1798(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1804)
static void C_fcall f_1804(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1808)
static void C_ccall f_1808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1817)
static void C_ccall f_1817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1774)
static void C_ccall f_1774(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1717)
static void C_ccall f_1717(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1717)
static void C_ccall f_1717r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1721)
static void C_ccall f_1721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1674)
static void C_ccall f_1674(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1674)
static void C_ccall f_1674r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1678)
static void C_ccall f_1678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1684)
static void C_ccall f_1684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1692)
static void C_ccall f_1692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1629)
static void C_ccall f_1629(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1654)
static void C_ccall f_1654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1668)
static void C_ccall f_1668(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1647)
static void C_ccall f_1647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1593)
static void C_ccall f_1593(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1593)
static void C_ccall f_1593r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1600)
static void C_ccall f_1600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1605)
static void C_fcall f_1605(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1609)
static void C_ccall f_1609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1618)
static void C_ccall f_1618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1548)
static void C_ccall f_1548(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1556)
static void C_ccall f_1556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1558)
static C_word C_fcall f_1558(C_word t0);
C_noret_decl(f_1483)
static void C_ccall f_1483(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1483)
static void C_ccall f_1483r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1487)
static void C_ccall f_1487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1540)
static void C_ccall f_1540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1490)
static void C_ccall f_1490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1501)
static void C_fcall f_1501(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1531)
static void C_ccall f_1531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1527)
static void C_ccall f_1527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1508)
static void C_ccall f_1508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1514)
static void C_ccall f_1514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1522)
static void C_ccall f_1522(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1465)
static void C_ccall f_1465(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1477)
static void C_ccall f_1477(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1471)
static void C_ccall f_1471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1447)
static void C_ccall f_1447(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1459)
static void C_ccall f_1459(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1453)
static void C_ccall f_1453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1429)
static void C_ccall f_1429(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1441)
static void C_ccall f_1441(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1435)
static void C_ccall f_1435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1411)
static void C_ccall f_1411(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1423)
static void C_ccall f_1423(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1417)
static void C_ccall f_1417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1393)
static void C_ccall f_1393(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1405)
static void C_ccall f_1405(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1399)
static void C_ccall f_1399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1378)
static void C_ccall f_1378(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1390)
static void C_ccall f_1390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1384)
static void C_ccall f_1384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1363)
static void C_ccall f_1363(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1375)
static void C_ccall f_1375(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1369)
static void C_ccall f_1369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1348)
static void C_ccall f_1348(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1360)
static void C_ccall f_1360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1354)
static void C_ccall f_1354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1240)
static void C_ccall f_1240(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1256)
static void C_ccall f_1256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1285)
static void C_ccall f_1285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1310)
static void C_ccall f_1310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1295)
static void C_ccall f_1295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1266)
static void C_ccall f_1266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1226)
static void C_fcall f_1226(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1143)
static void C_ccall f_1143(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1143)
static void C_ccall f_1143r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1172)
static void C_fcall f_1172(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1167)
static void C_fcall f_1167(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1145)
static void C_fcall f_1145(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1153)
static void C_ccall f_1153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1159)
static void C_ccall f_1159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1156)
static void C_ccall f_1156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1079)
static void C_ccall f_1079(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1079)
static void C_ccall f_1079r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1095)
static void C_fcall f_1095(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1090)
static void C_fcall f_1090(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1081)
static void C_fcall f_1081(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1089)
static void C_ccall f_1089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_998)
static void C_fcall f_998(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1027)
static void C_ccall f_1027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1034)
static void C_fcall f_1034(C_word t0,C_word t1) C_noret;
C_noret_decl(f_967)
static void C_fcall f_967(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_906)
static void C_fcall f_906(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_915)
static void C_fcall f_915(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_945)
static void C_ccall f_945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_953)
static void C_ccall f_953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_852)
static void C_fcall f_852(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_868)
static void C_fcall f_868(C_word t0,C_word t1) C_noret;
C_noret_decl(f_839)
static void C_ccall f_839(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_850)
static void C_ccall f_850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_815)
static void C_ccall f_815(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_822)
static void C_ccall f_822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_828)
static void C_ccall f_828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_797)
static void C_ccall f_797(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_797)
static void C_ccall f_797r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_801)
static void C_ccall f_801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_804)
static void C_ccall f_804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_705)
static void C_ccall f_705(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_705)
static void C_ccall f_705r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_709)
static void C_ccall f_709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_786)
static void C_ccall f_786(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_795)
static void C_ccall f_795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_712)
static void C_ccall f_712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_717)
static void C_ccall f_717(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_721)
static void C_ccall f_721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_784)
static void C_ccall f_784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_763)
static void C_fcall f_763(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_773)
static void C_ccall f_773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_724)
static void C_ccall f_724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_727)
static void C_ccall f_727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_730)
static void C_ccall f_730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_733)
static void C_ccall f_733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_742)
static void C_ccall f_742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_653)
static void C_ccall f_653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_736)
static void C_ccall f_736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_699)
static void C_ccall f_699(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_699)
static void C_ccall f_699r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_680)
static void C_fcall f_680(C_word t0,C_word t1) C_noret;
C_noret_decl(f_697)
static void C_ccall f_697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_690)
static void C_ccall f_690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_577)
static void C_fcall f_577(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_581)
static void C_ccall f_581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_599)
static void C_ccall f_599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_590)
static void C_ccall f_590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_613)
static C_word C_fcall f_613(C_word t0,C_word t1);
C_noret_decl(f_532)
static void C_ccall f_532(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_532)
static void C_ccall f_532r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_536)
static void C_ccall f_536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_539)
static void C_ccall f_539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_549)
static void C_ccall f_549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_505)
static void C_ccall f_505(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_510)
static void C_ccall f_510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_515)
static void C_ccall f_515(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_530)
static void C_ccall f_530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_522)
static void C_ccall f_522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_513)
static void C_ccall f_513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_479)
static void C_ccall f_479(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_484)
static void C_ccall f_484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_489)
static void C_ccall f_489(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_503)
static void C_ccall f_503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_496)
static void C_ccall f_496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_452)
static void C_fcall f_452(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_477)
static void C_ccall f_477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_456)
static void C_fcall f_456(C_word t0,C_word t1) C_noret;
C_noret_decl(f_470)
static void C_ccall f_470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_466)
static void C_ccall f_466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_459)
static void C_fcall f_459(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2008)
static void C_fcall trf_2008(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2008(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2008(t0,t1,t2,t3);}

C_noret_decl(trf_2027)
static void C_fcall trf_2027(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2027(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2027(t0,t1);}

C_noret_decl(trf_1973)
static void C_fcall trf_1973(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1973(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1973(t0,t1);}

C_noret_decl(trf_1918)
static void C_fcall trf_1918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1918(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1918(t0,t1);}

C_noret_decl(trf_1860)
static void C_fcall trf_1860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1860(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1860(t0,t1,t2);}

C_noret_decl(trf_1828)
static void C_fcall trf_1828(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1828(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1828(t0,t1,t2);}

C_noret_decl(trf_1804)
static void C_fcall trf_1804(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1804(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1804(t0,t1);}

C_noret_decl(trf_1605)
static void C_fcall trf_1605(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1605(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1605(t0,t1);}

C_noret_decl(trf_1501)
static void C_fcall trf_1501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1501(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1501(t0,t1);}

C_noret_decl(trf_1226)
static void C_fcall trf_1226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1226(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1226(t0,t1);}

C_noret_decl(trf_1172)
static void C_fcall trf_1172(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1172(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1172(t0,t1);}

C_noret_decl(trf_1167)
static void C_fcall trf_1167(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1167(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1167(t0,t1,t2);}

C_noret_decl(trf_1145)
static void C_fcall trf_1145(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1145(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1145(t0,t1,t2,t3);}

C_noret_decl(trf_1095)
static void C_fcall trf_1095(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1095(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1095(t0,t1);}

C_noret_decl(trf_1090)
static void C_fcall trf_1090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1090(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1090(t0,t1,t2);}

C_noret_decl(trf_1081)
static void C_fcall trf_1081(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1081(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1081(t0,t1,t2,t3);}

C_noret_decl(trf_998)
static void C_fcall trf_998(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_998(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_998(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_1034)
static void C_fcall trf_1034(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1034(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1034(t0,t1);}

C_noret_decl(trf_967)
static void C_fcall trf_967(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_967(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_967(t0,t1,t2,t3);}

C_noret_decl(trf_906)
static void C_fcall trf_906(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_906(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_906(t0,t1,t2,t3);}

C_noret_decl(trf_915)
static void C_fcall trf_915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_915(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_915(t0,t1,t2);}

C_noret_decl(trf_852)
static void C_fcall trf_852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_852(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_852(t0,t1,t2);}

C_noret_decl(trf_868)
static void C_fcall trf_868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_868(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_868(t0,t1);}

C_noret_decl(trf_763)
static void C_fcall trf_763(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_763(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_763(t0,t1,t2);}

C_noret_decl(trf_680)
static void C_fcall trf_680(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_680(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_680(t0,t1);}

C_noret_decl(trf_577)
static void C_fcall trf_577(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_577(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_577(t0,t1,t2,t3);}

C_noret_decl(trf_452)
static void C_fcall trf_452(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_452(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_452(t0,t1,t2);}

C_noret_decl(trf_456)
static void C_fcall trf_456(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_456(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_456(t0,t1);}

C_noret_decl(trf_459)
static void C_fcall trf_459(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_459(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_459(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_utils_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_utils_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("utils_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(912)){
C_save(t1);
C_rereclaim2(912*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,120);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],19,"\003sysundefined-value");
lf[3]=C_h_intern(&lf[3],20,"\003sysapropos-interned");
lf[4]=C_h_intern(&lf[4],18,"\003sysapropos-macros");
lf[5]=C_h_intern(&lf[5],13,"string-search");
lf[6]=C_h_intern(&lf[6],6,"regexp");
lf[7]=C_h_intern(&lf[7],13,"regexp-escape");
lf[8]=C_h_intern(&lf[8],14,"symbol->string");
lf[9]=C_h_intern(&lf[9],32,"\003syssymbol-has-toplevel-binding\077");
lf[10]=C_h_intern(&lf[10],23,"\003sysenvironment-symbols");
lf[11]=C_h_intern(&lf[11],23,"\003syshash-table-for-each");
lf[12]=C_h_intern(&lf[12],21,"\003sysmacro-environment");
lf[13]=C_h_intern(&lf[13],11,"\003sysapropos");
lf[14]=C_h_intern(&lf[14],10,"\003sysappend");
lf[15]=C_h_intern(&lf[15],9,"\003syserror");
lf[16]=C_h_intern(&lf[16],12,"apropos-list");
lf[17]=C_h_intern(&lf[17],7,"apropos");
lf[18]=C_h_intern(&lf[18],8,"\000macros\077");
lf[19]=C_h_intern(&lf[19],11,"environment");
lf[20]=C_h_intern(&lf[20],15,"\003syssignal-hook");
lf[21]=C_h_intern(&lf[21],11,"\000type-error");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\0003bad argument type - not a string, symbol, or regexp");
lf[23]=C_h_intern(&lf[23],7,"regexp\077");
lf[24]=C_h_intern(&lf[24],23,"interaction-environment");
lf[25]=C_h_intern(&lf[25],8,"keyword\077");
lf[26]=C_h_intern(&lf[26],28,"\003syssymbol->qualified-string");
lf[27]=C_h_intern(&lf[27],7,"newline");
lf[28]=C_h_intern(&lf[28],7,"display");
lf[29]=C_h_intern(&lf[29],5,"macro");
lf[30]=C_h_intern(&lf[30],9,"procedure");
lf[31]=C_h_intern(&lf[31],21,"procedure-information");
lf[32]=C_h_intern(&lf[32],8,"variable");
lf[33]=C_h_intern(&lf[33],6,"macro\077");
lf[34]=C_h_intern(&lf[34],12,"\003sysfor-each");
lf[35]=C_h_intern(&lf[35],7,"sprintf");
lf[36]=C_h_intern(&lf[36],6,"system");
lf[37]=C_h_intern(&lf[37],7,"system*");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\0003shell invocation failed with non-zero return status");
lf[39]=C_h_intern(&lf[39],12,"file-exists\077");
lf[40]=C_h_intern(&lf[40],11,"delete-file");
lf[41]=C_h_intern(&lf[41],12,"delete-file*");
lf[42]=C_h_intern(&lf[42],12,"string-match");
lf[43]=C_h_intern(&lf[43],13,"string-append");
lf[44]=C_h_intern(&lf[44],20,"\003syswindows-platform");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\014([A-Za-z]:)\077");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[47]=C_h_intern(&lf[47],18,"absolute-pathname\077");
lf[49]=C_h_intern(&lf[49],13,"\003syssubstring");
lf[50]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000/\376\003\000\000\002\376\377\012\000\000\134\376\377\016");
lf[51]=C_h_intern(&lf[51],13,"make-pathname");
lf[52]=C_h_intern(&lf[52],22,"make-absolute-pathname");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[60]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[61]=C_h_intern(&lf[61],17,"\003sysstring-append");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[64]=C_h_intern(&lf[64],18,"decompose-pathname");
lf[65]=C_h_intern(&lf[65],18,"pathname-directory");
lf[66]=C_h_intern(&lf[66],13,"pathname-file");
lf[67]=C_h_intern(&lf[67],18,"pathname-extension");
lf[68]=C_h_intern(&lf[68],24,"pathname-strip-directory");
lf[69]=C_h_intern(&lf[69],24,"pathname-strip-extension");
lf[70]=C_h_intern(&lf[70],26,"pathname-replace-directory");
lf[71]=C_h_intern(&lf[71],21,"pathname-replace-file");
lf[72]=C_h_intern(&lf[72],26,"pathname-replace-extension");
lf[73]=C_h_intern(&lf[73],6,"getenv");
lf[74]=C_h_intern(&lf[74],21,"call-with-output-file");
lf[75]=C_h_intern(&lf[75],21,"create-temporary-file");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\003tmp");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\003TMP");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\004TEMP");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\006TMPDIR");
lf[81]=C_h_intern(&lf[81],15,"directory-null\077");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[84]=C_h_intern(&lf[84],12,"string-split");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[86]=C_h_intern(&lf[86],9,"read-line");
lf[87]=C_h_intern(&lf[87],13,"for-each-line");
lf[88]=C_h_intern(&lf[88],18,"\003sysstandard-input");
lf[89]=C_h_intern(&lf[89],14,"\003syscheck-port");
lf[90]=C_h_intern(&lf[90],18,"for-each-argv-line");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[92]=C_h_intern(&lf[92],20,"with-input-from-file");
lf[93]=C_h_intern(&lf[93],22,"command-line-arguments");
lf[94]=C_h_intern(&lf[94],8,"read-all");
lf[95]=C_h_intern(&lf[95],20,"\003sysread-string/port");
lf[96]=C_h_intern(&lf[96],5,"port\077");
lf[97]=C_h_intern(&lf[97],6,"shift!");
lf[98]=C_h_intern(&lf[98],8,"unshift!");
lf[99]=C_h_intern(&lf[99],13,"port-for-each");
lf[100]=C_h_intern(&lf[100],7,"reverse");
lf[101]=C_h_intern(&lf[101],8,"port-map");
lf[102]=C_h_intern(&lf[102],9,"port-fold");
lf[103]=C_h_intern(&lf[103],19,"make-broadcast-port");
lf[104]=C_h_intern(&lf[104],12,"write-string");
lf[105]=C_h_intern(&lf[105],12,"flush-output");
lf[106]=C_h_intern(&lf[106],16,"make-output-port");
lf[107]=C_h_intern(&lf[107],4,"noop");
lf[108]=C_h_intern(&lf[108],22,"make-concatenated-port");
lf[109]=C_h_intern(&lf[109],18,"\003sysread-char/port");
lf[110]=C_h_intern(&lf[110],11,"char-ready\077");
lf[111]=C_h_intern(&lf[111],9,"peek-char");
lf[112]=C_h_intern(&lf[112],12,"read-string!");
lf[113]=C_h_intern(&lf[113],15,"make-input-port");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\034^(.*[\134/\134\134])\077((\134.)\077[^\134/\134\134]+)$");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000&^(.*[\134/\134\134])\077([^\134/\134\134]+)(\134.([^\134/\134\134.]+))$");
lf[116]=C_h_intern(&lf[116],21,"make-anchored-pattern");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\010[\134/\134\134].*");
lf[118]=C_h_intern(&lf[118],17,"register-feature!");
lf[119]=C_h_intern(&lf[119],5,"utils");
C_register_lf2(lf,120,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_437,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k435 */
static void C_ccall f_437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_440,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k438 in k435 */
static void C_ccall f_440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_443,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 69   register-feature! */
t3=*((C_word*)lf[118]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[119]);}

/* k441 in k438 in k435 */
static void C_ccall f_443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_443,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=C_mutate((C_word*)lf[3]+1,t2);
t4=*((C_word*)lf[2]+1);
t5=C_mutate((C_word*)lf[4]+1,t4);
t6=*((C_word*)lf[5]+1);
t7=*((C_word*)lf[6]+1);
t8=*((C_word*)lf[7]+1);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_452,a[2]=t8,a[3]=t7,a[4]=((C_word)li0),tmp=(C_word)a,a+=5,tmp);
t10=C_mutate((C_word*)lf[3]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_479,a[2]=t9,a[3]=t6,a[4]=((C_word)li2),tmp=(C_word)a,a+=5,tmp));
t11=C_mutate((C_word*)lf[4]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_505,a[2]=t9,a[3]=t6,a[4]=((C_word)li4),tmp=(C_word)a,a+=5,tmp));
t12=C_mutate((C_word*)lf[13]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_532,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[2]+1);
t14=C_mutate((C_word*)lf[16]+1,t13);
t15=*((C_word*)lf[2]+1);
t16=C_mutate((C_word*)lf[17]+1,t15);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_577,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_680,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp);
t19=C_mutate((C_word*)lf[16]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_699,a[2]=t17,a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp));
t20=C_mutate((C_word*)lf[17]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_705,a[2]=t17,a[3]=t18,a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp));
t21=*((C_word*)lf[35]+1);
t22=*((C_word*)lf[36]+1);
t23=C_mutate((C_word*)lf[37]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_797,a[2]=t21,a[3]=t22,a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp));
t24=*((C_word*)lf[39]+1);
t25=*((C_word*)lf[40]+1);
t26=C_mutate((C_word*)lf[41]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_815,a[2]=t24,a[3]=t25,a[4]=((C_word)li15),tmp=(C_word)a,a+=5,tmp));
t27=*((C_word*)lf[42]+1);
t28=*((C_word*)lf[6]+1);
t29=*((C_word*)lf[43]+1);
t30=(C_truep(*((C_word*)lf[44]+1))?lf[45]:lf[46]);
t31=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_835,a[2]=t28,a[3]=((C_word*)t0)[2],a[4]=t27,tmp=(C_word)a,a+=5,tmp);
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2057,a[2]=t31,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 205  string-append */
t33=t29;
((C_proc4)C_retrieve_proc(t33))(4,t33,t32,t30,lf[117]);}

/* k2055 in k441 in k438 in k435 */
static void C_ccall f_2057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 205  make-anchored-pattern */
t2=*((C_word*)lf[116]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k833 in k441 in k438 in k435 */
static void C_ccall f_835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_835,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_838,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 206  regexp */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_838,2,t0,t1);}
t2=C_mutate((C_word*)lf[47]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_839,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li16),tmp=(C_word)a,a+=5,tmp));
t3=C_mutate(&lf[48],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_852,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t4=*((C_word*)lf[2]+1);
t5=C_mutate((C_word*)lf[51]+1,t4);
t6=*((C_word*)lf[2]+1);
t7=C_mutate((C_word*)lf[52]+1,t6);
t8=*((C_word*)lf[43]+1);
t9=*((C_word*)lf[47]+1);
t10=lf[53];
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_906,a[2]=t8,a[3]=t10,a[4]=((C_word)li19),tmp=(C_word)a,a+=5,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_967,a[2]=t11,a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_998,a[2]=t8,a[3]=((C_word)li21),tmp=(C_word)a,a+=4,tmp);
t14=C_mutate((C_word*)lf[51]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1079,a[2]=t12,a[3]=t13,a[4]=((C_word)li25),tmp=(C_word)a,a+=5,tmp));
t15=C_mutate((C_word*)lf[52]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1143,a[2]=t12,a[3]=t9,a[4]=t10,a[5]=t13,a[6]=((C_word)li29),tmp=(C_word)a,a+=7,tmp));
t16=*((C_word*)lf[42]+1);
t17=*((C_word*)lf[6]+1);
t18=*((C_word*)lf[43]+1);
t19=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1222,a[2]=t17,a[3]=((C_word*)t0)[2],a[4]=t16,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 289  regexp */
t20=t17;
((C_proc3)C_retrieve_proc(t20))(3,t20,t19,lf[115]);}

/* k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1222,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1225,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 290  regexp */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[114]);}

/* k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word ab[84],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1225,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1226,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp);
t3=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1240,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li31),tmp=(C_word)a,a+=7,tmp));
t4=*((C_word*)lf[2]+1);
t5=C_mutate((C_word*)lf[65]+1,t4);
t6=*((C_word*)lf[2]+1);
t7=C_mutate((C_word*)lf[66]+1,t6);
t8=*((C_word*)lf[2]+1);
t9=C_mutate((C_word*)lf[67]+1,t8);
t10=*((C_word*)lf[2]+1);
t11=C_mutate((C_word*)lf[68]+1,t10);
t12=*((C_word*)lf[2]+1);
t13=C_mutate((C_word*)lf[69]+1,t12);
t14=*((C_word*)lf[2]+1);
t15=C_mutate((C_word*)lf[70]+1,t14);
t16=*((C_word*)lf[2]+1);
t17=C_mutate((C_word*)lf[71]+1,t16);
t18=*((C_word*)lf[2]+1);
t19=C_mutate((C_word*)lf[72]+1,t18);
t20=*((C_word*)lf[64]+1);
t21=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1348,a[2]=t20,a[3]=((C_word)li34),tmp=(C_word)a,a+=4,tmp));
t22=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1363,a[2]=t20,a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp));
t23=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1378,a[2]=t20,a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp));
t24=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1393,a[2]=t20,a[3]=((C_word)li43),tmp=(C_word)a,a+=4,tmp));
t25=C_mutate((C_word*)lf[69]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1411,a[2]=t20,a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp));
t26=C_mutate((C_word*)lf[70]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1429,a[2]=t20,a[3]=((C_word)li49),tmp=(C_word)a,a+=4,tmp));
t27=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1447,a[2]=t20,a[3]=((C_word)li52),tmp=(C_word)a,a+=4,tmp));
t28=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1465,a[2]=t20,a[3]=((C_word)li55),tmp=(C_word)a,a+=4,tmp));
t29=*((C_word*)lf[73]+1);
t30=*((C_word*)lf[51]+1);
t31=*((C_word*)lf[39]+1);
t32=*((C_word*)lf[74]+1);
t33=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1483,a[2]=t29,a[3]=t30,a[4]=t31,a[5]=t32,a[6]=((C_word)li58),tmp=(C_word)a,a+=7,tmp));
t34=C_mutate((C_word*)lf[81]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1548,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp));
t35=*((C_word*)lf[86]+1);
t36=C_mutate((C_word*)lf[87]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1593,a[2]=t35,a[3]=((C_word)li62),tmp=(C_word)a,a+=4,tmp));
t37=C_mutate((C_word*)lf[90]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1629,a[2]=((C_word)li65),tmp=(C_word)a,a+=3,tmp));
t38=C_mutate((C_word*)lf[94]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1674,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp));
t39=C_mutate((C_word*)lf[97]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1717,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp));
t40=C_mutate((C_word*)lf[98]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1774,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t41=C_mutate((C_word*)lf[99]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1798,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t42=*((C_word*)lf[100]+1);
t43=C_mutate((C_word*)lf[101]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1822,a[2]=t42,a[3]=((C_word)li73),tmp=(C_word)a,a+=4,tmp));
t44=C_mutate((C_word*)lf[102]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1854,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[103]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1879,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[108]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1903,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t47=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t47+1)))(2,t47,C_SCHEME_UNDEFINED);}

/* make-concatenated-port in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1903(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr3r,(void*)f_1903r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1903r(t0,t1,t2,t3);}}

static void C_ccall f_1903r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(21);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1912,a[2]=t6,a[3]=((C_word)li81),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1947,a[2]=t6,a[3]=((C_word)li82),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1967,a[2]=t6,a[3]=((C_word)li84),tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2002,a[2]=t6,a[3]=((C_word)li86),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 483  make-input-port */
t11=*((C_word*)lf[113]+1);
((C_proc7)C_retrieve_proc(t11))(7,t11,t1,t7,t8,*((C_word*)lf[107]+1),t9,t10);}

/* a2001 in make-concatenated-port in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_2002(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2002,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2008,a[2]=t4,a[3]=t5,a[4]=t7,a[5]=((C_word*)t0)[2],a[6]=((C_word)li85),tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_2008(t9,t1,t3,C_fix(0));}

/* loop in a2001 in make-concatenated-port in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_fcall f_2008(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2008,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[5])[1]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2024,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(((C_word*)((C_word*)t0)[5])[1]);
t6=(C_word)C_fixnum_plus(((C_word*)t0)[3],t3);
/* utils.scm: 511  read-string! */
t7=*((C_word*)lf[112]+1);
((C_proc6)C_retrieve_proc(t7))(6,t7,t4,t2,((C_word*)t0)[2],t5,t6);}}}

/* k2022 in loop in a2001 in make-concatenated-port in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_2024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2027,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,((C_word*)t0)[6]))){
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_2027(t5,t4);}
else{
t3=t2;
f_2027(t3,C_SCHEME_UNDEFINED);}}

/* k2025 in k2022 in loop in a2001 in make-concatenated-port in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_fcall f_2027(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],((C_word*)t0)[5]);
/* utils.scm: 514  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2008(t4,((C_word*)t0)[2],t2,t3);}

/* a1966 in make-concatenated-port in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1967,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1973,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word)li83),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1973(t5,t1);}

/* loop in a1966 in make-concatenated-port in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_fcall f_1973(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1973,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1983,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* utils.scm: 501  peek-char */
t4=*((C_word*)lf[111]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}}

/* k1981 in loop in a1966 in make-concatenated-port in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_eofp(t1))){
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
/* utils.scm: 504  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1973(t4,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* a1946 in make-concatenated-port in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1947,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[2])[1]);
/* utils.scm: 495  char-ready? */
t3=*((C_word*)lf[110]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}}

/* a1911 in make-concatenated-port in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1912,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1918,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word)li80),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1918(t5,t1);}

/* loop in a1911 in make-concatenated-port in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_fcall f_1918(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1918,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1928,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* read-char/port */
t4=*((C_word*)lf[109]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}}

/* k1926 in loop in a1911 in make-concatenated-port in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_eofp(t1))){
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
/* utils.scm: 491  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1918(t4,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* make-broadcast-port in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1879(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr2r,(void*)f_1879r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1879r(t0,t1,t2);}}

static void C_ccall f_1879r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1885,a[2]=t2,a[3]=((C_word)li77),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1897,a[2]=t2,a[3]=((C_word)li78),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 476  make-output-port */
t5=*((C_word*)lf[106]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t3,*((C_word*)lf[107]+1),t4);}

/* a1896 in make-broadcast-port in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1897,2,t0,t1);}
/* for-each */
t2=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,*((C_word*)lf[105]+1),((C_word*)t0)[2]);}

/* a1884 in make-broadcast-port in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1885(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1885,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1891,a[2]=t2,a[3]=((C_word)li76),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,((C_word*)t0)[2]);}

/* a1890 in a1884 in make-broadcast-port in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1891(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1891,3,t0,t1,t2);}
/* write-string */
t3=*((C_word*)lf[104]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[2],C_SCHEME_FALSE,t2);}

/* port-fold in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1854(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1854,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1860,a[2]=t4,a[3]=t2,a[4]=t6,a[5]=((C_word)li74),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_1860(t8,t1,t3);}

/* loop in port-fold in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_fcall f_1860(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1860,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1864,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 468  thunk */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k1862 in loop in port-fold in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1864,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_FILE);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1877,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 471  fn */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t1,((C_word*)t0)[4]);}}

/* k1875 in k1862 in loop in port-fold in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 471  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1860(t2,((C_word*)t0)[2],t1);}

/* port-map in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1822(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1822,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1828,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=((C_word)li72),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_1828(t7,t1,C_SCHEME_END_OF_LIST);}

/* loop in port-map in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_fcall f_1828(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1828,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1832,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 461  thunk */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k1830 in loop in port-map in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1832,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_FILE);
if(C_truep(t2)){
/* utils.scm: 463  reverse */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1852,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 464  fn */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}}

/* k1850 in k1830 in loop in port-map in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1852,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* utils.scm: 464  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1828(t3,((C_word*)t0)[2],t2);}

/* port-for-each in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1798(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1798,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1804,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=((C_word)li70),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_1804(t7,t1);}

/* loop in port-for-each in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_fcall f_1804(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1804,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1808,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 452  thunk */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1806 in loop in port-for-each in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1808,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_FILE);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1817,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 454  fn */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}}

/* k1815 in k1806 in loop in port-for-each in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 455  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1804(t2,((C_word*)t0)[2]);}

/* unshift! in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1774(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1774,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_pair_2(t3,lf[98]);
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_slot(t3,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_i_setslot(t3,C_fix(1),t7);
t9=(C_word)C_i_setslot(t3,C_fix(0),t2);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t3);}

/* shift! in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1717(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1717r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1717r(t0,t1,t2,t3);}}

static void C_ccall f_1717r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1721,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_1721(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_1721(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1719 in shift! in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_check_pair_2(((C_word*)t0)[3],lf[97]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t5=(C_word)C_i_check_pair_2(t4,lf[97]);
t6=(C_word)C_slot(t4,C_fix(1));
t7=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t6);
t8=(C_word)C_slot(t4,C_fix(0));
t9=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(0),t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t3);}}

/* read-all in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1674(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1674r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1674r(t0,t1,t2);}}

static void C_ccall f_1674r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1678,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_1678(2,t4,*((C_word*)lf[88]+1));}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_1678(2,t5,(C_word)C_i_car(t2));}
else{
/* utils.scm: 421  ##sys#error */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k1676 in read-all in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1684,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 422  port? */
t3=*((C_word*)lf[96]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k1682 in k1676 in read-all in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1684,2,t0,t1);}
if(C_truep(t1)){
/* read-string/port */
t2=*((C_word*)lf[95]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1692,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 424  with-input-from-file */
t3=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* a1691 in k1682 in k1676 in read-all in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1692,2,t0,t1);}
/* read-string/port */
t2=*((C_word*)lf[95]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_SCHEME_FALSE,*((C_word*)lf[88]+1));}

/* for-each-argv-line in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1629(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1629,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1654,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 410  command-line-arguments */
t4=*((C_word*)lf[93]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1652 in for-each-argv-line in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1654,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
/* utils.scm: 413  for-each-line */
t2=*((C_word*)lf[87]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1668,a[2]=((C_word*)t0)[2],a[3]=((C_word)li64),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t3=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,t1);}}

/* a1667 in k1652 in for-each-argv-line in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1668(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1668,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
if(C_truep((C_word)C_i_string_equal_p(t2,lf[91]))){
/* utils.scm: 408  for-each-line */
t4=*((C_word*)lf[87]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1647,a[2]=t3,a[3]=((C_word)li63),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 409  with-input-from-file */
t5=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t4);}}

/* a1646 in a1667 in k1652 in for-each-argv-line in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1647,2,t0,t1);}
/* for-each-line */
t2=*((C_word*)lf[87]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* for-each-line in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1593(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1593r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1593r(t0,t1,t2,t3);}}

static void C_ccall f_1593r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):*((C_word*)lf[88]+1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1600,a[2]=t1,a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 395  ##sys#check-port */
t7=*((C_word*)lf[89]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t5,lf[87]);}

/* k1598 in for-each-line in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1600,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1605,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word)li61),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1605(t5,((C_word*)t0)[2]);}

/* loop in k1598 in for-each-line in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_fcall f_1605(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1605,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1609,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 397  read-line */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1607 in loop in k1598 in for-each-line in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1609,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1618,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 399  proc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}}

/* k1616 in k1607 in loop in k1598 in for-each-line in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 400  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1605(t2,((C_word*)t0)[2]);}

/* directory-null? in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1548(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1548,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1556,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=t3;
f_1556(2,t4,t2);}
else{
t4=(C_word)C_i_check_string_2(t2,lf[81]);
/* utils.scm: 384  string-split */
t5=*((C_word*)lf[84]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t2,lf[85],C_SCHEME_TRUE);}}

/* k1554 in directory-null? in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1558,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1558(t1));}

/* loop in k1554 in directory-null? in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static C_word C_fcall f_1558(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=(C_word)C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_i_car(t1);
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[82]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[83]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=(C_word)C_i_cdr(t1);
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* create-temporary-file in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1483(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1483r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1483r(t0,t1,t2);}}

static void C_ccall f_1483r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1487,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* utils.scm: 365  getenv */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[80]);}

/* k1485 in create-temporary-file in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1490,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_1490(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1540,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 365  getenv */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[79]);}}

/* k1538 in k1485 in create-temporary-file in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_1490(2,t2,t1);}
else{
/* utils.scm: 365  getenv */
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],lf[78]);}}

/* k1488 in k1485 in create-temporary-file in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1490,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[6]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[6],C_fix(0)):lf[76]);
t4=(C_word)C_i_check_string_2(t3,lf[75]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1501,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t6,a[8]=((C_word)li57),tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_1501(t8,((C_word*)t0)[2]);}

/* loop in k1488 in k1485 in create-temporary-file in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_fcall f_1501(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1501,NULL,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(16));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1508,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1531,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 370  number->string */
C_number_to_string(4,0,t5,t2,C_fix(16));}

/* k1529 in loop in k1488 in k1485 in create-temporary-file in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 370  ##sys#string-append */
t2=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[77],t1);}

/* k1525 in loop in k1488 in k1485 in create-temporary-file in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 370  make-pathname */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1506 in loop in k1488 in k1485 in create-temporary-file in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1514,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 371  file-exists? */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1512 in k1506 in loop in k1488 in k1485 in create-temporary-file in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1514,2,t0,t1);}
if(C_truep(t1)){
/* utils.scm: 372  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1501(t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1522,a[2]=((C_word*)t0)[3],a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 373  call-with-output-file */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],((C_word*)t0)[3],t2);}}

/* a1521 in k1512 in k1506 in loop in k1488 in k1485 in create-temporary-file in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1522(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1522,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* pathname-replace-extension in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1465(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1465,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1471,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li53),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1477,a[2]=t3,a[3]=((C_word)li54),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a1476 in pathname-replace-extension in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1477(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1477,5,t0,t1,t2,t3,t4);}
/* utils.scm: 357  make-pathname */
t5=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,((C_word*)t0)[2]);}

/* a1470 in pathname-replace-extension in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1471,2,t0,t1);}
/* utils.scm: 356  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-replace-file in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1447(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1447,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1453,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li50),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1459,a[2]=t3,a[3]=((C_word)li51),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a1458 in pathname-replace-file in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1459(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1459,5,t0,t1,t2,t3,t4);}
/* utils.scm: 352  make-pathname */
t5=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,((C_word*)t0)[2],t4);}

/* a1452 in pathname-replace-file in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1453,2,t0,t1);}
/* utils.scm: 351  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-replace-directory in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1429(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1429,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1435,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1441,a[2]=t3,a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a1440 in pathname-replace-directory in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1441(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1441,5,t0,t1,t2,t3,t4);}
/* utils.scm: 347  make-pathname */
t5=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t3,t4);}

/* a1434 in pathname-replace-directory in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1435,2,t0,t1);}
/* utils.scm: 346  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-strip-extension in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1411(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1411,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1417,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li44),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1423,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a1422 in pathname-strip-extension in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1423(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1423,5,t0,t1,t2,t3,t4);}
/* utils.scm: 342  make-pathname */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}

/* a1416 in pathname-strip-extension in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1417,2,t0,t1);}
/* utils.scm: 341  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-strip-directory in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1393(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1393,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1399,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li41),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1405,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a1404 in pathname-strip-directory in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1405(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1405,5,t0,t1,t2,t3,t4);}
/* utils.scm: 337  make-pathname */
t5=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,C_SCHEME_FALSE,t3,t4);}

/* a1398 in pathname-strip-directory in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1399,2,t0,t1);}
/* utils.scm: 336  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-extension in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1378(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1378,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1384,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li38),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1390,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a1389 in pathname-extension in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1390,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* a1383 in pathname-extension in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1384,2,t0,t1);}
/* utils.scm: 331  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-file in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1363(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1363,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1369,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li35),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1375,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a1374 in pathname-file in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1375(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1375,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* a1368 in pathname-file in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1369,2,t0,t1);}
/* utils.scm: 326  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-directory in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1348(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1348,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1354,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li32),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1360,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a1359 in pathname-directory in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1360,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* a1353 in pathname-directory in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1354,2,t0,t1);}
/* utils.scm: 321  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* decompose-pathname in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1240(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1240,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[64]);
t4=(C_word)C_block_size(t2);
t5=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t5)){
/* utils.scm: 300  values */
C_values(5,0,t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1256,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 301  string-match */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[2],t2);}}

/* k1254 in decompose-pathname in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1256,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1266,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(t1);
/* utils.scm: 303  strip-pds */
f_1226(t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1285,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 304  string-match */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* k1283 in k1254 in decompose-pathname in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1285,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1295,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(t1);
/* utils.scm: 306  strip-pds */
f_1226(t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1310,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 307  strip-pds */
f_1226(t2,((C_word*)t0)[2]);}}

/* k1308 in k1283 in k1254 in decompose-pathname in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 307  values */
C_values(5,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k1293 in k1283 in k1254 in decompose-pathname in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_caddr(((C_word*)t0)[3]);
/* utils.scm: 306  values */
C_values(5,0,((C_word*)t0)[2],t1,t2,C_SCHEME_FALSE);}

/* k1264 in k1254 in decompose-pathname in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_caddr(((C_word*)t0)[3]);
t3=(C_word)C_i_cddddr(((C_word*)t0)[3]);
t4=(C_word)C_i_car(t3);
/* utils.scm: 303  values */
C_values(5,0,((C_word*)t0)[2],t1,t2,t4);}

/* strip-pds in k1223 in k1220 in k836 in k833 in k441 in k438 in k435 */
static void C_fcall f_1226(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1226,NULL,2,t1,t2);}
if(C_truep(t2)){
t3=t2;
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[62]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[63]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
/* utils.scm: 296  chop-pds */
f_852(t1,t2,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* make-absolute-pathname in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1143(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_1143r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1143r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1143r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1145,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=((C_word)li26),tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1167,a[2]=t5,a[3]=((C_word)li27),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1172,a[2]=t6,a[3]=((C_word)li28),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-ext161172 */
t8=t7;
f_1172(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-pds162170 */
t10=t6;
f_1167(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body159164 */
t12=t5;
f_1145(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-ext161 in make-absolute-pathname in k836 in k833 in k441 in k438 in k435 */
static void C_fcall f_1172(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1172,NULL,2,t0,t1);}
/* def-pds162170 */
t2=((C_word*)t0)[2];
f_1167(t2,t1,C_SCHEME_FALSE);}

/* def-pds162 in make-absolute-pathname in k836 in k833 in k441 in k438 in k435 */
static void C_fcall f_1167(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1167,NULL,3,t0,t1,t2);}
/* body159164 */
t3=((C_word*)t0)[2];
f_1145(t3,t1,t2,C_SCHEME_FALSE);}

/* body159 in make-absolute-pathname in k836 in k833 in k441 in k438 in k435 */
static void C_fcall f_1145(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1145,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1153,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* utils.scm: 277  canonicalize-dirs */
t5=((C_word*)t0)[3];
f_967(t5,t4,((C_word*)t0)[2],t3);}

/* k1151 in body159 in make-absolute-pathname in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1153,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1156,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1159,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 278  absolute-pathname? */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}

/* k1157 in k1151 in body159 in make-absolute-pathname in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_1156(2,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
t3=(C_truep(t2)?t2:((C_word*)t0)[2]);
/* utils.scm: 280  ##sys#string-append */
t4=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4]);}}

/* k1154 in k1151 in body159 in make-absolute-pathname in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 275  _make-pathname */
t2=((C_word*)t0)[6];
f_998(t2,((C_word*)t0)[5],lf[52],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* make-pathname in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1079(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr4r,(void*)f_1079r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1079r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1079r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(15);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1081,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word)li22),tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1090,a[2]=t5,a[3]=((C_word)li23),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1095,a[2]=t6,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-ext140148 */
t8=t7;
f_1095(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-pds141146 */
t10=t6;
f_1090(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body138143 */
t12=t5;
f_1081(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-ext140 in make-pathname in k836 in k833 in k441 in k438 in k435 */
static void C_fcall f_1095(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1095,NULL,2,t0,t1);}
/* def-pds141146 */
t2=((C_word*)t0)[2];
f_1090(t2,t1,C_SCHEME_FALSE);}

/* def-pds141 in make-pathname in k836 in k833 in k441 in k438 in k435 */
static void C_fcall f_1090(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1090,NULL,3,t0,t1,t2);}
/* body138143 */
t3=((C_word*)t0)[2];
f_1081(t3,t1,t2,C_SCHEME_FALSE);}

/* body138 in make-pathname in k836 in k833 in k441 in k438 in k435 */
static void C_fcall f_1081(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1081,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1089,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 271  canonicalize-dirs */
t5=((C_word*)t0)[3];
f_967(t5,t4,((C_word*)t0)[2],t3);}

/* k1087 in body138 in make-pathname in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 271  _make-pathname */
t2=((C_word*)t0)[6];
f_998(t2,((C_word*)t0)[5],lf[51],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* _make-pathname in k836 in k833 in k441 in k438 in k435 */
static void C_fcall f_998(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_998,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_truep(t5)?t5:lf[56]);
t8=(C_truep(t4)?t4:lf[57]);
t9=(C_truep(t6)?(C_word)C_block_size(t6):C_fix(1));
t10=(C_word)C_i_check_string_2(t3,t2);
t11=(C_word)C_i_check_string_2(t8,t2);
t12=(C_word)C_i_check_string_2(t7,t2);
t13=(C_truep(t6)?(C_word)C_i_check_string_2(t6,t2):C_SCHEME_UNDEFINED);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1027,a[2]=t7,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t15=(C_word)C_block_size(t8);
t16=(C_word)C_fixnum_greater_or_equal_p(t15,t9);
t17=(C_truep(t16)?(C_truep(t6)?(C_word)C_substring_compare(t6,t8,C_fix(0),C_fix(0),t9):(C_word)C_i_memq((C_word)C_subchar(t8,C_fix(0)),lf[60])):C_SCHEME_FALSE);
if(C_truep(t17)){
t18=(C_word)C_block_size(t8);
/* utils.scm: 261  ##sys#substring */
t19=*((C_word*)lf[49]+1);
((C_proc5)(void*)(*((C_word*)t19+1)))(5,t19,t14,t8,t9,t18);}
else{
t18=t14;
f_1027(2,t18,t8);}}

/* k1025 in _make-pathname in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_1027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1034,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t4=(C_word)C_eqp((C_word)C_subchar(((C_word*)t0)[2],C_fix(0)),C_make_character(46));
t5=t2;
f_1034(t5,(C_word)C_i_not(t4));}
else{
t4=t2;
f_1034(t4,C_SCHEME_FALSE);}}

/* k1032 in k1025 in _make-pathname in k836 in k833 in k441 in k438 in k435 */
static void C_fcall f_1034(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[58]:lf[59]);
/* utils.scm: 255  string-append */
t3=((C_word*)t0)[6];
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* canonicalize-dirs in k836 in k833 in k441 in k438 in k435 */
static void C_fcall f_967(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_967,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_not(t2);
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t2));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[55]);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t6=(C_word)C_a_i_list(&a,1,t2);
/* utils.scm: 244  conc-dirs */
t7=((C_word*)t0)[2];
f_906(t7,t1,t6,t3);}
else{
/* utils.scm: 245  conc-dirs */
t6=((C_word*)t0)[2];
f_906(t6,t1,t2,t3);}}}

/* conc-dirs in k836 in k833 in k441 in k438 in k435 */
static void C_fcall f_906(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_906,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_list_2(t2,lf[51]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_915,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t6,a[6]=((C_word)li18),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_915(t8,t1,t2);}

/* loop in conc-dirs in k836 in k833 in k441 in k438 in k435 */
static void C_fcall f_915(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_915,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[54]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_string_length(t3);
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
/* utils.scm: 236  loop */
t10=t1;
t11=t6;
t1=t10;
t2=t11;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_945,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_i_car(t2);
/* utils.scm: 238  chop-pds */
f_852(t6,t7,((C_word*)t0)[4]);}}}

/* k943 in loop in conc-dirs in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_945,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=(C_truep(t2)?t2:((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_953,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* utils.scm: 240  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_915(t6,t4,t5);}

/* k951 in k943 in loop in conc-dirs in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 237  string-append */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* chop-pds in k836 in k833 in k441 in k438 in k435 */
static void C_fcall f_852(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_852,NULL,3,t1,t2,t3);}
if(C_truep(t2)){
t4=(C_word)C_block_size(t2);
t5=(C_truep(t3)?(C_word)C_block_size(t3):C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_868,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,C_fix(1)))){
if(C_truep(t3)){
t7=(C_word)C_fixnum_difference(t4,t5);
t8=t6;
f_868(t8,(C_word)C_substring_compare(t2,t3,t7,C_fix(0),t5));}
else{
t7=(C_word)C_fixnum_difference(t4,t5);
t8=(C_word)C_subchar(t2,t7);
t9=t6;
f_868(t9,(C_word)C_i_memq(t8,lf[50]));}}
else{
t7=t6;
f_868(t7,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k866 in chop-pds in k836 in k833 in k441 in k438 in k435 */
static void C_fcall f_868(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* utils.scm: 220  ##sys#substring */
t3=*((C_word*)lf[49]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* absolute-pathname? in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_839(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_839,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[47]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_850,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 209  string-match */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k848 in absolute-pathname? in k836 in k833 in k441 in k438 in k435 */
static void C_ccall f_850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_pairp(t1));}

/* delete-file* in k441 in k438 in k435 */
static void C_ccall f_815(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_815,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_822,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 195  file-exists? */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k820 in delete-file* in k441 in k438 in k435 */
static void C_ccall f_822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_822,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_828,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 195  delete-file */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k826 in k820 in delete-file* in k441 in k438 in k435 */
static void C_ccall f_828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* system* in k441 in k438 in k435 */
static void C_ccall f_797(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_797r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_797r(t0,t1,t2,t3);}}

static void C_ccall f_797r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_801,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,((C_word*)t0)[2],t2,t3);}

/* k799 in system* in k441 in k438 in k435 */
static void C_ccall f_801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_804,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 184  system */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k802 in k799 in system* in k441 in k438 in k435 */
static void C_ccall f_804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* utils.scm: 186  ##sys#error */
t3=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[38],((C_word*)t0)[2],t1);}}

/* apropos in k441 in k438 in k435 */
static void C_ccall f_705(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_705r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_705r(t0,t1,t2,t3);}}

static void C_ccall f_705r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_709,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 152  %apropos-list */
f_577(t4,lf[17],t2,t3);}

/* k707 in apropos in k441 in k438 in k435 */
static void C_ccall f_709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_709,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_712,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_786,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li12),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t6=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t1);}

/* a785 in k707 in apropos in k441 in k438 in k435 */
static void C_ccall f_786(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_786,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_795,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 156  symlen */
f_680(t3,t2);}

/* k793 in a785 in k707 in apropos in k441 in k438 in k435 */
static void C_ccall f_795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k710 in k707 in apropos in k441 in k438 in k435 */
static void C_ccall f_712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_717,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word)li11),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t3=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a716 in k710 in k707 in apropos in k441 in k438 in k435 */
static void C_ccall f_717(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_717,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_721,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 160  display */
t4=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k719 in a716 in k710 in k707 in apropos in k441 in k438 in k435 */
static void C_ccall f_721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_724,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_784,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 161  symlen */
f_680(t3,((C_word*)t0)[4]);}

/* k782 in k719 in a716 in k710 in k707 in apropos in k441 in k438 in k435 */
static void C_ccall f_784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_784,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[3])[1],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_763,a[2]=t4,a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_763(t6,((C_word*)t0)[2],t2);}

/* do62 in k782 in k719 in a716 in k710 in k707 in apropos in k441 in k438 in k435 */
static void C_fcall f_763(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_763,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_773,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 163  display */
t4=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_make_character(32));}}

/* k771 in do62 in k782 in k719 in a716 in k710 in k707 in apropos in k441 in k438 in k435 */
static void C_ccall f_773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_763(t3,((C_word*)t0)[2],t2);}

/* k722 in k719 in a716 in k710 in k707 in apropos in k441 in k438 in k435 */
static void C_ccall f_724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 164  display */
t3=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(32));}

/* k725 in k722 in k719 in a716 in k710 in k707 in apropos in k441 in k438 in k435 */
static void C_ccall f_727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_730,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 164  display */
t3=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(58));}

/* k728 in k725 in k722 in k719 in a716 in k710 in k707 in apropos in k441 in k438 in k435 */
static void C_ccall f_730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_733,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 164  display */
t3=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(32));}

/* k731 in k728 in k725 in k722 in k719 in a716 in k710 in k707 in apropos in k441 in k438 in k435 */
static void C_ccall f_733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_736,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_742,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 165  macro? */
t4=*((C_word*)lf[33]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k740 in k731 in k728 in k725 in k722 in k719 in a716 in k710 in k707 in apropos in k441 in k438 in k435 */
static void C_ccall f_742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_742,2,t0,t1);}
if(C_truep(t1)){
/* utils.scm: 167  display */
t2=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],lf[29]);}
else{
t2=(C_word)C_retrieve(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_653,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 135  procedure-information */
t4=*((C_word*)lf[31]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
/* utils.scm: 172  display */
t3=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],lf[32]);}}}

/* k651 in k740 in k731 in k728 in k725 in k722 in k719 in a716 in k710 in k707 in apropos in k441 in k438 in k435 */
static void C_ccall f_653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_653,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_cdr(t1);
t3=(C_word)C_a_i_cons(&a,2,lf[30],t2);
/* utils.scm: 136  display */
t4=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}
else{
if(C_truep(t1)){
/* utils.scm: 137  display */
t2=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[30]);}
else{
/* utils.scm: 138  display */
t2=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[30]);}}}

/* k734 in k731 in k728 in k725 in k722 in k719 in a716 in k710 in k707 in apropos in k441 in k438 in k435 */
static void C_ccall f_736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 173  newline */
t2=*((C_word*)lf[27]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* apropos-list in k441 in k438 in k435 */
static void C_ccall f_699(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_699r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_699r(t0,t1,t2,t3);}}

static void C_ccall f_699r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* utils.scm: 148  %apropos-list */
f_577(t1,lf[16],t2,t3);}

/* symlen in k441 in k438 in k435 */
static void C_fcall f_680(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_680,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_697,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 141  ##sys#symbol->qualified-string */
t4=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k695 in symlen in k441 in k438 in k435 */
static void C_ccall f_697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_697,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_690,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 142  keyword? */
t4=*((C_word*)lf[25]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k688 in k695 in symlen in k441 in k438 in k435 */
static void C_ccall f_690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_fixnum_difference(((C_word*)t0)[2],C_fix(2)):((C_word*)t0)[2]));}

/* %apropos-list in k441 in k438 in k435 */
static void C_fcall f_577(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_577,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_581,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 116  interaction-environment */
t6=*((C_word*)lf[24]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k579 in %apropos-list in k441 in k438 in k435 */
static void C_ccall f_581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_581,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_613,a[2]=t3,a[3]=t5,a[4]=((C_word)li6),tmp=(C_word)a,a+=5,tmp);
t7=f_613(t6,((C_word*)t0)[5]);
t8=(C_word)C_i_check_structure_2(((C_word*)t3)[1],lf[19],((C_word*)t0)[4]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_590,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t10=(C_word)C_i_stringp(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_599,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t10)){
t12=t11;
f_599(2,t12,t10);}
else{
t12=(C_word)C_i_symbolp(((C_word*)t0)[2]);
if(C_truep(t12)){
t13=t11;
f_599(2,t13,t12);}
else{
/* utils.scm: 130  regexp? */
t13=*((C_word*)lf[23]+1);
((C_proc3)C_retrieve_proc(t13))(3,t13,t11,((C_word*)t0)[2]);}}}

/* k597 in k579 in %apropos-list in k441 in k438 in k435 */
static void C_ccall f_599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_590(2,t2,C_SCHEME_UNDEFINED);}
else{
/* utils.scm: 131  ##sys#signal-hook */
t2=*((C_word*)lf[20]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[21],((C_word*)t0)[3],lf[22],((C_word*)t0)[2]);}}

/* k588 in k579 in %apropos-list in k441 in k438 in k435 */
static void C_ccall f_590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 132  ##sys#apropos */
t2=*((C_word*)lf[13]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* loop in k579 in %apropos-list in k441 in k438 in k435 */
static C_word C_fcall f_613(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
C_stack_check;
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_eqp(lf[18],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cadr(t1);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=(C_word)C_i_cddr(t1);
t10=t6;
t1=t10;
goto loop;}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=(C_word)C_i_cdr(t1);
t10=t5;
t1=t10;
goto loop;}}
else{
return(C_SCHEME_UNDEFINED);}}

/* ##sys#apropos in k441 in k438 in k435 */
static void C_ccall f_532(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_532r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_532r(t0,t1,t2,t3,t4);}}

static void C_ccall f_532r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_536,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_536(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_536(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k534 in ##sys#apropos in k441 in k438 in k435 */
static void C_ccall f_536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_539,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 107  ##sys#apropos-interned */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k537 in k534 in ##sys#apropos in k441 in k438 in k435 */
static void C_ccall f_539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_539,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_549,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 109  ##sys#apropos-macros */
t3=*((C_word*)lf[4]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* k547 in k537 in k534 in ##sys#apropos in k441 in k438 in k435 */
static void C_ccall f_549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 109  ##sys#append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#apropos-macros in k441 in k438 in k435 */
static void C_ccall f_505(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_505,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_510,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 97   makpat */
t6=((C_word*)t0)[2];
f_452(t6,t5,((C_word*)t4)[1]);}

/* k508 in ##sys#apropos-macros in k441 in k438 in k435 */
static void C_ccall f_510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_510,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_513,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_515,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word)li3),tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 99   ##sys#hash-table-for-each */
t7=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,*((C_word*)lf[12]+1));}

/* a514 in k508 in ##sys#apropos-macros in k441 in k438 in k435 */
static void C_ccall f_515(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_515,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_522,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_530,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 101  symbol->string */
t6=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k528 in a514 in k508 in ##sys#apropos-macros in k441 in k438 in k435 */
static void C_ccall f_530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 101  string-search */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k520 in a514 in k508 in ##sys#apropos-macros in k441 in k438 in k435 */
static void C_ccall f_522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_522,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k511 in k508 in ##sys#apropos-macros in k441 in k438 in k435 */
static void C_ccall f_513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##sys#apropos-interned in k441 in k438 in k435 */
static void C_ccall f_479(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_479,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_484,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 89   makpat */
t6=((C_word*)t0)[2];
f_452(t6,t5,((C_word*)t4)[1]);}

/* k482 in ##sys#apropos-interned in k441 in k438 in k435 */
static void C_ccall f_484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_484,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_489,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word)li1),tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 90   ##sys#environment-symbols */
t4=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a488 in k482 in ##sys#apropos-interned in k441 in k438 in k435 */
static void C_ccall f_489(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_489,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_496,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_503,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 92   symbol->string */
t5=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k501 in a488 in k482 in ##sys#apropos-interned in k441 in k438 in k435 */
static void C_ccall f_503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 92   string-search */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k494 in a488 in k482 in ##sys#apropos-interned in k441 in k438 in k435 */
static void C_ccall f_496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* utils.scm: 93   ##sys#symbol-has-toplevel-binding? */
t2=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* makpat in k441 in k438 in k435 */
static void C_fcall f_452(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_452,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_456,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t3)[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_477,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 82   symbol->string */
t6=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t3)[1]);}
else{
t5=t4;
f_456(t5,C_SCHEME_UNDEFINED);}}

/* k475 in makpat in k441 in k438 in k435 */
static void C_ccall f_477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_456(t3,t2);}

/* k454 in makpat in k441 in k438 in k435 */
static void C_fcall f_456(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_456,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_459,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[4])[1]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_466,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_470,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 84   regexp-escape */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t2;
f_459(t3,C_SCHEME_UNDEFINED);}}

/* k468 in k454 in makpat in k441 in k438 in k435 */
static void C_ccall f_470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 84   regexp */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k464 in k454 in makpat in k441 in k438 in k435 */
static void C_ccall f_466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_459(t3,t2);}

/* k457 in k454 in makpat in k441 in k438 in k435 */
static void C_fcall f_459(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[175] = {
{"toplevelutils.scm",(void*)C_utils_toplevel},
{"f_437utils.scm",(void*)f_437},
{"f_440utils.scm",(void*)f_440},
{"f_443utils.scm",(void*)f_443},
{"f_2057utils.scm",(void*)f_2057},
{"f_835utils.scm",(void*)f_835},
{"f_838utils.scm",(void*)f_838},
{"f_1222utils.scm",(void*)f_1222},
{"f_1225utils.scm",(void*)f_1225},
{"f_1903utils.scm",(void*)f_1903},
{"f_2002utils.scm",(void*)f_2002},
{"f_2008utils.scm",(void*)f_2008},
{"f_2024utils.scm",(void*)f_2024},
{"f_2027utils.scm",(void*)f_2027},
{"f_1967utils.scm",(void*)f_1967},
{"f_1973utils.scm",(void*)f_1973},
{"f_1983utils.scm",(void*)f_1983},
{"f_1947utils.scm",(void*)f_1947},
{"f_1912utils.scm",(void*)f_1912},
{"f_1918utils.scm",(void*)f_1918},
{"f_1928utils.scm",(void*)f_1928},
{"f_1879utils.scm",(void*)f_1879},
{"f_1897utils.scm",(void*)f_1897},
{"f_1885utils.scm",(void*)f_1885},
{"f_1891utils.scm",(void*)f_1891},
{"f_1854utils.scm",(void*)f_1854},
{"f_1860utils.scm",(void*)f_1860},
{"f_1864utils.scm",(void*)f_1864},
{"f_1877utils.scm",(void*)f_1877},
{"f_1822utils.scm",(void*)f_1822},
{"f_1828utils.scm",(void*)f_1828},
{"f_1832utils.scm",(void*)f_1832},
{"f_1852utils.scm",(void*)f_1852},
{"f_1798utils.scm",(void*)f_1798},
{"f_1804utils.scm",(void*)f_1804},
{"f_1808utils.scm",(void*)f_1808},
{"f_1817utils.scm",(void*)f_1817},
{"f_1774utils.scm",(void*)f_1774},
{"f_1717utils.scm",(void*)f_1717},
{"f_1721utils.scm",(void*)f_1721},
{"f_1674utils.scm",(void*)f_1674},
{"f_1678utils.scm",(void*)f_1678},
{"f_1684utils.scm",(void*)f_1684},
{"f_1692utils.scm",(void*)f_1692},
{"f_1629utils.scm",(void*)f_1629},
{"f_1654utils.scm",(void*)f_1654},
{"f_1668utils.scm",(void*)f_1668},
{"f_1647utils.scm",(void*)f_1647},
{"f_1593utils.scm",(void*)f_1593},
{"f_1600utils.scm",(void*)f_1600},
{"f_1605utils.scm",(void*)f_1605},
{"f_1609utils.scm",(void*)f_1609},
{"f_1618utils.scm",(void*)f_1618},
{"f_1548utils.scm",(void*)f_1548},
{"f_1556utils.scm",(void*)f_1556},
{"f_1558utils.scm",(void*)f_1558},
{"f_1483utils.scm",(void*)f_1483},
{"f_1487utils.scm",(void*)f_1487},
{"f_1540utils.scm",(void*)f_1540},
{"f_1490utils.scm",(void*)f_1490},
{"f_1501utils.scm",(void*)f_1501},
{"f_1531utils.scm",(void*)f_1531},
{"f_1527utils.scm",(void*)f_1527},
{"f_1508utils.scm",(void*)f_1508},
{"f_1514utils.scm",(void*)f_1514},
{"f_1522utils.scm",(void*)f_1522},
{"f_1465utils.scm",(void*)f_1465},
{"f_1477utils.scm",(void*)f_1477},
{"f_1471utils.scm",(void*)f_1471},
{"f_1447utils.scm",(void*)f_1447},
{"f_1459utils.scm",(void*)f_1459},
{"f_1453utils.scm",(void*)f_1453},
{"f_1429utils.scm",(void*)f_1429},
{"f_1441utils.scm",(void*)f_1441},
{"f_1435utils.scm",(void*)f_1435},
{"f_1411utils.scm",(void*)f_1411},
{"f_1423utils.scm",(void*)f_1423},
{"f_1417utils.scm",(void*)f_1417},
{"f_1393utils.scm",(void*)f_1393},
{"f_1405utils.scm",(void*)f_1405},
{"f_1399utils.scm",(void*)f_1399},
{"f_1378utils.scm",(void*)f_1378},
{"f_1390utils.scm",(void*)f_1390},
{"f_1384utils.scm",(void*)f_1384},
{"f_1363utils.scm",(void*)f_1363},
{"f_1375utils.scm",(void*)f_1375},
{"f_1369utils.scm",(void*)f_1369},
{"f_1348utils.scm",(void*)f_1348},
{"f_1360utils.scm",(void*)f_1360},
{"f_1354utils.scm",(void*)f_1354},
{"f_1240utils.scm",(void*)f_1240},
{"f_1256utils.scm",(void*)f_1256},
{"f_1285utils.scm",(void*)f_1285},
{"f_1310utils.scm",(void*)f_1310},
{"f_1295utils.scm",(void*)f_1295},
{"f_1266utils.scm",(void*)f_1266},
{"f_1226utils.scm",(void*)f_1226},
{"f_1143utils.scm",(void*)f_1143},
{"f_1172utils.scm",(void*)f_1172},
{"f_1167utils.scm",(void*)f_1167},
{"f_1145utils.scm",(void*)f_1145},
{"f_1153utils.scm",(void*)f_1153},
{"f_1159utils.scm",(void*)f_1159},
{"f_1156utils.scm",(void*)f_1156},
{"f_1079utils.scm",(void*)f_1079},
{"f_1095utils.scm",(void*)f_1095},
{"f_1090utils.scm",(void*)f_1090},
{"f_1081utils.scm",(void*)f_1081},
{"f_1089utils.scm",(void*)f_1089},
{"f_998utils.scm",(void*)f_998},
{"f_1027utils.scm",(void*)f_1027},
{"f_1034utils.scm",(void*)f_1034},
{"f_967utils.scm",(void*)f_967},
{"f_906utils.scm",(void*)f_906},
{"f_915utils.scm",(void*)f_915},
{"f_945utils.scm",(void*)f_945},
{"f_953utils.scm",(void*)f_953},
{"f_852utils.scm",(void*)f_852},
{"f_868utils.scm",(void*)f_868},
{"f_839utils.scm",(void*)f_839},
{"f_850utils.scm",(void*)f_850},
{"f_815utils.scm",(void*)f_815},
{"f_822utils.scm",(void*)f_822},
{"f_828utils.scm",(void*)f_828},
{"f_797utils.scm",(void*)f_797},
{"f_801utils.scm",(void*)f_801},
{"f_804utils.scm",(void*)f_804},
{"f_705utils.scm",(void*)f_705},
{"f_709utils.scm",(void*)f_709},
{"f_786utils.scm",(void*)f_786},
{"f_795utils.scm",(void*)f_795},
{"f_712utils.scm",(void*)f_712},
{"f_717utils.scm",(void*)f_717},
{"f_721utils.scm",(void*)f_721},
{"f_784utils.scm",(void*)f_784},
{"f_763utils.scm",(void*)f_763},
{"f_773utils.scm",(void*)f_773},
{"f_724utils.scm",(void*)f_724},
{"f_727utils.scm",(void*)f_727},
{"f_730utils.scm",(void*)f_730},
{"f_733utils.scm",(void*)f_733},
{"f_742utils.scm",(void*)f_742},
{"f_653utils.scm",(void*)f_653},
{"f_736utils.scm",(void*)f_736},
{"f_699utils.scm",(void*)f_699},
{"f_680utils.scm",(void*)f_680},
{"f_697utils.scm",(void*)f_697},
{"f_690utils.scm",(void*)f_690},
{"f_577utils.scm",(void*)f_577},
{"f_581utils.scm",(void*)f_581},
{"f_599utils.scm",(void*)f_599},
{"f_590utils.scm",(void*)f_590},
{"f_613utils.scm",(void*)f_613},
{"f_532utils.scm",(void*)f_532},
{"f_536utils.scm",(void*)f_536},
{"f_539utils.scm",(void*)f_539},
{"f_549utils.scm",(void*)f_549},
{"f_505utils.scm",(void*)f_505},
{"f_510utils.scm",(void*)f_510},
{"f_515utils.scm",(void*)f_515},
{"f_530utils.scm",(void*)f_530},
{"f_522utils.scm",(void*)f_522},
{"f_513utils.scm",(void*)f_513},
{"f_479utils.scm",(void*)f_479},
{"f_484utils.scm",(void*)f_484},
{"f_489utils.scm",(void*)f_489},
{"f_503utils.scm",(void*)f_503},
{"f_496utils.scm",(void*)f_496},
{"f_452utils.scm",(void*)f_452},
{"f_477utils.scm",(void*)f_477},
{"f_456utils.scm",(void*)f_456},
{"f_470utils.scm",(void*)f_470},
{"f_466utils.scm",(void*)f_466},
{"f_459utils.scm",(void*)f_459},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
