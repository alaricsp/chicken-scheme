/* Generated from utils.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-05-13 09:14
   Version 3.2.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook hostpcre ]
   SVN rev. 10674	compiled 2008-04-30 on debian (Linux)
   command line: utils.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file utils.c
   unit: utils
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[128];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,14),40,109,97,107,112,97,116,32,112,97,116,116,52,41,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,11),40,97,53,55,57,32,115,121,109,57,41,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,97,112,114,111,112,111,115,45,105,110,116,101,114,110,101,100,32,112,97,116,116,55,32,101,110,118,56,41,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,18),40,97,54,48,53,32,107,101,121,49,52,32,118,97,108,49,53,41,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,97,112,114,111,112,111,115,45,109,97,99,114,111,115,32,112,97,116,116,49,49,32,101,110,118,49,50,41,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,36),40,35,35,115,121,115,35,97,112,114,111,112,111,115,32,112,97,116,116,50,48,32,101,110,118,50,49,32,46,32,103,49,57,50,50,41,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,35),40,37,97,112,114,111,112,111,115,45,108,105,115,116,32,108,111,99,51,49,32,112,97,116,116,51,50,32,97,114,103,115,51,51,41,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,14),40,115,121,109,108,101,110,32,115,121,109,53,50,41,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,30),40,97,112,114,111,112,111,115,45,108,105,115,116,32,112,97,116,116,53,52,32,46,32,114,101,115,116,53,53,41,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,10),40,100,111,54,50,32,105,54,52,41,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,12),40,97,56,48,55,32,115,121,109,54,49,41,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,12),40,97,56,55,54,32,115,121,109,54,48,41,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,25),40,97,112,114,111,112,111,115,32,112,97,116,116,53,54,32,46,32,114,101,115,116,53,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,25),40,115,121,115,116,101,109,42,32,102,115,116,114,55,56,32,46,32,97,114,103,115,55,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,21),40,100,101,108,101,116,101,45,102,105,108,101,42,32,102,105,108,101,56,52,41,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,7),40,97,49,48,48,57,41,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,15),40,97,49,48,48,51,32,103,49,51,49,49,51,54,41,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,7),40,97,49,48,52,52,41,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,7),40,97,49,48,53,54,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,17),40,97,49,48,53,48,32,46,32,103,49,51,52,49,52,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,7),40,97,49,48,51,56,41,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,14),40,97,57,57,55,32,103,49,51,51,49,51,53,41,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,100,49,50,55,32,108,49,50,56,41};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,7),40,97,49,48,55,55,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,15),40,97,49,48,55,49,32,103,49,49,54,49,50,49,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,7),40,97,49,49,48,50,41,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,7),40,97,49,49,49,52,41,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,17),40,97,49,49,48,56,32,46,32,103,49,49,57,49,50,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,7),40,97,49,48,57,54,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,15),40,97,49,48,54,53,32,103,49,49,56,49,50,48,41,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,7),40,97,49,49,51,53,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,15),40,97,49,49,50,57,32,103,49,48,54,49,49,49,41,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,7),40,97,49,49,54,48,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,7),40,97,49,49,55,50,41,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,17),40,97,49,49,54,54,32,46,32,103,49,48,57,49,49,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,7),40,97,49,49,53,52,41,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,15),40,97,49,49,50,51,32,103,49,48,56,49,49,48,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,30),40,98,111,100,121,57,49,32,99,108,111,98,98,101,114,57,55,32,98,108,111,99,107,115,105,122,101,57,56,41,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,31),40,100,101,102,45,98,108,111,99,107,115,105,122,101,57,52,32,37,99,108,111,98,98,101,114,56,57,49,53,49,41,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,15),40,100,101,102,45,99,108,111,98,98,101,114,57,51,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,40),40,102,105,108,101,45,99,111,112,121,32,111,114,105,103,102,105,108,101,56,54,32,110,101,119,102,105,108,101,56,55,32,46,32,103,56,53,56,56,41};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,7),40,97,49,51,52,53,41,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,15),40,97,49,51,51,57,32,103,50,48,49,50,48,54,41,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,7),40,97,49,51,55,48,41,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,7),40,97,49,51,56,50,41,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,17),40,97,49,51,55,54,32,46,32,103,50,48,52,50,48,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,7),40,97,49,51,54,52,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,15),40,97,49,51,51,51,32,103,50,48,51,50,48,53,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,7),40,97,49,52,49,55,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,15),40,97,49,52,49,49,32,103,50,49,51,50,49,56,41,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,7),40,97,49,52,53,50,41,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,7),40,97,49,52,54,52,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,17),40,97,49,52,53,56,32,46,32,103,50,49,54,50,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,7),40,97,49,52,52,54,41,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,15),40,97,49,52,48,53,32,103,50,49,53,50,49,55,41,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,100,49,57,57,32,108,50,48,48,41};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,7),40,97,49,52,56,53,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,15),40,97,49,52,55,57,32,103,49,56,56,49,57,51,41,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,7),40,97,49,53,49,48,41,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,7),40,97,49,53,50,50,41,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,17),40,97,49,53,49,54,32,46,32,103,49,57,49,49,57,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,7),40,97,49,53,48,52,41,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,15),40,97,49,52,55,51,32,103,49,57,48,49,57,50,41,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,7),40,97,49,53,52,51,41,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,15),40,97,49,53,51,55,32,103,49,55,56,49,56,51,41,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,7),40,97,49,53,54,56,41,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,7),40,97,49,53,56,48,41,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,17),40,97,49,53,55,52,32,46,32,103,49,56,49,49,56,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,7),40,97,49,53,54,50,41,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,15),40,97,49,53,51,49,32,103,49,56,48,49,56,50,41,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,33),40,98,111,100,121,49,54,51,32,99,108,111,98,98,101,114,49,54,57,32,98,108,111,99,107,115,105,122,101,49,55,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,33),40,100,101,102,45,98,108,111,99,107,115,105,122,101,49,54,54,32,37,99,108,111,98,98,101,114,49,54,49,50,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,99,108,111,98,98,101,114,49,54,53,41};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,44),40,102,105,108,101,45,109,111,118,101,32,111,114,105,103,102,105,108,101,49,53,56,32,110,101,119,102,105,108,101,49,53,57,32,46,32,103,49,53,55,49,54,48,41,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,26),40,97,98,115,111,108,117,116,101,45,112,97,116,104,110,97,109,101,63,32,112,110,50,52,53,41,0,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,24),40,99,104,111,112,45,112,100,115,32,115,116,114,50,52,55,32,112,100,115,50,52,56,41};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,115,116,114,115,50,54,48,41,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,26),40,99,111,110,99,45,100,105,114,115,32,100,105,114,115,50,53,55,32,112,100,115,50,53,56,41,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,34),40,99,97,110,111,110,105,99,97,108,105,122,101,45,100,105,114,115,32,100,105,114,115,50,54,54,32,112,100,115,50,54,55,41,0,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,52),40,95,109,97,107,101,45,112,97,116,104,110,97,109,101,32,108,111,99,50,55,48,32,100,105,114,50,55,49,32,102,105,108,101,50,55,50,32,101,120,116,50,55,51,32,112,100,115,50,55,52,41,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,23),40,98,111,100,121,50,57,50,32,101,120,116,50,57,56,32,112,100,115,50,57,57,41,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,23),40,100,101,102,45,112,100,115,50,57,53,32,37,101,120,116,50,57,48,51,48,49,41,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,101,120,116,50,57,52,41,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,41),40,109,97,107,101,45,112,97,116,104,110,97,109,101,32,100,105,114,115,50,56,55,32,102,105,108,101,50,56,56,32,46,32,103,50,56,54,50,56,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,23),40,98,111,100,121,51,49,51,32,101,120,116,51,49,57,32,112,100,115,51,50,48,41,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,23),40,100,101,102,45,112,100,115,51,49,54,32,37,101,120,116,51,49,49,51,50,53,41,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,101,120,116,51,49,53,41,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,50),40,109,97,107,101,45,97,98,115,111,108,117,116,101,45,112,97,116,104,110,97,109,101,32,100,105,114,115,51,48,56,32,102,105,108,101,51,48,57,32,46,32,103,51,48,55,51,49,48,41,0,0,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,18),40,115,116,114,105,112,45,112,100,115,32,100,105,114,51,52,51,41,0,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,26),40,100,101,99,111,109,112,111,115,101,45,112,97,116,104,110,97,109,101,32,112,110,51,52,52,41,0,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,7),40,97,50,49,57,57,41,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,38),40,97,50,50,48,53,32,100,105,114,51,53,48,51,53,51,32,102,105,108,101,51,53,49,51,53,52,32,101,120,116,51,53,50,51,53,53,41,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,26),40,112,97,116,104,110,97,109,101,45,100,105,114,101,99,116,111,114,121,32,112,110,51,52,57,41,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,7),40,97,50,50,49,52,41,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,38),40,97,50,50,50,48,32,100,105,114,51,54,48,51,54,51,32,102,105,108,101,51,54,49,51,54,52,32,101,120,116,51,54,50,51,54,53,41,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,21),40,112,97,116,104,110,97,109,101,45,102,105,108,101,32,112,110,51,53,57,41,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,7),40,97,50,50,50,57,41,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,38),40,97,50,50,51,53,32,100,105,114,51,55,48,51,55,51,32,102,105,108,101,51,55,49,51,55,52,32,101,120,116,51,55,50,51,55,53,41,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,26),40,112,97,116,104,110,97,109,101,45,101,120,116,101,110,115,105,111,110,32,112,110,51,54,57,41,0,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,7),40,97,50,50,52,52,41,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,38),40,97,50,50,53,48,32,100,105,114,51,56,48,51,56,51,32,102,105,108,101,51,56,49,51,56,52,32,101,120,116,51,56,50,51,56,53,41,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,32),40,112,97,116,104,110,97,109,101,45,115,116,114,105,112,45,100,105,114,101,99,116,111,114,121,32,112,110,51,55,57,41};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,7),40,97,50,50,54,50,41,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,38),40,97,50,50,54,56,32,100,105,114,51,57,48,51,57,51,32,102,105,108,101,51,57,49,51,57,52,32,101,120,116,51,57,50,51,57,53,41,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,32),40,112,97,116,104,110,97,109,101,45,115,116,114,105,112,45,101,120,116,101,110,115,105,111,110,32,112,110,51,56,57,41};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,7),40,97,50,50,56,48,41,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,36),40,97,50,50,56,54,32,95,52,48,49,52,48,52,32,102,105,108,101,52,48,50,52,48,53,32,101,120,116,52,48,51,52,48,54,41,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,41),40,112,97,116,104,110,97,109,101,45,114,101,112,108,97,99,101,45,100,105,114,101,99,116,111,114,121,32,112,110,51,57,57,32,100,105,114,52,48,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,7),40,97,50,50,57,56,41,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,35),40,97,50,51,48,52,32,100,105,114,52,49,50,52,49,53,32,95,52,49,51,52,49,54,32,101,120,116,52,49,52,52,49,55,41,0,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,37),40,112,97,116,104,110,97,109,101,45,114,101,112,108,97,99,101,45,102,105,108,101,32,112,110,52,49,48,32,102,105,108,101,52,49,49,41,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,7),40,97,50,51,49,54,41,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,36),40,97,50,51,50,50,32,100,105,114,52,50,51,52,50,54,32,102,105,108,101,52,50,52,52,50,55,32,95,52,50,53,52,50,56,41,0,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,41),40,112,97,116,104,110,97,109,101,45,114,101,112,108,97,99,101,45,101,120,116,101,110,115,105,111,110,32,112,110,52,50,49,32,101,120,116,52,50,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,12),40,97,50,51,54,55,32,112,52,53,51,41,0,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,32),40,99,114,101,97,116,101,45,116,101,109,112,111,114,97,114,121,45,102,105,108,101,32,46,32,101,120,116,52,52,51,41};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,24),40,100,105,114,101,99,116,111,114,121,45,110,117,108,108,63,32,100,105,114,52,53,54,41};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,33),40,102,111,114,45,101,97,99,104,45,108,105,110,101,32,112,114,111,99,52,54,52,32,46,32,112,111,114,116,52,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,7),40,97,50,52,57,50,41,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,14),40,97,50,53,49,51,32,97,114,103,52,55,55,41,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,29),40,102,111,114,45,101,97,99,104,45,97,114,103,118,45,108,105,110,101,32,116,104,117,110,107,52,55,50,41,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,7),40,97,50,53,51,55,41,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,20),40,114,101,97,100,45,97,108,108,32,46,32,102,105,108,101,52,55,57,41,0,0,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_utils_toplevel)
C_externexport void C_ccall C_utils_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_525)
static void C_ccall f_525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_528)
static void C_ccall f_528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_531)
static void C_ccall f_531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_534)
static void C_ccall f_534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2565)
static void C_ccall f_2565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1681)
static void C_ccall f_1681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1684)
static void C_ccall f_1684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2068)
static void C_ccall f_2068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2071)
static void C_ccall f_2071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2520)
static void C_ccall f_2520(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2520)
static void C_ccall f_2520r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2524)
static void C_ccall f_2524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2530)
static void C_ccall f_2530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2538)
static void C_ccall f_2538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2475)
static void C_ccall f_2475(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2500)
static void C_ccall f_2500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2493)
static void C_ccall f_2493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2446)
static void C_ccall f_2446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2451)
static void C_fcall f_2451(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2464)
static void C_ccall f_2464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2402)
static void C_ccall f_2402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2404)
static C_word C_fcall f_2404(C_word t0);
C_noret_decl(f_2329)
static void C_ccall f_2329(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2329)
static void C_ccall f_2329r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2333)
static void C_ccall f_2333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2386)
static void C_ccall f_2386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2336)
static void C_ccall f_2336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2347)
static void C_fcall f_2347(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2377)
static void C_ccall f_2377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2373)
static void C_ccall f_2373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2354)
static void C_ccall f_2354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2360)
static void C_ccall f_2360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2311)
static void C_ccall f_2311(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2323)
static void C_ccall f_2323(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2317)
static void C_ccall f_2317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2293)
static void C_ccall f_2293(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2305)
static void C_ccall f_2305(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2299)
static void C_ccall f_2299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2275)
static void C_ccall f_2275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2287)
static void C_ccall f_2287(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2269)
static void C_ccall f_2269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2263)
static void C_ccall f_2263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2251)
static void C_ccall f_2251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2245)
static void C_ccall f_2245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2224)
static void C_ccall f_2224(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2236)
static void C_ccall f_2236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2230)
static void C_ccall f_2230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2209)
static void C_ccall f_2209(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2221)
static void C_ccall f_2221(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2215)
static void C_ccall f_2215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2194)
static void C_ccall f_2194(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2206)
static void C_ccall f_2206(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2200)
static void C_ccall f_2200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2086)
static void C_ccall f_2086(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2102)
static void C_ccall f_2102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2131)
static void C_ccall f_2131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2156)
static void C_ccall f_2156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2141)
static void C_ccall f_2141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2112)
static void C_ccall f_2112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2072)
static void C_fcall f_2072(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1989)
static void C_ccall f_1989(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1989)
static void C_ccall f_1989r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2018)
static void C_fcall f_2018(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2013)
static void C_fcall f_2013(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1991)
static void C_fcall f_1991(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1999)
static void C_ccall f_1999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2005)
static void C_ccall f_2005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2002)
static void C_ccall f_2002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1925)
static void C_ccall f_1925(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1925)
static void C_ccall f_1925r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1941)
static void C_fcall f_1941(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1936)
static void C_fcall f_1936(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1927)
static void C_fcall f_1927(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1935)
static void C_ccall f_1935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1844)
static void C_fcall f_1844(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1873)
static void C_ccall f_1873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1880)
static void C_fcall f_1880(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1813)
static void C_fcall f_1813(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1752)
static void C_fcall f_1752(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1761)
static void C_fcall f_1761(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1799)
static void C_ccall f_1799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1698)
static void C_fcall f_1698(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1714)
static void C_fcall f_1714(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1685)
static void C_ccall f_1685(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1696)
static void C_ccall f_1696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1268)
static void C_ccall f_1268(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1268)
static void C_ccall f_1268r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1628)
static void C_fcall f_1628(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1623)
static void C_fcall f_1623(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1270)
static void C_fcall f_1270(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1283)
static void C_fcall f_1283(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1616)
static void C_ccall f_1616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1612)
static void C_ccall f_1612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1286)
static void C_ccall f_1286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1289)
static void C_ccall f_1289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1605)
static void C_ccall f_1605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1292)
static void C_ccall f_1292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1588)
static void C_ccall f_1588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1598)
static void C_ccall f_1598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1295)
static void C_ccall f_1295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1532)
static void C_ccall f_1532(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1563)
static void C_ccall f_1563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1575)
static void C_ccall f_1575(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1575)
static void C_ccall f_1575r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1581)
static void C_ccall f_1581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1569)
static void C_ccall f_1569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1538)
static void C_ccall f_1538(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1544)
static void C_ccall f_1544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1555)
static void C_ccall f_1555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1530)
static void C_ccall f_1530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1298)
static void C_ccall f_1298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1474)
static void C_ccall f_1474(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1505)
static void C_ccall f_1505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1517)
static void C_ccall f_1517(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1517)
static void C_ccall f_1517r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1523)
static void C_ccall f_1523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1511)
static void C_ccall f_1511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1480)
static void C_ccall f_1480(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1486)
static void C_ccall f_1486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1497)
static void C_ccall f_1497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1472)
static void C_ccall f_1472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1301)
static void C_ccall f_1301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1304)
static void C_ccall f_1304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1311)
static void C_ccall f_1311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1313)
static void C_fcall f_1313(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1406)
static void C_ccall f_1406(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1447)
static void C_ccall f_1447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1459)
static void C_ccall f_1459(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1459)
static void C_ccall f_1459r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1465)
static void C_ccall f_1465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1453)
static void C_ccall f_1453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1412)
static void C_ccall f_1412(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1418)
static void C_ccall f_1418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1425)
static void C_ccall f_1425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1428)
static void C_ccall f_1428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1439)
static void C_ccall f_1439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1435)
static void C_ccall f_1435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1404)
static void C_ccall f_1404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1390)
static void C_ccall f_1390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1397)
static void C_ccall f_1397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1323)
static void C_ccall f_1323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1326)
static void C_ccall f_1326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1334)
static void C_ccall f_1334(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1365)
static void C_ccall f_1365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1377)
static void C_ccall f_1377(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1377)
static void C_ccall f_1377r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1383)
static void C_ccall f_1383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1371)
static void C_ccall f_1371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1340)
static void C_ccall f_1340(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1346)
static void C_ccall f_1346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1357)
static void C_ccall f_1357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1332)
static void C_ccall f_1332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1329)
static void C_ccall f_1329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_921)
static void C_ccall f_921(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_921)
static void C_ccall f_921r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1220)
static void C_fcall f_1220(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1215)
static void C_fcall f_1215(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_923)
static void C_fcall f_923(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_936)
static void C_fcall f_936(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1208)
static void C_ccall f_1208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1204)
static void C_ccall f_1204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_939)
static void C_ccall f_939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_942)
static void C_ccall f_942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1197)
static void C_ccall f_1197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_945)
static void C_ccall f_945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1180)
static void C_ccall f_1180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1190)
static void C_ccall f_1190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_948)
static void C_ccall f_948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1124)
static void C_ccall f_1124(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1155)
static void C_ccall f_1155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1167)
static void C_ccall f_1167(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1167)
static void C_ccall f_1167r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1173)
static void C_ccall f_1173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1161)
static void C_ccall f_1161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1130)
static void C_ccall f_1130(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1136)
static void C_ccall f_1136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1147)
static void C_ccall f_1147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1122)
static void C_ccall f_1122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_951)
static void C_ccall f_951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1066)
static void C_ccall f_1066(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1097)
static void C_ccall f_1097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1109)
static void C_ccall f_1109(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1109)
static void C_ccall f_1109r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1115)
static void C_ccall f_1115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1103)
static void C_ccall f_1103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1072)
static void C_ccall f_1072(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1078)
static void C_ccall f_1078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1089)
static void C_ccall f_1089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1064)
static void C_ccall f_1064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_954)
static void C_ccall f_954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_957)
static void C_ccall f_957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_964)
static void C_ccall f_964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_966)
static void C_fcall f_966(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_998)
static void C_ccall f_998(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1039)
static void C_ccall f_1039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1051)
static void C_ccall f_1051(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1051)
static void C_ccall f_1051r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1057)
static void C_ccall f_1057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1045)
static void C_ccall f_1045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1004)
static void C_ccall f_1004(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1010)
static void C_ccall f_1010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1017)
static void C_ccall f_1017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1020)
static void C_ccall f_1020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1031)
static void C_ccall f_1031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1027)
static void C_ccall f_1027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_996)
static void C_ccall f_996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_982)
static void C_ccall f_982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_989)
static void C_ccall f_989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_976)
static void C_ccall f_976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_979)
static void C_ccall f_979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_906)
static void C_ccall f_906(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_913)
static void C_ccall f_913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_919)
static void C_ccall f_919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_888)
static void C_ccall f_888(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_888)
static void C_ccall f_888r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_892)
static void C_ccall f_892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_895)
static void C_ccall f_895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_796)
static void C_ccall f_796(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_796)
static void C_ccall f_796r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_800)
static void C_ccall f_800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_877)
static void C_ccall f_877(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_886)
static void C_ccall f_886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_803)
static void C_ccall f_803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_808)
static void C_ccall f_808(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_812)
static void C_ccall f_812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_875)
static void C_ccall f_875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_854)
static void C_fcall f_854(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_864)
static void C_ccall f_864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_815)
static void C_ccall f_815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_818)
static void C_ccall f_818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_821)
static void C_ccall f_821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_824)
static void C_ccall f_824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_833)
static void C_ccall f_833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_744)
static void C_ccall f_744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_827)
static void C_ccall f_827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_790)
static void C_ccall f_790(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_790)
static void C_ccall f_790r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_771)
static void C_fcall f_771(C_word t0,C_word t1) C_noret;
C_noret_decl(f_788)
static void C_ccall f_788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_781)
static void C_ccall f_781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_668)
static void C_fcall f_668(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_672)
static void C_ccall f_672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_690)
static void C_ccall f_690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_681)
static void C_ccall f_681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_704)
static C_word C_fcall f_704(C_word t0,C_word t1);
C_noret_decl(f_623)
static void C_ccall f_623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_623)
static void C_ccall f_623r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_627)
static void C_ccall f_627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_630)
static void C_ccall f_630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_640)
static void C_ccall f_640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_596)
static void C_ccall f_596(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_601)
static void C_ccall f_601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_606)
static void C_ccall f_606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_621)
static void C_ccall f_621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_613)
static void C_ccall f_613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_604)
static void C_ccall f_604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_570)
static void C_ccall f_570(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_575)
static void C_ccall f_575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_580)
static void C_ccall f_580(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_594)
static void C_ccall f_594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_587)
static void C_ccall f_587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_543)
static void C_fcall f_543(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_568)
static void C_ccall f_568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_547)
static void C_fcall f_547(C_word t0,C_word t1) C_noret;
C_noret_decl(f_561)
static void C_ccall f_561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_557)
static void C_ccall f_557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_550)
static void C_fcall f_550(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2451)
static void C_fcall trf_2451(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2451(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2451(t0,t1);}

C_noret_decl(trf_2347)
static void C_fcall trf_2347(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2347(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2347(t0,t1);}

C_noret_decl(trf_2072)
static void C_fcall trf_2072(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2072(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2072(t0,t1);}

C_noret_decl(trf_2018)
static void C_fcall trf_2018(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2018(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2018(t0,t1);}

C_noret_decl(trf_2013)
static void C_fcall trf_2013(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2013(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2013(t0,t1,t2);}

C_noret_decl(trf_1991)
static void C_fcall trf_1991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1991(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1991(t0,t1,t2,t3);}

C_noret_decl(trf_1941)
static void C_fcall trf_1941(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1941(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1941(t0,t1);}

C_noret_decl(trf_1936)
static void C_fcall trf_1936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1936(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1936(t0,t1,t2);}

C_noret_decl(trf_1927)
static void C_fcall trf_1927(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1927(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1927(t0,t1,t2,t3);}

C_noret_decl(trf_1844)
static void C_fcall trf_1844(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1844(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_1844(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_1880)
static void C_fcall trf_1880(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1880(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1880(t0,t1);}

C_noret_decl(trf_1813)
static void C_fcall trf_1813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1813(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1813(t0,t1,t2,t3);}

C_noret_decl(trf_1752)
static void C_fcall trf_1752(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1752(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1752(t0,t1,t2,t3);}

C_noret_decl(trf_1761)
static void C_fcall trf_1761(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1761(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1761(t0,t1,t2);}

C_noret_decl(trf_1698)
static void C_fcall trf_1698(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1698(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1698(t0,t1,t2);}

C_noret_decl(trf_1714)
static void C_fcall trf_1714(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1714(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1714(t0,t1);}

C_noret_decl(trf_1628)
static void C_fcall trf_1628(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1628(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1628(t0,t1);}

C_noret_decl(trf_1623)
static void C_fcall trf_1623(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1623(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1623(t0,t1,t2);}

C_noret_decl(trf_1270)
static void C_fcall trf_1270(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1270(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1270(t0,t1,t2,t3);}

C_noret_decl(trf_1283)
static void C_fcall trf_1283(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1283(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1283(t0,t1);}

C_noret_decl(trf_1313)
static void C_fcall trf_1313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1313(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1313(t0,t1,t2,t3);}

C_noret_decl(trf_1220)
static void C_fcall trf_1220(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1220(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1220(t0,t1);}

C_noret_decl(trf_1215)
static void C_fcall trf_1215(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1215(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1215(t0,t1,t2);}

C_noret_decl(trf_923)
static void C_fcall trf_923(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_923(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_923(t0,t1,t2,t3);}

C_noret_decl(trf_936)
static void C_fcall trf_936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_936(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_936(t0,t1);}

C_noret_decl(trf_966)
static void C_fcall trf_966(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_966(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_966(t0,t1,t2,t3);}

C_noret_decl(trf_854)
static void C_fcall trf_854(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_854(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_854(t0,t1,t2);}

C_noret_decl(trf_771)
static void C_fcall trf_771(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_771(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_771(t0,t1);}

C_noret_decl(trf_668)
static void C_fcall trf_668(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_668(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_668(t0,t1,t2,t3);}

C_noret_decl(trf_543)
static void C_fcall trf_543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_543(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_543(t0,t1,t2);}

C_noret_decl(trf_547)
static void C_fcall trf_547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_547(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_547(t0,t1);}

C_noret_decl(trf_550)
static void C_fcall trf_550(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_550(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_550(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_utils_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_utils_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("utils_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(862)){
C_save(t1);
C_rereclaim2(862*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,128);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],19,"\003sysundefined-value");
lf[3]=C_h_intern(&lf[3],20,"\003sysapropos-interned");
lf[4]=C_h_intern(&lf[4],18,"\003sysapropos-macros");
lf[5]=C_h_intern(&lf[5],13,"string-search");
lf[6]=C_h_intern(&lf[6],6,"regexp");
lf[7]=C_h_intern(&lf[7],13,"regexp-escape");
lf[8]=C_h_intern(&lf[8],14,"symbol->string");
lf[9]=C_h_intern(&lf[9],32,"\003syssymbol-has-toplevel-binding\077");
lf[10]=C_h_intern(&lf[10],23,"\003sysenvironment-symbols");
lf[11]=C_h_intern(&lf[11],23,"\003syshash-table-for-each");
lf[12]=C_h_intern(&lf[12],21,"\003sysmacro-environment");
lf[13]=C_h_intern(&lf[13],11,"\003sysapropos");
lf[14]=C_h_intern(&lf[14],10,"\003sysappend");
lf[15]=C_h_intern(&lf[15],9,"\003syserror");
lf[16]=C_h_intern(&lf[16],12,"apropos-list");
lf[17]=C_h_intern(&lf[17],7,"apropos");
lf[18]=C_h_intern(&lf[18],8,"\000macros\077");
lf[19]=C_h_intern(&lf[19],11,"environment");
lf[20]=C_h_intern(&lf[20],15,"\003syssignal-hook");
lf[21]=C_h_intern(&lf[21],11,"\000type-error");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\0003bad argument type - not a string, symbol, or regexp");
lf[23]=C_h_intern(&lf[23],7,"regexp\077");
lf[24]=C_h_intern(&lf[24],23,"interaction-environment");
lf[25]=C_h_intern(&lf[25],8,"keyword\077");
lf[26]=C_h_intern(&lf[26],28,"\003syssymbol->qualified-string");
lf[27]=C_h_intern(&lf[27],7,"newline");
lf[28]=C_h_intern(&lf[28],7,"display");
lf[29]=C_h_intern(&lf[29],5,"macro");
lf[30]=C_h_intern(&lf[30],9,"procedure");
lf[31]=C_h_intern(&lf[31],21,"procedure-information");
lf[32]=C_h_intern(&lf[32],8,"variable");
lf[33]=C_h_intern(&lf[33],6,"macro\077");
lf[34]=C_h_intern(&lf[34],12,"\003sysfor-each");
lf[35]=C_h_intern(&lf[35],7,"sprintf");
lf[36]=C_h_intern(&lf[36],6,"system");
lf[37]=C_h_intern(&lf[37],7,"system*");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\0003shell invocation failed with non-zero return status");
lf[39]=C_h_intern(&lf[39],12,"file-exists\077");
lf[40]=C_h_intern(&lf[40],11,"delete-file");
lf[41]=C_h_intern(&lf[41],12,"delete-file*");
lf[42]=C_h_intern(&lf[42],9,"file-copy");
lf[43]=C_h_intern(&lf[43],17,"close-output-port");
lf[44]=C_h_intern(&lf[44],16,"close-input-port");
lf[45]=C_h_intern(&lf[45],12,"read-string!");
lf[46]=C_h_intern(&lf[46],9,"condition");
lf[47]=C_h_intern(&lf[47],13,"string-append");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\037error writing file starting at ");
lf[49]=C_h_intern(&lf[49],12,"write-string");
lf[50]=C_h_intern(&lf[50],22,"with-exception-handler");
lf[51]=C_h_intern(&lf[51],30,"call-with-current-continuation");
lf[52]=C_h_intern(&lf[52],11,"make-string");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000#could not open newfile for write - ");
lf[54]=C_h_intern(&lf[54],16,"open-output-file");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000#could not open origfile for read - ");
lf[56]=C_h_intern(&lf[56],15,"open-input-file");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000&newfile exists but clobber is false - ");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\032origfile does not exist - ");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\0002invalid blocksize given: not a positive integer - ");
lf[60]=C_h_intern(&lf[60],9,"file-move");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\034could not remove origfile - ");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\037error writing file starting at ");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000#could not open newfile for write - ");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000#could not open origfile for read - ");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000&newfile exists but clobber is false - ");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\032origfile does not exist - ");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\0002invalid blocksize given: not a positive integer - ");
lf[68]=C_h_intern(&lf[68],12,"string-match");
lf[69]=C_h_intern(&lf[69],20,"\003syswindows-platform");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\014([A-Za-z]:)\077");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[72]=C_h_intern(&lf[72],18,"absolute-pathname\077");
lf[74]=C_h_intern(&lf[74],13,"\003syssubstring");
lf[75]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000/\376\003\000\000\002\376\377\012\000\000\134\376\377\016");
lf[76]=C_h_intern(&lf[76],13,"make-pathname");
lf[77]=C_h_intern(&lf[77],22,"make-absolute-pathname");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[85]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[86]=C_h_intern(&lf[86],17,"\003sysstring-append");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[89]=C_h_intern(&lf[89],18,"decompose-pathname");
lf[90]=C_h_intern(&lf[90],18,"pathname-directory");
lf[91]=C_h_intern(&lf[91],13,"pathname-file");
lf[92]=C_h_intern(&lf[92],18,"pathname-extension");
lf[93]=C_h_intern(&lf[93],24,"pathname-strip-directory");
lf[94]=C_h_intern(&lf[94],24,"pathname-strip-extension");
lf[95]=C_h_intern(&lf[95],26,"pathname-replace-directory");
lf[96]=C_h_intern(&lf[96],21,"pathname-replace-file");
lf[97]=C_h_intern(&lf[97],26,"pathname-replace-extension");
lf[98]=C_h_intern(&lf[98],6,"getenv");
lf[99]=C_h_intern(&lf[99],21,"call-with-output-file");
lf[100]=C_h_intern(&lf[100],21,"create-temporary-file");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\003tmp");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\003TMP");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\004TEMP");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\006TMPDIR");
lf[106]=C_h_intern(&lf[106],15,"directory-null\077");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[109]=C_h_intern(&lf[109],12,"string-split");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[111]=C_h_intern(&lf[111],9,"read-line");
lf[112]=C_h_intern(&lf[112],13,"for-each-line");
lf[113]=C_h_intern(&lf[113],18,"\003sysstandard-input");
lf[114]=C_h_intern(&lf[114],14,"\003syscheck-port");
lf[115]=C_h_intern(&lf[115],18,"for-each-argv-line");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[117]=C_h_intern(&lf[117],20,"with-input-from-file");
lf[118]=C_h_intern(&lf[118],22,"command-line-arguments");
lf[119]=C_h_intern(&lf[119],8,"read-all");
lf[120]=C_h_intern(&lf[120],20,"\003sysread-string/port");
lf[121]=C_h_intern(&lf[121],5,"port\077");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\034^(.*[\134/\134\134])\077((\134.)\077[^\134/\134\134]+)$");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000&^(.*[\134/\134\134])\077([^\134/\134\134]+)(\134.([^\134/\134\134.]+))$");
lf[124]=C_h_intern(&lf[124],21,"make-anchored-pattern");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\010[\134/\134\134].*");
lf[126]=C_h_intern(&lf[126],17,"register-feature!");
lf[127]=C_h_intern(&lf[127],5,"utils");
C_register_lf2(lf,128,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_525,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k523 */
static void C_ccall f_525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_528,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k526 in k523 */
static void C_ccall f_528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_531,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k529 in k526 in k523 */
static void C_ccall f_531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_534,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 69   register-feature! */
t3=*((C_word*)lf[126]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[127]);}

/* k532 in k529 in k526 in k523 */
static void C_ccall f_534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_534,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=C_mutate((C_word*)lf[3]+1,t2);
t4=*((C_word*)lf[2]+1);
t5=C_mutate((C_word*)lf[4]+1,t4);
t6=*((C_word*)lf[5]+1);
t7=*((C_word*)lf[6]+1);
t8=*((C_word*)lf[7]+1);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_543,a[2]=t8,a[3]=t7,a[4]=((C_word)li0),tmp=(C_word)a,a+=5,tmp);
t10=C_mutate((C_word*)lf[3]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_570,a[2]=t9,a[3]=t6,a[4]=((C_word)li2),tmp=(C_word)a,a+=5,tmp));
t11=C_mutate((C_word*)lf[4]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_596,a[2]=t9,a[3]=t6,a[4]=((C_word)li4),tmp=(C_word)a,a+=5,tmp));
t12=C_mutate((C_word*)lf[13]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_623,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[2]+1);
t14=C_mutate((C_word*)lf[16]+1,t13);
t15=*((C_word*)lf[2]+1);
t16=C_mutate((C_word*)lf[17]+1,t15);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_668,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_771,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp);
t19=C_mutate((C_word*)lf[16]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_790,a[2]=t17,a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp));
t20=C_mutate((C_word*)lf[17]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_796,a[2]=t17,a[3]=t18,a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp));
t21=*((C_word*)lf[35]+1);
t22=*((C_word*)lf[36]+1);
t23=C_mutate((C_word*)lf[37]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_888,a[2]=t21,a[3]=t22,a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp));
t24=*((C_word*)lf[39]+1);
t25=*((C_word*)lf[40]+1);
t26=C_mutate((C_word*)lf[41]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_906,a[2]=t24,a[3]=t25,a[4]=((C_word)li15),tmp=(C_word)a,a+=5,tmp));
t27=C_mutate((C_word*)lf[42]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_921,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[60]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1268,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t29=*((C_word*)lf[68]+1);
t30=*((C_word*)lf[6]+1);
t31=*((C_word*)lf[47]+1);
t32=(C_truep(*((C_word*)lf[69]+1))?lf[70]:lf[71]);
t33=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1681,a[2]=t30,a[3]=((C_word*)t0)[2],a[4]=t29,tmp=(C_word)a,a+=5,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2565,a[2]=t33,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 296  string-append */
t35=t31;
((C_proc4)C_retrieve_proc(t35))(4,t35,t34,t32,lf[125]);}

/* k2563 in k532 in k529 in k526 in k523 */
static void C_ccall f_2565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 296  make-anchored-pattern */
t2=*((C_word*)lf[124]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_1681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1684,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 297  regexp */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_1684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1684,2,t0,t1);}
t2=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1685,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li75),tmp=(C_word)a,a+=5,tmp));
t3=C_mutate(&lf[73],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1698,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t4=*((C_word*)lf[2]+1);
t5=C_mutate((C_word*)lf[76]+1,t4);
t6=*((C_word*)lf[2]+1);
t7=C_mutate((C_word*)lf[77]+1,t6);
t8=*((C_word*)lf[47]+1);
t9=*((C_word*)lf[72]+1);
t10=lf[78];
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1752,a[2]=t8,a[3]=t10,a[4]=((C_word)li78),tmp=(C_word)a,a+=5,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1813,a[2]=t11,a[3]=((C_word)li79),tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1844,a[2]=t8,a[3]=((C_word)li80),tmp=(C_word)a,a+=4,tmp);
t14=C_mutate((C_word*)lf[76]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1925,a[2]=t12,a[3]=t13,a[4]=((C_word)li84),tmp=(C_word)a,a+=5,tmp));
t15=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1989,a[2]=t12,a[3]=t9,a[4]=t10,a[5]=t13,a[6]=((C_word)li88),tmp=(C_word)a,a+=7,tmp));
t16=*((C_word*)lf[68]+1);
t17=*((C_word*)lf[6]+1);
t18=*((C_word*)lf[47]+1);
t19=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2068,a[2]=t17,a[3]=((C_word*)t0)[2],a[4]=t16,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 380  regexp */
t20=t17;
((C_proc3)C_retrieve_proc(t20))(3,t20,t19,lf[123]);}

/* k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2071,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 381  regexp */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[122]);}

/* k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word ab[62],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2072,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp);
t3=C_mutate((C_word*)lf[89]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2086,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li90),tmp=(C_word)a,a+=7,tmp));
t4=*((C_word*)lf[2]+1);
t5=C_mutate((C_word*)lf[90]+1,t4);
t6=*((C_word*)lf[2]+1);
t7=C_mutate((C_word*)lf[91]+1,t6);
t8=*((C_word*)lf[2]+1);
t9=C_mutate((C_word*)lf[92]+1,t8);
t10=*((C_word*)lf[2]+1);
t11=C_mutate((C_word*)lf[93]+1,t10);
t12=*((C_word*)lf[2]+1);
t13=C_mutate((C_word*)lf[94]+1,t12);
t14=*((C_word*)lf[2]+1);
t15=C_mutate((C_word*)lf[95]+1,t14);
t16=*((C_word*)lf[2]+1);
t17=C_mutate((C_word*)lf[96]+1,t16);
t18=*((C_word*)lf[2]+1);
t19=C_mutate((C_word*)lf[97]+1,t18);
t20=*((C_word*)lf[89]+1);
t21=C_mutate((C_word*)lf[90]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2194,a[2]=t20,a[3]=((C_word)li93),tmp=(C_word)a,a+=4,tmp));
t22=C_mutate((C_word*)lf[91]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2209,a[2]=t20,a[3]=((C_word)li96),tmp=(C_word)a,a+=4,tmp));
t23=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2224,a[2]=t20,a[3]=((C_word)li99),tmp=(C_word)a,a+=4,tmp));
t24=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2239,a[2]=t20,a[3]=((C_word)li102),tmp=(C_word)a,a+=4,tmp));
t25=C_mutate((C_word*)lf[94]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2257,a[2]=t20,a[3]=((C_word)li105),tmp=(C_word)a,a+=4,tmp));
t26=C_mutate((C_word*)lf[95]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2275,a[2]=t20,a[3]=((C_word)li108),tmp=(C_word)a,a+=4,tmp));
t27=C_mutate((C_word*)lf[96]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2293,a[2]=t20,a[3]=((C_word)li111),tmp=(C_word)a,a+=4,tmp));
t28=C_mutate((C_word*)lf[97]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2311,a[2]=t20,a[3]=((C_word)li114),tmp=(C_word)a,a+=4,tmp));
t29=*((C_word*)lf[98]+1);
t30=*((C_word*)lf[76]+1);
t31=*((C_word*)lf[39]+1);
t32=*((C_word*)lf[99]+1);
t33=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2329,a[2]=t29,a[3]=t30,a[4]=t31,a[5]=t32,a[6]=((C_word)li117),tmp=(C_word)a,a+=7,tmp));
t34=C_mutate((C_word*)lf[106]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2394,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp));
t35=*((C_word*)lf[111]+1);
t36=C_mutate((C_word*)lf[112]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2439,a[2]=t35,a[3]=((C_word)li121),tmp=(C_word)a,a+=4,tmp));
t37=C_mutate((C_word*)lf[115]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2475,a[2]=((C_word)li124),tmp=(C_word)a,a+=3,tmp));
t38=C_mutate((C_word*)lf[119]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2520,a[2]=((C_word)li126),tmp=(C_word)a,a+=3,tmp));
t39=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t39+1)))(2,t39,C_SCHEME_UNDEFINED);}

/* read-all in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2520(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2520r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2520r(t0,t1,t2);}}

static void C_ccall f_2520r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2524,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_2524(2,t4,*((C_word*)lf[113]+1));}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_2524(2,t5,(C_word)C_i_car(t2));}
else{
/* utils.scm: 512  ##sys#error */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k2522 in read-all in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2530,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 513  port? */
t3=*((C_word*)lf[121]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k2528 in k2522 in read-all in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2530,2,t0,t1);}
if(C_truep(t1)){
/* read-string/port */
t2=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2538,a[2]=((C_word)li125),tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 515  with-input-from-file */
t3=*((C_word*)lf[117]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* a2537 in k2528 in k2522 in read-all in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2538,2,t0,t1);}
/* read-string/port */
t2=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_SCHEME_FALSE,*((C_word*)lf[113]+1));}

/* for-each-argv-line in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2475(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2475,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2500,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 501  command-line-arguments */
t4=*((C_word*)lf[118]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k2498 in for-each-argv-line in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2500,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
/* utils.scm: 504  for-each-line */
t2=*((C_word*)lf[112]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2514,a[2]=((C_word*)t0)[2],a[3]=((C_word)li123),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t3=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,t1);}}

/* a2513 in k2498 in for-each-argv-line in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2514(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2514,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
if(C_truep((C_word)C_i_string_equal_p(t2,lf[116]))){
/* utils.scm: 499  for-each-line */
t4=*((C_word*)lf[112]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2493,a[2]=t3,a[3]=((C_word)li122),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 500  with-input-from-file */
t5=*((C_word*)lf[117]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t4);}}

/* a2492 in a2513 in k2498 in for-each-argv-line in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2493,2,t0,t1);}
/* for-each-line */
t2=*((C_word*)lf[112]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* for-each-line in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2439(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2439r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2439r(t0,t1,t2,t3);}}

static void C_ccall f_2439r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):*((C_word*)lf[113]+1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2446,a[2]=t1,a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 486  ##sys#check-port */
t7=*((C_word*)lf[114]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t5,lf[112]);}

/* k2444 in for-each-line in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2446,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2451,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word)li120),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2451(t5,((C_word*)t0)[2]);}

/* loop in k2444 in for-each-line in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_fcall f_2451(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2451,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2455,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 488  read-line */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2453 in loop in k2444 in for-each-line in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2455,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2464,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 490  proc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}}

/* k2462 in k2453 in loop in k2444 in for-each-line in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 491  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2451(t2,((C_word*)t0)[2]);}

/* directory-null? in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2394(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2394,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2402,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=t3;
f_2402(2,t4,t2);}
else{
t4=(C_word)C_i_check_string_2(t2,lf[106]);
/* utils.scm: 475  string-split */
t5=*((C_word*)lf[109]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t2,lf[110],C_SCHEME_TRUE);}}

/* k2400 in directory-null? in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2404,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2404(t1));}

/* loop in k2400 in directory-null? in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static C_word C_fcall f_2404(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=(C_word)C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_i_car(t1);
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[107]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[108]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=(C_word)C_i_cdr(t1);
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* create-temporary-file in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2329(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2329r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2329r(t0,t1,t2);}}

static void C_ccall f_2329r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2333,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* utils.scm: 456  getenv */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[105]);}

/* k2331 in create-temporary-file in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2336,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_2336(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2386,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 456  getenv */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[104]);}}

/* k2384 in k2331 in create-temporary-file in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2336(2,t2,t1);}
else{
/* utils.scm: 456  getenv */
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],lf[103]);}}

/* k2334 in k2331 in create-temporary-file in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2336,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[6]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[6],C_fix(0)):lf[101]);
t4=(C_word)C_i_check_string_2(t3,lf[100]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2347,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t6,a[8]=((C_word)li116),tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_2347(t8,((C_word*)t0)[2]);}

/* loop in k2334 in k2331 in create-temporary-file in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_fcall f_2347(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2347,NULL,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(16));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2354,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2373,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2377,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 461  number->string */
C_number_to_string(4,0,t5,t2,C_fix(16));}

/* k2375 in loop in k2334 in k2331 in create-temporary-file in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 461  ##sys#string-append */
t2=*((C_word*)lf[86]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[102],t1);}

/* k2371 in loop in k2334 in k2331 in create-temporary-file in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 461  make-pathname */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2352 in loop in k2334 in k2331 in create-temporary-file in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2360,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 462  file-exists? */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2358 in k2352 in loop in k2334 in k2331 in create-temporary-file in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2360,2,t0,t1);}
if(C_truep(t1)){
/* utils.scm: 463  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2347(t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2368,a[2]=((C_word*)t0)[3],a[3]=((C_word)li115),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 464  call-with-output-file */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],((C_word*)t0)[3],t2);}}

/* a2367 in k2358 in k2352 in loop in k2334 in k2331 in create-temporary-file in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2368(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2368,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* pathname-replace-extension in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2311(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2311,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2317,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li112),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2323,a[2]=t3,a[3]=((C_word)li113),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a2322 in pathname-replace-extension in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2323(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2323,5,t0,t1,t2,t3,t4);}
/* utils.scm: 448  make-pathname */
t5=*((C_word*)lf[76]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,((C_word*)t0)[2]);}

/* a2316 in pathname-replace-extension in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2317,2,t0,t1);}
/* utils.scm: 447  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-replace-file in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2293(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2293,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2299,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li109),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2305,a[2]=t3,a[3]=((C_word)li110),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a2304 in pathname-replace-file in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2305(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2305,5,t0,t1,t2,t3,t4);}
/* utils.scm: 443  make-pathname */
t5=*((C_word*)lf[76]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,((C_word*)t0)[2],t4);}

/* a2298 in pathname-replace-file in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2299,2,t0,t1);}
/* utils.scm: 442  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-replace-directory in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2275,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2281,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li106),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2287,a[2]=t3,a[3]=((C_word)li107),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a2286 in pathname-replace-directory in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2287(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2287,5,t0,t1,t2,t3,t4);}
/* utils.scm: 438  make-pathname */
t5=*((C_word*)lf[76]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t3,t4);}

/* a2280 in pathname-replace-directory in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2281,2,t0,t1);}
/* utils.scm: 437  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-strip-extension in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2257(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2257,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2263,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li103),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2269,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a2268 in pathname-strip-extension in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2269,5,t0,t1,t2,t3,t4);}
/* utils.scm: 433  make-pathname */
t5=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}

/* a2262 in pathname-strip-extension in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2263,2,t0,t1);}
/* utils.scm: 432  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-strip-directory in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2239,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2245,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li100),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2251,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a2250 in pathname-strip-directory in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2251,5,t0,t1,t2,t3,t4);}
/* utils.scm: 428  make-pathname */
t5=*((C_word*)lf[76]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,C_SCHEME_FALSE,t3,t4);}

/* a2244 in pathname-strip-directory in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2245,2,t0,t1);}
/* utils.scm: 427  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-extension in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2224(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2224,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2230,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li97),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2236,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a2235 in pathname-extension in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2236,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* a2229 in pathname-extension in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2230,2,t0,t1);}
/* utils.scm: 422  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-file in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2209(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2209,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2215,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li94),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2221,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a2220 in pathname-file in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2221(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2221,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* a2214 in pathname-file in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2215,2,t0,t1);}
/* utils.scm: 417  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-directory in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2194(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2194,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2200,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li91),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2206,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a2205 in pathname-directory in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2206(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2206,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* a2199 in pathname-directory in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2200,2,t0,t1);}
/* utils.scm: 412  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* decompose-pathname in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2086(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2086,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[89]);
t4=(C_word)C_block_size(t2);
t5=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t5)){
/* utils.scm: 391  values */
C_values(5,0,t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2102,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 392  string-match */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[2],t2);}}

/* k2100 in decompose-pathname in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2102,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2112,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(t1);
/* utils.scm: 394  strip-pds */
f_2072(t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2131,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 395  string-match */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* k2129 in k2100 in decompose-pathname in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2131,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2141,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(t1);
/* utils.scm: 397  strip-pds */
f_2072(t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2156,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 398  strip-pds */
f_2072(t2,((C_word*)t0)[2]);}}

/* k2154 in k2129 in k2100 in decompose-pathname in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 398  values */
C_values(5,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k2139 in k2129 in k2100 in decompose-pathname in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_caddr(((C_word*)t0)[3]);
/* utils.scm: 397  values */
C_values(5,0,((C_word*)t0)[2],t1,t2,C_SCHEME_FALSE);}

/* k2110 in k2100 in decompose-pathname in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_caddr(((C_word*)t0)[3]);
t3=(C_word)C_i_cddddr(((C_word*)t0)[3]);
t4=(C_word)C_i_car(t3);
/* utils.scm: 394  values */
C_values(5,0,((C_word*)t0)[2],t1,t2,t4);}

/* strip-pds in k2069 in k2066 in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_fcall f_2072(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2072,NULL,2,t1,t2);}
if(C_truep(t2)){
t3=t2;
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[87]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[88]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
/* utils.scm: 387  chop-pds */
f_1698(t1,t2,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* make-absolute-pathname in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_1989(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_1989r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1989r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1989r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1991,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=((C_word)li85),tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2013,a[2]=t5,a[3]=((C_word)li86),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2018,a[2]=t6,a[3]=((C_word)li87),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-ext315326 */
t8=t7;
f_2018(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-pds316324 */
t10=t6;
f_2013(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body313318 */
t12=t5;
f_1991(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-ext315 in make-absolute-pathname in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_fcall f_2018(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2018,NULL,2,t0,t1);}
/* def-pds316324 */
t2=((C_word*)t0)[2];
f_2013(t2,t1,C_SCHEME_FALSE);}

/* def-pds316 in make-absolute-pathname in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_fcall f_2013(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2013,NULL,3,t0,t1,t2);}
/* body313318 */
t3=((C_word*)t0)[2];
f_1991(t3,t1,t2,C_SCHEME_FALSE);}

/* body313 in make-absolute-pathname in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_fcall f_1991(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1991,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1999,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* utils.scm: 368  canonicalize-dirs */
t5=((C_word*)t0)[3];
f_1813(t5,t4,((C_word*)t0)[2],t3);}

/* k1997 in body313 in make-absolute-pathname in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_1999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2002,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2005,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 369  absolute-pathname? */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}

/* k2003 in k1997 in body313 in make-absolute-pathname in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_2002(2,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
t3=(C_truep(t2)?t2:((C_word*)t0)[2]);
/* utils.scm: 371  ##sys#string-append */
t4=*((C_word*)lf[86]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4]);}}

/* k2000 in k1997 in body313 in make-absolute-pathname in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_2002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 366  _make-pathname */
t2=((C_word*)t0)[6];
f_1844(t2,((C_word*)t0)[5],lf[77],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* make-pathname in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_1925(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr4r,(void*)f_1925r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1925r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1925r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(15);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1927,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word)li81),tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1936,a[2]=t5,a[3]=((C_word)li82),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1941,a[2]=t6,a[3]=((C_word)li83),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-ext294302 */
t8=t7;
f_1941(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-pds295300 */
t10=t6;
f_1936(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body292297 */
t12=t5;
f_1927(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-ext294 in make-pathname in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_fcall f_1941(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1941,NULL,2,t0,t1);}
/* def-pds295300 */
t2=((C_word*)t0)[2];
f_1936(t2,t1,C_SCHEME_FALSE);}

/* def-pds295 in make-pathname in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_fcall f_1936(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1936,NULL,3,t0,t1,t2);}
/* body292297 */
t3=((C_word*)t0)[2];
f_1927(t3,t1,t2,C_SCHEME_FALSE);}

/* body292 in make-pathname in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_fcall f_1927(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1927,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1935,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 362  canonicalize-dirs */
t5=((C_word*)t0)[3];
f_1813(t5,t4,((C_word*)t0)[2],t3);}

/* k1933 in body292 in make-pathname in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_1935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 362  _make-pathname */
t2=((C_word*)t0)[6];
f_1844(t2,((C_word*)t0)[5],lf[76],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* _make-pathname in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_fcall f_1844(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1844,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_truep(t5)?t5:lf[81]);
t8=(C_truep(t4)?t4:lf[82]);
t9=(C_truep(t6)?(C_word)C_block_size(t6):C_fix(1));
t10=(C_word)C_i_check_string_2(t3,t2);
t11=(C_word)C_i_check_string_2(t8,t2);
t12=(C_word)C_i_check_string_2(t7,t2);
t13=(C_truep(t6)?(C_word)C_i_check_string_2(t6,t2):C_SCHEME_UNDEFINED);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1873,a[2]=t7,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t15=(C_word)C_block_size(t8);
t16=(C_word)C_fixnum_greater_or_equal_p(t15,t9);
t17=(C_truep(t16)?(C_truep(t6)?(C_word)C_substring_compare(t6,t8,C_fix(0),C_fix(0),t9):(C_word)C_i_memq((C_word)C_subchar(t8,C_fix(0)),lf[85])):C_SCHEME_FALSE);
if(C_truep(t17)){
t18=(C_word)C_block_size(t8);
/* utils.scm: 352  ##sys#substring */
t19=*((C_word*)lf[74]+1);
((C_proc5)(void*)(*((C_word*)t19+1)))(5,t19,t14,t8,t9,t18);}
else{
t18=t14;
f_1873(2,t18,t8);}}

/* k1871 in _make-pathname in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_1873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1880,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t4=(C_word)C_eqp((C_word)C_subchar(((C_word*)t0)[2],C_fix(0)),C_make_character(46));
t5=t2;
f_1880(t5,(C_word)C_i_not(t4));}
else{
t4=t2;
f_1880(t4,C_SCHEME_FALSE);}}

/* k1878 in k1871 in _make-pathname in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_fcall f_1880(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[83]:lf[84]);
/* utils.scm: 346  string-append */
t3=((C_word*)t0)[6];
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* canonicalize-dirs in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_fcall f_1813(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1813,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_not(t2);
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t2));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[80]);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t6=(C_word)C_a_i_list(&a,1,t2);
/* utils.scm: 335  conc-dirs */
t7=((C_word*)t0)[2];
f_1752(t7,t1,t6,t3);}
else{
/* utils.scm: 336  conc-dirs */
t6=((C_word*)t0)[2];
f_1752(t6,t1,t2,t3);}}}

/* conc-dirs in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_fcall f_1752(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1752,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_list_2(t2,lf[76]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1761,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t6,a[6]=((C_word)li77),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_1761(t8,t1,t2);}

/* loop in conc-dirs in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_fcall f_1761(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1761,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[79]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_string_length(t3);
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
/* utils.scm: 327  loop */
t10=t1;
t11=t6;
t1=t10;
t2=t11;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1791,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_i_car(t2);
/* utils.scm: 329  chop-pds */
f_1698(t6,t7,((C_word*)t0)[4]);}}}

/* k1789 in loop in conc-dirs in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_1791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1791,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=(C_truep(t2)?t2:((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1799,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* utils.scm: 331  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1761(t6,t4,t5);}

/* k1797 in k1789 in loop in conc-dirs in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_1799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 328  string-append */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* chop-pds in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_fcall f_1698(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1698,NULL,3,t1,t2,t3);}
if(C_truep(t2)){
t4=(C_word)C_block_size(t2);
t5=(C_truep(t3)?(C_word)C_block_size(t3):C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1714,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,C_fix(1)))){
if(C_truep(t3)){
t7=(C_word)C_fixnum_difference(t4,t5);
t8=t6;
f_1714(t8,(C_word)C_substring_compare(t2,t3,t7,C_fix(0),t5));}
else{
t7=(C_word)C_fixnum_difference(t4,t5);
t8=(C_word)C_subchar(t2,t7);
t9=t6;
f_1714(t9,(C_word)C_i_memq(t8,lf[75]));}}
else{
t7=t6;
f_1714(t7,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k1712 in chop-pds in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_fcall f_1714(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* utils.scm: 311  ##sys#substring */
t3=*((C_word*)lf[74]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* absolute-pathname? in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_1685(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1685,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[72]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1696,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 300  string-match */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k1694 in absolute-pathname? in k1682 in k1679 in k532 in k529 in k526 in k523 */
static void C_ccall f_1696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_pairp(t1));}

/* file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1268(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_1268r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1268r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1268r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1270,a[2]=t3,a[3]=t2,a[4]=((C_word)li71),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1623,a[2]=t5,a[3]=((C_word)li72),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1628,a[2]=t6,a[3]=((C_word)li73),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-clobber165234 */
t8=t7;
f_1628(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-blocksize166232 */
t10=t6;
f_1623(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body163168 */
t12=t5;
f_1270(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-clobber165 in file-move in k532 in k529 in k526 in k523 */
static void C_fcall f_1628(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1628,NULL,2,t0,t1);}
/* def-blocksize166232 */
t2=((C_word*)t0)[2];
f_1623(t2,t1,C_SCHEME_FALSE);}

/* def-blocksize166 in file-move in k532 in k529 in k526 in k523 */
static void C_fcall f_1623(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1623,NULL,3,t0,t1,t2);}
/* body163168 */
t3=((C_word*)t0)[2];
f_1270(t3,t1,t2,C_fix(1024));}

/* body163 in file-move in k532 in k529 in k526 in k523 */
static void C_fcall f_1270(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1270,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[60]);
t5=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[60]);
t6=(C_word)C_i_check_number_2(t3,lf[60]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1283,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_integerp(t3))){
t8=t3;
t9=t7;
f_1283(t9,(C_word)C_fixnum_greaterp(t8,C_fix(0)));}
else{
t8=t7;
f_1283(t8,C_SCHEME_FALSE);}}

/* k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_fcall f_1283(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1283,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1286,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_1286(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1612,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1616,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 248  number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[5]);}}

/* k1614 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 246  string-append */
t2=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[67],t1);}

/* k1610 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 246  ##sys#error */
t2=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1286,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1289,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 249  file-exists? */
t3=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1292,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_1292(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1605,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 250  string-append */
t4=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[66],((C_word*)t0)[6]);}}

/* k1603 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 250  ##sys#error */
t2=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1292,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1295,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1588,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 251  file-exists? */
t4=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k1586 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1588,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_1295(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1598,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 253  string-append */
t4=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[65],((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[3];
f_1295(2,t2,C_SCHEME_FALSE);}}

/* k1596 in k1586 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 253  ##sys#error */
t2=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1298,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1530,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1532,a[2]=((C_word*)t0)[5],a[3]=((C_word)li70),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 256  call-with-current-continuation */
t5=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1531 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1532(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1532,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1538,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li65),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1563,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li69),tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 256  with-exception-handler */
t5=*((C_word*)lf[50]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a1562 in a1531 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1569,a[2]=((C_word*)t0)[3],a[3]=((C_word)li66),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1575,a[2]=((C_word*)t0)[2],a[3]=((C_word)li68),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 256  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1574 in a1562 in a1531 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1575(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1575r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1575r(t0,t1,t2);}}

static void C_ccall f_1575r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1581,a[2]=t2,a[3]=((C_word)li67),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 256  g180 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1580 in a1574 in a1562 in a1531 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1581,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1568 in a1562 in a1531 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1569,2,t0,t1);}
/* utils.scm: 256  open-input-file */
t2=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a1537 in a1531 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1538(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1538,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1544,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li64),tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 256  g180 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1543 in a1537 in a1531 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1544,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[3],lf[46]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1555,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 258  string-append */
t5=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[64],((C_word*)t0)[2]);}

/* k1553 in a1543 in a1537 in a1531 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 258  ##sys#error */
t2=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1528 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1301,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1472,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1474,a[2]=((C_word*)t0)[2],a[3]=((C_word)li63),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 261  call-with-current-continuation */
t5=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1473 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1474(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1474,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1480,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li58),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1505,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li62),tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 261  with-exception-handler */
t5=*((C_word*)lf[50]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a1504 in a1473 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1511,a[2]=((C_word*)t0)[3],a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1517,a[2]=((C_word*)t0)[2],a[3]=((C_word)li61),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 261  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1516 in a1504 in a1473 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1517(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1517r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1517r(t0,t1,t2);}}

static void C_ccall f_1517r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1523,a[2]=t2,a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 261  g190 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1522 in a1516 in a1504 in a1473 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1523,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1510 in a1504 in a1473 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1511,2,t0,t1);}
/* utils.scm: 261  open-output-file */
t2=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a1479 in a1473 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1480(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1480,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1486,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li57),tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 261  g190 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1485 in a1479 in a1473 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1486,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[3],lf[46]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1497,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 263  string-append */
t5=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[63],((C_word*)t0)[2]);}

/* k1495 in a1485 in a1479 in a1473 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 263  ##sys#error */
t2=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1470 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1304,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 266  make-string */
t3=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1311,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* utils.scm: 267  read-string! */
t3=*((C_word*)lf[45]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* k1309 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1311,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1313,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li56),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_1313(t5,((C_word*)t0)[2],t1,C_fix(0));}

/* loop in k1309 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_fcall f_1313(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1313,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1323,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 271  close-input-port */
t7=*((C_word*)lf[44]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[5]);}
else{
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1390,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1404,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1406,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word)li55),tmp=(C_word)a,a+=8,tmp);
/* utils.scm: 280  call-with-current-continuation */
t9=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}}

/* a1405 in loop in k1309 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1406(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1406,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1412,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word)li50),tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1447,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word)li54),tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 280  with-exception-handler */
t5=*((C_word*)lf[50]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a1446 in a1405 in loop in k1309 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1453,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li51),tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1459,a[2]=((C_word*)t0)[2],a[3]=((C_word)li53),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 280  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1458 in a1446 in a1405 in loop in k1309 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1459(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1459r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1459r(t0,t1,t2);}}

static void C_ccall f_1459r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1465,a[2]=t2,a[3]=((C_word)li52),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 280  g215 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1464 in a1458 in a1446 in a1405 in loop in k1309 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1465,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1452 in a1446 in a1405 in loop in k1309 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1453,2,t0,t1);}
/* utils.scm: 280  write-string */
t2=*((C_word*)lf[49]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1411 in a1405 in loop in k1309 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1412(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1412,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1418,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word)li49),tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 280  g215 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1417 in a1411 in a1405 in loop in k1309 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1418,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[5],lf[46]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1425,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 282  close-input-port */
t5=*((C_word*)lf[44]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k1423 in a1417 in a1411 in a1405 in loop in k1309 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1428,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 283  close-output-port */
t3=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1426 in k1423 in a1417 in a1411 in a1405 in loop in k1309 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1435,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1439,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 286  number->string */
C_number_to_string(3,0,t3,((C_word*)t0)[2]);}

/* k1437 in k1426 in k1423 in a1417 in a1411 in a1405 in loop in k1309 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 284  string-append */
t2=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[62],t1);}

/* k1433 in k1426 in k1423 in a1417 in a1411 in a1405 in loop in k1309 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 284  ##sys#error */
t2=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1402 in loop in k1309 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1388 in loop in k1309 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1397,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 287  read-string! */
t3=*((C_word*)lf[45]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1395 in k1388 in loop in k1309 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* utils.scm: 287  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1313(t3,((C_word*)t0)[2],t1,t2);}

/* k1321 in loop in k1309 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1326,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 272  close-output-port */
t3=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1324 in k1321 in loop in k1309 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1329,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1332,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1334,a[2]=((C_word*)t0)[2],a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 273  call-with-current-continuation */
t5=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1333 in k1324 in k1321 in loop in k1309 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1334(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1334,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1340,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li43),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1365,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 273  with-exception-handler */
t5=*((C_word*)lf[50]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a1364 in a1333 in k1324 in k1321 in loop in k1309 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1371,a[2]=((C_word*)t0)[3],a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1377,a[2]=((C_word*)t0)[2],a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 273  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1376 in a1364 in a1333 in k1324 in k1321 in loop in k1309 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1377(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1377r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1377r(t0,t1,t2);}}

static void C_ccall f_1377r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1383,a[2]=t2,a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 273  g203 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1382 in a1376 in a1364 in a1333 in k1324 in k1321 in loop in k1309 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1383,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1370 in a1364 in a1333 in k1324 in k1321 in loop in k1309 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1371,2,t0,t1);}
/* utils.scm: 273  delete-file */
t2=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a1339 in a1333 in k1324 in k1321 in loop in k1309 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1340(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1340,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1346,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li42),tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 273  g203 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1345 in a1339 in a1333 in k1324 in k1321 in loop in k1309 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1346,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[3],lf[46]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1357,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 275  string-append */
t5=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[61],((C_word*)t0)[2]);}

/* k1355 in a1345 in a1339 in a1333 in k1324 in k1321 in loop in k1309 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 275  ##sys#error */
t2=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1330 in k1324 in k1321 in loop in k1309 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1327 in k1324 in k1321 in loop in k1309 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1281 in body163 in file-move in k532 in k529 in k526 in k523 */
static void C_ccall f_1329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_921(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_921r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_921r(t0,t1,t2,t3,t4);}}

static void C_ccall f_921r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_923,a[2]=t3,a[3]=t2,a[4]=((C_word)li38),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1215,a[2]=t5,a[3]=((C_word)li39),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1220,a[2]=t6,a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-clobber93152 */
t8=t7;
f_1220(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-blocksize94150 */
t10=t6;
f_1215(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body9196 */
t12=t5;
f_923(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-clobber93 in file-copy in k532 in k529 in k526 in k523 */
static void C_fcall f_1220(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1220,NULL,2,t0,t1);}
/* def-blocksize94150 */
t2=((C_word*)t0)[2];
f_1215(t2,t1,C_SCHEME_FALSE);}

/* def-blocksize94 in file-copy in k532 in k529 in k526 in k523 */
static void C_fcall f_1215(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1215,NULL,3,t0,t1,t2);}
/* body9196 */
t3=((C_word*)t0)[2];
f_923(t3,t1,t2,C_fix(1024));}

/* body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_fcall f_923(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_923,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[42]);
t5=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[42]);
t6=(C_word)C_i_check_number_2(t3,lf[42]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_936,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_integerp(t3))){
t8=t3;
t9=t7;
f_936(t9,(C_word)C_fixnum_greaterp(t8,C_fix(0)));}
else{
t8=t7;
f_936(t8,C_SCHEME_FALSE);}}

/* k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_fcall f_936(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_936,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_939(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1204,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1208,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 205  number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[6]);}}

/* k1206 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 203  string-append */
t2=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[59],t1);}

/* k1202 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 203  ##sys#error */
t2=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_942,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 206  file-exists? */
t3=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_945(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1197,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 207  string-append */
t4=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[58],((C_word*)t0)[3]);}}

/* k1195 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 207  ##sys#error */
t2=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_948,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1180,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 208  file-exists? */
t4=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k1178 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1180,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_948(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1190,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 210  string-append */
t4=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[57],((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[3];
f_948(2,t2,C_SCHEME_FALSE);}}

/* k1188 in k1178 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 210  ##sys#error */
t2=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_951,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1122,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1124,a[2]=((C_word*)t0)[2],a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 213  call-with-current-continuation */
t5=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1123 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1124(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1124,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1130,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li32),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1155,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li36),tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 213  with-exception-handler */
t5=*((C_word*)lf[50]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a1154 in a1123 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1161,a[2]=((C_word*)t0)[3],a[3]=((C_word)li33),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1167,a[2]=((C_word*)t0)[2],a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 213  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1166 in a1154 in a1123 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1167(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1167r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1167r(t0,t1,t2);}}

static void C_ccall f_1167r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1173,a[2]=t2,a[3]=((C_word)li34),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 213  g108 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1172 in a1166 in a1154 in a1123 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1173,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1160 in a1154 in a1123 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1161,2,t0,t1);}
/* utils.scm: 213  open-input-file */
t2=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a1129 in a1123 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1130(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1130,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1136,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li31),tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 213  g108 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1135 in a1129 in a1123 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1136,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[3],lf[46]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1147,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 215  string-append */
t5=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[55],((C_word*)t0)[2]);}

/* k1145 in a1135 in a1129 in a1123 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 215  ##sys#error */
t2=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1120 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_954,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1064,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1066,a[2]=((C_word*)t0)[2],a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 218  call-with-current-continuation */
t5=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1065 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1066(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1066,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1072,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li25),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1097,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li29),tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 218  with-exception-handler */
t5=*((C_word*)lf[50]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a1096 in a1065 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1097,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1103,a[2]=((C_word*)t0)[3],a[3]=((C_word)li26),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1109,a[2]=((C_word*)t0)[2],a[3]=((C_word)li28),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 218  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1108 in a1096 in a1065 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1109(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1109r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1109r(t0,t1,t2);}}

static void C_ccall f_1109r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1115,a[2]=t2,a[3]=((C_word)li27),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 218  g118 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1114 in a1108 in a1096 in a1065 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1115,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1102 in a1096 in a1065 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1103,2,t0,t1);}
/* utils.scm: 218  open-output-file */
t2=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a1071 in a1065 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1072(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1072,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1078,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li24),tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 218  g118 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1077 in a1071 in a1065 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1078,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[3],lf[46]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1089,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 220  string-append */
t5=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[53],((C_word*)t0)[2]);}

/* k1087 in a1077 in a1071 in a1065 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 220  ##sys#error */
t2=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1062 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k952 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_957,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 223  make-string */
t3=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_964,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 224  read-string! */
t3=*((C_word*)lf[45]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* k962 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_964,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_966,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li23),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_966(t5,((C_word*)t0)[2],t1,C_fix(0));}

/* loop in k962 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_fcall f_966(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_966,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_976,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 228  close-input-port */
t7=*((C_word*)lf[44]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[5]);}
else{
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_982,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_996,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_998,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word)li22),tmp=(C_word)a,a+=8,tmp);
/* utils.scm: 232  call-with-current-continuation */
t9=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}}

/* a997 in loop in k962 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_998(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_998,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1004,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word)li17),tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1039,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word)li21),tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 232  with-exception-handler */
t5=*((C_word*)lf[50]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a1038 in a997 in loop in k962 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1039,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1045,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li18),tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1051,a[2]=((C_word*)t0)[2],a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 232  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1050 in a1038 in a997 in loop in k962 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1051(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1051r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1051r(t0,t1,t2);}}

static void C_ccall f_1051r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1057,a[2]=t2,a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 232  g133 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1056 in a1050 in a1038 in a997 in loop in k962 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1057,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1044 in a1038 in a997 in loop in k962 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1045,2,t0,t1);}
/* utils.scm: 232  write-string */
t2=*((C_word*)lf[49]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1003 in a997 in loop in k962 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1004(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1004,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1010,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word)li16),tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 232  g133 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1009 in a1003 in a997 in loop in k962 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1010,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[5],lf[46]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1017,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 234  close-input-port */
t5=*((C_word*)lf[44]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k1015 in a1009 in a1003 in a997 in loop in k962 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1020,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 235  close-output-port */
t3=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1018 in k1015 in a1009 in a1003 in a997 in loop in k962 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1027,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1031,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 238  number->string */
C_number_to_string(3,0,t3,((C_word*)t0)[2]);}

/* k1029 in k1018 in k1015 in a1009 in a1003 in a997 in loop in k962 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 236  string-append */
t2=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[48],t1);}

/* k1025 in k1018 in k1015 in a1009 in a1003 in a997 in loop in k962 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_1027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 236  ##sys#error */
t2=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k994 in loop in k962 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k980 in loop in k962 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_989,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 239  read-string! */
t3=*((C_word*)lf[45]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k987 in k980 in loop in k962 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* utils.scm: 239  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_966(t3,((C_word*)t0)[2],t1,t2);}

/* k974 in loop in k962 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_979,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 229  close-output-port */
t3=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k977 in k974 in loop in k962 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in body91 in file-copy in k532 in k529 in k526 in k523 */
static void C_ccall f_979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* delete-file* in k532 in k529 in k526 in k523 */
static void C_ccall f_906(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_906,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_913,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 195  file-exists? */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k911 in delete-file* in k532 in k529 in k526 in k523 */
static void C_ccall f_913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_913,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_919,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 195  delete-file */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k917 in k911 in delete-file* in k532 in k529 in k526 in k523 */
static void C_ccall f_919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* system* in k532 in k529 in k526 in k523 */
static void C_ccall f_888(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_888r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_888r(t0,t1,t2,t3);}}

static void C_ccall f_888r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_892,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,((C_word*)t0)[2],t2,t3);}

/* k890 in system* in k532 in k529 in k526 in k523 */
static void C_ccall f_892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_895,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 184  system */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k893 in k890 in system* in k532 in k529 in k526 in k523 */
static void C_ccall f_895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* utils.scm: 186  ##sys#error */
t3=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[38],((C_word*)t0)[2],t1);}}

/* apropos in k532 in k529 in k526 in k523 */
static void C_ccall f_796(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_796r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_796r(t0,t1,t2,t3);}}

static void C_ccall f_796r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_800,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 152  %apropos-list */
f_668(t4,lf[17],t2,t3);}

/* k798 in apropos in k532 in k529 in k526 in k523 */
static void C_ccall f_800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_800,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_803,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_877,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li12),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t6=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t1);}

/* a876 in k798 in apropos in k532 in k529 in k526 in k523 */
static void C_ccall f_877(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_877,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_886,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 156  symlen */
f_771(t3,t2);}

/* k884 in a876 in k798 in apropos in k532 in k529 in k526 in k523 */
static void C_ccall f_886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k801 in k798 in apropos in k532 in k529 in k526 in k523 */
static void C_ccall f_803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_808,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word)li11),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t3=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a807 in k801 in k798 in apropos in k532 in k529 in k526 in k523 */
static void C_ccall f_808(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_808,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_812,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 160  display */
t4=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k810 in a807 in k801 in k798 in apropos in k532 in k529 in k526 in k523 */
static void C_ccall f_812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_812,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_815,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_875,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 161  symlen */
f_771(t3,((C_word*)t0)[4]);}

/* k873 in k810 in a807 in k801 in k798 in apropos in k532 in k529 in k526 in k523 */
static void C_ccall f_875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_875,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[3])[1],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_854,a[2]=t4,a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_854(t6,((C_word*)t0)[2],t2);}

/* do62 in k873 in k810 in a807 in k801 in k798 in apropos in k532 in k529 in k526 in k523 */
static void C_fcall f_854(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_854,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_864,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 163  display */
t4=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_make_character(32));}}

/* k862 in do62 in k873 in k810 in a807 in k801 in k798 in apropos in k532 in k529 in k526 in k523 */
static void C_ccall f_864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_854(t3,((C_word*)t0)[2],t2);}

/* k813 in k810 in a807 in k801 in k798 in apropos in k532 in k529 in k526 in k523 */
static void C_ccall f_815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 164  display */
t3=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(32));}

/* k816 in k813 in k810 in a807 in k801 in k798 in apropos in k532 in k529 in k526 in k523 */
static void C_ccall f_818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_821,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 164  display */
t3=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(58));}

/* k819 in k816 in k813 in k810 in a807 in k801 in k798 in apropos in k532 in k529 in k526 in k523 */
static void C_ccall f_821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 164  display */
t3=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(32));}

/* k822 in k819 in k816 in k813 in k810 in a807 in k801 in k798 in apropos in k532 in k529 in k526 in k523 */
static void C_ccall f_824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_827,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_833,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 165  macro? */
t4=*((C_word*)lf[33]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k831 in k822 in k819 in k816 in k813 in k810 in a807 in k801 in k798 in apropos in k532 in k529 in k526 in k523 */
static void C_ccall f_833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_833,2,t0,t1);}
if(C_truep(t1)){
/* utils.scm: 167  display */
t2=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],lf[29]);}
else{
t2=(C_word)C_retrieve(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_744,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 135  procedure-information */
t4=*((C_word*)lf[31]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
/* utils.scm: 172  display */
t3=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],lf[32]);}}}

/* k742 in k831 in k822 in k819 in k816 in k813 in k810 in a807 in k801 in k798 in apropos in k532 in k529 in k526 in k523 */
static void C_ccall f_744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_744,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_cdr(t1);
t3=(C_word)C_a_i_cons(&a,2,lf[30],t2);
/* utils.scm: 136  display */
t4=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}
else{
if(C_truep(t1)){
/* utils.scm: 137  display */
t2=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[30]);}
else{
/* utils.scm: 138  display */
t2=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[30]);}}}

/* k825 in k822 in k819 in k816 in k813 in k810 in a807 in k801 in k798 in apropos in k532 in k529 in k526 in k523 */
static void C_ccall f_827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 173  newline */
t2=*((C_word*)lf[27]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* apropos-list in k532 in k529 in k526 in k523 */
static void C_ccall f_790(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_790r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_790r(t0,t1,t2,t3);}}

static void C_ccall f_790r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* utils.scm: 148  %apropos-list */
f_668(t1,lf[16],t2,t3);}

/* symlen in k532 in k529 in k526 in k523 */
static void C_fcall f_771(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_771,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_788,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 141  ##sys#symbol->qualified-string */
t4=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k786 in symlen in k532 in k529 in k526 in k523 */
static void C_ccall f_788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_788,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_781,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 142  keyword? */
t4=*((C_word*)lf[25]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k779 in k786 in symlen in k532 in k529 in k526 in k523 */
static void C_ccall f_781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_fixnum_difference(((C_word*)t0)[2],C_fix(2)):((C_word*)t0)[2]));}

/* %apropos-list in k532 in k529 in k526 in k523 */
static void C_fcall f_668(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_668,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_672,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 116  interaction-environment */
t6=*((C_word*)lf[24]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k670 in %apropos-list in k532 in k529 in k526 in k523 */
static void C_ccall f_672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_672,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_704,a[2]=t3,a[3]=t5,a[4]=((C_word)li6),tmp=(C_word)a,a+=5,tmp);
t7=f_704(t6,((C_word*)t0)[5]);
t8=(C_word)C_i_check_structure_2(((C_word*)t3)[1],lf[19],((C_word*)t0)[4]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_681,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t10=(C_word)C_i_stringp(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t10)){
t12=t11;
f_690(2,t12,t10);}
else{
t12=(C_word)C_i_symbolp(((C_word*)t0)[2]);
if(C_truep(t12)){
t13=t11;
f_690(2,t13,t12);}
else{
/* utils.scm: 130  regexp? */
t13=*((C_word*)lf[23]+1);
((C_proc3)C_retrieve_proc(t13))(3,t13,t11,((C_word*)t0)[2]);}}}

/* k688 in k670 in %apropos-list in k532 in k529 in k526 in k523 */
static void C_ccall f_690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_681(2,t2,C_SCHEME_UNDEFINED);}
else{
/* utils.scm: 131  ##sys#signal-hook */
t2=*((C_word*)lf[20]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[21],((C_word*)t0)[3],lf[22],((C_word*)t0)[2]);}}

/* k679 in k670 in %apropos-list in k532 in k529 in k526 in k523 */
static void C_ccall f_681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 132  ##sys#apropos */
t2=*((C_word*)lf[13]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* loop in k670 in %apropos-list in k532 in k529 in k526 in k523 */
static C_word C_fcall f_704(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
C_stack_check;
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_eqp(lf[18],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cadr(t1);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=(C_word)C_i_cddr(t1);
t10=t6;
t1=t10;
goto loop;}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=(C_word)C_i_cdr(t1);
t10=t5;
t1=t10;
goto loop;}}
else{
return(C_SCHEME_UNDEFINED);}}

/* ##sys#apropos in k532 in k529 in k526 in k523 */
static void C_ccall f_623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_623r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_623r(t0,t1,t2,t3,t4);}}

static void C_ccall f_623r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_627,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_627(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_627(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k625 in ##sys#apropos in k532 in k529 in k526 in k523 */
static void C_ccall f_627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_627,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_630,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 107  ##sys#apropos-interned */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k628 in k625 in ##sys#apropos in k532 in k529 in k526 in k523 */
static void C_ccall f_630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_630,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_640,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 109  ##sys#apropos-macros */
t3=*((C_word*)lf[4]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* k638 in k628 in k625 in ##sys#apropos in k532 in k529 in k526 in k523 */
static void C_ccall f_640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 109  ##sys#append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#apropos-macros in k532 in k529 in k526 in k523 */
static void C_ccall f_596(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_596,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_601,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 97   makpat */
t6=((C_word*)t0)[2];
f_543(t6,t5,((C_word*)t4)[1]);}

/* k599 in ##sys#apropos-macros in k532 in k529 in k526 in k523 */
static void C_ccall f_601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_601,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_604,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_606,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word)li3),tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 99   ##sys#hash-table-for-each */
t7=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,*((C_word*)lf[12]+1));}

/* a605 in k599 in ##sys#apropos-macros in k532 in k529 in k526 in k523 */
static void C_ccall f_606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_606,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_613,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_621,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 101  symbol->string */
t6=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k619 in a605 in k599 in ##sys#apropos-macros in k532 in k529 in k526 in k523 */
static void C_ccall f_621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 101  string-search */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k611 in a605 in k599 in ##sys#apropos-macros in k532 in k529 in k526 in k523 */
static void C_ccall f_613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_613,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k602 in k599 in ##sys#apropos-macros in k532 in k529 in k526 in k523 */
static void C_ccall f_604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##sys#apropos-interned in k532 in k529 in k526 in k523 */
static void C_ccall f_570(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_570,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_575,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 89   makpat */
t6=((C_word*)t0)[2];
f_543(t6,t5,((C_word*)t4)[1]);}

/* k573 in ##sys#apropos-interned in k532 in k529 in k526 in k523 */
static void C_ccall f_575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_575,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_580,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word)li1),tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 90   ##sys#environment-symbols */
t4=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a579 in k573 in ##sys#apropos-interned in k532 in k529 in k526 in k523 */
static void C_ccall f_580(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_580,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_587,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_594,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 92   symbol->string */
t5=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k592 in a579 in k573 in ##sys#apropos-interned in k532 in k529 in k526 in k523 */
static void C_ccall f_594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 92   string-search */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k585 in a579 in k573 in ##sys#apropos-interned in k532 in k529 in k526 in k523 */
static void C_ccall f_587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* utils.scm: 93   ##sys#symbol-has-toplevel-binding? */
t2=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* makpat in k532 in k529 in k526 in k523 */
static void C_fcall f_543(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_543,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_547,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t3)[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_568,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 82   symbol->string */
t6=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t3)[1]);}
else{
t5=t4;
f_547(t5,C_SCHEME_UNDEFINED);}}

/* k566 in makpat in k532 in k529 in k526 in k523 */
static void C_ccall f_568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_547(t3,t2);}

/* k545 in makpat in k532 in k529 in k526 in k523 */
static void C_fcall f_547(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_547,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_550,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[4])[1]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_557,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_561,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 84   regexp-escape */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t2;
f_550(t3,C_SCHEME_UNDEFINED);}}

/* k559 in k545 in makpat in k532 in k529 in k526 in k523 */
static void C_ccall f_561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 84   regexp */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k555 in k545 in makpat in k532 in k529 in k526 in k523 */
static void C_ccall f_557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_550(t3,t2);}

/* k548 in k545 in makpat in k532 in k529 in k526 in k523 */
static void C_fcall f_550(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[261] = {
{"toplevelutils.scm",(void*)C_utils_toplevel},
{"f_525utils.scm",(void*)f_525},
{"f_528utils.scm",(void*)f_528},
{"f_531utils.scm",(void*)f_531},
{"f_534utils.scm",(void*)f_534},
{"f_2565utils.scm",(void*)f_2565},
{"f_1681utils.scm",(void*)f_1681},
{"f_1684utils.scm",(void*)f_1684},
{"f_2068utils.scm",(void*)f_2068},
{"f_2071utils.scm",(void*)f_2071},
{"f_2520utils.scm",(void*)f_2520},
{"f_2524utils.scm",(void*)f_2524},
{"f_2530utils.scm",(void*)f_2530},
{"f_2538utils.scm",(void*)f_2538},
{"f_2475utils.scm",(void*)f_2475},
{"f_2500utils.scm",(void*)f_2500},
{"f_2514utils.scm",(void*)f_2514},
{"f_2493utils.scm",(void*)f_2493},
{"f_2439utils.scm",(void*)f_2439},
{"f_2446utils.scm",(void*)f_2446},
{"f_2451utils.scm",(void*)f_2451},
{"f_2455utils.scm",(void*)f_2455},
{"f_2464utils.scm",(void*)f_2464},
{"f_2394utils.scm",(void*)f_2394},
{"f_2402utils.scm",(void*)f_2402},
{"f_2404utils.scm",(void*)f_2404},
{"f_2329utils.scm",(void*)f_2329},
{"f_2333utils.scm",(void*)f_2333},
{"f_2386utils.scm",(void*)f_2386},
{"f_2336utils.scm",(void*)f_2336},
{"f_2347utils.scm",(void*)f_2347},
{"f_2377utils.scm",(void*)f_2377},
{"f_2373utils.scm",(void*)f_2373},
{"f_2354utils.scm",(void*)f_2354},
{"f_2360utils.scm",(void*)f_2360},
{"f_2368utils.scm",(void*)f_2368},
{"f_2311utils.scm",(void*)f_2311},
{"f_2323utils.scm",(void*)f_2323},
{"f_2317utils.scm",(void*)f_2317},
{"f_2293utils.scm",(void*)f_2293},
{"f_2305utils.scm",(void*)f_2305},
{"f_2299utils.scm",(void*)f_2299},
{"f_2275utils.scm",(void*)f_2275},
{"f_2287utils.scm",(void*)f_2287},
{"f_2281utils.scm",(void*)f_2281},
{"f_2257utils.scm",(void*)f_2257},
{"f_2269utils.scm",(void*)f_2269},
{"f_2263utils.scm",(void*)f_2263},
{"f_2239utils.scm",(void*)f_2239},
{"f_2251utils.scm",(void*)f_2251},
{"f_2245utils.scm",(void*)f_2245},
{"f_2224utils.scm",(void*)f_2224},
{"f_2236utils.scm",(void*)f_2236},
{"f_2230utils.scm",(void*)f_2230},
{"f_2209utils.scm",(void*)f_2209},
{"f_2221utils.scm",(void*)f_2221},
{"f_2215utils.scm",(void*)f_2215},
{"f_2194utils.scm",(void*)f_2194},
{"f_2206utils.scm",(void*)f_2206},
{"f_2200utils.scm",(void*)f_2200},
{"f_2086utils.scm",(void*)f_2086},
{"f_2102utils.scm",(void*)f_2102},
{"f_2131utils.scm",(void*)f_2131},
{"f_2156utils.scm",(void*)f_2156},
{"f_2141utils.scm",(void*)f_2141},
{"f_2112utils.scm",(void*)f_2112},
{"f_2072utils.scm",(void*)f_2072},
{"f_1989utils.scm",(void*)f_1989},
{"f_2018utils.scm",(void*)f_2018},
{"f_2013utils.scm",(void*)f_2013},
{"f_1991utils.scm",(void*)f_1991},
{"f_1999utils.scm",(void*)f_1999},
{"f_2005utils.scm",(void*)f_2005},
{"f_2002utils.scm",(void*)f_2002},
{"f_1925utils.scm",(void*)f_1925},
{"f_1941utils.scm",(void*)f_1941},
{"f_1936utils.scm",(void*)f_1936},
{"f_1927utils.scm",(void*)f_1927},
{"f_1935utils.scm",(void*)f_1935},
{"f_1844utils.scm",(void*)f_1844},
{"f_1873utils.scm",(void*)f_1873},
{"f_1880utils.scm",(void*)f_1880},
{"f_1813utils.scm",(void*)f_1813},
{"f_1752utils.scm",(void*)f_1752},
{"f_1761utils.scm",(void*)f_1761},
{"f_1791utils.scm",(void*)f_1791},
{"f_1799utils.scm",(void*)f_1799},
{"f_1698utils.scm",(void*)f_1698},
{"f_1714utils.scm",(void*)f_1714},
{"f_1685utils.scm",(void*)f_1685},
{"f_1696utils.scm",(void*)f_1696},
{"f_1268utils.scm",(void*)f_1268},
{"f_1628utils.scm",(void*)f_1628},
{"f_1623utils.scm",(void*)f_1623},
{"f_1270utils.scm",(void*)f_1270},
{"f_1283utils.scm",(void*)f_1283},
{"f_1616utils.scm",(void*)f_1616},
{"f_1612utils.scm",(void*)f_1612},
{"f_1286utils.scm",(void*)f_1286},
{"f_1289utils.scm",(void*)f_1289},
{"f_1605utils.scm",(void*)f_1605},
{"f_1292utils.scm",(void*)f_1292},
{"f_1588utils.scm",(void*)f_1588},
{"f_1598utils.scm",(void*)f_1598},
{"f_1295utils.scm",(void*)f_1295},
{"f_1532utils.scm",(void*)f_1532},
{"f_1563utils.scm",(void*)f_1563},
{"f_1575utils.scm",(void*)f_1575},
{"f_1581utils.scm",(void*)f_1581},
{"f_1569utils.scm",(void*)f_1569},
{"f_1538utils.scm",(void*)f_1538},
{"f_1544utils.scm",(void*)f_1544},
{"f_1555utils.scm",(void*)f_1555},
{"f_1530utils.scm",(void*)f_1530},
{"f_1298utils.scm",(void*)f_1298},
{"f_1474utils.scm",(void*)f_1474},
{"f_1505utils.scm",(void*)f_1505},
{"f_1517utils.scm",(void*)f_1517},
{"f_1523utils.scm",(void*)f_1523},
{"f_1511utils.scm",(void*)f_1511},
{"f_1480utils.scm",(void*)f_1480},
{"f_1486utils.scm",(void*)f_1486},
{"f_1497utils.scm",(void*)f_1497},
{"f_1472utils.scm",(void*)f_1472},
{"f_1301utils.scm",(void*)f_1301},
{"f_1304utils.scm",(void*)f_1304},
{"f_1311utils.scm",(void*)f_1311},
{"f_1313utils.scm",(void*)f_1313},
{"f_1406utils.scm",(void*)f_1406},
{"f_1447utils.scm",(void*)f_1447},
{"f_1459utils.scm",(void*)f_1459},
{"f_1465utils.scm",(void*)f_1465},
{"f_1453utils.scm",(void*)f_1453},
{"f_1412utils.scm",(void*)f_1412},
{"f_1418utils.scm",(void*)f_1418},
{"f_1425utils.scm",(void*)f_1425},
{"f_1428utils.scm",(void*)f_1428},
{"f_1439utils.scm",(void*)f_1439},
{"f_1435utils.scm",(void*)f_1435},
{"f_1404utils.scm",(void*)f_1404},
{"f_1390utils.scm",(void*)f_1390},
{"f_1397utils.scm",(void*)f_1397},
{"f_1323utils.scm",(void*)f_1323},
{"f_1326utils.scm",(void*)f_1326},
{"f_1334utils.scm",(void*)f_1334},
{"f_1365utils.scm",(void*)f_1365},
{"f_1377utils.scm",(void*)f_1377},
{"f_1383utils.scm",(void*)f_1383},
{"f_1371utils.scm",(void*)f_1371},
{"f_1340utils.scm",(void*)f_1340},
{"f_1346utils.scm",(void*)f_1346},
{"f_1357utils.scm",(void*)f_1357},
{"f_1332utils.scm",(void*)f_1332},
{"f_1329utils.scm",(void*)f_1329},
{"f_921utils.scm",(void*)f_921},
{"f_1220utils.scm",(void*)f_1220},
{"f_1215utils.scm",(void*)f_1215},
{"f_923utils.scm",(void*)f_923},
{"f_936utils.scm",(void*)f_936},
{"f_1208utils.scm",(void*)f_1208},
{"f_1204utils.scm",(void*)f_1204},
{"f_939utils.scm",(void*)f_939},
{"f_942utils.scm",(void*)f_942},
{"f_1197utils.scm",(void*)f_1197},
{"f_945utils.scm",(void*)f_945},
{"f_1180utils.scm",(void*)f_1180},
{"f_1190utils.scm",(void*)f_1190},
{"f_948utils.scm",(void*)f_948},
{"f_1124utils.scm",(void*)f_1124},
{"f_1155utils.scm",(void*)f_1155},
{"f_1167utils.scm",(void*)f_1167},
{"f_1173utils.scm",(void*)f_1173},
{"f_1161utils.scm",(void*)f_1161},
{"f_1130utils.scm",(void*)f_1130},
{"f_1136utils.scm",(void*)f_1136},
{"f_1147utils.scm",(void*)f_1147},
{"f_1122utils.scm",(void*)f_1122},
{"f_951utils.scm",(void*)f_951},
{"f_1066utils.scm",(void*)f_1066},
{"f_1097utils.scm",(void*)f_1097},
{"f_1109utils.scm",(void*)f_1109},
{"f_1115utils.scm",(void*)f_1115},
{"f_1103utils.scm",(void*)f_1103},
{"f_1072utils.scm",(void*)f_1072},
{"f_1078utils.scm",(void*)f_1078},
{"f_1089utils.scm",(void*)f_1089},
{"f_1064utils.scm",(void*)f_1064},
{"f_954utils.scm",(void*)f_954},
{"f_957utils.scm",(void*)f_957},
{"f_964utils.scm",(void*)f_964},
{"f_966utils.scm",(void*)f_966},
{"f_998utils.scm",(void*)f_998},
{"f_1039utils.scm",(void*)f_1039},
{"f_1051utils.scm",(void*)f_1051},
{"f_1057utils.scm",(void*)f_1057},
{"f_1045utils.scm",(void*)f_1045},
{"f_1004utils.scm",(void*)f_1004},
{"f_1010utils.scm",(void*)f_1010},
{"f_1017utils.scm",(void*)f_1017},
{"f_1020utils.scm",(void*)f_1020},
{"f_1031utils.scm",(void*)f_1031},
{"f_1027utils.scm",(void*)f_1027},
{"f_996utils.scm",(void*)f_996},
{"f_982utils.scm",(void*)f_982},
{"f_989utils.scm",(void*)f_989},
{"f_976utils.scm",(void*)f_976},
{"f_979utils.scm",(void*)f_979},
{"f_906utils.scm",(void*)f_906},
{"f_913utils.scm",(void*)f_913},
{"f_919utils.scm",(void*)f_919},
{"f_888utils.scm",(void*)f_888},
{"f_892utils.scm",(void*)f_892},
{"f_895utils.scm",(void*)f_895},
{"f_796utils.scm",(void*)f_796},
{"f_800utils.scm",(void*)f_800},
{"f_877utils.scm",(void*)f_877},
{"f_886utils.scm",(void*)f_886},
{"f_803utils.scm",(void*)f_803},
{"f_808utils.scm",(void*)f_808},
{"f_812utils.scm",(void*)f_812},
{"f_875utils.scm",(void*)f_875},
{"f_854utils.scm",(void*)f_854},
{"f_864utils.scm",(void*)f_864},
{"f_815utils.scm",(void*)f_815},
{"f_818utils.scm",(void*)f_818},
{"f_821utils.scm",(void*)f_821},
{"f_824utils.scm",(void*)f_824},
{"f_833utils.scm",(void*)f_833},
{"f_744utils.scm",(void*)f_744},
{"f_827utils.scm",(void*)f_827},
{"f_790utils.scm",(void*)f_790},
{"f_771utils.scm",(void*)f_771},
{"f_788utils.scm",(void*)f_788},
{"f_781utils.scm",(void*)f_781},
{"f_668utils.scm",(void*)f_668},
{"f_672utils.scm",(void*)f_672},
{"f_690utils.scm",(void*)f_690},
{"f_681utils.scm",(void*)f_681},
{"f_704utils.scm",(void*)f_704},
{"f_623utils.scm",(void*)f_623},
{"f_627utils.scm",(void*)f_627},
{"f_630utils.scm",(void*)f_630},
{"f_640utils.scm",(void*)f_640},
{"f_596utils.scm",(void*)f_596},
{"f_601utils.scm",(void*)f_601},
{"f_606utils.scm",(void*)f_606},
{"f_621utils.scm",(void*)f_621},
{"f_613utils.scm",(void*)f_613},
{"f_604utils.scm",(void*)f_604},
{"f_570utils.scm",(void*)f_570},
{"f_575utils.scm",(void*)f_575},
{"f_580utils.scm",(void*)f_580},
{"f_594utils.scm",(void*)f_594},
{"f_587utils.scm",(void*)f_587},
{"f_543utils.scm",(void*)f_543},
{"f_568utils.scm",(void*)f_568},
{"f_547utils.scm",(void*)f_547},
{"f_561utils.scm",(void*)f_561},
{"f_557utils.scm",(void*)f_557},
{"f_550utils.scm",(void*)f_550},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
