/* Generated from utils.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-01-07 10:48
   Version 4.0.0x5 - SVN rev. 12936
   linux-unix-gnu-x86 [ dload ptables applyhook ]
   compiled 2009-01-05 on dill (Linux)
   command line: utils.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -output-file utils.c
   unit: utils
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[62];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,15),40,109,97,107,112,97,116,32,112,97,116,116,50,55,41,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,12),40,97,51,55,56,32,115,121,109,51,57,41,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,37),40,35,35,115,121,115,35,97,112,114,111,112,111,115,45,105,110,116,101,114,110,101,100,32,112,97,116,116,51,54,32,101,110,118,51,55,41,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,10),40,97,52,48,52,32,97,52,57,41,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,97,112,114,111,112,111,115,45,109,97,99,114,111,115,32,112,97,116,116,52,52,32,101,110,118,52,53,41,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,97,112,114,111,112,111,115,32,112,97,116,116,54,54,32,101,110,118,54,55,32,46,32,116,109,112,54,53,54,56,41,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,35),40,37,97,112,114,111,112,111,115,45,108,105,115,116,32,108,111,99,56,57,32,112,97,116,116,57,48,32,97,114,103,115,57,49,41,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,15),40,115,121,109,108,101,110,32,115,121,109,49,51,55,41,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,32),40,97,112,114,111,112,111,115,45,108,105,115,116,32,112,97,116,116,49,52,50,32,46,32,114,101,115,116,49,52,51,41};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,49,53,53,32,105,49,54,49,41};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,13),40,97,54,48,55,32,115,121,109,49,53,51,41,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,13),40,97,54,55,54,32,115,121,109,49,53,49,41,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,27),40,97,112,114,111,112,111,115,32,112,97,116,116,49,52,53,32,46,32,114,101,115,116,49,52,54,41,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,27),40,115,121,115,116,101,109,42,32,102,115,116,114,49,56,56,32,46,32,97,114,103,115,49,56,57,41,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,33),40,102,111,114,45,101,97,99,104,45,108,105,110,101,32,112,114,111,99,50,48,50,32,46,32,112,111,114,116,50,48,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,6),40,97,55,53,57,41,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,13),40,97,55,56,48,32,97,114,103,50,51,52,41,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,29),40,102,111,114,45,101,97,99,104,45,97,114,103,118,45,108,105,110,101,32,116,104,117,110,107,50,50,48,41,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,6),40,97,56,48,52,41,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,20),40,114,101,97,100,45,97,108,108,32,46,32,102,105,108,101,50,51,57,41,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,11),40,97,56,54,48,32,99,50,57,49,41,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,23),40,113,115,32,115,116,114,50,54,53,32,46,32,116,109,112,50,54,52,50,54,54,41,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_utils_toplevel)
C_externexport void C_ccall C_utils_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_324)
static void C_ccall f_324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_327)
static void C_ccall f_327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_330)
static void C_ccall f_330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_333)
static void C_ccall f_333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_336)
static void C_ccall f_336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_339)
static void C_ccall f_339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_830)
static void C_ccall f_830(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_830)
static void C_ccall f_830r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_834)
static void C_ccall f_834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_884)
static void C_ccall f_884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_861)
static void C_ccall f_861(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_859)
static void C_ccall f_859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_787)
static void C_ccall f_787(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_787)
static void C_ccall f_787r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_791)
static void C_ccall f_791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_797)
static void C_ccall f_797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_805)
static void C_ccall f_805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_742)
static void C_ccall f_742(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_767)
static void C_ccall f_767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_781)
static void C_ccall f_781(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_760)
static void C_ccall f_760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_706)
static void C_ccall f_706(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_706)
static void C_ccall f_706r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_713)
static void C_ccall f_713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_718)
static void C_fcall f_718(C_word t0,C_word t1) C_noret;
C_noret_decl(f_722)
static void C_ccall f_722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_731)
static void C_ccall f_731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_688)
static void C_ccall f_688(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_688)
static void C_ccall f_688r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_692)
static void C_ccall f_692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_695)
static void C_ccall f_695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_596)
static void C_ccall f_596(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_596)
static void C_ccall f_596r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_600)
static void C_ccall f_600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_677)
static void C_ccall f_677(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_686)
static void C_ccall f_686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_603)
static void C_ccall f_603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_608)
static void C_ccall f_608(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_612)
static void C_ccall f_612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_675)
static void C_ccall f_675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_654)
static void C_fcall f_654(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_664)
static void C_ccall f_664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_615)
static void C_ccall f_615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_618)
static void C_ccall f_618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_621)
static void C_ccall f_621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_624)
static void C_ccall f_624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_633)
static void C_ccall f_633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_544)
static void C_ccall f_544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_627)
static void C_ccall f_627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_590)
static void C_ccall f_590(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_590)
static void C_ccall f_590r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_571)
static void C_fcall f_571(C_word t0,C_word t1) C_noret;
C_noret_decl(f_588)
static void C_ccall f_588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_581)
static void C_ccall f_581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_468)
static void C_fcall f_468(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_472)
static void C_ccall f_472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_490)
static void C_ccall f_490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_481)
static void C_ccall f_481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_504)
static C_word C_fcall f_504(C_word t0,C_word t1);
C_noret_decl(f_429)
static void C_ccall f_429(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_429)
static void C_ccall f_429r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_433)
static void C_ccall f_433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_436)
static void C_ccall f_436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_446)
static void C_ccall f_446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_395)
static void C_ccall f_395(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_400)
static void C_ccall f_400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_427)
static void C_ccall f_427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_405)
static void C_ccall f_405(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_423)
static void C_ccall f_423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_415)
static void C_ccall f_415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_403)
static void C_ccall f_403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_369)
static void C_ccall f_369(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_374)
static void C_ccall f_374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_379)
static void C_ccall f_379(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_393)
static void C_ccall f_393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_386)
static void C_ccall f_386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_342)
static void C_fcall f_342(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_367)
static void C_ccall f_367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_346)
static void C_fcall f_346(C_word t0,C_word t1) C_noret;
C_noret_decl(f_360)
static void C_ccall f_360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_356)
static void C_ccall f_356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_349)
static void C_fcall f_349(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_718)
static void C_fcall trf_718(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_718(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_718(t0,t1);}

C_noret_decl(trf_654)
static void C_fcall trf_654(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_654(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_654(t0,t1,t2);}

C_noret_decl(trf_571)
static void C_fcall trf_571(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_571(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_571(t0,t1);}

C_noret_decl(trf_468)
static void C_fcall trf_468(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_468(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_468(t0,t1,t2,t3);}

C_noret_decl(trf_342)
static void C_fcall trf_342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_342(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_342(t0,t1,t2);}

C_noret_decl(trf_346)
static void C_fcall trf_346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_346(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_346(t0,t1);}

C_noret_decl(trf_349)
static void C_fcall trf_349(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_349(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_349(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_utils_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_utils_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("utils_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(593)){
C_save(t1);
C_rereclaim2(593*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,62);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],20,"\003sysapropos-interned");
lf[3]=C_h_intern(&lf[3],18,"\003sysapropos-macros");
lf[4]=C_h_intern(&lf[4],13,"string-search");
lf[5]=C_h_intern(&lf[5],6,"regexp");
lf[6]=C_h_intern(&lf[6],13,"regexp-escape");
lf[7]=C_h_intern(&lf[7],14,"symbol->string");
lf[8]=C_h_intern(&lf[8],32,"\003syssymbol-has-toplevel-binding\077");
lf[9]=C_h_intern(&lf[9],23,"\003sysenvironment-symbols");
lf[10]=C_h_intern(&lf[10],12,"\003sysfor-each");
lf[11]=C_h_intern(&lf[11],21,"\003sysmacro-environment");
lf[12]=C_h_intern(&lf[12],11,"\003sysapropos");
lf[13]=C_h_intern(&lf[13],10,"\003sysappend");
lf[14]=C_h_intern(&lf[14],9,"\003syserror");
lf[15]=C_h_intern(&lf[15],12,"apropos-list");
lf[16]=C_h_intern(&lf[16],7,"apropos");
lf[17]=C_h_intern(&lf[17],8,"\000macros\077");
lf[18]=C_h_intern(&lf[18],11,"environment");
lf[19]=C_h_intern(&lf[19],15,"\003syssignal-hook");
lf[20]=C_h_intern(&lf[20],11,"\000type-error");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\0003bad argument type - not a string, symbol, or regexp");
lf[22]=C_h_intern(&lf[22],7,"regexp\077");
lf[23]=C_h_intern(&lf[23],23,"interaction-environment");
lf[24]=C_h_intern(&lf[24],8,"keyword\077");
lf[25]=C_h_intern(&lf[25],28,"\003syssymbol->qualified-string");
lf[26]=C_h_intern(&lf[26],7,"newline");
lf[27]=C_h_intern(&lf[27],7,"display");
lf[28]=C_h_intern(&lf[28],5,"macro");
lf[29]=C_h_intern(&lf[29],9,"procedure");
lf[30]=C_h_intern(&lf[30],21,"procedure-information");
lf[31]=C_h_intern(&lf[31],8,"variable");
lf[32]=C_h_intern(&lf[32],6,"macro\077");
lf[33]=C_h_intern(&lf[33],7,"sprintf");
lf[34]=C_h_intern(&lf[34],6,"system");
lf[35]=C_h_intern(&lf[35],7,"system*");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\0003shell invocation failed with non-zero return status");
lf[37]=C_h_intern(&lf[37],9,"read-line");
lf[38]=C_h_intern(&lf[38],13,"for-each-line");
lf[39]=C_h_intern(&lf[39],18,"\003sysstandard-input");
lf[40]=C_h_intern(&lf[40],14,"\003syscheck-port");
lf[41]=C_h_intern(&lf[41],18,"for-each-argv-line");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[43]=C_h_intern(&lf[43],20,"with-input-from-file");
lf[44]=C_h_intern(&lf[44],22,"command-line-arguments");
lf[45]=C_h_intern(&lf[45],8,"read-all");
lf[46]=C_h_intern(&lf[46],20,"\003sysread-string/port");
lf[47]=C_h_intern(&lf[47],5,"port\077");
lf[48]=C_h_intern(&lf[48],2,"qs");
lf[49]=C_h_intern(&lf[49],7,"mingw32");
lf[50]=C_h_intern(&lf[50],4,"msvc");
lf[51]=C_h_intern(&lf[51],13,"string-append");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\002\047\047");
lf[55]=C_h_intern(&lf[55],18,"string-concatenate");
lf[56]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000#\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000`\376\003\000\000\002\376\377\012\000\000\264\376\003\000\000\002\376\377\012\000\000~\376\003\000\000\002\376\377\012\000\000&\376\003\000"
"\000\002\376\377\012\000\000%\376\003\000\000\002\376\377\012\000\000$\376\003\000\000\002\376\377\012\000\000!\376\003\000\000\002\376\377\012\000\000*\376\003\000\000\002\376\377\012\000\000;\376\003\000\000\002\376\377\012\000\000<\376\003\000\000\002\376\377\012\000\000>\376\003\000\000\002\376"
"\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000(\376\003\000\000\002\376\377\012\000\000)\376\003\000\000\002\376\377\012\000\000[\376\003\000\000\002\376\377\012\000\000]\376\003\000\000\002\376\377\012\000\000{\376\003\000\000\002\376\377\012\000\000}\376\377\016");
lf[57]=C_h_intern(&lf[57],7,"\003sysmap");
lf[58]=C_h_intern(&lf[58],16,"\003sysstring->list");
lf[59]=C_h_intern(&lf[59],14,"build-platform");
lf[60]=C_h_intern(&lf[60],17,"register-feature!");
lf[61]=C_h_intern(&lf[61],5,"utils");
C_register_lf2(lf,62,create_ptable());
t2=C_mutate(&lf[0] /* (set! c79 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_324,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k322 */
static void C_ccall f_324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_327,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k325 in k322 */
static void C_ccall f_327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_330,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k328 in k325 in k322 */
static void C_ccall f_330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_333,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k331 in k328 in k325 in k322 */
static void C_ccall f_333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_336,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_339,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 55   register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[60]+1)))(3,*((C_word*)lf[60]+1),t2,lf[61]);}

/* k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_339,2,t0,t1);}
t2=C_set_block_item(lf[2] /* apropos-interned */,0,C_SCHEME_UNDEFINED);
t3=C_set_block_item(lf[3] /* apropos-macros */,0,C_SCHEME_UNDEFINED);
t4=*((C_word*)lf[4]+1);
t5=*((C_word*)lf[5]+1);
t6=*((C_word*)lf[6]+1);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_342,a[2]=t6,a[3]=t5,a[4]=((C_word)li0),tmp=(C_word)a,a+=5,tmp);
t8=C_mutate((C_word*)lf[2]+1 /* (set! apropos-interned ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_369,a[2]=t7,a[3]=t4,a[4]=((C_word)li2),tmp=(C_word)a,a+=5,tmp));
t9=C_mutate((C_word*)lf[3]+1 /* (set! apropos-macros ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_395,a[2]=t7,a[3]=t4,a[4]=((C_word)li4),tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[12]+1 /* (set! apropos ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_429,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t11=C_set_block_item(lf[15] /* apropos-list */,0,C_SCHEME_UNDEFINED);
t12=C_set_block_item(lf[16] /* apropos */,0,C_SCHEME_UNDEFINED);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_468,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_571,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp);
t15=C_mutate((C_word*)lf[15]+1 /* (set! apropos-list ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_590,a[2]=t13,a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp));
t16=C_mutate((C_word*)lf[16]+1 /* (set! apropos ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_596,a[2]=t13,a[3]=t14,a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp));
t17=*((C_word*)lf[33]+1);
t18=*((C_word*)lf[34]+1);
t19=C_mutate((C_word*)lf[35]+1 /* (set! system* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_688,a[2]=t17,a[3]=t18,a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp));
t20=*((C_word*)lf[37]+1);
t21=C_mutate((C_word*)lf[38]+1 /* (set! for-each-line ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_706,a[2]=t20,a[3]=((C_word)li16),tmp=(C_word)a,a+=4,tmp));
t22=C_mutate((C_word*)lf[41]+1 /* (set! for-each-argv-line ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_742,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[45]+1 /* (set! read-all ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_787,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[48]+1 /* (set! qs ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_830,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t25=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,C_SCHEME_UNDEFINED);}

/* qs in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_830(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_830r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_830r(t0,t1,t2,t3);}}

static void C_ccall f_830r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_834,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* utils.scm: 216  build-platform */
((C_proc2)C_retrieve_proc(*((C_word*)lf[59]+1)))(2,*((C_word*)lf[59]+1),t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_834(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k832 in qs in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_834,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[49]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(t1,lf[50]));
if(C_truep(t3)){
/* utils.scm: 219  string-append */
t4=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],lf[52],((C_word*)t0)[2],lf[53]);}
else{
t4=(C_word)C_i_string_length(((C_word*)t0)[2]);
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[54]);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_859,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_861,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_884,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t9=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,((C_word*)t0)[2]);}}}

/* k882 in k832 in qs in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a860 in k832 in qs in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_861(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_861,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_whitespacep(t2);
t4=(C_truep(t3)?t3:(C_word)C_i_memq(t2,lf[56]));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?(C_word)C_a_i_string(&a,2,C_make_character(92),t2):(C_word)C_a_i_string(&a,1,t2)));}

/* k857 in k832 in qs in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 223  string-concatenate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[55]+1)))(3,*((C_word*)lf[55]+1),((C_word*)t0)[2],t1);}

/* read-all in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_787(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_787r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_787r(t0,t1,t2);}}

static void C_ccall f_787r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_791,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_791(2,t4,*((C_word*)lf[39]+1));}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_791(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k789 in read-all in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_797,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 209  port? */
t3=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k795 in k789 in read-all in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_797,2,t0,t1);}
if(C_truep(t1)){
/* read-string/port */
t2=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_805,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 211  with-input-from-file */
t3=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* a804 in k795 in k789 in read-all in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_805,2,t0,t1);}
/* read-string/port */
t2=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_SCHEME_FALSE,*((C_word*)lf[39]+1));}

/* for-each-argv-line in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_742(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_742,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_767,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 197  command-line-arguments */
t4=*((C_word*)lf[44]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k765 in for-each-argv-line in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_767,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
/* utils.scm: 200  for-each-line */
t2=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_781,a[2]=((C_word*)t0)[2],a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t3=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,t1);}}

/* a780 in k765 in for-each-argv-line in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_781(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_781,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
if(C_truep((C_word)C_i_string_equal_p(t2,lf[42]))){
/* utils.scm: 195  for-each-line */
t4=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_760,a[2]=t3,a[3]=((C_word)li17),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 196  with-input-from-file */
t5=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t4);}}

/* a759 in a780 in k765 in for-each-argv-line in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_760,2,t0,t1);}
/* for-each-line */
t2=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* for-each-line in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_706(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_706r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_706r(t0,t1,t2,t3);}}

static void C_ccall f_706r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):*((C_word*)lf[39]+1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_713,a[2]=t1,a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 182  ##sys#check-port */
t7=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t5,lf[38]);}

/* k711 in for-each-line in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_713,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_718,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word)li15),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_718(t5,((C_word*)t0)[2]);}

/* loop in k711 in for-each-line in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_fcall f_718(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_718,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_722,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 184  read-line */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k720 in loop in k711 in for-each-line in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_722,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_731,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 186  proc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}}

/* k729 in k720 in loop in k711 in for-each-line in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 187  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_718(t2,((C_word*)t0)[2]);}

/* system* in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_688(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_688r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_688r(t0,t1,t2,t3);}}

static void C_ccall f_688r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_692,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,((C_word*)t0)[2],t2,t3);}

/* k690 in system* in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_692,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_695,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 171  system */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k693 in k690 in system* in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* utils.scm: 173  ##sys#error */
t3=*((C_word*)lf[14]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[36],((C_word*)t0)[2],t1);}}

/* apropos in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_596(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_596r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_596r(t0,t1,t2,t3);}}

static void C_ccall f_596r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_600,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 139  %apropos-list */
f_468(t4,lf[16],t2,t3);}

/* k598 in apropos in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_600,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_603,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_677,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li12),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t6=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t1);}

/* a676 in k598 in apropos in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_677(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_677,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_686,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 143  symlen */
f_571(t3,t2);}

/* k684 in a676 in k598 in apropos in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k601 in k598 in apropos in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_608,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word)li11),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t3=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a607 in k601 in k598 in apropos in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_608(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_608,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_612,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 147  display */
t4=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k610 in a607 in k601 in k598 in apropos in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_615,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_675,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 148  symlen */
f_571(t3,((C_word*)t0)[4]);}

/* k673 in k610 in a607 in k601 in k598 in apropos in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_675,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[3])[1],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_654,a[2]=t4,a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_654(t6,((C_word*)t0)[2],t2);}

/* doloop155 in k673 in k610 in a607 in k601 in k598 in apropos in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_fcall f_654(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_654,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_664,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 150  display */
t4=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_make_character(32));}}

/* k662 in doloop155 in k673 in k610 in a607 in k601 in k598 in apropos in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_654(t3,((C_word*)t0)[2],t2);}

/* k613 in k610 in a607 in k601 in k598 in apropos in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_615,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 151  display */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(32));}

/* k616 in k613 in k610 in a607 in k601 in k598 in apropos in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_621,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 151  display */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(58));}

/* k619 in k616 in k613 in k610 in a607 in k601 in k598 in apropos in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 151  display */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(32));}

/* k622 in k619 in k616 in k613 in k610 in a607 in k601 in k598 in apropos in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_627,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_633,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 152  macro? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[32]+1)))(3,*((C_word*)lf[32]+1),t3,((C_word*)t0)[2]);}

/* k631 in k622 in k619 in k616 in k613 in k610 in a607 in k601 in k598 in apropos in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_633,2,t0,t1);}
if(C_truep(t1)){
/* utils.scm: 154  display */
t2=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],lf[28]);}
else{
t2=(C_word)C_retrieve(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_544,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 122  procedure-information */
((C_proc3)C_retrieve_proc(*((C_word*)lf[30]+1)))(3,*((C_word*)lf[30]+1),t3,t2);}
else{
/* utils.scm: 159  display */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],lf[31]);}}}

/* k542 in k631 in k622 in k619 in k616 in k613 in k610 in a607 in k601 in k598 in apropos in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_544,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_cdr(t1);
t3=(C_word)C_a_i_cons(&a,2,lf[29],t2);
/* utils.scm: 123  display */
t4=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}
else{
if(C_truep(t1)){
/* utils.scm: 124  display */
t2=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[29]);}
else{
/* utils.scm: 125  display */
t2=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[29]);}}}

/* k625 in k622 in k619 in k616 in k613 in k610 in a607 in k601 in k598 in apropos in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 160  newline */
t2=*((C_word*)lf[26]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* apropos-list in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_590(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_590r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_590r(t0,t1,t2,t3);}}

static void C_ccall f_590r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* utils.scm: 135  %apropos-list */
f_468(t1,lf[15],t2,t3);}

/* symlen in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_fcall f_571(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_571,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_588,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 128  ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[25]+1)))(3,*((C_word*)lf[25]+1),t3,t2);}

/* k586 in symlen in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_588,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_581,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 129  keyword? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[24]+1)))(3,*((C_word*)lf[24]+1),t3,((C_word*)t0)[2]);}

/* k579 in k586 in symlen in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_fixnum_difference(((C_word*)t0)[2],C_fix(2)):((C_word*)t0)[2]));}

/* %apropos-list in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_fcall f_468(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_468,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_472,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 103  interaction-environment */
((C_proc2)C_retrieve_proc(*((C_word*)lf[23]+1)))(2,*((C_word*)lf[23]+1),t5);}

/* k470 in %apropos-list in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_472,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_504,a[2]=t3,a[3]=t5,a[4]=((C_word)li6),tmp=(C_word)a,a+=5,tmp);
t7=f_504(t6,((C_word*)t0)[5]);
t8=(C_word)C_i_check_structure_2(((C_word*)t3)[1],lf[18],((C_word*)t0)[4]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_481,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t10=(C_word)C_i_stringp(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_490,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t10)){
t12=t11;
f_490(2,t12,t10);}
else{
t12=(C_word)C_i_symbolp(((C_word*)t0)[2]);
if(C_truep(t12)){
t13=t11;
f_490(2,t13,t12);}
else{
/* utils.scm: 117  regexp? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[22]+1)))(3,*((C_word*)lf[22]+1),t11,((C_word*)t0)[2]);}}}

/* k488 in k470 in %apropos-list in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_481(2,t2,C_SCHEME_UNDEFINED);}
else{
/* utils.scm: 118  ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[19]+1)))(6,*((C_word*)lf[19]+1),((C_word*)t0)[4],lf[20],((C_word*)t0)[3],lf[21],((C_word*)t0)[2]);}}

/* k479 in k470 in %apropos-list in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 119  ##sys#apropos */
((C_proc5)C_retrieve_proc(*((C_word*)lf[12]+1)))(5,*((C_word*)lf[12]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* loop in k470 in %apropos-list in k337 in k334 in k331 in k328 in k325 in k322 */
static C_word C_fcall f_504(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
C_stack_check;
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_eqp(lf[17],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cadr(t1);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=(C_word)C_i_cddr(t1);
t10=t6;
t1=t10;
goto loop;}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=(C_word)C_i_cdr(t1);
t10=t5;
t1=t10;
goto loop;}}
else{
return(C_SCHEME_UNDEFINED);}}

/* ##sys#apropos in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_429(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_429r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_429r(t0,t1,t2,t3,t4);}}

static void C_ccall f_429r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_433,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_433(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_433(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k431 in ##sys#apropos in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_436,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 94   ##sys#apropos-interned */
((C_proc4)C_retrieve_proc(*((C_word*)lf[2]+1)))(4,*((C_word*)lf[2]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k434 in k431 in ##sys#apropos in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_436,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_446,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 96   ##sys#apropos-macros */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* k444 in k434 in k431 in ##sys#apropos in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 96   ##sys#append */
t2=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#apropos-macros in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_395(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_395,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_400,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 83   makpat */
t6=((C_word*)t0)[2];
f_342(t6,t5,((C_word*)t4)[1]);}

/* k398 in ##sys#apropos-macros in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_400,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_403,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_405,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word)li3),tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_427,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 90   ##sys#macro-environment */
t8=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}

/* k425 in k398 in ##sys#apropos-macros in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a404 in k398 in ##sys#apropos-macros in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_405(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_405,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_415,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_423,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 88   symbol->string */
t6=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}

/* k421 in a404 in k398 in ##sys#apropos-macros in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 88   string-search */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k413 in a404 in k398 in ##sys#apropos-macros in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_415,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k401 in k398 in ##sys#apropos-macros in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##sys#apropos-interned in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_369(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_369,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_374,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 75   makpat */
t6=((C_word*)t0)[2];
f_342(t6,t5,((C_word*)t4)[1]);}

/* k372 in ##sys#apropos-interned in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_374,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_379,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word)li1),tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 76   ##sys#environment-symbols */
t4=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a378 in k372 in ##sys#apropos-interned in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_379(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_379,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_386,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_393,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 78   symbol->string */
t5=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k391 in a378 in k372 in ##sys#apropos-interned in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 78   string-search */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k384 in a378 in k372 in ##sys#apropos-interned in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* utils.scm: 79   ##sys#symbol-has-toplevel-binding? */
t2=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* makpat in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_fcall f_342(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_342,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_346,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t3)[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_367,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 68   symbol->string */
t6=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t3)[1]);}
else{
t5=t4;
f_346(t5,C_SCHEME_UNDEFINED);}}

/* k365 in makpat in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_346(t3,t2);}

/* k344 in makpat in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_fcall f_346(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_346,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_349,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[4])[1]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_356,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_360,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 70   regexp-escape */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t2;
f_349(t3,C_SCHEME_UNDEFINED);}}

/* k358 in k344 in makpat in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 70   regexp */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k354 in k344 in makpat in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_ccall f_356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_349(t3,t2);}

/* k347 in k344 in makpat in k337 in k334 in k331 in k328 in k325 in k322 */
static void C_fcall f_349(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[77] = {
{"toplevel:utils_scm",(void*)C_utils_toplevel},
{"f_324:utils_scm",(void*)f_324},
{"f_327:utils_scm",(void*)f_327},
{"f_330:utils_scm",(void*)f_330},
{"f_333:utils_scm",(void*)f_333},
{"f_336:utils_scm",(void*)f_336},
{"f_339:utils_scm",(void*)f_339},
{"f_830:utils_scm",(void*)f_830},
{"f_834:utils_scm",(void*)f_834},
{"f_884:utils_scm",(void*)f_884},
{"f_861:utils_scm",(void*)f_861},
{"f_859:utils_scm",(void*)f_859},
{"f_787:utils_scm",(void*)f_787},
{"f_791:utils_scm",(void*)f_791},
{"f_797:utils_scm",(void*)f_797},
{"f_805:utils_scm",(void*)f_805},
{"f_742:utils_scm",(void*)f_742},
{"f_767:utils_scm",(void*)f_767},
{"f_781:utils_scm",(void*)f_781},
{"f_760:utils_scm",(void*)f_760},
{"f_706:utils_scm",(void*)f_706},
{"f_713:utils_scm",(void*)f_713},
{"f_718:utils_scm",(void*)f_718},
{"f_722:utils_scm",(void*)f_722},
{"f_731:utils_scm",(void*)f_731},
{"f_688:utils_scm",(void*)f_688},
{"f_692:utils_scm",(void*)f_692},
{"f_695:utils_scm",(void*)f_695},
{"f_596:utils_scm",(void*)f_596},
{"f_600:utils_scm",(void*)f_600},
{"f_677:utils_scm",(void*)f_677},
{"f_686:utils_scm",(void*)f_686},
{"f_603:utils_scm",(void*)f_603},
{"f_608:utils_scm",(void*)f_608},
{"f_612:utils_scm",(void*)f_612},
{"f_675:utils_scm",(void*)f_675},
{"f_654:utils_scm",(void*)f_654},
{"f_664:utils_scm",(void*)f_664},
{"f_615:utils_scm",(void*)f_615},
{"f_618:utils_scm",(void*)f_618},
{"f_621:utils_scm",(void*)f_621},
{"f_624:utils_scm",(void*)f_624},
{"f_633:utils_scm",(void*)f_633},
{"f_544:utils_scm",(void*)f_544},
{"f_627:utils_scm",(void*)f_627},
{"f_590:utils_scm",(void*)f_590},
{"f_571:utils_scm",(void*)f_571},
{"f_588:utils_scm",(void*)f_588},
{"f_581:utils_scm",(void*)f_581},
{"f_468:utils_scm",(void*)f_468},
{"f_472:utils_scm",(void*)f_472},
{"f_490:utils_scm",(void*)f_490},
{"f_481:utils_scm",(void*)f_481},
{"f_504:utils_scm",(void*)f_504},
{"f_429:utils_scm",(void*)f_429},
{"f_433:utils_scm",(void*)f_433},
{"f_436:utils_scm",(void*)f_436},
{"f_446:utils_scm",(void*)f_446},
{"f_395:utils_scm",(void*)f_395},
{"f_400:utils_scm",(void*)f_400},
{"f_427:utils_scm",(void*)f_427},
{"f_405:utils_scm",(void*)f_405},
{"f_423:utils_scm",(void*)f_423},
{"f_415:utils_scm",(void*)f_415},
{"f_403:utils_scm",(void*)f_403},
{"f_369:utils_scm",(void*)f_369},
{"f_374:utils_scm",(void*)f_374},
{"f_379:utils_scm",(void*)f_379},
{"f_393:utils_scm",(void*)f_393},
{"f_386:utils_scm",(void*)f_386},
{"f_342:utils_scm",(void*)f_342},
{"f_367:utils_scm",(void*)f_367},
{"f_346:utils_scm",(void*)f_346},
{"f_360:utils_scm",(void*)f_360},
{"f_356:utils_scm",(void*)f_356},
{"f_349:utils_scm",(void*)f_349},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
