/* Generated from utils.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-10-29 11:58
   Version 4.0.0x - linux-unix-gnu-x86	[ ptables applyhook ]
   SVN rev. 12299	compiled 2008-10-29 on dill (Linux)
   command line: utils.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -output-file utils.c
   unit: utils
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[50];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,15),40,109,97,107,112,97,116,32,112,97,116,116,50,55,41,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,12),40,97,51,51,49,32,115,121,109,51,57,41,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,37),40,35,35,115,121,115,35,97,112,114,111,112,111,115,45,105,110,116,101,114,110,101,100,32,112,97,116,116,51,54,32,101,110,118,51,55,41,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,10),40,97,51,53,55,32,97,52,57,41,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,97,112,114,111,112,111,115,45,109,97,99,114,111,115,32,112,97,116,116,52,52,32,101,110,118,52,53,41,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,97,112,114,111,112,111,115,32,112,97,116,116,54,54,32,101,110,118,54,55,32,46,32,116,109,112,54,53,54,56,41,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,35),40,37,97,112,114,111,112,111,115,45,108,105,115,116,32,108,111,99,56,57,32,112,97,116,116,57,48,32,97,114,103,115,57,49,41,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,15),40,115,121,109,108,101,110,32,115,121,109,49,51,55,41,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,32),40,97,112,114,111,112,111,115,45,108,105,115,116,32,112,97,116,116,49,52,50,32,46,32,114,101,115,116,49,52,51,41};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,49,53,53,32,105,49,54,49,41};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,13),40,97,53,54,48,32,115,121,109,49,53,51,41,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,13),40,97,54,50,57,32,115,121,109,49,53,49,41,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,27),40,97,112,114,111,112,111,115,32,112,97,116,116,49,52,53,32,46,32,114,101,115,116,49,52,54,41,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,27),40,115,121,115,116,101,109,42,32,102,115,116,114,49,56,56,32,46,32,97,114,103,115,49,56,57,41,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,33),40,102,111,114,45,101,97,99,104,45,108,105,110,101,32,112,114,111,99,50,48,50,32,46,32,112,111,114,116,50,48,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,6),40,97,55,49,50,41,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,13),40,97,55,51,51,32,97,114,103,50,51,52,41,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,29),40,102,111,114,45,101,97,99,104,45,97,114,103,118,45,108,105,110,101,32,116,104,117,110,107,50,50,48,41,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,6),40,97,55,53,55,41,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,20),40,114,101,97,100,45,97,108,108,32,46,32,102,105,108,101,50,51,57,41,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_utils_toplevel)
C_externexport void C_ccall C_utils_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_280)
static void C_ccall f_280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_283)
static void C_ccall f_283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_286)
static void C_ccall f_286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_289)
static void C_ccall f_289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_292)
static void C_ccall f_292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_740)
static void C_ccall f_740(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_740)
static void C_ccall f_740r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_744)
static void C_ccall f_744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_750)
static void C_ccall f_750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_758)
static void C_ccall f_758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_695)
static void C_ccall f_695(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_720)
static void C_ccall f_720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_734)
static void C_ccall f_734(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_713)
static void C_ccall f_713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_659)
static void C_ccall f_659(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_659)
static void C_ccall f_659r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_666)
static void C_ccall f_666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_671)
static void C_fcall f_671(C_word t0,C_word t1) C_noret;
C_noret_decl(f_675)
static void C_ccall f_675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_684)
static void C_ccall f_684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_641)
static void C_ccall f_641(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_641)
static void C_ccall f_641r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_645)
static void C_ccall f_645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_648)
static void C_ccall f_648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_549)
static void C_ccall f_549(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_549)
static void C_ccall f_549r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_553)
static void C_ccall f_553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_630)
static void C_ccall f_630(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_639)
static void C_ccall f_639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_556)
static void C_ccall f_556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_561)
static void C_ccall f_561(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_565)
static void C_ccall f_565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_628)
static void C_ccall f_628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_607)
static void C_fcall f_607(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_617)
static void C_ccall f_617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_568)
static void C_ccall f_568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_571)
static void C_ccall f_571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_574)
static void C_ccall f_574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_577)
static void C_ccall f_577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_586)
static void C_ccall f_586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_497)
static void C_ccall f_497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_580)
static void C_ccall f_580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_543)
static void C_ccall f_543(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_543)
static void C_ccall f_543r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_524)
static void C_fcall f_524(C_word t0,C_word t1) C_noret;
C_noret_decl(f_541)
static void C_ccall f_541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_534)
static void C_ccall f_534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_421)
static void C_fcall f_421(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_425)
static void C_ccall f_425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_443)
static void C_ccall f_443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_434)
static void C_ccall f_434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_457)
static C_word C_fcall f_457(C_word t0,C_word t1);
C_noret_decl(f_382)
static void C_ccall f_382(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_382)
static void C_ccall f_382r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_386)
static void C_ccall f_386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_389)
static void C_ccall f_389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_399)
static void C_ccall f_399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_348)
static void C_ccall f_348(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_353)
static void C_ccall f_353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_380)
static void C_ccall f_380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_358)
static void C_ccall f_358(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_376)
static void C_ccall f_376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_368)
static void C_ccall f_368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_356)
static void C_ccall f_356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_322)
static void C_ccall f_322(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_327)
static void C_ccall f_327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_332)
static void C_ccall f_332(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_346)
static void C_ccall f_346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_339)
static void C_ccall f_339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_295)
static void C_fcall f_295(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_320)
static void C_ccall f_320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_299)
static void C_fcall f_299(C_word t0,C_word t1) C_noret;
C_noret_decl(f_313)
static void C_ccall f_313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_309)
static void C_ccall f_309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_302)
static void C_fcall f_302(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_671)
static void C_fcall trf_671(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_671(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_671(t0,t1);}

C_noret_decl(trf_607)
static void C_fcall trf_607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_607(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_607(t0,t1,t2);}

C_noret_decl(trf_524)
static void C_fcall trf_524(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_524(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_524(t0,t1);}

C_noret_decl(trf_421)
static void C_fcall trf_421(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_421(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_421(t0,t1,t2,t3);}

C_noret_decl(trf_295)
static void C_fcall trf_295(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_295(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_295(t0,t1,t2);}

C_noret_decl(trf_299)
static void C_fcall trf_299(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_299(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_299(t0,t1);}

C_noret_decl(trf_302)
static void C_fcall trf_302(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_302(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_302(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_utils_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_utils_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("utils_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(450)){
C_save(t1);
C_rereclaim2(450*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,50);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],20,"\003sysapropos-interned");
lf[3]=C_h_intern(&lf[3],18,"\003sysapropos-macros");
lf[4]=C_h_intern(&lf[4],13,"string-search");
lf[5]=C_h_intern(&lf[5],6,"regexp");
lf[6]=C_h_intern(&lf[6],13,"regexp-escape");
lf[7]=C_h_intern(&lf[7],14,"symbol->string");
lf[8]=C_h_intern(&lf[8],32,"\003syssymbol-has-toplevel-binding\077");
lf[9]=C_h_intern(&lf[9],23,"\003sysenvironment-symbols");
lf[10]=C_h_intern(&lf[10],12,"\003sysfor-each");
lf[11]=C_h_intern(&lf[11],21,"\003sysmacro-environment");
lf[12]=C_h_intern(&lf[12],11,"\003sysapropos");
lf[13]=C_h_intern(&lf[13],10,"\003sysappend");
lf[14]=C_h_intern(&lf[14],9,"\003syserror");
lf[15]=C_h_intern(&lf[15],12,"apropos-list");
lf[16]=C_h_intern(&lf[16],7,"apropos");
lf[17]=C_h_intern(&lf[17],8,"\000macros\077");
lf[18]=C_h_intern(&lf[18],11,"environment");
lf[19]=C_h_intern(&lf[19],15,"\003syssignal-hook");
lf[20]=C_h_intern(&lf[20],11,"\000type-error");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\0003bad argument type - not a string, symbol, or regexp");
lf[22]=C_h_intern(&lf[22],7,"regexp\077");
lf[23]=C_h_intern(&lf[23],23,"interaction-environment");
lf[24]=C_h_intern(&lf[24],8,"keyword\077");
lf[25]=C_h_intern(&lf[25],28,"\003syssymbol->qualified-string");
lf[26]=C_h_intern(&lf[26],7,"newline");
lf[27]=C_h_intern(&lf[27],7,"display");
lf[28]=C_h_intern(&lf[28],5,"macro");
lf[29]=C_h_intern(&lf[29],9,"procedure");
lf[30]=C_h_intern(&lf[30],21,"procedure-information");
lf[31]=C_h_intern(&lf[31],8,"variable");
lf[32]=C_h_intern(&lf[32],6,"macro\077");
lf[33]=C_h_intern(&lf[33],7,"sprintf");
lf[34]=C_h_intern(&lf[34],6,"system");
lf[35]=C_h_intern(&lf[35],7,"system*");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\0003shell invocation failed with non-zero return status");
lf[37]=C_h_intern(&lf[37],9,"read-line");
lf[38]=C_h_intern(&lf[38],13,"for-each-line");
lf[39]=C_h_intern(&lf[39],18,"\003sysstandard-input");
lf[40]=C_h_intern(&lf[40],14,"\003syscheck-port");
lf[41]=C_h_intern(&lf[41],18,"for-each-argv-line");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[43]=C_h_intern(&lf[43],20,"with-input-from-file");
lf[44]=C_h_intern(&lf[44],22,"command-line-arguments");
lf[45]=C_h_intern(&lf[45],8,"read-all");
lf[46]=C_h_intern(&lf[46],20,"\003sysread-string/port");
lf[47]=C_h_intern(&lf[47],5,"port\077");
lf[48]=C_h_intern(&lf[48],17,"register-feature!");
lf[49]=C_h_intern(&lf[49],5,"utils");
C_register_lf2(lf,50,create_ptable());
t2=C_mutate(&lf[0] /* (set! c79 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_280,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k278 */
static void C_ccall f_280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_283,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k281 in k278 */
static void C_ccall f_283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_286,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k284 in k281 in k278 */
static void C_ccall f_286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_286,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_289,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k287 in k284 in k281 in k278 */
static void C_ccall f_289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_292,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 55   register-feature! */
t3=*((C_word*)lf[48]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[49]);}

/* k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[48],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_292,2,t0,t1);}
t2=C_set_block_item(lf[2] /* apropos-interned */,0,C_SCHEME_UNDEFINED);
t3=C_set_block_item(lf[3] /* apropos-macros */,0,C_SCHEME_UNDEFINED);
t4=*((C_word*)lf[4]+1);
t5=*((C_word*)lf[5]+1);
t6=*((C_word*)lf[6]+1);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_295,a[2]=t6,a[3]=t5,a[4]=((C_word)li0),tmp=(C_word)a,a+=5,tmp);
t8=C_mutate((C_word*)lf[2]+1 /* (set! apropos-interned ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_322,a[2]=t7,a[3]=t4,a[4]=((C_word)li2),tmp=(C_word)a,a+=5,tmp));
t9=C_mutate((C_word*)lf[3]+1 /* (set! apropos-macros ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_348,a[2]=t7,a[3]=t4,a[4]=((C_word)li4),tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[12]+1 /* (set! apropos ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_382,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t11=C_set_block_item(lf[15] /* apropos-list */,0,C_SCHEME_UNDEFINED);
t12=C_set_block_item(lf[16] /* apropos */,0,C_SCHEME_UNDEFINED);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_421,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_524,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp);
t15=C_mutate((C_word*)lf[15]+1 /* (set! apropos-list ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_543,a[2]=t13,a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp));
t16=C_mutate((C_word*)lf[16]+1 /* (set! apropos ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_549,a[2]=t13,a[3]=t14,a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp));
t17=*((C_word*)lf[33]+1);
t18=*((C_word*)lf[34]+1);
t19=C_mutate((C_word*)lf[35]+1 /* (set! system* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_641,a[2]=t17,a[3]=t18,a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp));
t20=*((C_word*)lf[37]+1);
t21=C_mutate((C_word*)lf[38]+1 /* (set! for-each-line ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_659,a[2]=t20,a[3]=((C_word)li16),tmp=(C_word)a,a+=4,tmp));
t22=C_mutate((C_word*)lf[41]+1 /* (set! for-each-argv-line ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_695,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[45]+1 /* (set! read-all ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_740,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t24=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t24+1)))(2,t24,C_SCHEME_UNDEFINED);}

/* read-all in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_740(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_740r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_740r(t0,t1,t2);}}

static void C_ccall f_740r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_744,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_744(2,t4,*((C_word*)lf[39]+1));}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_744(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k742 in read-all in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_750,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 209  port? */
t3=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k748 in k742 in read-all in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_750,2,t0,t1);}
if(C_truep(t1)){
/* read-string/port */
t2=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_758,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 211  with-input-from-file */
t3=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* a757 in k748 in k742 in read-all in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_758,2,t0,t1);}
/* read-string/port */
t2=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_SCHEME_FALSE,*((C_word*)lf[39]+1));}

/* for-each-argv-line in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_695(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_695,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_720,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 197  command-line-arguments */
t4=*((C_word*)lf[44]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k718 in for-each-argv-line in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_720,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
/* utils.scm: 200  for-each-line */
t2=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_734,a[2]=((C_word*)t0)[2],a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t3=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,t1);}}

/* a733 in k718 in for-each-argv-line in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_734(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_734,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
if(C_truep((C_word)C_i_string_equal_p(t2,lf[42]))){
/* utils.scm: 195  for-each-line */
t4=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_713,a[2]=t3,a[3]=((C_word)li17),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 196  with-input-from-file */
t5=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t4);}}

/* a712 in a733 in k718 in for-each-argv-line in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_713,2,t0,t1);}
/* for-each-line */
t2=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* for-each-line in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_659(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_659r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_659r(t0,t1,t2,t3);}}

static void C_ccall f_659r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):*((C_word*)lf[39]+1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_666,a[2]=t1,a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 182  ##sys#check-port */
t7=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t5,lf[38]);}

/* k664 in for-each-line in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_666,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_671,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word)li15),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_671(t5,((C_word*)t0)[2]);}

/* loop in k664 in for-each-line in k290 in k287 in k284 in k281 in k278 */
static void C_fcall f_671(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_671,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_675,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 184  read-line */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k673 in loop in k664 in for-each-line in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_675,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_684,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 186  proc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}}

/* k682 in k673 in loop in k664 in for-each-line in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 187  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_671(t2,((C_word*)t0)[2]);}

/* system* in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_641(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_641r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_641r(t0,t1,t2,t3);}}

static void C_ccall f_641r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_645,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,((C_word*)t0)[2],t2,t3);}

/* k643 in system* in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_648,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 171  system */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k646 in k643 in system* in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* utils.scm: 173  ##sys#error */
t3=*((C_word*)lf[14]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[36],((C_word*)t0)[2],t1);}}

/* apropos in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_549(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_549r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_549r(t0,t1,t2,t3);}}

static void C_ccall f_549r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_553,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 139  %apropos-list */
f_421(t4,lf[16],t2,t3);}

/* k551 in apropos in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_553,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_556,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_630,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li12),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t6=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t1);}

/* a629 in k551 in apropos in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_630(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_630,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_639,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 143  symlen */
f_524(t3,t2);}

/* k637 in a629 in k551 in apropos in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k554 in k551 in apropos in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_561,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word)li11),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t3=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a560 in k554 in k551 in apropos in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_561(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_561,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_565,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 147  display */
t4=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k563 in a560 in k554 in k551 in apropos in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_568,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_628,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 148  symlen */
f_524(t3,((C_word*)t0)[4]);}

/* k626 in k563 in a560 in k554 in k551 in apropos in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_628,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[3])[1],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_607,a[2]=t4,a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_607(t6,((C_word*)t0)[2],t2);}

/* doloop155 in k626 in k563 in a560 in k554 in k551 in apropos in k290 in k287 in k284 in k281 in k278 */
static void C_fcall f_607(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_607,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_617,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 150  display */
t4=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_make_character(32));}}

/* k615 in doloop155 in k626 in k563 in a560 in k554 in k551 in apropos in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_607(t3,((C_word*)t0)[2],t2);}

/* k566 in k563 in a560 in k554 in k551 in apropos in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 151  display */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(32));}

/* k569 in k566 in k563 in a560 in k554 in k551 in apropos in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 151  display */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(58));}

/* k572 in k569 in k566 in k563 in a560 in k554 in k551 in apropos in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_577,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 151  display */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(32));}

/* k575 in k572 in k569 in k566 in k563 in a560 in k554 in k551 in apropos in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_577,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_580,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_586,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 152  macro? */
t4=*((C_word*)lf[32]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k584 in k575 in k572 in k569 in k566 in k563 in a560 in k554 in k551 in apropos in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_586,2,t0,t1);}
if(C_truep(t1)){
/* utils.scm: 154  display */
t2=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],lf[28]);}
else{
t2=(C_word)C_retrieve(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_497,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 122  procedure-information */
t4=*((C_word*)lf[30]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
/* utils.scm: 159  display */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],lf[31]);}}}

/* k495 in k584 in k575 in k572 in k569 in k566 in k563 in a560 in k554 in k551 in apropos in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_497,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_cdr(t1);
t3=(C_word)C_a_i_cons(&a,2,lf[29],t2);
/* utils.scm: 123  display */
t4=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}
else{
if(C_truep(t1)){
/* utils.scm: 124  display */
t2=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[29]);}
else{
/* utils.scm: 125  display */
t2=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[29]);}}}

/* k578 in k575 in k572 in k569 in k566 in k563 in a560 in k554 in k551 in apropos in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 160  newline */
t2=*((C_word*)lf[26]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* apropos-list in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_543(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_543r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_543r(t0,t1,t2,t3);}}

static void C_ccall f_543r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* utils.scm: 135  %apropos-list */
f_421(t1,lf[15],t2,t3);}

/* symlen in k290 in k287 in k284 in k281 in k278 */
static void C_fcall f_524(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_524,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_541,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 128  ##sys#symbol->qualified-string */
t4=*((C_word*)lf[25]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k539 in symlen in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_541,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_534,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 129  keyword? */
t4=*((C_word*)lf[24]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k532 in k539 in symlen in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_fixnum_difference(((C_word*)t0)[2],C_fix(2)):((C_word*)t0)[2]));}

/* %apropos-list in k290 in k287 in k284 in k281 in k278 */
static void C_fcall f_421(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_421,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_425,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 103  interaction-environment */
t6=*((C_word*)lf[23]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k423 in %apropos-list in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_425,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_457,a[2]=t3,a[3]=t5,a[4]=((C_word)li6),tmp=(C_word)a,a+=5,tmp);
t7=f_457(t6,((C_word*)t0)[5]);
t8=(C_word)C_i_check_structure_2(((C_word*)t3)[1],lf[18],((C_word*)t0)[4]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_434,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t10=(C_word)C_i_stringp(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_443,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t10)){
t12=t11;
f_443(2,t12,t10);}
else{
t12=(C_word)C_i_symbolp(((C_word*)t0)[2]);
if(C_truep(t12)){
t13=t11;
f_443(2,t13,t12);}
else{
/* utils.scm: 117  regexp? */
t13=*((C_word*)lf[22]+1);
((C_proc3)C_retrieve_proc(t13))(3,t13,t11,((C_word*)t0)[2]);}}}

/* k441 in k423 in %apropos-list in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_434(2,t2,C_SCHEME_UNDEFINED);}
else{
/* utils.scm: 118  ##sys#signal-hook */
t2=*((C_word*)lf[19]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[20],((C_word*)t0)[3],lf[21],((C_word*)t0)[2]);}}

/* k432 in k423 in %apropos-list in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 119  ##sys#apropos */
t2=*((C_word*)lf[12]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* loop in k423 in %apropos-list in k290 in k287 in k284 in k281 in k278 */
static C_word C_fcall f_457(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
C_stack_check;
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_eqp(lf[17],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cadr(t1);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=(C_word)C_i_cddr(t1);
t10=t6;
t1=t10;
goto loop;}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=(C_word)C_i_cdr(t1);
t10=t5;
t1=t10;
goto loop;}}
else{
return(C_SCHEME_UNDEFINED);}}

/* ##sys#apropos in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_382(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_382r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_382r(t0,t1,t2,t3,t4);}}

static void C_ccall f_382r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_386,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_386(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_386(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k384 in ##sys#apropos in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_389,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 94   ##sys#apropos-interned */
t3=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k387 in k384 in ##sys#apropos in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_389,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_399,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 96   ##sys#apropos-macros */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* k397 in k387 in k384 in ##sys#apropos in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 96   ##sys#append */
t2=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#apropos-macros in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_348(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_348,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_353,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 83   makpat */
t6=((C_word*)t0)[2];
f_295(t6,t5,((C_word*)t4)[1]);}

/* k351 in ##sys#apropos-macros in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_353,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_356,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_358,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word)li3),tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_380,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 90   ##sys#macro-environment */
t8=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}

/* k378 in k351 in ##sys#apropos-macros in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a357 in k351 in ##sys#apropos-macros in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_358(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_358,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_368,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_376,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 88   symbol->string */
t6=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}

/* k374 in a357 in k351 in ##sys#apropos-macros in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 88   string-search */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k366 in a357 in k351 in ##sys#apropos-macros in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_368,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k354 in k351 in ##sys#apropos-macros in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##sys#apropos-interned in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_322(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_322,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_327,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 75   makpat */
t6=((C_word*)t0)[2];
f_295(t6,t5,((C_word*)t4)[1]);}

/* k325 in ##sys#apropos-interned in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_327,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_332,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word)li1),tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 76   ##sys#environment-symbols */
t4=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a331 in k325 in ##sys#apropos-interned in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_332(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_332,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_339,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_346,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 78   symbol->string */
t5=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k344 in a331 in k325 in ##sys#apropos-interned in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 78   string-search */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k337 in a331 in k325 in ##sys#apropos-interned in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* utils.scm: 79   ##sys#symbol-has-toplevel-binding? */
t2=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* makpat in k290 in k287 in k284 in k281 in k278 */
static void C_fcall f_295(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_295,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_299,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t3)[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_320,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 68   symbol->string */
t6=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t3)[1]);}
else{
t5=t4;
f_299(t5,C_SCHEME_UNDEFINED);}}

/* k318 in makpat in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_299(t3,t2);}

/* k297 in makpat in k290 in k287 in k284 in k281 in k278 */
static void C_fcall f_299(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_299,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_302,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[4])[1]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_309,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_313,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 70   regexp-escape */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t2;
f_302(t3,C_SCHEME_UNDEFINED);}}

/* k311 in k297 in makpat in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 70   regexp */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k307 in k297 in makpat in k290 in k287 in k284 in k281 in k278 */
static void C_ccall f_309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_302(t3,t2);}

/* k300 in k297 in makpat in k290 in k287 in k284 in k281 in k278 */
static void C_fcall f_302(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[71] = {
{"toplevelutils.scm",(void*)C_utils_toplevel},
{"f_280utils.scm",(void*)f_280},
{"f_283utils.scm",(void*)f_283},
{"f_286utils.scm",(void*)f_286},
{"f_289utils.scm",(void*)f_289},
{"f_292utils.scm",(void*)f_292},
{"f_740utils.scm",(void*)f_740},
{"f_744utils.scm",(void*)f_744},
{"f_750utils.scm",(void*)f_750},
{"f_758utils.scm",(void*)f_758},
{"f_695utils.scm",(void*)f_695},
{"f_720utils.scm",(void*)f_720},
{"f_734utils.scm",(void*)f_734},
{"f_713utils.scm",(void*)f_713},
{"f_659utils.scm",(void*)f_659},
{"f_666utils.scm",(void*)f_666},
{"f_671utils.scm",(void*)f_671},
{"f_675utils.scm",(void*)f_675},
{"f_684utils.scm",(void*)f_684},
{"f_641utils.scm",(void*)f_641},
{"f_645utils.scm",(void*)f_645},
{"f_648utils.scm",(void*)f_648},
{"f_549utils.scm",(void*)f_549},
{"f_553utils.scm",(void*)f_553},
{"f_630utils.scm",(void*)f_630},
{"f_639utils.scm",(void*)f_639},
{"f_556utils.scm",(void*)f_556},
{"f_561utils.scm",(void*)f_561},
{"f_565utils.scm",(void*)f_565},
{"f_628utils.scm",(void*)f_628},
{"f_607utils.scm",(void*)f_607},
{"f_617utils.scm",(void*)f_617},
{"f_568utils.scm",(void*)f_568},
{"f_571utils.scm",(void*)f_571},
{"f_574utils.scm",(void*)f_574},
{"f_577utils.scm",(void*)f_577},
{"f_586utils.scm",(void*)f_586},
{"f_497utils.scm",(void*)f_497},
{"f_580utils.scm",(void*)f_580},
{"f_543utils.scm",(void*)f_543},
{"f_524utils.scm",(void*)f_524},
{"f_541utils.scm",(void*)f_541},
{"f_534utils.scm",(void*)f_534},
{"f_421utils.scm",(void*)f_421},
{"f_425utils.scm",(void*)f_425},
{"f_443utils.scm",(void*)f_443},
{"f_434utils.scm",(void*)f_434},
{"f_457utils.scm",(void*)f_457},
{"f_382utils.scm",(void*)f_382},
{"f_386utils.scm",(void*)f_386},
{"f_389utils.scm",(void*)f_389},
{"f_399utils.scm",(void*)f_399},
{"f_348utils.scm",(void*)f_348},
{"f_353utils.scm",(void*)f_353},
{"f_380utils.scm",(void*)f_380},
{"f_358utils.scm",(void*)f_358},
{"f_376utils.scm",(void*)f_376},
{"f_368utils.scm",(void*)f_368},
{"f_356utils.scm",(void*)f_356},
{"f_322utils.scm",(void*)f_322},
{"f_327utils.scm",(void*)f_327},
{"f_332utils.scm",(void*)f_332},
{"f_346utils.scm",(void*)f_346},
{"f_339utils.scm",(void*)f_339},
{"f_295utils.scm",(void*)f_295},
{"f_320utils.scm",(void*)f_320},
{"f_299utils.scm",(void*)f_299},
{"f_313utils.scm",(void*)f_313},
{"f_309utils.scm",(void*)f_309},
{"f_302utils.scm",(void*)f_302},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
