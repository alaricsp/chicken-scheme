/* Generated from chicken-profile.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-08-25 23:22
   Version 4.0.0x - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11761	compiled 2008-08-25 on tesseract.thetesseract.org (Linux)
   command line: chicken-profile.scm -optimize-level 2 -include-path . -include-path . -no-lambda-info -output-file chicken-profile.c
   used units: library eval data_structures ports extras srfi_69 srfi_1 srfi_13 srfi_69 posix utils
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[92];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_305)
static void C_ccall f_305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_308)
static void C_ccall f_308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_311)
static void C_ccall f_311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_314)
static void C_ccall f_314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_317)
static void C_ccall f_317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_320)
static void C_ccall f_320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_323)
static void C_ccall f_323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_326)
static void C_ccall f_326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_329)
static void C_ccall f_329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_332)
static void C_ccall f_332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_335)
static void C_ccall f_335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1262)
static void C_ccall f_1262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_391)
static void C_fcall f_391(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_593)
static void C_fcall f_593(C_word t0,C_word t1) C_noret;
C_noret_decl(f_587)
static void C_ccall f_587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_779)
static void C_ccall f_779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_783)
static void C_ccall f_783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_787)
static void C_ccall f_787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_744)
static void C_fcall f_744(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_754)
static void C_ccall f_754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_546)
static void C_ccall f_546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_529)
static void C_ccall f_529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_522)
static void C_ccall f_522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_513)
static void C_ccall f_513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_506)
static void C_ccall f_506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_488)
static void C_ccall f_488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_465)
static void C_fcall f_465(C_word t0,C_word t1) C_noret;
C_noret_decl(f_485)
static void C_ccall f_485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_469)
static void C_ccall f_469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_446)
static void C_fcall f_446(C_word t0,C_word t1) C_noret;
C_noret_decl(f_408)
static void C_ccall f_408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_426)
static void C_ccall f_426(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_434)
static void C_ccall f_434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_438)
static void C_ccall f_438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_424)
static void C_ccall f_424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_411)
static void C_ccall f_411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_401)
static void C_fcall f_401(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1003)
static void C_ccall f_1003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1006)
static void C_ccall f_1006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1241)
static void C_ccall f_1241(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1009)
static void C_ccall f_1009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1192)
static void C_ccall f_1192(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1210)
static void C_fcall f_1210(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1217)
static void C_fcall f_1217(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1190)
static void C_ccall f_1190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1012)
static void C_ccall f_1012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1178)
static void C_ccall f_1178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1182)
static void C_ccall f_1182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1015)
static void C_fcall f_1015(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1158)
static void C_ccall f_1158(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1156)
static void C_ccall f_1156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1098)
static void C_ccall f_1098(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1118)
static void C_ccall f_1118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1122)
static void C_ccall f_1122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1126)
static void C_ccall f_1126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1130)
static void C_ccall f_1130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1134)
static void C_ccall f_1134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1019)
static void C_ccall f_1019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1028)
static void C_ccall f_1028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1080)
static void C_ccall f_1080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1088)
static void C_ccall f_1088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1031)
static void C_ccall f_1031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1048)
static void C_ccall f_1048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1066)
static void C_ccall f_1066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1058)
static void C_ccall f_1058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1051)
static void C_ccall f_1051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1033)
static void C_ccall f_1033(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1045)
static void C_ccall f_1045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1041)
static void C_ccall f_1041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1252)
static void C_ccall f_1252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1258)
static void C_ccall f_1258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1255)
static void C_ccall f_1255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_943)
static void C_fcall f_943(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_997)
static void C_ccall f_997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_954)
static void C_ccall f_954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_986)
static void C_ccall f_986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_990)
static void C_ccall f_990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_978)
static void C_ccall f_978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_966)
static void C_ccall f_966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_962)
static void C_ccall f_962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_863)
static void C_ccall f_863(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_863)
static void C_ccall f_863r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_895)
static void C_fcall f_895(C_word t0,C_word t1) C_noret;
C_noret_decl(f_890)
static void C_fcall f_890(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_865)
static void C_fcall f_865(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_872)
static void C_ccall f_872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_796)
static void C_ccall f_796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_800)
static void C_ccall f_800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_810)
static void C_ccall f_810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_812)
static void C_fcall f_812(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_853)
static void C_ccall f_853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_839)
static void C_ccall f_839(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_837)
static void C_ccall f_837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_822)
static void C_ccall f_822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_829)
static void C_ccall f_829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_803)
static void C_ccall f_803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_712)
static void C_ccall f_712(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_720)
static void C_ccall f_720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_724)
static void C_ccall f_724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_683)
static void C_ccall f_683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_654)
static void C_ccall f_654(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_619)
static void C_ccall f_619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_344)
static void C_fcall f_344(C_word t0) C_noret;
C_noret_decl(f_355)
static void C_ccall f_355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_348)
static void C_ccall f_348(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_391)
static void C_fcall trf_391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_391(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_391(t0,t1,t2);}

C_noret_decl(trf_593)
static void C_fcall trf_593(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_593(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_593(t0,t1);}

C_noret_decl(trf_744)
static void C_fcall trf_744(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_744(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_744(t0,t1,t2);}

C_noret_decl(trf_465)
static void C_fcall trf_465(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_465(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_465(t0,t1);}

C_noret_decl(trf_446)
static void C_fcall trf_446(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_446(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_446(t0,t1);}

C_noret_decl(trf_401)
static void C_fcall trf_401(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_401(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_401(t0,t1);}

C_noret_decl(trf_1210)
static void C_fcall trf_1210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1210(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1210(t0,t1);}

C_noret_decl(trf_1217)
static void C_fcall trf_1217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1217(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1217(t0,t1);}

C_noret_decl(trf_1015)
static void C_fcall trf_1015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1015(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1015(t0,t1);}

C_noret_decl(trf_943)
static void C_fcall trf_943(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_943(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_943(t0,t1,t2);}

C_noret_decl(trf_895)
static void C_fcall trf_895(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_895(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_895(t0,t1);}

C_noret_decl(trf_890)
static void C_fcall trf_890(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_890(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_890(t0,t1,t2);}

C_noret_decl(trf_865)
static void C_fcall trf_865(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_865(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_865(t0,t1,t2,t3);}

C_noret_decl(trf_812)
static void C_fcall trf_812(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_812(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_812(t0,t1,t2);}

C_noret_decl(trf_344)
static void C_fcall trf_344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_344(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_344(t0);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(396)){
C_save(t1);
C_rereclaim2(396*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,92);
lf[8]=C_h_intern(&lf[8],4,"exit");
lf[9]=C_h_intern(&lf[9],7,"display");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\001\242)\012 -no-unused                remove procedures that are never called\012 -top "
"N                    display only the top N entries\012 -help                     s"
"how this text and exit\012 -version                  show version and exit\012 -releas"
"e                  show release number and exit\012\012 FILENAME defaults to the `PROF"
"ILE.<number>\047, selecting the one with\012 the highest modification time, in case mu"
"ltiple profiles exist.\012");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\001\315Usage: chicken-profile [FILENAME | OPTION] ...\012\012 -sort-by-calls            "
"sort output by call frequency\012 -sort-by-time             sort output by procedur"
"e execution time\012 -sort-by-avg              sort output by average procedure exe"
"cution time\012 -sort-by-name             sort output alphabetically by procedure n"
"ame\012 -decimals DDD             set number of decimals for seconds, average and\012 "
"                          percent columns (three digits, default: ");
lf[14]=C_h_intern(&lf[14],19,"\003sysprint-to-string");
lf[19]=C_h_intern(&lf[19],8,"string<\077");
lf[20]=C_h_intern(&lf[20],14,"symbol->string");
lf[22]=C_h_intern(&lf[22],17,"hash-table->alist");
lf[23]=C_h_intern(&lf[23],4,"read");
lf[24]=C_h_intern(&lf[24],15,"hash-table-set!");
lf[25]=C_h_intern(&lf[25],3,"map");
lf[26]=C_h_intern(&lf[26],22,"hash-table-ref/default");
lf[27]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\000\376\003\000\000\002\376\377\001\000\000\000\000\376\377\016");
lf[28]=C_h_intern(&lf[28],15,"make-hash-table");
lf[29]=C_h_intern(&lf[29],3,"eq\077");
lf[31]=C_h_intern(&lf[31],13,"string-append");
lf[32]=C_h_intern(&lf[32],11,"make-string");
lf[33]=C_h_intern(&lf[33],9,"\003syserror");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[38]=C_h_intern(&lf[38],9,"substring");
lf[39]=C_h_intern(&lf[39],8,"truncate");
lf[40]=C_h_intern(&lf[40],4,"expt");
lf[41]=C_h_intern(&lf[41],25,"\003sysimplicit-exit-handler");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\011procedure");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\005calls");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\007seconds");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\007average");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\007percent");
lf[47]=C_h_intern(&lf[47],5,"print");
lf[48]=C_h_intern(&lf[48],11,"string-join");
lf[49]=C_h_intern(&lf[49],12,"\003sysfor-each");
lf[50]=C_h_intern(&lf[50],6,"reduce");
lf[51]=C_h_intern(&lf[51],1,"+");
lf[52]=C_h_intern(&lf[52],3,"max");
lf[53]=C_h_intern(&lf[53],7,"\003sysmap");
lf[54]=C_h_intern(&lf[54],13,"string-length");
lf[55]=C_h_intern(&lf[55],4,"fold");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\010overflow");
lf[57]=C_h_intern(&lf[57],28,"\003syssymbol->qualified-string");
lf[58]=C_h_intern(&lf[58],6,"remove");
lf[59]=C_h_intern(&lf[59],4,"take");
lf[60]=C_h_intern(&lf[60],4,"sort");
lf[61]=C_h_intern(&lf[61],6,"append");
lf[62]=C_h_intern(&lf[62],20,"with-input-from-file");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\011reading `");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\006\047 ...\012");
lf[65]=C_h_intern(&lf[65],5,"error");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\021no PROFILEs found");
lf[67]=C_h_intern(&lf[67],22,"file-modification-time");
lf[68]=C_h_intern(&lf[68],4,"glob");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\011PROFILE.*");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\032missing argument to option");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid argument to option");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\032chicken-profile - Version ");
lf[78]=C_h_intern(&lf[78],15,"chicken-version");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\010-release");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\012-no-unused");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\004-top");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\016-sort-by-calls");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\015-sort-by-time");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\014-sort-by-avg");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\015-sort-by-name");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\011-decimals");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000$invalid argument to -decimals option");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000$invalid argument to -decimals option");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid option");
lf[91]=C_h_intern(&lf[91],22,"command-line-arguments");
C_register_lf2(lf,92,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_305,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k303 */
static void C_ccall f_305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_308,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k306 in k303 */
static void C_ccall f_308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_311,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k309 in k306 in k303 */
static void C_ccall f_311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_314,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k312 in k309 in k306 in k303 */
static void C_ccall f_314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_317,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_320,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_323,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_326,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_329,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_332,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_335,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_335,2,t0,t1);}
t2=lf[0] /* sort-by */ =C_SCHEME_FALSE;;
t3=lf[1] /* file */ =C_SCHEME_FALSE;;
t4=lf[2] /* no-unused */ =C_SCHEME_FALSE;;
t5=lf[3] /* seconds-digits */ =C_fix(3);;
t6=lf[4] /* average-digits */ =C_fix(3);;
t7=lf[5] /* percent-digits */ =C_fix(3);;
t8=lf[6] /* top */ =C_fix(0);;
t9=C_mutate(&lf[7] /* print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_344,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[15] /* sort-by-calls ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_619,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[16] /* sort-by-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_654,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[17] /* sort-by-avg ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_683,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate(&lf[18] /* sort-by-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_712,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate(&lf[0] /* sort-by ...) */,lf[16]);
t15=C_mutate(&lf[21] /* read-profile ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_796,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[30] /* format-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_863,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[35] /* format-real ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_943,tmp=(C_word)a,a+=2,tmp));
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1252,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1262,a[2]=t18,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-profile.scm: 234  command-line-arguments");
t20=C_retrieve(lf[91]);
((C_proc2)C_retrieve_proc(t20))(2,t20,t19);}

/* k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1262,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_391,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_391(t5,((C_word*)t0)[2],t1);}

/* loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_fcall f_391(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[43],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_391,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_401,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(lf[1])){
t4=t3;
f_401(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_408,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-profile.scm: 73   glob");
t5=C_retrieve(lf[68]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[69]);}}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_446,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_465,a[2]=t7,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_488,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[72]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[73]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[74]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
C_trace("chicken-profile.scm: 93   print-usage");
f_344(t9);}
else{
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[75]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[76]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_506,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_513,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-profile.scm: 95   chicken-version");
t12=C_retrieve(lf[78]);
((C_proc2)C_retrieve_proc(t12))(2,t12,t11);}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[79]))){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_522,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_529,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-profile.scm: 98   chicken-version");
t12=C_retrieve(lf[78]);
((C_proc2)C_retrieve_proc(t12))(2,t12,t11);}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[80]))){
t10=lf[2] /* no-unused */ =C_SCHEME_TRUE;;
t11=t9;
f_488(2,t11,t10);}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[81]))){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_546,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-profile.scm: 101  next-number");
t11=t8;
f_465(t11,t10);}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[82]))){
t10=C_mutate(&lf[0] /* sort-by ...) */,lf[15]);
t11=t9;
f_488(2,t11,t10);}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[83]))){
t10=C_mutate(&lf[0] /* sort-by ...) */,lf[16]);
t11=t9;
f_488(2,t11,t10);}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[84]))){
t10=C_mutate(&lf[0] /* sort-by ...) */,lf[17]);
t11=t9;
f_488(2,t11,t10);}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[85]))){
t10=C_mutate(&lf[0] /* sort-by ...) */,lf[18]);
t11=t9;
f_488(2,t11,t10);}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[86]))){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_587,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-profile.scm: 106  next-arg");
t11=t7;
f_446(t11,t10);}
else{
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_593,a[2]=t3,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_i_string_length(t3);
if(C_truep((C_word)C_i_greaterp(t11,C_fix(1)))){
t12=(C_word)C_i_string_ref(t3,C_fix(0));
t13=t10;
f_593(t13,(C_word)C_eqp(C_make_character(45),t12));}
else{
t12=t10;
f_593(t12,C_SCHEME_FALSE);}}}}}}}}}}}}}

/* k591 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_fcall f_593(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
C_trace("chicken-profile.scm: 108  error");
t2=*((C_word*)lf[65]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[90],((C_word*)t0)[2]);}
else{
if(C_truep(lf[1])){
C_trace("chicken-profile.scm: 109  print-usage");
f_344(((C_word*)t0)[3]);}
else{
t2=C_mutate(&lf[1] /* file ...) */,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_488(2,t3,t2);}}}

/* k585 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_587,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
if(C_truep((C_word)C_i_nequalp(t2,C_fix(3)))){
t3=C_mutate(&lf[87] /* arg-digit ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_744,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_779,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-profile.scm: 148  arg-digit");
t5=C_retrieve2(lf[87],"arg-digit");
f_744(t5,t4,C_fix(0));}
else{
C_trace("chicken-profile.scm: 151  error");
t3=*((C_word*)lf[65]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],lf[89],t1);}}

/* k777 in k585 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_779,2,t0,t1);}
t2=C_mutate(&lf[3] /* seconds-digits ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_783,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-profile.scm: 149  arg-digit");
t4=C_retrieve2(lf[87],"arg-digit");
f_744(t4,t3,C_fix(1));}

/* k781 in k777 in k585 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_783,2,t0,t1);}
t2=C_mutate(&lf[4] /* average-digits ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_787,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-profile.scm: 150  arg-digit");
t4=C_retrieve2(lf[87],"arg-digit");
f_744(t4,t3,C_fix(2));}

/* k785 in k781 in k777 in k585 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[5] /* percent-digits ...) */,t1);
t3=((C_word*)t0)[2];
f_488(2,t3,t2);}

/* arg-digit in k585 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_fcall f_744(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_744,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_string_ref(((C_word*)t0)[2],t2);
t4=(C_word)C_fix((C_word)C_character_code(t3));
t5=(C_word)C_a_i_minus(&a,2,t4,C_fix(48));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_754,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("chicken-profile.scm: 145  <=");
C_less_or_equal_p(5,0,t6,C_fix(0),t5,C_fix(9));}

/* k752 in arg-digit in k585 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_nequalp(((C_word*)t0)[4],C_fix(9));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_fix(8):((C_word*)t0)[4]));}
else{
C_trace("chicken-profile.scm: 147  error");
t2=*((C_word*)lf[65]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[88],((C_word*)t0)[2]);}}

/* k544 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[6] /* top ...) */,t1);
t3=((C_word*)t0)[2];
f_488(2,t3,t2);}

/* k527 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-profile.scm: 98   print");
t2=*((C_word*)lf[47]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k520 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-profile.scm: 99   exit");
t2=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k511 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-profile.scm: 95   print");
t2=*((C_word*)lf[47]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[77],t1);}

/* k504 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-profile.scm: 96   exit");
t2=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k486 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-profile.scm: 111  loop");
t2=((C_word*)((C_word*)t0)[4])[1];
f_391(t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* next-number in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_fcall f_465(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_465,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_469,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_485,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-profile.scm: 90   next-arg");
t4=((C_word*)t0)[2];
f_446(t4,t3);}

/* k483 in next-number in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-profile.scm: 90   string->number");
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k467 in next-number in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_i_greaterp(t1,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
C_trace("chicken-profile.scm: 91   error");
t3=*((C_word*)lf[65]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],lf[71],((C_word*)t0)[2]);}}

/* next-arg in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_fcall f_446(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_446,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
C_trace("chicken-profile.scm: 85   error");
t2=*((C_word*)lf[65]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[70],((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* k406 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_411,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t1))){
C_trace("chicken-profile.scm: 75   error");
t3=*((C_word*)lf[65]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[66]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_424,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_426,tmp=(C_word)a,a+=2,tmp);
C_trace("chicken-profile.scm: 76   sort");
t5=C_retrieve(lf[60]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t1,t4);}}

/* a425 in k406 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_426(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_426,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_434,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("chicken-profile.scm: 78   file-modification-time");
t5=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k432 in a425 in k406 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_438,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("chicken-profile.scm: 79   file-modification-time");
t3=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k436 in k432 in a425 in k406 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_greaterp(((C_word*)t0)[2],t1));}

/* k422 in k406 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_411(2,t2,(C_word)C_i_car(t1));}

/* k409 in k406 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[1] /* file ...) */,t1);
t3=((C_word*)t0)[2];
f_401(t3,t2);}

/* k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_fcall f_401(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_401,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1003,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-profile.scm: 184  print");
t4=*((C_word*)lf[47]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[63],lf[1],lf[64]);}

/* k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1006,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-profile.scm: 185  with-input-from-file");
t3=C_retrieve(lf[62]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[1],lf[21]);}

/* k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1009,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1241,tmp=(C_word)a,a+=2,tmp);
C_trace("chicken-profile.scm: 186  fold");
t4=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,C_fix(0),t1);}

/* a1240 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1241(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1241,4,t0,t1,t2,t3);}
t4=(C_word)C_i_caddr(t2);
C_trace("chicken-profile.scm: 187  max");
t5=*((C_word*)lf[52]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t3);}

/* k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1012,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1190,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1192,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t5=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a1191 in k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1192(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1192,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_caddr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1210,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t6=(C_word)C_i_greaterp(t3,C_fix(0));
t7=t5;
f_1210(t7,(C_truep(t6)?(C_word)C_a_i_divide(&a,2,t4,t3):C_SCHEME_FALSE));}
else{
t6=t5;
f_1210(t6,C_SCHEME_FALSE);}}

/* k1208 in a1191 in k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_fcall f_1210(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1210,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1217,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_greaterp(((C_word*)t0)[3],C_fix(0)))){
t4=(C_word)C_a_i_divide(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t5=t3;
f_1217(t5,(C_word)C_a_i_times(&a,2,t4,C_fix(100)));}
else{
t4=t3;
f_1217(t4,C_SCHEME_FALSE);}}

/* k1215 in k1208 in a1191 in k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_fcall f_1217(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1217,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t2);
C_trace("chicken-profile.scm: 191  append");
t4=*((C_word*)lf[61]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k1188 in k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-profile.scm: 190  sort");
t2=C_retrieve(lf[60]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[0]);}

/* k1010 in k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1012,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1015,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1178,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_length(((C_word*)t3)[1]);
C_trace("chicken-profile.scm: 200  <");
C_lessp(5,0,t5,C_fix(0),lf[6],t6);}

/* k1176 in k1010 in k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1178,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1182,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("chicken-profile.scm: 201  take");
t3=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],lf[6]);}
else{
t2=((C_word*)t0)[2];
f_1015(t2,C_SCHEME_UNDEFINED);}}

/* k1180 in k1176 in k1010 in k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1015(t3,t2);}

/* k1013 in k1010 in k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_fcall f_1015(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1015,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1098,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1156,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1158,tmp=(C_word)a,a+=2,tmp);
C_trace("chicken-profile.scm: 212  remove");
t6=C_retrieve(lf[58]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)((C_word*)t0)[3])[1]);}

/* a1157 in k1013 in k1010 in k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1158(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1158,3,t0,t1,t2);}
if(C_truep((C_word)C_i_cadr(t2))){
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_zerop(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?lf[2]:C_SCHEME_FALSE));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1154 in k1013 in k1010 in k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1097 in k1013 in k1010 in k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1098(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1098,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_caddr(t2);
t5=(C_word)C_i_cadddr(t2);
t6=(C_word)C_i_list_ref(t2,C_fix(4));
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1118,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=t6,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_i_car(t2);
C_trace("chicken-profile.scm: 207  ##sys#symbol->qualified-string");
t9=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t7,t8);}

/* k1116 in a1097 in k1013 in k1010 in k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1122,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("chicken-profile.scm: 208  number->string");
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_1122(2,t3,lf[56]);}}

/* k1120 in k1116 in a1097 in k1013 in k1010 in k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1126,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_a_i_divide(&a,2,((C_word*)t0)[2],C_fix(1000));
C_trace("chicken-profile.scm: 209  format-real");
f_943(t2,t3,lf[3]);}

/* k1124 in k1120 in k1116 in a1097 in k1013 in k1010 in k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1126,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1130,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_a_i_divide(&a,2,((C_word*)t0)[2],C_fix(1000));
C_trace("chicken-profile.scm: 210  format-real");
f_943(t2,t3,lf[4]);}

/* k1128 in k1124 in k1120 in k1116 in a1097 in k1013 in k1010 in k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1130,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1134,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("chicken-profile.scm: 211  format-real");
f_943(t2,((C_word*)t0)[2],lf[5]);}

/* k1132 in k1128 in k1124 in k1120 in k1116 in a1097 in k1013 in k1010 in k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1134,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k1017 in k1013 in k1010 in k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1019,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=(C_word)C_a_i_list(&a,5,lf[42],lf[43],lf[44],lf[45],lf[46]);
t4=(C_word)C_a_i_list(&a,5,C_SCHEME_FALSE,C_SCHEME_TRUE,C_SCHEME_TRUE,C_SCHEME_TRUE,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1028,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
C_trace("chicken-profile.scm: 220  make-string");
t6=*((C_word*)lf[32]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_fix(2),C_make_character(32));}

/* k1026 in k1017 in k1013 in k1010 in k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1031,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1080,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_a_i_list(&a,5,C_fix(0),C_fix(0),C_fix(0),C_fix(0),C_fix(0));
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
C_trace("chicken-profile.scm: 221  fold");
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t2,t3,t4,t5);}

/* a1079 in k1026 in k1017 in k1013 in k1010 in k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1080,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1088,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t5=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[54]+1),t2);}

/* k1086 in a1079 in k1026 in k1017 in k1013 in k1010 in k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-profile.scm: 223  map");
t2=*((C_word*)lf[25]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[52]+1),t1,((C_word*)t0)[2]);}

/* k1029 in k1026 in k1017 in k1013 in k1010 in k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1033,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1048,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("chicken-profile.scm: 228  print-row");
t4=t2;
f_1033(3,t4,t3,((C_word*)t0)[2]);}

/* k1046 in k1029 in k1026 in k1017 in k1013 in k1010 in k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1051,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1058,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1066,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("chicken-profile.scm: 229  reduce");
t5=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[51]+1),C_fix(0),((C_word*)t0)[2]);}

/* k1064 in k1046 in k1029 in k1026 in k1017 in k1013 in k1010 in k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1066,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
t3=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
t4=(C_word)C_a_i_times(&a,2,C_fix(2),t3);
t5=(C_word)C_a_i_plus(&a,2,t1,t4);
C_trace("chicken-profile.scm: 229  make-string");
t6=*((C_word*)lf[32]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[2],t5,C_make_character(45));}

/* k1056 in k1046 in k1029 in k1026 in k1017 in k1013 in k1010 in k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-profile.scm: 229  print");
t2=*((C_word*)lf[47]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1049 in k1046 in k1029 in k1026 in k1017 in k1013 in k1010 in k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("for-each");
t2=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* print-row in k1029 in k1026 in k1017 in k1013 in k1010 in k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1033(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1033,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1041,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1045,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("chicken-profile.scm: 227  map");
t5=*((C_word*)lf[25]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,lf[30],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1043 in print-row in k1029 in k1026 in k1017 in k1013 in k1010 in k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-profile.scm: 227  string-join");
t2=C_retrieve(lf[48]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1039 in print-row in k1029 in k1026 in k1017 in k1013 in k1010 in k1007 in k1004 in k1001 in k399 in loop in k1260 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-profile.scm: 227  print");
t2=*((C_word*)lf[47]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1250 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1255,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1258,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#implicit-exit-handler");
t4=C_retrieve(lf[41]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k1256 in k1250 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1253 in k1250 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_1255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* format-real in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_fcall f_943(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_943,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_997,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("chicken-profile.scm: 172  truncate");
t5=*((C_word*)lf[39]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k995 in format-real in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_997,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_954,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("chicken-profile.scm: 174  number->string");
C_number_to_string(3,0,t3,t2);}

/* k952 in k995 in format-real in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_954,2,t0,t1);}
t2=(C_word)C_i_greaterp(((C_word*)t0)[5],C_fix(0));
t3=(C_truep(t2)?lf[36]:lf[37]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_962,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_966,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_978,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_986,a[2]=((C_word*)t0)[5],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
C_trace("chicken-profile.scm: 180  -");
C_minus(5,0,t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(-1));}

/* k984 in k952 in k995 in format-real in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_990,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("chicken-profile.scm: 180  expt");
t3=*((C_word*)lf[40]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_fix(10),((C_word*)t0)[2]);}

/* k988 in k984 in k952 in k995 in format-real in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_990,2,t0,t1);}
t2=(C_word)C_a_i_times(&a,2,((C_word*)t0)[3],t1);
C_trace("chicken-profile.scm: 179  truncate");
t3=*((C_word*)lf[39]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k976 in k952 in k995 in format-real in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_inexact_to_exact(t1);
C_trace("chicken-profile.scm: 177  number->string");
C_number_to_string(3,0,((C_word*)t0)[2],t2);}

/* k964 in k952 in k995 in format-real in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_966,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
C_trace("chicken-profile.scm: 176  substring");
t3=*((C_word*)lf[38]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],t1,C_fix(1),t2);}

/* k960 in k952 in k995 in format-real in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-profile.scm: 173  string-append");
t2=*((C_word*)lf[31]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* format-string in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_863(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_863r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_863r(t0,t1,t2,t3,t4);}}

static void C_ccall f_863r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_865,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_890,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_895,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
C_trace("def-right153175");
t8=t7;
f_895(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
C_trace("def-padc154171");
t10=t6;
f_890(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
C_trace("body151160");
t12=t5;
f_865(t12,t1,t8,t10);}
else{
C_trace("##sys#error");
t12=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[34],t11);}}}}

/* def-right153 in format-string in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_fcall f_895(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_895,NULL,2,t0,t1);}
C_trace("def-padc154171");
t2=((C_word*)t0)[2];
f_890(t2,t1,C_SCHEME_FALSE);}

/* def-padc154 in format-string in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_fcall f_890(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_890,NULL,3,t0,t1,t2);}
C_trace("body151160");
t3=((C_word*)t0)[2];
f_865(t3,t1,t2,C_make_character(32));}

/* body151 in format-string in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_fcall f_865(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_865,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_length(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_872,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_difference(((C_word*)t0)[2],t4);
t7=(C_word)C_i_fixnum_max(C_fix(0),t6);
C_trace("chicken-profile.scm: 166  make-string");
t8=*((C_word*)lf[32]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t5,t7,t3);}

/* k870 in body151 in format-string in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
C_trace("chicken-profile.scm: 168  string-append");
t2=*((C_word*)lf[31]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
C_trace("chicken-profile.scm: 169  string-append");
t2=*((C_word*)lf[31]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}}

/* read-profile in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_800,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-profile.scm: 154  make-hash-table");
t3=C_retrieve(lf[28]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,*((C_word*)lf[29]+1));}

/* k798 in read-profile in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_803,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_810,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("chicken-profile.scm: 155  read");
t4=*((C_word*)lf[23]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k808 in k798 in read-profile in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_810,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_812,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_812(t5,((C_word*)t0)[2],t1);}

/* doloop109 in k808 in k798 in read-profile in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_fcall f_812(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_812,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_822,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_837,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_839,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_853,a[2]=t6,a[3]=t5,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_car(t2);
C_trace("chicken-profile.scm: 160  hash-table-ref/default");
t9=C_retrieve(lf[26]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,((C_word*)t0)[2],t8,lf[27]);}}

/* k851 in doloop109 in k808 in k798 in read-profile in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("chicken-profile.scm: 159  map");
t3=*((C_word*)lf[25]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* a838 in doloop109 in k808 in k798 in read-profile in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_839(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_839,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t2)?(C_truep(t3)?(C_word)C_a_i_plus(&a,2,t2,t3):C_SCHEME_FALSE):C_SCHEME_FALSE));}

/* k835 in doloop109 in k808 in k798 in read-profile in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-profile.scm: 157  hash-table-set!");
t2=C_retrieve(lf[24]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k820 in doloop109 in k808 in k798 in read-profile in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_829,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("chicken-profile.scm: 155  read");
t3=*((C_word*)lf[23]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k827 in k820 in doloop109 in k808 in k798 in read-profile in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_812(t2,((C_word*)t0)[2],t1);}

/* k801 in k798 in read-profile in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-profile.scm: 162  hash-table->alist");
t2=C_retrieve(lf[22]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* sort-by-name in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_712(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_712,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_720,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t2);
C_trace("chicken-profile.scm: 135  symbol->string");
t6=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k718 in sort-by-name in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_724,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
C_trace("chicken-profile.scm: 135  symbol->string");
t4=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k722 in k718 in sort-by-name in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-profile.scm: 135  string<?");
t2=*((C_word*)lf[19]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* sort-by-avg in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_683,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cadddr(t2);
t5=(C_word)C_i_cadddr(t3);
if(C_truep((C_word)C_i_eqvp(t4,t5))){
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_caddr(t3);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_greaterp(t6,t7));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_greaterp(t4,t5));}}

/* sort-by-time in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_654(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_654,4,t0,t1,t2,t3);}
t4=(C_word)C_i_caddr(t2);
t5=(C_word)C_i_caddr(t3);
if(C_truep((C_word)C_i_nequalp(t4,t5))){
t6=(C_word)C_i_cadr(t2);
t7=(C_word)C_i_cadr(t3);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_greaterp(t6,t7));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_greaterp(t4,t5));}}

/* sort-by-calls in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_619,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_i_cadr(t3);
if(C_truep((C_word)C_i_eqvp(t4,t5))){
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_caddr(t3);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_greaterp(t6,t7));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t4)?(C_truep(t5)?(C_word)C_i_greaterp(t4,t5):C_SCHEME_TRUE):C_SCHEME_TRUE));}}

/* print-usage in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_fcall f_344(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_344,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_348,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_355,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,lf[10],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[5],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[11],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[4],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[12],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[3],t8);
t10=(C_word)C_a_i_cons(&a,2,lf[13],t9);
C_trace("chicken-profile.scm: 45   ##sys#print-to-string");
t11=C_retrieve(lf[14]);
((C_proc3)C_retrieve_proc(t11))(3,t11,t3,t10);}

/* k353 in print-usage in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-profile.scm: 45   display");
t2=*((C_word*)lf[9]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k346 in print-usage in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 in k306 in k303 */
static void C_ccall f_348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-profile.scm: 65   exit");
t2=C_retrieve(lf[8]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(64));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[106] = {
{"toplevelchicken-profile.scm",(void*)C_toplevel},
{"f_305chicken-profile.scm",(void*)f_305},
{"f_308chicken-profile.scm",(void*)f_308},
{"f_311chicken-profile.scm",(void*)f_311},
{"f_314chicken-profile.scm",(void*)f_314},
{"f_317chicken-profile.scm",(void*)f_317},
{"f_320chicken-profile.scm",(void*)f_320},
{"f_323chicken-profile.scm",(void*)f_323},
{"f_326chicken-profile.scm",(void*)f_326},
{"f_329chicken-profile.scm",(void*)f_329},
{"f_332chicken-profile.scm",(void*)f_332},
{"f_335chicken-profile.scm",(void*)f_335},
{"f_1262chicken-profile.scm",(void*)f_1262},
{"f_391chicken-profile.scm",(void*)f_391},
{"f_593chicken-profile.scm",(void*)f_593},
{"f_587chicken-profile.scm",(void*)f_587},
{"f_779chicken-profile.scm",(void*)f_779},
{"f_783chicken-profile.scm",(void*)f_783},
{"f_787chicken-profile.scm",(void*)f_787},
{"f_744chicken-profile.scm",(void*)f_744},
{"f_754chicken-profile.scm",(void*)f_754},
{"f_546chicken-profile.scm",(void*)f_546},
{"f_529chicken-profile.scm",(void*)f_529},
{"f_522chicken-profile.scm",(void*)f_522},
{"f_513chicken-profile.scm",(void*)f_513},
{"f_506chicken-profile.scm",(void*)f_506},
{"f_488chicken-profile.scm",(void*)f_488},
{"f_465chicken-profile.scm",(void*)f_465},
{"f_485chicken-profile.scm",(void*)f_485},
{"f_469chicken-profile.scm",(void*)f_469},
{"f_446chicken-profile.scm",(void*)f_446},
{"f_408chicken-profile.scm",(void*)f_408},
{"f_426chicken-profile.scm",(void*)f_426},
{"f_434chicken-profile.scm",(void*)f_434},
{"f_438chicken-profile.scm",(void*)f_438},
{"f_424chicken-profile.scm",(void*)f_424},
{"f_411chicken-profile.scm",(void*)f_411},
{"f_401chicken-profile.scm",(void*)f_401},
{"f_1003chicken-profile.scm",(void*)f_1003},
{"f_1006chicken-profile.scm",(void*)f_1006},
{"f_1241chicken-profile.scm",(void*)f_1241},
{"f_1009chicken-profile.scm",(void*)f_1009},
{"f_1192chicken-profile.scm",(void*)f_1192},
{"f_1210chicken-profile.scm",(void*)f_1210},
{"f_1217chicken-profile.scm",(void*)f_1217},
{"f_1190chicken-profile.scm",(void*)f_1190},
{"f_1012chicken-profile.scm",(void*)f_1012},
{"f_1178chicken-profile.scm",(void*)f_1178},
{"f_1182chicken-profile.scm",(void*)f_1182},
{"f_1015chicken-profile.scm",(void*)f_1015},
{"f_1158chicken-profile.scm",(void*)f_1158},
{"f_1156chicken-profile.scm",(void*)f_1156},
{"f_1098chicken-profile.scm",(void*)f_1098},
{"f_1118chicken-profile.scm",(void*)f_1118},
{"f_1122chicken-profile.scm",(void*)f_1122},
{"f_1126chicken-profile.scm",(void*)f_1126},
{"f_1130chicken-profile.scm",(void*)f_1130},
{"f_1134chicken-profile.scm",(void*)f_1134},
{"f_1019chicken-profile.scm",(void*)f_1019},
{"f_1028chicken-profile.scm",(void*)f_1028},
{"f_1080chicken-profile.scm",(void*)f_1080},
{"f_1088chicken-profile.scm",(void*)f_1088},
{"f_1031chicken-profile.scm",(void*)f_1031},
{"f_1048chicken-profile.scm",(void*)f_1048},
{"f_1066chicken-profile.scm",(void*)f_1066},
{"f_1058chicken-profile.scm",(void*)f_1058},
{"f_1051chicken-profile.scm",(void*)f_1051},
{"f_1033chicken-profile.scm",(void*)f_1033},
{"f_1045chicken-profile.scm",(void*)f_1045},
{"f_1041chicken-profile.scm",(void*)f_1041},
{"f_1252chicken-profile.scm",(void*)f_1252},
{"f_1258chicken-profile.scm",(void*)f_1258},
{"f_1255chicken-profile.scm",(void*)f_1255},
{"f_943chicken-profile.scm",(void*)f_943},
{"f_997chicken-profile.scm",(void*)f_997},
{"f_954chicken-profile.scm",(void*)f_954},
{"f_986chicken-profile.scm",(void*)f_986},
{"f_990chicken-profile.scm",(void*)f_990},
{"f_978chicken-profile.scm",(void*)f_978},
{"f_966chicken-profile.scm",(void*)f_966},
{"f_962chicken-profile.scm",(void*)f_962},
{"f_863chicken-profile.scm",(void*)f_863},
{"f_895chicken-profile.scm",(void*)f_895},
{"f_890chicken-profile.scm",(void*)f_890},
{"f_865chicken-profile.scm",(void*)f_865},
{"f_872chicken-profile.scm",(void*)f_872},
{"f_796chicken-profile.scm",(void*)f_796},
{"f_800chicken-profile.scm",(void*)f_800},
{"f_810chicken-profile.scm",(void*)f_810},
{"f_812chicken-profile.scm",(void*)f_812},
{"f_853chicken-profile.scm",(void*)f_853},
{"f_839chicken-profile.scm",(void*)f_839},
{"f_837chicken-profile.scm",(void*)f_837},
{"f_822chicken-profile.scm",(void*)f_822},
{"f_829chicken-profile.scm",(void*)f_829},
{"f_803chicken-profile.scm",(void*)f_803},
{"f_712chicken-profile.scm",(void*)f_712},
{"f_720chicken-profile.scm",(void*)f_720},
{"f_724chicken-profile.scm",(void*)f_724},
{"f_683chicken-profile.scm",(void*)f_683},
{"f_654chicken-profile.scm",(void*)f_654},
{"f_619chicken-profile.scm",(void*)f_619},
{"f_344chicken-profile.scm",(void*)f_344},
{"f_355chicken-profile.scm",(void*)f_355},
{"f_348chicken-profile.scm",(void*)f_348},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
